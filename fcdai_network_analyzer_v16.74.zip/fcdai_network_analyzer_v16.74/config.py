"""
FCDAI Network Analyzer v14.5 - Configuration Loader
=====================================================
AIR-GAPPED | ZERO DATA LEAKAGE | PII PROTECTED | OFFLINE-ONLY
v14.5 fixes over v14.4:
  FIX-A: Score post-propagation rank-calibration (prevents 20-40% Critical inflation)
  FIX-B: Dashboard tier cards always use risk_tier column (consistent with exec summary)
  FIX-C: Pipeline completion triggers global-refresh-ts (all pages auto-sync after run)
  FIX-D: Top-flagged table uses tier column, not hard-coded score thresholds
  FIX-E: consensus_multiplier_rate 0.03 -> 0.015 (10-family max: 1.15x not 1.30x)
  FIX-F: Propagation boost 15/8/5 -> 10/5/3 (prevents hub-dominated inflation)
v14.4: NEW-08 thru NEW-17 (all unsupervised, air-gapped, n=50-10000 adaptive)
"""
# ── Developer Attribution (v16.45) ─────────────────────────────────────────
__author__  = "Das Apurba"
__team__    = "FCDAI Analytics"
__version__ = "16.74.0"

import yaml
from pathlib import Path
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional

BASE_DIR = Path(__file__).parent


def _load_yaml() -> dict:
    config_path = BASE_DIR / "config.yaml"
    if config_path.exists():
        with open(config_path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    return {}


_CFG = _load_yaml()


@dataclass
class PathConfig:
    BASE: Path = BASE_DIR
    DATA: Path = field(default_factory=lambda: BASE_DIR / _CFG.get("paths", {}).get("data", "data"))
    SAMPLES: Path = field(
        default_factory=lambda: BASE_DIR / _CFG.get("paths", {}).get("samples", "data/samples")
    )
    VAULT: Path = field(
        default_factory=lambda: BASE_DIR / _CFG.get("paths", {}).get("vault", "data/vault")
    )
    EXPORTS: Path = field(
        default_factory=lambda: BASE_DIR / _CFG.get("paths", {}).get("exports", "data/exports")
    )
    UPLOADS: Path = field(
        default_factory=lambda: BASE_DIR / _CFG.get("paths", {}).get("uploads", "data/uploads")
    )
    LOGS: Path = field(default_factory=lambda: BASE_DIR / _CFG.get("paths", {}).get("logs", "logs"))
    CACHE: Path = field(
        default_factory=lambda: BASE_DIR / _CFG.get("paths", {}).get("cache", "cache")
    )
    MODELS: Path = field(
        default_factory=lambda: BASE_DIR / _CFG.get("paths", {}).get("models", "models")
    )
    ASSETS: Path = field(
        default_factory=lambda: BASE_DIR / _CFG.get("paths", {}).get("assets", "assets")
    )
    DB_PATH: Path = field(
        default_factory=lambda: BASE_DIR / _CFG.get("paths", {}).get("db_path", "data/fcdai.db")
    )

    def __post_init__(self):
        for p in [
            self.DATA,
            self.SAMPLES,
            self.VAULT,
            self.EXPORTS,
            self.UPLOADS,
            self.LOGS,
            self.CACHE,
            self.MODELS,
            self.ASSETS,
        ]:
            p.mkdir(parents=True, exist_ok=True)


@dataclass
class ThemeConfig:
    PRIMARY: str = field(default_factory=lambda: _CFG.get("theme", {}).get("primary", "#00D4FF"))
    SECONDARY: str = field(
        default_factory=lambda: _CFG.get("theme", {}).get("secondary", "#9D4EDD")
    )
    ACCENT: str = field(default_factory=lambda: _CFG.get("theme", {}).get("accent", "#FF6B6B"))
    SUCCESS: str = field(default_factory=lambda: _CFG.get("theme", {}).get("success", "#00E676"))
    WARNING: str = field(default_factory=lambda: _CFG.get("theme", {}).get("warning", "#FFD600"))
    DANGER: str = field(default_factory=lambda: _CFG.get("theme", {}).get("danger", "#FF1744"))
    INFO: str = field(default_factory=lambda: _CFG.get("theme", {}).get("info", "#2196F3"))
    DARK_BG: str = field(default_factory=lambda: _CFG.get("theme", {}).get("dark_bg", "#0A0E17"))
    DARK_BG_CARD: str = field(
        default_factory=lambda: _CFG.get("theme", {}).get("dark_bg_card", "#111827")
    )
    DARK_BG_ELEVATED: str = field(
        default_factory=lambda: _CFG.get("theme", {}).get("dark_bg_elevated", "#1A2332")
    )
    DARK_BORDER: str = field(
        default_factory=lambda: _CFG.get("theme", {}).get("dark_border", "#1E293B")
    )
    GLASS_BG: str = field(
        default_factory=lambda: _CFG.get("theme", {}).get("glass_bg", "rgba(17, 24, 39, 0.7)")
    )
    GLASS_BORDER: str = field(
        default_factory=lambda: _CFG.get("theme", {}).get(
            "glass_border", "rgba(255, 255, 255, 0.08)"
        )
    )
    TEXT_PRIMARY: str = field(
        default_factory=lambda: _CFG.get("theme", {}).get("text_primary", "#E2E8F0")
    )
    TEXT_SECONDARY: str = field(
        default_factory=lambda: _CFG.get("theme", {}).get("text_secondary", "#94A3B8")
    )
    TEXT_MUTED: str = field(
        default_factory=lambda: _CFG.get("theme", {}).get("text_muted", "#64748B")
    )


@dataclass
class PipelineConfig:
    _raw: Dict = field(default_factory=lambda: _CFG.get("pipeline", {}))
    EXPECTED_TABLES: List[str] = field(
        default_factory=lambda: _CFG.get("pipeline", {}).get(
            "expected_tables",
            ["customer", "account", "kyc", "transaction", "historical", "alert", "relationship"],
        )
    )
    DQ_THRESHOLDS: Dict[str, float] = field(
        default_factory=lambda: _CFG.get("pipeline", {}).get(
            "dq_thresholds", {"completeness": 0.90, "consistency": 0.85, "validity": 0.80}
        )
    )
    CUSTOMER_ID_COL: str = field(
        default_factory=lambda: _CFG.get("pipeline", {}).get("customer_id_column", "customer_id")
    )
    ACCOUNT_ID_COL: str = field(
        default_factory=lambda: _CFG.get("pipeline", {}).get("account_id_column", "account_id")
    )
    AMOUNT_COL: str = field(
        default_factory=lambda: _CFG.get("pipeline", {}).get("amount_column", "amount")
    )
    TIMESTAMP_COL: str = field(
        default_factory=lambda: _CFG.get("pipeline", {}).get("timestamp_column", "timestamp")
    )
    GRAPH_MAX_NODES: int = field(
        default_factory=lambda: _CFG.get("pipeline", {}).get("graph", {}).get("max_nodes", 10000)
    )
    GRAPH_LAYOUT: str = field(
        default_factory=lambda: _CFG.get("pipeline", {})
        .get("graph", {})
        .get("layout", "cose-bilkent")
    )
    SIMILARITY_THRESHOLD: float = field(
        default_factory=lambda: _CFG.get("pipeline", {})
        .get("graph", {})
        .get("similarity_threshold", 0.7)
    )
    ANALYTICS: Dict[str, Any] = field(
        default_factory=lambda: _CFG.get("pipeline", {}).get("analytics", {})
    )
    RISK_WEIGHTS: Dict[str, float] = field(
        default_factory=lambda: _CFG.get("pipeline", {})
        .get("scoring", {})
        .get("risk_formula_weights", {})
    )
    RISK_TIERS: Dict[str, List] = field(
        default_factory=lambda: _CFG.get("pipeline", {})
        .get("scoring", {})
        .get("risk_tiers", {"P1": [80, 100], "P2": [60, 80], "P3": [40, 60], "P4": [0, 40]})
    )
    RISK_TIER_MODE: str = field(
        default_factory=lambda: _CFG.get("pipeline", {})
        .get("scoring", {})
        .get("tier_mode", "percentile")
    )  # v14.1: 'percentile' or 'absolute'
    RISK_TIER_PERCENTILES: Dict[str, float] = field(
        default_factory=lambda: _CFG.get("pipeline", {})
        .get("scoring", {})
        .get("tier_percentiles", {"P1": 1.0, "P2": 5.0, "P3": 15.0})
    )
    MIN_TIER_SCORE: Dict[str, float] = field(
        default_factory=lambda: _CFG.get("pipeline", {})
        .get("scoring", {})
        .get("min_tier_score", {"P1": 20, "P2": 15, "P3": 10})
    )  # v14.3: safety gate
    RISK_PROPAGATION: bool = field(
        default_factory=lambda: bool(
            _CFG.get("pipeline", {}).get("scoring", {}).get("risk_propagation", True)
        )
    )  # v14.3: 1-hop score boost
    RISK_PROPAGATION_BOOST: float = field(
        default_factory=lambda: float(
            _CFG.get("pipeline", {}).get("scoring", {}).get("risk_propagation_boost", 10.0)
        )
    )  # v14.5 FIX-F: P1 downstream boost (was 15)
    RISK_PROPAGATION_UPSTREAM_BOOST: float = field(
        default_factory=lambda: float(
            _CFG.get("pipeline", {}).get("scoring", {}).get("risk_propagation_upstream_boost", 3.0)
        )
    )  # v14.5 FIX-F: P1 upstream boost (was 5)
    CONSENSUS_THRESHOLD: int = field(
        default_factory=lambda: int(
            _CFG.get("pipeline", {}).get("scoring", {}).get("consensus_threshold", 3)
        )
    )  # v14.3: min families for high-confidence
    CONSENSUS_MULTIPLIER_RATE: float = field(
        default_factory=lambda: float(
            _CFG.get("pipeline", {}).get("scoring", {}).get("consensus_multiplier_rate", 0.015)
        )
    )  # v14.5 FIX-E: lowered from 0.03
    CONSENSUS_EFFECTIVE_CAP: int = field(
        default_factory=lambda: int(
            _CFG.get("pipeline", {}).get("scoring", {}).get("consensus_effective_cap", 5)
        )
    )  # v15.23 FIX-CC: cap consensus at 5 (not 10)
    INTRA_FAMILY_WEIGHTS: Dict[str, Dict[str, float]] = field(
        default_factory=lambda: _CFG.get("pipeline", {})
        .get("scoring", {})
        .get("intra_family_weights", {})
    )  # v14.4 NEW-13: per-column importance within family
    SCORE_CALIBRATE_POST_PROPAGATION: bool = field(
        default_factory=lambda: bool(
            _CFG.get("pipeline", {})
            .get("scoring", {})
            .get("score_calibrate_post_propagation", True)
        )
    )  # v14.5 FIX-A: re-rank after propagation
    ROLE_CLASSIFICATION: Dict[str, Any] = field(
        default_factory=lambda: _CFG.get("pipeline", {}).get(
            "role_classification",
            {  # v15.22: AML role classification thresholds
                "mule_passthrough_min": 0.80,
                "broker_betweenness_pct": 85,
                "originator_outdegree_pct": 80,
                "sink_indegree_pct": 80,
                "min_evidence_score": 8.0,
            },
        )
    )
    INVESTIGATION_CAPACITY: int = field(
        default_factory=lambda: _CFG.get("pipeline", {}).get("investigation_capacity", 1000)
    )
    # v16.4 GAP-7: User-selectable normalisation method (rank/minmax/zscore/robust).
    # Exposed as a dropdown in Dashboard > Pipeline Scoring Configuration.
    # Default 'rank' is backward-compatible with all v14–v16.3 behaviour.
    NORM_METHOD: str = field(
        default_factory=lambda: str(_CFG.get("pipeline", {}).get("norm_method", "rank"))
    )
    # v16.3 fusion params (formally declared here; used via getattr fallback in l6_scoring)
    FUSION_OWA_BLEND: float = field(
        default_factory=lambda: float(_CFG.get("pipeline", {}).get("fusion_owa_blend", 0.60))
    )
    FUSION_MAX_AVG_ALPHA: float = field(
        default_factory=lambda: float(_CFG.get("pipeline", {}).get("fusion_max_avg_alpha", 0.25))
    )
    FUSION_SPIKE_PENALTY: float = field(
        default_factory=lambda: float(_CFG.get("pipeline", {}).get("fusion_spike_penalty", 0.88))
    )
    # v16.44 F8: Correlated family deweighting
    # Pairs of families known to measure overlapping signals (ρ≈0.65 in scale-free networks).
    # Default: centrality+community (both measure hub position), anomaly+structuring (both
    # fire on cash-heavy behavioural outliers). correlation_penalty applied to each member.
    CORRELATED_FAMILY_PAIRS: list = field(
        default_factory=lambda: _CFG.get("pipeline", {}).get(
            "correlated_family_pairs", [["centrality", "community"], ["anomaly", "structuring"]]
        )
    )
    CORRELATION_PENALTY: float = field(
        default_factory=lambda: float(_CFG.get("pipeline", {}).get("correlation_penalty", 0.65))
    )
    # v16.5 Rule-4: Binary flag weights moved from l6_scoring.py hardcode to config
    BINARY_FLAG_BOOST_CAP: float = field(
        default_factory=lambda: float(
            _CFG.get("pipeline", {}).get("scoring", {}).get("binary_flag_boost_cap", 0.30)
        )
    )
    BINARY_FLAG_WEIGHTS: Dict[str, float] = field(
        default_factory=lambda: _CFG.get("pipeline", {})
        .get("scoring", {})
        .get(
            "binary_flag_weights",
            {
                "motif_circular": 0.15,
                "potential_structuring": 0.12,
                "potential_ctr_avoidance": 0.12,
                "is_layering_intermediary": 0.10,
                "is_scripted_regular": 0.10,
                "is_temporal_relay": 0.10,
                "benfords_second_anomaly": 0.09,
                "is_powerlaw_tail": 0.08,
                "benfords_anomaly": 0.08,
                "is_burst": 0.04,
            },
        )
    )


@dataclass
class AppConfig:
    TITLE: str = field(
        default_factory=lambda: _CFG.get("app", {}).get("title", "FCDAI Network Analyzer")
    )
    VERSION: str = field(default_factory=lambda: _CFG.get("app", {}).get("version", "12.9.0"))
    HOST: str = field(default_factory=lambda: _CFG.get("app", {}).get("host", "127.0.0.1"))
    PORT: int = field(default_factory=lambda: _CFG.get("app", {}).get("port", 9104))
    DEBUG: bool = field(default_factory=lambda: _CFG.get("app", {}).get("debug", False))
    SERVE_LOCALLY: bool = field(
        default_factory=lambda: _CFG.get("app", {}).get("serve_locally", True)
    )
    AIR_GAPPED: bool = field(default_factory=lambda: _CFG.get("app", {}).get("air_gapped", True))
    PII_PROTECTION: bool = field(
        default_factory=lambda: _CFG.get("app", {}).get("pii_protection", True)
    )
    RANDOM_SEED: int = field(default_factory=lambda: _CFG.get("app", {}).get("random_seed", 42))
    PLOTLY_CONFIG: Dict = field(
        default_factory=lambda: _CFG.get(
            "plotly",
            {
                "displaylogo": False,
                "modeBarButtonsToRemove": ["sendDataToCloud", "lasso2d", "select2d"],
                "toImageButtonOptions": {"format": "png", "scale": 2},
            },
        )
    )


@dataclass
class GeoRiskConfig:
    HIGH_RISK: List[str] = field(
        default_factory=lambda: _CFG.get("geo_risk", {}).get(
            "high_risk_countries", ["KY", "BZ", "AE", "PA", "VG", "SC", "MU", "LR"]
        )
    )
    MEDIUM_RISK: List[str] = field(
        default_factory=lambda: _CFG.get("geo_risk", {}).get(
            "medium_risk_countries", ["HK", "SG", "CH", "LU", "LI", "MC", "AD"]
        )
    )
    SANCTIONS: List[str] = field(
        default_factory=lambda: _CFG.get("geo_risk", {}).get(
            "sanctions_countries", ["KP", "IR", "SY", "CU", "VE"]
        )
    )


@dataclass
class PIIConfig:
    MASK_MODE: str = field(default_factory=lambda: _CFG.get("pii", {}).get("mask_mode", "partial"))
    FIELDS_TO_MASK: List[str] = field(
        default_factory=lambda: _CFG.get("pii", {}).get(
            "fields_to_mask", ["name", "customer_name", "account_id"]
        )
    )
    HASH_ALGO: str = field(
        default_factory=lambda: _CFG.get("pii", {}).get("hash_algorithm", "sha256")
    )
    EXPORT_REDACTION: bool = field(
        default_factory=lambda: _CFG.get("pii", {}).get("export_redaction", True)
    )
    LOG_REDACTION: bool = field(
        default_factory=lambda: _CFG.get("pii", {}).get("log_redaction", True)
    )


@dataclass
class PerformanceConfig:
    """v12.4: Performance tuning configuration."""

    PARALLEL: bool = field(
        default_factory=lambda: _CFG.get("performance", {}).get("parallel", True)
    )
    MAX_WORKERS: int = field(
        default_factory=lambda: _CFG.get("performance", {}).get("max_workers", 6)
    )
    CACHING: bool = field(default_factory=lambda: _CFG.get("performance", {}).get("caching", True))
    CACHE_MAX_ENTRIES: int = field(
        default_factory=lambda: _CFG.get("performance", {}).get("cache_max_entries", 30)
    )
    PROGRESSIVE: bool = field(
        default_factory=lambda: _CFG.get("performance", {}).get("progressive", True)
    )
    SAMPLING_ENABLED: bool = field(
        default_factory=lambda: _CFG.get("performance", {})
        .get("sampling", {})
        .get("enabled", False)
    )
    SAMPLING_THRESHOLD: int = field(
        default_factory=lambda: _CFG.get("performance", {})
        .get("sampling", {})
        .get("threshold", 5000)
    )
    SAMPLING_DEFAULT_SIZE: int = field(
        default_factory=lambda: _CFG.get("performance", {})
        .get("sampling", {})
        .get("default_size", 5000)
    )
    FLOAT32: bool = field(
        default_factory=lambda: _CFG.get("performance", {}).get("float32_quantize", True)
    )


@dataclass
class MemoryConfig:
    WARNING_MB: int = field(
        default_factory=lambda: _CFG.get("memory", {}).get("warning_threshold_mb", 6000)
    )
    CRITICAL_MB: int = field(
        default_factory=lambda: _CFG.get("memory", {}).get("critical_threshold_mb", 7000)
    )
    GC_AGGRESSIVE: bool = field(
        default_factory=lambda: _CFG.get("memory", {}).get("gc_aggressive", True)
    )
    FLOAT32: bool = field(
        default_factory=lambda: _CFG.get("memory", {}).get("float32_quantize", True)
    )


# Singletons
PATHS = PathConfig()
THEME = ThemeConfig()
PIPELINE = PipelineConfig()
APP = AppConfig()
GEO_RISK = GeoRiskConfig()
PII = PIIConfig()
MEMORY = MemoryConfig()
PERFORMANCE = PerformanceConfig()
