"""v14.5 Smoke Test — validates v14.4 items + v14.5 FIX-A through FIX-C"""

import sys, os

sys.path.insert(0, os.path.dirname(__file__))

# ── 1. Imports ───────────────────────────────────────────────────────────────
try:
    import networkx as nx
    import numpy as np
    import pandas as pd
    from config import PIPELINE
    from layers.l5_analytics import AnalyticsLayer
    from layers.l6_scoring import ScoringLayer

    print("IMPORTS OK")
except Exception as e:
    print(f"IMPORT FAIL: {e}")
    sys.exit(1)

# ── 2. Config field checks ───────────────────────────────────────────────────
assert hasattr(
    PIPELINE, "RISK_PROPAGATION_UPSTREAM_BOOST"
), "MISSING: RISK_PROPAGATION_UPSTREAM_BOOST"
assert hasattr(PIPELINE, "CONSENSUS_MULTIPLIER_RATE"), "MISSING: CONSENSUS_MULTIPLIER_RATE"
assert hasattr(PIPELINE, "INTRA_FAMILY_WEIGHTS"), "MISSING: INTRA_FAMILY_WEIGHTS"
# v14.5 FIX-E/F: reduced boosts
assert (
    float(PIPELINE.RISK_PROPAGATION_BOOST) == 10.0
), f"WRONG downstream boost: {PIPELINE.RISK_PROPAGATION_BOOST} (expected 10.0)"
assert (
    float(PIPELINE.RISK_PROPAGATION_UPSTREAM_BOOST) == 3.0
), f"WRONG upstream boost: {PIPELINE.RISK_PROPAGATION_UPSTREAM_BOOST} (expected 3.0)"
assert (
    float(PIPELINE.CONSENSUS_MULTIPLIER_RATE) <= 0.02
), f"WRONG consensus rate: {PIPELINE.CONSENSUS_MULTIPLIER_RATE} (expected <=0.02)"
# v14.5 FIX-A: calibration toggle
assert hasattr(
    PIPELINE, "SCORE_CALIBRATE_POST_PROPAGATION"
), "MISSING: SCORE_CALIBRATE_POST_PROPAGATION"
print(
    f"CONFIG OK | upstream_boost={PIPELINE.RISK_PROPAGATION_UPSTREAM_BOOST} downstream_boost={PIPELINE.RISK_PROPAGATION_BOOST}"
    f" consensus_mult_rate={PIPELINE.CONSENSUS_MULTIPLIER_RATE} calibrate={PIPELINE.SCORE_CALIBRATE_POST_PROPAGATION}"
)


# ── 3. Build test graph (200 nodes, varies to test n=50, 200, 1000) ──────────
def make_test_graph(n=200):
    rng = np.random.default_rng(42)
    G = nx.scale_free_graph(n, seed=42)
    G = nx.DiGraph(G)
    for node in G.nodes():
        G.nodes[node]["in_flow"] = float(rng.exponential(10000))
        G.nodes[node]["out_flow"] = float(rng.exponential(10000))
        G.nodes[node]["in_degree"] = G.in_degree(node)
        G.nodes[node]["out_degree"] = G.out_degree(node)
        G.nodes[node]["total_degree"] = G.degree(node)
        G.nodes[node]["txn_count"] = int(rng.integers(1, 200))
    for u, v, d in G.edges(data=True):
        d["weight"] = float(rng.choice([1000, 5000, 9999, 10001, 500, 50000]))
        d["amount"] = d["weight"]
    return G


# Test with n=50 (smallest), n=200, n=1000
for n_test in [50, 200, 1000]:
    G = make_test_graph(n_test)
    layer = AnalyticsLayer()
    results = layer.run_all(G, parallel=False)
    assert len(results) >= 9, f"n={n_test}: <9 families returned"
    print(f"  n={n_test:5d} -> {len(results)} families, OK")

# ── 4. NEW-09: Katz centrality ────────────────────────────────────────────────
G = make_test_graph(200)
layer = AnalyticsLayer()
results = layer.run_all(G, parallel=False)
centrality_df = results.get("centrality")
assert (
    centrality_df is not None and "katz" in centrality_df.columns
), f"NEW-09 FAIL: katz not in centrality columns: {list(centrality_df.columns) if centrality_df is not None else 'None'}"
katz_vals = centrality_df["katz"].values
assert not np.all(katz_vals == 0), "NEW-09 FAIL: all katz values are 0"
print(
    f"NEW-09 Katz PASS | min={katz_vals.min():.4f} max={katz_vals.max():.4f} mean={katz_vals.mean():.4f}"
)

# ── 5. NEW-10: Bilateral motif ────────────────────────────────────────────────
motif_df = results.get("motifs")
assert (
    motif_df is not None and "bilateral_ratio" in motif_df.columns
), f"NEW-10 FAIL: bilateral_ratio not in motifs: {list(motif_df.columns) if motif_df is not None else 'None'}"
bl_vals = motif_df["bilateral_ratio"].values
print(f"NEW-10 Bilateral Motif PASS | nodes with bilateral>0: {(bl_vals>0).sum()}")

# ── 6. NEW-11: Velocity delta ─────────────────────────────────────────────────
temporal_df = results.get("temporal")
assert (
    temporal_df is not None and "velocity_delta_zscore" in temporal_df.columns
), f"NEW-11 FAIL: velocity_delta_zscore not in temporal: {list(temporal_df.columns) if temporal_df is not None else 'None'}"
vd_vals = temporal_df["velocity_delta_zscore"].values
assert not np.all(vd_vals == 0), "NEW-11 FAIL: all velocity_delta_zscore are 0"
print(f"NEW-11 Velocity Delta PASS | min={vd_vals.min():.4f} max={vd_vals.max():.4f}")

# ── 7. NEW-12: Unexplained Jaccard ────────────────────────────────────────────
lp_df = results.get("link_prediction")
assert (
    lp_df is not None and "unexplained_jaccard" in lp_df.columns
), f"NEW-12 FAIL: unexplained_jaccard not in link_prediction: {list(lp_df.columns) if lp_df is not None else 'None'}"
uj_vals = lp_df["unexplained_jaccard"].values
print(f"NEW-12 Unexplained Jaccard PASS | mean={uj_vals.mean():.4f} max={uj_vals.max():.4f}")

# ── 8. NEW-16: Community size inversion ──────────────────────────────────────
comm_df = results.get("community")
assert (
    comm_df is not None and "small_community_risk" in comm_df.columns
), f"NEW-16 FAIL: small_community_risk not in community: {list(comm_df.columns) if comm_df is not None else 'None'}"
scr_vals = comm_df["small_community_risk"].values
print(f"NEW-16 Community Inversion PASS | min={scr_vals.min():.3f} max={scr_vals.max():.3f}")

# ── 9. NEW-14: Decimal round fix (structuring) ───────────────────────────────
struct_df = results.get("structuring")
assert (
    struct_df is not None and "round_number_ratio" in struct_df.columns
), "NEW-14 FAIL: round_number_ratio missing"
print(f"NEW-14 Decimal Fix PASS | round_number_ratio present")

# ── 10. Scoring: NEW-13 intra-weights, NEW-15 consensus multiplier, NEW-08 asymm propagation ──
scoring = ScoringLayer()
assert hasattr(scoring, "upstream_boost"), "SCORING: upstream_boost missing"
assert hasattr(scoring, "consensus_multiplier_rate"), "SCORING: consensus_multiplier_rate missing"
assert hasattr(scoring, "intra_family_weights"), "SCORING: intra_family_weights missing"
print(
    f"SCORING INIT OK | upstream_boost={scoring.upstream_boost} consensus_mult={scoring.consensus_multiplier_rate}"
)

scored = scoring.score(results, G=G)
assert "risk_score" in scored.columns and "risk_tier" in scored.columns, "SCORE COLS MISSING"
assert "consensus_count" in scored.columns, "consensus_count MISSING"
tier_dist = scored["risk_tier"].value_counts().to_dict()
print(f"SCORING PASS | n={len(scored)} tiers={tier_dist}")

# v14.5 FIX-A: Verify post-calibration gives realistic distribution (<10% P1)
p1_pct = tier_dist.get("P1", 0) / len(scored) * 100
p4_pct = tier_dist.get("P4", 0) / len(scored) * 100
print(f"FIX-A CALIBRATION CHECK | P1={p1_pct:.1f}% P4={p4_pct:.1f}%")
assert p1_pct < 20.0, f"FIX-A FAIL: too many P1 ({p1_pct:.1f}% >= 20%) — calibration not working"
# pre_calib_score audit column should exist when calibration is on
if PIPELINE.SCORE_CALIBRATE_POST_PROPAGATION:
    assert "pre_calib_score" in scored.columns, "FIX-A FAIL: pre_calib_score audit column missing"
print(f"FIX-A CALIBRATION PASS | P1={p1_pct:.1f}% (expected <20%)")


# ── 11. Verify asymmetric propagation is active ─────────────────────────────
# Create a simple 3-node graph: A->B->C. Make A a high-risk node.
# After propagation: B (downstream of A) should get bigger boost than nothing.
def check_propagation_direction():
    G3 = nx.DiGraph()
    G3.add_nodes_from(["A", "B", "C"])
    G3.add_edges_from([("A", "B"), ("B", "C")], weight=1.0, amount=1.0)
    for nd in G3.nodes():
        G3.nodes[nd].update(
            {
                "in_flow": 1.0,
                "out_flow": 1.0,
                "in_degree": 1,
                "out_degree": 1,
                "total_degree": 2,
                "txn_count": 5,
            }
        )
    # Build a mock analytics result that gives A a very high score
    n_nodes = list(G3.nodes())
    mock = {
        "anomaly": pd.DataFrame(
            {
                "node_id": n_nodes,
                "anomaly_score_if": [0.99, 0.01, 0.01],
                "anomaly_score_lof": [0.99, 0.01, 0.01],
                "anomaly_score_zscore": [0.99, 0.01, 0.01],
            }
        )
    }
    sc = ScoringLayer()
    sc.propagate = True
    sc.propagation_boost = 10.0  # v14.5: reduced from 15
    sc.upstream_boost = 3.0  # v14.5: reduced from 5
    res = sc.score(mock, G=G3)
    scores = res.set_index("node_id")["risk_score"].to_dict()
    # B is downstream of A -> should get downstream boost
    # C is downstream of B (but B may not be P1/P2 after initial scoring)
    print(
        f"  Propagation direction check: A={scores.get('A',0):.1f} B={scores.get('B',0):.1f} C={scores.get('C',0):.1f}"
    )
    return True


check_propagation_direction()
print("NEW-08 Asymmetric Propagation PASS")

# ── 12. Weight sum ───────────────────────────────────────────────────────────
wsum = sum(PIPELINE.RISK_WEIGHTS.values())
assert abs(wsum - 1.0) < 0.01, f"Weight sum={wsum:.4f} (not 1.0)"
print(f"WEIGHT SUM = {wsum:.4f} PASS")

print("\n=== ALL V14.5 SMOKE TESTS PASSED ===")
