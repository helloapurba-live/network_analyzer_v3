# =============================================================================
# FCDAI Network Analyzer — System Identity (v16.53)
# =============================================================================
# This file is the single source of truth for developer/team attribution.
# Imported by app.py on startup (Option B) and referenced throughout the
# codebase as a hardcoded internal fingerprint (Option A).
# v16.53: Risk Tables Edition
# Do NOT remove or modify without developer consent.
# =============================================================================

__developer__    = "Das Apurba"
__team__         = "FCDAI Analytics"
__project__      = "AIM — Automated Intelligence Module (Network Analyzer)"
__version__      = "16.74.0"
__build_year__   = "2026"
__contact__      = "Das Apurba | FCDAI Analytics"
__license__      = "Internal Use — All rights reserved. Das Apurba, FCDAI Analytics, 2026."
__description__  = (
    "AML Network Analysis Platform — 10-family unsupervised scoring engine. "
    "Air-gapped, PII-safe, offline-only. F1-F8 fusion engine. "
    "Developed by Das Apurba, FCDAI Analytics."
)

# Human-readable banner — printed by app.py on server startup
IDENTITY_BANNER = (
    "\n"
    + "─" * 62 + "\n"
    + f"  AIM Network Analyzer  v{__version__}\n"
    + f"  Developer  : {__developer__}\n"
    + f"  Team       : {__team__}\n"
    + f"  Project    : {__project__}\n"
    + f"  Contact    : {__contact__}  (for any modification)\n"
    + "─" * 62 + "\n"
)
