"""
FCDAI Network Analyzer v16.53 — Risk Tables Edition
============================================================
Air-Gapped | PII-Protected | Offline-Only | 21 Themes
Intelligence Hub | Workspace | Reports | Audit Chain
Persistent state across sessions via localStorage + SQLite

v16.51 Security Hardening:
  #1b  Dash login screen (admin/fcdai2026 default, credentials in config.yaml)
  #16  Rotating log files via utils.logger (TimedRotatingFileHandler)
  (Full security list in config.yaml header)
"""
# ── Developer Attribution (v16.51) ─────────────────────────────────────────
__author__  = "Das Apurba"
__team__    = "FCDAI Analytics"
__version__ = "16.74.0"

import dash
from dash import (
    html,
    dcc,
    page_registry,
    page_container,
    Input,
    Output,
    State,
    callback,
    clientside_callback,
    ctx,
    no_update,
)
import dash_mantine_components as dmc
import dash_bootstrap_components as dbc
from dash_iconify import DashIconify
from pathlib import Path
import sys
import traceback
import socket
import webbrowser
import shutil
import json as _json
import threading as _threading
import secrets as _secrets
import hashlib as _hashlib

sys.path.insert(0, str(Path(__file__).parent))
from config import APP, THEME, PATHS

# v16.51 #16: Activate rotating logs early
try:
    from utils.logger import audit_logger as _audit_logger, log_audit
    _LOG_READY = True
except Exception:
    _LOG_READY = False


# =============================================================================
# DASH APPLICATION
# =============================================================================
app = dash.Dash(
    __name__,
    use_pages=True,
    pages_folder="pages",
    suppress_callback_exceptions=True,
    assets_folder="assets",
    serve_locally=True,
    title=APP.TITLE,
    update_title=None,
    external_stylesheets=[dbc.themes.DARKLY],
)


# =============================================================================
# v16.51 #1b — DASH LOGIN GUARD
# -----------------------------------------------------------------------------
# Flask basic session authentication — no extra dependencies.
# Credentials loaded from config.yaml auth section.
# Defaults: admin / fcdai2026  (change in config.yaml before real data use).
# All Dash internal routes (/_dash-*), /assets, /health are exempt.
# =============================================================================
from flask import (  # noqa: E402 — must be after app creation
    session as _fk_session,
    redirect as _fk_redirect,
    request as _fk_request,
    make_response as _fk_make_response,
)

# ── Secret key for Flask sessions (regenerated each restart; sessions expire) ─
app.server.secret_key = _secrets.token_hex(32)


def _load_users_config() -> dict:
    """
    Load multi-user credentials and roles from config.yaml auth.users list.
    Returns: {username: {"password": str, "role": str}}
    Roles: admin | investigator | internal | reporter
    """
    _default = {
        "admin":        {"password": "das1234",  "role": "admin"},
        "investigator": {"password": "das123",   "role": "investigator"},
        "internal":     {"password": "das123",   "role": "internal"},
        "reporter":     {"password": "das123",   "role": "reporter"},
    }
    try:
        import yaml
        cfg_path = Path(__file__).parent / "config.yaml"
        with open(cfg_path, encoding="utf-8") as f:
            cfg = yaml.safe_load(f)
        users_list = cfg.get("auth", {}).get("users", [])
        if users_list:
            return {
                u["username"]: {
                    "password": u["password"],
                    "role": u.get("role", "viewer"),
                }
                for u in users_list
                if "username" in u and "password" in u
            }
        # Fallback: legacy single-user format in config.yaml
        auth = cfg.get("auth", {})
        _u = auth.get("username", "admin")
        _p = auth.get("password", "das1234")
        return {_u: {"password": _p, "role": "admin"}}
    except Exception:
        return _default


_USERS: dict = _load_users_config()

# URL prefixes that bypass authentication (Dash internals, static assets, health)
_BYPASS_PREFIXES = (
    "/_dash-",
    "/_reload-hash",
    "/assets/",
    "/health",
    "/favicon.ico",
    "/login",
    "/logout",
)


@app.server.before_request
def _require_login():
    """Redirect unauthenticated users to /login before serving any Dash page."""
    path = _fk_request.path
    # Allow bypass paths (Dash internals, assets, login page itself)
    if any(path.startswith(bp) for bp in _BYPASS_PREFIXES):
        return None
    # Check session cookie
    if not _fk_session.get("authenticated"):
        return _fk_redirect(f"/login?next={_fk_request.url}")
    return None


@app.server.route("/login", methods=["GET", "POST"])
def _login_page():
    """
    Simple username/password login form.
    Credentials from config.yaml auth.username / auth.password.
    On success, sets session['authenticated'] = True and redirects.
    """
    error = ""
    if _fk_request.method == "POST":
        username = _fk_request.form.get("username", "").strip()
        password = _fk_request.form.get("password", "")
        # Multi-user lookup + constant-time password comparison (timing-attack safe)
        _user_entry = _USERS.get(username)
        _user_ok    = _user_entry is not None
        _pass_ok    = _secrets.compare_digest(password, _user_entry["password"]) if _user_entry else False
        if _user_ok and _pass_ok:
            _fk_session["authenticated"] = True
            _fk_session["user"]          = username
            _fk_session["role"]          = _user_entry["role"]
            # Audit trail
            try:
                from database import get_db
                db = get_db()
                db.log_audit_event(
                    action="LOGIN_SUCCESS",
                    details=f"user={username} ip={_fk_request.remote_addr}",
                    user=username,
                    severity="INFO",
                )
            except Exception:
                pass
            next_url = _fk_request.args.get("next", "/")
            # Safety: only redirect to same-host paths
            if not next_url.startswith("/"):
                next_url = "/"
            return _fk_redirect(next_url)
        else:
            error = "Invalid username or password."
            # Audit trail — failed login
            try:
                from database import get_db
                db = get_db()
                db.log_audit_event(
                    action="LOGIN_FAILED",
                    details=f"username_attempt={username[:20]!r} ip={_fk_request.remote_addr}",
                    user="SYSTEM",
                    severity="WARN",
                )
            except Exception:
                pass

    # Render minimal inline HTML login form (no external CDN — air-gapped)
    error_html = f'<p style="color:#ff6b6b;margin-top:8px;">{error}</p>' if error else ""
    return _fk_make_response(f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>FCDAI — Sign In</title>
  <style>
    * {{ box-sizing: border-box; margin: 0; padding: 0; }}
    body {{
      background: #0A0E17;
      color: #e0e0e0;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
    }}
    .card {{
      background: #111827;
      border: 1px solid #1E293B;
      border-radius: 16px;
      padding: 40px 48px;
      width: 380px;
      box-shadow: 0 20px 60px rgba(0,0,0,0.5);
    }}
    .brand {{
      display: flex;
      align-items: center;
      gap: 12px;
      margin-bottom: 28px;
    }}
    .brand-icon {{
      width: 40px;
      height: 40px;
      background: linear-gradient(135deg, #00D4FF, #9D4EDD);
      border-radius: 10px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 20px;
    }}
    .brand-title {{
      font-size: 22px;
      font-weight: 800;
      background: linear-gradient(90deg, #00D4FF, #9D4EDD);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      letter-spacing: 2px;
    }}
    .brand-sub {{
      font-size: 11px;
      color: #64748b;
      margin-top: 1px;
    }}
    h2 {{
      font-size: 16px;
      font-weight: 600;
      color: #94a3b8;
      margin-bottom: 24px;
    }}
    label {{
      display: block;
      font-size: 12px;
      font-weight: 600;
      color: #64748b;
      text-transform: uppercase;
      letter-spacing: 0.8px;
      margin-bottom: 6px;
    }}
    input[type=text], input[type=password] {{
      width: 100%;
      padding: 10px 14px;
      background: #0A0E17;
      border: 1px solid #1E293B;
      border-radius: 8px;
      color: #e0e0e0;
      font-size: 14px;
      margin-bottom: 16px;
      outline: none;
      transition: border-color 0.2s;
    }}
    input:focus {{ border-color: #00D4FF; }}
    button {{
      width: 100%;
      padding: 12px;
      background: linear-gradient(135deg, #00D4FF, #9D4EDD);
      border: none;
      border-radius: 8px;
      color: #fff;
      font-size: 14px;
      font-weight: 700;
      cursor: pointer;
      letter-spacing: 0.5px;
      margin-top: 4px;
    }}
    .badge {{
      font-size: 10px;
      color: #1e3a1e;
      background: #00E676;
      border-radius: 4px;
      padding: 2px 7px;
      margin-left: 8px;
      font-weight: 700;
    }}
    .footer {{
      text-align: center;
      margin-top: 20px;
      font-size: 11px;
      color: #334155;
    }}
  </style>
</head>
<body>
  <div class="card">
    <div class="brand">
      <div class="brand-icon">🕸</div>
      <div>
        <div class="brand-title">FCDAI</div>
        <div class="brand-sub">AML Network Analyzer</div>
      </div>
    </div>
    <h2>Sign in to continue <span class="badge">AIR-GAPPED</span></h2>
    <form method="POST" autocomplete="off">
      <label for="username">Username</label>
      <input type="text" id="username" name="username" placeholder=""
             autofocus autocomplete="off">
      <label for="password">Password</label>
      <input type="password" id="password" name="password" placeholder="••••••••"
             autocomplete="off">
      {error_html}
      <button type="submit">Sign In</button>
    </form>
    <div class="footer">v{APP.VERSION} &bull; Bank-grade &bull; PII-Protected &bull; Offline-Only</div>
  </div>
</body>
</html>""", 200)


@app.server.route("/logout")
def _logout():
    """Clear session and redirect to login page."""
    username = _fk_session.get("user", "unknown")
    _fk_session.clear()
    try:
        from database import get_db
        db = get_db()
        db.log_audit_event(
            action="LOGOUT",
            details=f"user={username}",
            user=username,
            severity="INFO",
        )
    except Exception:
        pass
    return _fk_redirect("/login")



def nav_link(icon, label, href, color=None):
    return dmc.NavLink(
        label=label,
        href=href,
        leftSection=DashIconify(icon=icon, width=18, color=color),
        active="exact",
        style={"borderRadius": "8px", "marginBottom": "1px", "padding": "8px 12px 8px 22px"},
        variant="light",
        className="sidebar-navlink",
    )


# =============================================================================
# 21 PREMIUM THEMES
# =============================================================================
THEMES = [
    {"value": "midnight", "label": "🌊  Midnight Ocean"},
    {"value": "emerald", "label": "🌿  Emerald Matrix"},
    {"value": "ember", "label": "🔥  Ember Glow"},
    {"value": "amethyst", "label": "💎  Royal Amethyst"},
    {"value": "arctic", "label": "🧊  Arctic Frost"},
    {"value": "daylight", "label": "☀️  Daylight"},
    {"value": "titanium", "label": "⚙️  Titanium Steel"},
    {"value": "rosegold", "label": "🌸  Rose Gold"},
    {"value": "solar", "label": "🌅  Solar Flare"},
    {"value": "ocean", "label": "🐋  Deep Ocean"},
    {"value": "neon", "label": "⚡  Neon Tokyo"},
    {"value": "corporate", "label": "🏢  Corporate Slate"},
    {"value": "obsidian", "label": "🖤  Obsidian Night"},
    {"value": "cyberpunk", "label": "🤖  Cyberpunk"},
    {"value": "pearl", "label": "🦪  Pearl White"},
    {"value": "sakura", "label": "🌸  Sakura Bloom"},
    {"value": "lavender", "label": "💜  Soft Lavender"},
    {"value": "mist", "label": "🌫️  Morning Mist"},
    {"value": "cream", "label": "🍦  Cream Canvas"},
    {"value": "iceblue", "label": "❄️  Ice Blue"},
    {"value": "sand", "label": "🏖️  Warm Sand"},
]


# =============================================================================
# LOAD PERSISTED THEME PREFERENCE
# =============================================================================
def _get_saved_theme():
    """Load saved theme from DB (persistence across sessions)."""
    try:
        from database import get_db

        db = get_db()
        return db.get_preference("theme", "midnight")
    except Exception:
        return "midnight"


def _get_saved_sidebar_state():
    """Load saved sidebar state from DB. Returns 'expanded', 'collapsed', or 'hidden'."""
    try:
        from database import get_db

        db = get_db()
        val = db.get_preference("sidebar_state", "expanded")
        if val in ("expanded", "collapsed", "hidden"):
            return val
        # Migrate from old boolean format
        old = db.get_preference("sidebar_collapsed", "false")
        return "collapsed" if old == "true" else "expanded"
    except Exception:
        return "expanded"


_initial_theme = _get_saved_theme()
# v16.39 T4: Always start expanded — clean default UX on every app restart
_initial_sidebar = "expanded"

_SIDEBAR_WIDTHS = {"expanded": "260px", "collapsed": "60px", "hidden": "0px"}


# =============================================================================
# SIDEBAR
# =============================================================================
sidebar = dmc.Paper(
    [
        # Collapse toggle
        dmc.ActionIcon(
            DashIconify(icon="mdi:menu", width=20),
            id="sidebar-toggle",
            variant="subtle",
            color="gray",
            style={"position": "absolute", "top": "12px", "right": "8px", "zIndex": 200},
            className="sidebar-toggle-btn",
        ),
        # Logo
        dmc.Group(
            [
                dmc.ThemeIcon(
                    DashIconify(icon="mdi:spider-web", width=28),  # v16.47: spider-web icon
                    size="xl",
                    radius="md",
                    variant="gradient",
                    gradient={"from": "cyan", "to": "indigo"},
                ),
                dmc.Stack(
                    [
                        dmc.Text(
                            "FCDAI",  # v16.46: sidebar brand renamed to FCDAI
                            size="lg",
                            fw=800,
                            style={"letterSpacing": "1.5px"},
                            className="sidebar-logo-text",
                        ),
                        dmc.Text(
                            "",  # v16.46: subtitle cleared (topbar unchanged)
                            size="xs",
                            style={"letterSpacing": "0.5px", "opacity": "0.7"},
                            className="sidebar-subtitle",
                        ),
                    ],
                    gap=0,
                ),
            ],
            gap="sm",
            px="md",
            py="md",
        ),
        dmc.Divider(color="rgba(255,255,255,0.06)"),
        # Search
        dmc.Box(
            [
                dmc.TextInput(
                    id="sidebar-search",
                    placeholder="Search pages…",
                    leftSection=DashIconify(icon="mdi:magnify", width=16),
                    size="xs",
                    styles={
                        "input": {
                            "backgroundColor": "rgba(0,0,0,0.2)",
                            "border": "1px solid rgba(255,255,255,0.06)",
                            "color": "var(--text-primary)",
                            "fontSize": "12px",
                            "borderRadius": "8px",
                        },
                    },
                ),
            ],
            px="sm",
            py="xs",
            className="sidebar-search-box",
        ),
        # ━━━ SCROLLABLE NAV SECTION (v12.23 TASK5: wraps all pages so sidebar scrolls) ━━━
        dmc.Box(
            [
                # ---- EXECUTIVE BRIEFING (v12.32) ----
                dmc.Stack(
                    [
                        dmc.Text(
                            "EXECUTIVE BRIEFING",
                            size="xs",
                            c="dimmed",
                            fw=600,
                            px="md",
                            pt="sm",
                            style={
                                "letterSpacing": "1.5px",
                                "fontSize": "10px",
                                "background": "linear-gradient(90deg,#FFD700,#FFA000)",
                                "WebkitBackgroundClip": "text",
                                "WebkitTextFillColor": "transparent",
                            },
                            className="sidebar-section-label",
                        ),
                        nav_link(
                            "mdi:presentation",
                            "Executive Summary",
                            "/executive-summary",
                            color="#FFD700",
                        ),
                    ],
                    gap=1,
                    px="sm",
                ),
                dmc.Divider(color="rgba(255,215,0,0.12)", my="xs"),
                # ---- MANAGEMENT REPORTS ----
                dmc.Stack(
                    [
                        dmc.Text(
                            "REPORTS",
                            size="xs",
                            c="dimmed",
                            fw=600,
                            px="md",
                            pt="sm",
                            style={
                                "letterSpacing": "1.5px",
                                "fontSize": "10px",
                                "background": "linear-gradient(90deg,#9C27B0,#2196F3)",
                                "WebkitBackgroundClip": "text",
                                "WebkitTextFillColor": "transparent",
                            },
                            className="sidebar-section-label",
                        ),
                        nav_link(
                            "mdi:chart-line",
                            "Risk & Exposure",
                            "/reports/executive-risk",
                            color="#FF9800",
                        ),
                        nav_link(
                            "mdi:account-group",
                            "Customer Risk Profiles",
                            "/reports/customer-profiles",
                            color="#FF5252",
                        ),
                        nav_link(
                            "mdi:swap-horizontal",
                            "Transaction & Flow",
                            "/reports/transaction-flow",
                            color="#00BCD4",
                        ),
                        nav_link(
                            "mdi:lan",
                            "Hidden Networks & Rings",
                            "/reports/hidden-networks",
                            color="#E91E63",
                        ),
                        nav_link(
                            "mdi:earth",
                            "Geographic Intelligence",
                            "/reports/geographic-intelligence",
                            color="#4CAF50",
                        ),
                        nav_link(
                            "mdi:shield-check-outline",
                            "Detection to Action",
                            "/reports/detection-to-action",
                            color="#9C27B0",
                        ),
                        nav_link(
                            "mdi:database-check",
                            "System Quality",
                            "/reports/data-system-quality",
                            color="#26C6DA",
                        ),
                    ],
                    gap=1,
                    px="sm",
                ),
                dmc.Divider(color="rgba(255,215,0,0.12)", my="xs"),
                # ---- OPERATIONS ----
                dmc.Stack(
                    [
                        dmc.Text(
                            "OPERATIONS",
                            size="xs",
                            c="dimmed",
                            fw=600,
                            px="md",
                            pt="sm",
                            style={"letterSpacing": "1.5px", "fontSize": "10px"},
                            className="sidebar-section-label",
                        ),
                        nav_link(
                            "mdi:database-import-outline",
                            "Port Authority",
                            "/port-authority",
                            color=THEME.INFO,
                        ),
                        nav_link(
                            "mdi:shield-check",
                            "Data Quality",
                            "/data-quality",
                            color="#00E676",
                        ),
                        nav_link("mdi:view-dashboard-outline", "Dashboard", "/"),
                        nav_link("mdi:radar", "The Radar", "/radar", color=THEME.SUCCESS),
                        nav_link(
                            "mdi:chart-box-outline",
                            "Visualization",
                            "/visualization",
                            color="#E040FB",
                        ),
                        nav_link(
                            "mdi:safe-square-outline", "The Vault", "/vault", color=THEME.SECONDARY
                        ),
                        nav_link(
                            "mdi:shield-alert-outline",
                            "Command Center",
                            "/command-center",
                            color=THEME.DANGER,
                        ),
                    ],
                    gap=1,
                    px="sm",
                ),
                dmc.Divider(color="rgba(255,255,255,0.04)", my="xs"),
                # ---- INTELLIGENCE ----
                dmc.Stack(
                    [
                        dmc.Text(
                            "INTELLIGENCE",
                            size="xs",
                            c="dimmed",
                            fw=600,
                            px="md",
                            style={"letterSpacing": "1.5px", "fontSize": "10px"},
                            className="sidebar-section-label",
                        ),
                        nav_link(
                            "mdi:graph",
                            "Network Intelligence",
                            "/network-intelligence",
                            color="#00D4FF",
                        ),
                        nav_link(
                            "mdi:account-group-outline",
                            "Lobby Analysis",
                            "/lobby-analysis",
                            color="#FF1744",
                        ),
                    ],
                    gap=1,
                    px="sm",
                ),
                dmc.Divider(color="rgba(255,255,255,0.04)", my="xs"),
                # ---- ANALYTICS ENGINE ----
                dmc.Stack(
                    [
                        dmc.Text(
                            "ANALYTICS ENGINE",
                            size="xs",
                            c="dimmed",
                            fw=600,
                            px="md",
                            style={"letterSpacing": "1.5px", "fontSize": "10px"},
                            className="sidebar-section-label",
                        ),
                        nav_link(
                            "mdi:star-four-points",
                            "Influence Hub",
                            "/analytics/centrality",
                            color="#00D4FF",
                        ),
                        nav_link(
                            "mdi:account-group",
                            "Cluster Engine",
                            "/analytics/community",
                            color="#9D4EDD",
                        ),
                        nav_link(
                            "mdi:transit-connection-variant",
                            "Traceability",
                            "/analytics/pathflow",
                            color="#FF6B6B",
                        ),
                        nav_link(
                            "mdi:link-variant",
                            "Association Predictor",
                            "/analytics/link-prediction",
                            color="#FFD600",
                        ),
                        nav_link(
                            "mdi:alert-decagram",
                            "Outlier Detector",
                            "/analytics/anomaly",
                            color="#FF9800",
                        ),
                        nav_link(
                            "mdi:clock-fast",
                            "Velocity Analyzer",
                            "/analytics/temporal",
                            color="#00E676",
                        ),
                        nav_link(
                            "mdi:layers-triple",
                            "Multi-Layer",
                            "/analytics/multi-layer",
                            color="#2196F3",
                        ),
                    ],
                    gap=1,
                    px="sm",
                ),
                dmc.Divider(color="rgba(255,255,255,0.04)", my="xs"),
                # ---- INSIGHT ENGINE (v12.4) ----
                dmc.Stack(
                    [
                        dmc.Text(
                            "INSIGHT ENGINE",
                            size="xs",
                            c="dimmed",
                            fw=600,
                            px="md",
                            style={"letterSpacing": "1.5px", "fontSize": "10px"},
                            className="sidebar-section-label",
                        ),
                        nav_link("mdi:brain", "Intelligence Hub", "/intelligence", color="#00D4FF"),
                        nav_link("mdi:pin-outline", "Workspace", "/workspace", color="#FFD600"),
                        nav_link("mdi:file-chart", "Reports", "/reports", color="#FF6B6B"),
                    ],
                    gap=1,
                    px="sm",
                ),
                dmc.Divider(color="rgba(255,255,255,0.04)", my="xs"),
                # ---- ADVANCED (v12.5: moved below engine pages, above Data & History) ----
                dmc.Stack(
                    [
                        dmc.Text(
                            "ADVANCED",
                            size="xs",
                            c="dimmed",
                            fw=600,
                            px="md",
                            style={"letterSpacing": "1.5px", "fontSize": "10px"},
                            className="sidebar-section-label",
                        ),
                        nav_link("mdi:earth", "Geo-Risk Heat Map", "/geo-risk", color="#FF6B6B"),
                        nav_link(
                            "mdi:account-details", "Customer 360", "/customer-360", color="#00E5FF"
                        ),
                        nav_link(
                            "mdi:compare-horizontal",
                            "Comparative Runs",
                            "/comparative-runs",
                            color="#9D4EDD",
                        ),
                        nav_link("mdi:shield-lock", "Audit Trail", "/audit-trail", color="#FFD600"),
                    ],
                    gap=1,
                    px="sm",
                ),
                dmc.Divider(color="rgba(255,255,255,0.04)", my="xs"),
                # ---- DATA & HISTORY ----
                dmc.Stack(
                    [
                        dmc.Text(
                            "DATA & HISTORY",
                            size="xs",
                            c="dimmed",
                            fw=600,
                            px="md",
                            style={"letterSpacing": "1.5px", "fontSize": "10px"},
                            className="sidebar-section-label",
                        ),
                        nav_link("mdi:history", "Pipeline Runs", "/pipeline-runs", color="#26C6DA"),
                        nav_link(
                            "mdi:database-search-outline", "Database", "/database", color="#AB47BC"
                        ),
                    ],
                    gap=1,
                    px="sm",
                ),
                dmc.Space(h=8),
                # ━━━ End scrollable nav section ━━━
            ],
            style={"flex": 1, "overflowY": "auto", "minHeight": 0, "paddingBottom": "4px"},
        ),
        # ---- MEMORY WIDGET ----
        dmc.Paper(
            [
                dmc.Stack(
                    [
                        dmc.Group(
                            [
                                DashIconify(icon="mdi:memory", width=14, color="dimmed"),
                                dmc.Text(
                                    "SYSTEM",
                                    size="xs",
                                    c="dimmed",
                                    fw=600,
                                    style={"letterSpacing": "1px", "fontSize": "9px"},
                                ),
                            ],
                            gap=4,
                        ),
                        dmc.Group(
                            [
                                dmc.Text(
                                    id="memory-display",
                                    size="xs",
                                    style={"color": "var(--text-secondary)"},
                                    children="— MB",
                                ),
                                dmc.Badge(
                                    id="memory-badge",
                                    size="xs",
                                    color="green",
                                    variant="dot",
                                    children="OK",
                                ),
                            ],
                            justify="space-between",
                        ),
                        dmc.Progress(id="memory-bar", value=0, size="xs", color="cyan"),
                    ],
                    gap=4,
                ),
            ],
            p="xs",
            mx="sm",
            mb="xs",
            radius="md",
            className="memory-widget",
            style={
                "backgroundColor": "rgba(0,0,0,0.15)",
                "border": "1px solid rgba(255,255,255,0.04)",
            },
        ),
        # ---- THEME DROPDOWN (bottom of sidebar) ----
        dmc.Box(
            [
                dmc.Select(
                    id="theme-selector",
                    data=THEMES,
                    value=_initial_theme,
                    size="xs",
                    allowDeselect=False,
                    leftSection=DashIconify(icon="mdi:palette-outline", width=16),
                    placeholder="Theme",
                    styles={
                        "input": {
                            "backgroundColor": "rgba(0,0,0,0.2)",
                            "border": "1px solid rgba(255,255,255,0.06)",
                            "color": "var(--text-primary)",
                            "fontSize": "12px",
                            "borderRadius": "8px",
                            "height": "34px",
                        },
                        "dropdown": {
                            "backgroundColor": "var(--bg-elevated, #111827)",
                            "border": "1px solid var(--border, rgba(255,255,255,0.1))",
                            "borderRadius": "10px",
                            "backdropFilter": "blur(16px)",
                        },
                        "option": {
                            "color": "var(--text-primary, white)",
                            "fontSize": "12px",
                            "borderRadius": "6px",
                            "padding": "6px 10px",
                        },
                    },
                ),
            ],
            px="sm",
            mb="xs",
            className="theme-dropdown-wrapper",
        ),
        # Footer badges
        dmc.Group(
            [
                dmc.Badge(f"v{APP.VERSION}", size="xs", variant="light", color="cyan"),
                dmc.Badge("AIR-GAPPED", size="xs", variant="dot", color="green"),
                dmc.Badge("OFFLINE", size="xs", variant="dot", color="teal"),
            ],
            justify="center",
            mb="sm",
            className="sidebar-footer-badges",
        ),
    ],
    id="sidebar",
    style={
        "width": _SIDEBAR_WIDTHS[_initial_sidebar],
        "height": "calc(100vh - 48px)",
        "position": "fixed",
        "top": "48px",
        "left": 0,
        "background": f"linear-gradient(180deg, {THEME.DARK_BG} 0%, {THEME.DARK_BG_CARD} 100%)",
        "borderRight": f"1px solid {THEME.DARK_BORDER}" if _initial_sidebar != "hidden" else "none",
        "overflowY": "auto" if _initial_sidebar != "hidden" else "hidden",
        "display": "flex",
        "flexDirection": "column",
        "zIndex": 100,
        "transition": "width 0.3s cubic-bezier(0.4,0,0.2,1)",
    },
    radius=0,
    className=f"sidebar {_initial_sidebar}" if _initial_sidebar != "expanded" else "sidebar",
)


# =============================================================================
# FLOATING SIDEBAR TOGGLE (visible when sidebar is hidden)
# =============================================================================
floating_toggle = dmc.ActionIcon(
    DashIconify(icon="mdi:menu", width=20),
    id="floating-sidebar-toggle",
    variant="filled",
    color="cyan",
    style={
        "position": "fixed",
        "top": "60px",
        "left": "12px",
        "zIndex": 200,
        "display": "block" if _initial_sidebar == "hidden" else "none",
        "borderRadius": "8px",
    },
    className="floating-toggle-btn",
)


# =============================================================================
# GLOBAL REFRESH BUTTON (v12.29) — syncs current page with latest pipeline run
# Visible top-right on EVERY page. Click to force re-render of current page data.
# =============================================================================
global_refresh_btn = dmc.Tooltip(
    label="Sync Latest Pipeline Run to This Page",
    position="bottom",
    children=dmc.ActionIcon(
        DashIconify(icon="mdi:refresh", width=20),
        id="global-refresh-btn",
        variant="gradient",
        gradient={"from": "teal", "to": "cyan"},
        size="lg",
        radius="md",
        style={
            "position": "fixed",
            "top": "60px",
            "right": "16px",
            "zIndex": 350,
            "boxShadow": "0 2px 12px rgba(0,212,255,0.25)",
        },
    ),
)


# =============================================================================
# NOTIFICATION TOAST
# =============================================================================
notification_area = html.Div(
    [
        dcc.Store(id="notification-store", data=None),
        html.Div(
            id="toast-container",
            style={
                "position": "fixed",
                "top": "16px",
                "right": "16px",
                "zIndex": 9999,
                "display": "flex",
                "flexDirection": "column",
                "gap": "8px",
            },
        ),
    ]
)


# =============================================================================
# TOP HEADER BAR (v16.33) — Databricks-inspired full-width app topbar
# Brand | Global Search | Status badges | User avatar
# =============================================================================
topbar = dmc.Box(
    [
        # LEFT — BRAND
        dmc.Group(
            [
                dmc.ThemeIcon(
                    DashIconify(icon="mdi:shield-search", width=20),
                    size="md",
                    radius="md",
                    variant="gradient",
                    gradient={"from": "cyan", "to": "indigo"},
                ),
                html.Span(
                    APP.TITLE.split()[0],  # v16.39 T3: dynamic from config.yaml
                    style={
                        "fontWeight": 800,
                        "fontSize": "15px",
                        "letterSpacing": "2px",
                        "background": "linear-gradient(135deg, #00D4FF, #9D4EDD)",
                        "WebkitBackgroundClip": "text",
                        "WebkitTextFillColor": "transparent",
                    },
                ),
                html.Span(
                    "│",
                    style={
                        "color": "rgba(255,255,255,0.18)",
                        "margin": "0 6px",
                        "fontSize": "18px",
                        "lineHeight": "1",
                    },
                ),
                # v16.39 T1: Bold highlighted brand — premium topbar look
                html.Span(
                    " ".join(APP.TITLE.split()[1:]),
                    style={
                        "fontWeight": 700,
                        "fontSize": "14px",
                        "letterSpacing": "0.8px",
                        "color": "#E2E8F0",
                        "backgroundColor": "rgba(0,212,255,0.08)",
                        "border": "1px solid rgba(0,212,255,0.22)",
                        "borderRadius": "6px",
                        "padding": "2px 10px",
                    },
                ),
            ],
            gap="xs",
        ),
        # CENTER — GLOBAL SEARCH
        dmc.TextInput(
            id="topbar-search",
            placeholder="Search pages, analytics, entities…",
            leftSection=DashIconify(icon="mdi:magnify", width=16, color="#6B7280"),
            rightSection=html.Span(
                "Alt+/",
                style={
                    "fontSize": "9px",
                    "color": "rgba(255,255,255,0.3)",
                    "border": "1px solid rgba(255,255,255,0.12)",
                    "borderRadius": "4px",
                    "padding": "2px 5px",
                    "whiteSpace": "nowrap",
                    "lineHeight": "1.5",
                },
            ),
            size="sm",
            styles={
                "input": {
                    "backgroundColor": "rgba(255,255,255,0.05)",
                    "border": "1px solid rgba(255,255,255,0.08)",
                    "color": "#e2e8f0",
                    "fontSize": "13px",
                    "borderRadius": "8px",
                },
                "wrapper": {"width": "360px"},
            },
        ),
        # RIGHT — STATUS + USER
        dmc.Group(
            [
                dmc.Badge(
                    f"v{APP.VERSION}",
                    color="cyan",
                    variant="outline",
                    size="xs",
                    style={"letterSpacing": "0.5px"},
                ),
                dmc.Badge(
                    "AIR-GAPPED",
                    color="green",
                    variant="dot",
                    size="xs",
                ),
                dmc.Tooltip(
                    label="Global Refresh — sync current page to latest pipeline run",
                    withArrow=True,
                    position="bottom-end",
                    children=dmc.ActionIcon(
                        DashIconify(icon="mdi:refresh", width=18, color="#00D4FF"),
                        id="topbar-refresh-btn",
                        variant="subtle",
                        color="gray",
                        size="sm",
                    ),
                ),
                dmc.Tooltip(
                    label="Analyst session — air-gapped mode",
                    withArrow=True,
                    position="bottom-end",
                    children=dmc.Avatar(
                        "A",
                        radius="xl",
                        size="sm",
                        style={
                            "background": "linear-gradient(135deg, #00D4FF 0%, #9D4EDD 100%)",
                            "cursor": "default",
                            "fontWeight": 700,
                            "fontSize": "13px",
                        },
                    ),
                ),
            ],
            gap="xs",
        ),
    ],
    id="app-topbar",
    style={
        "position": "fixed",
        "top": 0,
        "left": 0,
        "right": 0,
        "height": "48px",
        "zIndex": 400,
        # v16.47: stronger same-theme cyan+violet highlight on topbar
        "background": "linear-gradient(180deg, rgba(0,212,255,0.18) 0%, rgba(157,78,221,0.07) 55%, rgba(0,0,0,0.0) 100%), #0B1220",
        "borderBottom": "1px solid rgba(0,212,255,0.40)",
        "backdropFilter": "blur(20px)",
        "display": "flex",
        "alignItems": "center",
        "justifyContent": "space-between",
        "paddingLeft": "12px",
        "paddingRight": "16px",
        "boxShadow": "0 1px 24px rgba(0,0,0,0.60), 0 0 48px rgba(0,212,255,0.14), inset 0 1px 0 rgba(0,212,255,0.28)",
    },
    className="app-topbar",
)


# =============================================================================
# LAYOUT
# =============================================================================
app.layout = dmc.MantineProvider(
    [
        # Shared stores — v16.16: memory (Python-side _PA_DATA_STORE is source of
        # truth; localStorage stores were triggering Dash 4.x callback reconciliation
        # on page re-mount and overwriting staged data — see v16.15 fix notes)
        dcc.Store(id="pipeline-state", storage_type="memory"),
        dcc.Store(id="upload-state", storage_type="memory"),
        dcc.Store(id="data-readiness-state", storage_type="memory"),
        dcc.Store(id="theme-store", storage_type="local", data=_initial_theme),
        dcc.Store(id="sidebar-state", storage_type="local", data=_initial_sidebar),
        # v12.29: global refresh counter — pages listen to this to re-render on demand
        dcc.Store(id="global-refresh-ts", data=0, storage_type="memory"),
        dcc.Interval(id="memory-interval", interval=10000, n_intervals=0),
        # v16.9 C5: track which version's What's New the user has seen
        dcc.Store(id="version-seen-store", storage_type="local", data=""),
        # v16.9 C5 + E3: one-shot interval fires 1.2 s after page load
        dcc.Interval(id="startup-check", interval=1200, max_intervals=1, n_intervals=0),
        notification_area,
        floating_toggle,
        # v16.39 T2: removed duplicate floating global_refresh_btn — topbar-refresh-btn is the one working
        topbar,
        # v16.9 C5: What's New modal (shown once per version upgrade)
        html.Div(id="whats-new-modal-container"),
        # v16.9 E3: Recovery banner for interrupted pipeline runs
        html.Div(id="recovery-banner-container"),
        dmc.Box(
            [
                sidebar,
                dmc.Box(
                    [page_container],
                    id="main-content",
                    style={
                        "marginLeft": _SIDEBAR_WIDTHS[_initial_sidebar],
                        "padding": "72px 24px 24px 24px",
                        "minHeight": "100vh",
                        "backgroundColor": THEME.DARK_BG,
                        "transition": "margin-left 0.3s cubic-bezier(0.4,0,0.2,1)",
                    },
                    className="main-content",
                ),
            ]
        ),
    ],
    forceColorScheme="dark",
)

server = app.server


# =============================================================================
# HEALTH ENDPOINT (v12.4)
# =============================================================================
@server.route("/health")
def health():
    """Health check endpoint for monitoring."""
    import json
    from datetime import datetime as _dt

    try:
        from engine import get_pipeline

        pipeline = get_pipeline()
        has_data = pipeline.has_data()
    except Exception:
        has_data = False
    return (
        json.dumps(
            {
                "status": "ok",
                "version": APP.VERSION,
                "timestamp": _dt.now().isoformat(),
                "pipeline_loaded": has_data,
            }
        ),
        200,
        {"Content-Type": "application/json"},
    )


# =============================================================================
# THEME — Clientside + persist to DB
# =============================================================================
clientside_callback(
    """
    function(theme) {
        if (theme) {
            document.body.setAttribute('data-theme', theme);
        }
        return theme;
    }
    """,
    Output("theme-store", "data"),
    Input("theme-selector", "value"),
)

# Apply saved theme on page load
clientside_callback(
    """
    function(savedTheme) {
        var t = savedTheme || 'midnight';
        document.body.setAttribute('data-theme', t);
        return t;
    }
    """,
    Output("theme-selector", "value"),
    Input("theme-store", "data"),
)


# Persist theme to SQLite (survives browser cache clear)
@callback(
    Output("theme-store", "data", allow_duplicate=True),
    Input("theme-selector", "value"),
    prevent_initial_call=True,
)
def persist_theme(theme):
    if theme:
        try:
            from database import get_db

            get_db().set_preference("theme", theme)
        except Exception:
            pass
    return dash.no_update


# =============================================================================
# SIDEBAR 3-STATE — Clientside cycle: expanded → collapsed → hidden → expanded
# =============================================================================
clientside_callback(
    """
    function(n1, n2, currentState) {
        var cycle = {expanded: 'collapsed', collapsed: 'hidden', hidden: 'expanded'};
        var next = cycle[currentState] || 'expanded';
        var widths = {expanded: '260px', collapsed: '60px', hidden: '0px'};
        var sidebar = document.getElementById('sidebar');
        var content = document.getElementById('main-content');
        var floatingBtn = document.getElementById('floating-sidebar-toggle');
        if (sidebar && content) {
            sidebar.style.width = widths[next];
            content.style.marginLeft = widths[next];
            sidebar.classList.remove('collapsed', 'hidden');
            if (next !== 'expanded') {
                sidebar.classList.add(next);
            }
            if (next === 'hidden') {
                sidebar.style.overflow = 'hidden';
                sidebar.style.borderRight = 'none';
            } else {
                sidebar.style.overflowY = 'auto';
                sidebar.style.overflowX = 'hidden';
                sidebar.style.borderRight = '';
            }
        }
        if (floatingBtn) {
            floatingBtn.style.display = (next === 'hidden') ? 'block' : 'none';
        }
        return next;
    }
    """,
    Output("sidebar-state", "data"),
    Input("sidebar-toggle", "n_clicks"),
    Input("floating-sidebar-toggle", "n_clicks"),
    State("sidebar-state", "data"),
)


@callback(
    Output("sidebar-state", "data", allow_duplicate=True),
    Input("sidebar-state", "data"),
    prevent_initial_call=True,
)
def persist_sidebar(state):
    """Persist sidebar state to SQLite."""
    try:
        from database import get_db

        get_db().set_preference("sidebar_state", state or "expanded")
    except Exception:
        pass
    return dash.no_update


# =============================================================================
# MEMORY MONITOR — Robust with error boundary
# =============================================================================
@callback(
    [
        Output("memory-display", "children"),
        Output("memory-badge", "children"),
        Output("memory-badge", "color"),
        Output("memory-bar", "value"),
        Output("memory-bar", "color"),
    ],
    Input("memory-interval", "n_intervals"),
)
def update_memory_widget(_):
    try:
        from utils.memory_monitor import MemoryMonitor

        status = MemoryMonitor().get_status()
        rss = status["rss_mb"]
        level = status["level"]
        pct = min(100, (rss / 8192) * 100)
        color_map = {"ok": "green", "warning": "yellow", "critical": "red"}
        color = color_map.get(level, "gray")
        return f"{rss:.0f} MB", level.upper(), color, pct, color
    except Exception:
        return "— MB", "N/A", "gray", 0, "gray"


# =============================================================================
# NOTIFICATION TOAST — display pipeline events
# =============================================================================
@callback(
    Output("toast-container", "children"),
    Input("notification-store", "data"),
    prevent_initial_call=True,
)
def show_notification(notification):
    if not notification:
        return []
    msg = notification.get("message", "")
    ntype = notification.get("type", "info")
    color_map = {"success": "#00E676", "error": "#FF3D71", "warning": "#FFB300", "info": "#00D4FF"}
    icon_map = {
        "success": "mdi:check-circle",
        "error": "mdi:alert-circle",
        "warning": "mdi:alert",
        "info": "mdi:information",
    }
    return [
        dmc.Notification(
            title=ntype.upper(),
            message=msg,
            color=color_map.get(ntype, "#00D4FF"),
            icon=DashIconify(icon=icon_map.get(ntype, "mdi:information")),
            autoClose=5000,
            style={"backgroundColor": "var(--bg-elevated)", "border": "1px solid var(--border)"},
        ),
    ]


# =============================================================================
# GLOBAL REFRESH (v12.29) — floating button increments the shared global-refresh-ts
# counter. All page callbacks listen to this store to re-sync when clicked.
# =============================================================================
@callback(
    Output("global-refresh-ts", "data"),
    Input("topbar-refresh-btn", "n_clicks"),  # v16.39 T2: topbar button is the single working refresh
    State("global-refresh-ts", "data"),
    prevent_initial_call=True,
)
def trigger_global_refresh(global_n, current_ts):
    """Increment refresh timestamp so all subscribed page callbacks re-fire."""
    if not global_n:
        return no_update
    return (current_ts or 0) + 1


# =============================================================================
# C5 — WHAT'S NEW MODAL (shown once per version upgrade)
# =============================================================================
_WHATS_NEW = [
    ("A2", "Auto port detection", "Finds next free port if 8116 is occupied"),
    ("A3", "Auto browser open", "Browser launches automatically 3 s after startup"),
    ("A5", "One-click launcher", "launch_v16_9.bat — double-click to start, no terminal needed"),
    ("B1", "Auto-install deps", "Missing pip packages installed silently on startup"),
    ("C3", "Prefs persistence", "Theme & settings saved across browser cache clears"),
    ("D1", "Emoji stage chips", "Pipeline stages show emoji + colour-coded progress badges"),
    ("D2", "Toast notifications", "Pipeline complete / error toasts with auto-dismiss"),
    ("D5", "ETA countdown", "Live estimated time remaining during pipeline run"),
    ("E1", "Pre-flight checks", "Disk space, RAM and DB health verified on startup"),
    ("E3", "Crash recovery", "Detects incomplete runs and offers discard option"),
    ("F1", "Tab title updates", "Browser tab shows live progress % and status"),
    ("F3", "/health endpoint", "JSON status endpoint for external monitoring tools"),
]


@callback(
    Output("whats-new-modal-container", "children"),
    Output("version-seen-store", "data"),
    Input("startup-check", "n_intervals"),
    State("version-seen-store", "data"),
    prevent_initial_call=True,
)
def maybe_show_whats_new(_n, seen_version):
    """C5: Show What's New overlay once per version; user dismisses via button."""
    if seen_version == APP.VERSION:
        return [], no_update  # already seen this version

    rows = [
        dmc.Group(
            [
                dmc.Badge(code, color="cyan", variant="light", size="xs", miw=32),
                dmc.Text(title, size="sm", fw=600, style={"minWidth": 160}),
                dmc.Text(desc, size="xs", c="dimmed"),
            ],
            gap="xs",
            align="center",
        )
        for code, title, desc in _WHATS_NEW
    ]

    modal_inner = html.Div(
        [
            html.Div(
                [
                    dmc.Text(f"What's New in v{APP.VERSION}", fw=700, size="lg"),
                    dmc.Text("Premium UX Edition", size="xs", c="dimmed", mt=2),
                ],
                style={"marginBottom": 16},
            ),
            dmc.Stack(rows, gap=8),
            dmc.Button(
                "Got it — dismiss",
                id="whats-new-close-btn",
                variant="gradient",
                gradient={"from": "teal", "to": "cyan"},
                fullWidth=True,
                mt=20,
            ),
        ],
        style={
            "backgroundColor": "var(--bg-elevated, #1e1e2e)",
            "border": "1px solid var(--border, #2a2a3e)",
            "borderRadius": 12,
            "padding": "24px 28px",
            "maxWidth": 560,
            "width": "90vw",
            "boxShadow": "0 8px 40px rgba(0,0,0,0.6)",
        },
    )
    overlay = html.Div(
        modal_inner,
        id="whats-new-overlay",
        style={
            "position": "fixed",
            "top": 0,
            "left": 0,
            "width": "100vw",
            "height": "100vh",
            "backgroundColor": "rgba(0,0,0,0.55)",
            "display": "flex",
            "alignItems": "center",
            "justifyContent": "center",
            "zIndex": 10000,
        },
    )
    return [overlay], APP.VERSION


@callback(
    Output("whats-new-modal-container", "children", allow_duplicate=True),
    Input("whats-new-close-btn", "n_clicks"),
    prevent_initial_call=True,
)
def close_whats_new(_):
    """Dismiss the What's New modal when user clicks Got it."""
    return []


# =============================================================================
# E3 — RECOVERY BANNER (detect last interrupted pipeline run)
# =============================================================================
@callback(
    Output("recovery-banner-container", "children"),
    Input("startup-check", "n_intervals"),
    prevent_initial_call=True,
)
def maybe_show_recovery_banner(_n):
    """E3: If the most recent DB run has status='running', it was interrupted.
    Show a dismissible amber banner with a discard option."""
    try:
        from database import get_db

        history_df = get_db().get_run_history(limit=1)
        if history_df is None or len(history_df) == 0:
            return []
        last_status = str(history_df.iloc[0].get("status", "")).lower()
        if last_status != "running":
            return []
        last_run_id = history_df.iloc[0].get("run_id", "?")
        started_at = history_df.iloc[0].get("started_at", "unknown")
    except Exception:
        return []

    banner = dmc.Alert(
        dmc.Group(
            [
                DashIconify(icon="mdi:alert-circle", width=20, color="#FFB300"),
                dmc.Stack(
                    [
                        dmc.Text(
                            f"Incomplete run detected (Run #{last_run_id}, started {started_at})",
                            size="sm",
                            fw=600,
                            c="#FFB300",
                        ),
                        dmc.Text(
                            "The previous pipeline run did not complete — the server may have "
                            "restarted. Previous results are still available. "
                            "Re-run the pipeline to refresh.",
                            size="xs",
                            c="dimmed",
                        ),
                    ],
                    gap=2,
                ),
            ],
            gap="sm",
            align="flex-start",
        ),
        id="recovery-alert",
        color="yellow",
        variant="light",
        withCloseButton=True,
        style={
            "position": "fixed",
            "bottom": 16,
            "left": "50%",
            "transform": "translateX(-50%)",
            "zIndex": 8000,
            "maxWidth": 680,
            "width": "92vw",
            "boxShadow": "0 4px 24px rgba(0,0,0,0.4)",
        },
    )
    return [banner]


# =============================================================================
# LAUNCH HELPERS  (v16.9 Premium UX: A2, B1, C3, E1)
# =============================================================================


def _find_free_port(start: int, host: str = "127.0.0.1") -> int:
    """A2: Scan ports from `start` upward until one is available."""
    port = start
    while port < start + 20:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                sock.bind((host, port))
                return port
            except OSError:
                port += 1
    return start  # fallback — let Dash report the error


def _ensure_requirements() -> None:
    """B1: Silently pip-install any missing packages from requirements.txt."""
    import subprocess
    import sys as _sys

    req_file = Path(__file__).parent / "requirements.txt"
    if not req_file.exists():
        return
    try:
        import pkg_resources

        missing = []
        with open(req_file, encoding="utf-8") as f:
            for raw in f:
                line = raw.strip()
                if not line or line.startswith("#"):
                    continue
                pkg_name = line.split(";")[0].split("[")[0].strip()
                try:
                    pkg_resources.require(pkg_name)
                except Exception:
                    missing.append(line)
        if missing:
            print(f"  [PKG] Installing {len(missing)} missing package(s)\u2026")
            subprocess.check_call(
                [_sys.executable, "-m", "pip", "install", "--quiet"] + missing,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.STDOUT,
            )
            print(f"  [PKG] OK \u2014 {len(missing)} package(s) installed")
        else:
            print("  [PKG] All requirements satisfied")
    except Exception as exc:
        print(f"  [PKG] Auto-install skipped: {exc}")


def _preflight_checks() -> list:
    """E1: Check disk space, RAM, DB. Returns list of warning strings."""
    warnings: list = []
    try:
        usage = shutil.disk_usage(Path(__file__).parent)
        free_gb = usage.free / (1024**3)
        if free_gb < 0.5:
            warnings.append(f"Low disk space: {free_gb:.1f} GB free (recommend > 0.5 GB)")
        else:
            print(f"  [OK] Disk: {free_gb:.1f} GB free")
    except Exception as exc:
        warnings.append(f"Disk check failed: {exc}")
    try:
        import psutil

        avail_mb = psutil.virtual_memory().available // (1024 * 1024)
        if avail_mb < 512:
            warnings.append(f"Low RAM: {avail_mb} MB available (recommend > 512 MB)")
        else:
            print(f"  [OK] RAM: {avail_mb} MB available")
    except ImportError:
        pass
    except Exception as exc:
        warnings.append(f"RAM check: {exc}")
    try:
        if PATHS.DB_PATH.exists():
            db_mb = PATHS.DB_PATH.stat().st_size / (1024 * 1024)
            print(f"  [OK] DB: {PATHS.DB_PATH.name} ({db_mb:.1f} MB)")
        else:
            print("  [OK] DB: will be created at first run")
    except Exception as exc:
        warnings.append(f"DB check: {exc}")
    return warnings


def _sync_prefs_to_json() -> None:
    """C3: Mirror DB preferences to user_prefs.json as a human-readable backup."""
    try:
        from database import get_db

        prefs = get_db().get_all_preferences()
        if not prefs:
            return
        pref_file = Path(__file__).parent / "user_prefs.json"
        existing: dict = {}
        if pref_file.exists():
            try:
                existing = _json.loads(pref_file.read_text(encoding="utf-8"))
            except Exception:
                existing = {}
        existing.update(prefs)
        pref_file.write_text(_json.dumps(existing, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass  # Never block startup for pref-sync


# =============================================================================
# STARTUP — Robust with full error recovery
# =============================================================================
def _startup():
    """Initialize pipeline, load persisted data, validate air-gap."""
    # E1: Pre-flight hardware / environment checks
    _pf_warns = _preflight_checks()
    for _w in _pf_warns:
        print(f"  [WARN] {_w}")
    # B1: Silently install any missing requirements
    _ensure_requirements()
    try:
        from engine import get_pipeline

        pipeline = get_pipeline()

        # Validate air-gap compliance
        try:
            from utils.pii_guard import validate_air_gap

            validate_air_gap()
            print("  [OK] Air-Gap: COMPLIANT")
        except Exception as e:
            print(f"  [WARN] Air-Gap check: {e}")

        # Load persisted preferences
        try:
            from database import get_db

            db = get_db()
            prefs = db.get_all_preferences()
            if prefs:
                print(f"  [OK] Preferences: {len(prefs)} settings loaded")
            else:
                # Set defaults
                db.set_preference("theme", "midnight")
                db.set_preference("sidebar_collapsed", "false")
                print("  [OK] Preferences: defaults initialized")
        except Exception:
            print("  [WARN] Preferences: using defaults")

        # C3: Backup preferences to user_prefs.json
        _sync_prefs_to_json()

        # Load last run
        loaded = pipeline.load_last_run()
        if loaded and pipeline.has_data():
            meta = pipeline.last_run_meta
            print(
                f"  [OK] Loaded run #{meta.get('run_id', '?')}: "
                f"{meta.get('customers', 0)} customers, "
                f"{meta.get('graph_nodes', 0)} nodes"
            )
        else:
            print("  [--] No previous run. Use Dashboard to start pipeline.")

    except Exception as e:
        print(f"  [ERR] Startup error: {e}")
        traceback.print_exc()


# =============================================================================
# MAIN
# =============================================================================
if __name__ == "__main__":
    # v16.48 FIX: Force UTF-8 stdout so Unicode box-drawing chars in IDENTITY_BANNER
    # don't crash on Windows cp1252 consoles (e.g. MINGW64 / CMD with default codepage)
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except AttributeError:
        pass  # Python < 3.7 fallback
    from __about__ import IDENTITY_BANNER  # Option B: startup identity print
    print(IDENTITY_BANNER)
    print()
    print("=" * 64)
    print(f"  FCDAI NETWORK ANALYZER v{APP.VERSION} - SECURITY HARDENING EDITION")
    print("  Financial Crime Detection & AI")
    print("=" * 64)
    print("  Features:")
    print("    21 Premium Themes | 10-Family Analytics | Audit Chain")
    print("    Intelligence Hub | Workspace | Reports")
    print("    3-State Sidebar | Persistent Data | Memory Monitor")
    print("    Geo-Risk | Customer-360 | Comparative Runs")
    print("    PDF Activity Reports | Excel Export | PII Protection")
    print("    Plugin Architecture | Cache Manager | Config Hot-Reload")
    print(f"  v{APP.VERSION} — v16.56.0 Risk Tables Edition:")
    print("    #U1: 4 role-based users (admin/investigator/internal/reporter)")
    print("    #U2: Admin sees full Swagger/ReDoc without API key")
    print("    #U3: Role stored in Flask session on login")
    print("    #2:  Audit trail wired: pipeline trigger, export, SAR access")
    print("    #7:  Swagger at /admin/api-docs (API key req'd), /docs disabled")
    print("    #8b: pip-audit CVE scan in CI workflow")
    print("    #10: CORS allow_headers explicit list (no wildcard)")
    print("    #12: Generic error messages (ref ID + server-side log)")
    print("    #14: Idempotency on POST /pipeline/run (60-s dedup)")
    print("    #15: CSV formula injection sanitisation (=,+,-,@ → ')")
    print("    #16: Rotating log files (TimedRotatingFileHandler, 90-day retention)")
    print("  v12.45:")
    print("    T1: SAR renamed to Activity Report / Narrative throughout")
    print("    T2: Customer names on Money Flow visualization")
    print("    T3/T5: Dashboard persistence fixes (layout fn + placeholders)")
    print("    T4: Analytics charts show absolute + percentage values")
    print("  v12.43:")
    print("    B1: Business-first language overhaul (executive-friendly)")
    print("    B2: Previous-run indicator banner (Run #X, date)")
    print("    B3: Progressive UI reset on re-run (stage-by-stage)")
    print("    B4: Enhanced Data Readiness (business context per table)")
    print("  v12.40:")
    print("    4-View Executive Report Suite (Overview|Strategic|Financial|Technical)")
    print("  v12.4 Base:")
    print("    Parallel 10-family | Sampling | Caching | Background execution")
    print("    Scalable Graph: 1K / 5K / 10K nodes, no lag")
    print("=" * 64)
    print(f"  Server : http://{APP.HOST}:{APP.PORT}")
    print(f"  Database: {PATHS.DB_PATH}")
    print(f"  Mode   : Air-Gapped | PII-Protected | Offline-Only")
    print("=" * 64)
    print()

    _startup()

    # A2: Auto-detect free port if configured port is occupied
    resolved_port = _find_free_port(APP.PORT, APP.HOST)
    if resolved_port != APP.PORT:
        print(f"  [PORT] {APP.PORT} in use \u2192 switching to port {resolved_port}")

    print()
    print(f"  >> Ready at http://{APP.HOST}:{resolved_port}")
    print("  Press Ctrl+C to stop")
    print("  Browser opens automatically in 3 seconds\u2026")
    print()

    # A3: Auto-open browser after Dash binds (3-second delay)
    _threading.Timer(3.0, lambda: webbrowser.open(f"http://{APP.HOST}:{resolved_port}")).start()

    app.run(debug=APP.DEBUG, host=APP.HOST, port=resolved_port)
