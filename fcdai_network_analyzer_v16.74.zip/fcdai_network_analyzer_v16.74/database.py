"""
FCDAI Network Analyzer v16.16 — Database Manager (SQLCipher + SQLite fallback)
===============================================================================
v16.16 Bank-Grade Security:
  - SQLCipher (AES-256 at-rest encryption) used when pysqlcipher3 is available.
  - Graceful fallback to standard sqlite3 if SQLCipher is not installed.
  - Encryption key is derived from a machine-specific key file (data/db.key).
    If the key file does not exist it is auto-generated with os.urandom(32) and
    stored with restricted permissions (0o600).  The DB can only be opened on
    the machine that created the key file — satisfying air-gapped PII policy.
  - Key file path configurable via DB_KEY_FILE env-var (for CI/test override).
  - Also adds pa_staging_log table for full data-provenance audit trail.

Technical Implementation: DataFrames serialised as JSON. Graphs as pickle blobs.
Thread-safe with check_same_thread=False.
"""

import os
import hashlib
import secrets
import stat
import sqlite3
import json
import pickle
import time
import io
from pathlib import Path
from typing import Any, Dict, List, Optional
from datetime import datetime
import pandas as pd
import numpy as np
import networkx as nx

# ── SQLCipher (AES-256) with plain sqlite3 fallback ─────────────────────────
try:
    from pysqlcipher3 import dbapi2 as _sqlmodule  # type: ignore
    _CIPHER_AVAILABLE = True
except ImportError:
    _sqlmodule = sqlite3
    _CIPHER_AVAILABLE = False


def _get_or_create_db_key(db_path: Path) -> str:
    """Return hex encryption key, creating key-file on first run.
    Key file lives next to the DB (data/fcdai.key) with mode 0o600.
    Set env-var DB_KEY_FILE to override the path (useful in tests).
    Bank policy: key file must exist before DB is opened — if it is deleted
    the DB becomes inaccessible (correct behaviour for PII compliance).
    """
    key_file = Path(os.environ.get("DB_KEY_FILE", "") or db_path.with_suffix(".key"))
    if not key_file.exists():
        raw = secrets.token_bytes(32)  # 256-bit key
        key_file.write_bytes(raw)
        try:
            key_file.chmod(0o600)   # owner read/write only
        except Exception:
            pass  # Windows may not support chmod — acceptable on air-gapped PC
    return key_file.read_bytes().hex()  # SQLCipher wants hex string


def _open_connection(db_path: Path, key: str):
    """Open a SQLCipher or plain SQLite connection depending on availability."""
    if _CIPHER_AVAILABLE:
        conn = _sqlmodule.connect(
            str(db_path),
            check_same_thread=False,
            detect_types=sqlite3.PARSE_DECLTYPES,
        )
        conn.execute(f"PRAGMA key=\"x'{key}'\"")   # SQLCipher key pragma
        conn.execute("PRAGMA cipher_page_size=4096")
        conn.execute("PRAGMA kdf_iter=256000")       # PBKDF2 iterations
        conn.execute("PRAGMA cipher_hmac_algorithm=HMAC_SHA512")
    else:
        conn = sqlite3.connect(
            str(db_path),
            check_same_thread=False,
            detect_types=sqlite3.PARSE_DECLTYPES,
        )
    return conn

# v16.8 L3: JSON prefix for format detection (vs legacy pickle)
_JSON_PREFIX = b"json:"


class _NumpyEncoder(json.JSONEncoder):
    """JSON encoder that handles numpy scalar/array types."""

    def default(self, obj):
        if isinstance(obj, (np.integer,)):
            return int(obj)
        if isinstance(obj, (np.floating,)):
            return float(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        return super().default(obj)


class DatabaseManager:
    """
    Business Logic: Manages all pipeline data persistence via SQLite.
    Stores run history, raw tables, scored results, analytics, and metadata.
    """

    def __init__(self, db_path: Path):
        """Initialize DB connection with SQLCipher (AES-256) or SQLite fallback.
        v16.16: key is read from / generated in a sibling .key file.
        SQLCipher availability is printed once at startup for ops transparency.
        """
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._encryption_key = _get_or_create_db_key(self.db_path)
        self._conn = _open_connection(self.db_path, self._encryption_key)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        _mode = "SQLCipher AES-256" if _CIPHER_AVAILABLE else "SQLite (plain — install pysqlcipher3 for encryption)"
        print(f"  [DB] Storage: {_mode} | {self.db_path.name}", flush=True)
        self._create_tables()

    def _create_tables(self):
        """Create all required tables if they don't exist."""
        self._conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS pipeline_runs (
                run_id       INTEGER PRIMARY KEY AUTOINCREMENT,
                started_at   TEXT NOT NULL,
                finished_at  TEXT,
                duration_sec REAL,
                customers    INTEGER DEFAULT 0,
                nodes        INTEGER DEFAULT 0,
                edges        INTEGER DEFAULT 0,
                status       TEXT DEFAULT 'running',
                metadata     TEXT DEFAULT '{}'
            );

            CREATE TABLE IF NOT EXISTS raw_tables (
                id       INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id   INTEGER NOT NULL,
                name     TEXT NOT NULL,
                data     TEXT NOT NULL,
                rows     INTEGER DEFAULT 0,
                cols     INTEGER DEFAULT 0,
                FOREIGN KEY (run_id) REFERENCES pipeline_runs(run_id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS scored_results (
                id       INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id   INTEGER NOT NULL,
                data     TEXT NOT NULL,
                rows     INTEGER DEFAULT 0,
                FOREIGN KEY (run_id) REFERENCES pipeline_runs(run_id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS analytics_results (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id      INTEGER NOT NULL,
                family      TEXT NOT NULL,
                data        TEXT NOT NULL,
                rows        INTEGER DEFAULT 0,
                FOREIGN KEY (run_id) REFERENCES pipeline_runs(run_id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS graph_data (
                id       INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id   INTEGER NOT NULL,
                graph    BLOB NOT NULL,
                FOREIGN KEY (run_id) REFERENCES pipeline_runs(run_id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS reports_data (
                id       INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id   INTEGER NOT NULL,
                reports  BLOB NOT NULL,
                FOREIGN KEY (run_id) REFERENCES pipeline_runs(run_id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS user_preferences (
                key      TEXT PRIMARY KEY,
                value    TEXT NOT NULL,
                updated  TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS alert_hashes (
                hash     TEXT PRIMARY KEY,
                node_id  TEXT NOT NULL,
                tier     TEXT NOT NULL,
                pattern  TEXT DEFAULT '',
                run_id   INTEGER,
                created  TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS audit_trail (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id    INTEGER,
                timestamp TEXT NOT NULL,
                action    TEXT NOT NULL,
                details   TEXT DEFAULT '',
                user      TEXT DEFAULT 'SYSTEM',
                severity  TEXT DEFAULT 'INFO',
                hash      TEXT DEFAULT ''
            );

            -- v16.16: Data-provenance log for Port Authority staging events
            -- Immutable record: who loaded what data, when, with fingerprint.
            -- Append-only by convention (no DELETE / UPDATE in application code).
            CREATE TABLE IF NOT EXISTS pa_staging_log (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp     TEXT NOT NULL,
                action        TEXT NOT NULL,
                source_mode   TEXT DEFAULT 'sample',
                tables_loaded INTEGER DEFAULT 0,
                total_rows    INTEGER DEFAULT 0,
                n_customers   INTEGER DEFAULT 0,
                scope         TEXT DEFAULT '',
                seed          INTEGER DEFAULT 0,
                fingerprint   TEXT DEFAULT '',
                elapsed_sec   REAL DEFAULT 0.0,
                table_detail  TEXT DEFAULT '{}'
            );
        """
        )
        self._conn.commit()

    # =========================================================================
    # DATA PROVENANCE — PA STAGING LOG (v16.16)
    # =========================================================================
    def log_staging_event(
        self,
        action: str,
        source_mode: str = "sample",
        tables: dict = None,
        n_customers: int = 0,
        scope: str = "",
        seed: int = 0,
        fingerprint: str = "",
        elapsed_sec: float = 0.0,
    ) -> int:
        """Append-only record of every data staging event.
        actions: GENERATE | UPLOAD | PUSH | RESET | SCENARIO
        Returns the new row id.
        """
        tables = tables or {}
        total_rows = sum(len(v) for v in tables.values() if v is not None)
        detail = json.dumps({k: int(len(v)) for k, v in tables.items() if v is not None})
        now = datetime.now().isoformat()
        cur = self._conn.execute(
            "INSERT INTO pa_staging_log "
            "(timestamp, action, source_mode, tables_loaded, total_rows, "
            " n_customers, scope, seed, fingerprint, elapsed_sec, table_detail) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (now, action, source_mode, len(tables), total_rows,
             n_customers, scope, seed, fingerprint, elapsed_sec, detail),
        )
        self._conn.commit()
        return cur.lastrowid

    def get_staging_log(self, limit: int = 50) -> list:
        """Return recent staging events newest-first."""
        rows = self._conn.execute(
            "SELECT id, timestamp, action, source_mode, tables_loaded, "
            "total_rows, n_customers, scope, seed, fingerprint, elapsed_sec "
            "FROM pa_staging_log ORDER BY id DESC LIMIT ?",
            (limit,),
        ).fetchall()
        keys = ["id", "timestamp", "action", "source_mode", "tables_loaded",
                "total_rows", "n_customers", "scope", "seed", "fingerprint", "elapsed_sec"]
        return [dict(zip(keys, r)) for r in rows]

    # =========================================================================
    # AUDIT TRAIL — application-level event logging (v16.51 #2)
    # =========================================================================
    def log_audit_event(
        self,
        action: str,
        details: str = "",
        user: str = "SYSTEM",
        severity: str = "INFO",
        run_id: Optional[int] = None,
    ) -> int:
        """
        Insert one row into audit_trail for a security-relevant application event.

        v16.51 #2 — wired at:
          • POST /pipeline/run  (PIPELINE_TRIGGERED)
          • GET  /results/sar   (SAR_NARRATIVES_ACCESSED)
          • GET  /reports/export (RESULTS_EXPORTED)

        Args:
            action:   Short event code, e.g. 'PIPELINE_TRIGGERED'
            details:  Free-text detail string — must NOT contain raw PII
            user:     Logged-in analyst name, or os.getlogin() fallback
            severity: 'INFO' | 'WARN' | 'ALERT'
            run_id:   Associated pipeline run, or None for non-run events

        Returns: new row id
        """
        ts = datetime.utcnow().isoformat(timespec="seconds") + "Z"
        # Guard: truncate details to prevent unbounded row growth
        details = str(details)[:500] if details else ""
        cur = self._conn.execute(
            "INSERT INTO audit_trail (run_id, timestamp, action, details, user, severity) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (run_id, ts, action, details, user, severity),
        )
        self._conn.commit()
        return cur.lastrowid


    def get_alert_hashes(self) -> Dict[str, Dict]:
        """Get all previously stored alert hashes for dedup comparison."""
        rows = self._conn.execute(
            "SELECT hash, node_id, tier, pattern, run_id FROM alert_hashes"
        ).fetchall()
        return {
            r[0]: {"node_id": r[1], "tier": r[2], "pattern": r[3], "run_id": r[4]} for r in rows
        }

    def save_alert_hash(
        self, ahash: str, node_id: str, tier: str, pattern: str = "", run_id: int = None
    ):
        """Insert or update an alert hash for dedup tracking."""
        now = datetime.now().isoformat()
        self._conn.execute(
            "INSERT OR REPLACE INTO alert_hashes "
            "(hash, node_id, tier, pattern, run_id, created) "
            "VALUES (?,?,?,?,?,?)",
            (ahash, node_id, tier, pattern, run_id, now),
        )
        self._conn.commit()

    def save_alert_hashes_bulk(self, hashes: list):
        """Bulk-insert alert hashes. Each item: (hash, node_id, tier, pattern, run_id)."""
        now = datetime.now().isoformat()
        self._conn.executemany(
            "INSERT OR REPLACE INTO alert_hashes "
            "(hash, node_id, tier, pattern, run_id, created) "
            "VALUES (?,?,?,?,?,?)",
            [(h, n, t, p, r, now) for h, n, t, p, r in hashes],
        )
        self._conn.commit()

    # =========================================================================
    # USER PREFERENCE PERSISTENCE
    # =========================================================================
    def get_preference(self, key: str, default: str = None) -> Optional[str]:
        """Get a persisted user preference."""
        row = self._conn.execute(
            "SELECT value FROM user_preferences WHERE key=?", (key,)
        ).fetchone()
        return row[0] if row else default

    def set_preference(self, key: str, value: str):
        """Persist a user preference (upsert)."""
        now = datetime.now().isoformat()
        self._conn.execute(
            "INSERT OR REPLACE INTO user_preferences (key, value, updated) VALUES (?,?,?)",
            (key, value, now),
        )
        self._conn.commit()

    def get_all_preferences(self) -> Dict[str, str]:
        """Get all user preferences."""
        rows = self._conn.execute("SELECT key, value FROM user_preferences").fetchall()
        return {r[0]: r[1] for r in rows}

    # =========================================================================
    # SAVE OPERATIONS
    # =========================================================================
    def start_run(self, max_customers: int = 500) -> int:
        """Create a new pipeline run record. Returns run_id."""
        now = datetime.now().isoformat()
        cur = self._conn.execute(
            "INSERT INTO pipeline_runs (started_at, customers, status, metadata) "
            "VALUES (?, ?, 'running', ?)",
            (now, max_customers, json.dumps({"max_customers": max_customers})),
        )
        self._conn.commit()
        return cur.lastrowid

    def finish_run(
        self,
        run_id: int,
        duration: float,
        customers: int,
        nodes: int,
        edges: int,
        status: str = "success",
        meta: Dict = None,
    ):
        """Mark a run as complete with final stats."""
        now = datetime.now().isoformat()
        self._conn.execute(
            "UPDATE pipeline_runs SET finished_at=?, duration_sec=?, "
            "customers=?, nodes=?, edges=?, status=?, metadata=? WHERE run_id=?",
            (
                now,
                round(duration, 2),
                customers,
                nodes,
                edges,
                status,
                json.dumps(meta or {}),
                run_id,
            ),
        )
        self._conn.commit()

    def save_raw_tables(self, run_id: int, tables: Dict[str, pd.DataFrame]):
        """Save raw input DataFrames for a run.

        v16.8 H2: Truncate to 5 000-row preview to bound SQLite cell size.
        Full data is separately persisted to Parquet vault by the engine.
        """
        _PREVIEW_ROWS = 5000
        for name, df in tables.items():
            full_rows = len(df)
            preview_df = df.head(_PREVIEW_ROWS) if full_rows > _PREVIEW_ROWS else df
            data_json = preview_df.to_json(orient="split", date_format="iso", default_handler=str)
            self._conn.execute(
                "INSERT INTO raw_tables (run_id, name, data, rows, cols) VALUES (?,?,?,?,?)",
                (run_id, name, data_json, full_rows, len(df.columns)),
            )
        self._conn.commit()

    def save_scored(self, run_id: int, scored_df: pd.DataFrame):
        """Save scored results DataFrame for a run."""
        if scored_df is not None and len(scored_df) > 0:
            data_json = scored_df.to_json(orient="split", date_format="iso", default_handler=str)
            self._conn.execute(
                "INSERT INTO scored_results (run_id, data, rows) VALUES (?,?,?)",
                (run_id, data_json, len(scored_df)),
            )
            self._conn.commit()

    def save_analytics(self, run_id: int, analytics: Dict[str, pd.DataFrame]):
        """Save analytics results by family."""
        for family, df in analytics.items():
            if df is not None and isinstance(df, pd.DataFrame) and len(df) > 0:
                data_json = df.to_json(orient="split", date_format="iso", default_handler=str)
                self._conn.execute(
                    "INSERT INTO analytics_results (run_id, family, data, rows) "
                    "VALUES (?,?,?,?)",
                    (run_id, family, data_json, len(df)),
                )
        self._conn.commit()

    def save_graph(self, run_id: int, graph):
        """Save networkx graph. v16.8 L3: uses JSON node-link format (forward-safe).
        Falls back to pickle only if graph contains non-serialisable custom objects.
        """
        if graph is not None:
            try:
                data = nx.node_link_data(graph)
                blob = _JSON_PREFIX + json.dumps(data, cls=_NumpyEncoder).encode("utf-8")
            except Exception:
                blob = pickle.dumps(graph)  # graceful pickle fallback
            self._conn.execute(
                "INSERT INTO graph_data (run_id, graph) VALUES (?,?)",
                (run_id, blob),
            )
            self._conn.commit()

    def save_reports(self, run_id: int, reports: Dict):
        """Save reports dictionary. v16.8 L3: JSON-based for forward compatibility.
        DataFrames are inlined as JSON split-orient; unknown types fall back to pickle.
        """
        if reports is not None:
            try:
                serialisable = {}
                for k, v in reports.items():
                    if isinstance(v, pd.DataFrame):
                        serialisable[k] = {
                            "__df__": True,
                            "data": v.to_json(
                                orient="split", date_format="iso", default_handler=str
                            ),
                        }
                    else:
                        serialisable[k] = v
                blob = _JSON_PREFIX + json.dumps(
                    serialisable, cls=_NumpyEncoder, default=str
                ).encode("utf-8")
            except Exception:
                blob = pickle.dumps(reports)  # graceful pickle fallback
            self._conn.execute(
                "INSERT INTO reports_data (run_id, reports) VALUES (?,?)",
                (run_id, blob),
            )
            self._conn.commit()

    # =========================================================================
    # LOAD OPERATIONS
    # =========================================================================
    def load_latest_run(self) -> Optional[Dict[str, Any]]:
        """
        Load the most recent successful run data.
        Returns dict with: run_info, scored_df, analytics, graph, raw_tables, reports
        """
        row = self._conn.execute(
            "SELECT run_id, started_at, finished_at, duration_sec, customers, "
            "nodes, edges, status, metadata "
            "FROM pipeline_runs WHERE status='success' "
            "ORDER BY run_id DESC LIMIT 1"
        ).fetchone()

        if not row:
            return None

        run_id = row[0]
        run_info = {
            "run_id": run_id,
            "started_at": row[1],
            "finished_at": row[2],
            "duration_sec": row[3],
            "customers": row[4],
            "nodes": row[5],
            "edges": row[6],
            "status": row[7],
            "metadata": json.loads(row[8] or "{}"),
        }

        result = {"run_info": run_info}

        # Scored results
        scored_row = self._conn.execute(
            "SELECT data FROM scored_results WHERE run_id=? ORDER BY id DESC LIMIT 1",
            (run_id,),
        ).fetchone()
        result["scored_df"] = (
            pd.read_json(io.StringIO(scored_row[0]), orient="split") if scored_row else None
        )

        # Analytics
        analytics = {}
        for arow in self._conn.execute(
            "SELECT family, data FROM analytics_results WHERE run_id=?", (run_id,)
        ).fetchall():
            analytics[arow[0]] = pd.read_json(io.StringIO(arow[1]), orient="split")
        result["analytics"] = analytics

        # Graph — v16.8 L3: JSON-first, pickle fallback for legacy runs
        graph_row = self._conn.execute(
            "SELECT graph FROM graph_data WHERE run_id=? ORDER BY id DESC LIMIT 1",
            (run_id,),
        ).fetchone()
        if graph_row:
            raw = bytes(graph_row[0])
            try:
                if raw.startswith(_JSON_PREFIX):
                    data = json.loads(raw[len(_JSON_PREFIX) :].decode("utf-8"))
                    result["graph"] = nx.node_link_graph(data)
                else:
                    result["graph"] = pickle.loads(raw)
            except Exception:
                result["graph"] = None
        else:
            result["graph"] = None

        # Raw tables
        raw_tables = {}
        for trow in self._conn.execute(
            "SELECT name, data FROM raw_tables WHERE run_id=?", (run_id,)
        ).fetchall():
            raw_tables[trow[0]] = pd.read_json(io.StringIO(trow[1]), orient="split")
        result["raw_tables"] = raw_tables

        # Reports — v16.8 L3: JSON-first, pickle fallback for legacy runs
        reports_row = self._conn.execute(
            "SELECT reports FROM reports_data WHERE run_id=? ORDER BY id DESC LIMIT 1",
            (run_id,),
        ).fetchone()
        if reports_row:
            raw = bytes(reports_row[0])
            try:
                if raw.startswith(_JSON_PREFIX):
                    loaded = json.loads(raw[len(_JSON_PREFIX) :].decode("utf-8"))
                    reports = {}
                    for k, v in loaded.items():
                        if isinstance(v, dict) and v.get("__df__"):
                            reports[k] = pd.read_json(io.StringIO(v["data"]), orient="split")
                        else:
                            reports[k] = v
                    result["reports"] = reports
                else:
                    result["reports"] = pickle.loads(raw)
            except Exception:
                result["reports"] = None
        else:
            result["reports"] = None

        return result

    # =========================================================================
    # HISTORY & QUERY OPERATIONS
    # =========================================================================
    def get_run_history(self, limit: int = 50) -> pd.DataFrame:
        """Get all pipeline runs as a DataFrame."""
        rows = self._conn.execute(
            "SELECT run_id, started_at, finished_at, duration_sec, customers, "
            "nodes, edges, status FROM pipeline_runs "
            "ORDER BY run_id DESC LIMIT ?",
            (limit,),
        ).fetchall()

        if not rows:
            return pd.DataFrame(
                columns=[
                    "run_id",
                    "started_at",
                    "finished_at",
                    "duration_sec",
                    "customers",
                    "nodes",
                    "edges",
                    "status",
                ]
            )

        return pd.DataFrame(
            rows,
            columns=[
                "run_id",
                "started_at",
                "finished_at",
                "duration_sec",
                "customers",
                "nodes",
                "edges",
                "status",
            ],
        )

    def get_run_scored(self, run_id: int) -> Optional[pd.DataFrame]:
        """Get scored results for a specific run."""
        row = self._conn.execute(
            "SELECT data FROM scored_results WHERE run_id=?", (run_id,)
        ).fetchone()
        return pd.read_json(io.StringIO(row[0]), orient="split") if row else None

    def get_table_list(self) -> List[Dict]:
        """List all SQLite tables with row/column counts."""
        tables = []
        for row in self._conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
        ).fetchall():
            name = row[0]
            count = self._conn.execute(f"SELECT COUNT(*) FROM [{name}]").fetchone()[0]
            # Get column info
            cols = self._conn.execute(f"PRAGMA table_info([{name}])").fetchall()
            tables.append(
                {
                    "table": name,
                    "rows": count,
                    "columns": len(cols),
                    "col_names": [c[1] for c in cols],
                }
            )
        return tables

    def preview_table(self, table_name: str, limit: int = 100) -> pd.DataFrame:
        """Preview any SQLite table."""
        try:
            df = pd.read_sql_query(
                f"SELECT * FROM [{table_name}] LIMIT ?", self._conn, params=(limit,)
            )
            return df
        except Exception:
            return pd.DataFrame()

    def run_query(self, sql: str, limit: int = 500) -> pd.DataFrame:
        """Execute arbitrary SELECT query. Read-only."""
        sql_stripped = sql.strip().upper()
        if not sql_stripped.startswith("SELECT"):
            return pd.DataFrame({"error": ["Only SELECT queries are allowed"]})
        try:
            df = pd.read_sql_query(sql, self._conn)
            return df.head(limit)
        except Exception as e:
            return pd.DataFrame({"error": [str(e)]})

    # =========================================================================
    # AUDIT TRAIL PERSISTENCE (v16.8 H1)
    # =========================================================================
    def save_audit_trail(self, entries: List[Dict], run_id: int = None):
        """Persist in-memory audit trail entries to SQLite."""
        if not entries:
            return
        rows = [
            (
                run_id,
                e.get("timestamp", datetime.now().isoformat()),
                e.get("action", ""),
                e.get("details", ""),
                e.get("user", "SYSTEM"),
                e.get("severity", "INFO"),
                e.get("hash", ""),
            )
            for e in entries
        ]
        self._conn.executemany(
            "INSERT INTO audit_trail (run_id, timestamp, action, details, user, severity, hash) "
            "VALUES (?,?,?,?,?,?,?)",
            rows,
        )
        self._conn.commit()

    def load_audit_trail(self, limit: int = 500, severity: str = None) -> List[Dict]:
        """Load recent audit trail entries from SQLite."""
        if severity:
            rows = self._conn.execute(
                "SELECT run_id, timestamp, action, details, user, severity, hash "
                "FROM audit_trail WHERE severity=? ORDER BY id DESC LIMIT ?",
                (severity, limit),
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT run_id, timestamp, action, details, user, severity, hash "
                "FROM audit_trail ORDER BY id DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [
            {
                "run_id": r[0],
                "timestamp": r[1],
                "action": r[2],
                "details": r[3],
                "user": r[4],
                "severity": r[5],
                "hash": r[6],
            }
            for r in reversed(rows)  # chronological order
        ]

    def clear_runs(self):
        """Delete all pipeline run data."""
        for table in [
            "reports_data",
            "graph_data",
            "analytics_results",
            "scored_results",
            "raw_tables",
            "pipeline_runs",
        ]:
            self._conn.execute(f"DELETE FROM [{table}]")
        self._conn.execute("VACUUM")
        self._conn.commit()

    def get_db_stats(self) -> Dict:
        """Get database statistics."""
        size_bytes = self.db_path.stat().st_size if self.db_path.exists() else 0
        runs = self._conn.execute("SELECT COUNT(*) FROM pipeline_runs").fetchone()[0]
        return {
            "size_mb": round(size_bytes / (1024 * 1024), 2),
            "total_runs": runs,
            "db_path": str(self.db_path),
        }

    def close(self):
        """Close the database connection."""
        self._conn.close()


# =============================================================================
# SINGLETON
# =============================================================================
_db: Optional[DatabaseManager] = None


def get_db() -> DatabaseManager:
    """Get or create the singleton DatabaseManager."""
    global _db
    if _db is None:
        from config import PATHS

        _db = DatabaseManager(PATHS.DB_PATH)
    return _db
