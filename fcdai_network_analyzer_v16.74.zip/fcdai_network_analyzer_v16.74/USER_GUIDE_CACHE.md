# FCDAI Network Analyzer v16.73 — Cache System User Guide

## What's New?

**Instant Results on Instant Replay** ⚡

v16.73 adds a **smart cache system** that instantly reuses pipeline results when you run the analysis again with the exact same data and settings. No recomputation. No waiting.

---

## How It Works (Simple Version)

Every time you click **"Run Pipeline"**, the system creates a unique "fingerprint" of:
1. **Your data** (all uploaded tables)
2. **Your weights** (the 10 scoring sliders you adjusted)
3. **Your settings** (max customers, normalization method, etc.)
4. **The app version** (v16.73.0)

### Scenario 1: First Run
```
DATA uploaded: 1000 customers, 500 nodes
WEIGHTS: centrality=0.15, community=0.10, ...
SETTINGS: max=500, norm=rank, parallel=ON
────────────────────────────────────────────
Fingerprint A created
Run pipeline (takes ~30-60 seconds)
Store results + Fingerprint A in memory
```

### Scenario 2: You Run Again with NO Changes
```
Same DATA, WEIGHTS, and SETTINGS
────────────────────────────────────────────
New fingerprint computed... it's identical to Fingerprint A!
✅ CACHE HIT → Results loaded **instantly** (< 500ms)
No pipeline recomputation needed
```

### Scenario 3: You Change ONE Weight
```
WEIGHTS: centrality=0.20 (was 0.15 ✏️)
All else unchanged
────────────────────────────────────────────
New fingerprint computed... different from Fingerprint A!
❌ Cache miss → Fresh pipeline run starts
Orange badge shows: "**Scoring weights changed → fresh run**"
Pipeline takes ~30-60 seconds again
Results updated with new weight emphasis
```

---

## When You Get Instant Results 🚀

**Cache hit** (instant < 500ms):
- ✅ All data exactly the same (no rows added/deleted/edited)
- ✅ All 10 weights unchanged (sliders untouched)
- ✅ All settings unchanged (max customers, norm method, parallel, etc.)
- ✅ App version unchanged (same v16.73.0)

→ **System shows: "⚡ Exact Match — Results Reloaded"** (Teal bar)

---

## When You Get a Fresh Run 🔄

**Cache miss** (fresh pipeline ~30-60s):
- Any single row added to any table
- Any single row edited in any table  
- Any single row deleted from any table
- Any weight slider adjusted (even 0.15 → 0.20)
- Max customers changed
- Normalization method changed (rank ↔ z-score)
- Tier mode changed (percentile ↔ absolute)
- Parallel/Progressive toggles
- Sampling settings changed
- App updated to new version

→ **System shows orange badge with what changed:**
- "**Input data changed** → fresh run"
- "**Scoring weights changed** → fresh run"
- "**Pipeline config changed** → fresh run"
- Or combo: "**Weights + Config changed** → fresh run"

---

## Real-World Example: Refining Analysis

**Your workflow:**

| Step | Action | Result | Time |
|------|--------|--------|------|
| 1 | Upload data, click **Run** | Fingerprint A created, pipeline runs | 45s |
| 2 | Click **Run** again (test) | FP matches A → **cache hit** ⚡ | 0.3s |
| 3 | Adjust centrality 0.15 → 0.18 | FP differs (weights), fresh run | 45s |
| 4 | Adjust community 0.10 → 0.12 | FP differs (weights), fresh run | 45s |
| 5 | Click **Run** again (double-check) | FP matches current weights → **cache hit** ⚡ | 0.3s |
| 6 | Adjust max customers | FP differs (config), fresh run | 45s |
| 7 | Revert max customers back | FP matches → **cache hit** ⚡ | 0.3s |

**Total time:**
- Without cache: 45×4 = 180s
- With cache: 45×3 + 0.3×4 = **136s** ✅ **24% faster**

---

## What Gets Checked?

### ✅ Data Fingerprint
Every cell in every uploaded table is checked:
- Customer table: 1000 rows × 25 columns = 25,000 cells checked
- Node table: 500 rows × 40 columns = 20,000 cells checked
- etc.

If even ONE cell value changes, fingerprint differs. No false cache hits.

### ✅ Weights Fingerprint
All 10 scoring weights:
1. Centrality
2. Community
3. Path Flow
4. Link Prediction
5. Anomaly Detection
6. Temporal Decay
7. Multi-Layer Links
8. Structuring
9. Benford's Law
10. Motif Analysis

Precision: 6 decimal places (0.15 ≠ 0.150001).

### ✅ Settings Fingerprint
- Max customers cap
- Normalization method (rank / z-score)
- Risk tier mode (percentile / absolute)
- Tier thresholds (p1, p2, p3)
- Parallel processing (ON/OFF)
- Progressive UI (ON/OFF)
- Sampling (ON/OFF + size)

### ✅ Version Fingerprint
App version (v16.73.0). Forces fresh run on any update → ensures compatibility.

---

## FAQ

### Q: Why does it take 2 seconds even with a cache hit?
**A:** System loads results from database into memory. For large datasets (1000+ customers), DB query + memory load takes ~200-500ms. Still 60× faster than recomputation.

### Q: Can I force a fresh run even if nothing changed?
**A:** Yes — edit any data value, adjust any weight slider, change any setting. Or **restart the server** to clear memory cache (though DB cache is still used).

### Q: What if I upload the same data file twice?
**A:** Fingerprint will be identical → cache hit. Results reused.

### Q: What if the database gets corrupted?
**A:** Safety feature: if database load fails, system falls back to fresh pipeline run. No data loss, just slower (no cache benefit).

### Q: Does restarting the server clear the cache?
**A:** No! Fingerprints are saved in the database. After restart, on first run with same data, system retrieves previous run from DB and shows instant results.

### Q: Can I see which layers changed?
**A:** Yes! Orange badge during pipeline load shows exactly what changed:
- "Input data changed" = rows/cells updated
- "Scoring weights changed" = weight sliders adjusted
- "Pipeline config changed" = settings (max, norm, tier) adjusted
- "App version changed" = automatic on app update

### Q: Is this secure? Does it share fingerprints?
**A:** Yes, secure. Fingerprints are:
- Stored locally in your SQLite database only
- Never sent to cloud or external services
- Used for comparison only (read-only impact on cache)
- Air-gapped (no network access)

---

## Behind the Scenes (For the Curious)

The fingerprint is a **SHA-256 hash** — think of it like a unique ID for your exact data + weights + settings combination:

```
Input: 1000 customers + 10 weights + 7 config params + version
       ↓
       Hash each layer separately
       ↓
       Combine 4 hashes into 1 master hash
       ↓
       Result: 32-character unique ID
       
If you ever have the EXACT same inputs again:
       ↓
       You get the EXACT same 32-char ID
       ↓
       System recognizes it → CACHE HIT
```

No two different data/weight combinations produce the same hash (1 in 10^77 chance of collision).

---

## Tips for Best Results

1. **During exploratory analysis:** 
   - Run once with data
   - Adjust weights incrementally, let each run complete
   - Check results between each adjustment
   - Use cache hits to speed up iteration

2. **When comparing results:**
   - Run with weights A → see results A
   - Change to weights B → run (fresh run, takes time)
   - To compare: adjust back to weights A → instant cache hit with results A
   - No need to re-run A (system remembers)

3. **Multiple analysts:**
   - Each person's weight adjustments are independent
   - Cache hits only apply to YOUR same setting

4. **Troubleshooting:**
   - If results seem stale, check the orange cache-miss banner
   - It tells you exactly what changed since last run
   - If you didn't intend the change, adjust back

---

## Performance Impact

### Best Case (Cache Hit)
```
Total Time: 200-500ms
├─ Fingerprint computation: 50ms
├─ Database load: 150-300ms
└─ UI render: 50-100ms
```

### Worst Case (Fresh Run)
```
Total Time: 30-60s
├─ Data cleansing: 5-10s
├─ Graph construction: 8-12s
├─ 10-family scoring: 10-15s
├─ Analytics: 5-8s
├─ Report generation: 2-3s
└─ Database save: 1-2s
```

**Speedup:** 60-120× faster on cache hit! ⚡

---

## What Happens When...

| Scenario | What You Do | System Behavior | Time |
|----------|-----------|-----------------|------|
| New session | Upload data, Run | Fresh run | 45s |
| Test run | Run again | Cache hit ✅ | 0.3s |
| Adjust weight | Slide → Run | Fresh run | 45s |
| Adjust again | Slide → Run | Fresh run | 45s |
| Revert weight | Slide back → Run | Cache hit ✅ | 0.3s |
| Add 1 row | Edit table → Run | Fresh run | 45s |
| Run baseline | Run no changes | Cache hit ✅ | 0.3s |

---

## Version Info

- **v16.73.0** — Smart 4-layer cache (this version)
- **v16.72.0** — Earlier version without smart cache
- Update available? System will show "App version changed → fresh run" on next update

---

## Need Help?

- **Cache not working?** Check orange banner for what changed
- **Results seem stale?** Look at Run ID in status — if it's old, refresh or make a change
- **Server restarted?** First pipeline run might be slow (re-populating memory from DB), subsequent same-data runs will be instant
- **Want instant results always?** Don't change inputs! (Use cache hits as-is)

---

## Summary

✅ **Same data, weights, settings** → Instant results (cache hit)  
⚠️ **Anything changed** → Fresh run with orange badge showing what changed  
🔄 **Even after server restart** → Cache still works (stored in database)  
⚡ **Speed gain** → 60-120× faster on cache hits

**That's it!** The system works invisibly. Just run your analysis, adjust weights as needed, and watch the cache kicks in when appropriate. 🚀
