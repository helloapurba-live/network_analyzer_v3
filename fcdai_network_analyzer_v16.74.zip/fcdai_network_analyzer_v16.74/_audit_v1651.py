"""
v16.53 End-to-End Audit Script
Checks: syntax, imports, cross-module links, duplicate functions, config sync,
        API route registration, DB method existence, version consistency.
Run: python _audit_v1651.py  (from inside fcdai_network_analyzer_v16.51/)
"""
import py_compile, sys, os, re, ast, importlib, traceback
from pathlib import Path

BASE = Path(__file__).parent
sys.path.insert(0, str(BASE))

PASS = "\033[92m  PASS\033[0m"
FAIL = "\033[91m  FAIL\033[0m"
WARN = "\033[93m  WARN\033[0m"
issues = []

def ok(msg):    print(f"{PASS}  {msg}")
def fail(msg):  print(f"{FAIL}  {msg}"); issues.append(msg)
def warn(msg):  print(f"{WARN}  {msg}"); issues.append("WARN: " + msg)

# ── 1. SYNTAX CHECK ───────────────────────────────────────────────────────────
print("\n=== 1. Syntax Check ===")
SYNTAX_FILES = [
    "app.py", "engine.py", "database.py", "config.py",
    "api/__init__.py", "api/auth.py", "api/main.py", "api/models.py",
    "api/routes/__init__.py", "api/routes/pipeline.py",
    "api/routes/results.py", "api/routes/reports.py",
    "utils/__init__.py", "utils/logger.py", "utils/audit_chain.py",
    "utils/pii_guard.py", "utils/cache_manager.py",
    "fcdai/__init__.py", "fcdai/sdk.py", "fcdai/cli.py",
    "layers/__init__.py",
    "layers/l0_ingest.py", "layers/l1_validate.py", "layers/l2_aggregate.py",
    "layers/l3_graph.py", "layers/l5_analytics.py",
    "layers/l6_scoring.py", "layers/l7_reporting.py",
]
for rel in SYNTAX_FILES:
    fp = BASE / rel
    if not fp.exists():
        warn(f"Missing file: {rel}")
        continue
    try:
        py_compile.compile(str(fp), doraise=True)
        ok(rel)
    except py_compile.PyCompileError as e:
        fail(f"Syntax error: {rel} — {e}")

# ── 2. DUPLICATE FUNCTION DETECTOR ────────────────────────────────────────────
print("\n=== 2. Duplicate Function Check ===")
CHECK_DUP = [
    "api/routes/results.py", "api/routes/reports.py",
    "api/routes/pipeline.py", "app.py", "database.py",
]
for rel in CHECK_DUP:
    fp = BASE / rel
    if not fp.exists(): continue
    src = fp.read_text(encoding="utf-8")
    try:
        tree = ast.parse(src)
    except SyntaxError:
        continue
    names = [n.name for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
    dups = [n for n in set(names) if names.count(n) > 1]
    if dups:
        fail(f"Duplicate functions in {rel}: {dups}")
    else:
        ok(f"No duplicates: {rel}")

# ── 3. VERSION CONSISTENCY ─────────────────────────────────────────────────────
print("\n=== 3. Version String Consistency ===")
TARGET_VER = "16.56.0"
VERSION_FILES = {
    "app.py":              r'__version__\s*=\s*["\']([^"\']+)',
    "engine.py":           r'__version__\s*=\s*["\']([^"\']+)',
    "__about__.py":        r'__version__\s*=\s*["\']([^"\']+)',
    "pyproject.toml":      r'(?m)^version\s*=\s*["\']([^"\']+)',  # [project] version only
    "fcdai/__init__.py":   r'__version__\s*=\s*["\']([^"\']+)',
    "fcdai/cli.py":        r'version_option\(version=["\']([^"\']+)',
    "fcdai/sdk.py":        r'"version":\s*["\']([^"\']+)',
    "config.yaml":         r'version:\s*["\']?([^\s"\'#\n]+)',
}
for rel, pattern in VERSION_FILES.items():
    fp = BASE / rel
    if not fp.exists():
        warn(f"Missing: {rel}")
        continue
    src = fp.read_text(encoding="utf-8")
    found = re.findall(pattern, src)
    stale = [v for v in found if v and not v.startswith(TARGET_VER[:5])]
    if stale:
        fail(f"Stale version in {rel}: {stale}")
    else:
        ok(f"Version OK: {rel}")

# ── 4. API ROUTE REGISTRATION ─────────────────────────────────────────────────
print("\n=== 4. API Route Registration in main.py ===")
main_src = (BASE / "api/main.py").read_text(encoding="utf-8")
EXPECTED_ROUTERS = ["pipeline_router", "results_router", "reports_router"]
for r in EXPECTED_ROUTERS:
    if r in main_src:
        ok(f"Router included: {r}")
    else:
        fail(f"Router NOT included in main.py: {r}")

# Check require_api_key wired to all routers
if "require_api_key" in main_src:
    ok("require_api_key dependency present in main.py")
else:
    fail("require_api_key NOT wired in main.py")

# Check CORS not wildcard
if 'allow_origins=["*"]' in main_src or "allow_origins=['*']" in main_src:
    fail("Wildcard CORS allow_origins detected in main.py")
else:
    ok("CORS allow_origins not wildcard")

# ── 5. AUTH MODULE LINKS ──────────────────────────────────────────────────────
print("\n=== 5. Auth Module Links ===")
auth_src = (BASE / "api/auth.py").read_text(encoding="utf-8")
if "FCDAI_API_KEY" in auth_src:
    ok("FCDAI_API_KEY env var checked in api/auth.py")
else:
    fail("FCDAI_API_KEY NOT in api/auth.py")
if "require_api_key" in auth_src:
    ok("require_api_key function defined in api/auth.py")
else:
    fail("require_api_key NOT defined in api/auth.py")
if "api/auth" in main_src or "from api.auth" in main_src or "from .auth" in main_src:
    ok("api/auth imported in api/main.py")
else:
    fail("api/auth NOT imported in api/main.py")

# ── 6. DATABASE METHOD LINKS ──────────────────────────────────────────────────
print("\n=== 6. Database Method Links ===")
db_src = (BASE / "database.py").read_text(encoding="utf-8")
REQUIRED_DB_METHODS = [
    "log_audit_event", "get_staging_log", "save_run", "load_latest_run",
    "get_db",
]
for m in REQUIRED_DB_METHODS:
    if f"def {m}" in db_src or f"def get_db" in db_src:
        ok(f"DB method present: {m}")
    else:
        fail(f"DB method MISSING: {m}")

# Check audit callers
for route_file in ["api/routes/pipeline.py", "api/routes/results.py", "api/routes/reports.py"]:
    fp = BASE / route_file
    if not fp.exists(): continue
    src = fp.read_text(encoding="utf-8")
    if "log_audit_event" in src:
        ok(f"log_audit_event called in {route_file}")
    else:
        fail(f"log_audit_event NOT called in {route_file}")

# ── 7. DASH LOGIN GUARD LINKS ─────────────────────────────────────────────────
print("\n=== 7. Dash Login / Session Guard ===")
app_src = (BASE / "app.py").read_text(encoding="utf-8")
checks = {
    "before_request guard": "before_request",
    "/login route":          "route(\"/login\"",
    "/logout route":         "route(\"/logout\"",
    "_load_users_config()":  "_load_users_config",
    "secrets.compare_digest":"compare_digest",
    "Flask secret_key":      "secret_key",
    "session import":        "from flask import",
}
for label, token in checks.items():
    if token in app_src:
        ok(f"{label} present in app.py")
    else:
        fail(f"{label} MISSING in app.py")

# ── 8. LOGGER ROTATION CHECK ──────────────────────────────────────────────────
print("\n=== 8. Rotating Logger ===")
logger_src = (BASE / "utils/logger.py").read_text(encoding="utf-8")
if "TimedRotatingFileHandler" in logger_src:
    ok("TimedRotatingFileHandler in utils/logger.py")
else:
    fail("TimedRotatingFileHandler MISSING in utils/logger.py")
if "backupCount" in logger_src:
    ok("backupCount (retention) set in logger")
else:
    fail("backupCount MISSING in logger")

# ── 9. CSV INJECTION GUARD ────────────────────────────────────────────────────
print("\n=== 9. CSV Injection Guard ===")
rep_src = (BASE / "api/routes/reports.py").read_text(encoding="utf-8")
if "_sanitise_cell" in rep_src and "_sanitise_csv_df" in rep_src:
    ok("CSV sanitiser functions present in reports.py")
else:
    fail("CSV sanitiser MISSING in reports.py")
if "_sanitise_csv_df" in rep_src and "to_csv" in rep_src:
    # Check sanitiser is called BEFORE to_csv
    idx_san = rep_src.find("_sanitise_csv_df")
    idx_csv = rep_src.find("to_csv")
    if idx_san < idx_csv:
        ok("_sanitise_csv_df called BEFORE to_csv")
    else:
        fail("_sanitise_csv_df NOT called before to_csv")
else:
    fail("to_csv or sanitiser missing in reports.py")

# ── 10. IDEMPOTENCY CACHE ─────────────────────────────────────────────────────
print("\n=== 10. Idempotency Cache ===")
pipe_src = (BASE / "api/routes/pipeline.py").read_text(encoding="utf-8")
if "_idempotency_cache" in pipe_src:
    ok("Idempotency cache dict in pipeline.py")
else:
    fail("Idempotency cache MISSING in pipeline.py")
if "_IDEMPOTENCY_TTL_SEC" in pipe_src or "TTL" in pipe_src:
    ok("TTL constant present")
else:
    fail("TTL constant MISSING in pipeline.py")

# ── 11. CONFIG YAML HEALTH ────────────────────────────────────────────────────
print("\n=== 11. Config YAML Health ===")
import yaml  # type: ignore
cfg_path = BASE / "config.yaml"
try:
    cfg = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
    ok("config.yaml parses without error")
    for key in ["app", "auth", "paths", "theme"]:
        if key in cfg:
            ok(f"config.yaml has '{key}' section")
        else:
            fail(f"config.yaml MISSING '{key}' section")
    # Port check
    port = cfg.get("app", {}).get("port", None)
    if str(port) == "8166":
        ok(f"Dash port = {port}")
    else:
        warn(f"Dash port = {port} (expected 8166)")
    auth = cfg.get("auth", {})
    # v16.53: multi-user list format
    users_list = auth.get("users", [])
    if users_list and len(users_list) >= 1:
        ok(f"auth.users list present ({len(users_list)} users: {[u.get('username') for u in users_list]})")
    elif auth.get("username") and auth.get("password"):
        ok("auth.username + auth.password set in config.yaml (legacy single-user)")
    else:
        fail("auth credentials missing in config.yaml")
except Exception as e:
    fail(f"config.yaml parse error: {e}")

# ── 12. REQUIREMENTS.LOCK EXISTS ─────────────────────────────────────────────
print("\n=== 12. Requirements Lock ===")
lock = BASE / "requirements.lock"
if lock.exists() and lock.stat().st_size > 500:
    lines = lock.read_text(encoding="utf-8").splitlines()
    ok(f"requirements.lock present ({len(lines)} packages)")
else:
    fail("requirements.lock missing or empty")

# ── 13. LOGS DIRECTORY ───────────────────────────────────────────────────────
print("\n=== 13. Logs Directory ===")
logs_dir = BASE / "logs"
if logs_dir.exists():
    ok("logs/ directory exists")
else:
    warn("logs/ directory absent — will be auto-created on first run")
    logs_dir.mkdir(exist_ok=True)
    ok("logs/ directory created now")

# ── 14. V16.53 RISK TABLES MODULE ────────────────────────────────────────────
print("\n=== 14. v16.53 Risk Tables Module ===")
rt_module = BASE / "pages" / "_dashboard_risk_tables.py"
if rt_module.exists():
    src = rt_module.read_text(encoding="utf-8")
    ok("pages/_dashboard_risk_tables.py exists")
    for fn in ("build_risk_tables_section", "_build_table1", "_build_table2",
               "_build_table3", "_build_table4", "_enrich_scored", "_family_keys"):
        if f"def {fn}" in src:
            ok(f"  function {fn} present")
        else:
            fail(f"  function {fn} MISSING in _dashboard_risk_tables.py")
else:
    fail("pages/_dashboard_risk_tables.py not found")

dash_src_path = BASE / "pages" / "dashboard.py"
if dash_src_path.exists():
    dash_src = dash_src_path.read_text(encoding="utf-8")
    checks = [
        ("from pages._dashboard_risk_tables import build_risk_tables_section", "import of build_risk_tables_section"),
        ("id=\"dash-risk-tables-section\"", "placeholder div id=dash-risk-tables-section"),
        ("def cb_risk_tables", "cb_risk_tables callback function"),
        ("Output(\"dash-risk-tables-section\", \"children\")", "Output wired to placeholder div"),
    ]
    for needle, label in checks:
        if needle in dash_src:
            ok(f"  dashboard.py: {label}")
        else:
            fail(f"  dashboard.py MISSING: {label}")
else:
    fail("pages/dashboard.py not found")

# ── 15. SUMMARY ──────────────────────────────────────────────────────────────
print("\n" + "="*60)
real_fails = [i for i in issues if not i.startswith("WARN")]
warns       = [i for i in issues if i.startswith("WARN")]
print(f"  FAILURES : {len(real_fails)}")
print(f"  WARNINGS : {len(warns)}")
if real_fails:
    print("\nFAILURES:")
    for f in real_fails: print(f"  - {f}")
if warns:
    print("\nWARNINGS:")
    for w in warns: print(f"  - {w}")
if not real_fails:
    print("\n  ALL CHECKS PASSED — v16.53 is clean and ready to start.\n")
else:
    print("\n  FIX THE ABOVE BEFORE STARTING SERVER.\n")
