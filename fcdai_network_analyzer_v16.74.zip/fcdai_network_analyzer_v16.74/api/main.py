"""
api.main — FCDAI FastAPI Application
=====================================
Full REST API for the FCDAI Network Analyzer.

Start:
    python -m api.main           (from v16.51 directory)
    fcdai api --port 8101        (via CLI)
    uvicorn api.main:app --host 127.0.0.1 --port 8101

Interactive docs (admin only — no API key needed):
    http://127.0.0.1:8101/admin/api-docs    (Swagger UI)
    http://127.0.0.1:8101/admin/redoc       (ReDoc)

Air-gapped: binds to 127.0.0.1 by default. No external calls.
PII: node_id fields are opaque strings — never logged or traced.

v16.51 Security:
  #1a  X-API-Key header required on all routes except /health
  #7   /docs and /redoc disabled publicly; served at /admin/* (key req'd)
  #10  CORS allow_headers explicit list (no *)
  #12  Generic error responses (no raw exceptions exposed to callers)
  #16  Rotating audit/debug logs via utils.logger
"""

from __future__ import annotations

import sys
import time
import logging
import uuid
from pathlib import Path

# Ensure package root on path
_PKG_ROOT = Path(__file__).parent.parent.resolve()
if str(_PKG_ROOT) not in sys.path:
    sys.path.insert(0, str(_PKG_ROOT))

# v16.51 #16: Activate rotating file logging early
try:
    from utils.logger import audit_logger, debug_logger  # noqa: F401 — side-effect: sets up handlers
    _logger = logging.getLogger("fcdai.api.main")
except Exception:
    _logger = logging.getLogger("fcdai.api.main")

from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, HTMLResponse
from fastapi.openapi.docs import get_swagger_ui_html, get_redoc_html

from api.routes.pipeline import router as pipeline_router
from api.routes.results import router as results_router
from api.routes.reports import router as reports_router
from api.models import HealthResponse
from api.auth import require_api_key  # v16.51 #1a

# Load version + ports from config (single source of truth)
try:
    from config import APP as _APP  # type: ignore
    _VERSION = _APP.version
    _DASH_PORT = _APP.port
    _API_PORT = _APP.port + 1  # API always Dash+1
except Exception:
    _VERSION = "16.56.0"
    _DASH_PORT = 8169
    _API_PORT = 8170

# ---------------------------------------------------------------------------
# App startup time (for uptime calculation)
# ---------------------------------------------------------------------------
_START_TIME = time.time()

# ---------------------------------------------------------------------------
# FastAPI app
# v16.51 #7: docs_url / redoc_url disabled — served at secret /admin/* paths
# ---------------------------------------------------------------------------
app = FastAPI(
    title="FCDAI Network Analyzer — REST API",
    description=(
        "Unsupervised AML graph analytics REST API.\n\n"
        "**Air-gapped** | **Zero PII leakage** | **Bank-grade** | **Offline-only**\n\n"
        "Trigger pipeline runs, stream progress, query scored results, export SAR narratives.\n\n"
        "**All endpoints require `X-API-Key` header** (except `/health`)."
    ),
    version=_VERSION,
    license_info={"name": "MIT", "identifier": "MIT"},
    contact={"name": "FCDAI AML Data Science Team"},
    openapi_tags=[
        {"name": "health", "description": "System health and version info"},
        {"name": "pipeline", "description": "Trigger and monitor pipeline runs"},
        {"name": "results", "description": "Query scored account results"},
        {"name": "reports", "description": "Generate and export reports"},
    ],
    # v16.51 #7: Disable public /docs and /redoc
    docs_url=None,
    redoc_url=None,
)

# ---------------------------------------------------------------------------
# CORS — localhost only (air-gapped)
# v16.51 #10: Explicit allow_headers — no wildcard
# ---------------------------------------------------------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        f"http://127.0.0.1:{_DASH_PORT}",
        f"http://localhost:{_DASH_PORT}",   # Dash UI
        f"http://127.0.0.1:{_API_PORT}",
        f"http://localhost:{_API_PORT}",    # FastAPI self
    ],
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    # v16.51 #10: Explicit headers instead of "*"
    allow_headers=["Content-Type", "X-API-Key", "Authorization", "Accept"],
)

# ---------------------------------------------------------------------------
# Route registration
# v16.51 #1a: All routes protected by require_api_key dependency
# ---------------------------------------------------------------------------
app.include_router(
    pipeline_router,
    prefix="/api/v1/pipeline",
    tags=["pipeline"],
    dependencies=[Depends(require_api_key)],
)
app.include_router(
    results_router,
    prefix="/api/v1/results",
    tags=["results"],
    dependencies=[Depends(require_api_key)],
)
app.include_router(
    reports_router,
    prefix="/api/v1/reports",
    tags=["reports"],
    dependencies=[Depends(require_api_key)],
)


# ---------------------------------------------------------------------------
# Health endpoint — intentionally unauthenticated (monitoring / liveness)
# ---------------------------------------------------------------------------
@app.get(
    "/health",
    response_model=HealthResponse,
    tags=["health"],
    summary="System health check",
    description="Returns API status, version, port configuration, and DB connectivity. No auth required.",
)
async def health():
    """
    Health check endpoint.
    Safe to call frequently — no DB write, O(1) response.
    Deliberately excluded from API key requirement (monitoring use).
    """
    db_ok = False
    try:
        from database import get_db  # type: ignore

        db = get_db()
        db._conn.execute("SELECT 1").fetchone()
        db_ok = True
    except Exception:
        pass

    return HealthResponse(
        status="ok",
        version=_VERSION,
        dash_port=_DASH_PORT,
        api_port=_API_PORT,
        uptime_seconds=round(time.time() - _START_TIME, 1),
        db_connected=db_ok,
    )


# ---------------------------------------------------------------------------
# v16.52 #U2: Admin-only Swagger UI at secret path
# No API key required for docs pages — admin is already authenticated via Dash
# session. Data endpoints (/pipeline/*, /results/*, /reports/*) still require
# X-API-Key. Docs are served only on loopback (127.0.0.1), air-gapped.
# ---------------------------------------------------------------------------
@app.get("/admin/api-docs", include_in_schema=False)
async def admin_swagger():
    """Swagger UI — admin only (URL is secret; no API key required for docs)."""
    return get_swagger_ui_html(
        openapi_url="/openapi.json",
        title=f"FCDAI API v{_VERSION} — Admin Docs",
    )


@app.get("/admin/redoc", include_in_schema=False)
async def admin_redoc():
    """ReDoc — admin only (URL is secret; no API key required for docs)."""
    return get_redoc_html(
        openapi_url="/openapi.json",
        title=f"FCDAI API v{_VERSION} — Admin ReDoc",
    )


@app.get("/openapi.json", include_in_schema=False)
async def openapi_json():
    """OpenAPI schema JSON — served to admin docs pages (no key needed)."""
    return JSONResponse(app.openapi())


# ---------------------------------------------------------------------------
# Root
# ---------------------------------------------------------------------------
@app.get("/", include_in_schema=False)
async def root():
    return JSONResponse(
        {
            "message": f"FCDAI Network Analyzer API v{_VERSION}",
            "admin_docs": "/admin/api-docs (no API key — admin access via known URL)",
            "health": "/health",
            "endpoints": {
                "pipeline": "/api/v1/pipeline",
                "results": "/api/v1/results",
                "reports": "/api/v1/reports",
            },
        }
    )


# ---------------------------------------------------------------------------
# Dev entry point
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "api.main:app",
        host="127.0.0.1",
        port=_API_PORT,
        reload=False,
        log_level="info",
    )
