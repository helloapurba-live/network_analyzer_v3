"""
api.routes.results — Scored results query endpoints
====================================================
GET /api/v1/results/latest       — All results, paginated
GET /api/v1/results/nodes        — Filtered by tier / role / min score
GET /api/v1/results/tiers        — Tier distribution (P1/P2/P3/P4 counts)
GET /api/v1/results/roles        — AML role distribution
GET /api/v1/results/escalations  — Accounts that escalated vs previous run
GET /api/v1/results/sar          — SAR narratives for P1+P2 accounts

All endpoints read from SQLite — no pipeline re-run required.
PII safety: node_id is returned as-is (opaque string). No additional PII fields.

v16.51:
  #2   Audit trail insert on every SAR narrative access (SAR_NARRATIVES_ACCESSED)
  #12  Generic error messages in public responses (ref + server-side log)
"""

from __future__ import annotations

import sys
import json
import logging
from pathlib import Path
from typing import List, Optional

import pandas as pd
from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import JSONResponse

_PKG_ROOT = Path(__file__).parent.parent.parent.resolve()
if str(_PKG_ROOT) not in sys.path:
    sys.path.insert(0, str(_PKG_ROOT))

from api.models import (
    NodeResult,
    PaginatedNodeResults,
    TierSummary,
    RoleSummary,
    EscalationResult,
    SARNarrative,
)

_logger = logging.getLogger("fcdai.api.results")

router = APIRouter()


# ---------------------------------------------------------------------------
# Helper: load latest scored results from SQLite
# ---------------------------------------------------------------------------
def _load_scored_df() -> pd.DataFrame:
    """
    Load the latest scored results from SQLite.
    Returns empty DataFrame if no results available yet.
    """
    try:
        from database import get_db  # type: ignore

        db = get_db()
        data = db.load_latest_run()
        if data and data.get("scored_df") is not None:
            return data["scored_df"].copy()
    except Exception:
        pass
    # Fallback: direct SQLite query
    try:
        import sqlite3

        conn = sqlite3.connect(str(_PKG_ROOT / "data" / "fcdai.db"), timeout=5)
        row = conn.execute("SELECT data FROM scored_results ORDER BY id DESC LIMIT 1").fetchone()
        conn.close()
        if row:
            return pd.DataFrame(json.loads(row[0]))
    except Exception:
        pass
    return pd.DataFrame()


def _df_to_node_results(df: pd.DataFrame) -> List[NodeResult]:
    """Convert DataFrame rows to NodeResult objects."""
    results = []
    for _, row in df.iterrows():
        try:
            results.append(
                NodeResult(
                    node_id=str(row.get("node_id", "")),
                    risk_score=float(row.get("risk_score", 0)),
                    risk_tier=str(row.get("risk_tier", "P4")),
                    aml_role=str(row.get("aml_role", "")) or None,
                    role_confidence=(
                        float(row["role_confidence"])
                        if "role_confidence" in row and pd.notna(row["role_confidence"])
                        else None
                    ),
                    sar_narrative=str(row.get("sar_narrative", "")) or None,
                    prev_tier=str(row.get("prev_tier", "")) or None,
                    tier_change=str(row.get("tier_change", "")) or None,
                    tier_escalated=(
                        int(row["tier_escalated"])
                        if "tier_escalated" in row and pd.notna(row["tier_escalated"])
                        else None
                    ),
                )
            )
        except Exception:
            continue
    return results


# ---------------------------------------------------------------------------
# GET /latest
# ---------------------------------------------------------------------------
@router.get(
    "/latest",
    response_model=PaginatedNodeResults,
    summary="Get latest scored results (paginated)",
    description=(
        "Returns all scored accounts from the most recent pipeline run, paginated.\n\n"
        "Sorted by risk_score descending (highest risk first)."
    ),
)
async def get_latest(
    page: int = Query(default=1, ge=1, description="Page number (1-based)"),
    limit: int = Query(default=100, ge=1, le=1000, description="Results per page"),
):
    df = _load_scored_df()
    if df.empty:
        raise HTTPException(
            status_code=404, detail="No pipeline results found. Run the pipeline first."
        )

    if "risk_score" in df.columns:
        df = df.sort_values("risk_score", ascending=False)

    total = len(df)
    start = (page - 1) * limit
    end = start + limit
    subset = df.iloc[start:end]

    return PaginatedNodeResults(
        total=total,
        page=page,
        limit=limit,
        results=_df_to_node_results(subset),
    )


# ---------------------------------------------------------------------------
# GET /nodes  (filtered query)
# ---------------------------------------------------------------------------
@router.get(
    "/nodes",
    response_model=List[NodeResult],
    summary="Query scored nodes with filters",
    description=(
        "Returns scored accounts filtered by tier, role, and/or minimum score.\n\n"
        "Useful for pulling P1 accounts, or all money mules, etc."
    ),
)
async def get_nodes(
    tier: Optional[str] = Query(default=None, description="Filter by tier: P1|P2|P3|P4"),
    role: Optional[str] = Query(
        default=None, description="Filter by role (partial match): MULE|BROKER|ORIGINATOR|SINK"
    ),
    min_score: Optional[float] = Query(
        default=None, ge=0, le=100, description="Minimum risk_score"
    ),
    limit: int = Query(default=500, ge=1, le=5000, description="Max results to return"),
):
    df = _load_scored_df()
    if df.empty:
        raise HTTPException(status_code=404, detail="No pipeline results found.")

    if tier and "risk_tier" in df.columns:
        df = df[df["risk_tier"] == tier.upper()]
    if role and "aml_role" in df.columns:
        df = df[df["aml_role"].str.contains(role.upper(), na=False)]
    if min_score is not None and "risk_score" in df.columns:
        df = df[df["risk_score"] >= min_score]

    if "risk_score" in df.columns:
        df = df.sort_values("risk_score", ascending=False)

    return _df_to_node_results(df.head(limit))


# ---------------------------------------------------------------------------
# GET /tiers
# ---------------------------------------------------------------------------
@router.get(
    "/tiers",
    response_model=List[TierSummary],
    summary="Tier distribution summary",
    description="Returns count and percentage of accounts in each risk tier (P1/P2/P3/P4).",
)
async def get_tiers():
    df = _load_scored_df()
    if df.empty:
        raise HTTPException(status_code=404, detail="No pipeline results found.")

    if "risk_tier" not in df.columns:
        raise HTTPException(status_code=422, detail="risk_tier column missing in results.")

    counts = df["risk_tier"].value_counts().reindex(["P1", "P2", "P3", "P4"], fill_value=0)
    total = counts.sum() or 1
    labels = {"P1": "Critical", "P2": "High", "P3": "Medium", "P4": "Low"}

    return [
        TierSummary(
            tier=t,
            label=labels.get(t, ""),
            count=int(counts.get(t, 0)),
            percentage=round(float(counts.get(t, 0)) / total * 100, 1),
        )
        for t in ["P1", "P2", "P3", "P4"]
    ]


# ---------------------------------------------------------------------------
# GET /roles
# ---------------------------------------------------------------------------
@router.get(
    "/roles",
    response_model=List[RoleSummary],
    summary="AML role distribution",
    description=(
        "Returns the count of each AML role identified in the current analysis.\n\n"
        "Roles: MULE | BROKER | ORIGINATOR | SINK | PERIPHERAL | MIXED"
    ),
)
async def get_roles():
    df = _load_scored_df()
    if df.empty:
        raise HTTPException(status_code=404, detail="No pipeline results found.")

    if "aml_role" not in df.columns:
        return []

    counts = df["aml_role"].value_counts()
    return [RoleSummary(role=r, count=int(c)) for r, c in counts.items()]


# ---------------------------------------------------------------------------
# GET /escalations
# ---------------------------------------------------------------------------
@router.get(
    "/escalations",
    response_model=List[EscalationResult],
    summary="Accounts escalated vs prior run",
    description=(
        "Returns accounts whose risk tier INCREASED since the previous pipeline run.\n\n"
        "P2→P1 escalation = most urgent alert. These accounts need immediate attention.\n"
        "Empty list = first run, or all accounts are stable/improved."
    ),
)
async def get_escalations():
    df = _load_scored_df()
    if df.empty:
        raise HTTPException(status_code=404, detail="No pipeline results found.")

    if "tier_escalated" not in df.columns:
        return []

    esc = df[df["tier_escalated"] == 1].copy()
    if "risk_score" in esc.columns:
        esc = esc.sort_values("risk_score", ascending=False)

    results = []
    for _, row in esc.iterrows():
        try:
            results.append(
                EscalationResult(
                    node_id=str(row.get("node_id", "")),
                    prev_tier=str(row.get("prev_tier", "??")),
                    current_tier=str(row.get("risk_tier", "??")),
                    tier_change=str(row.get("tier_change", "")),
                    risk_score=float(row.get("risk_score", 0)),
                    aml_role=str(row.get("aml_role", "")) or None,
                    sar_narrative=str(row.get("sar_narrative", "")) or None,
                )
            )
        except Exception:
            continue
    return results


# ---------------------------------------------------------------------------
# GET /sar
# ---------------------------------------------------------------------------
@router.get(
    "/sar",
    response_model=List[SARNarrative],
    summary="SAR narratives for flagged accounts",
    description=(
        "Returns SAR opening sentences for P1 and P2 accounts.\n\n"
        "The `sar_narrative` field contains a plain-English sentence "
        "ready to paste into a Suspicious Activity Report.\n\n"
        "Sorted by risk_score descending.\n\n"
        "**v16.51 #2** — every call is written to the audit_trail table."
    ),
)
async def get_sar(
    tiers: str = Query(default="P1,P2", description="Comma-separated tiers, e.g. P1,P2"),
    limit: int = Query(default=200, ge=1, le=2000, description="Max narratives to return"),
):
    df = _load_scored_df()
    if df.empty:
        raise HTTPException(status_code=404, detail="No pipeline results found.")

    tier_list = [t.strip().upper() for t in tiers.split(",") if t.strip()]
    if "risk_tier" in df.columns:
        df = df[df["risk_tier"].isin(tier_list)]

    if "sar_narrative" not in df.columns:
        raise HTTPException(
            status_code=422, detail="sar_narrative column not found. Run v16.1 pipeline."
        )

    if "risk_score" in df.columns:
        df = df.sort_values("risk_score", ascending=False)

    results = []
    for _, row in df.head(limit).iterrows():
        nar = str(row.get("sar_narrative", ""))
        if not nar:
            continue
        try:
            results.append(
                SARNarrative(
                    node_id=str(row.get("node_id", "")),
                    risk_tier=str(row.get("risk_tier", "P4")),
                    risk_score=float(row.get("risk_score", 0)),
                    aml_role=str(row.get("aml_role", "")) or None,
                    role_confidence=(
                        float(row["role_confidence"])
                        if "role_confidence" in row and pd.notna(row.get("role_confidence"))
                        else None
                    ),
                    sar_narrative=nar,
                    tier_change=str(row.get("tier_change", "")) or None,
                )
            )
        except Exception:
            continue

    # v16.51 #2: Audit trail — record every SAR access
    try:
        import os
        from database import get_db  # type: ignore
        user = _get_request_user()
        db = get_db()
        db.log_audit_event(
            action="SAR_NARRATIVES_ACCESSED",
            details=f"tiers={tiers} count={len(results)} limit={limit}",
            user=user,
            severity="INFO",
        )
    except Exception as _ae:
        _logger.warning("Audit trail write failed (non-fatal): %s", _ae)

    return results


def _get_request_user() -> str:
    """Best-effort: return OS username as audit actor."""
    import os
    try:
        return os.getlogin()
    except Exception:
        return os.environ.get("USERNAME", os.environ.get("USER", "SYSTEM"))



