"""
api.routes.reports — Report generation and export endpoints
============================================================
GET /api/v1/reports/summary          — Executive summary (JSON)
GET /api/v1/reports/export           — Full results export (CSV or JSON download)

v16.51:
  #2   Audit trail insert on every export (RESULTS_EXPORTED)
  #12  Generic error messages in public responses (ref + server-side log)
  #15  CSV formula-injection sanitisation (=, +, -, @ prefix → ')
"""

from __future__ import annotations

import sys
import io
import json
import logging
import uuid
from pathlib import Path
from typing import Optional

import pandas as pd
from fastapi import APIRouter, Query
from fastapi.responses import StreamingResponse, JSONResponse

_PKG_ROOT = Path(__file__).parent.parent.parent.resolve()
if str(_PKG_ROOT) not in sys.path:
    sys.path.insert(0, str(_PKG_ROOT))

from api.models import ExecutiveSummary, TierSummary, RoleSummary

_logger = logging.getLogger("fcdai.api.reports")

router = APIRouter()


def _load_scored_df() -> pd.DataFrame:
    """Load latest scored results (shared helper)."""
    try:
        from database import get_db  # type: ignore

        db = get_db()
        data = db.load_latest_run()
        if data and data.get("scored_df") is not None:
            return data["scored_df"].copy()
    except Exception:
        pass
    try:
        import sqlite3

        conn = sqlite3.connect(str(_PKG_ROOT / "data" / "fcdai.db"), timeout=5)
        row = conn.execute("SELECT data FROM scored_results ORDER BY id DESC LIMIT 1").fetchone()
        conn.close()
        if row:
            return pd.DataFrame(json.loads(row[0]))
    except Exception:
        pass
    return pd.DataFrame()


# ---------------------------------------------------------------------------
# v16.51 #15: CSV formula injection sanitisation
# Prefixes cells whose first character is =, +, -, @ with a single-quote
# so Excel/LibreOffice does not interpret them as formulas.
# Applied to ALL string columns before CSV serialisation.
# ---------------------------------------------------------------------------
_FORMULA_CHARS = ("=", "+", "-", "@", "\t", "\r")


def _sanitise_cell(val: str) -> str:
    """Prefix dangerous leading chars so spreadsheet software won't execute them."""
    if isinstance(val, str) and val and val[0] in _FORMULA_CHARS:
        return "'" + val
    return val


def _sanitise_csv_df(df: pd.DataFrame) -> pd.DataFrame:
    """Apply formula injection guard to all object/string columns."""
    df = df.copy()
    for col in df.select_dtypes(include=["object"]).columns:
        df[col] = df[col].apply(_sanitise_cell)
    return df


def _get_export_user() -> str:
    """Best-effort: return OS username as audit actor."""
    import os
    try:
        return os.getlogin()
    except Exception:
        return os.environ.get("USERNAME", os.environ.get("USER", "SYSTEM"))


# ---------------------------------------------------------------------------
# GET /summary
# ---------------------------------------------------------------------------
@router.get(
    "/summary",
    response_model=ExecutiveSummary,
    summary="Executive summary report",
    description=(
        "Returns a business-ready executive summary of the current risk landscape.\n\n"
        "Includes tier breakdown, role distribution, and run metadata.\n"
        "Designed for presentation to senior compliance and business stakeholders."
    ),
)
async def get_summary():
    df = _load_scored_df()
    if df.empty:
        return JSONResponse(
            status_code=404,
            content={"error": "No pipeline results available. Run the pipeline first."},
        )

    # Tier counts
    tier_labels = {"P1": "Critical", "P2": "High", "P3": "Medium", "P4": "Low"}
    tier_counts = {}
    tier_breakdown = []
    if "risk_tier" in df.columns:
        counts = df["risk_tier"].value_counts().reindex(["P1", "P2", "P3", "P4"], fill_value=0)
        total = counts.sum() or 1
        for t in ["P1", "P2", "P3", "P4"]:
            c = int(counts.get(t, 0))
            tier_counts[t] = c
            tier_breakdown.append(
                TierSummary(
                    tier=t,
                    label=tier_labels[t],
                    count=c,
                    percentage=round(c / total * 100, 1),
                )
            )

    # Role breakdown
    role_breakdown = []
    if "aml_role" in df.columns:
        role_counts = df["aml_role"].value_counts()
        role_breakdown = [RoleSummary(role=r, count=int(c)) for r, c in role_counts.items()]

    # Escalations
    escalated_count = 0
    if "tier_escalated" in df.columns:
        escalated_count = int(df["tier_escalated"].sum())

    # Run metadata (from DB)
    run_meta = {}
    try:
        from database import get_db  # type: ignore

        db = get_db()
        data = db.load_latest_run()
        if data and data.get("run_info"):
            ri = data["run_info"]
            run_meta = {
                "run_id": ri.get("run_id"),
                "started_at": ri.get("started_at"),
                "finished_at": ri.get("finished_at"),
                "duration_sec": ri.get("duration_sec"),
                "nodes": ri.get("nodes", 0),
                "edges": ri.get("edges", 0),
            }
    except Exception:
        pass

    return ExecutiveSummary(
        total_accounts=len(df),
        critical_p1=tier_counts.get("P1", 0),
        high_p2=tier_counts.get("P2", 0),
        medium_p3=tier_counts.get("P3", 0),
        low_p4=tier_counts.get("P4", 0),
        escalated_count=escalated_count,
        tier_breakdown=tier_breakdown,
        role_breakdown=role_breakdown,
        run_meta=run_meta,
        pipeline_version="16.1.0",
    )


# ---------------------------------------------------------------------------
# GET /export
# ---------------------------------------------------------------------------
@router.get(
    "/export",
    summary="Export full results (CSV or JSON download)",
    description=(
        "Downloads the complete scored results as a file attachment.\n\n"
        "- `format=csv`  → Excel-compatible CSV, all columns\n"
        "- `format=json` → JSON array of records\n\n"
        "Use `tiers=P1,P2` to export only high-risk accounts.\n"
        "**The file download contains node_id and risk data — handle as PII.**\n\n"
        "**v16.51 #2** — every export is written to the audit_trail table.\n"
        "**v16.51 #15** — CSV cells starting with =, +, -, @ are prefixed with ' "
        "to prevent spreadsheet formula injection."
    ),
)
async def export_results(
    format: str = Query(default="csv", description="csv | json"),
    tiers: Optional[str] = Query(
        default=None, description="Comma-separated tiers to export, e.g. P1,P2. Default=all."
    ),
    cols: Optional[str] = Query(
        default=None, description="Comma-separated columns to include. Default=all AML columns."
    ),
):
    df = _load_scored_df()
    if df.empty:
        return JSONResponse(
            status_code=404, content={"error": "No results available. Run the pipeline first."}
        )

    # Filter by tier
    if tiers:
        tier_list = [t.strip().upper() for t in tiers.split(",")]
        if "risk_tier" in df.columns:
            df = df[df["risk_tier"].isin(tier_list)]

    # Column selection (default: AML-relevant columns only)
    _default_cols = [
        "node_id",
        "risk_score",
        "risk_tier",
        "aml_role",
        "role_confidence",
        "sar_narrative",
        "prev_tier",
        "tier_change",
        "tier_escalated",
        "betweenness_centrality",
        "in_degree",
        "out_degree",
        "passthrough_ratio",
        "louvain_community_stable",
        "louvain_stability",
        "ring_confidence",
    ]
    if cols:
        col_list = [c.strip() for c in cols.split(",")]
    else:
        col_list = [c for c in _default_cols if c in df.columns]

    df_export = df[col_list] if col_list else df

    # Sort by risk descending
    if "risk_score" in df_export.columns:
        df_export = df_export.sort_values("risk_score", ascending=False)

    # Build file response
    if format.lower() == "json":
        content = df_export.to_json(orient="records", indent=2, default_handler=str)
        media_type = "application/json"
        filename = "fcdai_results.json"
    else:
        # v16.51 #15: Sanitise CSV cells against formula injection
        df_safe = _sanitise_csv_df(df_export)
        buf = io.StringIO()
        df_safe.to_csv(buf, index=False)
        content = buf.getvalue()
        media_type = "text/csv"
        filename = "fcdai_results.csv"

    row_count = len(df_export)
    col_count = len(df_export.columns)

    # v16.51 #2: Audit trail — record every export
    try:
        user = _get_export_user()
        from database import get_db  # type: ignore
        db = get_db()
        db.log_audit_event(
            action="RESULTS_EXPORTED",
            details=(
                f"format={format} tiers={tiers or 'all'} "
                f"rows={row_count} cols={col_count} file={filename}"
            ),
            user=user,
            severity="INFO",
        )
    except Exception as _ae:
        _logger.warning("Audit trail write failed (non-fatal): %s", _ae)

    _logger.info(
        "Export: user=%s format=%s rows=%d tiers=%s", _get_export_user(), format, row_count, tiers
    )

    return StreamingResponse(
        io.BytesIO(content.encode("utf-8")),
        media_type=media_type,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )

