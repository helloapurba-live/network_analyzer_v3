"""
api.routes.pipeline — Pipeline trigger and monitoring endpoints
===============================================================
POST /api/v1/pipeline/run     — Trigger a pipeline run (background task)
GET  /api/v1/pipeline/status  — Current run progress
GET  /api/v1/pipeline/stream  — SSE stream of live progress
GET  /api/v1/pipeline/runs    — History of all completed runs

v16.51:
  #14  Idempotency on POST /run — 60-s dedup by optional request_id field
  #2   Audit trail insert on every pipeline trigger (PIPELINE_TRIGGERED)
  #12  Generic error messages in public responses (ref ID + server-side log)
"""

from __future__ import annotations

import sys
import json
import asyncio
import logging
import threading
import time
import uuid
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, BackgroundTasks, HTTPException
from fastapi.responses import StreamingResponse, JSONResponse

_PKG_ROOT = Path(__file__).parent.parent.parent.resolve()
if str(_PKG_ROOT) not in sys.path:
    sys.path.insert(0, str(_PKG_ROOT))

from api.models import PipelineRunRequest, PipelineRunResponse, PipelineStatusResponse

_logger = logging.getLogger("fcdai.api.pipeline")

router = APIRouter()

# ---------------------------------------------------------------------------
# Shared pipeline state (single-process, thread-safe for Windows local CPU)
# ---------------------------------------------------------------------------
_pipeline_state: dict = {
    "run_id": None,
    "status": "idle",  # idle | running | complete | error
    "progress": 0,
    "stage": "idle",
    "message": "No run started yet",
    "started_at": None,
    "duration_sec": None,
    "error": None,
}
_state_lock = threading.Lock()
_engine_instance = None

# ---------------------------------------------------------------------------
# v16.51 #14: Idempotency cache — {request_id: (run_id, timestamp)}
# ---------------------------------------------------------------------------
_idempotency_cache: dict[str, tuple[str, float]] = {}
_IDEMPOTENCY_TTL_SEC = 60  # deduplicate within 60 seconds


def _get_engine():
    """Return the FCDAIPipeline singleton (robust warm-start from DB)."""
    global _engine_instance
    if _engine_instance is None:
        from engine import get_pipeline  # type: ignore

        _engine_instance = get_pipeline()  # singleton — shared with Dash process
        _engine_instance.load_last_run()   # warm-start from DB if prior run exists
    return _engine_instance


def _update_state(**kwargs):
    with _state_lock:
        _pipeline_state.update(kwargs)


def _run_pipeline_background(request: PipelineRunRequest, run_id: str):
    """Blocking pipeline run executed in a background thread."""
    _update_state(
        run_id=run_id,
        status="running",
        progress=0,
        stage="starting",
        message="Pipeline initialising...",
        started_at=time.strftime("%Y-%m-%dT%H:%M:%S"),
        duration_sec=None,
        error=None,
    )
    t0 = time.time()
    try:
        engine = _get_engine()

        # Patch progress hook to update state
        original_pct = engine.progress.get_status

        def _patched_status():
            info = original_pct()
            _update_state(
                progress=int(info.get("overall_pct", 0)),
                stage=info.get("stage", ""),
                message=info.get("message", ""),
            )
            return info

        engine.progress.get_status = _patched_status

        result = engine.run(
            max_customers=request.max_nodes,
            parallel=request.parallel,
            resume=request.resume,
        )

        duration = round(time.time() - t0, 1)
        n_accounts = len(engine.scored_df) if engine.scored_df is not None else 0
        tiers = {}
        if engine.scored_df is not None and "risk_tier" in engine.scored_df.columns:
            tiers = engine.scored_df["risk_tier"].value_counts().to_dict()

        _update_state(
            status="complete",
            progress=100,
            stage="complete",
            message=(
                f"Pipeline complete — {n_accounts} accounts scored | "
                f"P1:{tiers.get('P1',0)} P2:{tiers.get('P2',0)} "
                f"P3:{tiers.get('P3',0)} P4:{tiers.get('P4',0)}"
            ),
            duration_sec=duration,
        )

    except Exception as exc:
        # v16.51 #12: Log full exception server-side; expose only generic message
        err_ref = str(uuid.uuid4())[:8]
        _logger.error("Pipeline background error ref=%s: %s", err_ref, exc, exc_info=True)
        duration = round(time.time() - t0, 1)
        _update_state(
            status="error",
            stage="error",
            message=f"Pipeline failed. Contact administrator. Ref: {err_ref}",
            error=f"Internal error. Ref: {err_ref}",
            duration_sec=duration,
        )


# ---------------------------------------------------------------------------
# POST /run
# ---------------------------------------------------------------------------
@router.post(
    "/run",
    response_model=PipelineRunResponse,
    status_code=202,
    summary="Trigger a pipeline run",
    description=(
        "Starts a full AML pipeline run as a background task.\n\n"
        "**Requires data to have been uploaded via Port Authority first.**\n"
        "Poll `GET /api/v1/pipeline/status` or stream `GET /api/v1/pipeline/stream` for progress.\n"
        "Returns 202 Accepted immediately — the run continues in the background.\n\n"
        "**v16.51 #14** — Supply `request_id` for idempotency: same `request_id` within 60 s "
        "returns the original run without re-triggering."
    ),
)
async def trigger_run(
    request: PipelineRunRequest,
    background_tasks: BackgroundTasks,
):
    # v16.51 #14: Idempotency — deduplicate by request_id within 60 seconds
    if request.request_id:
        cached = _idempotency_cache.get(request.request_id)
        if cached:
            cached_run_id, cached_ts = cached
            if time.time() - cached_ts < _IDEMPOTENCY_TTL_SEC:
                _logger.info(
                    "Idempotent request_id=%s → returning existing run_id=%s",
                    request.request_id, cached_run_id,
                )
                return PipelineRunResponse(
                    run_id=cached_run_id,
                    status="accepted",
                    message=(
                        f"Idempotent: request_id already submitted. "
                        f"Existing run_id={cached_run_id}. "
                        f"Poll GET /api/v1/pipeline/status for progress."
                    ),
                )
        # Evict stale entries to prevent unbounded growth
        _prune_idempotency_cache()

    with _state_lock:
        if _pipeline_state["status"] == "running":
            raise HTTPException(
                status_code=409,
                detail="A pipeline run is already in progress. Poll /status for progress.",
            )

    run_id = str(uuid.uuid4())[:8]

    # Cache request_id → run_id for idempotency window
    if request.request_id:
        _idempotency_cache[request.request_id] = (run_id, time.time())

    # v16.51 #2: Write audit trail — who triggered the pipeline
    try:
        _user = _get_current_user()
        from database import get_db  # type: ignore
        db = get_db()
        db.log_audit_event(
            action="PIPELINE_TRIGGERED",
            details=f"run_id={run_id} max_nodes={request.max_nodes} parallel={request.parallel}",
            user=_user,
            severity="INFO",
        )
    except Exception as _ae:
        _logger.warning("Audit trail write failed (non-fatal): %s", _ae)

    # Run in thread (engine is CPU-bound, not async-native)
    thread = threading.Thread(
        target=_run_pipeline_background,
        args=(request, run_id),
        daemon=True,
        name=f"fcdai-pipeline-{run_id}",
    )
    thread.start()

    _logger.info("Pipeline triggered: run_id=%s user=%s", run_id, _get_current_user())

    return PipelineRunResponse(
        run_id=run_id,
        status="accepted",
        message=(
            f"Pipeline run {run_id} started. "
            f"Poll GET /api/v1/pipeline/status or stream GET /api/v1/pipeline/stream"
        ),
    )


def _prune_idempotency_cache():
    """Remove expired entries from idempotency cache (called before each insert)."""
    now = time.time()
    expired = [k for k, (_, ts) in _idempotency_cache.items() if now - ts >= _IDEMPOTENCY_TTL_SEC]
    for k in expired:
        del _idempotency_cache[k]


def _get_current_user() -> str:
    """Return current OS user as audit trail actor (no auth session in background thread)."""
    import os
    try:
        return os.getlogin()
    except Exception:
        return os.environ.get("USERNAME", os.environ.get("USER", "SYSTEM"))


# ---------------------------------------------------------------------------
# GET /status
# ---------------------------------------------------------------------------
@router.get(
    "/status",
    response_model=PipelineStatusResponse,
    summary="Get current pipeline status",
    description=(
        "Returns the current pipeline run status and progress (0–100%).\n\n"
        "Poll this endpoint to track pipeline progress. "
        "For push-based updates, use the `/stream` SSE endpoint."
    ),
)
async def get_status():
    with _state_lock:
        state = dict(_pipeline_state)

    return PipelineStatusResponse(
        run_id=state.get("run_id"),
        status=state.get("status", "idle"),
        progress=state.get("progress", 0),
        stage=state.get("stage", "idle"),
        message=state.get("message", ""),
        started_at=state.get("started_at"),
        duration_sec=state.get("duration_sec"),
    )


# ---------------------------------------------------------------------------
# GET /stream  — SSE (Server-Sent Events)
# ---------------------------------------------------------------------------
@router.get(
    "/stream",
    summary="SSE stream of pipeline progress",
    description=(
        "Server-Sent Events stream. Opens a persistent connection and pushes "
        "pipeline progress updates as JSON events until the run completes.\n\n"
        "Each event: `data: {run_id, status, progress, stage, message}\\n\\n`\n\n"
        "The stream closes automatically when status is 'complete' or 'error'."
    ),
    response_class=StreamingResponse,
)
async def stream_progress():
    """SSE stream — sends progress updates every second."""

    async def generate():
        last_progress = -1
        max_idle_sec = 300  # stop stream after 5 min of inactivity
        start = time.time()

        while time.time() - start < max_idle_sec:
            with _state_lock:
                state = dict(_pipeline_state)

            progress = state.get("progress", 0)
            status = state.get("status", "idle")

            # Only send update if something changed (reduces client CPU)
            if progress != last_progress or status in ("complete", "error"):
                payload = json.dumps(
                    {
                        "run_id": state.get("run_id"),
                        "status": status,
                        "progress": progress,
                        "stage": state.get("stage", ""),
                        "message": state.get("message", ""),
                    }
                )
                yield f"data: {payload}\n\n"
                last_progress = progress

            if status in ("complete", "error", "idle"):
                # Send final event then close
                yield f"data: {json.dumps({'type':'close','status':status})}\n\n"
                break

            await asyncio.sleep(1.0)

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


# ---------------------------------------------------------------------------
# GET /runs  — run history
# ---------------------------------------------------------------------------
@router.get(
    "/runs",
    summary="List all pipeline runs",
    description="Returns the history of all pipeline runs stored in the SQLite database.",
)
async def list_runs(limit: int = 20):
    """Returns the last N pipeline runs from the database."""
    try:
        from database import get_db  # type: ignore

        db = get_db()
        rows = db._conn.execute(
            "SELECT run_id, started_at, finished_at, duration_sec, status, "
            "customers, nodes, edges FROM pipeline_runs ORDER BY run_id DESC LIMIT ?",
            (limit,),
        ).fetchall()
        keys = [
            "run_id",
            "started_at",
            "finished_at",
            "duration_sec",
            "status",
            "account_count",
            "node_count",
            "edge_count",
        ]
        return [dict(zip(keys, row)) for row in rows]
    except Exception as exc:
        # v16.51 #12: Generic error — log full exc server-side
        err_ref = str(uuid.uuid4())[:8]
        _logger.error("list_runs error ref=%s: %s", err_ref, exc, exc_info=True)
        return JSONResponse(
            status_code=503,
            content={"error": "Cannot read run history. Contact administrator.", "ref": err_ref},
        )
