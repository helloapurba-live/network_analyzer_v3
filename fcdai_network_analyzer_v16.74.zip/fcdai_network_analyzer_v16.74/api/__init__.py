"""api — FCDAI FastAPI REST Layer"""
