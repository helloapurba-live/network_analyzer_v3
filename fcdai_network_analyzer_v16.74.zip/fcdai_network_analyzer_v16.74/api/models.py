"""
api.models — Pydantic request/response models for FCDAI REST API
=================================================================
All models are validated by FastAPI automatically.
No PII field names are ever exposed in API responses (node_id is opaque string).
"""

from __future__ import annotations
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Request models
# ---------------------------------------------------------------------------


class PipelineRunRequest(BaseModel):
    """Trigger a pipeline run via POST /api/v1/pipeline/run."""

    max_nodes: int = Field(
        default=5000, ge=1, le=100_000, description="Maximum accounts to analyse."
    )
    parallel: bool = Field(default=True, description="Enable parallel family execution.")
    resume: bool = Field(default=False, description="Resume from last successful stage.")
    request_id: Optional[str] = Field(
        default=None,
        max_length=64,
        description=(
            "v16.51 #14 — Idempotency key. "
            "If the same request_id is submitted within 60 seconds, "
            "the original run_id is returned without triggering a new run."
        ),
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "max_nodes": 5000,
                "parallel": True,
                "resume": False,
                "request_id": "analyst-run-2025-06-21-001",
            }
        }
    }


# ---------------------------------------------------------------------------
# Response models
# ---------------------------------------------------------------------------


class HealthResponse(BaseModel):
    status: str = Field(description="'ok' or 'error'")
    version: str
    dash_port: int
    api_port: int
    uptime_seconds: float
    db_connected: bool


class PipelineRunResponse(BaseModel):
    """Returned immediately (202) when a pipeline run is triggered."""

    run_id: str
    status: str = Field(description="'accepted' | 'running' | 'complete' | 'error'")
    message: str


class PipelineStatusResponse(BaseModel):
    run_id: Optional[str]
    status: str
    progress: int = Field(ge=0, le=100, description="0–100%")
    stage: str
    message: str
    started_at: Optional[str]
    duration_sec: Optional[float]


class TierSummary(BaseModel):
    tier: str = Field(description="P1 | P2 | P3 | P4")
    label: str = Field(description="Critical | High | Medium | Low")
    count: int
    percentage: float


class RoleSummary(BaseModel):
    role: str
    count: int


class NodeResult(BaseModel):
    """Single scored account result."""

    node_id: Any = Field(description="Account identifier (hashed in logs)")
    risk_score: float = Field(ge=0, le=100)
    risk_tier: str
    aml_role: Optional[str]
    role_confidence: Optional[float] = Field(default=None, ge=0, le=1)
    sar_narrative: Optional[str]
    prev_tier: Optional[str]
    tier_change: Optional[str]
    tier_escalated: Optional[int] = Field(default=None, ge=0, le=1)


class PaginatedNodeResults(BaseModel):
    total: int
    page: int
    limit: int
    results: List[NodeResult]


class EscalationResult(BaseModel):
    node_id: Any
    prev_tier: str
    current_tier: str
    tier_change: str
    risk_score: float
    aml_role: Optional[str]
    sar_narrative: Optional[str]


class SARNarrative(BaseModel):
    node_id: Any
    risk_tier: str
    risk_score: float
    aml_role: Optional[str]
    role_confidence: Optional[float]
    sar_narrative: str
    tier_change: Optional[str]


class ExecutiveSummary(BaseModel):
    total_accounts: int
    critical_p1: int
    high_p2: int
    medium_p3: int
    low_p4: int
    escalated_count: int
    tier_breakdown: List[TierSummary]
    role_breakdown: List[RoleSummary]
    run_meta: Dict[str, Any]
    pipeline_version: str


class RunHistoryEntry(BaseModel):
    run_id: int
    started_at: Optional[str]
    finished_at: Optional[str]
    duration_sec: Optional[float]
    status: Optional[str]
    account_count: int
    node_count: int
    edge_count: int
