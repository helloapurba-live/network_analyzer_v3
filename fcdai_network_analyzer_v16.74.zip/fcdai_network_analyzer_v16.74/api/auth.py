"""
api.auth — API Key authentication for FCDAI FastAPI
=====================================================
v16.51 #1a: API key middleware.

Priority order (read-only — key is never generated here for API callers):
  1. os.environ.get("FCDAI_API_KEY") — for scripts / notebooks / CI
  2. data/api.key file (auto-generated on first use if absent — 32-hex hex)

Usage in routes:
    from api.auth import require_api_key
    @router.get("/my-endpoint")
    async def endpoint(api_key: str = Depends(require_api_key)):
        ...

The /health endpoint is intentionally excluded from key enforcement so that
monitoring tools can call it without authentication.
"""

from __future__ import annotations

import os
import secrets
import logging
from pathlib import Path
from fastapi import HTTPException, Security, status
from fastapi.security.api_key import APIKeyHeader

_logger = logging.getLogger("fcdai.api.auth")

# Header name callers must send
_API_KEY_HEADER = APIKeyHeader(name="X-API-Key", auto_error=False)

# Location of the auto-generated key file (relative to package root)
_PKG_ROOT = Path(__file__).parent.parent.resolve()
_KEY_FILE = _PKG_ROOT / "data" / "api.key"


def _get_expected_key() -> str:
    """
    Return the valid API key for this instance.

    Order of precedence:
      1. FCDAI_API_KEY environment variable (scripts, notebooks, CI)
      2. data/api.key file (auto-generated 64-char hex on first run)

    Air-gapped: no network calls, no external key-vault.
    """
    # 1. Environment variable (highest priority — CI / analyst notebooks)
    env_key = os.environ.get("FCDAI_API_KEY", "").strip()
    if env_key:
        return env_key

    # 2. Key file — generate if absent
    _KEY_FILE.parent.mkdir(parents=True, exist_ok=True)
    if not _KEY_FILE.exists():
        raw = secrets.token_hex(32)  # 64-char hex = 256 bits
        _KEY_FILE.write_text(raw, encoding="utf-8")
        try:
            _KEY_FILE.chmod(0o600)  # owner read/write only (no-op on Windows, safe)
        except Exception:
            pass
        _logger.info("API key auto-generated and saved to data/api.key")
        print(f"  [AUTH] API key generated → {_KEY_FILE}")
        print(f"  [AUTH] Set env var FCDAI_API_KEY=<key> or read from {_KEY_FILE}")
    return _KEY_FILE.read_text(encoding="utf-8").strip()


async def require_api_key(api_key: str = Security(_API_KEY_HEADER)) -> str:
    """
    FastAPI dependency — raises 401 if the X-API-Key header is missing or wrong.
    Returns the key string on success (allows routes to log which key was used).

    v16.51 #12: Returns generic error message — never leaks the expected key value.
    """
    expected = _get_expected_key()
    if not api_key or api_key != expected:
        _logger.warning("INVALID_API_KEY attempt — key header missing or mismatch")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or missing API key. Set X-API-Key header.",
            headers={"WWW-Authenticate": "ApiKey"},
        )
    return api_key
