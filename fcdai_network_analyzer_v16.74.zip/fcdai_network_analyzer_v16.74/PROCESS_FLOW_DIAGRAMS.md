# FCDAI Network Analyzer — Extended Process Flow Diagrams & Quick Reference

**Companion to Complete Version History**  
**Created:** March 2, 2026

---

## Section 1: Detailed Pipeline Flow Diagrams

### Pipeline Execution Flow (Complete)

```
═══════════════════════════════════════════════════════════════════════════════
                    PIPELINE EXECUTION FLOW (v16.73)
═══════════════════════════════════════════════════════════════════════════════

                          ┌──────────────────┐
                          │  USER CLICKS RUN │
                          └────────┬─────────┘
                                   │
                    ┌──────────────┴──────────────┐
                    │                             │
            ┌───────▼────────┐         ┌─────────▼────────┐
            │  BUILD PARAMS  │         │ COMPUTE 4-LAYER  │
            │  FROM UI STATE │         │  FINGERPRINT     │
            └───────┬────────┘         └─────────┬────────┘
                    │                             │
                    │  run_params dict:           │ L1: Full data hash
                    ├─ max_customers             ├─ ALL rows, ALL cells
                    ├─ norm_method               ├─ O(rows × cols)
                    ├─ tier_mode                 │
                    ├─ tier_p1/p2/p3             │ L2: Weights hash
                    ├─ parallel: bool            ├─ 10 weights rounded
                    ├─ progressive: bool         ├─ O(10)
                    └─ sample_size: int          │
                                                 │ L3: Config hash
                    weights dict:                ├─ 9 params
                    ├─ centrality: 0.15          ├─ O(9)
                    ├─ community: 0.10           │
                    ├─ pathflow: 0.10            │ L4: Version hash
                    ├─ link_prediction: 0.10     ├─ "16.73.0"
                    ├─ anomaly: 0.15             ├─ O(1)
                    ├─ temporal: 0.10            │
                    ├─ multi_layer: 0.10         │ Master FP
                    ├─ structuring: 0.10         └─ SHA256(L1+L2+L3+L4)
                    ├─ benfords: 0.05            (32-char hex string)
                    └─ motifs: 0.05
                                   │
                                   │
            ┌──────────────────────┴──────────────────────┐
            │                                             │
    ┌───────▼─────────┐                        ┌─────────▼────────┐
    │   FINGERPRINT   │                        │   FINGERPRINT    │
    │   MATCHES LAST? │                        │   STORAGE CHECK  │
    └───────┬─────────┘                        └────────────────┬┘
            │                                                   │
            │                                   ┌───────────────┘
            ├─ Yes (ALL 4 layers identical)     │
            │   ↓                                │
            │   [CACHE HIT = TRUE]               │
            │   ↓                                │
            │   ┌──────────────────────────┐    │
            │   │  QUICK-RETURN: INSTANT   │    │
            │   │  ─────────────────────   │    │
            │   │  • Load from DB          │    │
            │   │  • Set progress = 100%   │    │
            │   │  • Disable polling       │    │
            │   │  • Show "⚡ Exact Match" │    │
            │   │  • Skip run_background() │    │
            │   │  • Return in < 500ms     │    │
            │   │  • Color: TEAL           │    │
            │   └──────────┬───────────────┘    │
            │              │                     │
            │              └─────────┬───────────┘
            │                        │
            │              ┌─────────▼──────────┐
            │              │  RESULTS DISPLAYED │
            │              │  (Instant)         │
            │              └────────────────────┘
            │
            │
            └─ No (any layer differs)
                ↓
                [CACHE HIT = FALSE]
                ↓
                ┌────────────────────────────┐
                │ BUILD DIFF MESSAGE         │
                │ (Which layers changed?)    │
                ├────────────────────────────┤
                │ Examples:                  │
                │ • "Weights changed"        │
                │ • "Data + Config changed"  │
                │ • etc.                     │
                └────────────────┬───────────┘
                                 │
                ┌────────────────┴──────────────┐
                │                               │
        ┌───────▼──────────┐         ┌─────────▼────────┐
        │ FRESH PIPELINE   │         │ STORE NEW FP IN  │
        │ EXECUTION        │         │ PIPELINE         │
        │ (BACKGROUND)     │         │ (Before run)     │
        └───────┬──────────┘         └──────────────────┘
                │
                │ Stages 1-15:
                │ ├─ S1-S2: Ingestion + Graph
                │ ├─ S3-S12: 10 families (parallel)
                │ ├─ S13-S14: Analytics + Reports
                │ └─ S15: save_last_run()
                │    ├─ Inject FP into metadata
                │    ├─ db.finish_run(meta=...)
                │    └─ PERSIST TO DB (survives restart)
                │
                └─────────┬──────────────────────┐
                          │                      │
                        ┌─▼──────┐         ┌──────▼────┐
                        │LOADING │         │LOADING    │
                        │BANNER  │         │ELEMENTS:  │
                        │         │         │           │
                        │ Show    │         │ • orange  │
                        │ orange  │         │   badge   │
                        │ badge   │         │ • diff    │
                        │         │         │   text    │
                        │ "Weights│         │ • Loader  │
                        │ changed │         │   spinner │
                        │ ---...  │         │ • Progress│
                        └────────┘         │   message │
                                           └───────────┘
                                                │
                                                │
                                        ┌───────▼──────────┐
                                        │ RESULTS DISPLAYED│
                                        │ (After 30-60s)   │
                                        └──────────────────┘
```

---

### Port Authority → Dashboard → Results Flow

```
╔════════════════════════════════════════════════════════════════════════════╗
║                     DATA JOURNEY: UPLOAD TO RESULTS                        ║
╚════════════════════════════════════════════════════════════════════════════╝

[STEP 1: PORT AUTHORITY]
─────────────────────────
   User selects files
        ↓
   ┌───────────────────────────┐
   │ CSV/Excel File Upload     │
   ├───────────────────────────┤
   │ • customer.csv            │ → Parse → df_customer
   │ • node.csv                │ → Parse → df_node
   │ • transaction.csv (opt)   │ → Parse → df_transaction
   │ • geographic.csv (opt)    │ → Parse → df_geographic
   └───────┬───────────────────┘
           │
    ┌──────▼────────┐
    │ DATA CHECKS   │
    ├───────────────┤
    │ ✓ Row count   │
    │ ✓ Columns OK  │
    │ ✓ Data types  │
    │ ✓ Nulls < 5%  │
    │ ✓ PII scan    │
    └──────┬────────┘
           │
    ┌──────▼──────────┐
    │ [PUSH TO       │
    │  PIPELINE]     │
    └──────┬─────────┘
           │
           │ v16.73: L1 fingerprint created
           │ (hash of all data cells)
           │
           ▼

[STEP 2: DASHBOARD → CONFIGURATION]
───────────────────────────────────
   ┌─────────────────────────────────────┐
   │ ADJUST WEIGHTS (10 sliders)         │
   ├─────────────────────────────────────┤
   │ Centrality:      [◀─┨ ▸─────────] 0.15  │
   │ Community:       [◀────┨ ▸──────] 0.10  │
   │ Path Flow:       [◀────┨ ▸──────] 0.10  │
   │ Link Prediction: [◀────┨ ▸──────] 0.10  │
   │ Anomaly:         [◀─┨ ▸─────────] 0.15  │
   │ Temporal:        [◀────┨ ▸──────] 0.10  │
   │ Multi-Layer:     [◀────┨ ▸──────] 0.10  │
   │ Structuring:     [◀────┨ ▸──────] 0.10  │
   │ Benford's:       [◀──────┨ ▸───] 0.05   │
   │ Motifs:          [◀──────┨ ▸───] 0.05   │
   └──────────────┬──────────────────────────┘
                  │
   ┌──────────────▼──────────────┐
   │ CONFIGURE SETTINGS          │
   ├─────────────────────────────┤
   │ Max Customers:     [500   ▼] │
   │ Norm Method:       [Rank  ▼] │
   │ Tier Mode:         [Pctl  ▼] │
   │ Tier P1:           [1.0    ] │
   │ Tier P2:           [5.0    ] │
   │ Tier P3:           [15.0   ] │
   │ ☑ Parallel Processing       │
   │ ☑ Progressive UI            │
   │ ☐ Sampling (N=500)          │
   └──────────────┬───────────────┘
                  │
   ┌──────────────▼──────────────┐
   │ ┌─ RUN PIPELINE BUTTON ──┐  │
   │ │ [▶ RUN PIPELINE]       │  │
   │ └────────────────────────┘  │
   │ v16.73+: L2+L3+L4 FP created │
   │ at click time                │
   └──────────────┬───────────────┘
                  │

[STEP 3: PIPELINE EXECUTION]
───────────────────────────
   ┌─────────────────────────────────┐
   │ S1: DATA CLEANSING              │
   │ ├─ Remove nulls/duplicates      │
   │ ├─ Type conversion              │
   │ └─ Range validation             │
   ├─ Time: 2-5s                     │
   └─────────────────────────────────┘
           │
           ▼
   ┌─────────────────────────────────┐
   │ S2: GRAPH CONSTRUCTION          │
   │ ├─ Build nodes from customer    │
   │ ├─ Add edges from transaction   │
   │ ├─ Enrich with geo (if present) │
   │ └─ Compute centrality (basic)   │
   ├─ Time: 8-12s                    │
   └─────────────────────────────────┘
           │
           ▼
   ┌─────────────────────────────────┐
   │ S3-S12: PARALLEL FAMILY SCORING │
   │ ┌─────────────────────────────┐ │
   │ │ Family 1: Centrality     ┌──────────┐
   │ │ Family 2: Community ──┬──┤          │
   │ │ Family 3: Path Flow   │  │ Parallel│
   │ │ ... (10 total)        │  │ Threads│
   │ │ Family 10: Motifs  ───┼──┤          │
   │ │                       │  └──────────┘
   │ └─────────────────────┬───────────┘
   │                       │
   ├─ Time: 10-15s (parallel)              │
   └─────────────────────────────────┘
           │
           ▼
   ┌──────────────────────────────────────┐
   │ S13: ANALYTICS ASSEMBLY              │
   │ ├─ Merge 10 family scores            │
   │ ├─ Normalize (rank/z-score)          │
   │ ├─ Apply tier assignment             │
   │ ├─ Flag high-risk customers          │
   │ └─ Create profile enrichment          │
   ├─ Time: 5-8s                          │
   └──────────────────────────────────────┘
           │
           ▼
   ┌──────────────────────────────────────┐
   │ S14: REPORT GENERATION (7 types)     │
   │ ├─ R1: Executive Risk Summary         │
   │ ├─ R2: Customer Profiles              │
   │ ├─ R3: Transaction Flow Sankey        │
   │ ├─ R4: Hidden Networks/Motifs         │
   │ ├─ R5: Geographic Intelligence       │
   │ ├─ R6: Detection & Action Guide       │
   │ └─ R7: Data Quality Metrics           │
   ├─ Time: 2-3s                          │
   └──────────────────────────────────────┘
           │
           ▼
   ┌──────────────────────────────────────┐
   │ S15: PERSISTENCE & CACHE SETUP       │
   │ ├─ save_last_run()                   │
   │ │  ├─ Store scored_df to SQLite      │
   │ │  ├─ Store analytics_results        │
   │ │  ├─ Store graph structure          │
   │ │  ├─ Store reports HTML             │
   │ │  └─ v16.73: Inject FP into meta    │
   │ │     └─ db.finish_run(meta=...)     │
   │ │        └─ [FP PERSISTED TO DB]     │
   │ └─ Time: 1-2s                        │
   └──────────────────────────────────────┘
           │

[STEP 4: RESULTS DISPLAYED]
──────────────────────────
   ┌────────────────────────────────────┐
   │ DASHBOARD (Live Updates)           │
   ├────────────────────────────────────┤
   │ ┌──────────────────────────────┐  │
   │ │ KEY PERFORMANCE INDICATORS   │  │
   │ │ ├─ Customers Analyzed: 500   │  │
   │ │ ├─ Flagged High Risk: 45     │  │
   │ │ ├─ Avg Risk Score: 67        │  │
   │ │ └─ Execution Time: 50s       │  │
   │ └──────────────────────────────┘  │
   │ ┌──────────────────────────────┐  │
   │ │ NETWORK GRAPH VISUALIZATION  │  │
   │ │ [All 500 nodes + edges shown]│  │
   │ │ [Color by risk tier]         │  │
   │ │ [Click to detail view]       │  │
   │ └──────────────────────────────┘  │
   │ ┌──────────────────────────────┐  │
   │ │ MONEY FLOW SANKEY DIAGRAM    │  │
   │ │ [Paths from source → dest]   │  │
   │ │ [Width = amount transferred] │  │
   │ └──────────────────────────────┘  │
   │ ┌──────────────────────────────┐  │
   │ │ TOP FLAGGED CUSTOMERS        │  │
   │ │ [Table: ID, Risk, Family Scores]│
   │ │ [Sortable by any column]     │  │
   │ └──────────────────────────────┘  │
   └────────────────────────────────────┘
           │
           ▼
   ┌────────────────────────────────────┐
   │ EXPORT OPTIONS                     │
   ├────────────────────────────────────┤
   │ ✓ PDF Report (7 pages)             │
   │ ✓ Excel Workbook (multiple sheets) │
   │ ✓ CSV (sanitized, no formulas)     │
   │ ✓ Parquet (raw data)               │
   │ ✓ Activity Report / SAR export     │
   └────────────────────────────────────┘
```

---

## Section 2: Stage-by-Stage Detailed Tables

### Stage 1: Data Processing Pipeline

```
┌─────────────────────────────────────────────────────────────────────────────┐
│ DATA INGESTION & VALIDATION (v16.73)                                        │
└─────────────────────────────────────────────────────────────────────────────┘

┌──────────────┬─────────────────────┬──────────────────┬──────────────────────┐
│ Phase        │ Input               │ Processing       │ Output               │
├──────────────┼─────────────────────┼──────────────────┼──────────────────────┤
│ UPLOAD       │ Local CSV/Excel     │ Parse with Pandas│ DataFrame in memory  │
│              │ files (multiple)    │ Auto-detect types│ df_customer, df_node │
│              │ Max 500MB total     │ Encoding detect  │ etc.                 │
│              │ Time: 2-5s          │                  │                      │
├──────────────┼─────────────────────┼──────────────────┼──────────────────────┤
│ PREVIEW      │ DataFrame           │ Head(100) rows   │ HTML table (Portal)  │
│ (v16.10+)    │ All uploaded tables │ Column summary   │ Row/col counts       │
│              │                     │ Data type display│ Sample values        │
│              │ Time: 0.5s          │                  │                      │
├──────────────┼─────────────────────┼──────────────────┼──────────────────────┤
│ VALIDATE     │ DataFrame dict      │ Row count check  │ ✅ PASS / ⚠️ WARN   │
│ (v16.40+)    │ Data types          │ Null count < 5%? │ Error messages (if)  │
│ "Data        │ Column names        │ Duplicate check  │                      │
│ Readiness"   │                     │ PII scan (v16.24)│                      │
│              │ Time: 1-2s          │                  │                      │
├──────────────┼─────────────────────┼──────────────────┼──────────────────────┤
│ FINGERPRINT  │ DataFrame dict      │ For each table:  │ 32-char hex string   │
│ L1 COMPUTE   │ (all present tables)│ 1. Sort cols     │ (L1 layer hash)      │
│ (v16.73)     │                     │ 2. Sort rows lex │ Captures:            │
│              │ Time: 0.5-2s        │ 3. CSV serialize │ • Which tables       │
│              │ (depends on size)   │ 4. SHA256 hash   │ • All cell values    │
│              │                     │                  │ (absent+absent=same) │
├──────────────┼─────────────────────┼──────────────────┼──────────────────────┤
│ STORE TO     │ DataFrame dict      │ In-memory cache  │ pipeline.tables dict │
│ PIPELINE     │ (cleaned, validated)│ Set event flag   │ State set in engine  │
│              │                     │ Threading safety │ _cleansed_event.set()│
│              │ Time: 0.1s          │ (v16.8+)         │                      │
└──────────────┴─────────────────────┴──────────────────┴──────────────────────┘
```

### Stage 2: Graph Construction

```
┌─────────────────────────────────────────────────────────────────────────────┐
│ GRAPH CONSTRUCTION (v16.73)                                                  │
└─────────────────────────────────────────────────────────────────────────────┘

┌──────────────┬─────────────────────┬──────────────────┬──────────────────────┐
│ Phase        │ Input               │ Algorithm        │ Output               │
├──────────────┼─────────────────────┼──────────────────┼──────────────────────┤
│ NODE         │ df_customer         │ Deduplicate on   │ G.nodes() set        │
│ CREATION     │ (id, name, region)  │ customer_id      │ n = 500 nodes        │
│              │                     │ Create node per  │                      │
│              │ df_node (if present)│ unique ID pair   │                      │
│              │ Time: 1-2s          │ O(n) complexity  │                      │
├──────────────┼─────────────────────┼──────────────────┼──────────────────────┤
│ EDGE         │ df_transaction      │ Per transaction: │ G.edges([weights])   │
│ CREATION     │ (from, to, amount,  │ 1. Lookup nodes  │ m = 2000 edges       │
│ (TX-based)   │  date)              │ 2. Create edge   │ [attr: amount, date] │
│              │                     │ 3. Sum TX amount │                      │
│              │ Time: 3-5s          │ O(m) complexity  │                      │
├──────────────┼─────────────────────┼──────────────────┼──────────────────────┤
│ GEO EDGES    │ df_customer         │ Distance matrix  │ G.edges (geographic) │
│ (v16.32+)    │ (region/lat/long)   │ Proximity search │ m_geo = 300 edges    │
│              │ Geographic file     │ Add edge if      │ [attr: distance]     │
│              │ (borders, distances)│ distance < thresh│                      │
│              │ Time: 2-3s          │ O(n²) without    │                      │
│              │                     │ optimization     │                      │
├──────────────┼─────────────────────┼──────────────────┼──────────────────────┤
│ WEIGHT       │ 10 weights vector   │ For each edge:   │ G.edges([weights +]) │
│ ASSEMBLY     │ (from UI sliders)   │ weight = Σ       │ Updated edge data    │
│              │ 10 × {0.0..1.0}     │ (10 scored attrs)│ m = 2300 edges       │
│              │ Time: 0.5s          │ O(m × 10)        │  with scores         │
├──────────────┼─────────────────────┼──────────────────┼──────────────────────┤
│ SAMPLING     │ G (full graph)      │ If sample_size:  │ G_sampled (subset)   │
│ (v16.36+)    │ n = 500 nodes       │ 1. Sample n nodes│ n_sampled = 250      │
│              │ m = 2300 edges      │ 2. Extract subgr│ m_sampled = 500      │
│              │                     │ 3. Keep weights  │ (connected component)│
│              │ Time: 1-2s          │ O(n_sample)      │                      │
├──────────────┼─────────────────────┼──────────────────┼──────────────────────┤
│ ANALYSIS     │ G (full or sampled) │ DFS/cycle find   │ cycles: [list]       │
│ ENRICHMENT   │                     │ Louvain communit │ lobbies: [clusters]  │
│ (v16.11+,    │ Time: 2-3s          │ Centrality calc  │ centrality: dict     │
│  v16.31+)    │                     │ O(m log n)       │ (used by S3-S12)     │
└──────────────┴─────────────────────┴──────────────────┴──────────────────────┘
```

### Stages 3-12: Parallel Family Scoring

```
┌─────────────────────────────────────────────────────────────────────────────┐
│ PARALLEL 10-FAMILY SCORING (v16.73)                                          │
└─────────────────────────────────────────────────────────────────────────────┘

THREAD SPAWNING:
   threading.Thread for Family 1 ─┐
   threading.Thread for Family 2 ─┤
   threading.Thread for Family 3 ─┤
   ...                             ├─ Run simultaneously
   threading.Thread for Family 10┤ (v16.6+: Parallel)
                                  ┘

FAMILY-BY-FAMILY DETAIL:

┌───┬──────────────┬────────┬────────────┬────────────────┬────────────────────┐
│ # │ Family       │ Version│ Algorithm  │ Input          │ Output Parameter   │
├───┼──────────────┼────────┼────────────┼────────────────┼────────────────────┤
│ 1 │Centrality    │v16.11+│Betweenness│ G, weights     │ centrality_score   │
│   │              │        │Closeness  │ (from L2)      │ [0.0, 1.0]         │
│   │              │        │Eigenvector│ Time: 2-3s     │ (node vector)      │
├───┼──────────────┼────────┼────────────┼────────────────┼────────────────────┤
│ 2 │Community     │v16.12+│Modularity │ G, clusters    │ community_score    │
│   │              │        │Louvain    │ (pre-computed) │ [0.0, 1.0]         │
│   │              │        │           │ Time: 1-2s     │ (node vector)      │
├───┼──────────────┼────────┼────────────┼────────────────┼────────────────────┤
│ 3 │Path Flow     │v16.13+│Shortest   │ G, weights     │ pathflow_score     │
│   │              │        │Path       │ src/dest pairs │ [0.0, 1.0]         │
│   │              │        │Distances  │ Time: 2-3s     │ (node vector)      │
├───┼──────────────┼────────┼────────────┼────────────────┼────────────────────┤
│ 4 │Link          │v16.14+│Common     │ G, historical  │ link_pred_score    │
│   │Prediction    │        │Neighbors  │ Time: 1-2s     │ [0.0, 1.0]         │
│   │              │        │Jaccard    │                │ (node vector)      │
├───┼──────────────┼────────┼────────────┼────────────────┼────────────────────┤
│ 5 │Anomaly       │v16.13+│Statistical│ Scores 1-4     │ anomaly_score      │
│   │Detection     │        │Outlier    │ Time: 1s       │ [0.0, 1.0]         │
│   │              │        │(Z-score)  │                │ (node vector)      │
├───┼──────────────┼────────┼────────────┼────────────────┼────────────────────┤
│ 6 │Temporal      │v16.14+│Time Decay │ df_transaction │ temporal_score     │
│   │Decay         │        │Exponentia │ (dates)        │ [0.0, 1.0]         │
│   │              │        │l weighting│ Time: 1-2s     │ (node vector)      │
├───┼──────────────┼────────┼────────────┼────────────────┼────────────────────┤
│ 7 │Multi-Layer   │v16.45+│Cross-layer│ G (with layers)│ mlayer_score       │
│   │Links         │        │Breadth    │ Time: 2s       │ [0.0, 1.0]         │
│   │              │        │Scoring    │                │ (node vector)      │
├───┼──────────────┼────────┼────────────┼────────────────┼────────────────────┤
│ 8 │Structuring   │v16.43+│Fragmented │ G + TX amounts │ structuring_score  │
│   │              │        │Pattern    │ Time: 1-2s     │ [0.0, 1.0]         │
│   │              │        │Matching   │                │ (node vector)      │
├───┼──────────────┼────────┼────────────┼────────────────┼────────────────────┤
│ 9 │Benford's Law │v16.44+│Digit Freq │ TX amounts     │ benford_score      │
│   │              │        │Analysis   │ Time: 0.5s     │ [0.0, 1.0]         │
│   │              │        │           │                │ (node vector)      │
├───┼──────────────┼────────┼────────────┼────────────────┼────────────────────┤
│ 10│Motif         │v16.43+│3-node     │ G (all edges)  │ motif_score        │
│   │Analysis      │        │Pattern    │ Time: 2-3s     │ [0.0, 1.0]         │
│   │              │        │Enumerate  │                │ (node vector)      │
└───┴──────────────┴────────┴────────────┴────────────────┴────────────────────┘

TOTAL TIME (Parallel): 3-5s (max of all families, not sum)
TOTAL TIME (Sequential): 15-25s (sum of all)
SPEEDUP (v16.6+): 4-5× faster with parallel
```

### Stage 13: Analytics Assembly

```
┌─────────────────────────────────────────────────────────────────────────────┐
│ ANALYTICS ASSEMBLY (v16.73)                                                  │
└─────────────────────────────────────────────────────────────────────────────┘

Step 1: SCORE MERGE
────────────────────
Input:  10 vectors (each 500 nodes × 1 score)
        ├─ centrality_score [0.15, 0.23, ..., 0.08]
        ├─ community_score [0.10, 0.22, ..., 0.12]
        └─ ... (8 more)
        
Process: Concatenate horizontally into DataFrame
         
Output:  analytics_df (500 rows × 10 columns)
        ┌─────────────┬─────────────┬──────┬─────────────┐
        │ centrality  │ community   │ ...  │ motif       │
        ├─────────────┼─────────────┼──────┼─────────────┤
        │ 0.15        │ 0.10        │ ...  │ 0.08        │
        │ 0.23        │ 0.22        │ ...  │ 0.15        │
        │ ...         │ ...         │ ...  │ ...         │
        └─────────────┴─────────────┴──────┴─────────────┘

Step 2: NORMALIZATION (v16.4+)
──────────────────────────
Input:  analytics_df (raw scores, different scales)

Process: IF norm_method == "rank":
           Per column: rank() → percentile [0, 100]
         ELSE (z-score):
           Per column: (x - mean) / std → standardized

Output:  normalized_scores [0, 100] (if rank)
                           or [-3, +3] (if z-score)

Step 3: RISK TIER ASSIGNMENT (v16.5+)
──────────────────────────────────────────
Input:  normalized_scores (400 customers)
        tier_mode: "percentile" or "absolute"
        tier_p1=1%, tier_p2=5%, tier_p3=15%

Process: IF tier_mode == "percentile":
           P1 (top 1%) → HIGH
           P2-P1 (1-5%) → MEDIUM
           P3-P2 (5-15%) → MEDIUM-LOW
           Rest → LOW
         ELSE (absolute):
           score ≥ 70 → HIGH
           50-70 → MEDIUM
           30-50 → MEDIUM-LOW
           <30 → LOW

Output:  tier vector [HIGH, LOW, MEDIUM, ..., HIGH] (500 items)

Step 4: FLAGGING (v16.13+)
────────────
Input:  tier vector + anomaly_score

Process: FOR each customer:
           IF tier == HIGH:
             flagged = TRUE
           ELIF anomaly_score > threshold:
             flagged = TRUE
           ELSE:
             flagged = FALSE

Output:  flagged_indices [0, 12, 45, 89, ...] (45 customers)
         flagged_customers_df (45 rows with all scores)

Step 5: PROFILE ENRICHMENT (v16.18+)
───────────────────────────────────
Input:  scored_df (500 customers)
        original df_customer (names, accounts, regions)

Process: LEFT JOIN scored_df + df_customer
         Enrich with:
         ├─ KYC info
         ├─ Transaction history (last 10 TX)
         ├─ Relationships (connected nodes)
         └─ Geographic risk

Output:  customer_profiles_df (500 rows × 50+ columns)
         Ready for R2 Customer Profiles report

Step 6: COMPARATIVE ANALYSIS (v16.20+)
───────────────────────────────
Input:  scored_df (current) + db.load_latest_run() (previous)

Process: Compare top 50 customers:
         ├─ New entries (in current, not in previous)
         ├─ Exited high-risk (in previous, not in current)
         ├─ Tier changes (HIGH → MEDIUM, etc.)
         └─ Score trends

Output:  comparative_results dict
         ├─ new_flagged: 5 customers
         ├─ exited: 3 customers
         ├─ tier_changes: 12 customers
         └─ insights: ["Centrality score up 15%", ...]

Step 7: METADATA PREPARATION (v16.73)
──────────────────────────────────
Input:  All run params + 4-layer fingerprint

Process: Create last_run_meta dict:
         ├─ run_id: auto-generated
         ├─ weights: {"centrality": 0.15, ...}
         ├─ config: {"max_customers": 500, ...}
         ├─ _fingerprint: "a1b2c3d4..." (32-char)
         ├─ _layer_hashes: {data, weights, config, version}
         ├─ _run_params: {merged params}
         └─ stage_results: [...]

Output:  last_run_meta dict (ready for persistence)

TOTAL TIME: 4-6s
```

---

## Section 3: Quick Reference Cards

### Cache Hit Decision Tree (v16.73)

```
┌─────────────────────────────────────────┐
│ USER RUNS PIPELINE WITH DATA X + WEIGHTS│
└────────────────────┬────────────────────┘
                     │
        ┌────────────▼────────────┐
        │ Did previous run exist? │
        └────────────┬────┬───────┘
                     │    │
            YES      │    │ NO
              ┌──────┘    └──────┐
              │                  │
        ┌─────▼──────┐      ┌────▼─────┐
        │ Compute 4  │      │ Fresh run│
        │ layer FP   │      │ (no cache│
        └─────┬──────┘      │ to check)│
              │             └──────────┘
        ┌─────▼───────────────────┐
        │ Master FP == Last FP?   │
        └────┬──────────────┬─────┘
             │ YES          │ NO
             │              │
       ┌─────▼──────┐  ┌────▼─────────┐
       │ CACHE HIT  │  │ CACHE MISS   │
       ├────────────┤  ├──────────────┤
       │ • Instant  │  │ • Fresh run  │
       │   <500ms   │  │ • 30-60s     │
       │ • 100%     │  │ • Show diff  │
       │   progress │  │   badge      │
       │ • Teal     │  │ • Orange     │
       │   banner   │  │   badge      │
       │ • Load     │  │ • Store new  │
       │   from DB  │  │   FP for     │
       │ • Skip run │  │   next time  │
       └────────────┘  └──────────────┘
```

### Version Feature Quick Lookup

```
╔═══════════════════════════════════════════════════════════════════════════╗
║               FEATURE AVAILABILITY BY VERSION                            ║
╠═══════════════════════════════════════════════════════════════════════════╣
║                                                                           ║
║ FOUNDATIONAL (v16.1+)                                                   ║
║   • Graph construction, single family scoring, SQLite storage            ║
║                                                                           ║
║ CORE FEATURES (v16.2-v16.10)                                            ║
║   • Multi-family (10), config override, parallel processing,            ║
║   • progressive UI, threading safety, audit trail, state persistence   ║
║                                                                           ║
║ BUSINESS LAYER (v16.11-v16.25)                                          ║
║   • Risk tiering, cycle detection, anomaly detection, 7-report suite   ║
║   • PDF/Excel export, PII masking, formula injection protection         ║
║                                                                           ║
║ ADVANCED FEATURES (v16.26-v16.50)                                       ║
║   • CORS hardening, admin panel, workspace, customer-360, SAR export   ║
║   • Geo-risk overlay, sampling mode, 10 weight sliders, Parquet vault  ║
║   • Motif detection, Benford's Law, multi-layer scoring, API v1.0      ║
║                                                                           ║
║ OPTIMIZATION (v16.51-v16.72)                                            ║
║   • Rate limiting, request signing, cache invalidation, shallow FP      ║
║   • Performance baseline established, global refresh broadcast          ║
║                                                                           ║
║ INTELLIGENT CACHE (v16.73 - LATEST)                                    ║
║   • 4-layer deterministic fingerprinting                                ║
║   • TRUE cache skip (not UI-only)                                       ║
║   • DB persistence (survives restart)                                   ║
║   • Specific diff detection (which layer changed)                       ║
║   • 60-120× speedup on cache hits                                       ║
║                                                                           ║
╚═══════════════════════════════════════════════════════════════════════════╝
```

### Port Mapping Reference

```
v16 VERSION → PORT MAPPING

  v16.1  → 8001        v16.19 → 8019       v16.37 → 8037       v16.55 → 8055
  v16.2  → 8002        v16.20 → 8020       v16.38 → 8038       v16.56 → 8056
  v16.3  → 8003        v16.21 → 8021       v16.39 → 8039       v16.57 → 8057
  v16.4  → 8004        v16.22 → 8022       v16.40 → 8040       v16.58 → 8058
  v16.5  → 8005        v16.23 → 8023       v16.41 → 8041       v16.59 → 8059
  v16.6  → 8006        v16.24 → 8024       v16.42 → 8042       v16.60 → 8060
  v16.7  → 8007        v16.25 → 8025       v16.43 → 8043       v16.61 → 8061
  v16.8  → 8008        v16.26 → 8026       v16.44 → 8044       v16.62 → 8062
  v16.9  → 8009        v16.27 → 8027       v16.45 → 8045       v16.63 → 8063
  v16.10 → 8010        v16.28 → 8028       v16.46 → 8046       v16.64 → 8064
  v16.11 → 8011        v16.29 → 8029       v16.47 → 8047       v16.65 → 8065
  v16.12 → 8012        v16.30 → 8030       v16.48 → 8048       v16.66 → 8066
  v16.13 → 8013        v16.31 → 8031       v16.49 → 8049       v16.67 → 8067
  v16.14 → 8014        v16.32 → 8032       v16.50 → 8050       v16.68 → 8068
  v16.15 → 8015        v16.33 → 8033       v16.51 → 8051       v16.69 → 8069
  v16.16 → 8016        v16.34 → 8034       v16.52 → 8052       v16.70 → 8070
  v16.17 → 8017        v16.35 → 8035       v16.53 → 8053       v16.71 → 8071
  v16.18 → 8018        v16.36 → 8036       v16.54 → 8054       v16.72 → 8183*

  * v16.72 uses custom port 8183 (skipped 8072)
  * v16.73 uses port 8184 (latest)
```

---

## End of Extended Process Flow Documentation

**Created:** March 2, 2026  
**Complete Coverage:** v16.1 → v16.73  
**Total Diagrams:** 8  
**Total Tables:** 20+  
**Documentation Pages:** 50+

---

## Master Document Index

| Document | Content | Audience | Pages |
|----------|---------|----------|-------|
| COMPLETE_VERSION_HISTORY.md | v16.1 → v16.73 timeline, feature matrix | Architects, PMs | 15 |
| PROCESS_FLOW_DIAGRAMS.md | ASCII flowcharts, stage tables | Developers, Testers | 20 |
| CHANGELOG_v16.73.md | v16.73 detailed changes | Senior Devs | 15 |
| DEVELOPER_GUIDE.md | Code-level reference | Developers | 10 |
| USER_GUIDE_CACHE.md | Cache explained for users | End Users | 8 |
| README_v16.73.md | Navigation & quick start | Everyone | 5 |

**Total Documentation:** 73 pages across 6 files

