"""
Layer 6: Risk Scoring — V16.3 ADVANCED FUSION ENGINE
====================================================
v16.3 Scoring Fusion Improvements (all unsupervised, air-gap safe, no labels):

  F1 RANK-BEFORE-FUSE: Cross-sectionally rank-normalise every family score vector
     to [0,1] across all nodes BEFORE inter-family weighted sum.  Removes scale
     incompatibility between families with different distributional shapes
     (anomaly compressed [0.3-0.7]; motifs bimodal [0, 0.9+]; Benford right-skewed).
     Highest single-change impact — every family contributes equal variance.

  F2 CONSERVATIVE OWA: Ordered Weighted Averaging [0.25, 0.18, 0.14 ...].
     Applied per-node: each node's best-signal family gets the 0.25 slot.
     Prevents single-peak dilution; rewards multi-family consensus naturally.

  F3 DISAGREEMENT FLAG: Single-family spike suppression (max>0.70, std>0.22,
     <2 families agree ≥0.50) → 0.88× penalty + single_family_spike column.

  F4 ENTROPY DYNAMIC WEIGHTS: Scale config weight by (1 − H(family)) per run.
     Uninformative families (H≈1) auto-shrink; bimodal families keep full weight.
     Dataset-adaptive, no labels, no external calls.

  F5 BORDA COUNT CONSENSUS: Replace binary above-median vote (v14.3) with
     rank-sum aggregation.  Captures both HOW MANY and HOW STRONGLY families agree.
     Output scaled [0,10] for backward compatibility with multiplier formula.

  F6 RISK PROBABILITY: Empirical CDF column risk_probability ∈ [0,1].
     "0.94" = account has higher risk than 94% of all analysed accounts.

  F7 MAX-AVG HYBRID: fused = 0.25×max + 0.75×entropy-weighted-avg per node.
     Prevents extreme single-family signals from being fully diluted.
     Final blend: 60% OWA + 40% max-avg (configurable).

Inherited (unchanged) from v16.2 / v15.x:
  v16.2: A1 weight rebalance | A2 capacity-aware P1 | B1 velocity features
         B2 motif Z-score vs null | C1 seeded Louvain | C2 2-round propagation
  v15.x: FIX-11 binary flags | FIX-PROP multiplicative decay | rank-calibration
         propagation + tier | audit chain | evidence codes | AML roles | drift
"""
# ── Developer Attribution (v16.45) ─────────────────────────────────────────
__author__  = "Das Apurba"
__team__    = "FCDAI Analytics"
__version__ = "16.74.0"

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional
import sys

# v16.36: Business-language narrative engine
try:
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from utils.business_rules import build_business_narrative, build_action_required
    _HAS_BIZ_RULES = True
except Exception:
    _HAS_BIZ_RULES = False

try:
    import networkx as nx

    _HAS_NX = True
except ImportError:
    _HAS_NX = False

try:
    from scipy.stats import (
        rankdata as _scipy_rankdata,
    )  # v15.11: module-level import (was inside score() — slow first-call)
except ImportError:
    _scipy_rankdata = None

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import PIPELINE
from utils.logger import log_audit, log_data_transform
from utils.persistence import store_or_load

# v14.1: Binary/flag columns that should NOT be averaged into family score
# (they are 0/1 flags; including them in mean dilutes the continuous signals)
# v15.8: Added benfords_second_anomaly and potential_ctr_avoidance.
# v15.22: Added is_scripted_regular (Goh-Barabasi B<-0.3, automated bot signal),
#         is_temporal_relay (time-ordered A→B→C relay node, layering chain signal),
#         is_powerlaw_tail (degree in extreme tail of power-law fit, structural anomaly).
_BINARY_COLS = {
    "is_burst",
    "benfords_anomaly",
    "potential_structuring",
    "is_layering_intermediary",
    "motif_circular",
    "benfords_second_anomaly",  # v15.8: second-digit Benford's (structuring tell)
    "potential_ctr_avoidance",  # v15.8: CTR-bracket avoidance flag
    "is_scripted_regular",  # v15.22: Goh-Barabasi B<-0.3 (automated/bot pattern)
    "is_temporal_relay",  # v15.22: relay in timed A→B→C chain (layering)
    "is_powerlaw_tail",  # v15.22: degree in extreme structural tail (<1% expected)
}

# v15.12 C4: Module-level constant — was recreated inside score() loop per-family
# (~10 re-allocations per run). Defined once at import time, zero runtime cost.
# v15.22 FIX-BFLAG: Total boost capped at 0.30 per node (was uncapped, max +0.70).
# Justification: stacking 7 binary flags additively up to +0.70 overstates evidence
# strength in the absence of a statistical model. A 0.30 ceiling preserves relative
# ranking (severe = multiple flags) while preventing score over-inflation.
# v16.5 Rule-4: Values now driven by config.yaml > scoring > binary_flag_weights.
# Fallback dict below is used ONLY when config is unavailable (offline cold-start).
_BINARY_FLAG_WEIGHTS: dict = getattr(
    PIPELINE,
    "BINARY_FLAG_WEIGHTS",
    {
        "motif_circular": 0.15,
        "potential_structuring": 0.12,
        "potential_ctr_avoidance": 0.12,  # v15.8
        "is_layering_intermediary": 0.10,
        "is_scripted_regular": 0.10,  # v15.22: Goh-Barabasi bot pattern (newly added)
        "is_temporal_relay": 0.10,  # v15.22: timed A→B→C relay chain
        "benfords_second_anomaly": 0.09,  # v15.8
        "is_powerlaw_tail": 0.08,  # v15.22: structural degree anomaly
        "benfords_anomaly": 0.08,
        "is_burst": 0.04,
    },
)
# v16.5 Rule-4: Cap also config-driven; fallback 0.30 preserves v15.22 behaviour.
_BINARY_FLAG_BOOST_CAP: float = getattr(PIPELINE, "BINARY_FLAG_BOOST_CAP", 0.30)


# v16.4 GAP-7: Unified normalisation helper — used at BOTH intra-family level and
# cross-family F1 level so the chosen method is consistent end-to-end.
# ─────────────────────────────────────────────────────────────────────────────
# Method rationale for unsupervised AML inference:
#   rank   (DEFAULT) — (rank-1)/(n-1).  Outlier-immune, run-size stable.
#                      Same as v14–v16.3 default.  Recommended for all deployments.
#   minmax            — (x-min)/(max-min+ε).  Preserves relative score magnitudes.
#                      Sensitive to a single extreme-value outlier node.
#   zscore            — (x-μ)/σ clipped ±3σ → [0,1].  Assumes ~Normal distribution.
#                      Most AML raw metrics are NOT normal (heavy-tail, zero-inflated).
#   robust            — (x-median)/IQR clipped ±3IQR → [0,1].
#                      Best for skewed / heavy-tail AML data: Benford's Z-scores,
#                      IsolationForest anomaly scores, Goh-Barabasi burstiness.
# Air-gap: rank uses already-imported scipy.stats.rankdata (installed dep).
#          minmax / zscore / robust use numpy only — ZERO new pip installs.
# Shape:   input (n, m) → output (n, m), all values ∈ [0.0, 1.0].
#          Single-row (n=1) → 0.5 (neutral — no peer comparison possible).
def _normalise_mat(vals: np.ndarray, method: str) -> np.ndarray:
    """Normalise 2-D float matrix (n_nodes × n_cols) to [0,1] per column.
    method: 'rank' | 'minmax' | 'zscore' | 'robust'  (unknown → rank fallback)
    """
    n = vals.shape[0]
    if n <= 1:
        return np.full_like(vals, 0.5, dtype=float)
    if method == "rank":
        try:
            _rdf = (
                _scipy_rankdata
                if _scipy_rankdata is not None
                else (lambda x, axis=0: np.argsort(np.argsort(x, axis=axis), axis=axis) + 1.0)
            )
            rk = _rdf(vals, axis=0)  # 1..n per column (C-level via scipy)
            return (rk - 1.0) / (n - 1.0)
        except Exception:
            rk = np.argsort(np.argsort(vals, axis=0), axis=0) + 1.0
            return (rk - 1.0) / (n - 1.0)
    elif method == "minmax":
        mn = vals.min(axis=0)
        mx = vals.max(axis=0)
        denom = (mx - mn).clip(1e-8)
        return np.clip((vals - mn) / denom, 0.0, 1.0)
    elif method == "zscore":
        mu = vals.mean(axis=0)
        sd = vals.std(axis=0, ddof=0).clip(1e-8)
        z = (vals - mu) / sd
        # Map ±3σ window to [0,1]; values outside window clamped to 0 or 1
        return np.clip((z + 3.0) / 6.0, 0.0, 1.0)
    elif method == "robust":
        med = np.median(vals, axis=0)
        q75 = np.percentile(vals, 75, axis=0)
        q25 = np.percentile(vals, 25, axis=0)
        iqr = (q75 - q25).clip(1e-8)
        r = (vals - med) / iqr
        # Map ±3×IQR window to [0,1]; values outside window clamped
        return np.clip((r + 3.0) / 6.0, 0.0, 1.0)
    else:
        # Unknown method: safe fallback to rank
        try:
            _rdf = (
                _scipy_rankdata
                if _scipy_rankdata is not None
                else (lambda x, axis=0: np.argsort(np.argsort(x, axis=axis), axis=axis) + 1.0)
            )
            rk = _rdf(vals, axis=0)
            return (rk - 1.0) / (n - 1.0)
        except Exception:
            return np.clip(vals / vals.max(axis=0).clip(1e-8), 0.0, 1.0)


class ScoringLayer:
    """v14.1: Percentile-based tiers + explicit 10-family weights. Fully defensive."""

    def __init__(self) -> None:
        self.weights = PIPELINE.RISK_WEIGHTS
        self.tiers = PIPELINE.RISK_TIERS
        self.tier_mode = PIPELINE.RISK_TIER_MODE  # 'percentile' or 'absolute'
        self.tier_pct = PIPELINE.RISK_TIER_PERCENTILES  # {P1: 1.0, P2: 5.0, P3: 15.0}
        self.min_tier_score = PIPELINE.MIN_TIER_SCORE  # v14.3: {P1: 20, P2: 15, P3: 10}
        self.propagate = PIPELINE.RISK_PROPAGATION  # v14.3/v14.4: 1-hop propagation
        self.propagation_boost = PIPELINE.RISK_PROPAGATION_BOOST  # v14.5: downstream boost (10)
        self.upstream_boost = PIPELINE.RISK_PROPAGATION_UPSTREAM_BOOST  # v14.5: upstream boost (3)
        self.consensus_multiplier_rate = PIPELINE.CONSENSUS_MULTIPLIER_RATE  # v14.5: 0.015
        self.consensus_effective_cap = getattr(
            PIPELINE, "CONSENSUS_EFFECTIVE_CAP", 5
        )  # v15.23 FIX-CC: cap at 5
        self.intra_family_weights = PIPELINE.INTRA_FAMILY_WEIGHTS  # v14.4 NEW-13
        self.calibrate_post_propagation = getattr(
            PIPELINE, "SCORE_CALIBRATE_POST_PROPAGATION", True
        )  # v14.5 FIX-A
        self.scored_df: Optional[pd.DataFrame] = None

    def score(
        self,
        analytics_results: Dict[str, pd.DataFrame],
        weights: Dict[str, float] = None,
        G=None,  # v14.3: optional nx.DiGraph for 1-hop propagation
        norm_method=None,  # v16.4 GAP-7: 'rank'|'minmax'|'zscore'|'robust'
        tier_override=None,  # v16.4 GAP-2/9: dict {mode, p1, p2, p3} from UI
    ) -> pd.DataFrame:
        weights = weights or self.weights
        # v16.4: resolve normalisation method — UI selection > config default > hardcoded 'rank'
        _norm_method: str = (
            str(norm_method or getattr(PIPELINE, "NORM_METHOD", "rank") or "rank").lower().strip()
        )
        if _norm_method not in ("rank", "minmax", "zscore", "robust"):
            _norm_method = "rank"  # unknown value: safe fallback
        # v16.4: resolve tier override — must be a dict to be used
        _tier_override = tier_override if isinstance(tier_override, dict) else None
        _effective_tier_mode = (
            _tier_override.get("mode", self.tier_mode) if _tier_override else self.tier_mode
        )
        log_audit(
            "SCORING_START",
            f"norm_method={_norm_method} | tier_mode={_effective_tier_mode} | "
            f"weights={list(weights.keys()) if weights else 'default'}",
        )

        # Defensive: empty analytics
        if not analytics_results:
            log_audit("SCORING_SKIP", "No analytics results — returning empty")
            return pd.DataFrame(columns=["node_id", "risk_score", "risk_tier"])

        # Get common node list — try all families until we find one with nodes
        nodes = None
        for df in analytics_results.values():
            if df is not None and "node_id" in df.columns and len(df) > 0:
                nodes = df["node_id"].tolist()
                break

        if not nodes:
            return pd.DataFrame(columns=["node_id", "risk_score", "risk_tier"])

        result = pd.DataFrame({"node_id": nodes})

        # Compute family-level aggregate scores
        family_scores = {}
        for family_name, df in analytics_results.items():
            try:
                if df is None or "node_id" not in df.columns or len(df) == 0:
                    continue

                # FIX-11: Exclude binary flag columns from family mean (they dilute continuous scores)
                numeric_cols = [
                    c
                    for c in df.columns
                    if c != "node_id"
                    and c not in _BINARY_COLS
                    and df[c].dtype in [np.float64, np.float32, np.int64, np.int32, float, int]
                ]

                if not numeric_cols:
                    continue

                vals = df[numeric_cols].values.astype(float)
                vals = np.nan_to_num(vals, nan=0)

                # NEW-04 v14.3: Rank-based normalization (outlier-robust, run-size-stable)
                # (rank-1)/(n-1) maps to [0,1]; immune to single massive-outlier nodes.
                # Under min-max, 1 node with 100K txns collapses 99 others close to 0.
                n_rows = vals.shape[0]
                # v16.4 GAP-7: User-selectable normalisation via _normalise_mat().
                # Method flows from Dashboard dropdown → engine kwarg → this call.
                # Default is 'rank' (backward-compatible with v14–v16.3).
                # _normalise_mat handles n=1 (returns 0.5) and all 4 methods.
                vals = _normalise_mat(vals, _norm_method)

                # NEW-13 v14.4: Intra-family column weights.
                # Per-column importances within each family (configured in scoring.intra_family_weights).
                # If no config for this family → equal weights (backward compatible).
                # Weights are normalized to sum=1; missing columns get zero weight.
                # F15 v16.20: binary_boost intentionally removed from per-family score.
                # Binary flags are structural evidence (exist once per node), not per-family.
                # Applying them inside each family loop caused multi-counting through fusion:
                #   10 families × +0.12 structuring boost = +1.20 raw contribution to final score.
                # Binary boost is now accumulated once post-loop and applied to raw_fused score.
                col_weights_cfg = self.intra_family_weights.get(family_name, {})
                if col_weights_cfg and len(col_weights_cfg) > 0:
                    w_arr = np.array(
                        [col_weights_cfg.get(col, 1.0 / len(numeric_cols)) for col in numeric_cols],
                        dtype=float,
                    )
                    w_sum = w_arr.sum()
                    if w_sum > 0:
                        w_arr /= w_sum  # normalize
                        family_score = np.clip(vals @ w_arr, 0, 1)
                    else:
                        family_score = np.clip(vals.mean(axis=1), 0, 1)
                else:
                    family_score = np.clip(vals.mean(axis=1), 0, 1)
                family_scores[family_name] = family_score
                result[f"score_{family_name}"] = family_score
            except Exception:
                continue  # skip broken families

        # ── F15 v16.20: SINGLE POST-LOOP BINARY BOOST ────────────────────────
        # Accumulate binary flag evidence ONCE across all analytics_results dfs.
        # Each flag is a structural fact about the node — not about any particular
        # analytic family. Applying it once prevents the multi-counting that occurred
        # when it was inside the per-family loop (10 families × boost = 10× inflation).
        # FIX-11 tiered weights / v15.22 cap still applied — just at the right stage.
        _global_binary_boost = np.zeros(len(nodes))
        for _bb_df in analytics_results.values():
            if _bb_df is None or "node_id" not in _bb_df.columns:
                continue
            for bc in _BINARY_COLS:
                if bc in _bb_df.columns:
                    try:
                        _bv = _bb_df[bc].values.astype(float)
                        _bv = np.nan_to_num(_bv, nan=0)
                        _global_binary_boost += _bv * _BINARY_FLAG_WEIGHTS.get(bc, 0.05)
                    except Exception:
                        pass
        # Cap: same _BINARY_FLAG_BOOST_CAP ceiling as before — preserves rank ordering.
        _global_binary_boost = np.clip(_global_binary_boost, 0.0, _BINARY_FLAG_BOOST_CAP)

        # ═══════════════════════════════════════════════════════════════════════
        # v16.3 ADVANCED FUSION ENGINE: F1 + F2 + F4 + F7 + F3 + F5
        # Full rationale in module docstring and SCORING_ENHANCEMENTS.md
        # All operations: numpy/scipy only, offline, air-gap safe, no labels required.
        # ═══════════════════════════════════════════════════════════════════════
        if family_scores:
            n_nodes = len(nodes)
            family_names = list(family_scores.keys())
            n_fam = len(family_names)

            # Build fusion matrix: rows=nodes, cols=families
            fam_matrix = np.column_stack([family_scores[fn] for fn in family_names]).astype(float)

            # v16.19 BUG-8: Track families that contributed all-zero scores.
            # These families failed silently (dependency missing or empty output).
            # Logged in SCORING_COMPLETE warning so investigators see which signals were absent.
            self._zero_family_log = [
                fn for fn in family_names
                if np.max(np.abs(family_scores[fn])) < 1e-9
            ]

            # ── F1: CROSS-FAMILY NORMALISATION (v16.4: method = _norm_method) ──────────
            # Problem: each family writes [0,1] scores but with different distributional
            # shapes — anomaly compressed [0.3-0.7], motifs bimodal [0 / 0.9+], Benford's
            # right-skewed.  Fusing directly = the high-variance family dominates.
            # Fix: normalise the fusion matrix cross-sectionally (all n nodes vs all families)
            # BEFORE the weighted sum.  Every column (family) ends up with equal variance.
            # v16.4: uses _normalise_mat() with the same method as intra-family above →
            # consistent normalisation at both levels, user-controlled via Dashboard.
            if n_nodes > 1 and n_fam >= 1:
                try:
                    fam_matrix = _normalise_mat(fam_matrix, _norm_method)
                    # Cascade updated values back so F5 Borda uses normalised values.
                    for _fi_f1, _fn_f1 in enumerate(family_names):
                        family_scores[_fn_f1] = fam_matrix[:, _fi_f1]
                    log_audit(
                        "FUSION_F1_CROSSNORM",
                        f"F1: cross-family norm method={_norm_method} "
                        f"({n_fam} families, n={n_nodes})",
                    )
                except Exception:
                    pass  # non-fatal; keep raw family scores

            # ── F4: ENTROPY-BASED DYNAMIC WEIGHT ADJUSTMENT ──────────────────
            # A family that fires on ~50% of nodes this run has H(mean)≈1 —
            # it is essentially a coin flip and contributes no discriminative power.
            # A bimodal family (H≈0) deserves its full configured weight.
            # Entropy of the mean score (treated as Bernoulli parameter p):
            #   H(p) = -p·log₂p − (1-p)·log₂(1-p)
            #   discriminativity = 1 − H(p)  ∈ [0,1]
            # effective_weight = config_weight × discriminativity
            # Floor at 0.05 ensures no family is completely killed by one flat run.
            # Dataset-adaptive per run, no labels, no external calls.
            try:
                _cfg_w_f4 = np.array([weights.get(fn, 0.0) for fn in family_names], dtype=float)
                _fam_means_f4 = fam_matrix.mean(axis=0).clip(1e-8, 1 - 1e-8)
                _H_f4 = -_fam_means_f4 * np.log2(_fam_means_f4) - (1.0 - _fam_means_f4) * np.log2(
                    1.0 - _fam_means_f4
                )
                _disc_f4 = np.clip(1.0 - _H_f4, 0.05, 1.0)  # floor=0.05: never kill
                _eff_w_f4 = _cfg_w_f4 * _disc_f4
                _eff_w_sum_f4 = _eff_w_f4.sum()
                if _eff_w_sum_f4 > 0:
                    _eff_w_f4 /= _eff_w_sum_f4  # re-normalise to sum=1
                else:
                    _eff_w_f4 = np.ones(n_fam, dtype=float) / max(n_fam, 1)
                log_audit(
                    "FUSION_F4_ENTROPY",
                    f"F4: entropy-adj weights: { {fn: round(float(w), 4) for fn, w in zip(family_names, _eff_w_f4)} }",
                )
            except Exception:
                _eff_w_f4 = np.ones(n_fam, dtype=float) / max(n_fam, 1)

            # ── F8: CORRELATED FAMILY DEWEIGHTING (v16.44) ───────────────────
            # Problem: centrality + community both measure structural network position.
            # A hub node is always in a small dense community — these two families fire
            # together on every hub, giving it double credit for ONE structural fact.
            # IsolationForest (anomaly) and structuring both identify cash-heavy
            # behavioural outliers — same signal proxied twice in high-cash portfolios.
            # Measured correlation: ρ ≈ 0.65 in scale-free transaction graphs.
            # Fix: when BOTH members of a configured pair are present in this run,
            # multiply each member's entropy-adjusted weight by correlation_penalty (0.65).
            # Net effect: pair total = 1.30× instead of 2.00× → 35% pseudo-replication
            # removed. Non-fatal: if one pair member is absent, no penalty is applied.
            # Weights re-normalised to sum=1 after all penalties so scale is unchanged.
            # Unsupervised. No labels. No external calls. Pure config + numpy.
            try:
                _corr_pairs = getattr(
                    PIPELINE, "CORRELATED_FAMILY_PAIRS",
                    [["centrality", "community"], ["anomaly", "structuring"]]
                )
                _corr_penalty = float(getattr(PIPELINE, "CORRELATION_PENALTY", 0.65))
                _fn_set_f8 = set(family_names)
                _corr_applied_f8 = []
                for _pair_f8 in _corr_pairs:
                    if (
                        isinstance(_pair_f8, (list, tuple))
                        and len(_pair_f8) == 2
                        and str(_pair_f8[0]) in _fn_set_f8
                        and str(_pair_f8[1]) in _fn_set_f8
                    ):
                        _i0_f8 = family_names.index(str(_pair_f8[0]))
                        _i1_f8 = family_names.index(str(_pair_f8[1]))
                        _eff_w_f4[_i0_f8] *= _corr_penalty
                        _eff_w_f4[_i1_f8] *= _corr_penalty
                        _corr_applied_f8.append(f"{_pair_f8[0]}+{_pair_f8[1]}")
                # Re-normalise so all weights still sum to 1 after penalties
                _eff_w_sum_f8 = _eff_w_f4.sum()
                if _eff_w_sum_f8 > 0:
                    _eff_w_f4 /= _eff_w_sum_f8
                if _corr_applied_f8:
                    log_audit(
                        "FUSION_F8_CORRDEWEIGHT",
                        f"F8: penalty={_corr_penalty} applied to correlated pairs: "
                        f"{_corr_applied_f8} | weights renormalised",
                    )
            except Exception:
                pass  # non-fatal: F4 weights unchanged if F8 errors

            # ── F2: CONSERVATIVE ORDERED WEIGHTED AVERAGING (OWA) ────────────
            # Per-node: sort family scores descending, apply fixed rank-order weights.
            # OWA weight shape [0.25, 0.18, 0.14, 0.11, 0.09, 0.07, 0.05, 0.04, 0.04, 0.03]:
            #   Each node's BEST-SIGNAL family always gets 0.25.
            #   For a genuine typology case: 1 family fires at 0.95, rest near 0 →
            #     OWA = 0.25*0.95 + 0.18*0.05 + … ≈ 0.25 (35% of full P1 signal preserved)
            #   For multi-family consensus: 6 families all at 0.80 →
            #     OWA = 0.25*0.80 + 0.18*0.80 + … = 0.80 (full signal preserved)
            # Conservative vs. aggressive: top slot 0.25 (conservative) not 0.40 (aggressive).
            # This avoids over-rewarding single narrow-test positives.
            # F16 v16.20: Exclude all-zero families from OWA so their weight slots are
            # redistributed to active families. Zero families are those in _zero_family_log
            # (failed dependencies or empty outputs). Without this fix, a run with 4 of 10
            # families failed wastes 40% of OWA weight capacity on zero slots.
            try:
                _owa_shape_f2 = np.array(
                    [0.25, 0.18, 0.14, 0.11, 0.09, 0.07, 0.05, 0.04, 0.04, 0.03]
                )
                # F16: Build active-family matrix (exclude all-zero families for OWA)
                _zero_set_f2 = set(self._zero_family_log) if hasattr(self, "_zero_family_log") else set()
                _active_idx_f2 = [
                    i for i, fn in enumerate(family_names)
                    if fn not in _zero_set_f2
                ]
                if len(_active_idx_f2) == 0:
                    _active_idx_f2 = list(range(n_fam))  # fallback: use all
                _owa_mat_f2 = fam_matrix[:, _active_idx_f2]  # (n, n_active)
                _n_active_f2 = len(_active_idx_f2)
                if _n_active_f2 <= len(_owa_shape_f2):
                    _owa_w_f2 = _owa_shape_f2[:_n_active_f2]
                else:
                    _pad_f2 = np.array(
                        [max(0.01, 0.02 * (0.8**i)) for i in range(_n_active_f2 - len(_owa_shape_f2))]
                    )
                    _owa_w_f2 = np.concatenate([_owa_shape_f2, _pad_f2])
                _owa_w_f2 = _owa_w_f2 / _owa_w_f2.sum()  # ensure sum=1.0 over active families
                # Sort per node descending, apply OWA weights
                _sorted_fam_f2 = np.sort(_owa_mat_f2, axis=1)[:, ::-1]  # (n, n_active) descending
                owa_score_f2 = (_sorted_fam_f2[:, :_n_active_f2] * _owa_w_f2).sum(axis=1)  # (n,)
                _n_zero_f2 = n_fam - _n_active_f2
                log_audit(
                    "FUSION_F2_OWA",
                    f"F2: conservative OWA top-slot={_owa_w_f2[0]:.3f} over {_n_active_f2} active families"
                    f" ({_n_zero_f2} zero-families excluded, weight redistributed)",
                )
            except Exception:
                owa_score_f2 = fam_matrix.mean(axis=1)  # safe fallback

            # ── F7: MAX-AVG HYBRID ───────────────────────────────────────────
            # Problem: even with OWA, a pure weighted-average floor dilutes extreme signals.
            # Hybrid = α×max + (1-α)×entropy_weighted_avg where α=0.25 (conservative).
            # The max() term ensures that if ONE family scores 0.95 (statistically
            # improbable without criminal intent — e.g. Benford Z>3), that signal cannot
            # be drowned below 0.25×0.95 = 0.2375 by averaging alone.
            # α=0.25 avoids over-weighting single narrow tests.
            try:
                _max_f7 = fam_matrix.max(axis=1)  # (n,)
                _wavg_f7 = (fam_matrix * _eff_w_f4[np.newaxis, :]).sum(axis=1)  # (n,)
                _alpha_f7 = float(getattr(PIPELINE, "FUSION_MAX_AVG_ALPHA", 0.25))
                wavg_score_f7 = _alpha_f7 * _max_f7 + (1.0 - _alpha_f7) * _wavg_f7
                log_audit("FUSION_F7_MAXAVG", f"F7: max-avg hybrid α={_alpha_f7:.2f}")
            except Exception:
                wavg_score_f7 = (fam_matrix * _eff_w_f4[np.newaxis, :]).sum(axis=1)

            # ── FINAL BLEND: 60% OWA + 40% max-avg ──────────────────────────
            # OWA rewards per-node best signals; max-avg preserves global importance
            # weights and extreme-value protection.  60/40 blend from simulation
            # on synthetic AML portfolios — see SCORING_ENHANCEMENTS.md §7.
            _owa_blend_f = float(getattr(PIPELINE, "FUSION_OWA_BLEND", 0.60))
            _fused_pre_boost = _owa_blend_f * owa_score_f2 + (1.0 - _owa_blend_f) * wavg_score_f7
            # F15 v16.20: Apply binary evidence boost ONCE post-fusion.
            # Converting boost from [0,1] to [0,100] scale to match risk_score domain;
            # applied here before the final *100 conversion so arithmetic is consistent.
            # Cap already applied above (_BINARY_FLAG_BOOST_CAP); this just places it.
            raw_score = np.clip(_fused_pre_boost + _global_binary_boost, 0.0, 1.0)
            log_audit(
                "FUSION_F15_BINARYBOOST",
                f"F15: single post-fusion binary boost applied: "
                f"max={float(_global_binary_boost.max()):.3f}, "
                f"nodes_boosted={int((_global_binary_boost > 0).sum())}/{len(nodes)}",
            )

            # Persist F1-rank-normalised scores for each family (overwrite pre-F1 values)
            # so UI and reports show consistent, scale-comparable per-family scores.
            for _fi_store, _fn_store in enumerate(family_names):
                result[f"score_{_fn_store}"] = np.round(fam_matrix[:, _fi_store], 4)

            result["risk_score"] = np.clip(raw_score * 100, 0, 100).round(1)
            log_audit(
                "FUSION_COMPLETE",
                f"v16.3 fusion: {n_fam} families | OWA-blend={_owa_blend_f:.2f} | n={n_nodes}",
            )
        else:
            result["risk_score"] = 0.0

        # ── F3: INTER-FAMILY DISAGREEMENT SPIKE SUPPRESSION ──────────────────
        # Problem (false positive typology): Benford's first-digit test fires 0.95
        # on a single account. All 9 other families see 0.02-0.08 — nothing suspicious.
        # The account is likely a small business with few transactions (low sample
        # size for Benford's = benign). Post-fusion score WITHOUT F3 ≈ 0.52 (P2).
        # F3 identifies: max > 0.70 AND std > 0.22 AND fewer than 2 families agree ≥ 0.50.
        # This three-condition gate prevents penalising genuine multi-family P1 nodes:
        #   - std > 0.22 fails for multi-family consensus (all high = low std)
        #   - n_agree < 2 fails if even 2 families both see something
        # Penalty: 0.88× score multiplier (≈ one tier-step reduction, not elimination).
        # Adds single_family_spike=1 column as audit trail for reviewer transparency.
        # Only active when ≥ 3 families are present (trivial with 10-family architecture).
        if family_scores and len(family_scores) >= 3:
            try:
                _fam_arr_f3 = np.column_stack(list(family_scores.values())).astype(float)
                _f3_max = _fam_arr_f3.max(axis=1)
                _f3_std = _fam_arr_f3.std(axis=1)
                _f3_nagree = (_fam_arr_f3 > 0.50).sum(axis=1)
                _spike_mask = (_f3_max > 0.70) & (_f3_std > 0.22) & (_f3_nagree < 2)
                if _spike_mask.any():
                    _f3_penalty = float(getattr(PIPELINE, "FUSION_SPIKE_PENALTY", 0.88))
                    _sc_f3 = result["risk_score"].values.astype(float).copy()
                    _sc_f3[_spike_mask] = np.clip(
                        np.round(_sc_f3[_spike_mask] * _f3_penalty, 1), 0, 100
                    )
                    result["risk_score"] = _sc_f3
                    result["single_family_spike"] = _spike_mask.astype(int)
                    log_audit(
                        "FUSION_F3_DISAGREE",
                        f"F3: spike-penalty={_f3_penalty} applied to {int(_spike_mask.sum())} nodes",
                    )
                else:
                    result["single_family_spike"] = 0
            except Exception:
                result["single_family_spike"] = 0
        else:
            result["single_family_spike"] = 0

        # ── F5: BORDA COUNT CONSENSUS ─────────────────────────────────────────
        # Replaces binary above-median consensus_count (old v14.3 method).
        # OLD method flaw: family scoring 0.51 counted same as 0.99 — magnitude ignored.
        # Borda count: for each family, rank all nodes 1..n (rank 1 = lowest risk).
        # Each node's Borda score = sum of its rank positions across all families.
        # Normalise: borda_norm = (borda_sum - n_fam) / (n_fam × (n-1))  ∈ [0,1].
        # Scale output to [0,10] (same slot as old consensus_count) for backward compat.
        # Condorcet theorem: rank aggregation dominates binary voting for discriminating
        # between candidates (nodes) when underlying preferences (family scores) are noisy.
        # Graceful: n=1 or no families → output 0; non-fatal.
        if family_scores and len(family_scores) > 0:
            try:
                _fam_borda = np.column_stack(list(family_scores.values())).astype(float)
                _n_b, _f_b = _fam_borda.shape
                if _n_b > 1:
                    _rdf_b = (
                        _scipy_rankdata
                        if _scipy_rankdata is not None
                        else (
                            lambda x, axis=0, method="average": (
                                np.argsort(np.argsort(x, axis=axis), axis=axis) + 1.0
                            )
                        )
                    )
                    _borda_ranks = _rdf_b(_fam_borda, axis=0)  # (n, f) ranks 1..n
                    _borda_sum = _borda_ranks.sum(axis=1)  # (n,)
                    _borda_min = float(_f_b) * 1.0  # all ranked last
                    _borda_max = float(_f_b) * float(_n_b)  # all ranked first
                    _borda_norm = (_borda_sum - _borda_min) / max(_borda_max - _borda_min, 1e-8)
                    # Scale to [0,10] integer for backward compat with downstream
                    result["consensus_count"] = np.clip(
                        np.round(_borda_norm * 10).astype(int), 0, 10
                    )
                    log_audit(
                        "FUSION_F5_BORDA",
                        f"F5: Borda consensus (n_fam={_f_b}, n={_n_b}) supersedes binary above-median",
                    )
                else:
                    result["consensus_count"] = 0
            except Exception:
                result["consensus_count"] = 0
        else:
            result["consensus_count"] = 0

        # Consensus → multiplicative confidence boost (unchanged logic, now uses Borda score).
        # v16.3: consensus_count is now Borda-based [0-10] — same numeric range as before
        # so the multiplier formula is unchanged: score × (1 + rate × min(cc, cap)).
        # cap=5 remains appropriate: Borda 5/10 = consistent above-median across all families.
        # rate=0.015: at cap=5 → max 1.075× multiplier (conservative, non-inflating).
        try:
            cc_arr = result["consensus_count"].values.astype(float)
            cc_arr_capped = np.minimum(cc_arr, float(self.consensus_effective_cap))
            base_sc = result["risk_score"].values.astype(float)
            result["risk_score"] = np.clip(
                np.round(base_sc * (1.0 + self.consensus_multiplier_rate * cc_arr_capped), 1),
                0,
                100,
            )
            log_audit(
                "BORDA_BOOST",
                f"Borda consensus multiplier rate={self.consensus_multiplier_rate:.3f} cap={self.consensus_effective_cap}",
            )
        except Exception:
            pass

        # v15.5 FIX (NEW-06/NEW-08): Multiplicative decay propagation replaces flat additive boosts.
        # Problem with additive +10/+5/+3/+1.5: a scale-free hub with 500 successors pushes 10%
        # of all nodes to near-100 score uniformly regardless of transaction size — contaminates
        # clean accounts that happened to receive $1 from a suspicious node.
        # Multiplicative decay: score(successor) = max(current, parent_score * edge_weight_norm * decay)
        #   decay_down=0.3: 1st-hop downstream gets max 30% of parent; $9K edge on $50K-flow hub
        #   gives 0.5 * 0.3 = 15-point boost only. Naturally attenuates for low-weight edges.
        #   decay_up=0.15 (half of down): upstream signal is secondary (sender may be victim/mule).
        #   max() semantics: propagation only raises scores, never lowers a legitimately high scorer.
        if self.propagate and G is not None and _HAS_NX:
            try:
                node_to_idx = {n: i for i, n in enumerate(nodes)}
                scores_arr = result["risk_score"].values.copy().astype(float)
                decay_down = float(getattr(PIPELINE, "RISK_PROPAGATION_DECAY", 0.3))
                decay_up = decay_down * 0.5  # upstream weaker — sender may be legitimate
                n_s = len(scores_arr)
                p1_thresh = (
                    np.percentile(scores_arr, 100.0 - self.tier_pct.get("P1", 1.0))
                    if n_s >= 4
                    else scores_arr.max()
                )
                # Only nodes scoring >= 50% of P1 threshold emit propagation (avoids noise spread)
                min_propagate = p1_thresh * 0.5
                # Pre-compute max edge weight for normalization
                # v15.13 D2: bulk dict fetch vs generator over G.edges (faster for large graphs)
                _ew_dict = nx.get_edge_attributes(G, "weight")
                max_edge_w = float(max(_ew_dict.values())) if _ew_dict else 1.0
                if max_edge_w <= 0:
                    max_edge_w = 1.0
                # v15.12 A1: Vectorized propagation — same max() semantics as original nested loops
                # but using numpy edge arrays + np.maximum.at (~15-30x faster for large graphs).
                # Air-gap safe: pure numpy, no external calls. Identical math to v15.11.
                _valid_set = set(node_to_idx.keys())  # C7: O(1) membership check
                _edge_triples = [
                    (
                        node_to_idx[u],
                        node_to_idx[v],
                        min(float(d.get("weight", 1) or 1) / max_edge_w, 1.0),
                    )
                    for u, v, d in G.edges(data=True)
                    if u in _valid_set and v in _valid_set and node_to_idx[u] != node_to_idx[v]
                ]
                # v16.2 C2: 2-round iterative propagation catches up to 3-hop layering chains.
                # Round 1: direct P1 neighbours boosted (same as v16.1).
                # Round 2: second-degree neighbours boosted via already-boosted round-1 scores.
                # Effective hop-2 decay = 0.30^2 = 0.09 — meaningful but not over-inflating.
                # max() semantics preserved every round: scores only rise, never fall.
                prop_rounds = int(getattr(PIPELINE, "RISK_PROPAGATION_ROUNDS", 2))
                if _edge_triples:
                    _e_src = np.array([e[0] for e in _edge_triples], dtype=np.int32)
                    _e_dst = np.array([e[1] for e in _edge_triples], dtype=np.int32)
                    _e_w = np.array([e[2] for e in _edge_triples], dtype=np.float64)
                    for _prop_round in range(max(1, prop_rounds)):
                        # DOWNSTREAM: re-reads updated scores_arr each round
                        _down_mask = scores_arr[_e_src] >= min_propagate
                        _src_norm = scores_arr[_e_src] / 100.0
                        _prop_down = np.where(
                            _down_mask, _src_norm * _e_w * decay_down * 100.0, 0.0
                        )
                        np.maximum.at(scores_arr, _e_dst, _prop_down)
                        # UPSTREAM: high-risk dst raises score of sender
                        _up_mask = scores_arr[_e_dst] >= min_propagate
                        _dst_norm = scores_arr[_e_dst] / 100.0
                        _prop_up = np.where(_up_mask, _dst_norm * _e_w * decay_up * 100.0, 0.0)
                        np.maximum.at(scores_arr, _e_src, _prop_up)
                result["risk_score"] = np.clip(np.round(scores_arr, 1), 0, 100)
                log_audit(
                    "PROPAGATION",
                    f"Multiplicative decay: down={decay_down:.2f}, up={decay_up:.2f} | "
                    f"rounds={prop_rounds} | edge-weight-normalized | max-only | min_emit={min_propagate:.1f}",
                )
            except Exception:
                pass  # propagation failure is non-fatal

        # v14.5 FIX-A: Post-propagation rank calibration.
        # Problem: in scale-free networks (power-law degree), a single P1 hub may have
        # 30-50% of all nodes as 1-hop successors. Each gets +10-15 boost => 30-40%
        # nodes land above 80 => all classified P1/Critical. This is statistically
        # impossible in a real AML portfolio (investigator capacity = ~1-2% of customers).
        # Solution: after all boosts, re-rank scores so the distribution fits [0,100]
        # using a non-linear rank-based re-scaling:
        #   calibrated_score = rank_percentile * 100
        # This PRESERVES relative order and tier assignment (top 1% stays P1)
        # while ensuring scores spread across the full [0,100] range.
        # The original raw_score before calibration is stored as pre_calib_score.
        if self.calibrate_post_propagation:
            try:
                raw_final = result["risk_score"].values.astype(float)
                result["pre_calib_score"] = np.round(raw_final, 1)  # audit trail
                n_cal = len(raw_final)
                if n_cal > 1:
                    # Rank-based re-scaling: rank 0 = lowest, rank n-1 = highest
                    # Use fractional rank to handle ties fairly
                    # v15.11: use module-level _scipy_rankdata (no repeated import overhead)
                    _rdf = (
                        _scipy_rankdata
                        if _scipy_rankdata is not None
                        else (
                            lambda x, method="average": np.argsort(np.argsort(x)).astype(float) + 1
                        )
                    )
                    ranks = _rdf(raw_final, method="average")  # 1..n
                    # Map to [0,100]: (rank-1)/(n-1)*100 — but use power transform
                    # to spread mid-range: p=0.6 gives more distinction in upper half
                    pct = (ranks - 1) / (n_cal - 1)  # [0,1]
                    # Non-linear: gives ~log-normal shape (realistic AML distribution)
                    # pct^0.6 compresses high end; multiply back to 0-100
                    calibrated = np.round(np.power(pct, 0.65) * 100, 1)
                    result["risk_score"] = np.clip(calibrated, 0, 100)
                    log_audit(
                        "SCORE_CALIBRATION",
                        f"Post-propagation calibration applied: "
                        f"pre-calib max={raw_final.max():.1f} -> calib max={calibrated.max():.1f} "
                        f"| old mean={raw_final.mean():.1f} -> new mean={calibrated.mean():.1f}",
                    )
            except Exception:
                pass  # calibration failure is non-fatal; keep scores as-is

        # ── F6: RISK PROBABILITY — EMPIRICAL CDF ─────────────────────────────
        # Problem: risk_score=72 is opaque — is that 95th or 65th percentile?
        # Investigators need: "this account has higher risk than X% of all accounts"
        # (relative standing, not arbitrary 0-100 scale).
        # Implementation: empirical CDF = (rank - 1) / (n - 1).
        #   rank 1 = lowest-risk node  → risk_probability = 0.00
        #   rank n = highest-risk node → risk_probability = 1.00
        # This is fully non-parametric (no Beta distribution fit — too noisy on small n).
        # Air-gap safe: pure numpy. Added column: risk_probability ∈ [0.00, 1.00].
        # Backward compat: no existing column renamed or removed.
        try:
            _sc_f6 = result["risk_score"].values.astype(float)
            _n_f6 = len(_sc_f6)
            if _n_f6 > 1:
                _rdf_f6 = (
                    _scipy_rankdata
                    if _scipy_rankdata is not None
                    else (lambda x, method="average": np.argsort(np.argsort(x)).astype(float) + 1)
                )
                _ranks_f6 = _rdf_f6(_sc_f6, method="average")  # 1..n
                result["risk_probability"] = np.round(
                    (_ranks_f6 - 1.0) / (_n_f6 - 1.0), 4
                )  # 0.00 = lowest peer; 1.00 = highest peer
                log_audit(
                    "FUSION_F6_PROBCALIB",
                    f"F6: risk_probability empirical CDF assigned (n={_n_f6})",
                )
            else:
                result["risk_probability"] = 0.5  # neutral for single-node run
        except Exception:
            result["risk_probability"] = 0.0  # non-fatal; investigator still has risk_score

        # NEW-07 / FIX-09: Tier assignment AFTER propagation (uses final boosted scores)
        # v16.4: pass _tier_override so UI-selected mode/cutpoints take effect
        result["risk_tier"] = self._assign_tiers_vectorized(
            result["risk_score"].values, tier_override=_tier_override
        )

        # Audit log
        try:
            tier_counts = result["risk_tier"].value_counts().to_dict()
            log_audit(
                "SCORING_COMPLETE",
                f"Scored {len(result)} nodes | Tiers: {tier_counts} | mode={self.tier_mode} | prop={self.propagate}",
            )
            # v16.19 BUG-5: Warn investigators when dataset is too small for meaningful
            # tier differentiation. With n < 50 the min-score gate (min_p1=20) may produce
            # zero P1/P2 nodes even though all-P4 is statistically correct. Surface this
            # explicitly so investigators know the result is inconclusive, not "clean".
            _n_nodes_scored = len(result)
            _p1_count = tier_counts.get("P1", 0)
            _p2_count = tier_counts.get("P2", 0)
            if _n_nodes_scored < 50 and _p1_count == 0 and _p2_count == 0:
                log_audit(
                    "SCORING_WARN",
                    f"SMALL_DATASET: n={_n_nodes_scored} < 50. All nodes returned P4 (no alerts). "
                    f"Minimum 50 nodes recommended for statistically meaningful tier assignment. "
                    f"Increase max_customers in Port Authority for reliable AML detection.",
                )
            # v16.19 BUG-8: Warn when any scoring family contributed all-zero normalised scores.
            # This indicates a family failed silently (e.g. pyod/sklearn unavailable).
            # The OWA handles zeros gracefully (they sort to lowest weight) but investigators
            # should know which families were effectively absent from the analysis.
            if hasattr(self, "_zero_family_log") and self._zero_family_log:
                log_audit(
                    "SCORING_WARN",
                    f"ZERO_FAMILY_CONTRIB: Families with all-zero scores (silently excluded from signal): "
                    f"{self._zero_family_log}. Check analytics dependencies (pyod, sklearn, igraph).",
                )
        except Exception:
            log_audit("SCORING_COMPLETE", f"Scored {len(result)} nodes")

        # v15.6: Pull SCC/temporal node attributes computed by l3_graph + l2_aggregate
        # into the scored DataFrame so evidence codes can reference them.
        if G is not None and _HAS_NX:
            try:
                _pull_attrs = [
                    "in_ring",
                    "scc_size",
                    "temporal_circular_flow_count",
                    "temporal_burst_count",
                    "temporal_circular_flow_value",
                ]
                for _attr in _pull_attrs:
                    if _attr not in result.columns:
                        result[_attr] = [
                            float(G.nodes.get(n, {}).get(_attr, 0) or 0)
                            for n in result["node_id"].values
                        ]
            except Exception:
                pass

        # v15.6: Compile plain-English evidence codes — one readable string per customer.
        # Investigators receive an actionable narrative instead of a raw number.
        try:
            self._compile_evidence_inplace(result)
        except Exception:
            pass

        # v15.22 NEW-ROLE: Classify each node into an AML role.
        # Executed AFTER evidence compilation so role label is added to evidence_summary.
        try:
            self._classify_aml_roles_inplace(result, G)
        except Exception:
            pass

        # v15.23 NEW-DRIFT: Tier score drift tracking — run-over-run escalation detection.
        # ─────────────────────────────────────────────────────────
        # P2→P1 escalation between consecutive pipeline runs is the single most actionable
        # AML alert: it means a customer's risk profile has WORSENED since the last analysis.
        # An account that was 'watch' last run and is now 'critical' this run requires
        # IMMEDIATE investigator attention — their behaviour has intensified.
        #
        # Implementation:
        #   1. Open the SQLite DB (read-only lightweight query)
        #   2. Find the most recently saved scored_results row (= previous run)
        #   3. Parse its JSON, build node_id → prev_tier lookup
        #   4. Add columns: prev_tier, tier_change, tier_escalated
        #
        # Columns added:
        #   prev_tier:     tier from the previous run ('P4' if node is new)
        #   tier_change:   'STABLE' | 'ESCALATED (P2→P1)' | 'IMPROVED (P1→P2)'
        #   tier_escalated: 1 = risk has increased; 0 = stable or improved
        #
        # Business value: investigators immediately see which accounts have MOVED UP
        # in risk tier since the last analysis — without manually comparing two reports.
        # Graceful: if DB missing / first run / any error → all STABLE, no crash.
        try:
            import sqlite3 as _sqlite3
            from pathlib import Path as _Path

            _db_path = str(PIPELINE.DB_PATH)
            if _Path(_db_path).exists():
                _prev_conn = _sqlite3.connect(_db_path, timeout=3)
                _prev_conn.row_factory = _sqlite3.Row
                # Get most recently saved scored_results (= previous completed run)
                _prev_row = _prev_conn.execute(
                    "SELECT data FROM scored_results ORDER BY id DESC LIMIT 1"
                ).fetchone()
                _prev_conn.close()
                if _prev_row is not None:
                    import json as _json

                    _prev_data = _json.loads(_prev_row["data"])
                    _prev_df = pd.DataFrame(_prev_data)
                    if "node_id" in _prev_df.columns and "risk_tier" in _prev_df.columns:
                        _prev_tier_map = dict(
                            zip(_prev_df["node_id"].astype(str), _prev_df["risk_tier"].astype(str))
                        )
                        _tier_order = {"P1": 1, "P2": 2, "P3": 3, "P4": 4}
                        _node_ids = result["node_id"].astype(str).tolist()
                        _curr_tiers = result["risk_tier"].tolist()
                        _prev_tiers, _changes, _escalated = [], [], []
                        for _nd, _ct in zip(_node_ids, _curr_tiers):
                            _pt = _prev_tier_map.get(_nd, "P4")  # P4 = new/unknown node
                            _po = _tier_order.get(_pt, 4)
                            _co = _tier_order.get(_ct, 4)
                            _prev_tiers.append(_pt)
                            if _po == _co:
                                _changes.append("STABLE")
                                _escalated.append(0)
                            elif _co < _po:  # lower number = higher risk = ESCALATED
                                _changes.append(f"ESCALATED ({_pt}→{_ct})")
                                _escalated.append(1)
                            else:
                                _changes.append(f"IMPROVED ({_pt}→{_ct})")
                                _escalated.append(0)
                        result["prev_tier"] = _prev_tiers
                        result["tier_change"] = _changes
                        result["tier_escalated"] = _escalated
                        _n_esc = sum(_escalated)
                        log_audit(
                            "TIER_DRIFT",
                            f"Tier drift computed: {_n_esc} accounts ESCALATED this run",
                        )
        except Exception:
            pass  # tier drift is non-fatal; first run or DB missing = silent skip

        self.scored_df = result
        try:
            store_or_load("stage6_scored", result)
        except Exception:
            pass

        return result

    def _assign_tiers_vectorized(self, scores: np.ndarray, tier_override=None) -> np.ndarray:
        """
        FIX-09: Percentile-based tier assignment.
        'percentile' mode: P1=top 1%, P2=top 5%, P3=top 15%, P4=rest.
        'absolute' mode: hard score thresholds from config or UI override.
        Handles edge case: n < 4 nodes.
        v16.4 GAP-2/9: tier_override dict {mode, p1, p2, p3} takes precedence over config.
        """
        # v16.4: resolve overrides — UI values beat config; config beats hardcoded defaults
        _mode = (
            str(tier_override.get("mode", self.tier_mode)).lower()
            if tier_override
            else self.tier_mode
        )
        _p1_cfg = (
            float(tier_override.get("p1", self.tier_pct.get("P1", 1.0)))
            if tier_override
            else self.tier_pct.get("P1", 1.0)
        )
        _p2_cfg = (
            float(tier_override.get("p2", self.tier_pct.get("P2", 5.0)))
            if tier_override
            else self.tier_pct.get("P2", 5.0)
        )
        _p3_cfg = (
            float(tier_override.get("p3", self.tier_pct.get("P3", 15.0)))
            if tier_override
            else self.tier_pct.get("P3", 15.0)
        )

        n = len(scores)
        tiers = np.full(n, "P4", dtype=object)

        if n == 0:
            return tiers

        if _mode == "percentile" and n >= 4:
            # Sort descending: rank 0 = highest score
            sorted_idx = np.argsort(scores)[::-1]
            # v16.2 A2: Capacity-aware P1 threshold.
            # P1 = min(configured %, investigation_capacity / n * 100%).
            # On a 1M-node graph with 1000 investigators: capacity_pct=0.1% — beats config 1%.
            # On a 100-node test graph: 1000/100*100=1000% >> 1% — config wins (safe fallback).
            # Prevents alert fatigue: never generate more P1 cases than the team can investigate.
            _inv_cap = float(getattr(PIPELINE, "INVESTIGATION_CAPACITY", 1000))
            _capacity_pct = (_inv_cap / n) * 100.0
            # v16.4: use _p1_cfg/_p2_cfg/_p3_cfg (resolved above from UI or config)
            _p1_pct = min(_p1_cfg, _capacity_pct)
            p1_cut = max(1, int(np.ceil(n * _p1_pct / 100)))
            p2_cut = max(p1_cut + 1, int(np.ceil(n * _p2_cfg / 100)))
            p3_cut = max(p2_cut + 1, int(np.ceil(n * _p3_cfg / 100)))
            # NEW-07 v14.3: Min score gate — no elevated tier if absolute score is too low.
            # On 50-node test graphs the top 1% node may have risk_score=8. Assigning P1=8 is
            # misleading. Gate prevents alerting on uniformly low-risk populations.
            min_p1 = self.min_tier_score.get("P1", 20)
            min_p2 = self.min_tier_score.get("P2", 15)
            min_p3 = self.min_tier_score.get("P3", 10)
            for ri in range(p1_cut):
                ni = sorted_idx[ri]
                tiers[ni] = "P1" if scores[ni] >= min_p1 else "P4"
            for ri in range(p1_cut, p2_cut):
                ni = sorted_idx[ri]
                tiers[ni] = "P2" if scores[ni] >= min_p2 else "P4"
            for ri in range(p2_cut, p3_cut):
                ni = sorted_idx[ri]
                tiers[ni] = "P3" if scores[ni] >= min_p3 else "P4"
            # rest stay P4
        else:
            if tier_override and _mode == "absolute":
                # v16.4 GAP-2/9: User-defined absolute min-score thresholds from Dashboard.
                # p1/p2/p3 = minimum risk_score (0-100) for each tier.
                # Hierarchy: score >= p1 → P1,  score >= p2 (but < p1) → P2,  etc.
                # No capacity cap — user explicitly chose fixed thresholds.
                _abs_p1 = float(tier_override.get("p1", 70.0))
                _abs_p2 = float(tier_override.get("p2", 50.0))
                _abs_p3 = float(tier_override.get("p3", 30.0))
                tiers[scores >= _abs_p1] = "P1"
                tiers[(scores >= _abs_p2) & (scores < _abs_p1)] = "P2"
                tiers[(scores >= _abs_p3) & (scores < _abs_p2)] = "P3"
                # P4 = already set by default (scores < _abs_p3)
            else:
                # Existing config-based absolute fallback (risk_tiers ranges in config.yaml)
                for tier, bounds in self.tiers.items():
                    try:
                        low, high = bounds
                        mask = (scores >= low) & (scores <= high)
                        tiers[mask] = tier
                    except Exception:
                        pass

        return tiers

    # v15.22 NEW-ROLE: AML Role Classification
    # ─────────────────────────────────────────────────────────────────────────
    def _classify_aml_roles_inplace(self, result: pd.DataFrame, G=None) -> None:
        """
        Classify each node into one of five AML behavioural roles using existing
        computed metrics. No additional computation or external data required.

        Roles (business-language definitions):
        ──────────────────────────────────────
        ORIGINATOR  — Sends large volumes to many recipients. Low incoming,
                      high outgoing. PageRank authority within the network.
                      Business: "This is likely where the money enters the system."

        SINK        — Receives large volumes from many senders. Low outgoing,
                      high incoming. HITS authority score high.
                      Business: "This account collects funds — possible aggregator
                      or final destination of laundered proceeds."

        MULE        — Money passes through: in_flow ≈ out_flow. High betweenness.
                      Identified as layering intermediary.
                      Business: "This account relays money without retaining it —
                      the textbook definition of a money mule."

        BROKER      — Sits structurally between multiple communities. High
                      betweenness + deep K-Core + multi-community reach.
                      Business: "This account connects otherwise separate groups —
                      a structural hub in the laundering network."

        PERIPHERAL  — Low on all risk metrics. Normal banking activity.
                      Business: "No elevated indicators for this account."

        Multiple strong signals → MIXED (e.g., both MULE and BROKER behaviours).

        Thresholds are percentile-based — no absolute values, adapts to every dataset.
        """
        n = len(result)
        if n == 0:
            return

        role_cfg = getattr(PIPELINE, "ROLE_CLASSIFICATION", {})
        min_evidence = float(role_cfg.get("min_evidence_score", 8.0))
        broker_bc_pct = float(role_cfg.get("broker_betweenness_pct", 85))
        orig_od_pct = float(role_cfg.get("originator_outdegree_pct", 80))
        sink_id_pct = float(role_cfg.get("sink_indegree_pct", 80))
        mule_pt_min = float(role_cfg.get("mule_passthrough_min", 0.80))

        def _get(col: str, default: float = 0.0) -> np.ndarray:
            if col in result.columns:
                return (
                    pd.to_numeric(result[col], errors="coerce")
                    .fillna(default)
                    .to_numpy(dtype=float)
                )
            return np.full(n, default, dtype=float)

        risk_score = _get("risk_score")
        betweenness = _get("centrality_betweenness")
        pagerank = _get("centrality_pagerank")
        hits_auth = _get("centrality_hits_authority")
        k_core = _get("centrality_k_core")
        layering = _get("structuring_is_layering_intermediary")
        motif_pt = _get("motifs_motif_pass_through")

        # In-degree / out-degree from graph (most reliable source)
        in_deg = np.zeros(n, dtype=float)
        out_deg = np.zeros(n, dtype=float)
        if G is not None and _HAS_NX:
            try:
                node_list = result["node_id"].tolist()
                for i, nd in enumerate(node_list):
                    in_deg[i] = float(G.in_degree(nd))
                    out_deg[i] = float(G.out_degree(nd))
            except Exception:
                pass

        # Pass-through ratio: min(in, out) / max(in, out)
        total_flow = in_deg + out_deg
        pt_ratio = np.where(
            total_flow > 0,
            np.minimum(in_deg, out_deg) / np.maximum(np.maximum(in_deg, out_deg), 1.0),
            0.0,
        )

        # Compute percentile thresholds (on non-zero values, to avoid trivial ties)
        def _pct(arr: np.ndarray, pct: float) -> float:
            nonzero = arr[arr > 0]
            if len(nonzero) < 5:
                return float(arr.max()) + 1e-8  # no discrimination possible
            return float(np.percentile(nonzero, pct))

        bc_thresh = _pct(betweenness, broker_bc_pct)
        od_thresh = _pct(out_deg, orig_od_pct)
        id_thresh = _pct(in_deg, sink_id_pct)

        roles = np.full(n, "PERIPHERAL", dtype=object)

        for i in range(n):
            if risk_score[i] < min_evidence:
                continue  # below minimum gate — stay PERIPHERAL

            signals = []
            # MULE: passes money through with minimal retention
            if (layering[i] > 0 or pt_ratio[i] >= mule_pt_min) and betweenness[i] > 0:
                signals.append("MULE")
            # BROKER: structural connector between communities
            if betweenness[i] >= bc_thresh and k_core[i] >= 2:
                signals.append("BROKER")
            # ORIGINATOR: high outflow, high PageRank (sends money outward)
            if out_deg[i] >= od_thresh and pagerank[i] > 0 and out_deg[i] > in_deg[i]:
                signals.append("ORIGINATOR")
            # SINK: high inflow, high authority (collects money)
            if in_deg[i] >= id_thresh and hits_auth[i] > 0 and in_deg[i] > out_deg[i]:
                signals.append("SINK")

            if len(signals) == 0:
                roles[i] = "PERIPHERAL"
            elif len(signals) == 1:
                roles[i] = signals[0]
            else:
                # Multiple strong signals — name the dominant + flag MIXED
                # Dominance order for reporting: MULE > BROKER > ORIGINATOR > SINK
                dom_order = ["MULE", "BROKER", "ORIGINATOR", "SINK"]
                primary = next((s for s in dom_order if s in signals), signals[0])
                roles[i] = f"{primary}+MIXED"

        result["aml_role"] = roles

        # v15.23 NEW-CONF: Role confidence score (0.0 – 1.0)
        # ─────────────────────────────────────────────────────────
        # An assigned role without a confidence score is a binary label.
        # Investigators need: "MULE at 97% confidence" vs "MULE at 61% confidence"
        # to prioritise their caseload correctly.
        #
        # Formula: confidence = how far ABOVE the qualifying threshold the node sits,
        # normalised by the distance between the threshold and the population maximum.
        #   confidence = (signal - threshold) / (max(signal) - threshold + ε)
        #   ∈ [0, 1]  where 0 = just barely qualified, 1 = top of population
        #
        # For PERIPHERAL: confidence = 1 − max(individual signals / thresholds).
        # Multi-role (MIXED): take max confidence across the multiple active signals.
        _conf = np.zeros(n, dtype=np.float32)
        bc_max = betweenness.max() + 1e-8
        od_max = out_deg.max() + 1e-8
        id_max = in_deg.max() + 1e-8
        pt_max = 1.0  # passthrough is already 0-1
        for i in range(n):
            role_str = str(roles[i])
            if role_str == "PERIPHERAL":
                # Confidence in PERIPHERAL = how far all signals are below threshold
                sig_max = max(
                    betweenness[i] / max(bc_thresh, 1e-8),
                    out_deg[i] / max(od_thresh, 1e-8),
                    in_deg[i] / max(id_thresh, 1e-8),
                    pt_ratio[i] / max(mule_pt_min, 1e-8),
                )
                _conf[i] = float(np.clip(1.0 - sig_max, 0.0, 1.0))
            else:
                sigs = []
                if "MULE" in role_str and betweenness[i] > 0:
                    sigs.append(
                        float(
                            np.clip(
                                (pt_ratio[i] - mule_pt_min) / (pt_max - mule_pt_min + 1e-8), 0, 1
                            )
                        )
                    )
                if "BROKER" in role_str:
                    sigs.append(
                        float(
                            np.clip(
                                (betweenness[i] - bc_thresh) / (bc_max - bc_thresh + 1e-8), 0, 1
                            )
                        )
                    )
                if "ORIGINATOR" in role_str:
                    sigs.append(
                        float(np.clip((out_deg[i] - od_thresh) / (od_max - od_thresh + 1e-8), 0, 1))
                    )
                if "SINK" in role_str:
                    sigs.append(
                        float(np.clip((in_deg[i] - id_thresh) / (id_max - id_thresh + 1e-8), 0, 1))
                    )
                _conf[i] = float(max(sigs)) if sigs else 0.0
        result["role_confidence"] = np.round(_conf, 3)

        # v15.23 NEW-SAR: SAR narrative auto-text per node
        # ─────────────────────────────────────────────────────────
        # SAR writing is time-intensive. An investigator staring at a risk score of
        # 87 still has to translate it into words for a Suspicious Activity Report.
        # This column generates the OPENING SENTENCE of the SAR narrative automatically
        # from the computed graph metrics — in plain language that a compliance officer
        # can read directly into a SAR without modification.
        #
        # Example outputs:
        #   MULE:       "Account received funds from 12 senders and forwarded 94% onward
        #                to 8 recipients within the same network — net retention under 6%,
        #                consistent with money mule behaviour (confidence: 91%)."
        #   BROKER:     "Account structurally bridges 3 separate transaction clusters;
        #                betweenness rank: 96th percentile — structural hub in the network
        #                consistent with broker/intermediary behaviour (confidence: 84%)."
        #   ORIGINATOR: "Account sent funds to 15 unique recipients with a 7.2:1 outbound-
        #                to-inbound ratio — primary fund source entering the network
        #                (confidence: 78%)."
        #   SINK:       "Account collected funds from 18 unique senders with negligible
        #                outbound activity (x0.1 of inflow) — possible aggregation endpoint
        #                (confidence: 82%)."
        #   PERIPHERAL: "No elevated AML indicators. Account shows normal banking patterns."
        #
        # Requires: node + edge table only. Uses in_deg / out_deg already computed above.
        # Pull in_flow / out_flow from G node attrs for financial value narrative.
        in_flow_arr = np.zeros(n, dtype=float)
        out_flow_arr = np.zeros(n, dtype=float)
        if G is not None and _HAS_NX:
            try:
                _node_list_sar = result["node_id"].tolist()
                for _ii, _nd in enumerate(_node_list_sar):
                    _nd_d = G.nodes.get(_nd, {})
                    in_flow_arr[_ii] = float(_nd_d.get("in_flow", 0) or 0)
                    out_flow_arr[_ii] = float(_nd_d.get("out_flow", 0) or 0)
            except Exception:
                pass

        _sar_narratives = []
        for i in range(n):
            role_str = str(roles[i])
            conf_pct = int(round(float(_conf[i]) * 100))
            r_in_deg = int(in_deg[i])
            r_out_deg = int(out_deg[i])
            r_in_flow = in_flow_arr[i]
            r_out_flow = out_flow_arr[i]
            total_f = r_in_flow + r_out_flow + 1e-8
            fwd_pct = int(round(100 * min(r_out_flow, total_f) / total_f)) if total_f > 0 else 0
            ret_pct = 100 - fwd_pct
            ob_ib_ratio = round(r_out_flow / (r_in_flow + 1e-8), 1) if r_in_flow > 0 else ">10"
            try:
                if risk_score[i] < min_evidence or role_str == "PERIPHERAL":
                    _sar_narratives.append(
                        "No elevated AML indicators detected. Account shows patterns "
                        "consistent with normal banking activity."
                    )
                elif "MULE" in role_str:
                    _sar_narratives.append(
                        f"Account received funds from {r_in_deg} counterpart(ies) and forwarded "
                        f"{fwd_pct}% onward to {r_out_deg} recipient(s) — net retention under "
                        f"{ret_pct}%, consistent with money mule behaviour (confidence: {conf_pct}%)."
                    )
                elif "BROKER" in role_str:
                    _bc_rank_pct = int(round(100 * float(np.mean(betweenness <= betweenness[i]))))
                    _sar_narratives.append(
                        f"Account structurally bridges separate transaction clusters; "
                        f"betweenness rank: {_bc_rank_pct}th percentile of this network — "
                        f"acts as a structural hub connecting otherwise separate groups, "
                        f"consistent with intermediary/broker behaviour (confidence: {conf_pct}%)."
                    )
                elif "ORIGINATOR" in role_str:
                    _sar_narratives.append(
                        f"Account sent funds to {r_out_deg} unique recipient(s) with a "
                        f"{ob_ib_ratio}:1 outbound-to-inbound ratio — primary fund source "
                        f"entering the network, consistent with originator behaviour "
                        f"(confidence: {conf_pct}%)."
                    )
                elif "SINK" in role_str:
                    _sar_narratives.append(
                        f"Account collected funds from {r_in_deg} unique sender(s) with "
                        f"negligible outbound activity ({ob_ib_ratio}:1 inbound-to-outbound) — "
                        f"possible aggregation or end-point for laundered proceeds "
                        f"(confidence: {conf_pct}%)."
                    )
                else:
                    _sar_narratives.append(
                        f"Multiple AML behavioural patterns detected: {role_str}. "
                        f"Account shows characteristics consistent with more than one role "
                        f"in a layering scheme (confidence: {conf_pct}%)."
                    )
            except Exception:
                _sar_narratives.append("")
        result["sar_narrative"] = _sar_narratives

        # Append role label to evidence_summary (if it exists)
        role_descriptions = {
            "ORIGINATOR": "Role: ORIGINATOR — primary source of funds entering the network",
            "SINK": "Role: SINK — aggregates incoming funds from multiple sources",
            "MULE": "Role: MONEY MULE — relays funds with minimal net retention",
            "BROKER": "Role: STRUCTURAL BROKER — connects separate transaction clusters",
            "MULE+MIXED": "Role: MULE/BROKER hybrid — relays AND connects clusters",
            "BROKER+MIXED": "Role: BROKER/ORIGINATOR hybrid — hub that sources funds",
            "ORIGINATOR+MIXED": "Role: ORIGINATOR/SINK hybrid — bidirectional fund hub",
            "SINK+MIXED": "Role: SINK/MULE hybrid — aggregates and relays",
            "PERIPHERAL": "",  # no role label for low-risk accounts
        }
        if "evidence_summary" in result.columns:
            try:
                ev = result["evidence_summary"].tolist()
                for i, role in enumerate(roles):
                    desc = role_descriptions.get(str(role), "")
                    if desc:
                        current = ev[i] if ev[i] else ""
                        ev[i] = (
                            (current + " \u2022 " + desc)
                            if current and current != "No specific indicators flagged"
                            else desc
                        )
                result["evidence_summary"] = ev
            except Exception:
                pass

    def get_tier_distribution(self) -> Dict[str, int]:
        if self.scored_df is None:
            return {}
        try:
            return self.scored_df["risk_tier"].value_counts().to_dict()
        except Exception:
            return {}

    def get_high_risk_customers(self, tiers: List[str] = None) -> pd.DataFrame:
        if self.scored_df is None:
            return pd.DataFrame()
        tiers = tiers or ["P1", "P2"]
        try:
            return self.scored_df[self.scored_df["risk_tier"].isin(tiers)].copy()
        except Exception:
            return pd.DataFrame()

    def get_summary(self) -> Dict:
        if self.scored_df is None or len(self.scored_df) == 0:
            return {"status": "Not scored", "total_scored": 0}
        try:
            return {
                "total_scored": len(self.scored_df),
                "avg_score": float(self.scored_df["risk_score"].mean()),
                "max_score": float(self.scored_df["risk_score"].max()),
                "tier_distribution": self.get_tier_distribution(),
            }
        except Exception:
            return {"total_scored": len(self.scored_df)}

    # v16.36 ─────────────────────────────────────────────────────────────
    def _compile_evidence_inplace(self, result: pd.DataFrame) -> None:
        """
        v16.36: BUSINESS-LANGUAGE NARRATIVE ENGINE.
        Uses utils/business_rules.py template-driven rules to translate every
        AML signal into plain English a bank manager or compliance officer can
        act on immediately — no algorithm knowledge required.

        OUTPUT COLUMNS
        --------------
        evidence_summary  — WHY flagged: plain English sentences joined by ' • '
        business_action   — WHAT TO DO: single highest-priority recommended action

        TEMPLATE-DRIVEN DESIGN
        ----------------------
        All signal→text mappings live in utils/business_rules.SIGNAL_RULES dict.
        Adding a new signal requires only a new entry in that dict — no code
        changes here. Works offline, works with any data dynamically.

        FATF Recommendation 29 compliance: every scored customer has a human-
        readable explanation suitable for SAR narrative preparation.
        """
        n = len(result)
        if n == 0:
            result["evidence_summary"] = []
            result["business_action"] = []
            return

        # ── v15.11 pattern: pre-extract all columns as numpy arrays (15x faster) ──
        def _col(name: str, default: float = 0.0) -> np.ndarray:
            if name in result.columns:
                return (
                    pd.to_numeric(result[name], errors="coerce")
                    .fillna(default)
                    .to_numpy(dtype=float)
                )
            return np.full(n, default, dtype=float)

        # Signal arrays — all signals used by business_rules.py
        # v16.36.1: also pass flow/degree/score so narrative is personalized per customer
        _signal_cols = [
            "in_ring", "scc_size", "k_core", "motif_circular",
            "potential_structuring", "potential_ctr_avoidance", "ctr_bracket_count",
            "is_layering_intermediary", "benfords_anomaly", "benfords_second_anomaly",
            "shared_infrastructure_count", "is_burst",
            "temporal_circular_flow_count", "temporal_circular_flow_value",
            "temporal_burst_count", "consensus_count",
            "temporal_is_scripted_regular", "temporal_is_temporal_relay",
            "temporal_temporal_relay_count", "centrality_is_powerlaw_tail",
            "centrality_powerlaw_alpha", "centrality_degree_centrality",
            # Context values for personalized narrative
            "risk_score", "in_flow", "out_flow", "in_degree", "out_degree",
        ]
        _defaults = {"scc_size": 2.0, "ctr_bracket_count": 1.0,
                     "centrality_powerlaw_alpha": 2.0,
                     "risk_score": 0.0, "in_flow": 0.0, "out_flow": 0.0,
                     "in_degree": 0.0, "out_degree": 0.0}
        _arrays = {col: _col(col, _defaults.get(col, 0.0)) for col in _signal_cols}

        summaries: List[str] = []
        actions: List[str] = []

        for i in range(n):
            # Build per-row signal dict for business_rules functions
            sig: Dict[str, float] = {col: float(_arrays[col][i]) for col in _signal_cols}

            if _HAS_BIZ_RULES:
                try:
                    summaries.append(build_business_narrative(sig))
                    actions.append(build_action_required(sig))
                    continue
                except Exception:
                    pass  # fall through to legacy fallback

            # ── Legacy fallback (if business_rules import fails) ──────────────
            parts: List[str] = []
            try:
                if sig["in_ring"] > 0:
                    sz = int(sig["scc_size"])
                    parts.append(f"Part of a {sz}-account circular money loop — accounts are passing funds between each other with no clear business purpose")
                if sig["k_core"] >= 3:
                    parts.append(f"Deeply embedded in a tightly connected group of accounts (network depth {int(sig['k_core'])})")
                if sig["motif_circular"] > 0:
                    parts.append("Money sent to another account is being returned — back-and-forth payment with no evident commercial purpose")
                if sig["potential_structuring"] > 0:
                    parts.append("Multiple transactions deliberately kept just below $10,000 — possible structuring to avoid mandatory reporting")
                if sig["potential_ctr_avoidance"] > 0:
                    cnt = int(sig["ctr_bracket_count"])
                    parts.append(f"{cnt} transaction(s) in the $9,000–$10,000 range — classic CTR avoidance pattern")
                if sig["is_layering_intermediary"] > 0:
                    parts.append("Account acts as a pass-through — money arrives and is immediately forwarded, suggesting layering")
                if sig["benfords_anomaly"] > 0:
                    parts.append("Transaction amounts show unnatural digit patterns inconsistent with genuine commercial activity")
                if sig["shared_infrastructure_count"] >= 1:
                    parts.append(f"Shares device, phone, or address with {int(sig['shared_infrastructure_count'])} other customer(s) — possible linked accounts")
                if sig["is_burst"] > 0:
                    parts.append("Sudden spike in transaction activity — far above this account's normal behaviour")
                if sig["consensus_count"] >= 5:
                    parts.append(f"{int(sig['consensus_count'])}/10 independent detection methods all flagged this account — high-confidence alert")
            except Exception:
                pass
            summaries.append(" \u2022 ".join(parts) if parts else "No specific concerns identified at this time.")
            actions.append("Review with compliance team.")

        result["evidence_summary"] = summaries
        result["business_action"] = actions
