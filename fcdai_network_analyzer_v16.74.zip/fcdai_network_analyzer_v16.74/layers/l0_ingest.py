"""
Layer 0: Data Ingestion
========================
Business Logic: Loads data from 7 CSV/Parquet sources. Supports drag-and-drop
uploads via the Port Authority page or loading from the data/samples/ directory.
Uses the "store-or-load" pattern: new data is stored locally; if no new data
is provided, the last stored version is used.

Technical Implementation: Reads CSV/Parquet files into DataFrames. Validates
against Pydantic schemas. Logs every ingestion event to audit trail.
"""

import pandas as pd
from pathlib import Path
from typing import Dict, Optional, List, Tuple
from datetime import datetime
import sys
import io
import base64

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import PATHS, PIPELINE
from utils.logger import log_audit, log_error, log_data_transform
from utils.persistence import store_or_load


class IngestLayer:
    """
    Business Logic: Stage 0 — Load and validate 7 DB tables. If user uploads
    new data, store it and use it. Otherwise, load sample or previously stored data.

    Technical Implementation: Handles CSV, Parquet, and base64-encoded uploads
    from Dash file upload component.
    """

    def __init__(self):
        self.tables: Dict[str, pd.DataFrame] = {}
        self.load_log: List[Dict] = []

    # ── F01 v16.20: Schema enforcement ─────────────────────────────────────────
    # Converts amount/balance/price → float64, timestamp/date → datetime64.
    # Adds is_reversal flag (1 when amount < 0) BEFORE .abs() was silently hiding sign.
    # Preserves original sign — negative amounts are valid AML signals (reversal/chargeback).
    # Only node+edge tables are required; all other tables (kyc, alert, etc.) are optional.
    # Works safely on any non-empty DataFrame regardless of column presence.
    def _enforce_schema(self, df: pd.DataFrame, table_name: str) -> pd.DataFrame:
        if df is None or df.empty:
            return df
        df = df.copy()
        # Numeric coercion: amount/balance/price/fee/limit
        _num_keywords = ("amount", "balance", "price", "fee", "limit", "value", "credit", "debit")
        for col in df.columns:
            col_low = col.lower()
            if any(kw in col_low for kw in _num_keywords):
                original_nulls = df[col].isnull().sum()
                try:
                    # Strip currency prefixes (USD, EUR, £, $, €) and thousand-separators
                    if df[col].dtype == object:
                        df[col] = (
                            df[col].astype(str)
                            .str.replace(r"[\$£€¥₹]|USD|EUR|GBP|SGD|AED|JPY", "", regex=True)
                            .str.replace(",", "", regex=False)
                            .str.strip()
                        )
                    df[col] = pd.to_numeric(df[col], errors="coerce")
                    new_nulls = df[col].isnull().sum() - original_nulls
                    if new_nulls > 0:
                        log_audit("SCHEMA_WARN", f"{table_name}.{col}: {new_nulls} values could not be parsed as numeric")
                except Exception as e:
                    log_audit("SCHEMA_WARN", f"{table_name}.{col}: numeric coerce failed ({e})")
        # Datetime coercion: timestamp/date/time columns
        _dt_keywords = ("timestamp", "_date", "_time", "created_at", "updated_at")
        for col in df.columns:
            col_low = col.lower()
            if any(kw in col_low for kw in _dt_keywords):
                if df[col].dtype == object:
                    try:
                        df[col] = pd.to_datetime(df[col], errors="coerce", infer_datetime_format=True)
                    except Exception:
                        pass
        # F03 v16.20: Preserve sign → add is_reversal flag BEFORE any sign stripping occurs
        # Negative amount = debit reversal / chargeback / failed transaction → AML signal
        for col in df.columns:
            if "amount" in col.lower():
                if pd.api.types.is_numeric_dtype(df[col]):
                    if (df[col] < 0).any():
                        df[f"is_reversal_{col}"] = (df[col] < 0).astype(int)
                        log_audit("SCHEMA_INFO", f"{table_name}.{col}: {int((df[col] < 0).sum())} reversal rows flagged")
        return df

    def _derive_missing_events(self, tables: Dict[str, pd.DataFrame]) -> Dict[str, pd.DataFrame]:
        """
        v16.23 T1: If a table that carries transactions (transaction / edge)
        does NOT have an event_type column, derive one using the comprehensive
        AML rule engine in utils/event_rules.py.

        The derived column is named `derived_event_type` so it never collides
        with an existing `event_type` column supplied by the user.
        """
        try:
            from utils.event_rules import derive_event_types

            for tbl_name in ("transaction", "edge"):
                df = tables.get(tbl_name)
                if df is not None and not df.empty:
                    if "event_type" not in df.columns:
                        tables[tbl_name] = derive_event_types(df)
                        log_audit(
                            "EVENT_DERIVE",
                            f"Table '{tbl_name}': event_type missing — derived via rule engine",
                        )
                    else:
                        log_audit(
                            "EVENT_DERIVE",
                            f"Table '{tbl_name}': event_type column found — rule engine skipped",
                        )
        except Exception as exc:
            log_error(f"_derive_missing_events failed: {exc}")
        return tables

    def load_from_directory(self, directory: Path = None) -> Dict[str, pd.DataFrame]:
        """
        Business Logic: Load all available CSVs from a directory.
        v16.20: Optional tables (kyc, alert, historical, relationship) are loaded when
        present but the pipeline does not fail if they are absent — node+edge tables
        are the only required inputs.

        Args:
            directory: Path to directory containing CSV files. Defaults to data/samples/.

        Returns:
            Dict mapping table name to DataFrame.
        """
        directory = directory or PATHS.SAMPLES
        if not directory.exists():
            log_error(f"Data directory not found: {directory}")
            return {}

        # v16.20: Required tables vs optional — pipeline only requires node+edge tables
        _required = {"customer", "account", "transaction"}
        for table_name in PIPELINE.EXPECTED_TABLES:
            csv_path = directory / f"{table_name}.csv"
            parquet_path = directory / f"{table_name}.parquet"

            if csv_path.exists():
                df = pd.read_csv(csv_path)
                df = self._enforce_schema(df, table_name)  # F01 v16.20
                self.tables[table_name] = df
                self._log_load(table_name, csv_path, df)
            elif parquet_path.exists():
                df = pd.read_parquet(parquet_path, engine="pyarrow")
                df = self._enforce_schema(df, table_name)  # F01 v16.20
                self.tables[table_name] = df
                self._log_load(table_name, parquet_path, df)
            else:
                if table_name in _required:
                    log_audit("INGEST_WARN", f"Required table '{table_name}' not found in {directory}")
                else:
                    log_audit("INGEST_INFO", f"Optional table '{table_name}' absent — skipping")

        # Store all loaded tables for future use
        for name, df in self.tables.items():
            store_or_load(f"raw_{name}", df)

        # v16.23 T1: derive event types if missing
        self.tables = self._derive_missing_events(self.tables)

        return self.tables

    def load_from_upload(self, filename: str, content: str) -> Tuple[str, pd.DataFrame]:
        """
        Business Logic: Process a file uploaded via the Port Authority page.

        Args:
            filename: Original filename
            content: Base64-encoded file content from Dash upload

        Returns:
            Tuple of (table_name, DataFrame)
        """
        # Decode base64 content
        content_type, content_string = content.split(",")
        decoded = base64.b64decode(content_string)

        # Determine table name from filename
        stem = Path(filename).stem.lower()
        table_name = stem
        for expected in PIPELINE.EXPECTED_TABLES:
            if expected in stem:
                table_name = expected
                break

        # Read based on extension
        if filename.endswith(".csv"):
            df = pd.read_csv(io.StringIO(decoded.decode("utf-8")))
        elif filename.endswith((".parquet", ".pq")):
            df = pd.read_parquet(io.BytesIO(decoded), engine="pyarrow")
        elif filename.endswith((".xlsx", ".xls")):
            df = pd.read_excel(io.BytesIO(decoded), engine="openpyxl")
        else:
            raise ValueError(f"Unsupported file type: {filename}")

        df = self._enforce_schema(df, table_name)  # F01 v16.20
        self.tables[table_name] = df
        store_or_load(f"raw_{table_name}", df)
        self._log_load(table_name, Path(filename), df)

        return table_name, df

    def load_or_generate(self) -> Dict[str, pd.DataFrame]:
        """
        Business Logic: Try to load from vault first, then from samples,
        then generate new sample data if nothing exists.

        Returns:
            Dict of table name -> DataFrame
        """
        # Try vault first
        all_found = True
        for table_name in PIPELINE.EXPECTED_TABLES:
            df = store_or_load(f"raw_{table_name}")
            if df is not None:
                self.tables[table_name] = df
            else:
                all_found = False

        if all_found and len(self.tables) >= 5:
            log_audit("INGEST", "Loaded all tables from vault")
            self.tables = self._derive_missing_events(self.tables)
            return self.tables

        # Try samples directory
        if (PATHS.SAMPLES / "customer.csv").exists():
            return self.load_from_directory(PATHS.SAMPLES)

        # Generate fresh sample data
        log_audit("INGEST", "No existing data found — generating samples")
        from utils.sample_data import generate_all_samples

        self.tables = generate_all_samples()

        for name, df in self.tables.items():
            store_or_load(f"raw_{name}", df)

        # v16.23 T1: derive event types if missing
        self.tables = self._derive_missing_events(self.tables)

        return self.tables

    def _log_load(self, name: str, path: Path, df: pd.DataFrame):
        """Log a data load event."""
        info = {
            "table": name,
            "source": str(path),
            "rows": len(df),
            "columns": len(df.columns),
            "timestamp": datetime.now().isoformat(),
        }
        self.load_log.append(info)
        log_audit("INGEST_LOAD", f"{name}: {len(df)}r×{len(df.columns)}c from {path.name}")

    def get_summary(self) -> Dict:
        """Get ingestion summary."""
        return {
            "tables_loaded": len(self.tables),
            "total_rows": sum(len(df) for df in self.tables.values()),
            "details": {
                name: {"rows": len(df), "columns": len(df.columns)}
                for name, df in self.tables.items()
            },
            "load_log": self.load_log,
        }
