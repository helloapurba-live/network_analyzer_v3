"""
Layer 1: Data Validation & Quality — V9 BULLETPROOF
====================================
Business Logic: Validates ingested data. Computes DQ scores.
v9: Handles blank DB, 0-row tables, missing columns without crashing.
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from datetime import datetime
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import PIPELINE
from models.schemas import DataQualityReport
from utils.logger import log_audit, log_data_transform


class ValidateLayer:
    """
    v9: Fully defensive validation. Skips empty tables, guards all math.
    """

    def __init__(self):
        self.reports: Dict[str, DataQualityReport] = {}
        self.thresholds = PIPELINE.DQ_THRESHOLDS

    def assess_all(self, tables: Dict[str, pd.DataFrame]) -> Dict[str, DataQualityReport]:
        for name, df in tables.items():
            try:
                report = self.assess_table(name, df)
                self.reports[name] = report
                log_audit("DQ_ASSESS", f"{name}: overall={report.overall_score:.3f}")
            except Exception as e:
                # v16.20 F02: Report actual DQ failure — score=0.0 (not 1.0) so pipeline
                # correctly identifies bad/malformed tables and can block or warn.
                log_audit("DQ_ASSESS_FAIL", f"{name}: validation error — {e}")
                self.reports[name] = DataQualityReport(
                    source_name=name,
                    total_rows=len(df) if df is not None else 0,
                    total_columns=len(df.columns) if df is not None else 0,
                    completeness=0.0,
                    consistency=0.0,
                    validity=0.0,
                    overall_score=0.0,
                    issues=[f"Validation failed: {str(e)[:200]}"],
                    column_stats={},
                )
        return self.reports

    def assess_table(self, name: str, df: pd.DataFrame) -> DataQualityReport:
        issues = []

        # v9: Guard against None or empty DataFrames
        if df is None or df.empty:
            return DataQualityReport(
                source_name=name,
                total_rows=0,
                total_columns=0,
                completeness=1.0,
                consistency=1.0,
                validity=1.0,
                overall_score=1.0,
                issues=["Empty table — skipped validation"],
                column_stats={},
            )

        n_rows, n_cols = df.shape
        total_cells = max(n_rows * n_cols, 1)  # v9: never divide by zero

        # --- Completeness ---
        null_count = int(df.isnull().sum().sum())
        completeness = 1.0 - (null_count / total_cells)
        if completeness < self.thresholds.get("completeness", 0.90):
            issues.append(f"Low completeness ({completeness:.2%}): {null_count} nulls")

        # --- Consistency ---
        consistency_checks = 0
        consistency_pass = 0
        for col in df.columns:
            consistency_checks += 1
            try:
                non_null = df[col].dropna()
                if len(non_null) > 0:
                    types = non_null.apply(type).nunique()
                    if types <= 2:
                        consistency_pass += 1
                    else:
                        issues.append(f"Mixed types in '{col}': {types} types")
                else:
                    consistency_pass += 1  # v9: all-null column is "consistent"
            except Exception:
                consistency_pass += 1  # v9: skip problematic columns
        consistency = consistency_pass / max(consistency_checks, 1)

        # v9: Skip duplicate key check for tiny tables
        if n_rows > 1:
            for col in df.columns:
                # v16.20 F04: Include customer_id — removed prior exclusion.
                # Duplicate customer_id rows (synthetic identity injection / multi-system merge
                # ID collision) are a critical data quality failure that must be flagged.
                if col.endswith("_id"):
                    try:
                        dupes = df[col].dropna().duplicated().sum()
                        if dupes > 0:
                            issues.append(f"Duplicate keys in '{col}': {dupes}")
                    except Exception:
                        pass

        # --- Validity ---
        validity_checks = 0
        validity_pass = 0
        for col in df.select_dtypes(include=[np.number]).columns:
            validity_checks += 1
            try:
                series = df[col].dropna()
                if len(series) == 0:
                    validity_pass += 1
                    continue
                if "amount" in col.lower() or "balance" in col.lower():
                    neg_count = (series < 0).sum()
                    if neg_count == 0:
                        validity_pass += 1
                    else:
                        issues.append(f"Negative values in '{col}': {neg_count}")
                elif "score" in col.lower() or "rate" in col.lower():
                    out_of_range = ((series < 0) | (series > 1)).sum()
                    if out_of_range == 0:
                        validity_pass += 1
                    else:
                        issues.append(f"Out-of-range in '{col}': {out_of_range}")
                else:
                    validity_pass += 1
            except Exception:
                validity_pass += 1

        validity = validity_pass / max(validity_checks, 1) if validity_checks > 0 else 1.0
        overall = completeness * 0.4 + consistency * 0.3 + validity * 0.3

        # --- Column stats (v9: wrapped in try/except per column) ---
        column_stats = {}
        for col in df.columns:
            try:
                stats = {
                    "dtype": str(df[col].dtype),
                    "null_count": int(df[col].isnull().sum()),
                    "null_pct": float(df[col].isnull().mean()),
                    "unique_count": int(df[col].nunique()),
                }
                if df[col].dtype in [np.float64, np.float32, np.int64, np.int32, float, int]:
                    if not df[col].isnull().all() and len(df[col].dropna()) > 0:
                        stats.update(
                            {
                                "min": float(df[col].min()),
                                "max": float(df[col].max()),
                                "mean": float(df[col].mean()),
                            }
                        )
                column_stats[col] = stats
            except Exception:
                column_stats[col] = {"dtype": "unknown", "null_count": 0}

        return DataQualityReport(
            source_name=name,
            total_rows=n_rows,
            total_columns=n_cols,
            completeness=round(completeness, 4),
            consistency=round(consistency, 4),
            validity=round(validity, 4),
            overall_score=round(overall, 4),
            issues=issues,
            column_stats=column_stats,
        )

    def cleanse(self, df: pd.DataFrame, strategy: str = "moderate") -> pd.DataFrame:
        # v9: Handle None/empty DataFrames
        if df is None or df.empty:
            return df if df is not None else pd.DataFrame()

        input_shape = df.shape
        result = df.copy()

        try:
            if strategy in ("minimal", "moderate", "aggressive"):
                for col in result.columns:
                    if result[col].isnull().any():
                        try:
                            if result[col].dtype in [np.float64, np.float32, np.int64, np.int32]:
                                result[col] = result[col].fillna(result[col].median())
                            else:
                                mode_val = result[col].mode()
                                if len(mode_val) > 0:
                                    result[col] = result[col].fillna(mode_val.iloc[0])
                        except Exception:
                            pass  # v9: skip problematic columns

            if strategy in ("moderate", "aggressive"):
                for col in result.select_dtypes(include=[np.number]).columns:
                    if "amount" in col.lower() or "balance" in col.lower():
                        try:
                            # v16.20 F03: Do NOT force .abs() on amount columns.
                            # Negative amounts (reversals, chargebacks, refunds) are valid AML signals.
                            # is_reversal flags are added at ingest (_enforce_schema in l0_ingest).
                            # Only flag negative balances as validity issues, don't silently mutate.
                            neg_count = (result[col] < 0).sum()
                            if neg_count > 0 and "balance" in col.lower():
                                # For balances, negative is a warning (may be overdraft) not auto-fixed
                                pass  # preserve sign, already captured in DQ issues above
                        except Exception:
                            pass

            log_data_transform("CLEANSE", input_shape, result.shape, {"strategy": strategy})
        except Exception:
            pass

        return result

    # v16.20 F05: Pipeline DQ block threshold check.
    # Returns a dict with: blocked=True/False, reason, failing_tables
    # Engine can call this after assess_all() to decide whether to abort or warn.
    # Required tables (node+edge minimum) checked strictly; optional tables checked softly.
    def check_pipeline_block(
        self,
        required_tables: list = None,
        block_threshold: float = 0.50,
        warn_threshold: float = 0.75,
    ) -> Dict:
        """
        F05 v16.20: DQ gate for pipeline execution.
        - block_threshold: tables below this score block the pipeline (default 0.50)
        - warn_threshold:  tables below this score emit warnings but do not block
        - required_tables: if a required table has score=0.0 (failed validation), block immediately
        """
        if not self.reports:
            return {"blocked": False, "warnings": [], "blocked_tables": []}

        _required = required_tables or ["customer", "account", "transaction"]
        blocked_tables = []
        warning_tables = []

        for name, report in self.reports.items():
            score = report.overall_score
            if score == 0.0:
                # Validation completely failed — always block for required tables
                if name in _required:
                    blocked_tables.append((name, score, "validation_failed"))
                else:
                    warning_tables.append((name, score, "validation_failed_optional"))
            elif score < block_threshold and name in _required:
                blocked_tables.append((name, score, f"score_below_{block_threshold}"))
            elif score < warn_threshold:
                warning_tables.append((name, score, f"score_below_{warn_threshold}"))

        blocked = len(blocked_tables) > 0
        if blocked:
            log_audit("DQ_PIPELINE_BLOCK", f"Blocked: {[(t, s) for t, s, _ in blocked_tables]}")
        if warning_tables:
            log_audit("DQ_PIPELINE_WARN", f"Warnings: {[(t, s) for t, s, _ in warning_tables]}")

        return {
            "blocked": blocked,
            "blocked_tables": blocked_tables,
            "warnings": warning_tables,
            "message": ("PIPELINE BLOCKED: critical DQ failure in required tables" if blocked else "OK"),
        }

    # -------------------------------------------------------------------------
    # v16.32 NEW-DQ2: four extended quality checks used by DQ infographic page
    # -------------------------------------------------------------------------

    def check_referential_integrity(
        self, node_df: pd.DataFrame, edge_df: pd.DataFrame
    ) -> Dict:
        """
        Verify that every from_node / to_node in the edge table exists in node_id
        column of the node table. Returns orphan_count and a sample of orphan IDs.
        Industry standard: referential integrity is mandatory before graph construction.
        """
        result = {"orphan_count": 0, "orphan_sample": [], "issues": []}
        try:
            if node_df is None or node_df.empty or edge_df is None or edge_df.empty:
                result["issues"].append("Referential integrity skipped — empty table(s)")
                return result
            node_id_col = next((c for c in node_df.columns if c.lower() == "node_id"), None)
            if node_id_col is None:
                result["issues"].append("node_id column not found in node table")
                return result
            valid_ids = set(node_df[node_id_col].dropna().astype(str).str.strip().str.upper())
            orphans = set()
            for col in ["from_node", "to_node"]:
                if col in edge_df.columns:
                    vals = edge_df[col].dropna().astype(str).str.strip().str.upper()
                    orphans |= set(vals[~vals.isin(valid_ids)])
            count = len(orphans)
            result["orphan_count"] = count
            result["orphan_sample"] = list(orphans)[:10]
            if count > 0:
                result["issues"].append(
                    f"Referential integrity: {count} edge node(s) not in node table"
                )
                log_audit("DQ_REF_INTEGRITY", f"orphan_count={count}")
        except Exception as e:
            result["issues"].append(f"Referential integrity check error: {e}")
        return result

    def check_self_loops(self, edge_df: pd.DataFrame) -> Dict:
        """
        Flag edges where from_node == to_node (self-loops).
        Self-loops are structurally invalid in AML transaction graphs (a node
        cannot transfer funds to itself in a legitimate ledger).
        """
        result = {"self_loop_count": 0, "issues": []}
        try:
            if edge_df is None or edge_df.empty:
                return result
            if "from_node" in edge_df.columns and "to_node" in edge_df.columns:
                count = int((edge_df["from_node"] == edge_df["to_node"]).sum())
                result["self_loop_count"] = count
                if count > 0:
                    result["issues"].append(f"Self-loops detected: {count} edges")
                    log_audit("DQ_SELF_LOOPS", f"count={count}")
        except Exception as e:
            result["issues"].append(f"Self-loop check error: {e}")
        return result

    def check_future_dates(self, df: pd.DataFrame, date_cols: list = None) -> Dict:
        """
        Flag rows where a date/timestamp column has a value in the future.
        Future-dated transactions are a strong fabrication / data-entry anomaly.
        """
        result = {"future_date_count": 0, "affected_columns": [], "issues": []}
        try:
            if df is None or df.empty:
                return result
            now = pd.Timestamp.now()
            cols = date_cols or [c for c in df.columns if "timestamp" in c.lower() or "date" in c.lower()]
            total = 0
            for col in cols:
                if col not in df.columns:
                    continue
                try:
                    parsed = pd.to_datetime(df[col], errors="coerce")
                    future = int((parsed > now).sum())
                    if future > 0:
                        total += future
                        result["affected_columns"].append(col)
                        result["issues"].append(f"Future dates in '{col}': {future} rows")
                except Exception:
                    pass
            result["future_date_count"] = total
            if total > 0:
                log_audit("DQ_FUTURE_DATES", f"count={total}")
        except Exception as e:
            result["issues"].append(f"Future-date check error: {e}")
        return result

    def normalize_ids(self, df: pd.DataFrame, id_cols: list = None) -> pd.DataFrame:
        """
        Strip leading/trailing whitespace and uppercase all ID columns.
        Prevents silent join mismatches caused by inconsistent casing or padding.
        Returns the normalised DataFrame (does not mutate the original).
        """
        if df is None or df.empty:
            return df if df is not None else pd.DataFrame()
        result = df.copy()
        cols = id_cols or [c for c in df.columns if c.lower().endswith("_id") or c.lower() in ("from_node", "to_node")]
        for col in cols:
            if col in result.columns:
                try:
                    result[col] = result[col].astype(str).str.strip().str.upper()
                except Exception:
                    pass
        return result

    def get_overall_report(self) -> Dict:
        if not self.reports:
            return {"status": "No assessments run", "overall_score": 0}
        try:
            return {
                "tables_assessed": len(self.reports),
                "overall_score": np.mean([r.overall_score for r in self.reports.values()]),
                "tables_passing": sum(1 for r in self.reports.values() if r.overall_score >= 0.80),
                "total_issues": sum(len(r.issues) for r in self.reports.values()),
                "per_table": {
                    name: {
                        "rows": r.total_rows,
                        "completeness": r.completeness,
                        "consistency": r.consistency,
                        "validity": r.validity,
                        "overall": r.overall_score,
                        "issues": len(r.issues),
                    }
                    for name, r in self.reports.items()
                },
            }
        except Exception:
            return {"status": "Error computing report", "overall_score": 0}
