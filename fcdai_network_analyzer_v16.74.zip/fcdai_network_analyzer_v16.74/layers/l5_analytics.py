"""
Layer 5: Network Analytics (10-Family Suite) — V15.5 AML-GRADE
===============================================================
v15.5 fixes over v15.4 (all unsupervised, air-gapped, n=50–50000 adaptive):
  NEW-08: Bidirectional asymmetric propagation (in l6_scoring): successors +15 / predecessors +5
  NEW-09: Katz centrality added to centrality family (handles DAG + disconnected)
          Complements eigenvector/PR which degenerate on acyclic graphs (common in AML chains)
  NEW-10: A→B→A bilateral motif + amount-ratio check in motif family
          |amt_AB - amt_BA| / max < bilateral_amount_tolerance = TBML round-trip flag
  NEW-11: Velocity delta zscore in temporal family (behavioral CHANGE detection)
          Account going quiet→active is more suspicious than always-active
  NEW-12: Jaccard/AA → unexplained-connection score in link_prediction family
          Low topological similarity + high volume = transactions with no relationship basis
  NEW-13: Intra-family column weights applied in l6_scoring
  NEW-14: Round-number decimal fix in structuring family
          round(a) instead of int(a) avoids decimal truncation errors
  NEW-15: Consensus count → confidence multiplier in l6_scoring
  NEW-16: Community size inversion — small tight communities = higher AML risk
          Shell company rings are size 3–8, not giant clusters
  NEW-17: Degree-weighted path sampling in pathflow family
Inherited: v14.3 (NEW-01 to NEW-07) + v14.1 (FIX-01 to FIX-12)
Air-gapped: No external calls. All offline. PII-safe. Unsupervised only.
"""
# ── Developer Attribution (v16.45) ─────────────────────────────────────────
__author__  = "Das Apurba"
__team__    = "FCDAI Analytics"
__version__ = "16.45.0"

import pandas as pd
import numpy as np
import networkx as nx
from pathlib import Path
from typing import Dict, List, Optional, Any
from scipy import stats
from collections import Counter
import warnings
import sys
import time
import gc
import math
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading
import hashlib as _hashlib
import pickle as _pickle

# v15.14: joblib for persistent disk cache across restarts
try:
    from joblib import Memory as _JobMemory

    HAS_JOBLIB = True
except ImportError:
    HAS_JOBLIB = False

# v15.14: numba JIT detection (optional acceleration)
try:
    from numba import njit as _numba_njit

    HAS_NUMBA = True
except ImportError:
    HAS_NUMBA = False

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import PIPELINE, APP
from utils.logger import log_audit, log_error
from utils.persistence import store_or_load

warnings.filterwarnings("ignore")

# ---- Conditional fast imports ----
try:
    import igraph as ig

    HAS_IGRAPH = True
except ImportError:
    HAS_IGRAPH = False

try:
    from pyod.models.ecod import ECOD
    from pyod.models.hbos import HBOS  # v14.3: O(n log n) fallback for large graphs

    HAS_PYOD = True
except ImportError:
    HAS_PYOD = False

try:
    from sklearn.ensemble import IsolationForest
    from sklearn.neighbors import LocalOutlierFactor

    HAS_SKLEARN = True
except ImportError:
    HAS_SKLEARN = False

try:
    from datasketch import MinHash, MinHashLSH

    HAS_DATASKETCH = True
except ImportError:
    HAS_DATASKETCH = False


FAMILY_DISPLAY_NAMES = {
    "centrality": "Network Influence Hub",
    "community": "Topological Cluster Engine",
    "pathflow": "Laundering Traceability Logic",
    "link_prediction": "Hidden Association Predictor",
    "anomaly": "Topological Outlier Detector",
    "temporal": "Dynamic Velocity Analyzer",
    "multi_layer": "Multi-Layer Module",
    "structuring": "Structuring Split Detector",
    "benfords": "Benford's Law Analyzer",
    "motifs": "Network Motif Scanner",
}

# v12.4: Family speed classification for progressive analytics (P6)
FAST_FAMILIES = {"centrality", "community", "temporal", "multi_layer", "structuring"}
SLOW_FAMILIES = {"pathflow", "link_prediction", "anomaly", "benfords", "motifs"}

# v12.4: Thread-safe family result cache (P4)
_family_cache: Dict[str, pd.DataFrame] = {}
_cache_lock = threading.Lock()

# v15.14 #12: Optional persistent disk cache (survives server restarts)
_DISK_CACHE_DIR = Path(__file__).parent.parent / "data" / ".analytics_cache"
try:
    _DISK_CACHE_DIR.mkdir(parents=True, exist_ok=True)
    _DISK_CACHE_ENABLED = True
except Exception:
    _DISK_CACHE_ENABLED = False


def _nx_to_igraph(G: nx.DiGraph):
    """Convert NetworkX DiGraph to igraph for C-backend speed."""
    nodes = list(G.nodes())
    node_map = {n: i for i, n in enumerate(nodes)}
    edges = [(node_map[u], node_map[v]) for u, v in G.edges() if u in node_map and v in node_map]
    weights = [
        G[u][v].get("weight", G[u][v].get("amount", 1.0))
        for u, v in G.edges()
        if u in node_map and v in node_map
    ]
    g = ig.Graph(n=len(nodes), edges=edges, directed=True)
    g.vs["name"] = nodes
    g.es["weight"] = weights
    for attr in [
        "in_flow",
        "out_flow",
        "txn_count",
        "in_degree",
        "out_degree",
        "total_degree",
        "risk_score",
        "risk_tier",
        "edge_type",
    ]:
        vals = [G.nodes[n].get(attr, 0) for n in nodes]
        g.vs[attr] = vals
    return g, nodes, node_map


class AnalyticsLayer:
    """
    v12.4 High-Performance Analytics Engine — 10 families.
    P1: Parallel execution | P2: Sampling | P3: Fast algorithms
    P4: Hash caching | P5: Scipy ops | P6: Progressive stages
    Air-gapped, PII-safe, memory-efficient.
    """

    def __init__(self):
        self.results: Dict[str, pd.DataFrame] = {}
        self.analytics_config = PIPELINE.ANALYTICS
        self._ig_graph = None
        self._ig_nodes = None
        self._ig_node_map = None
        # v15.14 #2: Shared undirected projection — set once in run_all, reused by all families
        # Eliminates 4-5 redundant G.to_undirected() calls per pipeline run (~5-50ms each)
        self._G_und: Optional[nx.Graph] = None
        # v12.4: Performance tracking
        self._graph_hash: Optional[str] = None
        self._family_status: Dict[str, str] = {}
        self._perf_metrics: Dict[str, Dict] = {}

    # =========================================================================
    # v12.4: PERFORMANCE HELPERS (P1-P6)
    # =========================================================================
    def _compute_graph_hash(self, G: nx.DiGraph) -> str:
        """Fast hash of graph structure + weights for cache invalidation (P4).

        v16.19 BUG-2: Extended hash to include aggregate edge weight fingerprint.
        Previously only node/edge COUNTS + first 50 edges were hashed, causing stale
        cache hits when the same customers reload with different transaction amounts
        (identical topology, different weights). Now includes sum and max of ALL
        weights — O(E) but negligible vs analytics family runtimes.
        """
        h = _hashlib.md5()
        h.update(f"n{G.number_of_nodes()}e{G.number_of_edges()}".encode())
        # v16.19 BUG-2: Full weight fingerprint — prevents stale cache on amount-only changes
        _all_weights = [d.get("weight", 0) for _, _, d in G.edges(data=True)]
        _wt_sum = sum(_all_weights)
        _wt_max = max(_all_weights) if _all_weights else 0
        h.update(f"wsum{_wt_sum:.4f}wmax{_wt_max:.4f}".encode())
        for i, (u, v, d) in enumerate(G.edges(data=True)):
            if i >= 50:
                break
            h.update(f"{u}{v}{d.get('weight', 0):.2f}".encode())
        # v16.20 F21: Node attribute fingerprint — KYC/PEP changes now invalidate cache.
        # Resamples up to 100 nodes and hashes their key AML attributes.
        # Attribute-only changes (e.g., kyc_risk_rating updated) previously returned stale cache.
        _attr_keys = ("kyc_risk_rating", "pep_status", "risk_score", "kyc_status", "country",
                      "account_type", "occupation", "customer_segment")
        _sampled_nodes = list(G.nodes())[:100]  # deterministic: same order each call
        for _nd in _sampled_nodes:
            _attrs = G.nodes[_nd]
            _attr_sig = "".join(
                f"{k}={_attrs.get(k, '__')};"
                for k in _attr_keys
                if k in _attrs
            )
            if _attr_sig:
                h.update(_attr_sig.encode())
        return h.hexdigest()

    def _sample_graph(self, G: nx.DiGraph, sample_size: int):
        """Create representative subgraph for analytics (P2)."""
        n = G.number_of_nodes()
        if n <= sample_size:
            return G, set(G.nodes())
        # FIX-09: Remove dead risk_score component (always 0 at sample time, never computed yet)
        # Use degree + flow only — these are the only populated node attributes at this stage
        nodes_data = []
        for node in G.nodes():
            attrs = G.nodes[node]
            deg = G.degree(node)
            flow = abs(float(attrs.get("in_flow", 0) or 0)) + abs(
                float(attrs.get("out_flow", 0) or 0)
            )
            nodes_data.append((node, deg, flow))
        d_max = max((x[1] for x in nodes_data), default=1) or 1
        f_max = max((x[2] for x in nodes_data), default=1) or 1
        scored = [(nd[0], 0.5 * (nd[1] / d_max) + 0.5 * (nd[2] / f_max)) for nd in nodes_data]
        scored.sort(key=lambda x: x[1], reverse=True)
        # v15.5 FIX (P2): Pass-through node floor — include ALL nodes with both in_degree >= 1
        # AND out_degree >= 1 before filling remaining slots by degree+flow rank.
        # Pure rank cutoff by degree+flow drops low-degree mule intermediaries (layering nodes)
        # which are precisely the nodes receiving AND forwarding funds — not the highest-degree
        # nodes but the most critical AML typology targets.
        passthrough_floor = {
            nd for nd in G.nodes() if G.in_degree(nd) >= 1 and G.out_degree(nd) >= 1
        }
        # Start with pass-through nodes (take up to sample_size if there are very many)
        keep = set(list(passthrough_floor)[:sample_size])
        # Fill remaining slots from top-ranked scored nodes not already included
        if len(keep) < sample_size:
            for nd, _ in scored:
                if nd not in keep:
                    keep.add(nd)
                if len(keep) >= sample_size:
                    break
        sub = G.subgraph(keep).copy()
        log_audit(
            "GRAPH_SAMPLE",
            f"Sampled {sub.number_of_nodes()} from {n} nodes "
            f"(passthrough={len(passthrough_floor & keep)}, degree+flow fill)",
        )
        return sub, keep

    def _get_cached_family(self, family_name: str, graph_hash: str):
        """Check if cached result exists for this family+graph (P4).
        v15.14 #12: Also checks persistent disk cache (survives restarts)."""
        key = f"{family_name}_{graph_hash}"
        with _cache_lock:
            hit = _family_cache.get(key)
        if hit is not None:
            return hit
        # v15.14: Disk cache fallback
        if _DISK_CACHE_ENABLED:
            try:
                fpath = _DISK_CACHE_DIR / f"{key}.pkl"
                if fpath.exists():
                    with open(fpath, "rb") as fh:
                        df = _pickle.load(fh)
                    with _cache_lock:
                        _family_cache[key] = df  # warm in-memory cache too
                    return df
            except Exception:
                pass
        return None

    def _set_cached_family(self, family_name: str, graph_hash: str, df: pd.DataFrame):
        """Store result in cache (P4).
        v15.14 #12: Also writes to persistent disk cache."""
        key = f"{family_name}_{graph_hash}"
        with _cache_lock:
            _family_cache[key] = df
            if len(_family_cache) > 30:
                oldest = next(iter(_family_cache))
                del _family_cache[oldest]
        # v15.14: Write to disk async-safe (write to temp then rename for atomicity)
        if _DISK_CACHE_ENABLED:
            try:
                fpath = _DISK_CACHE_DIR / f"{key}.pkl"
                tmp_path = fpath.with_suffix(".tmp")
                with open(tmp_path, "wb") as fh:
                    _pickle.dump(df, fh, protocol=4)
                tmp_path.replace(fpath)
            except Exception:
                pass

    def _run_one_family(self, name: str, func, G: nx.DiGraph, params: Dict):
        """Run single family with timing and float32 quantization."""
        t0 = time.time()
        df = func(G, params)
        for col in df.select_dtypes(include=["float64"]).columns:
            df[col] = df[col].astype(np.float32)
        elapsed_ms = (time.time() - t0) * 1000
        display = FAMILY_DISPLAY_NAMES.get(name, name)
        log_audit(
            "ANALYTICS",
            f"{display}: {len(df)} nodes, " f"{len(df.columns) - 1} metrics, {elapsed_ms:.0f}ms",
        )
        return df, elapsed_ms

    def _run_families_batch(self, G, families, params, graph_hash, parallel, stop_check=None):
        """Run a batch of families, optionally in parallel (P1).

        v16.8 M2: stop_check callable — if provided and returns True, remaining
        families are skipped so stop_requested is honoured inside Stage 5.
        """
        if parallel and len(families) > 1:
            # v15.12 P3: use all available logical CPUs instead of hardcoded 6
            with ThreadPoolExecutor(
                max_workers=min(len(families), os.cpu_count() or 4)
            ) as executor:
                futures = {}
                for name, func in families:
                    # v16.8 M2: honour stop before submitting each family
                    if stop_check and stop_check():
                        log_audit("ANALYTICS_STOPPED", f"Stop requested before '{name}'")
                        self._family_status[name] = "skipped"
                        self.results[name] = pd.DataFrame({"node_id": list(G.nodes())})
                        continue
                    cached = self._get_cached_family(name, graph_hash)
                    if cached is not None:
                        self.results[name] = cached
                        self._family_status[name] = "cached"
                        self._perf_metrics[name] = {"time_ms": 0, "status": "cached"}
                        log_audit("ANALYTICS", f"{FAMILY_DISPLAY_NAMES.get(name, name)}: CACHED")
                        continue
                    family_params = {**self.analytics_config.get(name, {}), **params.get(name, {})}
                    self._family_status[name] = "running"
                    futures[executor.submit(self._run_one_family, name, func, G, family_params)] = (
                        name
                    )
                for future in as_completed(futures):
                    fname = futures[future]
                    try:
                        df, elapsed_ms = future.result()
                        self.results[fname] = df
                        self._family_status[fname] = "done"
                        self._perf_metrics[fname] = {"time_ms": elapsed_ms, "status": "done"}
                        self._set_cached_family(fname, graph_hash, df)
                    except Exception as e:
                        log_error(f"Family '{fname}' failed: {e}", exc=e)
                        self.results[fname] = pd.DataFrame({"node_id": list(G.nodes())})
                        self._family_status[fname] = "failed"
                        self._perf_metrics[fname] = {"time_ms": 0, "status": "failed"}
                    # v16.8 M2: after each completed future, propagate stop to remaining
                    if stop_check and stop_check():
                        log_audit("ANALYTICS_STOPPED", "Stop requested mid-parallel-batch")
                        for f in futures:
                            f.cancel()  # best-effort cancel of pending futures
                        break
        else:
            for name, func in families:
                # v16.8 M2: honour stop before each sequential family
                if stop_check and stop_check():
                    log_audit("ANALYTICS_STOPPED", f"Stop requested before '{name}'")
                    self._family_status[name] = "skipped"
                    self.results[name] = pd.DataFrame({"node_id": list(G.nodes())})
                    continue
                cached = self._get_cached_family(name, graph_hash)
                if cached is not None:
                    self.results[name] = cached
                    self._family_status[name] = "cached"
                    self._perf_metrics[name] = {"time_ms": 0, "status": "cached"}
                    continue
                self._family_status[name] = "running"
                family_params = {**self.analytics_config.get(name, {}), **params.get(name, {})}
                try:
                    df, elapsed_ms = self._run_one_family(name, func, G, family_params)
                    self.results[name] = df
                    self._family_status[name] = "done"
                    self._perf_metrics[name] = {"time_ms": elapsed_ms, "status": "done"}
                    self._set_cached_family(name, graph_hash, df)
                except Exception as e:
                    log_error(f"Family '{name}' failed: {e}", exc=e)
                    self.results[name] = pd.DataFrame({"node_id": list(G.nodes())})
                    self._family_status[name] = "failed"
                    self._perf_metrics[name] = {"time_ms": 0, "status": "failed"}
                # v15.12 C5: removed gc.collect() from sequential loop — was adding 5-20ms × 10 families

    def _extend_results_to_full(self, full_G: nx.DiGraph, sampled_nodes: set):
        """Extend sampled analytics results to cover all nodes in full graph (P2).
        v16.20 F08: Adds score_is_imputed=1 flag for rows filled by median imputation
        so investigators and the dashboard can distinguish computed vs imputed scores."""
        all_nodes = list(full_G.nodes())
        missing_nodes = set(all_nodes) - sampled_nodes
        if not missing_nodes:
            return
        for family_name, df in self.results.items():
            if "node_id" not in df.columns:
                continue
            numeric_cols = [
                c for c in df.columns if c != "node_id" and pd.api.types.is_numeric_dtype(df[c])
            ]
            medians = {col: float(df[col].median()) for col in numeric_cols}
            # F08 v16.20: mark all imputed rows clearly
            missing_rows = [{"node_id": node, "score_is_imputed": 1, **medians} for node in missing_nodes]
            if missing_rows:
                missing_df = pd.DataFrame(missing_rows)
                for col in missing_df.select_dtypes(include=["float64"]).columns:
                    missing_df[col] = missing_df[col].astype(np.float32)
                # Computed rows get score_is_imputed=0 if not already present
                if "score_is_imputed" not in df.columns:
                    df = df.copy()
                    df["score_is_imputed"] = 0
                    self.results[family_name] = df
                self.results[family_name] = pd.concat([self.results[family_name], missing_df], ignore_index=True)

    def get_family_status(self) -> Dict:
        """Get progressive status of each family (P6)."""
        return {
            "families": dict(self._family_status),
            "metrics": dict(self._perf_metrics),
            "completed": sum(1 for s in self._family_status.values() if s in ("done", "cached")),
            "total": len(self._family_status) if self._family_status else 10,
            "cached": sum(1 for s in self._family_status.values() if s == "cached"),
        }

    # =========================================================================
    # MAIN ENTRY POINT — v12.4 HIGH-PERFORMANCE
    # =========================================================================
    def run_all(
        self,
        G: nx.DiGraph,
        params: Dict[str, Any] = None,
        parallel: bool = True,
        sample_size: int = None,
        progressive: bool = False,
        progress_callback=None,
        stop_check=None,
    ) -> Dict[str, pd.DataFrame]:
        """
        v12.4 High-Performance 10-Family Analytics Engine.

        P1: Parallel family execution (ThreadPoolExecutor, 3-5x faster)
        P2: Graph sampling when node_count > sample_size (2-4x faster)
        P3: Faster algorithm approximations (built into each family)
        P4: Hash-based caching per family (5-10x on re-runs)
        P5: NumPy/Scipy matrix operations (built into families)
        P6: Progressive mode — fast families first, then slow
        v16.8 M2: stop_check callable — honour stop_requested inside Stage 5
        """
        params = params or {}

        if G is None or G.number_of_nodes() == 0:
            log_audit("ANALYTICS_SKIP", "Empty graph — returning empty results")
            empty = pd.DataFrame({"node_id": []})
            for name in FAMILY_DISPLAY_NAMES:
                self.results[name] = empty.copy()
                self._family_status[name] = "skipped"
            return self.results

        # ── P4: Compute graph hash for cache keying ──
        graph_hash = self._compute_graph_hash(G)

        # ── P2: Sample large graphs if user requested ──
        analytics_G = G
        sampled = False
        sampled_nodes = None
        if sample_size and G.number_of_nodes() > sample_size:
            analytics_G, sampled_nodes = self._sample_graph(G, sample_size)
            sampled = True

        # ── Build acceleration engines ──
        engines = []
        if HAS_IGRAPH:
            engines.append("igraph")
        if HAS_DATASKETCH:
            engines.append("MinHash")
        if HAS_PYOD:
            engines.append("ECOD")
        engine_str = "+".join(engines) if engines else "networkx"

        mode_flags = []
        if parallel:
            mode_flags.append("parallel")
        if sampled:
            mode_flags.append(f"sampled({sample_size})")
        if progressive:
            mode_flags.append("progressive")
        mode_str = "+".join(mode_flags) if mode_flags else "sequential"

        log_audit(
            "ANALYTICS_START",
            f"Running 10 families on {analytics_G.number_of_nodes()} nodes "
            f"[{engine_str}] mode={mode_str}",
        )

        if HAS_IGRAPH:
            try:
                t0 = time.time()
                self._ig_graph, self._ig_nodes, self._ig_node_map = _nx_to_igraph(analytics_G)
                log_audit("IGRAPH_BUILD", f"Converted in {(time.time() - t0) * 1000:.0f}ms")
            except Exception as e:
                log_audit("IGRAPH_SKIP", f"igraph conversion failed: {e}")
                self._ig_graph = None

        # v15.14 #2: Pre-compute undirected projection ONCE shared across ALL families
        # Removes 4–5 duplicate G.to_undirected() calls (∼5–50 ms each at n=500–10000)
        self._G_und = analytics_G.to_undirected()

        families = [
            ("centrality", self._centrality),
            ("community", self._community),
            ("pathflow", self._pathflow),
            ("link_prediction", self._link_prediction),
            ("anomaly", self._anomaly),
            ("temporal", self._temporal),
            ("multi_layer", self._multi_layer),
            ("structuring", self._structuring),
            ("benfords", self._benfords),
            ("motifs", self._motifs),
        ]

        total_t0 = time.time()
        self._family_status = {name: "pending" for name, _ in families}
        self._perf_metrics = {}

        if progressive:
            # ── P6: Stage 1 — Fast families first ──
            fast = [(n, f) for n, f in families if n in FAST_FAMILIES]
            slow = [(n, f) for n, f in families if n in SLOW_FAMILIES]

            self._run_families_batch(
                analytics_G, fast, params, graph_hash, parallel, stop_check=stop_check
            )
            if progress_callback:
                progress_callback(
                    "stage1_done",
                    {
                        "completed": [
                            n
                            for n in FAST_FAMILIES
                            if self._family_status.get(n) in ("done", "cached")
                        ],
                        "pending": [n for n, _ in slow],
                    },
                )

            # ── P6: Stage 2 — Slow families ──
            self._run_families_batch(
                analytics_G, slow, params, graph_hash, parallel, stop_check=stop_check
            )
            if progress_callback:
                progress_callback(
                    "stage2_done",
                    {
                        "completed": [
                            n
                            for n, _ in families
                            if self._family_status.get(n) in ("done", "cached")
                        ],
                        "pending": [],
                    },
                )
        else:
            # ── All families (P1: parallel if enabled) ──
            self._run_families_batch(
                analytics_G, families, params, graph_hash, parallel, stop_check=stop_check
            )

        # ── P2: Extend sampled results to cover full graph ──
        if sampled and sampled_nodes is not None:
            self._extend_results_to_full(G, sampled_nodes)

        self._graph_hash = graph_hash

        combined = self._combine_results(G)
        store_or_load("stage5_analytics", combined)
        total_ms = (time.time() - total_t0) * 1000
        cached_count = sum(1 for s in self._family_status.values() if s == "cached")
        log_audit(
            "ANALYTICS_COMPLETE",
            f"10 families, {len(combined.columns)} metrics, {total_ms:.0f}ms, "
            f"mode={mode_str}, cached={cached_count}",
        )
        return self.results

    # =========================================================================
    # FAMILY 1: NETWORK INFLUENCE HUB
    # =========================================================================
    def _centrality(self, G: nx.DiGraph, params: Dict) -> pd.DataFrame:
        nodes = list(G.nodes())
        df = pd.DataFrame({"node_id": nodes})
        # v15.14 #2: Reuse shared undirected projection (set in run_all) — no extra copy
        _G_und = self._G_und if self._G_und is not None else G.to_undirected()
        if HAS_IGRAPH and self._ig_graph is not None:
            g = self._ig_graph
            n = g.vcount()
            alpha = params.get("pagerank_alpha", 0.85)
            try:
                pr = g.personalized_pagerank(damping=alpha, directed=True, weights="weight")
                df["pagerank"] = pr
            except Exception:
                try:
                    pr = g.pagerank(damping=alpha, weights="weight")
                    df["pagerank"] = pr
                except Exception:
                    df["pagerank"] = 0
            # v15.22 FIX-DIR-BC: directed=True (was False).
            # AML justification: betweenness(directed) counts how often a node lies on the
            # shortest DIRECTED money-flow paths. A→X→B differs from B→X→A.
            # directed=False collapses both: receive-only nodes (sinks) appeared as brokers.
            # directed=True correctly identifies accounts that sit between money sources and
            # destinations in the flow direction — the structural definition of a money mule.
            bc_cutoff = params.get("betweenness_cutoff", 6)
            try:
                bc = g.betweenness(directed=True, cutoff=bc_cutoff, weights=None)
                max_bc = max(bc) if bc and max(bc) > 0 else 1
                df["betweenness"] = [b / max_bc for b in bc]
            except Exception:
                df["betweenness"] = 0
            try:
                cc = g.closeness(mode="ALL")
                df["closeness"] = [c if c is not None and not np.isnan(c) else 0 for c in cc]
            except Exception:
                df["closeness"] = 0
            df["degree_centrality"] = [d / (n - 1) for d in g.degree()] if n > 1 else [0] * n
            # FIX-01: Real eigenvector centrality using igraph C-backend
            # (was: degree/max_degree — that is NOT eigenvector centrality)
            try:
                ev = g.eigenvector_centrality(directed=True, scale=True, weights="weight")
                df["eigenvector"] = [max(0.0, float(v)) for v in ev]
            except Exception:
                try:
                    # Directed eigenvector can fail on DAGs — try undirected fallback
                    ev = g.as_undirected().eigenvector_centrality(scale=True)
                    df["eigenvector"] = [max(0.0, float(v)) for v in ev]
                except Exception:
                    df["eigenvector"] = 0
        else:
            G_und = _G_und  # v15.13 C1: reuse pre-computed undirected copy
            alpha = params.get("pagerank_alpha", 0.85)
            # FIX-02: max_iter from params (default 200, was 30 — insufficient for convergence)
            max_iter = params.get("pagerank_max_iter", 200)
            try:
                pr = nx.pagerank(G, alpha=alpha, max_iter=max_iter, tol=1e-6)
                df["pagerank"] = [pr.get(n, 0) for n in nodes]
            except Exception:
                df["pagerank"] = 0
            try:
                # v15.22 FIX-DIR-BC: Use directed G (not G_und) for betweenness.
                # Directed betweenness: broker = sits on directed money-flow shortest paths.
                # Using undirected projection was mathematically wrong — inflate scores of
                # pure receivers (sinks). Now: only accounts relaying money in the correct
                # direction score high. k scales to 10% sample coverage.
                k = min(len(nodes), max(50, len(nodes) // 10))
                bc = nx.betweenness_centrality(G, k=k, normalized=True)
                df["betweenness"] = [bc.get(n, 0) for n in nodes]
            except Exception:
                df["betweenness"] = 0
            try:
                cc = nx.closeness_centrality(G_und)
                df["closeness"] = [cc.get(n, 0) for n in nodes]
            except Exception:
                df["closeness"] = 0
            dc = nx.degree_centrality(G)
            df["degree_centrality"] = [dc.get(n, 0) for n in nodes]
            try:
                ec = nx.eigenvector_centrality_numpy(G_und)
                df["eigenvector"] = [ec.get(n, 0) for n in nodes]
            except Exception:
                df["eigenvector"] = 0
        # NEW-01 v14.3: HITS hub + authority (directed) — mule/layering vs placement/aggregator
        # v15.13 A1: scipy sparse power iteration — same math as nx.hits, ~10x faster.
        # h = A*a, a = A^T*h, normalise each step. Falls back to nx.hits on any error.
        try:
            import scipy.sparse as _sp_hits

            _A_hits = nx.to_scipy_sparse_array(G, nodelist=nodes, format="csr", dtype=float)
            _h = np.ones(len(nodes), dtype=float)
            _h /= _h.sum() + 1e-12
            _a = np.ones(len(nodes), dtype=float)
            _a /= _a.sum() + 1e-12
            _hits_tol = 1e-6
            for _ in range(params.get("hits_max_iter", 100)):
                _h_new = _A_hits.dot(_a)
                _h_new /= np.linalg.norm(_h_new) or 1
                _a_new = _A_hits.T.dot(_h_new)
                _a_new /= np.linalg.norm(_a_new) or 1
                if np.linalg.norm(_h_new - _h) + np.linalg.norm(_a_new - _a) < _hits_tol:
                    _h, _a = _h_new, _a_new
                    break
                _h, _a = _h_new, _a_new
            df["hits_hub"] = np.maximum(0.0, _h).tolist()
            df["hits_authority"] = np.maximum(0.0, _a).tolist()
        except Exception:
            try:
                hits_hub_d, hits_auth_d = nx.hits(G, max_iter=100, tol=1e-6, normalized=True)
                df["hits_hub"] = [max(0.0, float(hits_hub_d.get(n, 0))) for n in nodes]
                df["hits_authority"] = [max(0.0, float(hits_auth_d.get(n, 0))) for n in nodes]
            except Exception:
                df["hits_hub"] = 0.0
                df["hits_authority"] = 0.0
        # NEW-09 v14.4: Katz centrality — handles DAG + disconnected (eigenvector/PR = 0 on trees)
        # AML justification: shell company chains are often DAGs (money flows one direction).
        # Eigenvector = 0 on nodes with no in-edges in directed DAG; Katz uses a global attenuation
        # factor alpha so every node gets a non-zero score reflecting indirect reachability.
        # alpha auto-computed as 1/(2 * spectral_radius) for numerical stability.
        # NEW-09: Katz centrality — handles DAG + disconnected (shell company chains)
        # v15.13: scipy sparse spsolve for (I-αA)x = 1 (O(n) sparse vs O(n³) dense numpy inversion).
        # Falls back to nx.katz_centrality_numpy. Quality identical — same linear system.
        try:
            G_und_katz = _G_und  # v15.13 C1: reuse pre-computed undirected copy
            n_katz = G_und_katz.number_of_nodes()
            if n_katz > 1:
                try:
                    import scipy.sparse as _sp_katz
                    from scipy.sparse.linalg import eigsh as _eigsh_katz, spsolve as _spsolve

                    _A_katz = nx.to_scipy_sparse_array(
                        G_und_katz, nodelist=nodes, format="csr", dtype=float
                    )
                    try:
                        _eigs, _ = _eigsh_katz(_A_katz, k=1, which="LM", return_eigenvectors=True)
                        spectral_radius = float(abs(_eigs[0]))
                    except Exception:
                        spectral_radius = max((d for _, d in G_und_katz.degree()), default=1.0)
                    alpha_katz = 1.0 / (max(spectral_radius, 1.0) * 2 + 1e-8)
                    _I_katz = _sp_katz.eye(n_katz, format="csr", dtype=float)
                    _katz_vec = _spsolve(
                        _I_katz - alpha_katz * _A_katz, np.ones(n_katz, dtype=float)
                    )
                    _katz_vec = np.maximum(0.0, np.real(_katz_vec))
                    _kz = np.linalg.norm(_katz_vec)
                    _katz_vec /= _kz or 1
                    df["katz"] = _katz_vec.tolist()
                except Exception:
                    # Fallback: dense numpy inversion — slower but reliable
                    A = nx.to_scipy_sparse_array(G_und_katz, format="csr", dtype=float)
                    from scipy.sparse.linalg import eigsh

                    try:
                        eigs, _ = eigsh(A.astype(float), k=1, which="LM", return_eigenvectors=True)
                        spectral_radius = float(abs(eigs[0]))
                    except Exception:
                        spectral_radius = max((d for _, d in G_und_katz.degree()), default=1.0)
                    alpha_katz = 1.0 / (max(spectral_radius, 1.0) * 2 + 1e-8)
                    kc = nx.katz_centrality_numpy(G_und_katz, alpha=alpha_katz, normalized=True)
                    df["katz"] = [max(0.0, float(kc.get(n, 0))) for n in nodes]
            else:
                df["katz"] = 0.0
        except Exception:
            df["katz"] = 0.0

        # v15.6 NEW: K-Core decomposition — Criminal Ring Embedding Depth
        # Business value: Shows how deeply buried inside a transaction ring a
        # customer sits. K-core=1 = peripheral account (normal). K-core=3 =
        # inside a tight 3-way loop. K-core≥5 = deeply embedded in a complex
        # criminal ring structure (strong AML signal in unsupervised setting).
        # Shell company rings: typically K-core 3–8. Normal accounts: 1–2.
        # Algorithm: Batagelj-Zaversnik O(m). Built into NetworkX. Fast, exact.
        # Requires: node+edge tables only (works with minimum viable input).
        try:
            _G_und_kc = _G_und  # v15.13 C1: reuse pre-computed undirected copy
            _core_nums = nx.core_number(_G_und_kc)
            _max_core = max(_core_nums.values()) if _core_nums else 1
            df["k_core"] = [float(_core_nums.get(n, 0)) for n in nodes]
            df["k_core_norm"] = [
                float(_core_nums.get(n, 0)) / max(float(_max_core), 1.0) for n in nodes
            ]
        except Exception:
            df["k_core"] = 0.0
            df["k_core_norm"] = 0.0

        # v15.22 NEW-PL: Power-law degree tail probability (Clauset-Newman-Miller MLE)
        # ─────────────────────────────────────────────────────────────────────────────
        # AML networks are scale-free: most accounts have few connections, a rare few have
        # many (hubs). The power-law exponent α characterises this distribution.
        # A node whose degree falls in the extreme tail of the fitted power-law distribution
        # is a STRUCTURAL ANOMALY independent of any other behaviour metric.
        #
        # Business language: "This account has 847 counterparties. In a network of this
        # size, random chance predicts <0.1% of accounts should have this many connections.
        # Its connectivity is NOT explained by normal banking activity."
        #
        # Algorithm (Clauset-Newman-Miller MLE, 2009):
        #   α_hat = 1 + n / Σ ln(k_i / k_min)     [MLE estimator]
        #   P(K ≥ k) = (k / k_min)^(1-α_hat)       [tail probability under fitted power-law]
        #
        # Practical k_min: we use the degree value that minimises KS statistic vs fitted law.
        # Here we use a simplified version: k_min = median degree (robust, no optimization loop).
        # tail_prob close to 0 = structural anomaly; tail_prob = 1 = perfectly expected degree.
        #
        # Requires: node + edge tables only. No external packages. Pure numpy.
        try:
            _pl_kmin_mode = params.get("kmin_mode", "auto")
            _pl_kmin_fixed = params.get("kmin_fixed", 2)
            degrees = np.array([_G_und.degree(n) for n in nodes], dtype=float)
            if len(degrees) >= 10 and degrees.max() > 1:
                # Select k_min: auto = use median (robust for small samples)
                # For large graphs, median is a good robust xmin
                kmin = max(float(np.median(degrees)), 1.0)
                # Nodes with degree >= kmin form the power-law tail sample
                tail_mask = degrees >= kmin
                tail_degrees = degrees[tail_mask]
                n_tail = tail_mask.sum()
                if n_tail >= 5:
                    # MLE: α = 1 + n_tail / Σ ln(k_i / kmin)
                    ln_ratio = np.log(tail_degrees / kmin)
                    ln_ratio_sum = ln_ratio.sum()
                    alpha_pl = 1.0 + n_tail / (ln_ratio_sum + 1e-12)
                    alpha_pl = max(alpha_pl, 1.5)  # physical lower bound
                    # Tail probability for each node: P(K≥k) = (k/kmin)^(1-alpha)
                    # For k < kmin: probability = 1.0 (below threshold, expected)
                    tail_probs = np.ones(len(degrees), dtype=float)
                    for i, k_val in enumerate(degrees):
                        if k_val >= kmin:
                            tail_probs[i] = float((k_val / kmin) ** (1.0 - alpha_pl))
                    tail_probs = np.clip(tail_probs, 0.0, 1.0)
                    # is_powerlaw_tail = 1 when tail_prob < threshold (structural anomaly)
                    tail_alert_thresh = params.get("tail_prob_alert", 0.01)
                    df["powerlaw_tail_prob"] = np.float32(tail_probs)
                    df["is_powerlaw_tail"] = (tail_probs < tail_alert_thresh).astype(int)
                    # Anomaly score: 1 - tail_prob (higher = more anomalous connectivity)
                    df["powerlaw_anomaly_score"] = np.clip(1.0 - tail_probs, 0, 1).astype(
                        np.float32
                    )
                    # Store alpha for evidence text
                    df["powerlaw_alpha"] = np.float32(alpha_pl)
                else:
                    df["powerlaw_tail_prob"] = np.float32(1.0)
                    df["is_powerlaw_tail"] = 0
                    df["powerlaw_anomaly_score"] = np.float32(0.0)
                    df["powerlaw_alpha"] = np.float32(2.0)
            else:
                df["powerlaw_tail_prob"] = np.float32(1.0)
                df["is_powerlaw_tail"] = 0
                df["powerlaw_anomaly_score"] = np.float32(0.0)
                df["powerlaw_alpha"] = np.float32(2.0)
        except Exception:
            df["powerlaw_tail_prob"] = np.float32(1.0)
            df["is_powerlaw_tail"] = 0
            df["powerlaw_anomaly_score"] = np.float32(0.0)
            df["powerlaw_alpha"] = np.float32(2.0)

        return df

    # =========================================================================
    # FAMILY 2: TOPOLOGICAL CLUSTER ENGINE
    # =========================================================================
    def _community(self, G: nx.DiGraph, params: Dict) -> pd.DataFrame:
        nodes = list(G.nodes())
        df = pd.DataFrame({"node_id": nodes})
        # v15.22: define resolution at function level so both igraph and nx paths use same value
        resolution = params.get("louvain_resolution", 1.0)
        if HAS_IGRAPH and self._ig_graph is not None:
            g = self._ig_graph.as_undirected()
            np.random.seed(
                APP.RANDOM_SEED
            )  # v15.0: best-effort seed for igraph stochastic community methods
            try:
                leiden = g.community_leiden(
                    objective_function="modularity", resolution=resolution, n_iterations=3
                )
                df["louvain_community"] = leiden.membership
                df["louvain_n_communities"] = len(set(leiden.membership))
            except Exception:
                try:
                    louv = g.community_multilevel(weights=None)
                    df["louvain_community"] = louv.membership
                    df["louvain_n_communities"] = len(set(louv.membership))
                except Exception:
                    df["louvain_community"] = 0
                    df["louvain_n_communities"] = 1
            try:
                lp = g.community_label_propagation()
                df["label_prop_community"] = lp.membership
            except Exception:
                df["label_prop_community"] = 0
        else:
            # v15.14 #2: Reuse shared undirected projection
            G_und = self._G_und if self._G_und is not None else G.to_undirected()
            try:
                import community as community_louvain

                # v15.22: pass resolution to python-louvain best_partition (matches igraph path)
                try:
                    partition = community_louvain.best_partition(
                        G_und, random_state=APP.RANDOM_SEED, resolution=resolution
                    )
                except TypeError:
                    # Older community package versions lack resolution param — fall back gracefully
                    partition = community_louvain.best_partition(
                        G_und, random_state=APP.RANDOM_SEED
                    )
                df["louvain_community"] = [partition.get(n, -1) for n in nodes]
                df["louvain_n_communities"] = len(set(partition.values()))
            except ImportError:
                try:
                    # v15.14 #13: greedy_modularity_communities is O(n² log n) — too slow for n>200.
                    # label_propagation is O(n) and near-optimal for large graphs.
                    # For AML quality: greedy kept for small graphs (deterministic, best modularity).
                    if len(nodes) <= 200:
                        comms = list(nx.community.greedy_modularity_communities(G_und))
                    else:
                        comms = list(nx.community.label_propagation_communities(G_und))
                    n2c = {}
                    for i, c in enumerate(comms):
                        for node in c:
                            n2c[node] = i
                    df["louvain_community"] = [n2c.get(n, -1) for n in nodes]
                    df["louvain_n_communities"] = len(comms)
                except Exception:
                    df["louvain_community"] = 0
                    df["louvain_n_communities"] = 1
            try:
                lp_comms = list(nx.community.label_propagation_communities(G_und))
                n2lp = {}
                for i, c in enumerate(lp_comms):
                    for node in c:
                        n2lp[node] = i
                df["label_prop_community"] = [n2lp.get(n, -1) for n in nodes]
            except Exception:
                df["label_prop_community"] = 0
        if "louvain_community" in df.columns:
            comm_sizes = df["louvain_community"].value_counts().to_dict()
            df["community_size"] = df["louvain_community"].map(comm_sizes)
            # NEW-16 v14.4: Invert community size — small tight communities = higher AML risk.
            # Shell company rings are size 3-8 (not giant 1000-member clusters = normal businesses).
            # small_community_risk: size=3 -> 0.91, size=10 -> 0.37, size=100 -> 0.20, size=1000 -> 0.14
            comm_sizes_arr = df["community_size"].fillna(1).values.astype(float)
            df["small_community_risk"] = np.clip(
                1.0 / np.log(np.maximum(comm_sizes_arr, 1.0) + 2.0), 0, 1
            ).astype(np.float32)
        else:
            df["small_community_risk"] = np.float32(0)

        # v16.20 F10: Directed community detection via InfoMap.
        # InfoMap respects edge directionality (uses random walks on directed edges) —
        # unlike Louvain which projects to undirected and loses placement-layering distinction.
        # InfoMap identifies flow-based modules: accounts that form closed money-flow communities.
        # Run as SUPPLEMENTARY signal alongside undirected Louvain (not a replacement).
        # Graceful fallback: if igraph InfoMap unavailable, add directed asymmetry feature only.
        try:
            if HAS_IGRAPH and self._ig_graph is not None:
                _ig_dir = self._ig_graph  # keep directed graph
                try:
                    # community_infomap available in igraph >= 0.9
                    _im = _ig_dir.community_infomap()
                    df["infomap_community"] = _im.membership
                    _im_sizes = {}
                    for _m in _im.membership:
                        _im_sizes[_m] = _im_sizes.get(_m, 0) + 1
                    df["infomap_community_size"] = [_im_sizes.get(m, 1) for m in _im.membership]
                    # High signal: node in a small DIRECTED flow module (tighter than undirected community)
                    _im_sz_arr = np.array(df["infomap_community_size"].tolist(), dtype=float)
                    df["infomap_small_module_risk"] = np.clip(
                        1.0 / np.log(np.maximum(_im_sz_arr, 1.0) + 2.0), 0, 1
                    ).astype(np.float32)
                except (AttributeError, Exception):
                    # InfoMap not available — add directed asymmetry as directed-community proxy
                    df["infomap_community"] = df.get("louvain_community", 0)
                    df["infomap_community_size"] = df.get("community_size", 1)
                    df["infomap_small_module_risk"] = df.get("small_community_risk", np.float32(0))
            else:
                df["infomap_community"] = df.get("louvain_community", 0)
                df["infomap_community_size"] = df.get("community_size", 1)
                df["infomap_small_module_risk"] = df.get("small_community_risk", np.float32(0))

            # Directed asymmetry feature: within-community in_flow vs out_flow asymmetry.
            # Symmetric = legitimate business cluster. Asymmetric = directional money pipeline.
            # Formula: |out_flow - in_flow| / (out_flow + in_flow + eps) per community
            # Then assign community-mean asymmetry to each node member.
            try:
                _comm_col = "infomap_community"
                if _comm_col in df.columns:
                    _df_asym = df[["node_id", _comm_col]].copy()
                    _df_asym["in_flow"] = [float(G.nodes[nd].get("in_flow", 0) or 0) for nd in nodes]
                    _df_asym["out_flow"] = [float(G.nodes[nd].get("out_flow", 0) or 0) for nd in nodes]
                    _g_asym = _df_asym.groupby(_comm_col)[["in_flow", "out_flow"]].sum()
                    _g_asym["directed_asymmetry"] = (
                        (_g_asym["out_flow"] - _g_asym["in_flow"]).abs() /
                        (_g_asym["out_flow"] + _g_asym["in_flow"] + 1e-8)
                    )
                    _asym_map = _g_asym["directed_asymmetry"].to_dict()
                    df["directed_community_asymmetry"] = (
                        df[_comm_col].map(_asym_map).fillna(0.0).astype(np.float32)
                    )
            except Exception:
                df["directed_community_asymmetry"] = np.float32(0.0)
        except Exception:
            df["infomap_community"] = 0
            df["infomap_small_module_risk"] = np.float32(0.0)
            df["directed_community_asymmetry"] = np.float32(0.0)

        # v15.23 NEW-MRES: Multi-resolution Louvain stability sweep
        # ─────────────────────────────────────────────────────────
        # Running Louvain at a SINGLE resolution is a single point of failure:
        # resolution=1.5 catches rings 3-15 nodes but may fragment larger rings.
        # Running at 3 resolutions (1.0, 1.5, 2.0) and taking the majority-vote
        # community assignment gives a STABLE label: a node is in the same community
        # 2/3 or 3/3 resolutions = high-confidence ring membership.
        #
        # louvain_stability: 1.0 = all 3 resolutions agree (highest confidence)
        #                    0.67 = 2/3 agree (moderate confidence)
        #                    0.33 = only 1 agrees (lowest confidence)
        #
        # Business value: "Account X is in the same tight transaction ring across all
        # three analytical lenses — ring membership is confirmed, not an artefact of
        # one particular algorithm setting."
        #
        # louvain_community_stable: the majority-vote community ID
        # louvain_stability: fraction of resolutions that agreed on this assignment
        #
        # Requires: node + edge table only (igraph/nx already computed above).
        # Graceful exception handling: falls back to stability=0, community=-1 on any error.
        try:
            _multi_res = params.get("louvain_multi_resolution", [1.0, 1.5, 2.0])
            if isinstance(_multi_res, list) and len(_multi_res) >= 2 and len(nodes) >= 4:
                _G_und_mr = self._G_und if self._G_und is not None else G.to_undirected()
                _res_assignments = []  # list of: array[node_idx] -> community_id
                np.random.seed(
                    APP.RANDOM_SEED
                )  # v16.2 C1: ensure deterministic multi-resolution sweep
                for _res in _multi_res:
                    try:
                        if HAS_IGRAPH and self._ig_graph is not None:
                            _g_mr = self._ig_graph.as_undirected()
                            try:
                                _part = _g_mr.community_leiden(
                                    objective_function="modularity",
                                    resolution=float(_res),
                                    n_iterations=2,
                                )
                                _res_assignments.append(np.array(_part.membership, dtype=int))
                            except Exception:
                                try:
                                    _part2 = _g_mr.community_multilevel(weights=None)
                                    _res_assignments.append(np.array(_part2.membership, dtype=int))
                                except Exception:
                                    pass
                        else:
                            try:
                                import community as _cl

                                try:
                                    _part = _cl.best_partition(
                                        _G_und_mr,
                                        random_state=APP.RANDOM_SEED,
                                        resolution=float(_res),
                                    )
                                except TypeError:
                                    _part = _cl.best_partition(
                                        _G_und_mr, random_state=APP.RANDOM_SEED
                                    )
                                _res_assignments.append(
                                    np.array([_part.get(n, -1) for n in nodes], dtype=int)
                                )
                            except ImportError:
                                _comms = list(nx.community.label_propagation_communities(_G_und_mr))
                                _n2c = {nd: i for i, c in enumerate(_comms) for nd in c}
                                _res_assignments.append(
                                    np.array([_n2c.get(n, -1) for n in nodes], dtype=int)
                                )
                    except Exception:
                        pass  # skip this resolution, continue with others

                if len(_res_assignments) >= 2:
                    n_res = len(_res_assignments)  # actual number of successful runs
                    n_nodes = len(nodes)
                    # Majority-vote: for each node, find the modal community ID
                    # Community IDs are arbitrary integers — we compare pairwise agreement
                    _stable_comm = np.full(n_nodes, -1, dtype=int)
                    _stability = np.zeros(n_nodes, dtype=np.float32)
                    for _i in range(n_nodes):
                        _votes = [_ra[_i] for _ra in _res_assignments]
                        # Count pairwise agreements: how many pairs of resolutions assign same community
                        _agree_counts = {}
                        for _vi, _v in enumerate(_votes):
                            _agree_counts[_v] = _agree_counts.get(_v, 0) + 1
                        # Most common community in this node across resolutions
                        _best_comm = max(_agree_counts, key=_agree_counts.get)
                        _best_cnt = _agree_counts[_best_comm]
                        _stable_comm[_i] = _best_comm
                        _stability[_i] = float(_best_cnt) / float(n_res)
                    df["louvain_community_stable"] = _stable_comm.tolist()
                    df["louvain_stability"] = _stability
                    # High-confidence ring flag: stable + small+tight community
                    # (combines multi-resolution agreement with ring size signal)
                    if "small_community_risk" in df.columns:
                        _scr = df["small_community_risk"].values.astype(float)
                        df["ring_confidence"] = np.clip(_stability * _scr, 0, 1).astype(np.float32)
                    else:
                        df["ring_confidence"] = _stability
                else:
                    # Not enough successful resolutions — fallback
                    df["louvain_community_stable"] = df.get(
                        "louvain_community", pd.Series([-1] * len(nodes))
                    )
                    df["louvain_stability"] = np.float32(0.33)
                    df["ring_confidence"] = np.float32(0.0)
            else:
                df["louvain_community_stable"] = df.get("louvain_community", -1)
                df["louvain_stability"] = np.float32(0.0)
                df["ring_confidence"] = np.float32(0.0)
        except Exception:
            df["louvain_community_stable"] = -1
            df["louvain_stability"] = np.float32(0.0)
            df["ring_confidence"] = np.float32(0.0)

        return df

    # =========================================================================
    # FAMILY 3: LAUNDERING TRACEABILITY LOGIC
    # =========================================================================
    def _pathflow(self, G: nx.DiGraph, params: Dict) -> pd.DataFrame:
        nodes = list(G.nodes())
        df = pd.DataFrame({"node_id": nodes})

        # v16.20 F11: Passthrough-floor sampling for path analysis.
        # Old approach: degree-weighted sampling missed low-degree mule/layering intermediaries.
        # New approach:
        #   Tier-1: ALL passthrough nodes (in>=1 AND out>=1) — these are AML-critical relays.
        #   Tier-2: Fill remaining sample slots with degree-weighted selection from non-passthrough.
        # Works for any N from 50 to 10000+.
        def _build_sample_ids_nx(G, nodes, sample_size):
            """Return list of node indices into `nodes` list (passthrough-floor + degree fill)."""
            passthrough_idx = [
                i for i, nd in enumerate(nodes)
                if G.in_degree(nd) >= 1 and G.out_degree(nd) >= 1
            ]
            keep_idx = passthrough_idx[:sample_size]
            if len(keep_idx) < sample_size:
                remaining_idx = [i for i in range(len(nodes)) if i not in set(keep_idx)]
                degs = np.array([G.degree(nodes[i]) for i in remaining_idx], dtype=float) + 1.0
                degs /= degs.sum()
                fill_n = min(sample_size - len(keep_idx), len(remaining_idx))
                if fill_n > 0:
                    extra = np.random.choice(remaining_idx, size=fill_n, replace=False, p=degs).tolist()
                    keep_idx = keep_idx + extra
            return keep_idx

        if HAS_IGRAPH and self._ig_graph is not None:
            g = self._ig_graph
            try:
                sample_size = min(max(30, min(100, g.vcount())), g.vcount())
                # Map igraph vertex IDs through passthrough logic using the node list
                _ig_nodes = self._ig_nodes if self._ig_nodes is not None else list(range(g.vcount()))
                _ig_in_deg = g.indegree()
                _ig_out_deg = g.outdegree()
                passthrough_v = [
                    i for i in range(g.vcount())
                    if _ig_in_deg[i] >= 1 and _ig_out_deg[i] >= 1
                ]
                sample_ids = passthrough_v[:sample_size]
                if len(sample_ids) < sample_size:
                    remaining_v = [i for i in range(g.vcount()) if i not in set(sample_ids)]
                    _deg_rem = np.array([g.degree(i) for i in remaining_v], dtype=float) + 1.0
                    _deg_rem /= _deg_rem.sum()
                    fill_n = min(sample_size - len(sample_ids), len(remaining_v))
                    if fill_n > 0:
                        extra = np.random.choice(remaining_v, size=fill_n, replace=False, p=_deg_rem).tolist()
                        sample_ids = sample_ids + extra
                sp_matrix = g.distances(source=sample_ids, mode="out")
                avg_lengths = {}
                for row_idx, vid in enumerate(sample_ids):
                    lengths = sp_matrix[row_idx]
                    finite = [l for l in lengths if l < float("inf") and l > 0 and l <= 5]
                    avg_lengths[vid] = np.mean(finite) if finite else 0
                df["avg_path_length"] = [avg_lengths.get(i, 0) for i in range(g.vcount())]
            except Exception:
                df["avg_path_length"] = 0
            try:
                bc = g.betweenness(directed=True, cutoff=3, weights="weight")
                max_bc = max(bc) if bc and max(bc) > 0 else 1
                df["flow_centrality"] = [b / max_bc for b in bc]
            except Exception:
                df["flow_centrality"] = 0
        else:
            try:
                sample_size = min(max(30, min(100, len(nodes))), len(nodes))
                _sample_idx = _build_sample_ids_nx(G, nodes, sample_size)
                sample_nodes = [nodes[i] for i in _sample_idx]
                try:
                    import scipy.sparse as _sp_pf
                    from scipy.sparse.csgraph import shortest_path as _csgraph_sp

                    _A_pf = nx.to_scipy_sparse_array(
                        G, nodelist=nodes, format="csr", weight="weight", dtype=np.float32
                    )
                    _nd2idx = {nd: i for i, nd in enumerate(nodes)}
                    _sample_idx2 = [_nd2idx[nd] for nd in sample_nodes if nd in _nd2idx]
                    _D = _csgraph_sp(
                        _A_pf, method="D", directed=True, indices=_sample_idx2, limit=5.0
                    )
                    avg_path = {}
                    for row_i, src_nd in enumerate([nodes[i] for i in _sample_idx2]):
                        row = _D[row_i] if _D.ndim == 2 else _D
                        finite = row[(row > 0) & (row <= 5.0) & ~np.isinf(row)]
                        avg_path[src_nd] = float(np.mean(finite)) if len(finite) > 0 else 0.0
                except Exception:
                    avg_path = {}
                    for nd in sample_nodes:
                        try:
                            lengths = nx.single_source_shortest_path_length(G, nd, cutoff=5)
                            avg_path[nd] = (
                                float(np.mean(list(lengths.values()))) if lengths else 0.0
                            )
                        except Exception:
                            avg_path[nd] = 0.0
                df["avg_path_length"] = [avg_path.get(n, 0) for n in nodes]
            except Exception:
                df["avg_path_length"] = 0
            try:
                _cent_r = self.results.get("centrality")
                if _cent_r is not None and "betweenness" in _cent_r.columns:
                    _bc_map = dict(zip(_cent_r["node_id"], _cent_r["betweenness"]))
                    df["flow_centrality"] = [float(_bc_map.get(n, 0)) for n in nodes]
                else:
                    _G_und_pf = self._G_und if self._G_und is not None else G.to_undirected()
                    k_fc = max(20, min(200, int(len(nodes) ** 0.5 * 3)))
                    fc = nx.betweenness_centrality(
                        _G_und_pf, k=k_fc, normalized=True, weight="weight"
                    )
                    df["flow_centrality"] = [fc.get(n, 0) for n in nodes]
            except Exception:
                df["flow_centrality"] = 0
        return df

    # =========================================================================
    # FAMILY 4: HIDDEN ASSOCIATION PREDICTOR
    # =========================================================================
    def _link_prediction(self, G: nx.DiGraph, params: Dict) -> pd.DataFrame:
        nodes = list(G.nodes())
        df = pd.DataFrame({"node_id": nodes})
        if HAS_IGRAPH and self._ig_graph is not None:
            g = self._ig_graph.as_undirected()
            n = g.vcount()
            if HAS_DATASKETCH and n > 5:
                try:
                    num_perm = 64
                    minhashes = {}
                    for i in range(n):
                        m = MinHash(num_perm=num_perm)
                        nbs = g.neighbors(i)
                        for nb in nbs:
                            m.update(str(nb).encode("utf-8"))
                        if not nbs:
                            m.update(b"__empty__")
                        minhashes[i] = m
                    lsh = MinHashLSH(threshold=0.1, num_perm=num_perm)
                    for i, mh in minhashes.items():
                        try:
                            lsh.insert(str(i), mh)
                        except Exception:
                            pass
                    jaccard_avg = []
                    for i in range(n):
                        try:
                            candidates = lsh.query(minhashes[i])
                            sims = [
                                minhashes[i].jaccard(minhashes[int(c)])
                                for c in candidates[:20]
                                if int(c) != i
                            ]
                            jaccard_avg.append(np.mean(sims) if sims else 0)
                        except Exception:
                            jaccard_avg.append(0)
                    df["jaccard_avg"] = jaccard_avg
                except Exception:
                    df["jaccard_avg"] = 0
            else:
                try:
                    sample = min(n, 100)
                    sample_ids = np.random.choice(n, size=sample, replace=False)
                    sim = g.similarity_jaccard(pairs=None, mode="ALL", loops=False)
                    jaccard_avg = [
                        (
                            np.mean([sim[i][j] for j in sample_ids if j != i])
                            if len(sample_ids) > 1
                            else 0
                        )
                        for i in range(n)
                    ]
                    df["jaccard_avg"] = jaccard_avg
                except Exception:
                    df["jaccard_avg"] = 0
            try:
                degrees = np.array(g.degree(), dtype=float)
                degrees[degrees == 0] = 1
                log_deg = np.log(degrees)
                log_deg[log_deg == 0] = 1
                aa_scores = [
                    np.mean(1.0 / log_deg[g.neighbors(i)]) if g.neighbors(i) else 0
                    for i in range(n)
                ]
                df["adamic_adar_avg"] = aa_scores
            except Exception:
                df["adamic_adar_avg"] = 0
            # v15.5 FIX (FIX-08 igraph path): Distance-to-high-risk-anchor replaces PA.
            # PA (deg * mean_deg) is a generic scale-free metric, not AML-specific.
            # Being proximate to high-risk nodes in the transaction graph is the real signal.
            # Anchors: top-10% by risk_score (from node table) or in_flow as fallback.
            # Score: 1/(1+min_dist) so adjacent-to-anchor = 1.0, 5 hops away = 0.17.
            try:
                # v15.14 #2: Reuse shared undirected projection for anchor BFS
                _G_und_anchor = self._G_und if self._G_und is not None else G.to_undirected()
                _risk_v = np.array([float(G.nodes[nd].get("risk_score", 0) or 0) for nd in nodes])
                if _risk_v.max() > 0:
                    _anchor_cut = np.percentile(_risk_v, 90)
                    _anchor_set = {nd for nd, rv in zip(nodes, _risk_v) if rv >= _anchor_cut}
                else:
                    _inflow_v = np.array(
                        [float(G.nodes[nd].get("in_flow", 0) or 0) for nd in nodes]
                    )
                    _anchor_cut = np.percentile(_inflow_v, 90)
                    _anchor_set = {nd for nd, iv in zip(nodes, _inflow_v) if iv >= _anchor_cut}
                if not _anchor_set:
                    _anchor_set = set(nodes[: max(1, len(nodes) // 10)])
                # v15.13 A4: cap anchor BFS calls to 20 — top-90th-%ile already captured
                if len(_anchor_set) > 20:
                    _anchor_set = set(list(_anchor_set)[:20])
                _min_dist = {nd: 999 for nd in nodes}
                for _anc in _anchor_set:
                    try:
                        for nd, d in nx.single_source_shortest_path_length(
                            _G_und_anchor, _anc, cutoff=5
                        ).items():
                            if d < _min_dist.get(nd, 999):
                                _min_dist[nd] = d
                    except Exception:
                        pass
                _prox = np.array([1.0 / (1.0 + _min_dist.get(nd, 999)) for nd in nodes])
                df["pref_attachment"] = np.clip(_prox, 0, 1).astype(np.float32)
            except Exception:
                df["pref_attachment"] = 0
        else:
            # v15.14 #2: Reuse shared undirected projection
            G_und = self._G_und if self._G_und is not None else G.to_undirected()
            # v15.14 #4: Replace per-node Jaccard + Adamic-Adar Python loops with
            # scipy.sparse vectorised computation. O(nnz) vs O(n²) for large graphs.
            # Math: Jaccard(u,v) = |N(u)∩N(v)| / |N(u)∪N(v)|
            # Mean Jaccard for node u = (A @ deg)[u] / (n*deg[u] + total_deg - (A @ deg)[u])
            # Adamic-Adar weight per common neighbour z = deg[z]/log(deg[z])
            # AA_sum[u] = (A @ aa_wt)[u]
            try:
                import scipy.sparse as _sp_lp

                _A_lp = nx.to_scipy_sparse_array(
                    G_und, nodelist=nodes, format="csr", dtype=np.float32
                )
                _A_bin = (_A_lp > 0).astype(np.float32)
                _deg_lp = np.array(_A_bin.sum(axis=1)).flatten().astype(np.float32)
                _n_lp = len(nodes)
                _total_deg = float(_deg_lp.sum())
                # (A @ deg)[i] = sum of degrees of i's neighbours = sum_v intersection(i,v)
                _inter_sum = np.array(_A_bin.dot(_deg_lp)).flatten().astype(np.float64)
                _denom_jac = _n_lp * _deg_lp.astype(np.float64) + _total_deg - _inter_sum
                _jaccard_v = np.where(_denom_jac > 1e-10, _inter_sum / _denom_jac, 0.0)
                df["jaccard_avg"] = np.clip(_jaccard_v, 0, 1).astype(np.float32).tolist()
                # Adamic-Adar: AA weight for each node = deg / log(deg+1)
                _aa_wt = np.where(_deg_lp > 0, _deg_lp / np.log(_deg_lp + 1.0), 0.0).astype(
                    np.float32
                )
                _aa_sum = np.array(_A_bin.dot(_aa_wt)).flatten().astype(np.float64)
                _aa_max = _aa_sum.max() if _aa_sum.max() > 0 else 1.0
                df["adamic_adar_avg"] = (
                    np.clip(_aa_sum / (_aa_max * max(_n_lp, 1)), 0, 1).astype(np.float32).tolist()
                )
            except Exception:
                # Fallback: per-node sampled NX Jaccard/AA
                try:
                    jaccard_scores = {}
                    for n_node in nodes:
                        neighbors = set(G_und.neighbors(n_node))
                        non_nb = list(set(nodes) - neighbors - {n_node})[:30]
                        if non_nb:
                            jc = list(
                                nx.jaccard_coefficient(G_und, [(n_node, nn) for nn in non_nb])
                            )
                            jaccard_scores[n_node] = np.mean([s for _, _, s in jc])
                        else:
                            jaccard_scores[n_node] = 0
                    df["jaccard_avg"] = [jaccard_scores.get(n, 0) for n in nodes]
                except Exception:
                    df["jaccard_avg"] = 0
                try:
                    aa_scores = {}
                    for n_node in nodes:
                        neighbors = set(G_und.neighbors(n_node))
                        non_nb = list(set(nodes) - neighbors - {n_node})[:30]
                        if non_nb:
                            aa = list(nx.adamic_adar_index(G_und, [(n_node, nn) for nn in non_nb]))
                            aa_scores[n_node] = np.mean([s for _, _, s in aa])
                        else:
                            aa_scores[n_node] = 0
                    df["adamic_adar_avg"] = [aa_scores.get(n, 0) for n in nodes]
                except Exception:
                    df["adamic_adar_avg"] = 0
            # v15.5 FIX (FIX-08 NetworkX path): Distance-to-high-risk-anchor replaces PA.
            # PA (deg * mean_deg) is a generic scale-free metric, not AML-specific.
            # Score: 1/(1+min_dist) so adjacent-to-anchor = 1.0, 5 hops away = 0.17.
            try:
                _risk_v2 = np.array([float(G.nodes[nd].get("risk_score", 0) or 0) for nd in nodes])
                if _risk_v2.max() > 0:
                    _anchor_cut2 = np.percentile(_risk_v2, 90)
                    _anchor_set2 = {nd for nd, rv in zip(nodes, _risk_v2) if rv >= _anchor_cut2}
                else:
                    _inflow_v2 = np.array(
                        [float(G.nodes[nd].get("in_flow", 0) or 0) for nd in nodes]
                    )
                    _anchor_cut2 = np.percentile(_inflow_v2, 90)
                    _anchor_set2 = {nd for nd, iv in zip(nodes, _inflow_v2) if iv >= _anchor_cut2}
                if not _anchor_set2:
                    _anchor_set2 = set(nodes[: max(1, len(nodes) // 10)])
                # v15.13 A5: cap anchor BFS calls to 20 — mirrors igraph path A4 cap
                if len(_anchor_set2) > 20:
                    _anchor_set2 = set(list(_anchor_set2)[:20])
                _min_dist2 = {nd: 999 for nd in nodes}
                for _anc2 in _anchor_set2:
                    try:
                        for nd, d in nx.single_source_shortest_path_length(
                            G_und, _anc2, cutoff=5
                        ).items():
                            if d < _min_dist2.get(nd, 999):
                                _min_dist2[nd] = d
                    except Exception:
                        pass
                _prox2 = np.array([1.0 / (1.0 + _min_dist2.get(nd, 999)) for nd in nodes])
                df["pref_attachment"] = np.clip(_prox2, 0, 1).astype(np.float32)
            except Exception:
                df["pref_attachment"] = 0
        # NEW-12 v14.4: Unexplained connection score — reframes Jaccard/AA as AML signals.
        # Original Jaccard/AA: high similarity = likely future edge (link PREDICTION use-case).
        # AML use: low similarity + high transaction volume = suspicious (no relationship basis).
        # unexplained = (1 - jaccard_avg) * (1 + volume_factor * weight)
        # volume_factor = normalized (in_flow+out_flow) of the node.
        try:
            vol_wt = params.get("unexplained_volume_weight", 0.5)
            in_flows_lp = np.array([float(G.nodes[nd].get("in_flow", 0) or 0) for nd in nodes])
            out_flows_lp = np.array([float(G.nodes[nd].get("out_flow", 0) or 0) for nd in nodes])
            total_vol = in_flows_lp + out_flows_lp
            max_vol = total_vol.max() if total_vol.max() > 0 else 1.0
            vol_norm = total_vol / max_vol  # [0, 1]
            jac_arr = np.array(
                df.get("jaccard_avg", pd.Series(np.zeros(len(nodes)))).values, dtype=float
            )
            aa_arr = np.array(
                df.get("adamic_adar_avg", pd.Series(np.zeros(len(nodes)))).values, dtype=float
            )
            # Clip AA to [0,1] — raw AA scores can exceed 1 (log-based, unbounded)
            aa_max = aa_arr.max() if aa_arr.max() > 0 else 1.0
            aa_norm = np.clip(aa_arr / aa_max, 0, 1)
            df["unexplained_jaccard"] = (
                np.clip((1.0 - jac_arr) * (1.0 + vol_norm * vol_wt), 0, 2).astype(np.float32) / 2.0
            )  # rescale to [0,1]
            df["unexplained_adamic"] = (
                np.clip((1.0 - aa_norm) * (1.0 + vol_norm * vol_wt), 0, 2).astype(np.float32) / 2.0
            )
        except Exception:
            df["unexplained_jaccard"] = np.float32(0)
            df["unexplained_adamic"] = np.float32(0)
        return df

    # =========================================================================
    # FAMILY 5: TOPOLOGICAL OUTLIER DETECTOR
    # =========================================================================
    def _anomaly(self, G: nx.DiGraph, params: Dict) -> pd.DataFrame:
        nodes = list(G.nodes())
        df = pd.DataFrame({"node_id": nodes})
        feature_cols = []
        # v15.7 FIX: Removed total_degree (= in_degree + out_degree — purely redundant).
        # v15.8 ADD: shared_infrastructure_count — number of hidden-connection partners per
        # node (computed in l2_aggregate v15.7 from shared Device/Phone/IP/Address pairs).
        # Including it here lets ECOD/LOF factor in the shared-infrastructure signal during
        # multivariate anomaly detection. A node sharing a device with 3 other nodes AND
        # showing high in_flow is qualitatively different from a node with high in_flow alone.
        # This is a continuous count (0, 1, 2, ...), stored as a graph node attribute by l3.
        _base_attrs = [
            "in_degree",
            "out_degree",
            "in_flow",
            "out_flow",
            "txn_count",
            "shared_infrastructure_count",  # v15.8: hidden-connection partner count
        ]
        # v15.13 B4: Single dict-access pass for all attrs (replaces 6 separate O(n) list comps)
        _n_nodes = len(nodes)
        _attr_arrs = {a: np.zeros(_n_nodes, dtype=float) for a in _base_attrs}
        for _i, _nd in enumerate(nodes):
            _nd_d = G.nodes[_nd]
            for _a in _base_attrs:
                _attr_arrs[_a][_i] = float(_nd_d.get(_a, 0) or 0)
        for attr in _base_attrs:
            df[attr] = _attr_arrs[attr]
            if np.std(_attr_arrs[attr]) > 0:
                feature_cols.append(attr)
        # SCC ring-membership flag (1 = inside a circular-flow ring, 0 = not)
        _in_ring_vals = [float(G.nodes[n].get("in_ring", 0) or 0) for n in nodes]
        if np.std(_in_ring_vals) > 0:
            df["in_ring"] = _in_ring_vals
            feature_cols.append("in_ring")
        # Pull betweenness and k_core_norm from already-computed centrality family result
        _cent_df = self.results.get("centrality") if hasattr(self, "results") else None
        if _cent_df is not None and "node_id" in _cent_df.columns:
            try:
                # v15.14 #14: pandas merge replaces per-node .at[] dict lookups
                _feat_cols = [f for f in ["betweenness", "k_core_norm"] if f in _cent_df.columns]
                if _feat_cols:
                    _tmp = (
                        pd.DataFrame({"node_id": nodes})
                        .merge(_cent_df[["node_id"] + _feat_cols], on="node_id", how="left")
                        .fillna(0.0)
                    )
                    for _feat in _feat_cols:
                        _fvals = _tmp[_feat].values.astype(float)
                        if np.std(_fvals) > 0:
                            df[_feat] = _fvals
                            feature_cols.append(_feat)
            except Exception:
                pass
        # v16.19 BUG-3: Guarantee ≥ 2 features even for uniformly sparse graphs.
        # Original guard returned all-zero scores when base attribute variances were 0
        # (e.g. homogeneous synthetic data or very small graphs). This created a silent
        # dead-zone — precisely in the sparse topologies used by AML structuring rings.
        # Fallback: pure graph-degree features are always available and non-degenerate
        # in any graph with > 1 node and heterogeneous connectivity.
        if len(feature_cols) < 2:
            _deg_dict_fb = dict(G.degree())
            _indeg_dict_fb = dict(G.in_degree())
            _outdeg_dict_fb = dict(G.out_degree())
            _indeg_fb = np.array([float(_indeg_dict_fb.get(n, 0)) for n in nodes], dtype=float)
            _outdeg_fb = np.array([float(_outdeg_dict_fb.get(n, 0)) for n in nodes], dtype=float)
            _deg_fb = np.array([float(_deg_dict_fb.get(n, 0)) for n in nodes], dtype=float)
            if "in_degree" not in feature_cols:
                df["in_degree"] = _indeg_fb
                feature_cols.append("in_degree")
            if "out_degree" not in feature_cols:
                df["out_degree"] = _outdeg_fb
                feature_cols.append("out_degree")
            if len(feature_cols) < 2 and "degree_total" not in feature_cols:
                df["degree_total"] = _deg_fb
                feature_cols.append("degree_total")
        if len(feature_cols) < 2:
            df["anomaly_score_if"] = 0
            df["anomaly_score_lof"] = 0
            df["anomaly_score_zscore"] = 0
            return df
        X = np.nan_to_num(df[feature_cols].values.astype(float), nan=0)
        contamination = params.get("contamination", 0.05)
        if HAS_PYOD:
            try:
                # v15.14 #9: n_jobs=1 for small n — Windows process-spawn overhead > parallel gain
                _n_jobs_ecod = 1 if len(nodes) < 1000 else -1
                ecod = ECOD(contamination=contamination, n_jobs=_n_jobs_ecod)
                ecod.fit(X)
                scores = ecod.decision_scores_
                df["anomaly_score_if"] = (scores - scores.min()) / (
                    scores.max() - scores.min() + 1e-8
                )
            except Exception:
                df["anomaly_score_if"] = 0
        elif HAS_SKLEARN:
            try:
                iso = IsolationForest(
                    contamination=contamination, random_state=APP.RANDOM_SEED, n_jobs=-1
                )
                iso.fit(X)
                scores = -iso.decision_function(X)
                df["anomaly_score_if"] = (scores - scores.min()) / (
                    scores.max() - scores.min() + 1e-8
                )
            except Exception:
                df["anomaly_score_if"] = 0
        else:
            df["anomaly_score_if"] = 0
        # v15.5 FIX (replaces NEW-02 HBOS): HBOS removed — subsampled LOF used for large graphs.
        # HBOS treated each feature independently (per-axis histogram) — misses correlated AML
        # signals such as high in_flow + low out_degree simultaneously (smurfing pattern).
        # ECOD in anomaly_score_if already models full multivariate distribution.
        # anomaly_score_lof: LOF preserves local-density semantics across all graph sizes;
        # for n > lof_max_n we subsample, compute LOF on the sample, then assign median score
        # to unsampled nodes (conservative — does not inflate their scores).
        lof_max_n = params.get("lof_max_n", 2000)
        if HAS_SKLEARN:
            try:
                n_nb = min(20, len(nodes) - 1)
                if n_nb > 1:
                    if len(nodes) > lof_max_n:
                        # v16.19 BUG-6: ECOD-guided LOF subsample replaces random selection.
                        # Previous random subsample gave ring members (~50-node clusters in
                        # 10k-node graph) only ~50% inclusion probability — AML false negatives.
                        # Fix: prioritise nodes by ECOD anomaly score (already computed above).
                        # ECOD runs on ALL nodes (no size limit) so its scores are reliable.
                        # High-ECOD nodes get LOF computed; unsampled low-risk nodes inherit
                        # their ECOD score converted to LOF scale (conservative).
                        if "anomaly_score_if" in df.columns and df["anomaly_score_if"].sum() > 0:
                            _ecod_arr = df["anomaly_score_if"].values
                            _lof_sample_idx = np.argsort(_ecod_arr)[::-1][:lof_max_n]
                        else:
                            # Fallback: degree-priority subsample (better than pure random)
                            _deg_arr_lof = np.array(
                                [float(G.degree(nodes[_ii])) for _ii in range(len(nodes))], dtype=float
                            )
                            _sorted_deg = np.argsort(_deg_arr_lof)[::-1]
                            _top_half = min(lof_max_n // 2, len(nodes))
                            _rng_lof = np.random.default_rng(APP.RANDOM_SEED)
                            _remaining_lof = _sorted_deg[_top_half:]
                            _fill_n = min(lof_max_n - _top_half, len(_remaining_lof))
                            _fill_sel = _rng_lof.choice(len(_remaining_lof), size=_fill_n, replace=False)
                            _lof_sample_idx = np.concatenate(
                                [_sorted_deg[:_top_half], _remaining_lof[_fill_sel]]
                            )
                        X_sub = X[_lof_sample_idx]
                        n_nb_sub = min(20, lof_max_n - 1)
                        lof = LocalOutlierFactor(n_neighbors=n_nb_sub, contamination=contamination)
                        lof.fit(X_sub)
                        _sub_scores = -lof.negative_outlier_factor_
                        # Unsampled nodes inherit median score (conservative)
                        _full_lof = np.full(len(nodes), float(np.median(_sub_scores)))
                        _full_lof[_lof_sample_idx] = _sub_scores
                    else:
                        lof = LocalOutlierFactor(n_neighbors=n_nb, contamination=contamination)
                        lof.fit(X)
                        _full_lof = -lof.negative_outlier_factor_
                    df["anomaly_score_lof"] = (_full_lof - _full_lof.min()) / (
                        _full_lof.max() - _full_lof.min() + 1e-8
                    )
                else:
                    df["anomaly_score_lof"] = 0
            except Exception:
                df["anomaly_score_lof"] = 0
        else:
            df["anomaly_score_lof"] = 0
        try:
            # v15.14 #8: dict(G.degree()) is a single O(n) bulk call vs n separate G.degree(n)
            _deg_dict_an = dict(G.degree())
            degrees = np.array([_deg_dict_an.get(n, 0) for n in nodes], dtype=float)
            z = np.abs(stats.zscore(degrees)) if np.std(degrees) > 0 else np.zeros(len(nodes))
            df["anomaly_score_zscore"] = z / (z.max() + 1e-8)
        except Exception:
            df["anomaly_score_zscore"] = 0
        return df

    # =========================================================================
    # FAMILY 6: DYNAMIC VELOCITY ANALYZER — V14.1 (FIX-05: real timestamps)
    # =========================================================================
    def _temporal(self, G: nx.DiGraph, params: Dict) -> pd.DataFrame:
        nodes = list(G.nodes())
        df = pd.DataFrame({"node_id": nodes})
        txn_counts = np.array([G.nodes[n].get("txn_count", 0) for n in nodes], dtype=float)
        in_flows = np.array([G.nodes[n].get("in_flow", 0) for n in nodes], dtype=float)
        out_flows = np.array([G.nodes[n].get("out_flow", 0) for n in nodes], dtype=float)
        burst_sigma = params.get("velocity_burst_sigma", 3)
        mean_txn = txn_counts.mean() if len(txn_counts) > 0 else 1
        std_txn = txn_counts.std() if len(txn_counts) > 1 else 1
        df["velocity_ratio"] = txn_counts / max(mean_txn, 1)
        burst_threshold = mean_txn + burst_sigma * std_txn
        df["is_burst"] = (txn_counts > burst_threshold).astype(int)
        df["burst_score"] = np.clip((txn_counts - mean_txn) / (burst_sigma * std_txn + 1e-8), 0, 1)
        total_flow = in_flows + out_flows
        mean_flow = total_flow.mean() if len(total_flow) > 0 else 1
        std_flow = total_flow.std() if len(total_flow) > 1 else 1
        df["flow_acceleration"] = np.clip(
            (total_flow - mean_flow) / (std_flow + 1e-8) * df["velocity_ratio"].values, -5, 5
        )
        velocity_z = (
            (txn_counts - mean_txn) / (std_txn + 1e-8) if std_txn > 0 else np.zeros(len(nodes))
        )
        flow_z = (
            (total_flow - mean_flow) / (std_flow + 1e-8) if std_flow > 0 else np.zeros(len(nodes))
        )
        df["velocity_spike"] = np.clip((velocity_z + flow_z) / 2, 0, 1)

        # FIX-05: Use timestamp attributes when available
        # Aggregation layer may populate first_txn_ts / last_txn_ts as Unix epoch or ISO string
        use_ts = params.get("use_timestamps", True)
        recency_scores = np.zeros(len(nodes))
        freq_per_day = np.zeros(len(nodes))
        ts_available = False
        if use_ts:
            import datetime as _dt

            now_epoch = _dt.datetime.now().timestamp()
            # v15.14 #6: nx.get_node_attributes bulk-fetches all timestamp values in one
            # O(n) dict-comprehension pass instead of n separate G.nodes[node] accesses.
            _last_ts_map = nx.get_node_attributes(G, "last_txn_ts")
            _first_ts_map = nx.get_node_attributes(G, "first_txn_ts")

            def _to_epoch(v):
                """Convert ISO-string or numeric timestamp to float epoch."""
                try:
                    if isinstance(v, str):
                        return _dt.datetime.fromisoformat(v).timestamp()
                    return float(v)
                except Exception:
                    return None

            for idx, node in enumerate(nodes):
                lt = _last_ts_map.get(node)
                ft = _first_ts_map.get(node)
                try:
                    if lt is not None:
                        ts_available = True
                        lt_f = _to_epoch(lt)
                        if lt_f is not None:
                            days_ago = (now_epoch - lt_f) / 86400.0
                            recency_scores[idx] = max(0.0, 1.0 - days_ago / 90.0)
                            if ft is not None:
                                ft_f = _to_epoch(ft)
                                if ft_f is not None:
                                    span_days = max((lt_f - ft_f) / 86400.0, 1.0)
                                    freq_per_day[idx] = txn_counts[idx] / span_days
                except Exception:
                    pass
        df["ts_recency_score"] = recency_scores.astype(np.float32)
        if ts_available:
            max_freq = freq_per_day.max() if freq_per_day.max() > 0 else 1.0
            df["ts_freq_per_day_norm"] = np.clip(freq_per_day / max_freq, 0, 1).astype(np.float32)
        else:
            # Fall back to normalized txn_count when no timestamps present
            df["ts_freq_per_day_norm"] = np.clip(
                txn_counts / (txn_counts.max() + 1e-8), 0, 1
            ).astype(np.float32)

        # Combined temporal anomaly: weighted blend of all signals
        # NEW-11 v14.4: Velocity delta zscore — detect behavioral CHANGE, not absolute level.
        # An account always-high is NOT suspicious. Account going quiet→burst IS suspicious.
        # Method: approximate delta as (current_velocity_ratio - mean) / std of velocity_ratio.
        # Since we lack rolling history per node (single-run batch), we use cross-sectional
        # rank deviation: nodes far from their own typical value (estimated by graph mean).
        # velocity_delta = |(vel_ratio - median(vel_ratio))| / (mad(vel_ratio) + eps)
        # clipped to [0,1] and included in temporal_anomaly_score.
        try:
            vr = df["velocity_ratio"].values.astype(float)
            median_vr = float(np.median(vr))
            mad_vr = float(np.median(np.abs(vr - median_vr))) + 1e-8
            vel_delta = np.abs(vr - median_vr) / (
                mad_vr * 1.4826
            )  # 1.4826 = consistency factor for normal
            df["velocity_delta_zscore"] = np.clip(
                vel_delta / (vel_delta.max() + 1e-8), 0, 1
            ).astype(np.float32)
        except Exception:
            df["velocity_delta_zscore"] = np.float32(0)
        df["temporal_anomaly_score"] = np.clip(
            df["burst_score"].values * 0.25
            + np.abs(df["flow_acceleration"].values) / 5 * 0.15
            + df["velocity_spike"].values * 0.15
            + df["ts_recency_score"].values * 0.15
            + df["ts_freq_per_day_norm"].values * 0.15
            + df["velocity_delta_zscore"].values * 0.15,
            0,
            1,
        )

        # v15.22 NEW-GB: Goh-Barabási Burstiness B = (σ_τ − μ_τ) / (σ_τ + μ_τ)
        # ─────────────────────────────────────────────────────────────────────
        # Goh & Barabási (2008) showed that human activity follows bursty patterns
        # (B > 0) while automated/scripted activity is hyper-regular (B < 0 or B ≈ -1).
        # Current cross-sectional is_burst MISSES scripted fraud: a bot sending 500
        # identical daily transactions at 09:00 every day has ZERO burst by z-score
        # (always same level) but B ≈ -0.9 by Goh-Barabási (hyper-regular = bot signal).
        #
        # Formula: B = (σ_IET - μ_IET) / (σ_IET + μ_IET + ε)
        #   IET = inter-event time (time between consecutive transactions per node)
        #   B ∈ [-1, +1]
        #   B ~ -1 = perfectly regular (scripted/bot/automated fraud)
        #   B ~ 0  = Poisson random (normal human banking)
        #   B ~ +1 = highly bursty (occasional spikes, then quiet = staged layering)
        #
        # Implementation paths:
        #   PATH 1 (exact): edge timestamps available → compute per-node IET sequence
        #   PATH 2 (proxy): only txn_count + span → approximate using CV of IET
        #
        # Business language: "Transaction Regularity Score: this account shows hyper-regular
        # automated patterns consistent with scripted transaction generation."
        ts_attr = params.get("burstiness_edge_ts_attr", "timestamp")
        burstiness_b = np.zeros(len(nodes), dtype=np.float32)
        burstiness_method = "none"
        try:
            # PATH 1: Build per-node sorted timestamp list from edges
            node_ts_sequences: dict = {}  # node -> sorted list of timestamps (float epoch)
            for u, v, ed in G.edges(data=True):
                ts_val = ed.get(ts_attr)
                if ts_val is not None:
                    try:
                        if isinstance(ts_val, str):
                            import datetime as _dt2

                            ts_f = _dt2.datetime.fromisoformat(ts_val).timestamp()
                        else:
                            ts_f = float(ts_val)
                        # Record for both endpoints: u sent, v received
                        for _nd in (u, v):
                            if _nd not in node_ts_sequences:
                                node_ts_sequences[_nd] = []
                            node_ts_sequences[_nd].append(ts_f)
                    except Exception:
                        pass

            if len(node_ts_sequences) >= 3:
                # PATH 1 exact: compute actual IET sequences
                node_idx_map = {nd: i for i, nd in enumerate(nodes)}
                for nd, ts_list in node_ts_sequences.items():
                    if nd not in node_idx_map:
                        continue
                    i = node_idx_map[nd]
                    ts_sorted = sorted(ts_list)
                    if len(ts_sorted) < 3:
                        # Cannot compute IET std with < 2 intervals
                        # B = 0 (neutral — insufficient data)
                        burstiness_b[i] = 0.0
                        continue
                    iets = np.diff(ts_sorted)  # inter-event times in seconds
                    iets = iets[iets > 0]  # remove same-second events
                    if len(iets) < 2:
                        burstiness_b[i] = 0.0
                        continue
                    mu_iet = float(iets.mean())
                    sigma_iet = float(iets.std())
                    denom = sigma_iet + mu_iet + 1e-8
                    burstiness_b[i] = float(np.clip((sigma_iet - mu_iet) / denom, -1.0, 1.0))
                burstiness_method = "exact_iet"
            else:
                raise ValueError("insufficient_edge_timestamps")
        except Exception:
            # PATH 2: Proxy using txn_count + first/last timestamps (when available)
            # Proxy formula: approximate B using inter-arrival CV estimate.
            # For a node with txn_count=n over span T days:
            #   mean_IET ≈ T / (n-1)
            # If recency (last activity close to now) AND high freq_per_day relative to span:
            #   the account shows burst-then-quiet which approximates B > 0
            # If very high freq_per_day AND very uniform (velocity_delta ≈ 0):
            #   approximates B < 0 (regular scripted)
            try:
                vr = df["velocity_ratio"].values.astype(float)
                vd = df["velocity_delta_zscore"].values.astype(float)
                # B_proxy ≈ (velocity_relative - 1) / (velocity_relative + 1 + ε)
                # High vr (much busier than average) + low vd (uniform, not changing) = scripted = B < 0
                # High vr + high vd (activity changes) = bursty = B > 0
                b_proxy = np.clip((vr - 1.0) / (vr + 1.0 + 1e-8), -1.0, 1.0)
                # Modulate: if velocity_delta_zscore is low, push toward negative (regular)
                regularity_factor = 1.0 - np.clip(vd, 0, 1)  # 1=very regular, 0=irregular
                # For regular high-velocity accounts: b = b_proxy * (1 - 2*regularity) → goes negative
                b_adjusted = b_proxy * (1.0 - regularity_factor * 0.7)
                burstiness_b = np.clip(b_adjusted, -1.0, 1.0).astype(np.float32)
                burstiness_method = "proxy"
            except Exception:
                burstiness_b = np.zeros(len(nodes), dtype=np.float32)
                burstiness_method = "unavailable"

        df["burstiness_b"] = burstiness_b
        # Flag scripted fraud: B <-0.3 (hyper-regular, automated pattern)
        df["is_scripted_regular"] = (burstiness_b < -0.3).astype(int)
        # Flag bursty layering: B > 0.3 (burst-then-quiet staged pattern)
        df["is_bursty_layering"] = (burstiness_b > 0.3).astype(int)

        # v15.22 NEW-TM: Temporal Motif A→B→C within time window
        # ─────────────────────────────────────────────────────────
        # Paranjape et al. (2017) "Motifs in Temporal Networks":
        # A static C→B→A motif could span years. A TEMPORAL motif requires
        # the edges to occur in TIME ORDER within a bounded window.
        #   A→B at time t1 AND B→C at time t2 WHERE t1 < t2 < t1 + window
        # This is the exact computational signature of a LAYERING CHAIN:
        # money arrives at B from A, then is forwarded to C within 24 hours.
        # Static motif detection misses this entirely if timestamps are ignored.
        #
        # Business language: "This account was a relay node in 12 timed money chains
        # — funds arrived and were forwarded within 24 hours on 12 separate occasions."
        #
        # Requires: edge timestamps. Fallback: 0 (not penalised).
        tm_window_hours = params.get("temporal_motif_window_hours", 24)
        tm_node_limit = params.get("temporal_motif_node_limit", 500)
        tm_window_sec = tm_window_hours * 3600.0
        temporal_relay_count = np.zeros(len(nodes), dtype=int)
        temporal_relay_ratio = np.zeros(len(nodes), dtype=np.float32)
        try:
            # Rebuild edge timestamp index (may already be built above — reuse if possible)
            # Format: {node: [(ts, direction, counterparty), ...]}
            #   direction: 'in' = received, 'out' = sent
            _node_edge_ts: dict = {}
            _ts_attr = params.get("burstiness_edge_ts_attr", "timestamp")
            _has_any_ts = False
            for u, v, ed in G.edges(data=True):
                ts_val = ed.get(_ts_attr)
                if ts_val is None:
                    continue
                try:
                    if isinstance(ts_val, str):
                        import datetime as _dttm

                        ts_f = _dttm.datetime.fromisoformat(ts_val).timestamp()
                    else:
                        ts_f = float(ts_val)
                    _has_any_ts = True
                    # u sent → record as (ts, 'in') for v and (ts, 'out') for u
                    if u not in _node_edge_ts:
                        _node_edge_ts[u] = []
                    _node_edge_ts[u].append((ts_f, "out", v))
                    if v not in _node_edge_ts:
                        _node_edge_ts[v] = []
                    _node_edge_ts[v].append((ts_f, "in", u))
                except Exception:
                    continue

            if _has_any_ts and len(_node_edge_ts) > 0:
                node_idx_map2 = {nd: i for i, nd in enumerate(nodes)}
                scan_limit = min(tm_node_limit, len(nodes))
                for nd in nodes[:scan_limit]:
                    i = node_idx_map2.get(nd)
                    if i is None:
                        continue
                    nd_events = _node_edge_ts.get(nd, [])
                    if len(nd_events) < 2:
                        continue
                    # Temporal motif: node nd acts as relay B in A→B→C
                    # Need: an in-event at t1 AND an out-event at t2 where t1 < t2 < t1+window
                    in_events = sorted(
                        [(ts, cp) for ts, d, cp in nd_events if d == "in"], key=lambda x: x[0]
                    )
                    out_events = sorted(
                        [(ts, cp) for ts, d, cp in nd_events if d == "out"], key=lambda x: x[0]
                    )
                    if not in_events or not out_events:
                        continue
                    relay_count = 0
                    out_idx = 0
                    for t1, src in in_events:
                        # Advance out_idx to first out-event after t1
                        while out_idx < len(out_events) and out_events[out_idx][0] <= t1:
                            out_idx += 1
                        # Count out-events within window [t1, t1+window]
                        j = out_idx
                        while j < len(out_events) and out_events[j][0] <= t1 + tm_window_sec:
                            # Exclude self-loops (A→B→A is bilateral, already detected)
                            if out_events[j][1] != src:
                                relay_count += 1
                            j += 1
                    temporal_relay_count[i] = relay_count
                    n_in = max(len(in_events), 1)
                    temporal_relay_ratio[i] = float(np.clip(relay_count / n_in, 0, 1))
        except Exception:
            pass

        df["temporal_relay_count"] = temporal_relay_count
        df["temporal_relay_ratio"] = temporal_relay_ratio
        # Flag: any account that acted as timed relay ≥ 2 times is a layering candidate
        df["is_temporal_relay"] = (temporal_relay_count >= 2).astype(int)

        # Incorporate new signals into temporal_anomaly_score
        # burstiness: scripted (B<-0.3) OR bursty layering (B>0.3) both raise risk
        _bursty_component = np.abs(burstiness_b.astype(float)) * 0.15
        _relay_component = temporal_relay_ratio.astype(float) * 0.10
        df["temporal_anomaly_score"] = np.clip(
            df["temporal_anomaly_score"].values + _bursty_component + _relay_component, 0, 1
        ).astype(np.float32)

        return df

    # =========================================================================
    # FAMILY 7: MULTI-LAYER MODULE
    # =========================================================================
    def _multi_layer(self, G: nx.DiGraph, params: Dict) -> pd.DataFrame:
        nodes = list(G.nodes())
        df = pd.DataFrame({"node_id": nodes})
        node_idx = {n: i for i, n in enumerate(nodes)}
        n = len(nodes)
        txn_deg = np.zeros(n)
        rel_deg = np.zeros(n)
        for u, v, d in G.edges(data=True):
            is_txn = d.get("edge_type", "") == "transaction"
            ui, vi = node_idx.get(u), node_idx.get(v)
            if ui is not None and vi is not None:
                if is_txn:
                    txn_deg[ui] += 1
                    txn_deg[vi] += 1
                else:
                    rel_deg[ui] += 1
                    rel_deg[vi] += 1
        df["txn_layer_degree"] = txn_deg.astype(int)
        df["rel_layer_degree"] = rel_deg.astype(int)
        max_txn = txn_deg.max() or 1
        max_rel = rel_deg.max() or 1
        df["cross_layer_score"] = (txn_deg / max_txn) * 0.5 + (rel_deg / max_rel) * 0.5
        return df

    # =========================================================================
    # FAMILY 8: STRUCTURING SPLIT DETECTOR (NEW v10 — B1)
    # =========================================================================
    def _structuring(self, G: nx.DiGraph, params: Dict) -> pd.DataFrame:
        """B1: Detect transactions split below reporting threshold.
        v16.20 F12: Currency-aware jurisdiction thresholds.
        Reads 'currency' from edge attributes when available; falls back to USD $10K.
        Works with node+edge-only input (no external tables required).
        """
        nodes = list(G.nodes())
        df = pd.DataFrame({"node_id": nodes})

        # v16.20 F12: Jurisdiction-aware CTR threshold map.
        # Configurable via params['jurisdiction_thresholds'] dict (currency → threshold).
        # Covers major AML jurisdictions; falls back to USD 10000 for unknown currencies.
        _default_threshold = params.get("threshold", 10000)
        _jurisdiction_thresholds = params.get(
            "jurisdiction_thresholds",
            {
                "USD": 10000, "CAD": 10000, "AUD": 10000,
                "EUR": 10000, "GBP": 10000,
                "SGD": 20000,  # MAS STR threshold
                "AED": 40000,  # UAE FIU (approx)
                "JPY": 2000000,  # Japan FSA
                "CHF": 15000,  # FINMA
                "HKD": 120000,  # HK JFIU (approx HKD equiv)
            },
        )

        # Detect if edges carry a currency attribute (optional — not required)
        _has_currency = any(
            "currency" in d
            for _, _, d in list(G.edges(data=True))[:50]  # sample first 50 edges
        )

        # Use a single threshold when no currency info available (USD default)
        threshold = _default_threshold
        window_factor = params.get("window_factor", 0.8)
        lower_bound = threshold * window_factor

        # v15.14 #3: Single combined loop replaces 2 separate O(n×E) edge traversal loops.
        # Original: Loop-1 (out_edges → sub_counts) + Loop-2 (out+in edges → round/CTR).
        # Now: one pass fetches out_edges + in_edges ONCE per node, computes everything.
        round_denoms = params.get("round_number_denominators", [1000, 500, 100])
        ctr_threshold = params.get("ctr_threshold", 10000)
        ctr_bracket_lower = params.get("ctr_bracket_lower", ctr_threshold * 0.90)
        sub_counts, sub_ratios, sub_totals, near_counts = [], [], [], []
        round_ratios, ctr_counts_list, ctr_ratio_list = [], [], []
        for node in nodes:
            out_edges = list(G.out_edges(node, data=True))
            in_edges = list(G.in_edges(node, data=True))
            total_out = len(out_edges)

            # v16.20 F12: Per-edge currency aware threshold when currency is present
            def _edge_threshold(edge_data):
                """Return the jurisdictional CTR threshold for this edge."""
                if _has_currency:
                    cur = str(edge_data.get("currency", "USD")).upper().strip()[:3]
                    return _jurisdiction_thresholds.get(cur, _default_threshold)
                return threshold

            # ── Sub-threshold structuring (out_edges only) ──
            sub_threshold = [
                d.get("weight", d.get("amount", 0))
                for _, _, d in out_edges
                if 0 < d.get("weight", d.get("amount", 0)) < _edge_threshold(d)
            ]
            near_threshold = [
                a for _, _, d in out_edges
                for a in [d.get("weight", d.get("amount", 0))]
                if a >= _edge_threshold(d) * window_factor and a < _edge_threshold(d)
            ]
            sub_counts.append(len(sub_threshold))
            sub_ratios.append(len(sub_threshold) / max(total_out, 1))
            sub_totals.append(sum(sub_threshold))
            near_counts.append(len(near_threshold))
            # ── Round-number + CTR avoidance (all edges) ──
            all_edges = out_edges + in_edges
            amounts = [
                abs(d.get("weight", d.get("amount", 0)))
                for _, _, d in all_edges
                if abs(d.get("weight", d.get("amount", 0))) > 0
            ]
            if amounts:
                n_amt = len(amounts)
                round_count = sum(
                    1
                    for a in amounts
                    if any(int(round(a)) % denom == 0 for denom in round_denoms if denom > 0)
                )
                bracket_n = sum(1 for a in amounts if ctr_bracket_lower <= a < ctr_threshold)
                round_ratios.append(round_count / n_amt)
                ctr_counts_list.append(bracket_n)
                ctr_ratio_list.append(bracket_n / n_amt)
            else:
                round_ratios.append(0.0)
                ctr_counts_list.append(0)
                ctr_ratio_list.append(0.0)

        df["sub_threshold_count"] = sub_counts
        df["sub_threshold_ratio"] = sub_ratios
        df["sub_threshold_total"] = sub_totals
        df["near_threshold_count"] = near_counts

        sc = np.array(sub_counts, dtype=float)
        sr = np.array(sub_ratios, dtype=float)
        nc = np.array(near_counts, dtype=float)
        sc_norm = sc / (sc.max() + 1e-8) if sc.max() > 0 else sc
        nc_norm = nc / (nc.max() + 1e-8) if nc.max() > 0 else nc
        df["structuring_score"] = np.clip(sc_norm * 0.3 + sr * 0.3 + nc_norm * 0.4, 0, 1)
        df["potential_structuring"] = (
            (df["structuring_score"] > 0.5) & (df["near_threshold_count"] >= 2)
        ).astype(int)

        # FIX-06: Flow conservation = layering intermediary detection
        fc_tol = params.get("flow_conservation_tolerance", 0.10)
        fc_in_flows = np.array(
            [float(G.nodes[node].get("in_flow", 0) or 0) for node in nodes], dtype=float
        )
        fc_out_flows = np.array(
            [float(G.nodes[node].get("out_flow", 0) or 0) for node in nodes], dtype=float
        )
        fc_total = np.maximum(fc_in_flows, fc_out_flows)
        # v15.14 #8: dict(G.degree()) bulk call — one O(n) pass instead of n G.degree() calls
        _deg_dict_st = dict(G.degree())
        fc_degrees = np.array([_deg_dict_st.get(nd, 0) for nd in nodes], dtype=float)
        fc_diff_ratio = np.where(
            fc_total > 0, np.abs(fc_in_flows - fc_out_flows) / (fc_total + 1e-8), 1.0
        )
        df["flow_conservation_ratio"] = np.clip(1.0 - fc_diff_ratio, 0, 1).astype(np.float32)
        df["is_layering_intermediary"] = (
            (fc_diff_ratio < fc_tol) & (fc_degrees >= 3) & (fc_total > 0)
        ).astype(int)

        # v15.13 B1+B2 merged loop results already computed above
        df["round_number_ratio"] = np.array(round_ratios, dtype=np.float32)
        ctr_cnt_arr = np.array(ctr_counts_list, dtype=float)
        df["ctr_bracket_count"] = ctr_cnt_arr.astype(int)
        df["ctr_bracket_ratio"] = np.array(ctr_ratio_list, dtype=np.float32)
        df["potential_ctr_avoidance"] = (
            (ctr_cnt_arr >= 2) & (np.array(ctr_ratio_list) >= 0.10)
        ).astype(int)
        return df

    # =========================================================================
    # FAMILY 9: BENFORD'S LAW ANALYZER (NEW v10 — B2)
    # =========================================================================
    def _benfords(self, G: nx.DiGraph, params: Dict) -> pd.DataFrame:
        """B2: Benford's Law first-digit + second-digit distribution test per node.

        v15.9 SPEED FIX: Merged two separate O(E) edge-traversal loops into ONE.
        Previously each node's edges were iterated twice (first-digit loop + second-
        digit loop), doubling CPU time on large graphs.  Now a single pass extracts
        both digit positions simultaneously — ~50 % reduction in edge traversals.
        """
        nodes = list(G.nodes())
        df = pd.DataFrame({"node_id": nodes})
        min_samp = params.get("min_samples", 20)
        # v16.19 BUG-4: chi-square requires expected count ≥ 5 per cell (textbook rule).
        # With 9 Benford digit bins, this means n ≥ 9 * 5 / min_proportion ≈ 100.
        # Below chi2_min_samples we skip chi-sq and report p=1.0 (non-significant by default).
        # MAD (Mean Absolute Deviation) is still computed and valid at any n — it is
        # the primary AML signal (Nigrini 1999 threshold: MAD >= 0.015 = non-conforming).
        chi2_min_samp = params.get("chi2_min_samples", 100)

        # First-digit Benford expected proportions (precomputed once)
        benford_expected = {d: math.log10(1 + 1 / d) for d in range(1, 10)}
        exp_prop_1 = np.array([benford_expected[d] for d in range(1, 10)])

        # Second-digit Benford expected proportions (precomputed once — was inside loop)
        # P(second digit = k) = Σ_{n=1}^{9} log10(1 + 1/(10n+k)),  k ∈ {0..9}
        benford2_expected = {
            d: sum(math.log10(1 + 1 / (10 * k + d)) for k in range(1, 10)) for d in range(0, 10)
        }
        exp_prop_2 = np.array([benford2_expected[d] for d in range(0, 10)])

        chi2_scores, p_values, mad_scores, second_mad_scores = [], [], [], []

        for node in nodes:
            # ── Single edge pass — collect amounts once for both digit tests ──
            all_edges = list(G.out_edges(node, data=True)) + list(G.in_edges(node, data=True))
            amounts = [
                abs(d.get("weight", d.get("amount", 0)))
                for _, _, d in all_edges
                if abs(d.get("weight", d.get("amount", 0))) > 0
            ]

            # v15.5 FIX (FIX-04): min_samples lowered to 20 — MAD valid at any n
            if len(amounts) < min_samp:
                chi2_scores.append(0)
                p_values.append(1.0)
                mad_scores.append(0)
                second_mad_scores.append(0.0)
                continue

            # v15.14 #5: numpy log10 digit extraction replaces string-manipulation inner loop.
            # First digit: floor(x / 10^floor(log10(x)))  ← pure float arithmetic, no str()
            # Second digit: floor(x / 10^(floor_log-1)) % 10
            # Falls back to string method on any numerical edge-case (e.g. 0, subnormals).
            first_digits, second_digits = [], []
            try:
                _amts_np = np.array(amounts, dtype=np.float64)
                _pos = _amts_np[_amts_np > 0]
                if len(_pos) > 0:
                    _log10 = np.log10(_pos)
                    _floor_log = np.floor(_log10).astype(int)
                    _fd = np.floor(_pos / np.power(10.0, _floor_log.astype(float))).astype(int)
                    _mask1 = (_fd >= 1) & (_fd <= 9)
                    first_digits = _fd[_mask1].tolist()
                    # Second digit aligned to same valid set as first_digits
                    _sd_raw = (
                        np.floor(
                            _pos[_mask1] / np.power(10.0, (_floor_log[_mask1] - 1).astype(float))
                        ).astype(int)
                        % 10
                    )
                    second_digits = _sd_raw.tolist()
            except Exception:
                for amt in amounts:
                    try:
                        s = str(abs(float(amt))).replace(".", "").lstrip("0")
                        if s:
                            fd = int(s[0])
                            if 1 <= fd <= 9:
                                first_digits.append(fd)
                                if len(s) >= 2:
                                    second_digits.append(int(s[1]))
                    except Exception:
                        pass

            # ── First-digit Benford stats ──
            if len(first_digits) < min_samp:
                chi2_scores.append(0)
                p_values.append(1.0)
                mad_scores.append(0)
            else:
                digit_counts = Counter(first_digits)
                total = len(first_digits)
                observed = np.array([digit_counts.get(d, 0) for d in range(1, 10)], dtype=float)
                expected = np.array(
                    [benford_expected[d] * total for d in range(1, 10)], dtype=float
                )
                # v16.19 BUG-4: Only run chi-sq when sample is statistically sufficient.
                # chi2_min_samp default=100 ensures expected count per cell ≥ ~11 (valid).
                # For n < 100 we record chi2=0, p=1.0 and rely solely on MAD.
                if total >= chi2_min_samp:
                    try:
                        chi2_val, p_val = stats.chisquare(observed, f_exp=np.maximum(expected, 0.5))
                        chi2_scores.append(float(chi2_val))
                        p_values.append(float(p_val))
                    except Exception:
                        chi2_scores.append(0)
                        p_values.append(1.0)
                else:
                    # Insufficient data for chi-sq — silently skip, MAD still computed below
                    chi2_scores.append(0)
                    p_values.append(1.0)
                obs_prop = observed / total
                mad_scores.append(float(np.mean(np.abs(obs_prop - exp_prop_1))))

            # ── Second-digit Benford MAD (structuring / threshold-clustering signal) ──
            if len(second_digits) < min_samp:
                second_mad_scores.append(0.0)
            else:
                cnt2 = Counter(second_digits)
                tot2 = len(second_digits)
                obs2 = np.array([cnt2.get(d, 0) / tot2 for d in range(0, 10)], dtype=float)
                second_mad_scores.append(float(np.mean(np.abs(obs2 - exp_prop_2))))

        df["benfords_chi2"] = chi2_scores
        df["benfords_pvalue"] = p_values
        df["benfords_mad"] = mad_scores
        df["benfords_second_mad"] = second_mad_scores

        _mad2_thresh = params.get("benford_second_mad_threshold", 0.012)
        df["benfords_second_anomaly"] = (np.array(second_mad_scores) > _mad2_thresh).astype(int)

        # v15.5 FIX (FIX-04): benfords_anomaly uses MAD threshold, not chi-sq p-value.
        # MAD >= 0.015 = non-conforming; 0.006–0.015 = marginal; < 0.006 = conforming (Nigrini 1999).
        mad_anomaly_threshold = params.get("mad_anomaly_threshold", 0.015)
        mad_arr = np.array(mad_scores)
        df["benfords_anomaly"] = (mad_arr >= mad_anomaly_threshold).astype(int)
        max_mad = mad_arr.max() if mad_arr.max() > 0 else 1
        df["benfords_conformity"] = np.clip(1 - (mad_arr / max_mad), 0, 1)
        return df

    # =========================================================================
    # FAMILY 10: NETWORK MOTIF SCANNER (NEW v10 — B3)
    # =========================================================================
    def _motifs(self, G: nx.DiGraph, params: Dict) -> pd.DataFrame:
        """B3: Detect AML-relevant network motifs."""
        nodes = list(G.nodes())
        df = pd.DataFrame({"node_id": nodes})
        fan_out_threshold = params.get("fan_out_threshold", 3)
        fan_in_threshold = params.get("fan_in_threshold", 3)
        pass_through_tolerance = params.get("pass_through_tolerance", 0.2)

        fan_out_scores, fan_in_scores, pass_through_scores, back_to_back_scores = [], [], [], []
        for node in nodes:
            out_deg = G.out_degree(node)
            in_deg = G.in_degree(node)
            fan_out_scores.append(max(0, out_deg - fan_out_threshold))
            fan_in_scores.append(max(0, in_deg - fan_in_threshold))
            in_flow = G.nodes[node].get("in_flow", 0)
            out_flow = G.nodes[node].get("out_flow", 0)
            if in_flow > 0 and out_flow > 0:
                ratio = min(in_flow, out_flow) / max(in_flow, out_flow)
                pt = max(0, ratio - (1 - pass_through_tolerance))
                # v16.20 F13: Incorporate transaction count into pass-through score.
                # A node doing 1000 × $10 pass-throughs and 1 × $10K pass-through both have
                # ratio≈1.0 but the high-velocity one is the smurfing signal.
                # in_txn_count populated by F06 in l3_graph._add_basic_graph_features.
                _in_tc = float(G.nodes[node].get("in_txn_count", 0) or 0)
                _out_tc = float(G.nodes[node].get("out_txn_count", 0) or 0)
                _txn_vel = (_in_tc + _out_tc)  # raw velocity; normalised globally below
                pass_through_scores.append(
                    (pt / pass_through_tolerance if pass_through_tolerance > 0 else 0,
                     _txn_vel)
                )
            else:
                pass_through_scores.append((0, 0))
            successors = set(G.successors(node))
            predecessors = set(G.predecessors(node))
            back_to_back_scores.append(len(successors & predecessors))

        df["motif_fan_out"] = fan_out_scores
        df["motif_fan_in"] = fan_in_scores
        # v16.20 F13: Unpack (ratio_score, txn_velocity) tuples and blend
        _pt_ratios = np.array([v[0] for v in pass_through_scores], dtype=float)
        _pt_vels = np.array([v[1] for v in pass_through_scores], dtype=float)
        _vel_max = _pt_vels.max() if _pt_vels.max() > 0 else 1.0
        _vel_norm = _pt_vels / _vel_max
        # Final pass-through score: 60% amount-ratio signal + 40% transaction-velocity
        _pt_combined = np.clip(_pt_ratios * 0.6 + _vel_norm * 0.4, 0, 1)
        df["motif_pass_through"] = _pt_combined.astype(np.float32)
        df["motif_pass_through_velocity"] = _vel_norm.astype(np.float32)  # investigator drill-down
        df["motif_back_to_back"] = back_to_back_scores

        # Circular motif
        # v15.13 A3: Replace O(5000 BFS) nx.has_path with pre-computed SCC in_ring attr.
        # in_ring=1 ⇔ node inside a strongly-connected component (cycle exists by definition).
        # l3_graph always computes SCCs (Tarjan) from edge table.
        # Fallback to tight-budget BFS when in_ring is absent (node+edge-only graphs).
        circular_scores = np.zeros(len(nodes))
        try:
            _in_ring_probe = [
                G.nodes[nd].get("in_ring", None) for nd in nodes[: min(10, len(nodes))]
            ]
            _has_scc_attr = any(v is not None for v in _in_ring_probe)
            if _has_scc_attr:
                # O(n) SCC lookup — l3_graph already paid the Tarjan O(n+e) cost
                for idx, nd in enumerate(nodes):
                    if G.nodes[nd].get("in_ring", 0):
                        circular_scores[idx] = 1
            else:
                # Fallback BFS with tight budget (node+edge table only, no SCC pre-computed)
                circ_limit = min(params.get("circular_node_limit", 200), len(nodes))
                succ_limit = params.get("circular_succ_limit", 5)
                for idx, nd in enumerate(nodes[:circ_limit]):
                    try:
                        for succ in list(G.successors(nd))[:succ_limit]:
                            if nx.has_path(G, succ, nd):
                                circular_scores[idx] = 1
                                break
                    except Exception:
                        continue
        except Exception:
            pass
        df["motif_circular"] = circular_scores.astype(int)

        # v16.2 B2: Circular motif Z-score vs configuration model null (reduces false positives).
        # Problem: raw motif_circular=1 fires on ALL nodes in any SCC, including high-degree hubs
        # that appear in SCCs simply due to topology (invoice factoring, intercompany flows).
        # Fix: compute Z-score of circular membership vs expected under degree-sequence null model.
        #   Expected: E[circular(i)] = in_degree(i) * out_degree(i) / (n-1)
        #   Z-score: (observed - expected) / sqrt(expected + eps)
        # High Z = circular membership STATISTICALLY UNEXPECTED given degree (genuine ring).
        # Low Z  = circular membership explained by high degree alone (suppress the flag).
        # motif_circular_zscore is normalised to [0,1] for consistent fusion with other scores.
        try:
            _n_nodes = len(nodes)
            if _n_nodes >= 4:
                _in_d = np.array([G.in_degree(nd) for nd in nodes], dtype=float)
                _out_d = np.array([G.out_degree(nd) for nd in nodes], dtype=float)
                _expected_circ = (_in_d * _out_d) / max(float(_n_nodes - 1), 1.0)
                _z = (circular_scores - _expected_circ) / np.sqrt(np.maximum(_expected_circ, 1e-6))
                _z_pos = np.clip(_z, 0.0, None)  # only positive Z (more loops than expected)
                _z_max = _z_pos.max()
                df["motif_circular_zscore"] = (_z_pos / max(_z_max, 1e-8)).astype(np.float32)
            else:
                df["motif_circular_zscore"] = circular_scores.astype(np.float32)
        except Exception:
            df["motif_circular_zscore"] = circular_scores.astype(np.float32)

        # NEW-10 v14.4: A→B→A bilateral motif with amount-ratio check (TBML round-trip detection)
        # Trade-Based Money Laundering pattern: funds sent from A to B, then returned A←B.
        # Standard back-to-back only checks node co-membership; this checks BOTH:
        #   1. Directed reciprocal edge pair exists: G has edge A→B and B→A
        #   2. Amount similarity: |amount_AB - amount_BA| / max(amount_AB, amount_BA) < tolerance
        # High bilateral_ratio = strong TBML signal independent of node centrality.
        bilateral_counts = np.zeros(len(nodes), dtype=int)
        bilateral_ratio_arr = np.zeros(len(nodes), dtype=float)
        bilateral_limit = params.get("bilateral_node_limit", 1000)
        amt_tol = params.get("bilateral_amount_tolerance", 0.15)
        node_idx_map = {nd: idx for idx, nd in enumerate(nodes)}
        try:
            edge_amounts = {}  # (u, v) -> amount
            for u, v, ed in G.edges(data=True):
                edge_amounts[(u, v)] = abs(ed.get("weight", ed.get("amount", 0)) or 0)
            scan_nodes = nodes[: min(bilateral_limit, len(nodes))]
            for idx, node in enumerate(scan_nodes):
                out_eds = list(G.out_edges(node))
                bc = 0
                total_out = max(len(out_eds), 1)
                for src, tgt in out_eds:
                    if G.has_edge(tgt, src):  # reciprocal edge exists
                        amt_fwd = edge_amounts.get((src, tgt), 0)
                        amt_rev = edge_amounts.get((tgt, src), 0)
                        max_amt = max(amt_fwd, amt_rev, 1e-8)
                        if abs(amt_fwd - amt_rev) / max_amt < amt_tol:
                            bc += 1  # close-amount round-trip
                bilateral_counts[idx] = bc
                bilateral_ratio_arr[idx] = bc / total_out
        except Exception:
            pass
        df["bilateral_count"] = bilateral_counts
        df["bilateral_ratio"] = bilateral_ratio_arr.astype(np.float32)

        # Combined motif risk — redistributed weights to include bilateral (sum = 1.0)
        fo = np.array(fan_out_scores, dtype=float)
        fi = np.array(fan_in_scores, dtype=float)
        pt = np.array(pass_through_scores, dtype=float)
        bb = np.array(back_to_back_scores, dtype=float)
        bl = bilateral_ratio_arr
        fo_n = fo / (fo.max() + 1e-8) if fo.max() > 0 else fo
        fi_n = fi / (fi.max() + 1e-8) if fi.max() > 0 else fi
        bb_n = bb / (bb.max() + 1e-8) if bb.max() > 0 else bb
        # weights: fan_out 0.15, fan_in 0.15, pass_through 0.20, back_to_back 0.10, circular 0.15, bilateral 0.25
        df["motif_risk_score"] = np.clip(
            fo_n * 0.15
            + fi_n * 0.15
            + pt * 0.20
            + bb_n * 0.10
            + df["motif_circular_zscore"].values * 0.15
            + bl * 0.25,
            0,
            1,
        )
        return df

    # =========================================================================
    # COMBINE + ACCESSORS
    # =========================================================================
    def _combine_results(self, G: nx.DiGraph) -> pd.DataFrame:
        # v15.13 E1: Single merge chain using functools.reduce.
        # Replaces per-column set_index+reindex (~100 pandas index ops) with one left-join per family.
        from functools import reduce

        nodes = list(G.nodes())
        base = pd.DataFrame({"node_id": nodes})
        dfs_to_merge = []
        for family_name, df in self.results.items():
            if df is None or "node_id" not in df.columns or len(df) == 0:
                continue
            try:
                rename_map = {c: f"{family_name}_{c}" for c in df.columns if c != "node_id"}
                dfs_to_merge.append(df.rename(columns=rename_map))
            except Exception:
                continue
        if dfs_to_merge:
            try:
                return reduce(
                    lambda l, r: l.merge(r, on="node_id", how="left"), [base] + dfs_to_merge
                )
            except Exception:
                pass
        return base

    def get_family_results(self, family: str) -> Optional[pd.DataFrame]:
        return self.results.get(family)

    def get_summary(self) -> Dict:
        engines = []
        if HAS_IGRAPH:
            engines.append("igraph")
        if HAS_DATASKETCH:
            engines.append("MinHash-LSH")
        if HAS_PYOD:
            engines.append("PyOD-ECOD")
        return {
            "engine": "+".join(engines) if engines else "NetworkX",
            "families_completed": len(self.results),
            "total_metrics": sum(len(df.columns) - 1 for df in self.results.values()),
            "per_family": {
                FAMILY_DISPLAY_NAMES.get(name, name): {
                    "metrics": len(df.columns) - 1,
                    "nodes": len(df),
                }
                for name, df in self.results.items()
            },
        }
