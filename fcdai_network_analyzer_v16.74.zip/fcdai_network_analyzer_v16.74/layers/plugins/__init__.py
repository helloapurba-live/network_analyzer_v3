# FCDAI v2.1 - Plugins Directory
# Drop .py files here with PLUGIN_NAME (str) and run(engine) -> dict
# They will be auto-discovered by utils/plugin_loader.py
