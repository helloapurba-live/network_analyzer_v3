"""
Layer 3: Graph Construction — V10 SCALABLE ENGINE
===================================================
v10: Handles 0-10,000+ nodes without lag.
  - Level-of-Detail (LOD) rendering: 1K / 5K / 10K node tiers
  - Edge weight visualization (transaction amount as thickness/color)
  - Community-based aggregation for extreme scales
  - Performance-optimised element generation (vectorized, set-based)
  - Smart node selection: by degree, risk, or composite score
"""

import pandas as pd
import numpy as np
import networkx as nx
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
import sys
import json
import time

# v15.12: scipy.sparse for vectorized flow computation (same math, ~10x faster than Python loop)
try:
    from scipy.sparse import csr_matrix as _csr_matrix

    _HAS_SCIPY_SPARSE = True
except ImportError:
    _HAS_SCIPY_SPARSE = False

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import PIPELINE
from utils.logger import log_audit, log_error
from utils.persistence import store_or_load


# ── Scale-tier constants ─────────────────────────────────────────────────────
SCALE_TIERS = {
    "small": {"max_nodes": 1_000, "layout": "cose", "animate": True, "label": "Small (≤1K)"},
    "medium": {
        "max_nodes": 5_000,
        "layout": "cose-bilkent",
        "animate": False,
        "label": "Medium (≤5K)",
    },
    "large": {
        "max_nodes": 10_000,
        "layout": "cose-bilkent",
        "animate": False,
        "label": "Large (≤10K)",
    },
}


class GraphConstructionLayer:
    """v10: Scalable graph construction — handles 0-10K+ nodes smoothly."""

    def __init__(self):
        self.graph: Optional[nx.DiGraph] = None
        self.node_count: int = 0
        self.edge_count: int = 0
        self._weight_range: Tuple[float, float] = (0.0, 1.0)  # cached weight min/max
        # v15.6: SCC summary — Circular Ring Detection output
        # Business: tells the dashboard how many circular money rings were found
        self.scc_summary: Dict = {"ring_count": 0, "nodes_in_rings": 0, "largest_ring": 0}

    def build(self, customer_features: pd.DataFrame, edges: pd.DataFrame) -> nx.DiGraph:
        log_audit("GRAPH_BUILD_START", f"Nodes: {len(customer_features)}, Edges: {len(edges)}")

        G = nx.DiGraph()

        # v9: Handle empty customer features
        if customer_features is None or customer_features.empty:
            self.graph = G
            self.node_count = 0
            self.edge_count = 0
            log_audit("GRAPH_BUILD_COMPLETE", "Empty graph (no customers)")
            return G

        cid = PIPELINE.CUSTOMER_ID_COL
        if cid not in customer_features.columns:
            self.graph = G
            log_audit("GRAPH_BUILD_COMPLETE", f"No {cid} column found")
            return G

        # v15.12: Vectorized node add — avoids per-row Python overhead of iterrows().
        # to_dict('records') is a single C-level DataFrame scan, ~5-10x faster than iterrows.
        # Air-gap: pure local pandas/numpy, zero external calls.
        try:
            cf = customer_features.copy()
            cf[cid] = cf[cid].astype(str)
            _other_cols = [c for c in cf.columns if c != cid]
            _node_ids = cf[cid].tolist()

            def _norm_val(v):
                """Convert numpy scalars → Python types for networkx compatibility."""
                if isinstance(v, np.integer):
                    return int(v)
                if isinstance(v, np.floating):
                    return None if np.isnan(v) else float(v)
                if isinstance(v, float) and np.isnan(v):
                    return None
                return v

            _records = [
                {k: _norm_val(v) for k, v in r.items()} for r in cf[_other_cols].to_dict("records")
            ]
            G.add_nodes_from(zip(_node_ids, _records))
        except Exception:
            # Fallback: original row-by-row path (handles edge cases)
            for _, row in customer_features.iterrows():
                try:
                    node_id = str(row[cid])
                    attrs = {}
                    for col in customer_features.columns:
                        if col != cid:
                            val = row[col]
                            if isinstance(val, (np.integer,)):
                                val = int(val)
                            elif isinstance(val, (np.floating,)):
                                val = float(val)
                            elif pd.isna(val):
                                val = None
                            attrs[col] = val
                    G.add_node(node_id, **attrs)
                except Exception:
                    continue

        # v15.12: Vectorized edge add — groupby aggregates duplicate edges in one pass,
        # then add_edges_from bulk-loads. Identical to original but avoids per-row Python loop.
        if edges is not None and not edges.empty:
            try:
                _e = edges.copy()
                for _c in ["source", "target"]:
                    if _c in _e.columns:
                        _e[_c] = _e[_c].astype(str).str.strip()
                _e = _e[(_e.get("source", "") != "") & (_e.get("target", "") != "")]
                _valid_nodes = set(G.nodes())
                _e = _e[_e["source"].isin(_valid_nodes) & _e["target"].isin(_valid_nodes)]

                if not _e.empty:
                    # Aggregate duplicate (src, tgt) pairs — same semantics as original has_edge check
                    _agg = {}
                    if "weight" in _e.columns:
                        _agg["weight"] = "sum"
                    if "txn_count" in _e.columns:
                        _agg["txn_count"] = "sum"
                    if "edge_type" in _e.columns:
                        _agg["edge_type"] = "first"

                    _e_agg = (
                        _e.groupby(["source", "target"], as_index=False).agg(_agg)
                        if _agg
                        else _e[["source", "target"]].drop_duplicates()
                    )

                    for _col, _def in [
                        ("weight", 1.0),
                        ("txn_count", 0),
                        ("edge_type", "transaction"),
                    ]:
                        if _col not in _e_agg.columns:
                            _e_agg[_col] = _def

                    _e_agg["weight"] = pd.to_numeric(_e_agg["weight"], errors="coerce").fillna(1.0)
                    _e_agg["txn_count"] = (
                        pd.to_numeric(_e_agg["txn_count"], errors="coerce").fillna(0).astype(int)
                    )
                    _e_agg["edge_type"] = _e_agg["edge_type"].fillna("transaction").astype(str)

                    G.add_edges_from(
                        (
                            r["source"],
                            r["target"],
                            {
                                "weight": float(r["weight"]),
                                "edge_type": r["edge_type"],
                                "txn_count": int(r["txn_count"]),
                            },
                        )
                        for r in _e_agg.to_dict("records")
                    )
            except Exception:
                # Fallback: original row-by-row path
                for _, row in edges.iterrows():
                    try:
                        src = str(row.get("source", ""))
                        tgt = str(row.get("target", ""))
                        if not src or not tgt:
                            continue
                        if src in G.nodes and tgt in G.nodes:
                            weight = (
                                float(row.get("weight", 1.0))
                                if pd.notna(row.get("weight"))
                                else 1.0
                            )
                            edge_type = str(row.get("edge_type", "transaction"))
                            txn_count = (
                                int(row.get("txn_count", 0))
                                if pd.notna(row.get("txn_count"))
                                else 0
                            )
                            if G.has_edge(src, tgt):
                                G[src][tgt]["weight"] += weight
                                G[src][tgt]["txn_count"] += txn_count
                            else:
                                G.add_edge(
                                    src,
                                    tgt,
                                    weight=weight,
                                    edge_type=edge_type,
                                    txn_count=txn_count,
                                )
                    except Exception:
                        continue

        # v16.20 F07: Passthrough-floor + composite node selection.
        # Replaces pure degree-ranking cutoff which silently dropped low-degree
        # mule/intermediary accounts — exactly the accounts AML needs to detect.
        #
        # Priority order (when G.number_of_nodes() > max_nodes):
        #   Tier-1: ALL passthrough nodes (in_degree≥1 AND out_degree≥1).
        #           These receive AND forward funds = layering intermediaries.
        #           Kept unconditionally; capped at max_nodes if there are too many.
        #   Tier-2: Remaining slots filled by composite score:
        #           0.4 * norm_risk + 0.3 * norm_degree + 0.3 * norm_flow
        #           (risk_score=0 before scoring is fine — degree+flow dominate correctly)
        #
        # Works for any size: 50, 100, 1000, 10000 nodes.
        # Only node+edge tables required (in/out degree available from edge table alone).
        max_nodes = PIPELINE.GRAPH_MAX_NODES
        if G.number_of_nodes() > max_nodes:
            try:
                all_nodes = list(G.nodes())
                # Tier-1: passthrough (both receive and send)
                passthrough = [
                    n for n in all_nodes
                    if G.in_degree(n) >= 1 and G.out_degree(n) >= 1
                ]
                keep = set(passthrough[:max_nodes])  # cap if pathologically many

                if len(keep) < max_nodes:
                    # Tier-2: composite score for remaining slots
                    remaining = [n for n in all_nodes if n not in keep]
                    rs_vals = [float(G.nodes[n].get("risk_score", 0) or 0) for n in remaining]
                    deg_vals = [float(G.degree(n)) for n in remaining]
                    flow_vals = [
                        abs(float(G.nodes[n].get("in_flow", 0) or 0)) +
                        abs(float(G.nodes[n].get("out_flow", 0) or 0))
                        for n in remaining
                    ]
                    rs_max = max(rs_vals) or 1.0
                    deg_max = max(deg_vals) or 1.0
                    flow_max = max(flow_vals) or 1.0
                    composites = [
                        (n, 0.4 * (r / rs_max) + 0.3 * (d / deg_max) + 0.3 * (f / flow_max))
                        for n, r, d, f in zip(remaining, rs_vals, deg_vals, flow_vals)
                    ]
                    composites.sort(key=lambda x: x[1], reverse=True)
                    slots = max_nodes - len(keep)
                    for n, _ in composites[:slots]:
                        keep.add(n)

                remove = set(G.nodes()) - keep
                G.remove_nodes_from(remove)
                log_audit(
                    "GRAPH_PRUNE",
                    f"Pruned to {len(keep)} nodes (passthrough={len(passthrough)}, "
                    f"composite-fill={len(keep)-min(len(passthrough), max_nodes)}, "
                    f"removed={len(remove)})",
                )
            except Exception:
                # Absolute fallback: pure degree ranking (safe but suboptimal)
                try:
                    degrees = sorted(G.degree(), key=lambda x: x[1], reverse=True)
                    keep = set(n for n, d in degrees[:max_nodes])
                    G.remove_nodes_from(set(G.nodes()) - keep)
                except Exception:
                    pass

        self.graph = G
        self.node_count = G.number_of_nodes()
        self.edge_count = G.number_of_edges()

        # Extract basic graph features
        if self.node_count > 0:
            self._add_basic_graph_features()

        # Cache weight range for edge scaling
        self._cache_weight_range()

        log_audit(
            "GRAPH_BUILD_COMPLETE", f"Graph: {self.node_count} nodes, {self.edge_count} edges"
        )

        return G

    def _cache_weight_range(self):
        """Cache min/max edge weights for fast normalization."""
        G = self.graph
        if G is None or G.number_of_edges() == 0:
            self._weight_range = (0.0, 1.0)
            return
        try:
            weights = [d.get("weight", 1.0) for _, _, d in G.edges(data=True)]
            wmin = min(weights) if weights else 0.0
            wmax = max(weights) if weights else 1.0
            self._weight_range = (wmin, max(wmax, wmin + 0.01))
        except Exception:
            self._weight_range = (0.0, 1.0)

    def _add_basic_graph_features(self):
        G = self.graph
        if G is None or G.number_of_nodes() == 0:
            return

        # v15.12: Bulk degree assignment — single C-level dict traversal, no per-node Python loop.
        # nx.set_node_attributes is ~5-10x faster than G.nodes[node][attr] = val in a loop.
        try:
            nx.set_node_attributes(G, dict(G.in_degree()), "in_degree")
            nx.set_node_attributes(G, dict(G.out_degree()), "out_degree")
            nx.set_node_attributes(G, dict(G.degree()), "total_degree")
        except Exception:
            for node in G.nodes():
                try:
                    G.nodes[node]["in_degree"] = G.in_degree(node)
                    G.nodes[node]["out_degree"] = G.out_degree(node)
                    G.nodes[node]["total_degree"] = G.in_degree(node) + G.out_degree(node)
                except Exception:
                    pass

        # v15.12: Vectorized flow computation via scipy.sparse CSR matrix.
        # Builds A[i,j]=weight (src→dst), then:
        #   out_flow[i] = row-sum(A)[i]  (money sent by node i)
        #   in_flow[j]  = col-sum(A)[j]  (money received by node j)
        # Exact same math as the original predecessor/successor loops.
        # ~10x faster because all arithmetic is in C-level scipy, no Python per-edge overhead.
        _nodes_list = list(G.nodes())
        _n = len(_nodes_list)
        _nidx = {nd: i for i, nd in enumerate(_nodes_list)}

        _flow_ok = False
        if _HAS_SCIPY_SPARSE and G.number_of_edges() > 0:
            try:
                _rows, _cols, _wts = [], [], []
                for _u, _v, _d in G.edges(data=True):
                    _i = _nidx.get(_u)
                    _j = _nidx.get(_v)
                    if _i is not None and _j is not None:
                        _rows.append(_i)
                        _cols.append(_j)
                        _wts.append(float(_d.get("weight", 1.0) or 1.0))
                _A = _csr_matrix((_wts, (_rows, _cols)), shape=(_n, _n))
                _out_f = np.asarray(_A.sum(axis=1)).flatten()  # row-sums = money sent
                _in_f = np.asarray(_A.sum(axis=0)).flatten()  # col-sums = money received
                nx.set_node_attributes(
                    G, {_nodes_list[i]: float(_in_f[i]) for i in range(_n)}, "in_flow"
                )
                nx.set_node_attributes(
                    G, {_nodes_list[i]: float(_out_f[i]) for i in range(_n)}, "out_flow"
                )
                nx.set_node_attributes(
                    G, {_nodes_list[i]: float(_in_f[i] - _out_f[i]) for i in range(_n)}, "net_flow"
                )
                # v16.20 F06: Count-normalized flow features.
                # Raw flow (sum of amounts) cannot distinguish 1 × $10K from 1000 × $10.
                # Per-transaction amount exposes average ticket size — a smurfing signal.
                # Edge txn_count aggregation already done in build() vectorized path.
                _in_txn = np.zeros(_n, dtype=float)
                _out_txn = np.zeros(_n, dtype=float)
                for _u, _v, _ed in G.edges(data=True):
                    _j2 = _nidx.get(_v)
                    _i2 = _nidx.get(_u)
                    tc = float(_ed.get("txn_count", 1) or 1)
                    if _j2 is not None:
                        _in_txn[_j2] += tc
                    if _i2 is not None:
                        _out_txn[_i2] += tc
                nx.set_node_attributes(
                    G, {_nodes_list[i]: float(_in_txn[i]) for i in range(_n)}, "in_txn_count"
                )
                nx.set_node_attributes(
                    G, {_nodes_list[i]: float(_out_txn[i]) for i in range(_n)}, "out_txn_count"
                )
                # per-txn average amount (safe div-by-zero guard)
                _in_avg = np.where(_in_txn > 0, _in_f / _in_txn, 0.0)
                _out_avg = np.where(_out_txn > 0, _out_f / _out_txn, 0.0)
                nx.set_node_attributes(
                    G, {_nodes_list[i]: float(_in_avg[i]) for i in range(_n)}, "in_flow_per_txn"
                )
                nx.set_node_attributes(
                    G, {_nodes_list[i]: float(_out_avg[i]) for i in range(_n)}, "out_flow_per_txn"
                )
                _flow_ok = True
            except Exception:
                pass

        if not _flow_ok:
            # Fallback: original predecessor/successor loop (handles edge cases)
            for node in G.nodes():
                try:
                    in_flow = sum(G[u][node].get("weight", 0) for u in G.predecessors(node))
                    out_flow = sum(G[node][v].get("weight", 0) for v in G.successors(node))
                    G.nodes[node]["in_flow"] = in_flow
                    G.nodes[node]["out_flow"] = out_flow
                    G.nodes[node]["net_flow"] = (
                        in_flow - out_flow if isinstance(in_flow, (int, float)) else 0
                    )
                except Exception:
                    G.nodes[node]["in_flow"] = 0
                    G.nodes[node]["out_flow"] = 0
                    G.nodes[node]["net_flow"] = 0

        # ── v15.6: Circular Ring Detection (Strongly Connected Components) ────
        # Business value: A group of 2+ accounts where money can travel in a
        # closed circle is a potential circular layering ring. This detects ALL
        # multi-hop rings (A→B→C→A etc.) — not just 2-hop (A→B→A).
        # Math: Tarjan's SCC algorithm. Exact. O(n+e). Zero approximation.
        # Output per node: scc_size (ring size), in_ring (1 if inside ring)
        # Requires: only the directed transaction graph G (node+edge tables minimum)
        try:
            _scc_sets = list(nx.strongly_connected_components(G))
            _nontrivial = [s for s in _scc_sets if len(s) > 1]
            _node_scc_map: Dict = {}
            for _scc_idx, _scc_set in enumerate(_scc_sets):
                for _nd in _scc_set:
                    _node_scc_map[_nd] = (_scc_idx, len(_scc_set))
            for node in G.nodes():
                _scc_idx, _scc_sz = _node_scc_map.get(node, (0, 1))
                G.nodes[node]["scc_size"] = _scc_sz
                G.nodes[node]["in_ring"] = 1 if _scc_sz > 1 else 0
            self.scc_summary = {
                "ring_count": len(_nontrivial),
                "nodes_in_rings": sum(len(s) for s in _nontrivial),
                "largest_ring": max((len(s) for s in _nontrivial), default=0),
            }
        except Exception:
            self.scc_summary = {"ring_count": 0, "nodes_in_rings": 0, "largest_ring": 0}

        # v16.2 B1: Velocity features — delta_degree and dormancy_activation.
        # Detects the DORMANT ACCOUNT ACTIVATION pattern (top Europol mule typology):
        # an account that was quiet in the prior run but is suddenly active this run.
        # Reads the most recent prior scored_results row from SQLite (read-only, offline).
        # If DB missing / first run / any error: silently sets features to 0 (non-fatal).
        # Requires: only the existing SQLite DB that l6_scoring already writes.
        # Air-gapped: no external calls. No PII sent anywhere. Local reads only.
        # Outputs per node (as graph attributes, picked up by l5_analytics):
        #   prior_activity_score: proxy for prior run activity level (consensus_count)
        #   delta_activity:       max(0, current_degree - prior_activity) — positive = growing
        #   dormancy_activation:  1 if was quiet (prior < 2) and now active (degree >= 3)
        try:
            import sqlite3 as _sqlite3_v
            import json as _json_v
            from pathlib import Path as _Path_v

            _db_path_v = str(getattr(PIPELINE, "DB_PATH", "data/fcdai.db"))
            if _Path_v(_db_path_v).exists():
                _vconn = _sqlite3_v.connect(_db_path_v, timeout=2)
                _prev_row_v = _vconn.execute(
                    "SELECT data FROM scored_results ORDER BY id DESC LIMIT 1"
                ).fetchone()
                _vconn.close()
                if _prev_row_v is not None:
                    _prev_data_v = _json_v.loads(_prev_row_v[0])
                    _prev_df_v = pd.DataFrame(_prev_data_v)
                    if "node_id" in _prev_df_v.columns:
                        # v16.20 F09: Use total_degree from prior run as prior activity proxy.
                        # consensus_count (0-10) and G.degree() (0-1000+) are incommensurable.
                        # total_degree from prior scored_results is in the same units as
                        # current G.degree(), making delta_activity dimensionally valid.
                        # Fallback order: total_degree → degree_total → consensus_count / 10
                        if "total_degree" in _prev_df_v.columns:
                            _act_col = "total_degree"
                            _act_scale = 1.0
                        elif "degree_total" in _prev_df_v.columns:
                            _act_col = "degree_total"
                            _act_scale = 1.0
                        elif "consensus_count" in _prev_df_v.columns:
                            # consensus_count is 0-10 (max families); scale by 10 to rough-map to degree
                            _act_col = "consensus_count"
                            _act_scale = 10.0  # rough proxy; better than raw
                        else:
                            _act_col = None
                            _act_scale = 1.0

                        _prior_map_v = {}
                        if _act_col:
                            _raw_vals = pd.to_numeric(_prev_df_v[_act_col], errors="coerce").fillna(0)
                            _prior_map_v = dict(
                                zip(
                                    _prev_df_v["node_id"].astype(str),
                                    _raw_vals * _act_scale,
                                )
                            )
                        for node in G.nodes():
                            _prior_act = float(_prior_map_v.get(str(node), 0.0))
                            _curr_deg = float(G.degree(node))
                            G.nodes[node]["prior_activity_score"] = _prior_act
                            G.nodes[node]["delta_activity"] = max(0.0, _curr_deg - _prior_act)
                            # dormancy: was quiet (prior_activity < 2) and now active (degree >= 3)
                            G.nodes[node]["dormancy_activation"] = (
                                1 if (_prior_act < 2.0 and _curr_deg >= 3) else 0
                            )
                        log_audit(
                            "VELOCITY_FEATURES",
                            f"delta_activity + dormancy_activation loaded from prior DB run",
                        )
        except Exception:
            pass  # first run / DB missing / parse error — non-fatal, features default to 0

    # =========================================================================
    # NODE SELECTION STRATEGIES (for scale)
    # =========================================================================
    def _select_nodes_by_degree(self, max_nodes: int) -> set:
        """Select top-N nodes by total degree (most connected)."""
        G = self.graph
        degrees = sorted(G.degree(), key=lambda x: x[1], reverse=True)
        return set(n for n, d in degrees[:max_nodes])

    def _select_nodes_by_risk(self, max_nodes: int) -> set:
        """Select top-N nodes by risk score (highest risk first)."""
        G = self.graph
        scored = []
        for n in G.nodes():
            rs = G.nodes[n].get("risk_score", 0)
            if rs is None or (isinstance(rs, float) and np.isnan(rs)):
                rs = 0
            scored.append((n, rs))
        scored.sort(key=lambda x: x[1], reverse=True)
        return set(n for n, _ in scored[:max_nodes])

    def _select_nodes_composite(self, max_nodes: int) -> set:
        """Select top-N by composite score: 0.4*norm_risk + 0.3*norm_degree + 0.3*norm_flow."""
        G = self.graph
        nodes_data = []
        for n in G.nodes():
            attrs = G.nodes[n]
            rs = attrs.get("risk_score", 0)
            if rs is None or (isinstance(rs, float) and np.isnan(rs)):
                rs = 0
            deg = G.degree(n)
            flow = abs(attrs.get("in_flow", 0)) + abs(attrs.get("out_flow", 0))
            nodes_data.append((n, float(rs), float(deg), float(flow)))

        if not nodes_data:
            return set()

        # Normalize each dimension
        risks = [x[1] for x in nodes_data]
        degs = [x[2] for x in nodes_data]
        flows = [x[3] for x in nodes_data]
        r_max = max(risks) or 1.0
        d_max = max(degs) or 1.0
        f_max = max(flows) or 1.0

        composites = []
        for n, r, d, f in nodes_data:
            score = 0.4 * (r / r_max) + 0.3 * (d / d_max) + 0.3 * (f / f_max)
            composites.append((n, score))

        composites.sort(key=lambda x: x[1], reverse=True)
        return set(n for n, _ in composites[:max_nodes])

    # =========================================================================
    # EDGE WEIGHT NORMALIZATION
    # =========================================================================
    def _normalize_weight(self, weight: float) -> float:
        """Normalize edge weight to 0.0-1.0 range for visualization."""
        wmin, wmax = self._weight_range
        if wmax <= wmin:
            return 0.5
        return max(0.0, min(1.0, (weight - wmin) / (wmax - wmin)))

    # =========================================================================
    # SCALABLE CYTOSCAPE ELEMENT GENERATION
    # =========================================================================
    def to_cytoscape_elements(self, max_nodes: int = 1000) -> List[Dict]:
        """Legacy API — calls scalable version with degree selection."""
        return self.to_cytoscape_elements_scaled(
            max_nodes=max_nodes, selection="degree", show_weights=False
        )

    def to_cytoscape_elements_scaled(
        self,
        max_nodes: int = 5000,
        selection: str = "composite",
        show_weights: bool = True,
        performance_mode: bool = False,
    ) -> List[Dict]:
        """
        Scalable cytoscape element generation.

        Args:
            max_nodes: Maximum nodes to render (1K / 5K / 10K).
            selection: Node selection strategy — "degree", "risk", or "composite".
            show_weights: Include normalized edge weight data for visual scaling.
            performance_mode: If True, skips extra attributes for faster rendering.

        Returns:
            List of cytoscape-compatible element dicts.
        """
        G = self.graph
        if G is None or G.number_of_nodes() == 0:
            return []

        t0 = time.time()
        elements = []

        try:
            # ── Select visible nodes ──
            total = G.number_of_nodes()
            if total > max_nodes:
                if selection == "risk":
                    visible_nodes = self._select_nodes_by_risk(max_nodes)
                elif selection == "composite":
                    visible_nodes = self._select_nodes_composite(max_nodes)
                else:
                    visible_nodes = self._select_nodes_by_degree(max_nodes)
            else:
                visible_nodes = set(G.nodes())

            # ── Build node elements ──
            for node in visible_nodes:
                try:
                    attrs = G.nodes[node]
                    risk_score = attrs.get("risk_score", 0)
                    if risk_score is None or (
                        isinstance(risk_score, float) and np.isnan(risk_score)
                    ):
                        risk_score = 0

                    # SYNC FIX: Use percentile-based tier from scored_df (set on G.nodes
                    # by engine after scoring) so radar matches all other pages.
                    # Fall back to score-threshold only if risk_tier not yet assigned.
                    _stored_tier = attrs.get("risk_tier", None)
                    if _stored_tier in ("P1", "P2", "P3", "P4"):
                        tier = _stored_tier
                    else:
                        # Pre-run fallback: derive from score thresholds
                        if risk_score >= 80:
                            tier = "P1"
                        elif risk_score >= 60:
                            tier = "P2"
                        elif risk_score >= 40:
                            tier = "P3"
                        else:
                            tier = "P4"

                    data = {
                        "id": node,
                        "label": attrs.get("name", node),
                        "risk_score": risk_score,
                        "tier": tier,
                        "degree": G.degree(node),
                    }

                    if not performance_mode:
                        # Include richer attributes for investigation
                        data["in_flow"] = attrs.get("in_flow", 0)
                        data["out_flow"] = attrs.get("out_flow", 0)
                        data["net_flow"] = attrs.get("net_flow", 0)
                        for k, v in attrs.items():
                            if (
                                k not in data
                                and isinstance(v, (int, float, str, bool))
                                and v is not None
                            ):
                                data[k] = v

                    elements.append({"data": data, "classes": tier})
                except Exception:
                    continue

            # ── Build edge elements ──
            for src, tgt, edata in G.edges(data=True):
                if src in visible_nodes and tgt in visible_nodes:
                    weight = edata.get("weight", 1)
                    edge_el = {
                        "data": {
                            "source": src,
                            "target": tgt,
                            "weight": weight,
                            "edge_type": edata.get("edge_type", "transaction"),
                        }
                    }
                    if show_weights:
                        nw = self._normalize_weight(weight)
                        edge_el["data"]["norm_weight"] = round(nw, 4)
                        # Thickness class: thin / medium / thick / heavy
                        if nw < 0.25:
                            edge_el["classes"] = "edge-thin"
                        elif nw < 0.50:
                            edge_el["classes"] = "edge-medium"
                        elif nw < 0.75:
                            edge_el["classes"] = "edge-thick"
                        else:
                            edge_el["classes"] = "edge-heavy"
                    elements.append(edge_el)

        except Exception:
            pass

        elapsed = time.time() - t0
        log_audit(
            "CYTOSCAPE_ELEMENTS",
            f"Generated {len(elements)} elements "
            f"(nodes={len(visible_nodes) if 'visible_nodes' in dir() else '?'}, "
            f"max={max_nodes}, sel={selection}) in {elapsed:.3f}s",
        )
        return elements

    # =========================================================================
    # GRAPH SCALE INFO
    # =========================================================================
    def get_scale_info(self) -> Dict[str, Any]:
        """Return graph scale metrics for the UI to decide rendering strategy."""
        G = self.graph
        if G is None:
            return {
                "total_nodes": 0,
                "total_edges": 0,
                "recommended_tier": "small",
                "weight_range": [0, 0],
                "density": 0,
                "components": 0,
            }

        n = G.number_of_nodes()
        e = G.number_of_edges()

        if n <= 1000:
            tier = "small"
        elif n <= 5000:
            tier = "medium"
        else:
            tier = "large"

        return {
            "total_nodes": n,
            "total_edges": e,
            "recommended_tier": tier,
            "recommended_layout": SCALE_TIERS[tier]["layout"],
            "animate": SCALE_TIERS[tier]["animate"],
            "weight_range": list(self._weight_range),
            "density": round(nx.density(G), 6) if n > 0 else 0,
            "components": nx.number_weakly_connected_components(G) if n > 0 else 0,
            "avg_degree": round(np.mean([d for _, d in G.degree()]), 2) if n > 0 else 0,
        }

    def get_node_details(self, node_id: str) -> Dict[str, Any]:
        G = self.graph
        if G is None or node_id not in G.nodes:
            return {"error": f"Node {node_id} not found"}
        try:
            attrs = dict(G.nodes[node_id])
            neighbors = list(G.predecessors(node_id)) + list(G.successors(node_id))
            return {
                "node_id": node_id,
                "attributes": {k: v for k, v in attrs.items() if v is not None},
                "in_degree": G.in_degree(node_id),
                "out_degree": G.out_degree(node_id),
                "total_degree": G.in_degree(node_id) + G.out_degree(node_id),
                "neighbor_count": len(set(neighbors)),
                "in_flow": attrs.get("in_flow", 0),
                "out_flow": attrs.get("out_flow", 0),
                "net_flow": attrs.get("net_flow", 0),
                "risk_score": attrs.get("risk_score", None),
            }
        except Exception:
            return {"error": f"Error reading node {node_id}"}

    def get_summary(self) -> Dict:
        G = self.graph
        if G is None or G.number_of_nodes() == 0:
            return {"status": "No graph built", "nodes": 0, "edges": 0}
        try:
            return {
                "nodes": G.number_of_nodes(),
                "edges": G.number_of_edges(),
                "density": nx.density(G),
                "avg_degree": np.mean([d for _, d in G.degree()]) if G.number_of_nodes() > 0 else 0,
                "components": nx.number_weakly_connected_components(G),
                "ring_count": self.scc_summary.get("ring_count", 0),
                "nodes_in_rings": self.scc_summary.get("nodes_in_rings", 0),
                "largest_ring": self.scc_summary.get("largest_ring", 0),
            }
        except Exception:
            return {"nodes": G.number_of_nodes(), "edges": G.number_of_edges()}
