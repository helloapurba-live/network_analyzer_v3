"""
Layer 7: Reporting & Activity Report Generation — V9 BULLETPROOF
=====================================
v9: Handles empty scored_df, missing columns, None graph.
"""

import pandas as pd
import numpy as np
import networkx as nx
from pathlib import Path
from typing import Dict, List, Optional, Any
from datetime import datetime
import json
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import PATHS, PIPELINE
from utils.logger import log_audit
from utils.persistence import store_or_load

# v16.8 L2: Presidio PII scrubbing for free-text narratives (airgap-safe, optional)
try:
    from utils.presidio_pii import anonymise_text as _presidio_anonymise

    _HAS_PRESIDIO = True
except Exception:
    _HAS_PRESIDIO = False
    _presidio_anonymise = None


def _scrub_narrative(text: str) -> str:
    """v16.8 L2: Redact PII from narrative text using presidio (if available).

    Design rules:
      - Degrades silently when presidio / spaCy not installed.
      - Never logs the input text through the audit trail (PII safety).
      - Returns original text unchanged if presidio unavailable.
    """
    if not _HAS_PRESIDIO or _presidio_anonymise is None:
        return text
    try:
        return _presidio_anonymise(text)
    except Exception:
        return text


class ReportingLayer:
    """v9: Fully defensive reporting. Handles empty data gracefully."""

    def __init__(self):
        self.reports: Dict[str, Any] = {}
        self.narratives: Dict[str, str] = {}

    def generate_reports(
        self,
        scored_df: pd.DataFrame,
        G: nx.DiGraph = None,
        analytics: Dict[str, pd.DataFrame] = None,
    ) -> Dict[str, Any]:
        # v16.19 BUG-1: Clear narratives at the start of every run to prevent ghost data.
        # Without this, narratives from a prior run (different data slice / max_customers)
        # persist in self.narratives and are returned via get_narrative() for nodes that
        # no longer exist or changed tier in the current run.
        self.narratives = {}

        log_audit(
            "REPORTING_START",
            f"Generating reports for {len(scored_df) if scored_df is not None else 0} nodes",
        )

        # v9: Handle empty/None scored_df
        if scored_df is None or scored_df.empty:
            self.reports = {
                "narratives": {},
                "investigation_queue": pd.DataFrame(),
                "risk_matrix": {"total": 0, "tiers": {}, "score_distribution": {}},
                "timestamp": datetime.now().isoformat(),
            }
            log_audit("REPORTING_COMPLETE", "Empty results — no reports")
            return self.reports

        # Generate Activity Report narratives for P1/P2
        try:
            if "risk_tier" in scored_df.columns:
                high_risk = scored_df[scored_df["risk_tier"].isin(["P1", "P2"])].copy()
                # v15.11: cap narrative generation at top-50 (sorted by score desc)
                # Prevents O(n) bottleneck when large populations have many P1/P2 flags.
                if "risk_score" in high_risk.columns:
                    high_risk = high_risk.nlargest(50, "risk_score")
                else:
                    high_risk = high_risk.head(50)
                for _, row in high_risk.iterrows():
                    try:
                        node_id = row["node_id"]
                        narrative = self._generate_narrative(row, G, analytics)
                        self.narratives[node_id] = narrative
                    except Exception:
                        continue
        except Exception:
            pass

        # Build investigation queue
        investigation_queue = self._build_investigation_queue(scored_df, G)

        # Risk matrix summary
        risk_matrix = self._build_risk_matrix(scored_df)

        self.reports = {
            "narratives": self.narratives,
            "investigation_queue": investigation_queue,
            "risk_matrix": risk_matrix,
            "timestamp": datetime.now().isoformat(),
        }

        try:
            store_or_load("stage7_investigation_queue", investigation_queue)
        except Exception:
            pass

        log_audit(
            "REPORTING_COMPLETE",
            f"Generated {len(self.narratives)} narratives, "
            f"{len(investigation_queue)} investigation items",
        )

        return self.reports

    def _generate_narrative(self, row, G=None, analytics=None) -> str:
        try:
            node_id = row.get("node_id", "UNKNOWN")
            score = row.get("risk_score", 0) or 0
            tier = row.get("risk_tier", "P4")

            lines = [
                f"ACTIVITY REPORT — {node_id}",
                f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M')}",
                f"Risk Score: {score:.1f}/100 | Tier: {tier}",
                "",
            ]

            if G is not None and node_id in G.nodes:
                try:
                    attrs = G.nodes[node_id]
                    lines.append("== NETWORK ANALYSIS ==")
                    lines.append(f"Network connections: {G.degree(node_id)}")
                    in_flow = attrs.get("in_flow", 0) or 0
                    out_flow = attrs.get("out_flow", 0) or 0
                    lines.append(f"Flow: In ${in_flow:,.2f} / Out ${out_flow:,.2f}")
                    lines.append("")
                except Exception:
                    pass

            lines.append("== RISK FACTORS ==")
            try:
                score_cols = [c for c in row.index if c.startswith("score_")]
                for col in score_cols:
                    val = row.get(col, 0) or 0
                    if isinstance(val, (int, float)) and val > 0.3:
                        family = col.replace("score_", "").replace("_", " ").title()
                        level = "HIGH" if val > 0.7 else "ELEVATED" if val > 0.5 else "MODERATE"
                        lines.append(f"  - {family}: {val:.3f} [{level}]")
            except Exception:
                pass

            lines.append("")
            lines.append("== RECOMMENDATION ==")
            if tier == "P1":
                lines.append("ACTION: IMMEDIATE RESTRICTION. Escalate to compliance officer.")
            elif tier == "P2":
                lines.append("ACTION: Enhanced Due Diligence required.")

            lines.append(f"\nGenerated by FCDAI Network Analyzer V9")
            narrative = "\n".join(lines)
            # v16.8 L2: Scrub any residual PII from free-text narrative
            return _scrub_narrative(narrative)
        except Exception:
            return f"Report generation failed for {row.get('node_id', 'UNKNOWN')}"

    def _build_investigation_queue(self, scored_df, G=None) -> pd.DataFrame:
        try:
            if scored_df is None or scored_df.empty:
                return pd.DataFrame()
            queue = scored_df.copy()
            if "risk_score" in queue.columns:
                queue = queue.sort_values("risk_score", ascending=False)

            if G is not None:
                try:
                    queue["degree"] = queue["node_id"].apply(
                        lambda n: G.degree(n) if n in G.nodes else 0
                    )
                    queue["in_flow"] = queue["node_id"].apply(
                        lambda n: G.nodes[n].get("in_flow", 0) if n in G.nodes else 0
                    )
                    queue["out_flow"] = queue["node_id"].apply(
                        lambda n: G.nodes[n].get("out_flow", 0) if n in G.nodes else 0
                    )
                except Exception:
                    pass

            capacity = PIPELINE.INVESTIGATION_CAPACITY
            return queue.head(capacity)
        except Exception:
            return pd.DataFrame()

    def _build_risk_matrix(self, scored_df) -> Dict:
        try:
            if scored_df is None or scored_df.empty or "risk_score" not in scored_df.columns:
                return {"total": 0, "tiers": {}, "score_distribution": {}}

            matrix = {
                "total": len(scored_df),
                "tiers": {},
                "score_distribution": {
                    "0-20": int((scored_df["risk_score"] <= 20).sum()),
                    "20-40": int(
                        ((scored_df["risk_score"] > 20) & (scored_df["risk_score"] <= 40)).sum()
                    ),
                    "40-60": int(
                        ((scored_df["risk_score"] > 40) & (scored_df["risk_score"] <= 60)).sum()
                    ),
                    "60-80": int(
                        ((scored_df["risk_score"] > 60) & (scored_df["risk_score"] <= 80)).sum()
                    ),
                    "80-100": int((scored_df["risk_score"] > 80).sum()),
                },
            }

            if "risk_tier" in scored_df.columns:
                for tier in ["P1", "P2", "P3", "P4"]:
                    tier_df = scored_df[scored_df["risk_tier"] == tier]
                    matrix["tiers"][tier] = {
                        "count": len(tier_df),
                        "avg_score": float(tier_df["risk_score"].mean()) if len(tier_df) > 0 else 0,
                        "max_score": float(tier_df["risk_score"].max()) if len(tier_df) > 0 else 0,
                    }

            return matrix
        except Exception:
            return {"total": 0, "tiers": {}, "score_distribution": {}}

    def export_csv(self, name: str, df=None) -> Path:
        try:
            PATHS.EXPORTS.mkdir(parents=True, exist_ok=True)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filepath = PATHS.EXPORTS / f"{name}_{timestamp}.csv"
            if df is not None:
                df.to_csv(filepath, index=False)
            log_audit("EXPORT_CSV", f"{filepath.name}")
            return filepath
        except Exception:
            return Path()

    def export_full_report(self) -> Path:
        if "investigation_queue" in self.reports:
            return self.export_csv("full_report", self.reports["investigation_queue"])
        return Path()

    def get_narrative(self, node_id: str) -> str:
        return self.narratives.get(node_id, f"No narrative for {node_id}")

    def get_summary(self) -> Dict:
        return {
            "narratives_generated": len(self.narratives),
            "queue_size": len(self.reports.get("investigation_queue", [])) if self.reports else 0,
            "risk_matrix": self.reports.get("risk_matrix", {}) if self.reports else {},
        }
