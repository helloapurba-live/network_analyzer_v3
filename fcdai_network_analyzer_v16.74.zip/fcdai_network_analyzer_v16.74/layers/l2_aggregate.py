"""
Layer 2: Customer-Level Aggregation — V15.7
=====================================
v15.7: Similarity edges from shared_attribute table.
  NEW-SA: Build hidden-connection edges between nodes sharing same Device_ID /
          Phone / IP_Address / Address. These connections are invisible in the
          transaction graph but are primary AML indicators of related parties.
          Edge type: shared_device / shared_phone / shared_ip / shared_address.
          Per-node shared_infrastructure_count feature added for scoring/evidence.
v15.6: Temporal event_type extraction (Circular_Flow, Account_Burst).
v9: Handles missing columns, empty tables, 0-row DataFrames.
Skips any column that doesn't exist instead of crashing.
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from datetime import datetime
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import PIPELINE
from utils.logger import log_audit, log_data_transform
from utils.persistence import store_or_load


class AggregateLayer:
    """v12.36: Fully defensive aggregation. Supports graph-schema AND legacy modes."""

    def __init__(self):
        self.customer_features: Optional[pd.DataFrame] = None
        self.edges: Optional[pd.DataFrame] = None
        self.account_map: Dict[str, str] = {}

    # =========================================================================
    # v12.36: GRAPH-SCHEMA MODE — node+edge direct path
    # =========================================================================
    def run_graph_schema(
        self, tables: Dict[str, pd.DataFrame]
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        v12.36: Convert graph-schema tables (node + edge) directly to
        customer_features + edges format expected by GraphConstructionLayer.

        This allows the pipeline to run with ONLY 2 tables (node + edge).
        Optional enrichment from: relationship_edge, shared_attribute, temporal,
        and any legacy tables (kyc, alert, historical) if they happen to be present.

        Node table schema:  node_id, name, node_type, country, identifier, risk_score
        Edge table schema:  from_node, to_node, amount, date, transaction_type
        """
        log_audit(
            "AGGREGATE_GRAPH_SCHEMA_START", f"Graph-schema mode: {len(tables)} tables available"
        )

        # --- Convert NODE table → customer_features ---
        node_df = tables.get("node")
        if node_df is None or node_df.empty:
            self.customer_features = pd.DataFrame({"customer_id": []})
            self.edges = pd.DataFrame(
                columns=["source", "target", "weight", "txn_count", "edge_type"]
            )
            return self.customer_features, self.edges

        # Rename node_id → customer_id for downstream compatibility
        cf = node_df.copy()
        if "node_id" in cf.columns and "customer_id" not in cf.columns:
            cf = cf.rename(columns={"node_id": "customer_id"})

        # Ensure customer_id is string
        if "customer_id" in cf.columns:
            cf["customer_id"] = cf["customer_id"].astype(str)

        # --- Enrich with edge-derived transaction features ---
        edge_df = tables.get("edge")
        if edge_df is not None and not edge_df.empty:
            try:
                # Standardize column names
                e = edge_df.copy()
                col_map = {}
                if "from_node" in e.columns:
                    col_map["from_node"] = "source"
                if "to_node" in e.columns:
                    col_map["to_node"] = "target"
                if col_map:
                    e = e.rename(columns=col_map)

                # Aggregate transaction features per node (as source)
                if "source" in e.columns:
                    e["source"] = e["source"].astype(str)
                    amount_col = "amount" if "amount" in e.columns else "weight"
                    if amount_col in e.columns:
                        out_agg = (
                            e.groupby("source")
                            .agg(
                                txn_count_out=(amount_col, "count"),
                                txn_total_out=(amount_col, "sum"),
                                txn_avg_out=(amount_col, "mean"),
                                txn_max_out=(amount_col, "max"),
                            )
                            .reset_index()
                            .rename(columns={"source": "customer_id"})
                        )
                        cf = cf.merge(out_agg, on="customer_id", how="left")

                # Aggregate incoming features per node (as target)
                if "target" in e.columns:
                    e["target"] = e["target"].astype(str)
                    amount_col = "amount" if "amount" in e.columns else "weight"
                    if amount_col in e.columns:
                        in_agg = (
                            e.groupby("target")
                            .agg(
                                txn_count_in=(amount_col, "count"),
                                txn_total_in=(amount_col, "sum"),
                                txn_avg_in=(amount_col, "mean"),
                            )
                            .reset_index()
                            .rename(columns={"target": "customer_id"})
                        )
                        cf = cf.merge(in_agg, on="customer_id", how="left")

                # Count unique counterparties
                if "source" in e.columns and "target" in e.columns:
                    cp_out = e.groupby("source")["target"].nunique().reset_index()
                    cp_out.columns = ["customer_id", "unique_counterparties"]
                    cf = cf.merge(cp_out, on="customer_id", how="left")
            except Exception:
                pass

        # --- Enrich with shared_attribute features (optional) ---
        # v15.7: Also compute shared_infrastructure_count — how many hidden-connection
        # edges this node has (distinct from raw attribute count above).
        # Meaningful types only: Device_ID, Phone, IP_Address, Address.
        if "shared_attribute" in tables and tables["shared_attribute"] is not None:
            try:
                sa = tables["shared_attribute"]
                nid_col = "node_id" if "node_id" in sa.columns else "customer_id"
                if nid_col in sa.columns:
                    sa_renamed = sa.copy()
                    if nid_col != "customer_id":
                        sa_renamed = sa_renamed.rename(columns={nid_col: "customer_id"})
                    sa_renamed["customer_id"] = sa_renamed["customer_id"].astype(str)
                    sa_count = (
                        sa_renamed.groupby("customer_id")
                        .size()
                        .reset_index(name="shared_attr_count")
                    )
                    cf = cf.merge(sa_count, on="customer_id", how="left")
                    # v15.7: Count how many shared-infrastructure partners each node has
                    _SA_MEANINGFUL = {"Device_ID", "Phone", "IP_Address", "Address"}
                    if (
                        "attribute_type" in sa_renamed.columns
                        and "attribute_value" in sa_renamed.columns
                    ):
                        sa_filt = sa_renamed[
                            sa_renamed["attribute_type"].isin(_SA_MEANINGFUL)
                        ].copy()
                        if len(sa_filt) > 0:
                            grp = sa_filt.groupby(["attribute_type", "attribute_value"])[
                                "customer_id"
                            ].apply(list)
                            infra_counts: dict = {}
                            for nodes_list in grp:
                                if len(nodes_list) > 1:
                                    for _nd in nodes_list:
                                        infra_counts[_nd] = infra_counts.get(_nd, 0) + (
                                            len(nodes_list) - 1
                                        )
                            if infra_counts:
                                _ic_df = pd.DataFrame(
                                    list(infra_counts.items()),
                                    columns=["customer_id", "shared_infrastructure_count"],
                                )
                                cf = cf.merge(_ic_df, on="customer_id", how="left")
            except Exception:
                pass

        # --- Enrich with temporal pattern features (optional) ---
        if "temporal" in tables and tables["temporal"] is not None:
            try:
                tp = tables["temporal"]

                # v16.26: classify AML event types in backend if not already present.
                # Input temporal data has NO event_type column — the classifier derives
                # it from raw transaction fields using aml_rules.yaml thresholds.
                if "event_type" not in tp.columns:
                    try:
                        from utils.aml_event_classifier import classify_events
                        tp = classify_events(tp)
                        tables["temporal"] = tp  # update shared reference
                    except Exception as _clf_err:
                        import logging as _log
                        _log.getLogger(__name__).warning(
                            "AML classifier unavailable: %s — event_type features skipped",
                            _clf_err,
                        )

                nid_col = "node_id" if "node_id" in tp.columns else "customer_id"
                if nid_col in tp.columns:
                    tp_renamed = tp.copy()
                    if nid_col != "customer_id":
                        tp_renamed = tp_renamed.rename(columns={nid_col: "customer_id"})
                    tp_renamed["customer_id"] = tp_renamed["customer_id"].astype(str)
                    tp_count = (
                        tp_renamed.groupby("customer_id")
                        .size()
                        .reset_index(name="temporal_event_count")
                    )
                    cf = cf.merge(tp_count, on="customer_id", how="left")
                    # v16.26: Event-type breakdown using new FATF-aligned uppercase labels.
                    # CIRCULAR_LAYERING = multi-hop fund cycle (replaces old "Circular_Flow")
                    # BURST_ACTIVITY    = dormant then sudden activity (replaces "Account_Burst")
                    # DORMANT_REACTIVATION = 90+ day dormancy then reactivation
                    if "event_type" in tp_renamed.columns:
                        for _evt_type, _col_name in [
                            ("CIRCULAR_LAYERING",    "temporal_circular_flow_count"),
                            ("BURST_ACTIVITY",        "temporal_burst_count"),
                            ("DORMANT_REACTIVATION",  "temporal_dormant_reactivation_count"),
                            ("STRUCTURING",           "temporal_structuring_count"),
                            ("SAR_INDICATOR",         "temporal_sar_count"),
                        ]:
                            _evt_df = tp_renamed[tp_renamed["event_type"] == _evt_type]
                            if len(_evt_df) > 0:
                                _agg = (
                                    _evt_df.groupby("customer_id")
                                    .size()
                                    .reset_index(name=_col_name)
                                )
                                cf = cf.merge(_agg, on="customer_id", how="left")
                        if "value" in tp_renamed.columns:
                            _circ_df = tp_renamed[tp_renamed["event_type"] == "CIRCULAR_LAYERING"]
                            if len(_circ_df) > 0:
                                _val_agg = (
                                    _circ_df.groupby("customer_id")["value"]
                                    .sum()
                                    .reset_index(name="temporal_circular_flow_value")
                                )
                                cf = cf.merge(_val_agg, on="customer_id", how="left")
            except Exception:
                pass

        # --- Enrich with legacy tables if present (optional) ---
        cid = "customer_id"
        # KYC enrichment
        if "kyc" in tables and tables["kyc"] is not None and len(tables["kyc"]) > 0:
            try:
                kyc = tables["kyc"]
                if cid in kyc.columns:
                    kyc_cols = [c for c in kyc.columns if c != cid]
                    kyc_dedup = kyc.drop_duplicates(subset=[cid], keep="last")
                    cf = cf.merge(kyc_dedup[[cid] + kyc_cols], on=cid, how="left")
            except Exception:
                pass

        # Alert enrichment
        if "alert" in tables and tables["alert"] is not None and len(tables["alert"]) > 0:
            try:
                alerts = tables["alert"]
                if cid in alerts.columns:
                    first_col = alerts.columns[0]
                    alert_agg = (
                        alerts.groupby(cid).agg(alert_count=(first_col, "count")).reset_index()
                    )
                    cf = cf.merge(alert_agg, on=cid, how="left")
            except Exception:
                pass

        # v16.23 T5: Case count enrichment (optional — graceful fallback to 0)
        if "case" in tables and tables["case"] is not None and len(tables["case"]) > 0:
            try:
                cases = tables["case"]
                if cid in cases.columns:
                    case_agg = (
                        cases.groupby(cid)
                        .agg(
                            case_count=(cases.columns[0], "count"),
                        )
                        .reset_index()
                    )
                    cf = cf.merge(case_agg, on=cid, how="left")
                    # Break down by case type if column exists
                    if "case_type" in cases.columns:
                        for _ctype in cases["case_type"].dropna().unique():
                            _ct_df = cases[cases["case_type"] == _ctype]
                            _ct_agg = (
                                _ct_df.groupby(cid)
                                .size()
                                .reset_index(name=f"case_{_ctype.lower()}_count")
                            )
                            cf = cf.merge(_ct_agg, on=cid, how="left")
            except Exception:
                pass

        # v16.23 T5: High-risk country transaction count (from edge table)
        edge_df = tables.get("edge")
        if edge_df is not None and not edge_df.empty:
            try:
                HIGH_RISK = {"HK", "AE", "KY", "BZ", "OTHER", "VE", "IR", "SY", "KP", "MM", "YE"}
                e = edge_df.copy()
                src_col = "from_node" if "from_node" in e.columns else "source"
                cc_col = next(
                    (c for c in ("counterparty_country", "country") if c in e.columns), None
                )
                if src_col in e.columns and cc_col:
                    e["src2"] = e[src_col].astype(str)
                    e["_is_hr"] = e[cc_col].isin(HIGH_RISK).astype(int)
                    hr_agg = (
                        e.groupby("src2")["_is_hr"].sum().reset_index()
                        .rename(columns={"src2": cid, "_is_hr": "high_risk_country_txn_count"})
                    )
                    cf["customer_id"] = cf["customer_id"].astype(str)
                    cf = cf.merge(hr_agg, on=cid, how="left")
            except Exception:
                pass

        # v16.23 T5: Derived event-type feature breakdown per node
        # Works on both 'edge' and 'transaction' tables containing derived_event_type column.
        for _tbl_key in ("edge", "transaction"):
            _evt_df = tables.get(_tbl_key)
            if _evt_df is not None and not _evt_df.empty:
                _evt_col = "derived_event_type" if "derived_event_type" in _evt_df.columns else (
                    "event_type" if "event_type" in _evt_df.columns else None
                )
                _src_col = next(
                    (c for c in ("from_node", "source", "account_id") if c in _evt_df.columns), None
                )
                if _evt_col and _src_col:
                    try:
                        from utils.event_rules import event_type_features_per_node
                        _evt_feats = event_type_features_per_node(
                            _evt_df.rename(columns={_src_col: "src"}),
                            node_id_col=cid,
                        )
                        if not _evt_feats.empty and cid in _evt_feats.columns:
                            _evt_feats[cid] = _evt_feats[cid].astype(str)
                            cf[cid] = cf[cid].astype(str)
                            cf = cf.merge(_evt_feats, on=cid, how="left")
                    except Exception:
                        pass
                    break  # use the first found table only

        # Fill NaN with 0 for all numeric columns
        try:
            numeric_cols = cf.select_dtypes(include=[np.number]).columns
            cf[numeric_cols] = cf[numeric_cols].fillna(0)
        except Exception:
            pass

        self.customer_features = cf

        # --- Convert EDGE table → edges format ---
        self.edges = self._extract_graph_schema_edges(tables)

        try:
            store_or_load("stage2_customer_features", self.customer_features)
            store_or_load("stage2_edges", self.edges)
        except Exception:
            pass

        log_audit(
            "AGGREGATE_GRAPH_SCHEMA_COMPLETE",
            f"Nodes: {len(self.customer_features)}, Edges: {len(self.edges)}",
        )
        return self.customer_features, self.edges

    def _extract_graph_schema_edges(self, tables: Dict[str, pd.DataFrame]) -> pd.DataFrame:
        """
        v12.36: Extract edges from graph-schema tables.
        Primary: "edge" table (from_node, to_node, amount)
        Secondary: "relationship_edge" table (from_node, to_node, relationship_type)
        """
        edges = []

        # Transaction edges from "edge" table
        if "edge" in tables and tables["edge"] is not None and len(tables["edge"]) > 0:
            try:
                e = tables["edge"].copy()
                col_map = {}
                if "from_node" in e.columns:
                    col_map["from_node"] = "source"
                if "to_node" in e.columns:
                    col_map["to_node"] = "target"
                if col_map:
                    e = e.rename(columns=col_map)

                # Ensure source/target as strings
                if "source" in e.columns:
                    e["source"] = e["source"].astype(str)
                if "target" in e.columns:
                    e["target"] = e["target"].astype(str)

                # Amount → weight
                if "amount" in e.columns and "weight" not in e.columns:
                    e["weight"] = e["amount"]
                elif "weight" not in e.columns:
                    e["weight"] = 1.0

                # Aggregate by source-target pair
                if "source" in e.columns and "target" in e.columns:
                    agg_dict = {"weight": ("weight", "sum")}
                    if "transaction_type" in e.columns:
                        agg_dict["edge_type"] = ("transaction_type", "first")
                    txn_edges = e.groupby(["source", "target"]).agg(**agg_dict).reset_index()
                    if "edge_type" not in txn_edges.columns:
                        txn_edges["edge_type"] = "transaction"
                    txn_edges["txn_count"] = e.groupby(["source", "target"]).size().values
                    edges.append(txn_edges)
            except Exception:
                pass

        # Relationship edges from "relationship_edge" table (optional)
        if "relationship_edge" in tables and tables["relationship_edge"] is not None:
            try:
                re_df = tables["relationship_edge"].copy()
                col_map = {}
                if "from_node" in re_df.columns:
                    col_map["from_node"] = "source"
                if "to_node" in re_df.columns:
                    col_map["to_node"] = "target"
                if col_map:
                    re_df = re_df.rename(columns=col_map)
                if "source" in re_df.columns and "target" in re_df.columns:
                    re_df["source"] = re_df["source"].astype(str)
                    re_df["target"] = re_df["target"].astype(str)
                    if "weight" not in re_df.columns:
                        re_df["weight"] = 1.0
                    if "edge_type" not in re_df.columns:
                        re_df["edge_type"] = re_df.get("relationship_type", "relationship")
                    re_df["txn_count"] = 0
                    edges.append(re_df[["source", "target", "weight", "txn_count", "edge_type"]])
            except Exception:
                pass

        # Also include legacy relationship table if present
        if "relationship" in tables and tables["relationship"] is not None:
            try:
                rel = tables["relationship"]
                if "source_id" in rel.columns and "target_id" in rel.columns:
                    rel_edges = rel.rename(
                        columns={"source_id": "source", "target_id": "target", "strength": "weight"}
                    )
                    if "weight" not in rel_edges.columns:
                        rel_edges["weight"] = 1.0
                    rel_edges["edge_type"] = rel_edges.get("relationship_type", "relationship")
                    rel_edges["txn_count"] = 0
                    edges.append(
                        rel_edges[["source", "target", "weight", "txn_count", "edge_type"]]
                    )
            except Exception:
                pass

        # v15.7: SHARED INFRASTRUCTURE EDGES — Hidden Connections
        # Business rationale: Two entities sharing the same Device ID, Phone number,
        # IP Address, or physical Address are statistically co-dependent. In the absence
        # of any transaction between them, this shared infrastructure is the ONLY signal
        # that they are related parties. This is one of the top-3 indicators used by
        # financial crime investigators to connect shell companies and mules.
        # These edges are NOT in the transaction graph — they are invisible without this step.
        # Implementation: for each attribute value shared by 2+ nodes, create undirected
        # edges between every pair. Cap at max_pairs=50 per attribute value to prevent
        # a single shared IP (e.g. corporate Wi-Fi) from creating thousands of edges.
        # Only meaningful attribute types: Device_ID, Phone, IP_Address, Address.
        if "shared_attribute" in tables and tables["shared_attribute"] is not None:
            try:
                sa = tables["shared_attribute"].copy()
                _SA_MEANINGFUL = {"Device_ID", "Phone", "IP_Address", "Address"}
                nid_col = "node_id" if "node_id" in sa.columns else "customer_id"
                atype_col = "attribute_type" if "attribute_type" in sa.columns else None
                aval_col = "attribute_value" if "attribute_value" in sa.columns else None
                if nid_col in sa.columns and atype_col and aval_col:
                    sa[nid_col] = sa[nid_col].astype(str)
                    sa_filt = sa[sa[atype_col].isin(_SA_MEANINGFUL)].copy()
                    if len(sa_filt) > 0:
                        grp = sa_filt.groupby([atype_col, aval_col])[nid_col].apply(list)
                        sim_rows = []
                        _MAX_PAIRS = 50  # cap: prevents corporate-WiFi false signal
                        for (attr_type, _attr_val), node_list in grp.items():
                            node_list = list(set(node_list))  # deduplicate
                            if len(node_list) < 2:
                                continue
                            _etype = "shared_" + attr_type.lower().replace(" ", "_")
                            pair_count = 0
                            for i in range(len(node_list)):
                                for j in range(i + 1, len(node_list)):
                                    sim_rows.append(
                                        {
                                            "source": node_list[i],
                                            "target": node_list[j],
                                            "weight": 1.0,
                                            "txn_count": 0,
                                            "edge_type": _etype,
                                        }
                                    )
                                    pair_count += 1
                                    if pair_count >= _MAX_PAIRS:
                                        break
                                if pair_count >= _MAX_PAIRS:
                                    break
                        if sim_rows:
                            sim_df = pd.DataFrame(sim_rows)
                            edges.append(sim_df)
                            log_audit(
                                "SHARED_INFRA_EDGES",
                                f"{len(sim_rows)} hidden-connection edges built "
                                f"from shared_attribute table",
                            )
            except Exception:
                pass

        if edges:
            try:
                all_edges = pd.concat(edges, ignore_index=True)
                all_edges = all_edges[all_edges["source"] != all_edges["target"]]
                return all_edges
            except Exception:
                pass

        return pd.DataFrame(columns=["source", "target", "weight", "txn_count", "edge_type"])

    def run(self, tables: Dict[str, pd.DataFrame]) -> Tuple[pd.DataFrame, pd.DataFrame]:
        log_audit("AGGREGATE_START", f"Aggregating {len(tables)} tables")

        self._build_account_map(tables)
        self.customer_features = self._aggregate_customer_features(tables)
        self.edges = self._extract_edges(tables)

        try:
            store_or_load("stage2_customer_features", self.customer_features)
            store_or_load("stage2_edges", self.edges)
        except Exception:
            pass  # v9: never crash on persistence

        log_audit(
            "AGGREGATE_COMPLETE",
            f"Customers: {len(self.customer_features)}, Edges: {len(self.edges)}",
        )
        return self.customer_features, self.edges

    def _build_account_map(self, tables: Dict[str, pd.DataFrame]):
        if "account" in tables and tables["account"] is not None:
            acct_df = tables["account"]
            if "account_id" in acct_df.columns and "customer_id" in acct_df.columns:
                try:
                    self.account_map = dict(
                        zip(acct_df["account_id"].astype(str), acct_df["customer_id"].astype(str))
                    )
                except Exception:
                    pass

    def _aggregate_customer_features(self, tables: Dict[str, pd.DataFrame]) -> pd.DataFrame:
        # Start with customer base
        if "customer" in tables and tables["customer"] is not None and len(tables["customer"]) > 0:
            base = tables["customer"].copy()
        else:
            # Infer customer list from any table that has customer_id
            all_custs = set()
            for name, df in tables.items():
                if df is not None and "customer_id" in df.columns:
                    all_custs.update(df["customer_id"].dropna().unique())
            if not all_custs:
                return pd.DataFrame({"customer_id": []})
            base = pd.DataFrame({"customer_id": list(all_custs)})

        cid = PIPELINE.CUSTOMER_ID_COL

        # v9: Ensure cid column exists
        if cid not in base.columns:
            return base

        # Merge KYC features (v9: skip if missing columns)
        if "kyc" in tables and tables["kyc"] is not None and len(tables["kyc"]) > 0:
            try:
                kyc = tables["kyc"]
                if cid in kyc.columns:
                    kyc_cols = [c for c in kyc.columns if c != cid]
                    kyc_dedup = kyc.drop_duplicates(subset=[cid], keep="last")
                    base = base.merge(kyc_dedup[[cid] + kyc_cols], on=cid, how="left")
            except Exception:
                pass

        # Aggregate transaction features (v9: check every column before using)
        if (
            "transaction" in tables
            and tables["transaction"] is not None
            and len(tables["transaction"]) > 0
        ):
            try:
                txn = tables["transaction"]
                if cid in txn.columns:
                    agg_dict = {}
                    # Count transactions
                    first_col = txn.columns[0]
                    agg_dict["txn_count"] = (first_col, "count")

                    if PIPELINE.AMOUNT_COL in txn.columns:
                        agg_dict["txn_total_amount"] = (PIPELINE.AMOUNT_COL, "sum")
                        agg_dict["txn_avg_amount"] = (PIPELINE.AMOUNT_COL, "mean")
                        agg_dict["txn_max_amount"] = (PIPELINE.AMOUNT_COL, "max")
                        agg_dict["txn_std_amount"] = (PIPELINE.AMOUNT_COL, "std")

                    txn_agg = txn.groupby(cid).agg(**agg_dict).reset_index()
                    if "txn_std_amount" in txn_agg.columns:
                        txn_agg["txn_std_amount"] = txn_agg["txn_std_amount"].fillna(0)

                    # Count unique counterparties (v9: only if column exists)
                    if "counterparty_id" in txn.columns:
                        try:
                            cp_count = txn.groupby(cid)["counterparty_id"].nunique().reset_index()
                            cp_count.columns = [cid, "unique_counterparties"]
                            txn_agg = txn_agg.merge(cp_count, on=cid, how="left")
                        except Exception:
                            pass

                    # Count international txns (v9: only if column exists)
                    if "is_international" in txn.columns:
                        try:
                            intl = txn.groupby(cid)["is_international"].sum().reset_index()
                            intl.columns = [cid, "intl_txn_count"]
                            txn_agg = txn_agg.merge(intl, on=cid, how="left")
                        except Exception:
                            pass

                    base = base.merge(txn_agg, on=cid, how="left")
            except Exception:
                pass

        # Aggregate alert features (v9: defensive)
        if "alert" in tables and tables["alert"] is not None and len(tables["alert"]) > 0:
            try:
                alerts = tables["alert"]
                if cid in alerts.columns:
                    first_col = alerts.columns[0]
                    alert_agg = (
                        alerts.groupby(cid).agg(alert_count=(first_col, "count")).reset_index()
                    )
                    if "severity" in alerts.columns:
                        try:
                            sev = (
                                alerts.groupby(cid)["severity"]
                                .apply(lambda x: (x.isin(["high", "critical"])).sum())
                                .reset_index()
                            )
                            sev.columns = [cid, "high_severity_alerts"]
                            alert_agg = alert_agg.merge(sev, on=cid, how="left")
                        except Exception:
                            pass
                    base = base.merge(alert_agg, on=cid, how="left")
            except Exception:
                pass

        # Aggregate historical features (v9: defensive)
        if (
            "historical" in tables
            and tables["historical"] is not None
            and len(tables["historical"]) > 0
        ):
            try:
                hist = tables["historical"]
                if cid in hist.columns:
                    first_col = hist.columns[0]
                    hist_agg = (
                        hist.groupby(cid).agg(historical_events=(first_col, "count")).reset_index()
                    )
                    if "outcome" in hist.columns:
                        try:
                            tp = (
                                hist.groupby(cid)["outcome"]
                                .apply(lambda x: (x == "TP").sum())
                                .reset_index()
                            )
                            tp.columns = [cid, "true_positive_history"]
                            hist_agg = hist_agg.merge(tp, on=cid, how="left")
                        except Exception:
                            pass
                    base = base.merge(hist_agg, on=cid, how="left")
            except Exception:
                pass

        # Fill NaN aggregates with 0
        try:
            numeric_cols = base.select_dtypes(include=[np.number]).columns
            base[numeric_cols] = base[numeric_cols].fillna(0)
        except Exception:
            pass

        log_data_transform(
            "CUSTOMER_AGGREGATE",
            (
                sum(len(df) for df in tables.values() if df is not None),
                sum(len(df.columns) for df in tables.values() if df is not None),
            ),
            base.shape,
        )
        return base

    def _extract_edges(self, tables: Dict[str, pd.DataFrame]) -> pd.DataFrame:
        edges = []
        cid = PIPELINE.CUSTOMER_ID_COL

        # Transaction edges (v9: check every column)
        if (
            "transaction" in tables
            and tables["transaction"] is not None
            and len(tables["transaction"]) > 0
        ):
            try:
                txn = tables["transaction"]
                if cid in txn.columns and "counterparty_id" in txn.columns:
                    amount_col = PIPELINE.AMOUNT_COL if PIPELINE.AMOUNT_COL in txn.columns else None
                    if amount_col:
                        txn_edges = (
                            txn.groupby([cid, "counterparty_id"])
                            .agg(
                                weight=(amount_col, "sum"),
                                txn_count=(amount_col, "count"),
                            )
                            .reset_index()
                        )
                    else:
                        txn_edges = (
                            txn.groupby([cid, "counterparty_id"]).size().reset_index(name="weight")
                        )
                        txn_edges["txn_count"] = txn_edges["weight"]

                    txn_edges = txn_edges.rename(
                        columns={cid: "source", "counterparty_id": "target"}
                    )
                    txn_edges["edge_type"] = "transaction"
                    edges.append(txn_edges)
            except Exception:
                pass

        # Relationship edges (v9: defensive)
        if (
            "relationship" in tables
            and tables["relationship"] is not None
            and len(tables["relationship"]) > 0
        ):
            try:
                rel = tables["relationship"]
                if "source_id" in rel.columns and "target_id" in rel.columns:
                    rel_edges = rel.rename(
                        columns={"source_id": "source", "target_id": "target", "strength": "weight"}
                    )
                    if "weight" not in rel_edges.columns:
                        rel_edges["weight"] = 1.0
                    rel_edges["edge_type"] = rel_edges.get("relationship_type", "relationship")
                    rel_edges["txn_count"] = 0
                    edges.append(
                        rel_edges[["source", "target", "weight", "txn_count", "edge_type"]]
                    )
            except Exception:
                pass

        if edges:
            try:
                all_edges = pd.concat(edges, ignore_index=True)
                all_edges = all_edges[all_edges["source"] != all_edges["target"]]
                log_audit("AGGREGATE_EDGES", f"{len(all_edges)} edges extracted")
                return all_edges
            except Exception:
                pass

        return pd.DataFrame(columns=["source", "target", "weight", "txn_count", "edge_type"])

    def get_summary(self) -> Dict:
        return {
            "customers": len(self.customer_features) if self.customer_features is not None else 0,
            "edges": len(self.edges) if self.edges is not None else 0,
            "features": (
                len(self.customer_features.columns) if self.customer_features is not None else 0
            ),
            "account_map_size": len(self.account_map),
        }
