"""
FCDAI v12.4 - Reports Page
============================
R2: Narrative Report Templates (Money Laundering Activity, Customer Risk, Network Investigation)
R3: Trend Dashboard (risk score trends across runs)
R4: Executive Summary (KPI snapshot for management)
"""

import dash
from dash import html, dcc, callback, clientside_callback, Input, Output, State, no_update
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.graph_objects as go
import pandas as pd
from pathlib import Path
from datetime import datetime
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, PATHS, APP
from engine import get_pipeline
from utils.pii_guard import mask_value, mask_for_export
from utils.logger import GlobalExceptionHandler, log_audit

dash.register_page(
    __name__, path="/reports", name="Reports", title=f"FCDAI v{APP.VERSION} | Reports"
)

_GLASS = {
    "background": THEME.GLASS_BG,
    "backdropFilter": "blur(20px)",
    "border": f"1px solid {THEME.GLASS_BORDER}",
    "borderRadius": "12px",
    "padding": "1.25rem",
}

NARRATIVE_TEMPLATES = {
    "suspicious_activity": {
        "title": "Money Laundering Narrative",
        "icon": "mdi:alert-circle",
        "color": "#FF1744",
        "description": "Formal narrative documenting suspicious transaction patterns for regulatory review.",
        "sections": [
            "Subject Information",
            "Activity Description",
            "Risk Indicators",
            "Recommended Action",
        ],
    },
    "customer_risk": {
        "title": "Customer Risk Narrative",
        "icon": "mdi:account-alert",
        "color": "#FF6B6B",
        "description": "Comprehensive risk assessment narrative for a specific customer.",
        "sections": [
            "Customer Profile",
            "Risk Score Analysis",
            "Pattern Analysis",
            "Compliance Notes",
        ],
    },
    "network_investigation": {
        "title": "Network Investigation Narrative",
        "icon": "mdi:graph",
        "color": "#9D4EDD",
        "description": "Network-level investigation narrative covering connected entities and flows.",
        "sections": [
            "Network Overview",
            "Key Entities",
            "Transaction Flows",
            "Findings & Conclusions",
        ],
    },
}


def _section_header(icon, title, subtitle=""):
    return html.Div(
        [
            html.Div(
                [
                    DashIconify(icon=icon, width=24, color=THEME.PRIMARY),
                    html.H3(
                        title,
                        style={
                            "margin": 0,
                            "color": THEME.TEXT_PRIMARY,
                            "fontSize": "1.1rem",
                            "fontWeight": "700",
                        },
                    ),
                ],
                style={"display": "flex", "alignItems": "center", "gap": "0.6rem"},
            ),
            html.P(
                subtitle,
                style={
                    "margin": "0.25rem 0 0 2rem",
                    "color": THEME.TEXT_MUTED,
                    "fontSize": "0.8rem",
                },
            ),
        ],
        style={"marginBottom": "1rem"},
    )


# ─── Layout ───────────────────────────────────────────────────────────────────

layout = html.Div(
    [
        dcc.Interval(id="reports-init", interval=500, max_intervals=1),
        dcc.Download(id="reports-download"),
        # Header
        html.Div(
            [
                html.Div(
                    [
                        DashIconify(icon="mdi:file-chart", width=36, color=THEME.PRIMARY),
                        html.Div(
                            [
                                html.H1(
                                    "Reports",
                                    style={
                                        "margin": 0,
                                        "fontSize": "1.8rem",
                                        "fontWeight": "800",
                                        "background": f"linear-gradient(135deg, {THEME.PRIMARY}, {THEME.SECONDARY})",
                                        "WebkitBackgroundClip": "text",
                                        "WebkitTextFillColor": "transparent",
                                    },
                                ),
                                html.P(
                                    "Narrative Templates · Trend Analysis · Executive Summary",
                                    style={
                                        "margin": 0,
                                        "color": THEME.TEXT_MUTED,
                                        "fontSize": "0.8rem",
                                    },
                                ),
                            ]
                        ),
                    ],
                    style={"display": "flex", "alignItems": "center", "gap": "1rem"},
                ),
            ],
            style={
                "display": "flex",
                "justifyContent": "space-between",
                "alignItems": "center",
                "marginBottom": "1.5rem",
            },
        ),
        # ── CEO Context Panel ─────────────────────────────────────────────────────
        html.Div(
            [
                html.Div(
                    [
                        html.Div(
                            [
                                DashIconify(
                                    icon="mdi:information-outline", width=18, color="#FF6B6B"
                                ),
                                html.Span(
                                    "What is the Reports Centre?",
                                    style={
                                        "color": "#FF6B6B",
                                        "fontWeight": "700",
                                        "fontSize": "0.85rem",
                                        "marginLeft": "0.4rem",
                                    },
                                ),
                            ],
                            style={
                                "display": "flex",
                                "alignItems": "center",
                                "marginBottom": "0.75rem",
                            },
                        ),
                        dmc.SimpleGrid(
                            cols=3,
                            spacing="md",
                            children=[
                                html.Div(
                                    [
                                        html.Div(
                                            "📋 Overview",
                                            style={
                                                "color": "#FF6B6B",
                                                "fontWeight": "700",
                                                "fontSize": "0.78rem",
                                                "marginBottom": "0.35rem",
                                            },
                                        ),
                                        html.P(
                                            "Your compliance reporting hub. This page generates three types of output: "
                                            "(1) Board-ready Executive Summaries with key risk KPIs, "
                                            "(2) Trend Analysis showing how portfolio risk is moving over time, and "
                                            "(3) Regulatory Narrative templates for Narratives and customer risk files.",
                                            style={
                                                "color": "rgba(255,255,255,0.75)",
                                                "fontSize": "0.78rem",
                                                "margin": 0,
                                                "lineHeight": "1.5",
                                            },
                                        ),
                                    ]
                                ),
                                html.Div(
                                    [
                                        html.Div(
                                            "💡 Why It Matters",
                                            style={
                                                "color": "#FFD600",
                                                "fontWeight": "700",
                                                "fontSize": "0.78rem",
                                                "marginBottom": "0.35rem",
                                            },
                                        ),
                                        html.P(
                                            "The Executive Summary translates complex risk scores into plain-language "
                                            "KPIs that a CEO or Board can act on without technical knowledge. "
                                            "Trend Analysis shows whether the overall portfolio risk is increasing or "
                                            "decreasing, which is a critical management and regulatory metric.",
                                            style={
                                                "color": "rgba(255,255,255,0.75)",
                                                "fontSize": "0.78rem",
                                                "margin": 0,
                                                "lineHeight": "1.5",
                                            },
                                        ),
                                    ]
                                ),
                                html.Div(
                                    [
                                        html.Div(
                                            "⚡ When to Act",
                                            style={
                                                "color": "#FF6B6B",
                                                "fontWeight": "700",
                                                "fontSize": "0.78rem",
                                                "marginBottom": "0.35rem",
                                            },
                                        ),
                                        html.P(
                                            "Generate an Executive Summary before every board meeting or senior management "
                                            "review. Run a Narrative Report for every customer who triggers a Narrative decision. "
                                            "If the Trend Analysis shows P1 customers increasing by more than 10% between "
                                            "runs, brief the MLRO immediately.",
                                            style={
                                                "color": "rgba(255,255,255,0.75)",
                                                "fontSize": "0.78rem",
                                                "margin": 0,
                                                "lineHeight": "1.5",
                                            },
                                        ),
                                    ]
                                ),
                            ],
                        ),
                        html.Div(
                            [
                                html.Span("⚫ ", style={"color": "#00E676", "fontSize": "0.65rem"}),
                                html.Span(
                                    "LIVE — Auto-updates with every pipeline run",
                                    style={
                                        "color": "#00E676",
                                        "fontSize": "0.72rem",
                                        "fontWeight": "600",
                                    },
                                ),
                            ],
                            style={
                                "marginTop": "0.75rem",
                                "display": "flex",
                                "alignItems": "center",
                                "gap": "0.25rem",
                            },
                        ),
                    ]
                ),
            ],
            style={
                "background": "rgba(255,107,107,0.04)",
                "border": "1px solid rgba(255,107,107,0.2)",
                "borderLeft": "4px solid #FF6B6B",
                "borderRadius": "10px",
                "padding": "1rem 1.25rem",
                "marginBottom": "1.5rem",
            },
        ),
        # ── R4: Executive Summary ─────────────────────────────────────────────────
        html.Div(
            [
                _section_header(
                    "mdi:view-dashboard",
                    "Executive Summary",
                    "Management-level KPI snapshot — no technical details",
                ),
                html.Div(id="reports-executive-summary"),
                html.Div(
                    [
                        dmc.Button(
                            "Export Executive Summary PDF",
                            id="exec-pdf-btn",
                            size="sm",
                            leftSection=DashIconify(icon="mdi:file-pdf-box", width=16),
                            style={
                                "background": "rgba(0,212,255,0.1)",
                                "border": "1px solid rgba(0,212,255,0.3)",
                                "color": "#00D4FF",
                                "marginTop": "1rem",
                            },
                        ),
                    ]
                ),
            ],
            style={**_GLASS, "marginBottom": "1rem"},
        ),
        # ── R3: Trend Dashboard ───────────────────────────────────────────────────
        html.Div(
            [
                _section_header(
                    "mdi:trending-up",
                    "Risk Trend Analysis",
                    "Risk score and tier distribution trends across pipeline runs",
                ),
                dmc.SimpleGrid(
                    cols=2,
                    spacing="md",
                    children=[
                        dcc.Graph(
                            id="reports-trend-score",
                            config={"displayModeBar": False},
                            style={"height": "240px"},
                        ),
                        dcc.Graph(
                            id="reports-trend-tiers",
                            config={"displayModeBar": False},
                            style={"height": "240px"},
                        ),
                    ],
                ),
                html.Div(id="reports-trend-arrow", style={"marginTop": "0.75rem"}),
            ],
            style={**_GLASS, "marginBottom": "1rem"},
        ),
        # ── R2: Narrative Templates ───────────────────────────────────────────────
        html.Div(
            [
                _section_header(
                    "mdi:file-document-edit",
                    "Narrative Report Templates",
                    "Generate structured investigation narratives for regulatory review",
                ),
                dmc.Tabs(
                    value="suspicious_activity",
                    children=[
                        dmc.TabsList(
                            [
                                dmc.TabsTab(
                                    "Money Laundering Activity",
                                    value="suspicious_activity",
                                    leftSection=DashIconify(icon="mdi:alert-circle", width=16),
                                ),
                                dmc.TabsTab(
                                    "Customer Risk",
                                    value="customer_risk",
                                    leftSection=DashIconify(icon="mdi:account-alert", width=16),
                                ),
                                dmc.TabsTab(
                                    "Network Investigation",
                                    value="network_investigation",
                                    leftSection=DashIconify(icon="mdi:graph", width=16),
                                ),
                            ]
                        ),
                        *[
                            dmc.TabsPanel(
                                html.Div(
                                    [
                                        html.P(
                                            tmpl["description"],
                                            style={
                                                "color": THEME.TEXT_MUTED,
                                                "fontSize": "0.85rem",
                                                "marginBottom": "1rem",
                                            },
                                        ),
                                        dmc.Select(
                                            id=f"report-node-{key}",
                                            placeholder="Select customer for this report...",
                                            searchable=True,
                                            data=[],
                                            style={"marginBottom": "1rem"},
                                            styles={
                                                "input": {
                                                    "background": "rgba(255,255,255,0.05)",
                                                    "border": "1px solid rgba(255,255,255,0.1)",
                                                    "color": "#E2E8F0",
                                                }
                                            },
                                        ),
                                        # Narrative preview
                                        html.Div(
                                            id=f"report-preview-{key}",
                                            style={"marginBottom": "1rem"},
                                        ),
                                        dmc.Button(
                                            f"Generate {tmpl['title']} PDF",
                                            id=f"report-pdf-{key}",
                                            size="sm",
                                            leftSection=DashIconify(
                                                icon="mdi:file-pdf-box", width=16
                                            ),
                                            style={
                                                "background": f"rgba(255,255,255,0.05)",
                                                "border": f"1px solid {tmpl['color']}44",
                                                "color": tmpl["color"],
                                            },
                                        ),
                                    ]
                                ),
                                value=key,
                                style={"paddingTop": "1rem"},
                            )
                            for key, tmpl in NARRATIVE_TEMPLATES.items()
                        ],
                    ],
                ),
            ],
            style=_GLASS,
        ),
    ],
    style={
        "padding": "1.5rem",
        "fontFamily": "'Inter', sans-serif",
        "background": THEME.DARK_BG,
        "minHeight": "100vh",
        "color": THEME.TEXT_PRIMARY,
    },
)


# ─── Callbacks ────────────────────────────────────────────────────────────────


@callback(
    Output("reports-executive-summary", "children"),
    Output("reports-trend-score", "figure"),
    Output("reports-trend-tiers", "figure"),
    Output("reports-trend-arrow", "children"),
    Input("reports-init", "n_intervals"),
    Input("pipeline-state", "data"),
    Input("global-refresh-ts", "data"),
)
@GlobalExceptionHandler.wrap()
def load_reports(_init, _pipeline_state, _gr):
    pipeline = get_pipeline()
    scored_df = pipeline.get_scored_df()

    # get_run_history() returns a DataFrame, NOT a list of dicts
    try:
        run_history_df = (
            pipeline.get_run_history() if hasattr(pipeline, "get_run_history") else pd.DataFrame()
        )
    except Exception:
        run_history_df = pd.DataFrame()

    # ── Executive Summary ─────────────────────────────────────────────────────
    if scored_df is not None and not scored_df.empty:
        total = len(scored_df)
        p1_count = (
            len(scored_df[scored_df.get("risk_tier", pd.Series()) == "P1"])
            if "risk_tier" in scored_df.columns
            else 0
        )
        avg_score = (
            float(scored_df["risk_score"].mean()) if "risk_score" in scored_df.columns else 0
        )
        top_tier = (
            scored_df["risk_tier"].value_counts().index[0]
            if "risk_tier" in scored_df.columns and len(scored_df) > 0
            else "N/A"
        )

        # v12.43: Keep top-level 4-KPI strip AND add 3-tab deep-dive below
        exec_summary = html.Div(
            [
                dmc.SimpleGrid(
                    cols=4,
                    spacing="md",
                    mb="sm",
                    children=[
                        _exec_kpi(
                            "Total Customers Analysed", str(total), "mdi:account-group", "#00D4FF"
                        ),
                        _exec_kpi("Priority 1 Alerts", str(p1_count), "mdi:alert", "#FF1744"),
                        _exec_kpi("Average Risk Score", f"{avg_score:.1f}", "mdi:gauge", "#FFD600"),
                        _exec_kpi("Dominant Tier", top_tier, "mdi:podium", "#9D4EDD"),
                    ],
                ),
                _build_executive_tabs(pipeline, scored_df),
            ]
        )
    else:
        exec_summary = dmc.Alert(
            "Run the pipeline to generate executive summary.", color="blue", variant="light"
        )

    # ── Trend Charts (v12.4 fix: use DataFrame columns, compute scored stats per run) ──
    if (
        run_history_df is not None
        and isinstance(run_history_df, pd.DataFrame)
        and len(run_history_df) > 1
    ):
        # Build trend data by loading scored results for each historical run
        from database import get_db

        db = get_db()
        trend_data = []
        for _, rrow in run_history_df.tail(10).iterrows():
            rid = int(rrow["run_id"])
            run_scored = db.get_run_scored(rid)
            entry = {"run_id": rid}
            if run_scored is not None and not run_scored.empty:
                entry["avg_risk_score"] = (
                    float(run_scored["risk_score"].mean())
                    if "risk_score" in run_scored.columns
                    else 0
                )
                if "risk_tier" in run_scored.columns:
                    vc = run_scored["risk_tier"].value_counts()
                    entry["p1_count"] = int(vc.get("P1", 0))
                    entry["p2_count"] = int(vc.get("P2", 0))
                    entry["p3_count"] = int(vc.get("P3", 0))
                    entry["p4_count"] = int(vc.get("P4", 0))
                else:
                    entry.update({"p1_count": 0, "p2_count": 0, "p3_count": 0, "p4_count": 0})
            else:
                entry.update(
                    {
                        "avg_risk_score": 0,
                        "p1_count": 0,
                        "p2_count": 0,
                        "p3_count": 0,
                        "p4_count": 0,
                    }
                )
            trend_data.append(entry)

        run_labels = [f"Run {r['run_id']}" for r in trend_data]
        avg_scores = [r["avg_risk_score"] for r in trend_data]
        p1_counts = [r["p1_count"] for r in trend_data]
        p2_counts = [r["p2_count"] for r in trend_data]
        p3_counts = [r["p3_count"] for r in trend_data]
        p4_counts = [r["p4_count"] for r in trend_data]

        fig_score = go.Figure(
            go.Scatter(
                x=run_labels,
                y=avg_scores,
                mode="lines+markers",
                line=dict(color="#00D4FF", width=2),
                marker=dict(size=8, color="#00D4FF"),
                fill="tozeroy",
                fillcolor="rgba(0,212,255,0.1)",
            )
        )
        fig_score.update_layout(**_chart_layout("Average Risk Score Trend"))

        fig_tiers = go.Figure(
            [
                go.Bar(name="P1", x=run_labels, y=p1_counts, marker_color="#FF1744"),
                go.Bar(name="P2", x=run_labels, y=p2_counts, marker_color="#FF6B6B"),
                go.Bar(name="P3", x=run_labels, y=p3_counts, marker_color="#FFD600"),
                go.Bar(name="P4", x=run_labels, y=p4_counts, marker_color="#00E676"),
            ]
        )
        fig_tiers.update_layout(barmode="stack", **_chart_layout("Tier Distribution per Run"))

        # Trend arrow
        if len(avg_scores) >= 2:
            delta = avg_scores[-1] - avg_scores[-2]
            if delta > 1:
                arrow = dmc.Alert(
                    f"Risk trending UP by {delta:.1f} points since last run. Review P1 alerts.",
                    color="red",
                    title="Trend: INCREASING RISK",
                    icon=DashIconify(icon="mdi:trending-up", width=20),
                )
            elif delta < -1:
                arrow = dmc.Alert(
                    f"Risk trending DOWN by {abs(delta):.1f} points since last run.",
                    color="green",
                    title="Trend: DECREASING RISK",
                    icon=DashIconify(icon="mdi:trending-down", width=20),
                )
            else:
                arrow = dmc.Alert(
                    "Risk score is stable across recent runs.",
                    color="blue",
                    title="Trend: STABLE",
                    icon=DashIconify(icon="mdi:trending-neutral", width=20),
                )
        else:
            arrow = html.Div()
    else:
        fig_score = _empty_chart("Run pipeline multiple times to see trend")
        fig_tiers = _empty_chart("Run pipeline multiple times to see tier trends")
        arrow = dmc.Alert(
            "Run the pipeline at least twice to see trend analysis.", color="blue", variant="light"
        )

    return exec_summary, fig_score, fig_tiers, arrow


def _exec_kpi(label, value, icon, color):
    return html.Div(
        [
            html.Div(
                [
                    DashIconify(icon=icon, width=28, color=color),
                    html.Div(
                        value,
                        style={
                            "fontSize": "1.8rem",
                            "fontWeight": "800",
                            "color": color,
                            "marginLeft": "0.5rem",
                        },
                    ),
                ],
                style={"display": "flex", "alignItems": "center", "marginBottom": "0.4rem"},
            ),
            html.Div(label, style={"color": THEME.TEXT_MUTED, "fontSize": "0.8rem"}),
        ],
        style={
            "background": f"rgba(0,0,0,0.3)",
            "border": f"1px solid {color}22",
            "borderRadius": "8px",
            "padding": "1rem",
        },
    )


# ─── v12.43: Enhanced Executive Summary helpers ───────────────────────────────


def _exec_kpi_v2(label, value, icon, color, sub=""):
    """Compact KPI card with sub-label for the deep-dive tabs."""
    return dmc.Paper(
        [
            dmc.Group(
                [
                    DashIconify(icon=icon, width=22, color=color),
                    dmc.Stack(
                        [
                            dmc.Text(value, size="lg", fw=800, c=color),
                            dmc.Text(label, size="10px", c="dimmed"),
                        ],
                        gap=0,
                    ),
                ],
                gap="xs",
            ),
            dmc.Text(sub, size="10px", c="rgba(255,255,255,0.3)", mt=4) if sub else html.Span(),
        ],
        p="sm",
        radius="md",
        style={"backgroundColor": "rgba(0,0,0,0.3)", "border": f"1px solid {color}22"},
    )


def _tier_bar(label, count, pct, color):
    """Horizontal tier bar with label + count + percentage."""
    return html.Div(
        [
            dmc.Group(
                [
                    dmc.Text(
                        label, size="xs", c="dimmed", style={"minWidth": "220px", "flexShrink": 0}
                    ),
                    dmc.Text(
                        f"{count:,}",
                        size="xs",
                        fw=700,
                        c=color,
                        style={"minWidth": "50px", "textAlign": "right"},
                    ),
                    dmc.Text(f"({pct:.1f}%)", size="10px", c="dimmed"),
                ],
                gap="xs",
                mb=4,
            ),
            html.Div(
                html.Div(
                    style={
                        "width": f"{pct:.1f}%",
                        "height": "5px",
                        "backgroundColor": color,
                        "borderRadius": "3px",
                    }
                ),
                style={
                    "width": "100%",
                    "height": "5px",
                    "backgroundColor": "rgba(255,255,255,0.06)",
                    "borderRadius": "3px",
                    "marginBottom": "10px",
                },
            ),
        ]
    )


def _build_executive_tabs(pipeline, scored_df):
    """
    v12.43: Build the 3-tab deep-dive executive summary.
    Returns a dmc.Tabs component (Portfolio Risk | Network Intelligence |
    Priority Action Register) populated entirely from live pipeline data.
    """
    # ── Guard ────────────────────────────────────────────────────────────────
    if scored_df is None or scored_df.empty:
        return html.Div()

    total = len(scored_df)
    meta = pipeline.last_run_meta or {}
    run_id = meta.get("run_id", "?")
    saved_at = meta.get("saved_at", "")
    try:
        saved_at_str = datetime.fromisoformat(str(saved_at)).strftime("%d %b %Y %H:%M")
    except Exception:
        saved_at_str = str(saved_at) or "Unknown"

    # ── Column detection ─────────────────────────────────────────────────────
    score_col = next(
        (c for c in scored_df.columns if c in ("risk_score", "score", "composite_score")), None
    )
    if score_col is None:
        score_col = next((c for c in scored_df.columns if "score" in c.lower()), None)
    tier_col = next((c for c in scored_df.columns if "tier" in c.lower()), None)

    # ── Tier counts ──────────────────────────────────────────────────────────
    p1 = p2 = p3 = p4 = 0
    avg_score = max_score = 0.0
    if tier_col:
        vc = scored_df[tier_col].value_counts()
        p1, p2, p3, p4 = (
            int(vc.get("P1", 0)),
            int(vc.get("P2", 0)),
            int(vc.get("P3", 0)),
            int(vc.get("P4", 0)),
        )
    elif score_col:
        # v14.7 FIX-GAP1: quantile-based fallback (percentile-consistent with tier algorithm).
        # Hardcoded 80/60/40 thresholds give wrong P1 counts after v14.5 post-propagation
        # calibration where scores are rank-normalised (top 1%=P1 by rank, not by score>=80).
        # With n>=20 use quantile split matching l6_scoring.py percentile boundaries.
        _s = scored_df[score_col]
        _n = len(_s)
        if _n >= 20:
            p1 = int((_s >= _s.quantile(0.99)).sum())
            p2 = int(((_s >= _s.quantile(0.95)) & (_s < _s.quantile(0.99))).sum())
            p3 = int(((_s >= _s.quantile(0.85)) & (_s < _s.quantile(0.95))).sum())
            p4 = int((_s < _s.quantile(0.85)).sum())
        else:
            # Very small datasets: keep absolute thresholds as best available estimate
            p1 = int((_s >= 80).sum())
            p2 = int(((_s >= 60) & (_s < 80)).sum())
            p3 = int(((_s >= 40) & (_s < 60)).sum())
            p4 = int((_s < 40).sum())
    if score_col:
        avg_score = float(scored_df[score_col].mean())
        max_score = float(scored_df[score_col].max())

    pct = lambda n: (n / total * 100) if total > 0 else 0
    risk_level = "ELEVATED" if avg_score >= 60 else "MODERATE" if avg_score >= 40 else "LOW"
    risk_color = (
        "#FF1744"
        if risk_level == "ELEVATED"
        else "#FF9800" if risk_level == "MODERATE" else "#00E676"
    )
    action_needed = p1 + p2

    # ═══════════════════════════════════════════════════════════════════════
    # TAB 1 — Portfolio Risk Summary
    # ═══════════════════════════════════════════════════════════════════════
    narrative = (
        f"As of {saved_at_str}, the AML detection engine completed analysis across "
        f"{total:,} customers. The portfolio is classified as {risk_level} RISK with "
        f"an average composite risk score of {avg_score:.1f}/100 (highest: {max_score:.1f}). "
        f"{p1:,} customer{'s require' if p1 != 1 else ' requires'} IMMEDIATE Narrative "
        f"filing (P1 Critical Risk), {p2:,} require Enhanced Due Diligence (P2 High Risk), "
        f"{p3:,} are under routine monitoring (P3 Medium), and {p4:,} are within "
        f"acceptable standard-risk parameters (P4 Low)."
    )
    mlro_action = (
        f"BRIEF MLRO IMMEDIATELY — {p1} P1 case{'s' if p1 != 1 else ''} require Narrative filing."
        if p1 > 0
        else (
            ("Schedule EDD for %d P2 case%s." % (p2, "s" if p2 != 1 else ""))
            if p2 > 0
            else "No immediate escalations required at this run."
        )
    )
    mlro_color = "#FF1744" if p1 > 0 else ("#FF9800" if p2 > 0 else "#00E676")

    portfolio_tab = html.Div(
        [
            dmc.SimpleGrid(
                cols={"base": 2, "md": 4},
                spacing="sm",
                mb="md",
                children=[
                    _exec_kpi_v2("Total Analysed", f"{total:,}", "mdi:account-group", "#00D4FF"),
                    _exec_kpi_v2(
                        "Immediate Action",
                        f"{p1:,}",
                        "mdi:alert-octagon",
                        "#FF1744",
                        "P1 → Narrative filing",
                    ),
                    _exec_kpi_v2(
                        "Due Diligence", f"{p2:,}", "mdi:alert", "#FF9800", "P2 → EDD required"
                    ),
                    _exec_kpi_v2(
                        "Avg Risk Score",
                        f"{avg_score:.1f}",
                        "mdi:gauge-full",
                        risk_color,
                        f"{risk_level} risk level",
                    ),
                ],
            ),
            dmc.Paper(
                [
                    dmc.Text("Portfolio Risk Breakdown", size="xs", fw=700, c="dimmed", mb="xs"),
                    _tier_bar("P1 Critical — Narrative Filing Required", p1, pct(p1), "#FF1744"),
                    _tier_bar("P2 High Risk — Enhanced Due Diligence", p2, pct(p2), "#FF9800"),
                    _tier_bar("P3 Medium — Routine Monitoring", p3, pct(p3), "#FFD600"),
                    _tier_bar("P4 Low — Standard Processing", p4, pct(p4), "#00E676"),
                ],
                p="sm",
                radius="md",
                mb="md",
                style={
                    "backgroundColor": "rgba(0,0,0,0.2)",
                    "border": "1px solid rgba(255,255,255,0.06)",
                },
            ),
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            DashIconify(icon="mdi:text-box-outline", width=16, color="#FFD600"),
                            dmc.Text("Portfolio Risk Narrative", size="xs", fw=700, c="#FFD600"),
                        ],
                        gap="xs",
                        mb="xs",
                    ),
                    dmc.Text(
                        narrative, size="xs", c="rgba(255,255,255,0.8)", style={"lineHeight": "1.7"}
                    ),
                    dmc.Text(
                        f"MLRO Action: {mlro_action}", size="xs", fw=700, c=mlro_color, mt="xs"
                    ),
                ],
                p="sm",
                radius="md",
                style={
                    "backgroundColor": "rgba(0,0,0,0.2)",
                    "border": f"1px solid {'rgba(255,23,68,0.3)' if p1 > 0 else 'rgba(0,230,118,0.2)'}",
                },
            ),
        ]
    )

    # ═══════════════════════════════════════════════════════════════════════
    # TAB 2 — Network & Behavioural Intelligence
    # ═══════════════════════════════════════════════════════════════════════
    G = pipeline.G
    analytics = (
        pipeline.get_analytics_results() if hasattr(pipeline, "get_analytics_results") else {}
    )
    analytics = analytics or {}

    nodes = G.number_of_nodes() if G else meta.get("graph_nodes", 0)
    edges = G.number_of_edges() if G else meta.get("graph_edges", 0)
    density = (2 * edges / (nodes * (nodes - 1))) if nodes > 1 else 0

    _FAMILY_META = {
        "centrality": ("Relationship Influence", "#00D4FF", "mdi:graph-outline"),
        "community": ("Risk Group Identification", "#9D4EDD", "mdi:account-group"),
        "pathflow": ("Money Flow Tracing", "#FF9800", "mdi:swap-horizontal"),
        "link_prediction": ("Hidden Link Discovery", "#00E5FF", "mdi:link-variant"),
        "anomaly": ("Behavioural Anomaly", "#FF1744", "mdi:alert-decagram"),
        "temporal": ("Time-Pattern Analysis", "#FFD600", "mdi:clock-fast"),
        "multi_layer": ("Cross-Entity Assessment", "#2196F3", "mdi:layers-triple"),
        "structuring": ("Structuring Detection", "#FF1744", "mdi:cash-multiple"),
        "benfords": ("Numeric Pattern Check", "#E040FB", "mdi:chart-bell-curve"),
        "motifs": ("Transaction Patterns", "#00BCD4", "mdi:shape-outline"),
    }
    family_cards = []
    active_families = 0
    for fkey, fdf in analytics.items():
        if fdf is None or len(fdf) == 0:
            continue
        active_families += 1
        disp, color, icon_n = _FAMILY_META.get(
            fkey, (fkey.replace("_", " ").title(), "#00D4FF", "mdi:chart-line")
        )
        score_c = next((c for c in fdf.columns if "score" in c.lower()), None)
        avg_f = float(fdf[score_c].mean()) if score_c else 0.0
        high_n = int((fdf[score_c] >= 60).sum()) if score_c else 0
        family_cards.append(
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            DashIconify(icon=icon_n, width=15, color=color),
                            dmc.Text(disp, size="xs", fw=700, c=color),
                        ],
                        gap="xs",
                        mb=4,
                    ),
                    dmc.Group(
                        [
                            dmc.Text(f"{len(fdf):,} customers scored", size="xs", c="dimmed"),
                            dmc.Badge(
                                f"{high_n} elevated",
                                color="red" if high_n > 0 else "gray",
                                variant="light",
                                size="xs",
                            ),
                        ],
                        justify="space-between",
                    ),
                ],
                p="xs",
                radius="sm",
                style={"backgroundColor": "rgba(0,0,0,0.25)", "border": f"1px solid {color}22"},
            )
        )

    # Find top 3 contributing families by average score
    family_scores = []
    for fkey, fdf in analytics.items():
        if fdf is None or len(fdf) == 0:
            continue
        sc = next((c for c in fdf.columns if "score" in c.lower()), None)
        if sc:
            family_scores.append((fkey, float(fdf[sc].mean())))
    family_scores.sort(key=lambda x: x[1], reverse=True)
    top_families_text = (
        (
            "Top contributing detection engines: "
            + ", ".join(_FAMILY_META.get(k, (k,))[0] for k, _ in family_scores[:3])
            + "."
        )
        if family_scores
        else ""
    )

    community_note = (
        "Community detection has identified distinct risk clusters — "
        "entities in a shared cluster have financial connections worth joint investigation. "
        if "community" in analytics and analytics.get("community") is not None
        else ""
    )
    struct_note = (
        "Structuring patterns (potential smurfing) detected by the Structuring engine. "
        if "structuring" in analytics
        and analytics.get("structuring") is not None
        and len(analytics.get("structuring", [])) > 0
        else ""
    )
    net_narrative = (
        f"The transaction network comprises {nodes:,} entities connected by {edges:,} "
        f"financial links (density: {density:.4f}). {community_note}"
        f"{struct_note}"
        f"{top_families_text} "
        f"{'All 10' if active_families == 10 else str(active_families)} behavioural analysis "
        f"families applied to derive the composite risk scores."
    )

    network_tab = html.Div(
        [
            dmc.SimpleGrid(
                cols={"base": 2, "md": 3},
                spacing="sm",
                mb="md",
                children=[
                    _exec_kpi_v2(
                        "Financial Entities",
                        f"{nodes:,}",
                        "mdi:graph",
                        "#00D4FF",
                        "nodes in network",
                    ),
                    _exec_kpi_v2(
                        "Financial Links",
                        f"{edges:,}",
                        "mdi:swap-horizontal",
                        "#FF9800",
                        "transaction connections",
                    ),
                    _exec_kpi_v2(
                        "Detection Engines",
                        f"{active_families}/10",
                        "mdi:robot-outline",
                        "#9D4EDD",
                        "families executed",
                    ),
                ],
            ),
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            DashIconify(icon="mdi:graph-outline", width=16, color="#00D4FF"),
                            dmc.Text(
                                "Network Intelligence Summary", size="xs", fw=700, c="#00D4FF"
                            ),
                        ],
                        gap="xs",
                        mb="xs",
                    ),
                    dmc.Text(
                        net_narrative,
                        size="xs",
                        c="rgba(255,255,255,0.8)",
                        style={"lineHeight": "1.7"},
                    ),
                ],
                p="sm",
                radius="md",
                mb="md",
                style={
                    "backgroundColor": "rgba(0,0,0,0.2)",
                    "border": "1px solid rgba(0,212,255,0.15)",
                },
            ),
            dmc.Text("Detection Engine Results", size="xs", fw=700, c="dimmed", mb="xs"),
            (
                dmc.SimpleGrid(cols={"base": 1, "md": 2}, spacing="sm", children=family_cards)
                if family_cards
                else dmc.Text("No analytics results available.", c="dimmed", size="xs")
            ),
        ]
    )

    # ═══════════════════════════════════════════════════════════════════════
    # TAB 3 — Priority Action Register
    # ═══════════════════════════════════════════════════════════════════════
    action_items = []

    if scored_df is not None and not scored_df.empty:

        def _case_card(row, tier, color, badge_label):
            nid = mask_value(str(row.get("node_id", "?")), "partial")
            sc = float(row.get(score_col, 0)) if score_col else 0.0
            act = (
                "File Narrative with MLRO within 24 hours. Freeze account if appropriate."
                if tier == "P1"
                else "Conduct Enhanced Due Diligence within 5 business days."
            )
            return dmc.Paper(
                [
                    dmc.Group(
                        [
                            DashIconify(icon="mdi:account-alert", width=14, color=color),
                            dmc.Text(f"CUSTOMER  {nid}", size="xs", fw=700, c=color),
                            dmc.Badge(
                                f"Score {sc:.0f}",
                                color="red" if tier == "P1" else "orange",
                                variant="filled",
                                size="xs",
                            ),
                            dmc.Badge(
                                badge_label, color="red" if tier == "P1" else "orange", size="xs"
                            ),
                        ],
                        gap="xs",
                    ),
                    dmc.Text(f"Required Action: {act}", size="10px", c="dimmed", mt=4),
                ],
                p="xs",
                radius="sm",
                style={
                    "backgroundColor": f"{'rgba(255,23,68,0.07)' if tier == 'P1' else 'rgba(255,152,0,0.07)'}",
                    "border": f"1px solid {'rgba(255,23,68,0.3)' if tier == 'P1' else 'rgba(255,152,0,0.3)'}",
                },
            )

        if tier_col:
            p1_rows_df = scored_df[scored_df[tier_col] == "P1"]
            p2_rows_df = scored_df[scored_df[tier_col] == "P2"]
            if score_col:
                p1_rows_df = p1_rows_df.nlargest(10, score_col)
                p2_rows_df = p2_rows_df.nlargest(5, score_col)

            if len(p1_rows_df) > 0:
                action_items.append(
                    dmc.Paper(
                        [
                            dmc.Group(
                                [
                                    DashIconify(
                                        icon="mdi:alert-octagon", width=18, color="#FF1744"
                                    ),
                                    dmc.Text(
                                        f"P1 Critical — {p1:,} cases requiring Narrative filing "
                                        f"(top {min(10, len(p1_rows_df))} shown by risk score)",
                                        fw=700,
                                        size="sm",
                                        c="#FF1744",
                                    ),
                                ],
                                gap="xs",
                                mb="xs",
                            ),
                            dmc.Stack(
                                [
                                    _case_card(r, "P1", "#FF1744", "FILE NARRATIVE")
                                    for _, r in p1_rows_df.iterrows()
                                ],
                                gap="xs",
                            ),
                        ],
                        p="sm",
                        radius="md",
                        mb="sm",
                        style={
                            "backgroundColor": "rgba(0,0,0,0.2)",
                            "border": "2px solid rgba(255,23,68,0.45)",
                        },
                    )
                )

            if len(p2_rows_df) > 0:
                action_items.append(
                    dmc.Paper(
                        [
                            dmc.Group(
                                [
                                    DashIconify(icon="mdi:alert", width=18, color="#FF9800"),
                                    dmc.Text(
                                        f"P2 High Risk — {p2:,} cases requiring EDD "
                                        f"(top {min(5, len(p2_rows_df))} shown by risk score)",
                                        fw=700,
                                        size="sm",
                                        c="#FF9800",
                                    ),
                                ],
                                gap="xs",
                                mb="xs",
                            ),
                            dmc.Stack(
                                [
                                    _case_card(r, "P2", "#FF9800", "EDD REQUIRED")
                                    for _, r in p2_rows_df.iterrows()
                                ],
                                gap="xs",
                            ),
                        ],
                        p="sm",
                        radius="md",
                        mb="sm",
                        style={
                            "backgroundColor": "rgba(0,0,0,0.2)",
                            "border": "1px solid rgba(255,152,0,0.4)",
                        },
                    )
                )

    checklist_defs = [
        (
            p1 > 0,
            f"File {p1} Narrative report{'s' if p1 != 1 else ''} with MLRO (P1 cases)",
            "#FF1744",
        ),
        (
            p2 > 0,
            f"Conduct Enhanced Due Diligence for {p2} customer{'s' if p2 != 1 else ''} (P2 cases)",
            "#FF9800",
        ),
        (
            p3 > 0,
            f"Schedule routine monitoring review for {p3} customer{'s' if p3 != 1 else ''} (P3)",
            "#FFD600",
        ),
        (True, "Archive this analysis run in the Audit Trail", "#00D4FF"),
        (True, "Confirm next scheduled pipeline run with the data team", "#9D4EDD"),
    ]
    checklist = dmc.Paper(
        [
            dmc.Text("MLRO / Compliance Action Checklist", size="xs", fw=700, c="#FFD600", mb="xs"),
            dmc.Stack(
                [
                    dmc.Group(
                        [
                            DashIconify(
                                icon=(
                                    "mdi:checkbox-blank-circle"
                                    if active
                                    else "mdi:minus-circle-outline"
                                ),
                                width=14,
                                color=color if active else "#555",
                            ),
                            dmc.Text(
                                text,
                                size="xs",
                                c=color if active else "#555",
                                fw=600 if active else 400,
                            ),
                        ],
                        gap="xs",
                    )
                    for active, text, color in checklist_defs
                ],
                gap=6,
            ),
        ],
        p="sm",
        radius="md",
        style={"backgroundColor": "rgba(0,0,0,0.2)", "border": "1px solid rgba(255,215,0,0.2)"},
    )

    action_tab = html.Div(
        [
            dmc.Alert(
                dmc.Group(
                    [
                        DashIconify(icon="mdi:information-outline", width=18),
                        dmc.Text(
                            f"Run #{run_id} — completed {saved_at_str} — "
                            f"{action_needed} case{'s' if action_needed != 1 else ''} "
                            f"requiring elevated action out of {total:,} total.",
                            size="xs",
                        ),
                    ],
                    gap="xs",
                ),
                color="blue",
                variant="light",
                mb="md",
                radius="md",
            ),
            *(
                action_items
                if action_items
                else [
                    dmc.Paper(
                        dmc.Text(
                            "No P1/P2 cases identified. Portfolio is within acceptable risk parameters.",
                            c="#00E676",
                            size="sm",
                            ta="center",
                            py="lg",
                        ),
                        p="md",
                        radius="md",
                        style={
                            "backgroundColor": "rgba(0,230,118,0.05)",
                            "border": "1px solid rgba(0,230,118,0.2)",
                        },
                    )
                ]
            ),
            checklist,
        ]
    )

    # ── Assemble 3-tab panel ─────────────────────────────────────────────────
    return dmc.Paper(
        [
            dmc.Tabs(
                value="portfolio",
                children=[
                    dmc.TabsList(
                        [
                            dmc.TabsTab(
                                "Portfolio Risk Summary",
                                value="portfolio",
                                leftSection=DashIconify(icon="mdi:shield-check-outline", width=16),
                            ),
                            dmc.TabsTab(
                                "Network Intelligence",
                                value="network",
                                leftSection=DashIconify(icon="mdi:graph-outline", width=16),
                            ),
                            dmc.TabsTab(
                                "Priority Action Register",
                                value="actions",
                                leftSection=DashIconify(
                                    icon="mdi:clipboard-check-outline", width=16
                                ),
                            ),
                        ]
                    ),
                    dmc.TabsPanel(portfolio_tab, value="portfolio", pt="md"),
                    dmc.TabsPanel(network_tab, value="network", pt="md"),
                    dmc.TabsPanel(action_tab, value="actions", pt="md"),
                ],
            ),
        ],
        p="md",
        radius="md",
        mt="md",
        style={"backgroundColor": "rgba(0,0,0,0.15)", "border": "1px solid rgba(255,255,255,0.06)"},
    )


def _chart_layout(title=""):
    return dict(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=10, r=10, t=30, b=30),
        font=dict(color=THEME.TEXT_SECONDARY, size=11),
        title=dict(text=title, font=dict(color=THEME.TEXT_MUTED, size=12)),
        xaxis=dict(showgrid=False, tickfont=dict(size=10)),
        yaxis=dict(showgrid=True, gridcolor="rgba(255,255,255,0.05)"),
        legend=dict(font=dict(color=THEME.TEXT_MUTED, size=10)),
    )


def _empty_chart(msg="No data"):
    fig = go.Figure()
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=10, r=10, t=10, b=10),
        annotations=[dict(text=msg, showarrow=False, font=dict(color="#64748B", size=12))],
    )
    return fig


# Populate node selectors for narrative templates (MED-05 closure fix)
for _key in NARRATIVE_TEMPLATES:

    def _make_populate_cb(_bound_key):
        @callback(
            Output(f"report-node-{_bound_key}", "data"),
            Input("reports-init", "n_intervals"),
        )
        @GlobalExceptionHandler.wrap()
        def _populate_nodes(_):
            pipeline = get_pipeline()
            scored_df = pipeline.get_scored_df()
            if scored_df is None or scored_df.empty:
                return []
            return [
                {
                    "value": str(row["node_id"]),
                    "label": f"{mask_value(str(row['node_id']), 'partial')} | {row.get('risk_tier', '?')} | {float(row.get('risk_score', 0)):.1f}",
                }
                for _, row in scored_df.head(200).iterrows()
            ]

        return _populate_nodes

    _make_populate_cb(_key)


# Narrative preview callbacks
for _key, _tmpl in NARRATIVE_TEMPLATES.items():

    @callback(
        Output(f"report-preview-{_key}", "children"),
        Input(f"report-node-{_key}", "value"),
    )
    @GlobalExceptionHandler.wrap()
    def _preview_narrative(node_id, key=_key, tmpl=_tmpl):
        if not node_id:
            return html.P(
                "Select a customer to preview the narrative.",
                style={"color": THEME.TEXT_MUTED, "fontSize": "0.85rem"},
            )

        pipeline = get_pipeline()
        scored_df = pipeline.get_scored_df()
        row = None
        if scored_df is not None and "node_id" in scored_df.columns:
            matches = scored_df[scored_df["node_id"] == node_id]
            if len(matches) > 0:
                row = matches.iloc[0]

        now = datetime.now().strftime("%Y-%m-%d %H:%M")
        masked_id = mask_value(node_id, "partial")
        score = float(row["risk_score"]) if row is not None else 0
        tier = str(row.get("risk_tier", "?")) if row is not None else "?"

        sections = []
        for section in tmpl["sections"]:
            sections.append(
                html.Div(
                    [
                        html.Strong(
                            section,
                            style={
                                "color": tmpl["color"],
                                "fontSize": "0.85rem",
                                "display": "block",
                                "marginBottom": "0.25rem",
                            },
                        ),
                        html.P(
                            _generate_section_text(section, masked_id, score, tier, now),
                            style={
                                "color": THEME.TEXT_SECONDARY,
                                "fontSize": "0.82rem",
                                "margin": 0,
                                "lineHeight": "1.6",
                            },
                        ),
                    ],
                    style={
                        "marginBottom": "0.75rem",
                        "paddingLeft": "0.75rem",
                        "borderLeft": f"2px solid {tmpl['color']}44",
                    },
                )
            )

        return html.Div(
            [
                html.Div(
                    [
                        html.Strong(
                            tmpl["title"],
                            style={"color": THEME.TEXT_PRIMARY, "fontSize": "0.95rem"},
                        ),
                        html.Span(
                            f" — Generated {now}",
                            style={"color": THEME.TEXT_MUTED, "fontSize": "0.78rem"},
                        ),
                    ],
                    style={"marginBottom": "0.75rem"},
                ),
                *sections,
            ],
            style={
                "background": "rgba(0,0,0,0.3)",
                "border": f"1px solid {tmpl['color']}22",
                "borderRadius": "8px",
                "padding": "1rem",
            },
        )


def _generate_section_text(section, masked_id, score, tier, timestamp):
    """Generate placeholder narrative text for each section."""
    texts = {
        "Subject Information": f"Reference ID: {masked_id}. Risk Tier: {tier}. Risk Score: {score:.1f}/100. Report generated: {timestamp}.",
        "Customer Profile": f"Customer reference {masked_id} has been assigned risk tier {tier} with a composite risk score of {score:.1f}.",
        "Network Overview": f"Network analysis centred on entity {masked_id} reveals interconnected transaction patterns warranting investigation.",
        "Activity Description": f"The subject entity {masked_id} has exhibited transaction patterns consistent with elevated risk indicators as identified by the automated detection pipeline.",
        "Risk Score Analysis": f"Composite risk score: {score:.1f}/100 (Tier {tier}). Score derived from multi-layer analytics including relationship influence, time-pattern analysis, and behavioural anomaly detection.",
        "Pattern Analysis": f"Automated analysis identified patterns consistent with the assigned risk tier. Key contributing factors are detailed in the analytics breakdown.",
        "Risk Indicators": f"Elevated risk score ({score:.1f}) places this entity in tier {tier}. Specific indicators flagged by the detection engine are available in the Intelligence Hub.",
        "Key Entities": f"Primary entity: {masked_id}. Connected entities identified through network graph analysis. Full entity list available in the Port Authority view.",
        "Transaction Flows": f"Transaction flow analysis conducted across all connected accounts. Detailed flow data available in the Vault analytics section.",
        "Recommended Action": f"Based on risk tier {tier} classification, this case is recommended for {'immediate escalation to compliance team' if tier == 'P1' else 'standard review process'}.",
        "Compliance Notes": f"This narrative is generated by FCDAI v{APP.VERSION} in compliance with internal AML policy. All PII is masked per data protection requirements. Air-gapped processing confirmed.",
        "Findings & Conclusions": f"Investigation of entity {masked_id} is {'recommended for escalation' if tier in ('P1', 'P2') else 'recommended for monitoring'}. Full audit trail available in the Audit Trail page.",
    }
    return texts.get(section, f"[{section} — complete based on investigation findings]")

# ── v16.11 T2: Enhanced PDF export — converts Plotly charts to static images
# before printing so they appear in the PDF.  Also shows all tab panels. ─────
clientside_callback(
    """
    function(n) {
        if (!n) return window.dash_clientside.no_update;

        // 1) Force-show ALL Mantine TabsPanel (hidden ones won't print otherwise)
        document.querySelectorAll('[role="tabpanel"]').forEach(function(p) {
            p.style.display = 'block';
            p.style.visibility = 'visible';
            p.style.opacity = '1';
            p.style.position = 'relative';
            p.style.height = 'auto';
            p.style.overflow = 'visible';
        });

        // 2) Convert every Plotly chart to a static <img> for reliable printing
        var plots = document.querySelectorAll('.js-plotly-plot');
        var promises = [];
        plots.forEach(function(plot) {
            if (plot && plot.data) {
                var p = Plotly.toImage(plot, {format: 'png', width: 800, height: 400, scale: 2})
                    .then(function(dataUrl) {
                        var img = document.createElement('img');
                        img.src = dataUrl;
                        img.className = 'plotly-print-img';
                        img.style.width = '100%';
                        img.style.maxWidth = '100%';
                        img.style.display = 'none';
                        plot.parentNode.insertBefore(img, plot.nextSibling);
                    });
                promises.push(p);
            }
        });

        // 3) Wait for all conversions, add print class, print, clean up
        Promise.all(promises).then(function() {
            document.body.classList.add('printing-pdf');
            setTimeout(function() {
                window.print();
                // Clean up: remove inserted images and restore tabs
                document.querySelectorAll('.plotly-print-img').forEach(function(img) {
                    img.remove();
                });
                document.body.classList.remove('printing-pdf');
            }, 400);
        });

        return window.dash_clientside.no_update;
    }
    """,
    Output("exec-pdf-btn", "n_clicks"),
    Input("exec-pdf-btn", "n_clicks"),
    prevent_initial_call=True,
)