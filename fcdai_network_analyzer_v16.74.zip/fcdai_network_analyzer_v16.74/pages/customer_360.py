"""
Page: Customer 360 (v10 — A2)
================================
Business Logic: Single-customer deep-dive with all 10 analytics families,
transaction flow, neighbor network, risk narrative. PII-masked display.
"""

import dash
from dash import html, dcc, callback, Input, Output, State, no_update
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import numpy as np
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, APP
from utils.pii_guard import mask_value

dash.register_page(
    __name__,
    path="/customer-360",
    name="Customer 360",
    title=f"FCDAI v{APP.VERSION} | Customer 360",
)

TIER_COLORS = {"P1": "#FF1744", "P2": "#FF9800", "P3": "#FFD600", "P4": "#00E676"}

FAMILY_NAMES = {
    "centrality": "Relationship Influence",
    "community": "Risk Groups",
    "pathflow": "Money Flow",
    "link_prediction": "Hidden Links",
    "anomaly": "Anomaly Detection",
    "temporal": "Time-Patterns",
    "multi_layer": "Cross-Entity",
    "structuring": "Structuring",
    "benfords": "Benford's Law",
    "motifs": "Transaction Patterns",
}

layout = dmc.Box(
    [
        # v16.21: page-mount trigger
        dcc.Interval(id="c360-init", interval=800, max_intervals=1),
        dmc.Group(
            [
                dmc.Stack(
                    [
                        dmc.Title("Customer 360", order=2, c="white"),
                        dmc.Text(
                            "Deep-Dive Investigation View — PII Protected", c="dimmed", size="sm"
                        ),
                    ],
                    gap=2,
                ),
                dmc.Group(
                    [
                        dmc.Badge(f"v{APP.VERSION}", color="cyan", variant="filled", size="lg"),
                    ],
                    gap="sm",
                ),
            ],
            justify="space-between",
            mb="lg",
        ),
        # v12.26 Task 5: Business purpose banner
        dmc.Paper(
            dmc.Group(
                [
                    DashIconify(icon="mdi:information-outline", width=18, color="#00D4FF"),
                    dmc.Text(
                        "👤 Why This Page? A complete single-customer investigation view across all 10 AML detection "
                        "families. Select a customer to see their composite risk score, which algorithms "
                        "flagged them, their direct transaction network, and a business-ready risk narrative. "
                        "Use this to build an Activity Report (Narrative) package or present findings to a "
                        "compliance committee. All customer data is PII-masked per GDPR/CCPA.",
                        size="sm",
                        c="white",
                        style={"lineHeight": "1.6"},
                    ),
                ],
                gap="sm",
                align="flex-start",
            ),
            p="sm",
            radius="md",
            mb="md",
            style={"background": "rgba(0,212,255,0.06)", "border": "1px solid rgba(0,212,255,0.2)"},
        ),
        dmc.Paper(
            [
                dmc.Group(
                    [
                        DashIconify(icon="mdi:account-search", width=22, color=THEME.PRIMARY),
                        dmc.Text("Select Customer", fw=600, c="white"),
                    ],
                    gap="sm",
                    mb="sm",
                ),
                dmc.Group(
                    [
                        dmc.Select(
                            id="c360-node-select",
                            placeholder="Select a customer node...",
                            searchable=True,
                            clearable=True,
                            size="sm",
                            styles={
                                "input": {
                                    "backgroundColor": THEME.DARK_BG,
                                    "color": "white",
                                    "border": f"1px solid {THEME.DARK_BORDER}",
                                }
                            },
                            style={"flex": 1},
                        ),
                        dmc.Button("Load", id="c360-load-btn", color="cyan", variant="filled"),
                    ],
                    gap="sm",
                ),
            ],
            p="lg",
            radius="lg",
            className="glass-card",
            mb="md",
        ),
        # Export bar
        dmc.Paper(
            [
                dmc.Group(
                    [
                        DashIconify(icon="mdi:download-circle-outline", width=22, color="#00D4FF"),
                        dmc.Text("Export Customer Data", fw=600, c="white", size="sm"),
                        dmc.Button(
                            "⬇ Export CSV",
                            id="c360-export-csv",
                            size="xs",
                            variant="light",
                            color="cyan",
                            leftSection=DashIconify(icon="mdi:download", width=14),
                        ),
                    ],
                    gap="md",
                    align="center",
                ),
            ],
            p="sm",
            radius="lg",
            className="glass-card",
            mb="md",
            style={
                "background": "rgba(0,212,255,0.04)",
                "border": "1px solid rgba(0,212,255,0.15)",
            },
        ),
        dcc.Download(id="c360-download"),
        # Content area
        html.Div(id="c360-content"),
    ]
)


@callback(
    Output("c360-node-select", "data"),
    Input("c360-node-select", "searchValue"),
    Input("pipeline-state", "data"),
    Input("global-refresh-ts", "data"),
    Input("c360-init", "n_intervals"),
    prevent_initial_call=False,
)
def populate_node_list(_search, _pipeline_state, _gr, _init=None):
    from engine import get_pipeline

    pipeline = get_pipeline()
    if not pipeline.has_data():
        return []
    scored = pipeline.get_scored_df()
    if scored is None:
        return []
    nodes = scored.sort_values("risk_score", ascending=False)["node_id"].tolist()[:200]
    # v16.69: build name map for label enrichment
    _name_map = {}
    try:
        for _tbl_name in ("node", "customer"):
            _tbl = pipeline.tables.get(_tbl_name) if hasattr(pipeline, "tables") else None
            if _tbl is not None:
                _nc = next(
                    (c for c in ("customer_name", "name", "full_name", "entity_name") if c in _tbl.columns),
                    None,
                )
                _ni = next(
                    (c for c in ("node_id", "customer_id", "id") if c in _tbl.columns), None
                )
                if _nc and _ni:
                    _name_map = dict(zip(_tbl[_ni].astype(str), _tbl[_nc].astype(str)))
                    break
    except Exception:
        pass
    options = []
    for n in nodes:
        _cname = _name_map.get(str(n), "")
        if _cname:
            options.append({"value": n, "label": f"{_cname} ({mask_value(n, 'partial')})"})
        else:
            options.append({"value": n, "label": f"{mask_value(n, 'partial')} "})
    return options


@callback(
    Output("c360-content", "children"),
    Input("c360-load-btn", "n_clicks"),
    State("c360-node-select", "value"),
    prevent_initial_call=True,
)
def load_customer_360(_, node_id):
    if not node_id:
        return dmc.Alert("Select a customer node first", color="yellow")

    from engine import get_pipeline

    pipeline = get_pipeline()
    data = pipeline.get_customer_360(node_id)

    if not data:
        return dmc.Alert(f"Node not found", color="red")

    scored = data.get("scored", {})
    attrs = data.get("attributes", {})
    risk_score = scored.get("risk_score", 0)
    risk_tier = scored.get("risk_tier", "P4")
    tier_color = TIER_COLORS.get(risk_tier, "gray")

    # Overview cards
    overview = dmc.SimpleGrid(
        cols={"base": 2, "md": 4},
        spacing="md",
        mb="md",
        children=[
            _stat_card(f"{risk_score:.1f}", "Risk Score", "mdi:shield-alert", tier_color),
            _stat_card(risk_tier, "Risk Tier", "mdi:flag", tier_color),
            _stat_card(str(data.get("in_degree", 0)), "In-Degree", "mdi:arrow-left-bold", "cyan"),
            _stat_card(
                str(data.get("out_degree", 0)), "Out-Degree", "mdi:arrow-right-bold", "blue"
            ),
        ],
    )

    # Flow summary
    in_flow = attrs.get("in_flow", 0)
    out_flow = attrs.get("out_flow", 0)
    flow_card = dmc.Paper(
        [
            dmc.Group(
                [
                    DashIconify(icon="mdi:cash-multiple", width=20, color="#00E676"),
                    dmc.Text("Flow Summary", fw=600, c="white"),
                ],
                gap="sm",
                mb="sm",
            ),
            dmc.SimpleGrid(
                cols=3,
                spacing="md",
                children=[
                    dmc.Stack(
                        [
                            dmc.Text(f"${in_flow:,.2f}", fw=700, c="#00E676"),
                            dmc.Text("Inflow", c="dimmed", size="xs"),
                        ],
                        gap=0,
                    ),
                    dmc.Stack(
                        [
                            dmc.Text(f"${out_flow:,.2f}", fw=700, c="#FF6B6B"),
                            dmc.Text("Outflow", c="dimmed", size="xs"),
                        ],
                        gap=0,
                    ),
                    dmc.Stack(
                        [
                            dmc.Text(f"${abs(in_flow - out_flow):,.2f}", fw=700, c="white"),
                            dmc.Text("Net Flow", c="dimmed", size="xs"),
                        ],
                        gap=0,
                    ),
                ],
            ),
        ],
        p="lg",
        radius="lg",
        className="glass-card",
        mb="md",
    )

    # Family radar chart
    family_scores = data.get("family_scores", {})
    radar_fig = _build_radar(family_scores)
    # v16.69: 3-view descriptions (Technical, Business, Simple) — always visible
    _radar_descriptions = dmc.Stack(
        [
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            dmc.Badge("Technical", color="blue", variant="filled", size="sm"),
                            dmc.Text("Algorithm Family Breakdown", fw=700, c="white", size="sm"),
                        ],
                        gap="xs", mb=4,
                    ),
                    dmc.Text(
                        "The radar plots the normalised risk contribution (0–100) for each of the 10 AML "
                        "detection algorithm families: Centrality (PageRank/Betweenness influence), Community "
                        "(Louvain/Leiden cluster membership), Pathflow (money-flow graph traversal), Link Prediction "
                        "(GNN/embedding-based hidden-edge probability), Anomaly (Isolation Forest / LOF deviation score), "
                        "Temporal (time-series burst & velocity patterns), Multi-Layer (cross-entity propagation), "
                        "Structuring (sub-threshold transaction segmentation), Benford's Law (digit-distribution anomaly), "
                        "and Motifs (recurring suspicious sub-graph patterns). Each axis is percentile-scaled within the "
                        "full customer population so scores are directly comparable across families.",
                        size="xs", c="#94A3B8", style={"lineHeight": "1.6"},
                    ),
                ],
                p="sm", radius="md",
                style={"background": "rgba(0,80,160,0.12)", "border": "1px solid rgba(0,150,255,0.2)"},
            ),
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            dmc.Badge("Business English", color="orange", variant="filled", size="sm"),
                            dmc.Text("What the Chart Means for Compliance", fw=700, c="white", size="sm"),
                        ],
                        gap="xs", mb=4,
                    ),
                    dmc.Text(
                        "This spider chart shows how suspicious this customer is across ten different AML detection methods. "
                        "A large, filled shape means the customer triggered multiple detection engines simultaneously — a strong "
                        "signal that warrants escalation to an investigator. Key spikes to watch: Structuring indicates "
                        "intentional transaction-splitting to avoid reporting thresholds (Smurfing / Layering); Pathflow "
                        "indicates the customer sits on a high-volume cross-border money route; Community indicates cluster "
                        "membership with other high-risk accounts. If three or more axes exceed 70, the composite risk is "
                        "likely to be P1 or P2 — prepare a Suspicious Activity Report (SAR) package.",
                        size="xs", c="#CBD5E1", style={"lineHeight": "1.6"},
                    ),
                ],
                p="sm", radius="md",
                style={"background": "rgba(200,80,0,0.10)", "border": "1px solid rgba(255,140,0,0.25)"},
            ),
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            dmc.Badge("Simple English", color="green", variant="filled", size="sm"),
                            dmc.Text("Plain Language Summary", fw=700, c="white", size="sm"),
                        ],
                        gap="xs", mb=4,
                    ),
                    dmc.Text(
                        "Think of this chart like a fingerprint for financial crime. Each point on the star represents "
                        "one way the computer checked if this person’s banking looks unusual. The bigger and more filled "
                        "the star, the more red flags were raised. A tiny star means the person looks normal. A big, "
                        "uneven star — especially with spikes in Structuring or Pathflow — means the computer found "
                        "something worth a human investigator looking at closely. It does not mean the person is guilty; "
                        "it means: \"look here first.\"",
                        size="xs", c="#A7F3D0", style={"lineHeight": "1.6"},
                    ),
                ],
                p="sm", radius="md",
                style={"background": "rgba(0,120,60,0.12)", "border": "1px solid rgba(0,200,100,0.2)"},
            ),
        ],
        gap="xs",
        mt="sm",
    )
    radar_card = dmc.Paper(
        [
            dmc.Text("10-Family Analytics Radar", fw=600, c="white", mb="sm"),
            dcc.Graph(
                figure=radar_fig, config={"displayModeBar": False}, style={"height": "350px"}
            ),
            _radar_descriptions,
        ],
        p="lg",
        radius="lg",
        className="glass-card",
        mb="md",
    )

    # Edges tables
    edges_in = data.get("edges_in", [])
    edges_out = data.get("edges_out", [])
    edges_card = dmc.Paper(
        [
            dmc.Text("Transaction Edges", fw=600, c="white", mb="sm"),
            dmc.Tabs(
                [
                    dmc.TabsList(
                        [
                            dmc.TabsTab(f"Incoming ({len(edges_in)})", value="in"),
                            dmc.TabsTab(f"Outgoing ({len(edges_out)})", value="out"),
                        ]
                    ),
                    dmc.TabsPanel(_edges_table(edges_in, "from"), value="in"),
                    dmc.TabsPanel(_edges_table(edges_out, "to"), value="out"),
                ],
                value="in",
                color="cyan",
            ),
        ],
        p="lg",
        radius="lg",
        className="glass-card",
        mb="md",
    )

    # Narrative
    narrative = data.get("narrative", "No narrative generated.")
    narrative_card = dmc.Paper(
        [
            dmc.Group(
                [
                    DashIconify(icon="mdi:file-document", width=20, color="#FFD600"),
                    dmc.Text("Risk Narrative", fw=600, c="white"),
                ],
                gap="sm",
                mb="sm",
            ),
            dmc.Blockquote(
                narrative if narrative else "No narrative available",
                color="yellow",
                icon=DashIconify(icon="mdi:format-quote-open"),
            ),
        ],
        p="lg",
        radius="lg",
        className="glass-card",
    )

    return dmc.Stack([overview, flow_card, radar_card, edges_card, narrative_card], gap=0)


def _build_radar(family_scores: dict) -> go.Figure:
    categories = []
    values = []
    for family, scores in family_scores.items():
        display_name = FAMILY_NAMES.get(family, family)
        # Get the most important score from each family
        if isinstance(scores, dict):
            # Pick the main risk/score metric
            for key in [
                "risk_score",
                "motif_risk_score",
                "structuring_score",
                "benfords_conformity",
                "temporal_anomaly_score",
                "anomaly_score_if",
                "cross_layer_score",
                "pagerank",
                "burst_score",
                "flow_centrality",
                "jaccard_avg",
            ]:
                if key in scores:
                    categories.append(display_name)
                    values.append(min(float(scores[key]), 1.0))
                    break
            else:
                # First numeric value
                for v in scores.values():
                    try:
                        val = float(v)
                        categories.append(display_name)
                        values.append(min(val, 1.0))
                        break
                    except (ValueError, TypeError):
                        continue

    if not categories:
        categories = list(FAMILY_NAMES.values())
        values = [0] * len(categories)

    # v16.71 M1: Add "(N/A)" labels for engines that didn't run this customer
    _covered_names = set(categories)
    _any_na = False
    for _fkey, _fname in FAMILY_NAMES.items():
        if _fname not in _covered_names:
            categories.append(f"{_fname}\n(N/A)")
            values.append(0.0)
            _any_na = True

    fig = go.Figure()
    fig.add_trace(
        go.Scatterpolar(
            r=values,
            theta=categories,
            fill="toself",
            line=dict(color="#00D4FF"),
            fillcolor="rgba(0,212,255,0.2)",
            name="Risk Profile",
        )
    )
    fig.update_layout(
        polar=dict(
            radialaxis=dict(visible=True, range=[0, 1], color="rgba(255,255,255,0.3)"),
            bgcolor="rgba(0,0,0,0)",
        ),
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        showlegend=False,
        margin=dict(t=30, b=30 if not _any_na else 50, l=60, r=60),
    )
    if _any_na:
        fig.add_annotation(
            text="(N/A) = Engine not run for this customer",
            xref="paper", yref="paper", x=0.5, y=-0.12,
            showarrow=False, font=dict(size=10, color="rgba(255,255,255,0.45)"),
            align="center",
        )
    return fig


def _edges_table(edges, key):
    if not edges:
        return dmc.Text("No edges", c="dimmed", p="md")
    rows = []
    for e in edges[:20]:
        rows.append(
            dmc.Group(
                [
                    dmc.Text(
                        mask_value(str(e.get(key, "")), "partial"), c="white", size="sm", w=150
                    ),
                    dmc.Text(f"${e.get('amount', 0):,.2f}", c="#00D4FF", size="sm", w=120),
                    dmc.Badge(e.get("type", "unknown"), size="xs", variant="light", color="gray"),
                ],
                gap="md",
                style={"padding": "4px 0", "borderBottom": f"1px solid {THEME.DARK_BORDER}"},
            )
        )
    return dmc.Stack(rows, gap=0, p="sm")


def _stat_card(value, label, icon, color):
    return dmc.Paper(
        [
            dmc.Group(
                [
                    dmc.ThemeIcon(
                        DashIconify(icon=icon, width=20),
                        size="lg",
                        radius="md",
                        variant="light",
                        color=color,
                    ),
                    dmc.Stack(
                        [
                            dmc.Text(value, fw=700, c="white", size="lg"),
                            dmc.Text(label, c="dimmed", size="xs"),
                        ],
                        gap=0,
                    ),
                ],
                gap="sm",
            ),
        ],
        p="md",
        radius="lg",
        className="glass-card stat-card",
    )


# ── EXPORT CALLBACK ───────────────────────────────────────────────────────
@callback(
    Output("c360-download", "data"),
    Input("c360-export-csv", "n_clicks"),
    prevent_initial_call=True,
)
def export_c360_csv(_):
    """Export full scored customer data as CSV."""
    from engine import get_pipeline

    pipeline = get_pipeline()
    scored = pipeline.get_scored_df()
    if scored is not None:
        return dcc.send_data_frame(scored.to_csv, "customer_360_data.csv", index=False)
    return no_update
