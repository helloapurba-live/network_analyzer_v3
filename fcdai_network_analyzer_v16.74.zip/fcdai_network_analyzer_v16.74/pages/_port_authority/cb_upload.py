"""
pages/port_authority/cb_upload.py
=====================================
PURPOSE
-------
Callbacks for actual-data UPLOAD and table management on the Port Authority page:

  CB5  upload_files     — File upload → parse + store DataFrames + refresh displays
  CB6  delete_table     — Delete a specific table from the data store
  CB7  download_table   — Download a single table as CSV
  CB8  download_all     — Download all loaded tables as a ZIP of CSVs
  CB9  change_page_size — Change AG Grid page size across all tables

IMPORTANT: OPTIONAL TABLES
---------------------------
In real-world AML data, ONLY the following tables are REQUIRED:
  - node_table    (graph mode)
  - edge_table    (graph mode)
  - customer      (legacy mode)
  - transaction   (legacy mode)

All other 9 tables in ALL_TABLE_DEFS are OPTIONAL.  Their absence should
NEVER cause a crash.  Every helper and callback here guards for missing tables.

UPLOAD PATTERN (CB5)
--------------------
ALL_UPLOAD_SLOTS has 15 entries.  Outputs and Inputs for badge/content/filename
are built using Python list unpacking (*[...]) into the @callback decorator.
This pattern avoids writing 15 or 30 individual Input/Output arguments.
The syntax looks like:

    @callback(
        Output("pa-graph-tables-area", "children", allow_duplicate=True),
        *[Output(f"upload-badge-{k}", "children", allow_duplicate=True)
          for k, *_ in ALL_UPLOAD_SLOTS],    # 15 badge outputs
        *[Input(f"upload-{k}", "contents")
          for k, *_ in ALL_UPLOAD_SLOTS],    # 15 content inputs
        *[State(f"upload-{k}", "filename")
          for k, *_ in ALL_UPLOAD_SLOTS],    # 15 filename states
        State("pa-page-size", "value"),
        prevent_initial_call=True,
    )
    def upload_files(*args): ...

The callback receives positional *args: first 15 are contents, next 15 are
filenames, last is page_size.  Slicing reconstructs them.

IMPORT DEPENDENCY CHAIN
-----------------------
cb_upload.py imports:
  _state.py     — _PA_DATA_STORE, _pa_set_staged, _pa_get_staged
  _constants.py — ALL_UPLOAD_SLOTS, ALL_TABLE_DEFS, GRAPH_TABLE_KEYS
  _helpers.py   — _parse_upload, _build_split_table_cards, _build_pipeline_summary,
                  _build_quality_profile, _build_data_summary
"""

from __future__ import annotations

import io
import zipfile
import base64

import dash_mantine_components as dmc
from dash import callback, ctx, no_update, Input, Output, State
from dash.dcc import send_data_frame, send_bytes
from dash_iconify import DashIconify

from utils.logger import GlobalExceptionHandler

from ._state import (
    _PA_DATA_STORE,
    _pa_set_staged,
    _pa_get_staged,
)
from ._constants import (
    ALL_UPLOAD_SLOTS,
    ALL_TABLE_DEFS,
    GRAPH_TABLE_KEYS,
)
from ._helpers import (
    _parse_upload,
    _build_split_table_cards,
    _build_pipeline_summary,
    _build_quality_profile,
    _build_data_summary,
)


# ═══════════════════════════════════════════════════════════════════════════
# CB5: UPLOAD FILES — parse and store uploaded DataFrames
# ═══════════════════════════════════════════════════════════════════════════
@callback(
    # ── Fixed outputs (always rendered) ──────────────────────────────────
    Output("pa-graph-tables-area",  "children",  allow_duplicate=True),
    Output("pa-legacy-tables-area", "children",  allow_duplicate=True),
    Output("pa-tables-badge",       "children",  allow_duplicate=True),
    Output("pa-tables-badge",       "color",     allow_duplicate=True),
    Output("pa-push-btn",           "disabled",  allow_duplicate=True),
    Output("pa-gen-status",         "children",  allow_duplicate=True),
    Output("pa-pipe-summary",       "children",  allow_duplicate=True),
    Output("pa-quality-profile",    "children",  allow_duplicate=True),
    Output("pa-data-summary",       "children",  allow_duplicate=True),
    Output("pa-summary-mode-badge", "children",  allow_duplicate=True),
    Output("pipeline-state",        "data",      allow_duplicate=True),
    # ── 15 badge outputs — one per upload slot ────────────────────────────
    *[Output(f"upload-badge-{k}", "children", allow_duplicate=True)
      for k, *_ in ALL_UPLOAD_SLOTS],
    # ── 15 file content inputs ────────────────────────────────────────────
    *[Input(f"upload-{k}", "contents")
      for k, *_ in ALL_UPLOAD_SLOTS],
    # ── 15 filename states (for extension detection) ──────────────────────
    *[State(f"upload-{k}", "filename")
      for k, *_ in ALL_UPLOAD_SLOTS],
    # ── Common states ─────────────────────────────────────────────────────
    State("pa-page-size", "value"),
    prevent_initial_call=True,
)
@GlobalExceptionHandler.wrap(fallback=(no_update,) * (11 + len(ALL_UPLOAD_SLOTS)))
def upload_files(*args):
    """
    Parse each uploaded file into a DataFrame and merge with existing store.

    ANY COMBINATION of the 15 upload slots may be filled.  The rest remain
    None and are safely skipped.  ONLY the tables that have a file attached
    are updated — existing tables in other slots are PRESERVED.

    Positional *args layout (26 items after removal of State("pa-page-size")):
      args[0:15]  → contents lists (one per upload slot)
      args[15:30] → filename lists (one per upload slot)
      args[30]    → page_size (State)

    Steps
    -----
    1.  Reconstruct per-slot (contents, filename) pairs.
    2.  For each pair that has data: call _parse_upload().
    3.  Merge parsed DataFrame into _PA_DATA_STORE.
    4.  Rebuild displays and return.

    Optional-table safety
    ---------------------
    If a user only uploads node_table + edge_table, all other 11 tables
    will be None in the store.  _build_split_table_cards() handles this
    gracefully — missing tables get a "not uploaded" placeholder card.
    """
    n_slots = len(ALL_UPLOAD_SLOTS)    # 15
    # Unpack positional args
    contents_list: list = list(args[0:n_slots])
    filenames_list: list = list(args[n_slots:2 * n_slots])
    page_size: int = int(args[2 * n_slots] or 5)

    # ── Parse each uploaded slot ─────────────────────────────────────────
    badge_results = [no_update] * n_slots      # default: keep existing badge
    parsed_count  = 0
    parse_errors  = []

    # Get current staged tables so we MERGE (not clobber) existing data
    current_tables = dict(_pa_get_staged() or {})

    for i, (k, *_) in enumerate(ALL_UPLOAD_SLOTS):
        content  = contents_list[i]
        filename = filenames_list[i]

        if content is None:
            # No file uploaded this slot — do not touch existing data
            continue

        try:
            df = _parse_upload(content, filename)
            if df is not None and len(df) > 0:
                current_tables[k] = df
                parsed_count += 1
                badge_results[i] = dmc.Group(
                    [
                        DashIconify(icon="mdi:check-circle", width=14, color="#00E676"),
                        dmc.Text(f"{len(df):,} rows", size="xs", c="#00E676"),
                    ],
                    gap=4,
                )
            else:
                badge_results[i] = dmc.Group(
                    [
                        DashIconify(icon="mdi:alert-circle", width=14, color="#FF5252"),
                        dmc.Text("Empty file", size="xs", c="#FF5252"),
                    ],
                    gap=4,
                )
        except Exception as exc:  # noqa: BLE001
            parse_errors.append(f"{k}: {exc}")
            badge_results[i] = dmc.Group(
                [
                    DashIconify(icon="mdi:close-circle", width=14, color="#FF5252"),
                    dmc.Text("Parse error", size="xs", c="#FF5252"),
                ],
                gap=4,
            )

    # Persist merged tables
    if parsed_count > 0:
        _pa_set_staged(current_tables)

    staged = _pa_get_staged()
    total  = sum(len(v) for v in staged.values() if v is not None) if staged else 0
    loaded = sum(1 for v in staged.values() if v is not None and len(v) > 0) if staged else 0

    graph_cards, legacy_cards, total, loaded = _build_split_table_cards(staged, page_size)

    # Build status message
    if parse_errors:
        status = dmc.Group(
            [
                DashIconify(icon="mdi:alert-circle", width=16, color="#FF5252"),
                dmc.Text(f"Errors: {'; '.join(parse_errors[:2])}", size="xs", c="#FF5252"),
            ],
            gap="xs", mt="xs",
        )
    elif parsed_count > 0:
        status = dmc.Group(
            [
                DashIconify(icon="mdi:upload", width=16, color="#FF9800"),
                dmc.Text(
                    f"Uploaded {parsed_count} table(s). {loaded} total | {total:,} rows",
                    size="xs", c="#FF9800",
                ),
            ],
            gap="xs", mt="xs",
        )
    else:
        status = no_update

    # Combine fixed outputs + 15 badge outputs
    fixed = [
        graph_cards,
        legacy_cards,
        f"{loaded} / 13 loaded | {total:,} rows",
        "orange" if loaded else "gray",
        loaded == 0,  # push disabled if nothing loaded
        status,
        _build_pipeline_summary(staged),
        _build_quality_profile(staged),
        _build_data_summary(staged, "actual"),
        "Actual",
        {"staged": True, "tables": loaded, "rows": total},
    ]
    return tuple(fixed) + tuple(badge_results)


# ═══════════════════════════════════════════════════════════════════════════
# CB6: DELETE TABLE — remove one table by pattern button click
# ═══════════════════════════════════════════════════════════════════════════
@callback(
    Output("pa-graph-tables-area",  "children",  allow_duplicate=True),
    Output("pa-legacy-tables-area", "children",  allow_duplicate=True),
    Output("pa-tables-badge",       "children",  allow_duplicate=True),
    Output("pa-tables-badge",       "color",     allow_duplicate=True),
    Output("pa-push-btn",           "disabled",  allow_duplicate=True),
    Output("pa-gen-status",         "children",  allow_duplicate=True),
    Output("pa-pipe-summary",       "children",  allow_duplicate=True),
    Output("pa-quality-profile",    "children",  allow_duplicate=True),
    Output("pa-data-summary",       "children",  allow_duplicate=True),
    Input({"type": "btn-del-tbl", "index": "ALL"}, "n_clicks"),
    State("pa-page-size",   "value"),
    State("pa-source-mode", "data"),
    prevent_initial_call=True,
)
@GlobalExceptionHandler.wrap(fallback=(no_update,) * 9)
def delete_table(n_clicks_list, page_size, source_mode):
    """
    Remove a single table from the data store.

    Uses Dash MATCH-style ALL pattern — btn-del-tbl buttons embed the
    table name in their `index` prop.  ctx.triggered_id["index"] gives
    the table key to delete.

    v16.15 FIX: _no_mount_clicks guard prevents phantom fires on page mount.

    Parameters
    ----------
    n_clicks_list : list  — click counts for ALL delete buttons
    page_size     : int   — current page size
    source_mode   : str   — "sample" or "actual" (for data summary label)
    """
    from ._state import _no_mount_clicks  # local import to avoid circular at module level
    if _no_mount_clicks(n_clicks_list):
        return (no_update,) * 9

    triggered_id = ctx.triggered_id
    if triggered_id is None:
        return (no_update,) * 9

    # The button index IS the table key
    table_key = triggered_id.get("index") if isinstance(triggered_id, dict) else None
    if not table_key:
        return (no_update,) * 9

    staged = dict(_pa_get_staged() or {})
    if table_key in staged:
        del staged[table_key]
        _pa_set_staged(staged)

    page_size = int(page_size or 5)
    staged    = _pa_get_staged()
    total     = sum(len(v) for v in staged.values() if v is not None) if staged else 0
    loaded    = sum(1 for v in staged.values() if v is not None and len(v) > 0) if staged else 0
    graph_cards, legacy_cards, total, loaded = _build_split_table_cards(staged, page_size)

    status = dmc.Group(
        [
            DashIconify(icon="mdi:delete", width=16, color="#FF5252"),
            dmc.Text(f"Deleted '{table_key}'. {loaded} table(s) remain.", size="xs", c="#FF5252"),
        ],
        gap="xs", mt="xs",
    )
    return (
        graph_cards,
        legacy_cards,
        f"{loaded} / 13 loaded | {total:,} rows",
        "green" if loaded else "gray",
        loaded == 0,
        status,
        _build_pipeline_summary(staged),
        _build_quality_profile(staged),
        _build_data_summary(staged, source_mode or "sample"),
    )


# ═══════════════════════════════════════════════════════════════════════════
# CB7: DOWNLOAD SINGLE TABLE as CSV
# ═══════════════════════════════════════════════════════════════════════════
@callback(
    Output("pa-download-csv", "data", allow_duplicate=True),
    Input({"type": "btn-dl-tbl", "index": "ALL"}, "n_clicks"),
    prevent_initial_call=True,
)
@GlobalExceptionHandler.wrap(fallback=no_update)
def download_table(n_clicks_list):
    """
    Download the clicked table as a CSV file.

    The download button embeds the table name in its `index` prop.

    Parameters
    ----------
    n_clicks_list : list — click counts for ALL download buttons
    """
    from ._state import _no_mount_clicks
    if _no_mount_clicks(n_clicks_list):
        return no_update

    triggered_id = ctx.triggered_id
    if triggered_id is None:
        return no_update

    table_key = triggered_id.get("index") if isinstance(triggered_id, dict) else None
    if not table_key:
        return no_update

    staged = _pa_get_staged()
    df     = (staged or {}).get(table_key)
    if df is None or len(df) == 0:
        return no_update

    return send_data_frame(df.to_csv, f"{table_key}.csv", index=False)


# ═══════════════════════════════════════════════════════════════════════════
# CB8: DOWNLOAD ALL TABLES as ZIP of CSVs
# ═══════════════════════════════════════════════════════════════════════════
@callback(
    Output("pa-download-zip", "data", allow_duplicate=True),
    Input("pa-dl-all", "n_clicks"),
    prevent_initial_call=True,
)
@GlobalExceptionHandler.wrap(fallback=no_update)
def download_all(n_clicks):
    """
    Bundle ALL loaded tables into a single ZIP archive of CSV files.
    User downloads one ZIP — each table is a separate CSV inside.

    Purely in-memory, no temp files written to disk.
    ZIP is assembled using Python's built-in zipfile module.

    Parameters
    ----------
    n_clicks : int or None  — click count from Download All button
    """
    if not n_clicks:
        return no_update

    staged = _pa_get_staged() or {}
    if not staged:
        return no_update

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
        for name, df in staged.items():
            if df is not None and len(df) > 0:
                csv_bytes = df.to_csv(index=False).encode("utf-8")
                zf.writestr(f"{name}.csv", csv_bytes)

    buf.seek(0)
    return send_bytes(buf.read, "port_authority_data.zip")


# ═══════════════════════════════════════════════════════════════════════════
# CB9: CHANGE PAGE SIZE — re-render all AG Grid tables with new page size
# ═══════════════════════════════════════════════════════════════════════════
@callback(
    Output("pa-graph-tables-area",  "children", allow_duplicate=True),
    Output("pa-legacy-tables-area", "children", allow_duplicate=True),
    Input("pa-page-size", "value"),
    prevent_initial_call=True,
)
@GlobalExceptionHandler.wrap(fallback=(no_update, no_update))
def change_page_size(page_size):
    """
    Re-render table card areas whenever the user changes the page size.

    This replaces the AG Grid components with new ones configured at the
    chosen rows-per-page setting.

    Parameters
    ----------
    page_size : int  — new number of rows per AG Grid page (5/10/25/50)
    """
    page_size = int(page_size or 5)
    staged    = _pa_get_staged()
    if not staged:
        return no_update, no_update

    graph_cards, legacy_cards, _, _ = _build_split_table_cards(staged, page_size)
    return graph_cards, legacy_cards
