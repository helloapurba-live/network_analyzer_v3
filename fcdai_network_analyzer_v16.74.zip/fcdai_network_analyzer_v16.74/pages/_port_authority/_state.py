"""
pages/port_authority/_state.py
================================
PURPOSE
-------
Single source of truth for ALL module-level shared state used by the
Port Authority page.  Every other module in this package imports from here.

WHY A SEPARATE FILE?
--------------------
Python guarantees that a module is imported ONCE and cached in sys.modules.
That means _PA_DATA_STORE (a plain dict) defined here is THE SAME object in
memory, no matter which other module imports it.  There is no risk of two
"copies" of the data getting out of sync.

THREAD SAFETY NOTE
------------------
This app runs on a single-user Windows 11 machine (air-gapped bank workstation).
CPython's GIL protects plain dict reads/writes from concurrent threads.
No extra locks are needed for the simple key-value mutations we do here.

IMPORT DEPENDENCY CHAIN
-----------------------
_state.py  ← imports nothing from this package  (ROOT — no circular risk)
_constants.py   ← imports nothing from this package
_helpers.py     ← imports _state, _constants
layout.py       ← imports _state, _constants, _helpers
cb_*.py         ← import _state, _constants, _helpers
__init__.py     ← imports layout + all cb_*  (LEAF — registered last)
"""

from __future__ import annotations

import hashlib
import time
from pathlib import Path
import sys

# ---------------------------------------------------------------------------
# Ensure project root is on sys.path so "from config import ..." works
# regardless of how the interpreter was launched.
# ---------------------------------------------------------------------------
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

# ═══════════════════════════════════════════════════════════════════════════
# PRIMARY DATA STORE
# ═══════════════════════════════════════════════════════════════════════════
# _PA_DATA_STORE is the persistent staging area for DataFrames on this page.
#
# Lifecycle:
#   Created : first time this module is imported (at server start)
#   Filled  : by generate_sample / load_scenario / upload_files callbacks
#   Read    : by layout() and every display-refreshing callback
#   Cleared : ONLY by reset_all_data callback — nothing else clears it
#
# It outlives page navigations because Python module objects (and their globals)
# live for the lifetime of the server process.
_PA_DATA_STORE: dict = {}

# ═══════════════════════════════════════════════════════════════════════════
# ASYNC GENERATION JOB STATE
# ═══════════════════════════════════════════════════════════════════════════
# Used by the "large dataset" async path in cb_generate.py (CB3).
# When n_customers > _ASYNC_THRESHOLD, a daemon thread updates this dict
# and the 150 ms Interval callback (CBN3 in cb_grid.py) polls it.
#
# Status values:
#   "idle"    — nothing running; safe to start a new generation
#   "running" — background thread is working; spinner shown in UI
#   "done"    — thread finished; result dict is ready to be consumed
#   "error"   — thread raised an exception; error string in "error" key
_GEN_JOB: dict = {
    "status":   "idle",    # idle | running | done | error
    "result":   None,      # dict with tables, scope, n_cust, elapsed …
    "error":    None,      # str traceback if status == "error"
    "start_ts": 0.0,       # time.monotonic() when job started
    "params":  {},         # copy of generation params for UI display
}

# ═══════════════════════════════════════════════════════════════════════════
# COMPUTE CACHE
# ═══════════════════════════════════════════════════════════════════════════
# Lightweight key→result cache for expensive builder functions (_build_data_summary
# etc.).  Keyed by _tables_cache_key() — a cheap string representing the
# current table shapes.  Entries are plain Python objects (no Dash components)
# to avoid Dash vdom diffing issues with shared component instances.
_COMPUTE_CACHE: dict = {}

# ═══════════════════════════════════════════════════════════════════════════
# THRESHOLDS
# ═══════════════════════════════════════════════════════════════════════════
# Tables with this many rows or more switch to server-side AG Grid mode
# (rows fetched page-by-page instead of serialised to JSON all at once).
_SS_THRESHOLD: int = 5_000

# v16.34 FIX: Raised to 100 000 so ALL generation runs synchronously on the
# callback thread.  The async thread path was unreliable (polling could miss
# the "done" signal).  Full-sync mode is simpler, more predictable, and fast
# enough for the bank workstation use case (≤ 10 000 customers typical).
_ASYNC_THRESHOLD: int = 100_000

# Number of outputs in the poll_gen_progress callback — must stay in sync
# with the actual @callback decorator in cb_grid.py.
_GEN_OUTPUTS_COUNT: int = 15  # 13 data outputs + 2 fingerprint outputs


# ═══════════════════════════════════════════════════════════════════════════
# STATE ACCESS HELPERS
# ═══════════════════════════════════════════════════════════════════════════

def _pa_set_staged(tables: dict) -> None:
    """
    Write staged tables to BOTH the module-level cache (_PA_DATA_STORE)
    AND the pipeline singleton (_staged_tables attribute).

    Always call this instead of mutating _PA_DATA_STORE directly so both
    locations stay in sync.

    Parameters
    ----------
    tables : dict
        Mapping of table_name (str) → DataFrame.  Pass an empty dict {}
        to clear all staged data (done by reset_all_data callback).
    """
    global _PA_DATA_STORE  # noqa: PLW0603 — intentional module-global mutation
    _PA_DATA_STORE = dict(tables) if tables else {}
    # Keep pipeline singleton in sync so Dashboard / other pages can see data
    from engine import get_pipeline  # local import avoids circular dependency
    pipeline = get_pipeline()
    pipeline._staged_tables = _PA_DATA_STORE


def _pa_get_staged() -> dict:
    """
    Read staged tables — prefer the module-level cache (never cleared by
    engine internals) with fallback to the pipeline singleton (used on
    very first visit or after a server restart when the singleton has data
    from a previous session that was persisted via other means).

    Returns
    -------
    dict
        Mapping of table_name → DataFrame.  Never returns None — returns {}
        if no data has been staged yet.
    """
    global _PA_DATA_STORE  # noqa: PLW0603
    if _PA_DATA_STORE:
        return _PA_DATA_STORE
    # Fallback: warm the cache from pipeline singleton
    from engine import get_pipeline
    pipeline = get_pipeline()
    fallback = getattr(pipeline, '_staged_tables', None) or {}
    if fallback:
        _PA_DATA_STORE = dict(fallback)  # warm the cache for future calls
    return fallback


# ═══════════════════════════════════════════════════════════════════════════
# FINGERPRINT & CACHE KEY UTILITIES
# ═══════════════════════════════════════════════════════════════════════════

def _compute_fingerprint(tables: dict) -> str:
    """
    Compute an 8-character SHA-256 fingerprint of the current staged tables.

    The fingerprint changes whenever:
    - A table is added or removed
    - The row count of any table changes
    - The first row of any table changes (quick content check)

    Used in the PA header badge so analysts can confirm they are looking at
    the same dataset without re-navigating.

    Parameters
    ----------
    tables : dict
        Mapping of table_name → DataFrame (or None).

    Returns
    -------
    str
        8 hex characters, e.g. "a3f9b021".  Returns "00000000" if empty.
    """
    if not tables:
        return "00000000"
    parts = []
    for k in sorted(tables.keys()):
        df = tables[k]
        if df is None or len(df) == 0:
            parts.append(f"{k}:0x0")
        else:
            cols = ",".join(df.columns)
            first = str(df.iloc[0].to_dict()) if len(df) > 0 else ""
            h4 = hashlib.md5((cols + first).encode()).hexdigest()[:4]
            parts.append(f"{k}:{len(df)}x{len(df.columns)}:{h4}")
    return hashlib.sha256("|".join(parts).encode()).hexdigest()[:8]


def _tables_cache_key(tables: dict) -> str:
    """
    Generate a cheap, shape-only cache key for _COMPUTE_CACHE lookups.

    Only considers row counts + table names (not actual data).  This is
    fast enough to compute on every callback invocation and catches the
    most common "table changed" scenario (different number of rows).

    Parameters
    ----------
    tables : dict
        Mapping of table_name → DataFrame.

    Returns
    -------
    str
        A pipe-delimited string, e.g. "customer:500|node:500|edge:2500".
        Returns "empty" if tables is falsy.
    """
    if not tables:
        return "empty"
    return "|".join(
        f"{k}:{len(v)}"
        for k, v in sorted(tables.items())
        if v is not None
    )


def _no_mount_clicks(*click_lists) -> bool:
    """
    Universal guard for ALL-pattern callbacks in Dash 4.x.

    Problem
    -------
    Dash 4.x can set ctx.triggered_id to a non-None value on page re-mount
    (e.g., for MATCH/ALL pattern callbacks) even when no button was actually
    clicked by the user.  All n_clicks values are None or 0.

    Solution
    --------
    Check whether ANY of the click-count lists contains a truthy value.
    If every value is None/0, the callback was triggered by a page mount
    event and we should return (no_update,) * N to avoid side effects.

    Usage
    -----
    At the top of a callback that takes multiple n_clicks inputs from an
    ALL pattern:

        if _no_mount_clicks(s, m, l):
            return (no_update,) * N

    Parameters
    ----------
    *click_lists : int or None
        n_clicks values (one per Input button).

    Returns
    -------
    bool
        True  → abort (all clicks are None/0 = page mount, not user click)
        False → proceed (at least one real click was detected)
    """
    return not any(bool(c) for c in click_lists)
