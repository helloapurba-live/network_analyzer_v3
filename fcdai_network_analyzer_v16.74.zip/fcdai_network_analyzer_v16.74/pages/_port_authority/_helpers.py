"""
pages/port_authority/_helpers.py
===================================
PURPOSE
-------
All pure UI-builder helper functions for the Port Authority page.

A "helper" here means a function that:
  - takes raw data (DataFrames, dicts) as input
  - returns Dash component trees as output
  - has NO @callback decorator — never registers a callback
  - has NO side effects on _PA_DATA_STORE or the pipeline singleton

This makes helpers easy to test in isolation and reuse across callbacks.

OPTIONAL TABLE HANDLING
-----------------------
In real bank deployments, clients often only have:
  - node + edge  (minimum viable graph dataset)
  - customer + transaction  (minimum viable legacy dataset)
  - A subset of the other 9 optional tables

Every helper in this file handles missing / None tables GRACEFULLY:
  - If a table is absent from the dict → df = tables.get(name) returns None
  - Each function checks   if df is None or len(df) == 0:  and skips or
    shows a placeholder card.
  - NO helper will raise KeyError, AttributeError, or DataFrame-bool error.

IMPORT DEPENDENCY CHAIN
-----------------------
_helpers.py imports:
  - _state.py     (_PA_DATA_STORE, _SS_THRESHOLD — for AG Grid mode decision)
  - _constants.py (all table defs, styles, slots)
  - external Dash libs (dash, dmc, dag, plotly …)
"""

from __future__ import annotations

import base64
import gc
import io

import dash_ag_grid as dag
import dash_mantine_components as dmc
import pandas as pd
import plotly.graph_objects as go
from dash import dcc, html
from dash_iconify import DashIconify

# ── Internal package imports ───────────────────────────────────────────────
from ._state import _SS_THRESHOLD
from ._constants import (
    AG_GRID_STYLE,
    ALL_TABLE_DEFS,
    ALL_UPLOAD_SLOTS,
    CHART_LAYOUT,
    GRAPH_TABLE_DEFS,
    GRAPH_TABLE_KEYS,
    LEGACY_TABLE_DEFS,
    LEGACY_TABLE_KEYS,
    PIPELINE_STAGES,
    TABLE_COLOR_MAP,
    ACCEPTED_FORMATS,
)


# ═══════════════════════════════════════════════════════════════════════════
# FILE PARSING
# ═══════════════════════════════════════════════════════════════════════════

def _parse_upload(content: str, filename: str) -> pd.DataFrame:
    """
    Decode a dcc.Upload base64 content string into a pandas DataFrame.

    Supported formats (auto-detected from filename extension):
      .csv      → pd.read_csv
      .xlsx     → pd.read_excel
      .xls      → pd.read_excel
      .parquet  → pd.read_parquet

    Parameters
    ----------
    content : str
        Base64 content from dcc.Upload (format: "data:<mime>;base64,<data>")
    filename : str
        Original filename — used to detect format.

    Returns
    -------
    pd.DataFrame
        Parsed data.  May be empty (0 rows) if the file was blank.

    Raises
    ------
    ValueError / IOError
        On malformed files — callers should wrap in try/except.
    """
    # Strip the data URI prefix ("data:...;base64,") to get raw base64
    _, content_string = content.split(",")
    decoded = base64.b64decode(content_string)

    fname = (filename or "").lower()
    if fname.endswith(".parquet"):
        return pd.read_parquet(io.BytesIO(decoded))
    elif fname.endswith((".xlsx", ".xls")):
        return pd.read_excel(io.BytesIO(decoded))
    else:
        # Default: treat as CSV (most common upload format)
        return pd.read_csv(io.StringIO(decoded.decode("utf-8", errors="replace")))


# ═══════════════════════════════════════════════════════════════════════════
# AG GRID BUILDER
# ═══════════════════════════════════════════════════════════════════════════

def _make_ag_grid(df: pd.DataFrame | None, page_size: int = 5, table_name: str | None = None):
    """
    Build a paginated AG Grid from a DataFrame.

    Two modes (auto-selected based on row count vs _SS_THRESHOLD):

    CLIENT-SIDE mode  (default, < _SS_THRESHOLD rows)
    --------------------------------------------------
    All rows are serialised to JSON and sent to the browser.  Simple,
    instant, no further round-trips needed.

    SERVER-SIDE mode  (>= _SS_THRESHOLD rows, requires table_name)
    ---------------------------------------------------------------
    Only column definitions are sent.  Row data is fetched page-by-page
    via getRowsRequest events, which are handled by the serve_grid_rows
    callback in cb_grid.py (CBN1 — MATCH pattern).
    The component id MUST be {"type": "pa-grid", "table": table_name}
    for the MATCH callback to find it.

    Parameters
    ----------
    df : DataFrame or None
        The data to display.  If None or empty, returns a "No data" Text.
    page_size : int
        Number of rows per AG Grid page.
    table_name : str or None
        Table key (e.g. "node", "customer").  Required for server-side mode.

    Returns
    -------
    Dash component
        dag.AgGrid  or  dmc.Center("No data…")
    """
    if df is None or len(df) == 0:
        return dmc.Center(
            dmc.Text("No data", c="dimmed", size="sm"),
            style={"minHeight": "50px"},
        )

    # Build column definitions — common to both modes
    # v16.25 T3: display-name overrides for data columns
    _HEADER_RENAMES = {
        "node_type":  "Node Type 1",   # entity category (e.g. Account, Shell)
        "node_type1": "Node Type 2",   # Internal / External classification
    }
    columns = [
        {
            "field": c,
            "headerName": _HEADER_RENAMES.get(c, c.replace("_", " ").title()),
            "sortable": True,
            "filter": True,
            "resizable": True,
            "minWidth": 90,
        }
        for c in df.columns
    ]

    if table_name and len(df) >= _SS_THRESHOLD:
        # ── SERVER-SIDE grid: only column defs sent; rows fetched on demand ─
        # getRowsRequest fires when the grid mounts — CBN1 (serve_grid_rows)
        # in cb_grid.py responds to it via MATCH on {"type": "pa-grid", "table": ...}
        block_size = min(max(page_size * 10, 100), 500)
        return dag.AgGrid(
            id={"type": "pa-grid", "table": table_name},
            columnDefs=columns,
            rowModelType="serverSide",
            cacheBlockSize=block_size,
            maxBlocksInCache=5,
            defaultColDef={"flex": 1, "minWidth": 70},
            dashGridOptions={
                "animateRows":              True,
                "pagination":               True,
                "paginationPageSize":       page_size,
                "paginationPageSizeSelector": [25, 50, 100, 250, 500],
                "domLayout":                "autoHeight",
            },
            style={"height": None, **AG_GRID_STYLE},
            className="ag-theme-alpine-dark",
        )
    else:
        # ── CLIENT-SIDE grid: all rows embedded in the component ──────────
        return dag.AgGrid(
            rowData=df.to_dict("records"),
            columnDefs=columns,
            defaultColDef={"flex": 1, "minWidth": 70},
            dashGridOptions={
                "animateRows":              True,
                "pagination":               True,
                "paginationPageSize":       page_size,
                "paginationPageSizeSelector": [5, 10, 25, 50, 100],
                "domLayout":                "autoHeight",
            },
            style={"height": None, **AG_GRID_STYLE},
            className="ag-theme-alpine-dark",
        )


# ═══════════════════════════════════════════════════════════════════════════
# UPLOAD CARD BUILDER
# ═══════════════════════════════════════════════════════════════════════════

def _build_upload_card(key: str, icon: str, color: str, desc: str):
    """
    Build a single drag-and-drop upload zone card.

    Creates a dcc.Upload component wrapped in a styled Paper card with:
      - Icon + table name label
      - Short description text
      - A badge div (id="upload-badge-{key}") that callbacks update to
        show "N rows" after a successful upload.

    Parameters
    ----------
    key   : str   — table key, e.g. "node", "customer" (used in component ids)
    icon  : str   — MDI icon string for DashIconify
    color : str   — hex accent colour
    desc  : str   — short description shown under the table name

    Returns
    -------
    dmc.Stack
        Card component ready to place in a dmc.SimpleGrid.
    """
    return dmc.Stack(
        [
            dcc.Upload(
                children=dmc.Paper(
                    [
                        dmc.Stack(
                            [
                                DashIconify(icon=icon, width=18, color=color),
                                dmc.Text(
                                    key.replace("_", " ").title(),
                                    size="xs", fw=600, c="white", ta="center",
                                ),
                                dmc.Text(
                                    desc, size="10px", c="dimmed", ta="center", lh=1.2
                                ),
                            ],
                            gap=2,
                            align="center",
                        ),
                    ],
                    p="xs",
                    radius="md",
                    style={
                        "backgroundColor": "rgba(0,0,0,0.4)",
                        "border":          f"1px dashed {color}60",
                        "cursor":          "pointer",
                        "minHeight":       "72px",
                        "display":         "flex",
                        "alignItems":      "center",
                        "justifyContent":  "center",
                    },
                ),
                id=f"upload-{key}",
                accept=ACCEPTED_FORMATS,
                style={"width": "100%"},
            ),
            # Badge is updated by upload_files callback (cb_upload.py)
            html.Div(
                id=f"upload-badge-{key}",
                children=dmc.Badge(
                    "empty", color="gray", variant="dot", size="xs", fullWidth=True
                ),
            ),
        ],
        gap=2,
    )


# ═══════════════════════════════════════════════════════════════════════════
# TABLE PREVIEW CARD BUILDER
# ═══════════════════════════════════════════════════════════════════════════

def _build_table_card(
    name: str,
    icon: str,
    color: str,
    desc: str,
    df: pd.DataFrame | None = None,
    page_size: int = 5,
):
    """
    Build a full table preview card with header, AG Grid, and action buttons.

    OPTIONAL TABLE HANDLING:
    If df is None or has 0 rows, the card is still rendered but shows a
    "No data loaded" placeholder instead of a grid.  Download and Delete
    buttons are disabled when there is no data.

    Parameters
    ----------
    name      : str       — table key, e.g. "node"
    icon      : str       — MDI icon string
    color     : str       — hex accent colour
    desc      : str       — unused here but kept for API consistency
    df        : DataFrame or None — the table data (None = not loaded)
    page_size : int       — AG Grid page size

    Returns
    -------
    dmc.Paper
        Complete card component.
    """
    rows     = len(df) if df is not None else 0
    has_data = rows > 0
    is_graph  = name in GRAPH_TABLE_KEYS
    tag_color = "cyan"   if is_graph else "orange"
    tag_label = "Graph DB" if is_graph else "Legacy DB"

    # ── Grid or empty placeholder ─────────────────────────────────────────
    # pass table_name so _make_ag_grid can choose server-side mode for large tables
    grid = (
        _make_ag_grid(df, page_size, table_name=name)
        if has_data
        else dmc.Center(
            dmc.Stack(
                [
                    DashIconify(icon="mdi:table-off", width=20, color="#30363D"),
                    dmc.Text("No data loaded", size="xs", c="dimmed"),
                ],
                align="center",
                gap=4,
            ),
            style={"minHeight": "50px"},
        )
    )

    return dmc.Paper(
        [
            # ── Card header: name + badges + action buttons ───────────────
            dmc.Group(
                [
                    dmc.Group(
                        [
                            DashIconify(icon=icon, width=18, color=color),
                            dmc.Text(name.replace("_", " ").title(), fw=600, c="white", size="sm"),
                            dmc.Badge(tag_label,        color=tag_color, variant="outline", size="xs"),
                            dmc.Badge(
                                f"{rows:,} rows",
                                color="green" if has_data else "gray",
                                variant="light",
                                size="xs",
                            ),
                        ],
                        gap="xs",
                    ),
                    dmc.Group(
                        [
                            # Download button — disabled when no data
                            dmc.ActionIcon(
                                DashIconify(icon="mdi:download", width=16),
                                id={"type": "btn-dl-tbl", "table": name},
                                variant="subtle",
                                color="cyan",
                                size="sm",
                                disabled=not has_data,
                            ),
                            # Delete button — disabled when no data
                            dmc.ActionIcon(
                                DashIconify(icon="mdi:delete-outline", width=16),
                                id={"type": "btn-del-tbl", "table": name},
                                variant="subtle",
                                color="red",
                                size="sm",
                                disabled=not has_data,
                            ),
                        ],
                        gap=4,
                    ),
                ],
                justify="space-between",
                mb="xs",
            ),
            # ── AG Grid / placeholder ─────────────────────────────────────
            grid,
        ],
        p="sm",
        radius="lg",
        className="glass-card",
        mb="sm",
        style={"border": f"1px solid {color}20"},
    )


# ═══════════════════════════════════════════════════════════════════════════
# SPLIT TABLE CARDS (Graph section + Legacy section)
# ═══════════════════════════════════════════════════════════════════════════

def _build_split_table_cards(
    tables: dict | None,
    page_size: int = 5,
) -> tuple[list, list, int, int]:
    """
    Build ALL 13 table cards split into two lists (graph and legacy).

    OPTIONAL TABLE HANDLING:
    Tables that are absent from the `tables` dict are rendered as empty
    placeholder cards (see _build_table_card with df=None).

    Parameters
    ----------
    tables    : dict or None   — mapping of table_name → DataFrame
    page_size : int            — AG Grid page size to use in all cards

    Returns
    -------
    (graph_cards, legacy_cards, total_rows, n_loaded)
      graph_cards  : list of dmc.Paper — one per GRAPH_TABLE_DEFS entry (5)
      legacy_cards : list of dmc.Paper — one per LEGACY_TABLE_DEFS entry (8)
      total_rows   : int — sum of all rows across loaded tables
      n_loaded     : int — count of tables with at least 1 row
    """
    graph_cards  = []
    legacy_cards = []
    total        = 0
    loaded       = 0

    # ── Graph tables (5) — node + edge required; others optional ──────────
    for name, icon, color, desc in GRAPH_TABLE_DEFS:
        # Safely get DataFrame — returns None if table is absent
        df = tables.get(name) if tables else None
        rows = len(df) if df is not None else 0
        total  += rows
        if rows > 0:
            loaded += 1
        graph_cards.append(_build_table_card(name, icon, color, desc, df, page_size))

    # ── Legacy tables (8) — customer + transaction primary; others optional
    for name, icon, color, desc in LEGACY_TABLE_DEFS:
        df = tables.get(name) if tables else None
        rows = len(df) if df is not None else 0
        total  += rows
        if rows > 0:
            loaded += 1
        legacy_cards.append(_build_table_card(name, icon, color, desc, df, page_size))

    return graph_cards, legacy_cards, total, loaded


def _build_all_table_cards(
    tables: dict | None,
    page_size: int = 5,
) -> tuple[list, int, int]:
    """
    Build all 13 table cards as a single flat list.

    Kept for backward compatibility.  New code should prefer
    _build_split_table_cards() which returns graph and legacy lists
    separately (matching the two DOM containers on the page).

    Returns
    -------
    (cards, total_rows, n_loaded)
    """
    cards = []
    total = 0
    loaded = 0
    for name, icon, color, desc in ALL_TABLE_DEFS:
        df = tables.get(name) if tables else None
        rows = len(df) if df is not None else 0
        total += rows
        if rows > 0:
            loaded += 1
        cards.append(_build_table_card(name, icon, color, desc, df, page_size))
    return cards, total, loaded


# ═══════════════════════════════════════════════════════════════════════════
# PIPELINE SUMMARY BUILDER
# ═══════════════════════════════════════════════════════════════════════════

def _build_pipeline_summary(tables: dict | None):
    """
    Build the summary chip group shown above the Push to Pipeline button.

    Shows:
      - Count of graph tables loaded (cyan badge)
      - Count of legacy tables loaded (orange badge)
      - Total row count (green badge)
      - Individual table name badges

    OPTIONAL TABLE HANDLING: tables can be None, empty, or sparse.

    Returns
    -------
    dmc component (Text or Stack)
    """
    if not tables:
        return dmc.Text(
            "No tables loaded — generate or upload data first", c="dimmed", size="sm"
        )

    graph_loaded  = [k for k in GRAPH_TABLE_KEYS  if k in tables and len(tables[k]) > 0]
    legacy_loaded = [k for k in LEGACY_TABLE_KEYS if k in tables and len(tables[k]) > 0]
    total_rows    = sum(len(df) for df in tables.values() if df is not None)

    # Individual table badges
    chips = (
        [dmc.Badge(k.replace("_", " ").title(), color="cyan",   variant="light", size="xs") for k in graph_loaded]
        + [dmc.Badge(k.replace("_", " ").title(), color="orange", variant="light", size="xs") for k in legacy_loaded]
    )

    return dmc.Stack(
        [
            dmc.Group(
                [
                    dmc.Badge(f"{len(graph_loaded)} graph tables",  color="cyan",   variant="filled", size="sm"),
                    dmc.Badge(f"{len(legacy_loaded)} legacy tables", color="orange", variant="filled", size="sm"),
                    dmc.Badge(f"{total_rows:,} total rows",          color="green",  variant="light",  size="sm"),
                ],
                gap="xs",
            ),
            dmc.Group(chips, gap=4, style={"flexWrap": "wrap"}),
        ],
        gap="xs",
    )


# ═══════════════════════════════════════════════════════════════════════════
# PIPELINE STAGE DISPLAY BUILDER
# ═══════════════════════════════════════════════════════════════════════════

def _build_pipeline_stages_display(status: dict | None = None):
    """
    Build the visual pipeline stage card row.

    Each stage card shows an icon, stage ID, stage name, and a
    status indicator (pending / running / done / failed).

    Parameters
    ----------
    status : dict or None
        Mapping of stage_id → status string.
        If None or a stage_id is absent, that stage is shown as "pending".

    Returns
    -------
    dmc.Group
        Row of dmc.Paper stage cards.
    """
    _STATUS_ICON = {
        "pending": "mdi:circle-outline",
        "running": "mdi:loading",
        "done":    "mdi:check-circle",
        "failed":  "mdi:alert-circle",
    }
    _STATUS_COLOR = {
        "pending": "#30363D",
        "running": "#FFD600",
        "done":    "#00E676",
        "failed":  "#FF1744",
    }
    items = []
    for sid, sname, sicon, scolor in PIPELINE_STAGES:
        st = "pending"
        if status and sid in status:
            st = status[sid]

        items.append(
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            DashIconify(icon=sicon, width=18, color=scolor),
                            dmc.Text(f"[{sid}]", size="xs", c="dimmed", fw=600),
                            dmc.Text(sname, size="xs", fw=500, c="white"),
                        ],
                        gap=4,
                    ),
                    dmc.Group(
                        [
                            DashIconify(
                                icon=_STATUS_ICON.get(st, "mdi:circle-outline"),
                                width=14,
                                color=_STATUS_COLOR.get(st, "#30363D"),
                            ),
                            dmc.Text(st, size="xs", c=_STATUS_COLOR.get(st, "#30363D")),
                        ],
                        gap=4,
                        mt=4,
                    ),
                ],
                p="xs",
                radius="md",
                style={
                    "backgroundColor": "rgba(0,0,0,0.3)",
                    "border":          f"1px solid {scolor}30",
                    "flex":            "1",
                    "minWidth":        "120px",
                },
            ),
        )
    return dmc.Group(items, gap="xs", style={"flexWrap": "wrap"})


# ═══════════════════════════════════════════════════════════════════════════
# QUALITY PROFILE BUILDER
# ═══════════════════════════════════════════════════════════════════════════

def _build_quality_profile(tables: dict | None):
    """
    Build compact quality metric cards for all LOADED tables.

    Each card shows:
      - Table name + Graph/Legacy badge
      - Row count, column count, null count, null percentage

    Tables with no data (None or 0 rows) are SKIPPED — this is the
    correct behaviour when only a subset of tables is present.

    Returns
    -------
    dmc component (Text placeholder or SimpleGrid of Paper cards)
    """
    if not tables:
        return dmc.Text("No data loaded", c="dimmed", size="sm")

    profile_cards = []
    for name, icon, color, desc in ALL_TABLE_DEFS:
        df = tables.get(name)
        # Skip absent / empty tables — they are optional
        if df is None or len(df) == 0:
            continue

        n_rows   = len(df)
        n_cols   = len(df.columns)
        n_nulls  = int(df.isnull().sum().sum())
        n_cells  = n_rows * n_cols
        null_pct = (n_nulls / n_cells * 100) if n_cells > 0 else 0.0

        is_graph   = name in GRAPH_TABLE_KEYS
        tag        = "Graph" if is_graph else "Legacy"
        tag_color  = "cyan"  if is_graph else "orange"

        profile_cards.append(
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            DashIconify(icon=icon, width=16, color=color),
                            dmc.Text(name.replace("_", " ").title(), fw=600, c="white", size="xs"),
                            dmc.Badge(tag, color=tag_color, variant="outline", size="xs"),
                        ],
                        gap=4,
                        mb="xs",
                    ),
                    dmc.SimpleGrid(
                        cols=4,
                        spacing=4,
                        children=[
                            dmc.Stack([dmc.Text("Rows",  size="10px", c="dimmed"), dmc.Text(f"{n_rows:,}", size="xs", fw=700, c="white")], gap=0, align="center"),
                            dmc.Stack([dmc.Text("Cols",  size="10px", c="dimmed"), dmc.Text(str(n_cols), size="xs", fw=700, c="white")],   gap=0, align="center"),
                            dmc.Stack([dmc.Text("Nulls", size="10px", c="dimmed"), dmc.Text(f"{n_nulls:,}", size="xs", fw=700, c="#FF1744" if null_pct > 5 else "white")], gap=0, align="center"),
                            dmc.Stack([dmc.Text("Null%", size="10px", c="dimmed"), dmc.Text(f"{null_pct:.1f}%", size="xs", fw=700, c="#FF1744" if null_pct > 5 else "#00E676")], gap=0, align="center"),
                        ],
                    ),
                ],
                p="sm",
                radius="md",
                style={
                    "backgroundColor": "rgba(0,0,0,0.3)",
                    "border":          f"1px solid {color}30",
                },
            ),
        )

    if not profile_cards:
        return dmc.Text("No tables loaded", c="dimmed", size="sm")

    return dmc.SimpleGrid(
        cols={"base": 1, "sm": 2, "md": 3, "lg": 5},
        spacing="sm",
        children=profile_cards,
    )


# ═══════════════════════════════════════════════════════════════════════════
# MEMORY FORMATTER
# ═══════════════════════════════════════════════════════════════════════════

def _fmt_memory(mem_bytes: int) -> str:
    """
    Convert a byte count to a human-readable string.

    Examples:
      1_000_000 → "1.0 MB"
      50_000    → "50 KB"
      800       → "800 B"

    Parameters
    ----------
    mem_bytes : int
        Memory size in bytes (from df.memory_usage(deep=True).sum()).

    Returns
    -------
    str
    """
    if mem_bytes >= 1_000_000:
        return f"{mem_bytes / 1_000_000:.1f} MB"
    if mem_bytes >= 1_000:
        return f"{mem_bytes / 1_000:.0f} KB"
    return f"{mem_bytes} B"


# ═══════════════════════════════════════════════════════════════════════════
# COMPREHENSIVE DATA SUMMARY BUILDER
# ═══════════════════════════════════════════════════════════════════════════

def _build_data_summary(tables: dict | None, source_mode: str = "sample"):
    """
    Build the full Data Summary & Analytics section.

    Contains:
      1. 6 KPI stat cards (tables loaded, total rows, columns,
         null rate, memory, data source mode)
      2. Horizontal bar chart — row distribution by table (Plotly)
      3. Donut chart — graph vs legacy composition (Plotly)
      4. Stacked bar chart — column types per table (Plotly)
      5. Per-table detail cards with completeness ring, dtype breakdown,
         quality badge, and relative-size progress bar

    OPTIONAL TABLE HANDLING:
    Only loaded (non-None, non-empty) tables contribute to all
    charts and stats.  Missing tables are simply not represented.

    Parameters
    ----------
    tables      : dict or None — mapping table_name → DataFrame
    source_mode : str          — "sample" or "actual" (affects mode badge colour)

    Returns
    -------
    dmc component (Center placeholder or full dmc.Stack summary)
    """
    if not tables:
        return dmc.Center(
            dmc.Stack(
                [
                    DashIconify(icon="mdi:chart-box-outline", width=48, color="#30363D"),
                    dmc.Text("No Data Loaded", fw=700, c="dimmed", size="lg"),
                    dmc.Text(
                        "Generate sample data or upload actual files to see summary analytics",
                        c="dimmed", size="sm", ta="center", maw=400,
                    ),
                ],
                align="center",
                gap="sm",
            ),
            style={"minHeight": "250px"},
        )

    # ── Filter to loaded tables only ─────────────────────────────────────
    loaded_tables = {k: v for k, v in tables.items() if v is not None and len(v) > 0}
    n_loaded = len(loaded_tables)
    if n_loaded == 0:
        return dmc.Center(
            dmc.Stack(
                [
                    DashIconify(icon="mdi:table-off", width=40, color="#30363D"),
                    dmc.Text("All tables are empty", c="dimmed", size="sm"),
                ],
                align="center",
                gap="xs",
            ),
            style={"minHeight": "200px"},
        )

    graph_loaded  = {k: v for k, v in loaded_tables.items() if k in GRAPH_TABLE_KEYS}
    legacy_loaded = {k: v for k, v in loaded_tables.items() if k in LEGACY_TABLE_KEYS}

    total_rows   = sum(len(df) for df in loaded_tables.values())
    total_cols   = sum(len(df.columns) for df in loaded_tables.values())
    total_cells  = sum(len(df) * len(df.columns) for df in loaded_tables.values())
    total_nulls  = sum(int(df.isnull().sum().sum()) for df in loaded_tables.values())
    null_rate    = (total_nulls / total_cells * 100) if total_cells > 0 else 0.0
    total_memory = sum(df.memory_usage(deep=False).sum() for df in loaded_tables.values())  # deep=False: fast estimate, avoids traversing millions of string objects

    # ── 1. KPI Stat Cards ────────────────────────────────────────────────
    mode_color  = "#00D4FF" if source_mode == "sample" else "#FF9800"
    mode_icon   = "mdi:flask-outline" if source_mode == "sample" else "mdi:file-upload"
    mode_label  = "Sample" if source_mode == "sample" else "Actual"
    null_color  = "#00E676" if null_rate < 2 else ("#FFD600" if null_rate < 5 else "#FF1744")

    kpi_data = [
        ("mdi:table-multiple",      "#00D4FF",  f"{n_loaded}",              "Tables Loaded",   f"of 13 ({n_loaded*100//13}%)"),
        ("mdi:format-list-numbered","#00E676",  f"{total_rows:,}",          "Total Rows",       f"across {n_loaded} tables"),
        ("mdi:view-column",         "#9D4EDD",  f"{total_cols}",            "Total Columns",    f"~{total_cols//n_loaded} avg/table"),
        ("mdi:alert-decagram",      null_color, f"{null_rate:.1f}%",        "Null Rate",        f"{total_nulls:,} null values"),
        ("mdi:memory",              "#E040FB",  _fmt_memory(total_memory),  "Memory Est.",      f"{total_cells:,} data cells"),
        (mode_icon,                 mode_color, mode_label,                 "Data Source",      f"{len(graph_loaded)} graph + {len(legacy_loaded)} legacy"),
    ]

    kpi_cards = [
        dmc.Paper(
            [
                dmc.Stack(
                    [
                        DashIconify(icon=icon, width=24, color=color),
                        dmc.Text(value, fw=800, size="xl", c="white",
                                 style={"lineHeight": 1, "letterSpacing": "-0.5px"}),
                        dmc.Text(label,    fw=600, size="xs", c=color),
                        dmc.Text(subtitle, size="10px", c="dimmed", lh=1.2),
                    ],
                    align="center",
                    gap=3,
                ),
            ],
            p="md",
            radius="lg",
            style={
                "backgroundColor": "rgba(0,0,0,0.35)",
                "border":          f"1px solid {color}30",
                "minWidth":        "110px",
                "flex":            "1",
                "background":      f"linear-gradient(180deg, rgba(0,0,0,0.5) 0%, {color}08 100%)",
            },
        )
        for icon, color, value, label, subtitle in kpi_data
    ]

    # ── 2. Row Distribution Bar Chart ────────────────────────────────────
    tbl_names, tbl_rows, bar_colors = [], [], []
    for name, _, color, _ in reversed(ALL_TABLE_DEFS):
        df = loaded_tables.get(name)
        if df is not None:
            tbl_names.append(name.replace("_", " ").title())
            tbl_rows.append(len(df))
            bar_colors.append(color)

    bar_fig = go.Figure(
        go.Bar(
            y=tbl_names, x=tbl_rows,
            orientation="h",
            marker=dict(color=bar_colors, line=dict(color="rgba(255,255,255,0.1)", width=1)),  # cornerradius removed (triggers OneDrive lazy-import crash)
            text=[f"{r:,}" for r in tbl_rows],
            textposition="auto",
            textfont=dict(color="white", size=10, family="Inter"),
            hovertemplate="<b>%{y}</b><br>Rows: %{x:,}<extra></extra>",
        )
    )
    bar_fig.update_layout(
        **CHART_LAYOUT,
        title=dict(text="Row Distribution by Table", font=dict(size=13, color="#58A6FF")),
        xaxis=dict(showgrid=True, gridcolor="#21262D", gridwidth=1, zeroline=False, title=None, tickfont=dict(color="#8B949E")),
        yaxis=dict(showgrid=False, title=None, tickfont=dict(color="#C9D1D9", size=10)),
        height=max(220, len(tbl_names) * 30 + 60),
        showlegend=False,
    )

    # ── 3. Composition Donut Chart ───────────────────────────────────────
    graph_rows  = sum(len(df) for df in graph_loaded.values())
    legacy_rows = sum(len(df) for df in legacy_loaded.values())
    donut_fig = go.Figure(
        go.Pie(
            labels=["Graph DB", "Legacy DB"],
            values=[graph_rows, legacy_rows],
            hole=0.65,
            marker=dict(colors=["#00D4FF", "#FF9800"], line=dict(color="#0D1117", width=2)),
            textinfo="label+percent",
            textfont=dict(color="white", size=11),
            hovertemplate="<b>%{label}</b><br>Rows: %{value:,}<br>Share: %{percent}<extra></extra>",
        )
    )
    donut_fig.update_layout(
        **CHART_LAYOUT,
        title=dict(text="Graph vs Legacy Composition", font=dict(size=13, color="#58A6FF")),
        height=320,
        annotations=[dict(
            text=f"{total_rows:,}<br><span style='font-size:10px;color:#8B949E'>rows</span>",
            x=0.5, y=0.5, font=dict(size=18, color="white"), showarrow=False,
        )],
    )

    # ── 4. Column Types Stacked Bar ───────────────────────────────────────
    type_names, n_numeric, n_text, n_datetime, n_other = [], [], [], [], []
    for name, _, _, _ in ALL_TABLE_DEFS:
        df = loaded_tables.get(name)
        if df is not None:
            type_names.append(name.replace("_", " ").title())
            dtypes = df.dtypes
            num  = int(dtypes.apply(lambda d: pd.api.types.is_numeric_dtype(d)).sum())
            txt  = int(dtypes.apply(lambda d: pd.api.types.is_string_dtype(d) or pd.api.types.is_object_dtype(d)).sum())
            dtt  = int(dtypes.apply(lambda d: pd.api.types.is_datetime64_any_dtype(d)).sum())
            n_numeric.append(num); n_text.append(txt); n_datetime.append(dtt)
            n_other.append(len(df.columns) - num - txt - dtt)

    dtype_fig = go.Figure()
    for vals, name_label, color in [
        (n_numeric,  "Numeric",     "#00D4FF"),
        (n_text,     "Text/Object", "#FF9800"),
        (n_datetime, "DateTime",    "#E040FB"),
        (n_other,    "Other",       "#78909C"),
    ]:
        if sum(vals) > 0:
            dtype_fig.add_trace(go.Bar(
                x=type_names, y=vals, name=name_label,
                marker=dict(color=color),  # cornerradius removed (triggers OneDrive lazy-import crash)
                hovertemplate=f"<b>%{{x}}</b><br>{name_label}: %{{y}}<extra></extra>",
            ))
    dtype_fig.update_layout(
        **CHART_LAYOUT,
        title=dict(text="Column Types per Table", font=dict(size=13, color="#58A6FF")),
        barmode="stack",
        xaxis=dict(showgrid=False, title=None, tickfont=dict(color="#C9D1D9", size=9), tickangle=-35),
        yaxis=dict(showgrid=True, gridcolor="#21262D", title=None, tickfont=dict(color="#8B949E")),
        height=280,
    )
    dtype_fig.update_layout(legend=dict(orientation="h", y=1.15, x=0.5, xanchor="center"))

    # ── 5. Per-Table Detail Cards ─────────────────────────────────────────
    max_rows = max((len(df) for df in loaded_tables.values()), default=1)
    detail_cards = []
    for name, icon, color, desc in ALL_TABLE_DEFS:
        df = loaded_tables.get(name)
        if df is None:
            continue  # Skip tables that aren't present — they are optional

        n_rows   = len(df)
        n_cols   = len(df.columns)
        n_nulls  = int(df.isnull().sum().sum())
        n_cells  = n_rows * n_cols
        null_pct     = (n_nulls / n_cells * 100) if n_cells > 0 else 0
        completeness = 100 - null_pct
        mem          = df.memory_usage(deep=False).sum()  # deep=False: fast estimate
        row_pct      = (n_rows / max_rows * 100) if max_rows > 0 else 0

        is_graph  = name in GRAPH_TABLE_KEYS
        tag_color = "cyan"  if is_graph else "orange"
        tag_label = "Graph" if is_graph else "Legacy"

        dtypes    = df.dtypes
        num_count = int(dtypes.apply(lambda d: pd.api.types.is_numeric_dtype(d)).sum())
        txt_count = int(dtypes.apply(lambda d: pd.api.types.is_string_dtype(d) or pd.api.types.is_object_dtype(d)).sum())
        dt_count  = int(dtypes.apply(lambda d: pd.api.types.is_datetime64_any_dtype(d)).sum())

        q_color = "#00E676" if null_pct < 1 else ("#FFD600" if null_pct < 5 else "#FF1744")
        q_label = "Excellent" if null_pct < 1 else ("Good" if null_pct < 5 else "Needs Review")

        detail_cards.append(
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            dmc.Group([DashIconify(icon=icon, width=20, color=color), dmc.Text(name.replace("_", " ").title(), fw=700, c="white", size="sm")], gap=6),
                            dmc.Badge(tag_label, color=tag_color, variant="filled", size="xs"),
                        ],
                        justify="space-between",
                        mb="sm",
                    ),
                    dmc.SimpleGrid(
                        cols=3, spacing=6, mb="sm",
                        children=[
                            dmc.Paper([dmc.Text("Rows",    size="10px", c="dimmed", ta="center"), dmc.Text(f"{n_rows:,}", fw=800, size="md", c="white",  ta="center")], p=6, radius="md", style={"backgroundColor": "rgba(0,212,255,0.06)",  "border": "1px solid rgba(0,212,255,0.12)"}),
                            dmc.Paper([dmc.Text("Columns", size="10px", c="dimmed", ta="center"), dmc.Text(str(n_cols),   fw=800, size="md", c="white",  ta="center")], p=6, radius="md", style={"backgroundColor": "rgba(157,78,221,0.06)", "border": "1px solid rgba(157,78,221,0.12)"}),
                            dmc.Paper([dmc.Text("Nulls",   size="10px", c="dimmed", ta="center"), dmc.Text(f"{n_nulls:,}",fw=800, size="md", c=q_color if n_nulls > 0 else "white", ta="center")], p=6, radius="md", style={"backgroundColor": "rgba(255,23,68,0.06)" if n_nulls > 0 else "rgba(0,230,118,0.06)", "border": f"1px solid {q_color}20"}),
                        ],
                    ),
                    dmc.Text("Relative Size", size="10px", c="dimmed", mb=2),
                    dmc.Progress(value=row_pct, color=color, size="sm", radius="xl", style={"backgroundColor": "rgba(255,255,255,0.05)"}),
                    dmc.Group(
                        [
                            dmc.RingProgress(
                                sections=[{"value": completeness, "color": q_color}],
                                size=56, thickness=5, roundCaps=True,
                                label=dmc.Text(f"{completeness:.0f}%", size="10px", fw=700, c=q_color, ta="center"),
                            ),
                            dmc.Stack(
                                [
                                    dmc.Group([dmc.Badge(f"int/float: {num_count}", color="cyan",   variant="dot", size="xs"), dmc.Badge(f"text: {txt_count}", color="orange", variant="dot", size="xs")], gap=4),
                                    dmc.Group([dmc.Badge(f"datetime: {dt_count}",   color="grape",  variant="dot", size="xs"), dmc.Badge(_fmt_memory(mem), color="gray", variant="dot", size="xs")], gap=4),
                                ],
                                gap=4,
                            ),
                        ],
                        gap="sm",
                        mt="sm",
                    ),
                    dmc.Group(
                        [
                            DashIconify(icon="mdi:shield-check" if null_pct < 5 else "mdi:shield-alert", width=14, color=q_color),
                            dmc.Text(q_label, size="10px", c=q_color, fw=600),
                            dmc.Text(f"| {null_pct:.1f}% null", size="10px", c="dimmed"),
                        ],
                        gap=4,
                        mt="xs",
                    ),
                ],
                p="md",
                radius="lg",
                style={
                    "backgroundColor": "rgba(0,0,0,0.3)",
                    "border":          f"1px solid {color}25",
                    "background":      f"linear-gradient(180deg, rgba(0,0,0,0.4) 0%, {color}06 100%)",
                },
            ),
        )

    # ── Assemble full summary ─────────────────────────────────────────────
    return dmc.Stack(
        [
            # Row 1: KPI cards
            dmc.Group(kpi_cards, gap="sm", style={"flexWrap": "wrap", "justifyContent": "center"}),
            # Row 2: Bar + Donut charts
            dmc.Grid(
                [
                    dmc.GridCol([dmc.Paper([dcc.Graph(figure=bar_fig, config={"displayModeBar": False}, style={"width": "100%"})], p="sm", radius="lg", style={"backgroundColor": "rgba(0,0,0,0.25)", "border": "1px solid #21262D"})], span={"base": 12, "md": 7}),
                    dmc.GridCol([dmc.Paper([dcc.Graph(figure=donut_fig, config={"displayModeBar": False}, style={"width": "100%"})], p="sm", radius="lg", style={"backgroundColor": "rgba(0,0,0,0.25)", "border": "1px solid #21262D"})], span={"base": 12, "md": 5}),
                ],
                gutter="sm",
            ),
            # Row 3: Column types chart
            dmc.Paper([dcc.Graph(figure=dtype_fig, config={"displayModeBar": False}, style={"width": "100%"})], p="sm", radius="lg", style={"backgroundColor": "rgba(0,0,0,0.25)", "border": "1px solid #21262D"}),
            # Per-table section header
            dmc.Group(
                [
                    DashIconify(icon="mdi:view-grid-plus-outline", width=18, color="#58A6FF"),
                    dmc.Text("Per-Table Details", fw=700, c="white", size="sm"),
                    dmc.Badge(f"{n_loaded} tables", color="blue", variant="light", size="xs"),
                ],
                gap="xs",
            ),
            # Per-table detail cards grid (5 per row on large screens)
            dmc.SimpleGrid(cols={"base": 1, "sm": 2, "md": 3, "lg": 5}, spacing="sm", children=detail_cards),
        ],
        gap="md",
    )
