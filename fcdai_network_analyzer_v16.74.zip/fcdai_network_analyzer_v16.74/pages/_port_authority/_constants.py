"""
pages/port_authority/_constants.py
=====================================
PURPOSE
-------
All static constants used across the Port Authority package:
  - AG Grid / Plotly visual themes
  - Table definitions (name, icon, color, description)
  - Upload slot definitions
  - Pipeline stage definitions
  - Accepted file upload formats

WHY SEPARATE?
-------------
Keeping these pure-data constants isolated means:
 1. Any module that needs a colour or a table list just imports this file
    without dragging in Dash callbacks or stateful code.
 2. Easy to change a colour, rename a table, or add an upload slot in one
    place — all modules automatically use the updated value.
 3. New team members can understand the domain vocabulary just by reading
    this file.

IMPORT DEPENDENCY CHAIN
-----------------------
_constants.py imports NOTHING from this package — it is a pure leaf module.
"""

from __future__ import annotations

# ═══════════════════════════════════════════════════════════════════════════
# AG GRID VISUAL THEME
# ═══════════════════════════════════════════════════════════════════════════
# CSS custom-property overrides for the "ag-theme-alpine-dark" class.
# Applied via the `style` prop on every dag.AgGrid component so that all
# grids on the Port Authority page share a consistent dark appearance.
AG_GRID_STYLE: dict = {
    "--ag-background-color":       "#0D1117",
    "--ag-header-background-color":"#161B22",
    "--ag-odd-row-background-color":"#0D1117",
    "--ag-row-hover-color":         "#1C2333",
    "--ag-header-foreground-color": "#58A6FF",
    "--ag-foreground-color":        "#C9D1D9",
    "--ag-border-color":            "#21262D",
    "--ag-row-border-color":        "#21262D",
    "--ag-font-size":               "12px",
    "--ag-grid-size":               "4px",
}

# ═══════════════════════════════════════════════════════════════════════════
# PLOTLY DARK CHART LAYOUT (shared base for all charts on this page)
# ═══════════════════════════════════════════════════════════════════════════
# Use as: fig.update_layout(**CHART_LAYOUT, ...)
CHART_LAYOUT: dict = dict(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(0,0,0,0.15)",
    font=dict(color="#C9D1D9", size=11, family="Inter, sans-serif"),
    margin=dict(l=5, r=5, t=35, b=5),
    legend=dict(
        bgcolor="rgba(0,0,0,0.3)",
        bordercolor="#21262D",
        borderwidth=1,
        font=dict(color="#C9D1D9", size=10),
    ),
)

# ═══════════════════════════════════════════════════════════════════════════
# TABLE DEFINITIONS
# ═══════════════════════════════════════════════════════════════════════════
# Each entry is a 4-tuple:  (table_name, icon_id, hex_color, description)
#
# table_name  — must match the key used in _PA_DATA_STORE and in the
#               generate_all_samples() output dict.
# icon_id     — MDI icon string used with DashIconify (e.g. "mdi:graph")
# hex_color   — accent colour for this table's badge, border, etc.
# description — short human-readable label shown in upload cards / tooltips
#
# ── Graph DB (5 tables) ────────────────────────────────────────────────────
# In a Graph DB pipeline, "node" and "edge" are REQUIRED.
# relationship_edge, shared_attribute, temporal are OPTIONAL — they may not
# exist in all datasets.  All helpers that loop over GRAPH_TABLE_DEFS must
# guard for df=None gracefully.
GRAPH_TABLE_DEFS: list[tuple] = [
    ("node",               "mdi:circle-outline",   "#00D4FF", "Graph nodes (persons, entities, accounts)"),
    ("edge",               "mdi:arrow-right-bold", "#00E676", "Transaction edges between nodes"),
    ("relationship_edge",  "mdi:link-variant",     "#9D4EDD", "Ownership / control relationships"),
    ("shared_attribute",   "mdi:share-variant",    "#FF9800", "Shared addresses, phones, IPs"),
    ("temporal",           "mdi:timeline-clock",   "#E040FB", "Temporal ledger: node_id | date | value | dr_cr | counterparty_id | currency | country_code | txn_type_code | channel_code"),
]

# ── Legacy / Transaction DB (8 tables) ────────────────────────────────────
# In a Legacy pipeline, "customer" and "transaction" are the PRIMARY tables.
# account, kyc, alert, case, historical, relationship are OPTIONAL.
# All helpers must treat None DataFrames as "no data for this table".
LEGACY_TABLE_DEFS: list[tuple] = [
    ("customer",     "mdi:account-group",    "#00D4FF", "Core customer profiles"),
    ("account",      "mdi:bank",             "#9D4EDD", "Customer bank accounts"),
    ("transaction",  "mdi:swap-horizontal",  "#00E676", "Financial transactions"),
    ("kyc",          "mdi:file-document",    "#FFD600", "KYC compliance records"),
    ("alert",        "mdi:alert-circle",     "#FF1744", "Money laundering alerts"),
    ("case",         "mdi:briefcase",        "#FF6D00", "Investigation cases"),
    ("historical",   "mdi:history",          "#FF9800", "Historical risk data"),
    ("relationship", "mdi:link-variant",     "#2196F3", "Customer relationships"),
]

# Combined list of ALL 13 table definitions (graph first, then legacy)
ALL_TABLE_DEFS: list[tuple] = GRAPH_TABLE_DEFS + LEGACY_TABLE_DEFS

# Fast membership sets — used to decide "is this a graph or legacy table?"
# e.g.  if name in GRAPH_TABLE_KEYS: ...   (O(1) lookup)
GRAPH_TABLE_KEYS: set[str]  = {t[0] for t in GRAPH_TABLE_DEFS}   # 5 keys
LEGACY_TABLE_KEYS: set[str] = {t[0] for t in LEGACY_TABLE_DEFS}  # 8 keys

# Colour lookup for quick access by table name
# e.g.  border_color = TABLE_COLOR_MAP.get("node", "#ffffff")
TABLE_COLOR_MAP: dict[str, str] = {t[0]: t[2] for t in ALL_TABLE_DEFS}

# ═══════════════════════════════════════════════════════════════════════════
# UPLOAD SLOT DEFINITIONS (15 total drag-drop slots)
# ═══════════════════════════════════════════════════════════════════════════
# Upload slots mirror the table definitions PLUS an "others" catch-all slot
# for graph data that doesn't fit the standard schema.
#
# The slot keys are used as:
#   - dcc.Upload id:  f"upload-{key}"
#   - badge div id:   f"upload-badge-{key}"
#   - staged table key in _PA_DATA_STORE (after successful parse)
#
# ── Graph upload slots (6) ─────────────────────────────────────────────────
GRAPH_UPLOAD_SLOTS: list[tuple] = [
    ("node",               "mdi:circle-outline",   "#00D4FF", "Graph nodes"),
    ("edge",               "mdi:arrow-right-bold", "#00E676", "Transaction edges"),
    ("relationship_edge",  "mdi:link-variant",     "#9D4EDD", "Ownership edges"),
    ("shared_attribute",   "mdi:share-variant",    "#FF9800", "Shared attributes"),
    ("temporal",           "mdi:timeline-clock",   "#E040FB", "Temporal ledger rows (dr_cr + counterparty_id schema)"),
    ("others",             "mdi:dots-horizontal",  "#78909C", "Other graph data"),
]

# ── Legacy upload slots (9) ────────────────────────────────────────────────
LEGACY_UPLOAD_SLOTS: list[tuple] = [
    ("base",         "mdi:database",      "#607D8B", "Base / custom table"),
    ("transaction",  "mdi:swap-horizontal","#00E676", "Transactions"),
    ("customer",     "mdi:account-group", "#00D4FF", "Customers"),
    ("account",      "mdi:bank",          "#9D4EDD", "Accounts"),
    ("kyc",          "mdi:file-document", "#FFD600", "KYC records"),
    ("alert",        "mdi:alert-circle",  "#FF1744", "Alerts"),
    ("case",         "mdi:briefcase",     "#FF6D00", "Cases"),
    ("historical",   "mdi:history",       "#FF9800", "Historical"),
    ("relationship", "mdi:link-variant",  "#2196F3", "Relationships"),
]

# All 15 upload slots combined (graph first, then legacy)
ALL_UPLOAD_SLOTS: list[tuple] = GRAPH_UPLOAD_SLOTS + LEGACY_UPLOAD_SLOTS

# Accepted file types shown in the upload zone and enforced by dcc.Upload
ACCEPTED_FORMATS: str = ".csv, .xlsx, .xls, .parquet"

# ═══════════════════════════════════════════════════════════════════════════
# PIPELINE STAGE DEFINITIONS
# ═══════════════════════════════════════════════════════════════════════════
# Visual stage cards shown in the Push to Pipeline section.
# Each entry:  (stage_id, display_name, icon_id, accent_color)
# stage_id matches the key used in stage_statuses dict (push_to_pipeline CB).
PIPELINE_STAGES: list[tuple] = [
    ("0-1", "Ingest & Validate", "mdi:database-check", "#00D4FF"),
    ("2",   "Aggregation",       "mdi:chart-box",       "#00E676"),
    ("3-4", "Graph Construction","mdi:graph",           "#9D4EDD"),
    ("5",   "Analytics (10-Fam)","mdi:brain",           "#E040FB"),
    ("6-8", "Scoring & Reports", "mdi:shield-check",    "#FF9800"),
]
