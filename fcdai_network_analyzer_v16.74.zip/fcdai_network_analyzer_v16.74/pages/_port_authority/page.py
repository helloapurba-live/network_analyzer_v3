"""
pages/port_authority/page.py
=====================================
PURPOSE
-------
This is the ONLY file Dash auto-discovery can see inside this package.

WHY THIS FILE EXISTS
--------------------
Dash's pages scanner (use_pages=True) walks the pages/ directory and runs
every .py file that:
  1. Does NOT start with "_" or "."
  2. Contains the string "register_page"

Consequence: __init__.py is ALWAYS SKIPPED (starts with "_").
So register_page in __init__.py NEVER fires → 404 on every navigation.

This file is the thin entry point Dash CAN find.  Its entire job:
  1. Import the full package (triggers __init__.py → registers all callbacks)
  2. Expose `layout` for Dash's layout resolution
  3. Call register_page(__name__, path="/port-authority", layout=layout)

EXECUTION ORDER (at server startup)
-------------------------------------
  1. Dash walks pages/ → finds page.py (first non-underscore .py with register_page)
  2. Dash loads this file as module "pages.port_authority.page"
  3. importlib.import_module("pages.port_authority") runs __init__.py:
       → imports layout.py  (layout function)
       → imports cb_generate.py  (CB1-CB4c registered)
       → imports cb_upload.py    (CB5-CB9  registered)
       → imports cb_pipeline.py  (CB10-CB12 registered)
       → imports cb_grid.py      (CBN1-CBN3 registered)
       → registers clientside_callback for pa-mount-ts
  4. layout = _pa.layout   (captured from package)
  5. register_page registers path="/port-authority" with Dash
  6. Server is ready — navigating to /port-authority renders the layout

IMPORT SAFETY
-------------
importlib.import_module("pages.port_authority") is idempotent — Python
caches modules in sys.modules.  If __init__.py was already imported
(e.g. in tests), this is a no-op.
"""

from __future__ import annotations
import importlib

import dash
from config import APP

# ── Step 1: Import the full package ──────────────────────────────────────────
# This runs __init__.py which:
#   - imports layout.py
#   - imports cb_generate, cb_upload, cb_pipeline, cb_grid (registers all @callbacks)
#   - registers the pa-mount-ts clientside_callback
#
# Python caches the module in sys.modules["pages.port_authority"] after
# the first call — subsequent imports are free.
_pa = importlib.import_module("pages.port_authority")

# ── Step 2: Expose layout so Dash can serve the page ─────────────────────────
# Dash reads `layout` from this module after register_page is called.
# Passing it explicitly via `layout=layout` to register_page is the most
# reliable approach (Dash uses it directly, no attribute lookup needed).
layout = _pa.layout

# ── Step 3: Register this page with Dash's router ────────────────────────────
# __name__ here is "pages.port_authority.page" (Dash's inferred module name).
# path="/port-authority"  — the URL that serves this page.
# layout=layout           — passed explicitly so Dash doesn't need to look
#                           it up from __init__.py (which it can't see directly).
dash.register_page(
    __name__,
    path="/port-authority",
    name="Port Authority",
    title=f"FCDAI v{APP.VERSION} | Port Authority",
    order=10,
    layout=layout,
)

print(
    "[PA-TRACE] pages.port_authority.page: registered path=/port-authority",
    flush=True,
)
