"""
pages/port_authority/cb_generate.py
======================================
PURPOSE
-------
Callbacks related to data GENERATION on the Port Authority page:

  CB1  submit_mode          — Mode radio + Submit button → show/hide panels
  CB2  update_scope_info    — Scope segmented control → info text update
  CB3  generate_sample      — Generate button → create sample DataFrames
  CB4  load_scenario        — Quick preset buttons (10/100/500 nodes)
  CB4b sync_quick_preset    — Quick preset buttons → sync NumberInput value
  CB4c sync_n_customers     — NumberInput value change → persist to singleton

DUAL-MODE GENERATION (CB3)
--------------------------
  ≤ 1 000 customers → SYNCHRONOUS fast-path
      Runs generate_all_samples() directly on callback thread.
      Returns complete results immediately.  No polling needed.

  > 1 000 customers → ASYNC thread + 150 ms poll
      Starts a daemon thread; returns a spinner immediately.
      Enables dcc.Interval (pa-gen-interval) which triggers
      poll_gen_progress (CBN3 in cb_grid.py) every 150 ms.
      Data NEVER leaves the local Windows 11 machine.
      All generation is pure Python/NumPy — 100% air-gapped.

IMPORT DEPENDENCY CHAIN
-----------------------
cb_generate.py imports:
  _state.py      — _PA_DATA_STORE, _GEN_JOB, _ASYNC_THRESHOLD,
                   _pa_set_staged, _pa_get_staged, _compute_fingerprint,
                   _no_mount_clicks
  _constants.py  — GRAPH_TABLE_KEYS, LEGACY_TABLE_KEYS
  _helpers.py    — _build_split_table_cards, _build_pipeline_summary,
                   _build_quality_profile, _build_data_summary
"""

from __future__ import annotations

import threading
import time

import dash_mantine_components as dmc
from dash import callback, ctx, no_update, Input, Output, State
from dash_iconify import DashIconify

from engine import get_pipeline
from utils.sample_data import generate_all_samples
from utils.logger import GlobalExceptionHandler

from ._state import (
    _GEN_JOB,
    _ASYNC_THRESHOLD,
    _pa_set_staged,
    _pa_get_staged,
    _no_mount_clicks,
)
from ._constants import GRAPH_TABLE_KEYS, LEGACY_TABLE_KEYS
from ._helpers import (
    _build_split_table_cards,
    _build_pipeline_summary,
    _build_quality_profile,
    _build_data_summary,
)


# ═══════════════════════════════════════════════════════════════════════════
# CB1: MODE SUBMIT — show/hide Sample vs Actual panel
# ═══════════════════════════════════════════════════════════════════════════
@callback(
    Output("pa-sample-panel",  "style",    allow_duplicate=True),
    Output("pa-upload-panel",  "style",    allow_duplicate=True),
    Output("pa-gen-btn",       "disabled", allow_duplicate=True),
    Output("pa-mode-status",   "children", allow_duplicate=True),
    Output("pa-source-mode",   "data",     allow_duplicate=True),
    Input("pa-mode-submit", "n_clicks"),
    State("pa-mode",        "value"),
    prevent_initial_call=True,
)
def submit_mode(n_clicks, mode):
    """
    Triggered when user clicks 'Submit Selection'.

    Shows the correct right-hand panel (sample config or upload), enables/
    disables the Generate button, updates status text, and persists the
    selected mode to the pipeline singleton for cross-navigation memory.

    Parameters
    ----------
    n_clicks : int or None  — click counter from Submit button
    mode     : str          — radio group value: "sample" or "actual"
    """
    print(
        f"[PA-TRACE] submit_mode FIRED: n_clicks={n_clicks}, mode={mode}, "
        f"triggered={ctx.triggered_id}", flush=True
    )
    if not n_clicks:
        return (no_update,) * 5

    show = {"display": "block"}
    hide = {"display": "none"}

    # Persist selected mode to singleton so layout() restores it on next navigation
    pipeline = get_pipeline()
    pipeline._staged_source_mode = mode

    if mode == "actual":
        status = dmc.Group(
            [
                DashIconify(icon="mdi:check-circle", width=16, color="#FF9800"),
                dmc.Text("Actual Data mode selected — upload files on the right", size="xs", c="#FF9800"),
            ],
            gap="xs", mt="xs",
        )
        # Actual mode: hide sample panel, show upload panel, disable generate button
        return hide, show, True, status, "actual"
    else:
        status = dmc.Group(
            [
                DashIconify(icon="mdi:check-circle", width=16, color="#00D4FF"),
                dmc.Text("Sample Data mode selected — configure and generate on the right", size="xs", c="#00D4FF"),
            ],
            gap="xs", mt="xs",
        )
        # Sample mode: show sample panel, hide upload panel, enable generate button
        return show, hide, False, status, "sample"


# ═══════════════════════════════════════════════════════════════════════════
# CB2: SCOPE INFO TEXT UPDATE
# ═══════════════════════════════════════════════════════════════════════════
@callback(
    Output("pa-scope-info", "children", allow_duplicate=True),
    Input("pa-gen-scope", "value"),
    prevent_initial_call=True,
)
def update_scope_info(scope):
    """
    Update the info box below the Data Type segmented control.

    Fires whenever the user changes Graph / Legacy / All selection.
    Purely informational — no data changes.

    Parameters
    ----------
    scope : str  — "graph", "legacy", or "all"
    """
    info = {
        "graph":  "Graph — will generate 5 tables: node, edge, relationship_edge, shared_attribute, temporal",
        "legacy": "Legacy — will generate 8 tables: customer, account, kyc, transaction, historical, alert, case, relationship",
        "all":    "All — will generate all 13 tables (5 graph + 8 legacy)",
    }
    return dmc.Group(
        [
            DashIconify(icon="mdi:information-outline", width=16, color="#00D4FF"),
            dmc.Text(info.get(scope, ""), size="xs", c="dimmed"),
        ],
        gap="xs",
    )


# ═══════════════════════════════════════════════════════════════════════════
# CB3: GENERATE SAMPLE DATA (dual-mode: sync ≤1000, async >1000)
# ═══════════════════════════════════════════════════════════════════════════
@callback(
    Output("pa-gen-status",         "children",  allow_duplicate=True),
    Output("pa-graph-tables-area",  "children",  allow_duplicate=True),
    Output("pa-legacy-tables-area", "children",  allow_duplicate=True),
    Output("pa-tables-badge",       "children",  allow_duplicate=True),
    Output("pa-tables-badge",       "color",     allow_duplicate=True),
    Output("pa-push-btn",           "disabled",  allow_duplicate=True),
    Output("pa-pipe-summary",       "children",  allow_duplicate=True),
    Output("pa-quality-profile",    "children",  allow_duplicate=True),
    Output("pa-data-summary",       "children",  allow_duplicate=True),
    Output("pa-summary-mode-badge", "children",  allow_duplicate=True),
    Output("pipeline-state",        "data",      allow_duplicate=True),
    Output("pa-n-customers-store",  "data",      allow_duplicate=True),
    Output("pa-gen-interval",       "disabled",  allow_duplicate=True),
    Input("pa-gen-btn", "n_clicks"),
    State("pa-gen-scope",     "value"),
    State("pa-n-customers",   "value"),
    State("pa-page-size",     "value"),
    State("pa-seed",          "value"),
    prevent_initial_call=True,
)
@GlobalExceptionHandler.wrap(fallback=(no_update,) * 13)
def generate_sample(n_clicks, scope, n_cust, page_size, seed_val):
    """
    Generate synthetic sample data and populate all data displays.

    SYNC PATH (n_cust ≤ _ASYNC_THRESHOLD = 1 000):
    -----------------------------------------------
    Runs generate_all_samples() on the callback thread (< 1 s typical).
    Returns fully populated card areas immediately.
    pa-gen-interval remains DISABLED (True).

    ASYNC PATH (n_cust > _ASYNC_THRESHOLD):
    ----------------------------------------
    Starts a daemon thread.  Returns a spinner UI immediately.
    Enables pa-gen-interval (disabled=False) → triggers CBN3 every 150 ms.
    CBN3 (poll_gen_progress in cb_grid.py) renders results when done.

    NOTE: Data NEVER leaves the machine.  No network calls.
    Air-gapped, PII-safe, bank-compliant.

    Parameters
    ----------
    n_clicks  : int  — click counter from Generate button
    scope     : str  — "graph", "legacy", or "all"
    n_cust    : int  — number of customers / nodes to generate
    page_size : int  — AG Grid page size for initial render
    seed_val  : int  — random seed for reproducibility
    """
    print(
        f"[PA-TRACE] generate_sample FIRED: n_clicks={n_clicks}, "
        f"triggered={ctx.triggered_id}", flush=True
    )
    if not n_clicks:
        return (no_update,) * 13

    n_cust    = int(n_cust    or 100)
    page_size = int(page_size or 5)
    seed_val  = int(seed_val if seed_val is not None else 42)

    # ── Shared generation logic ────────────────────────────────────────────
    # This inner function runs on either the callback thread (sync) or a
    # daemon thread (async).  Pure CPU, 100% local.
    def _run_generation():
        """Returns (tables_dict, elapsed_seconds)."""
        t0     = time.monotonic()
        all_t  = generate_all_samples(
            n_customers=n_cust,
            n_transactions=n_cust * 5,
            seed=seed_val,
        )
        # Filter by scope selection
        if scope == "graph":
            tbl = {k: v for k, v in all_t.items() if k in GRAPH_TABLE_KEYS}
        elif scope == "legacy":
            tbl = {k: v for k, v in all_t.items() if k in LEGACY_TABLE_KEYS}
        else:
            tbl = all_t

        # Persist to module cache AND pipeline singleton
        _pa_set_staged(dict(tbl))
        pipeline = get_pipeline()
        pipeline._staged_seed        = seed_val
        pipeline._staged_source_type = "sample"
        pipeline._staged_n_customers = n_cust
        pipeline._staged_gen_scope   = scope
        return tbl, time.monotonic() - t0

    # ── SYNC FAST PATH: ≤ 1 000 customers ───────────────────────────────
    if n_cust <= _ASYNC_THRESHOLD:
        tables, elapsed = _run_generation()
        graph_cards, legacy_cards, total, loaded = _build_split_table_cards(
            _pa_get_staged(), page_size
        )
        scope_label = {"graph": "Graph", "legacy": "Legacy", "all": "All"}.get(scope, scope)
        status = dmc.Group(
            [
                DashIconify(icon="mdi:check-circle", width=16, color="#00E676"),
                dmc.Text(
                    f"Generated {scope_label}: {loaded} tables, {total:,} rows in {elapsed:.2f}s",
                    size="xs", c="#00E676",
                ),
            ],
            gap="xs", mt="xs",
        )
        return (
            status,
            graph_cards,
            legacy_cards,
            f"{loaded} / 13 loaded | {total:,} rows",
            "green",
            False,
            _build_pipeline_summary(_pa_get_staged()),
            _build_quality_profile(_pa_get_staged()),
            _build_data_summary(_pa_get_staged(), "sample"),
            "Sample",
            {"staged": True, "tables": loaded, "rows": total},
            n_cust,
            True,   # keep pa-gen-interval DISABLED (no async needed)
        )

    # ── ASYNC PATH: > 1 000 customers — start background thread ────────
    _GEN_JOB.update({
        "status":   "running",
        "result":   None,
        "error":    None,
        "start_ts": time.monotonic(),
        "params":   {"n_cust": n_cust, "scope": scope, "seed_val": seed_val, "page_size": page_size},
    })

    def _worker():
        """Background thread — updates _GEN_JOB when done or on error."""
        try:
            tables, elapsed = _run_generation()
            _GEN_JOB.update({
                "status": "done",
                "result": {
                    "tables":    tables,
                    "scope":     scope,
                    "n_cust":    n_cust,
                    "seed_val":  seed_val,
                    "page_size": page_size,
                    "elapsed":   elapsed,
                },
            })
        except Exception:  # noqa: BLE001
            import traceback
            _GEN_JOB.update({"status": "error", "error": traceback.format_exc()})

    threading.Thread(target=_worker, daemon=True).start()

    # Return spinner UI immediately while background thread works
    spinner = dmc.Group(
        [
            dmc.Loader(size="xs", color="#00D4FF"),
            dmc.Text(f"⏳ Generating {n_cust:,} customers locally (scope: {scope})…", size="xs", c="#00D4FF"),
        ],
        gap="xs", mt="xs",
    )
    loading_placeholder = [dmc.Center(
        dmc.Group(
            [dmc.Loader(size="sm", color="#00D4FF"), dmc.Text("Processing on local CPU…", size="xs", c="dimmed")],
            gap="xs",
        ),
        style={"minHeight": "80px"},
    )]
    return (
        spinner,
        loading_placeholder,
        loading_placeholder,
        "Generating…", "yellow",
        True,                  # disable push button while generating
        no_update, no_update, no_update, no_update,
        no_update,
        n_cust,
        False,  # pa-gen-interval disabled=False → ENABLE polling (CBN3)
    )


# ═══════════════════════════════════════════════════════════════════════════
# CB4: QUICK SCENARIO BUTTONS (10 / 100 / 500 nodes)
# ═══════════════════════════════════════════════════════════════════════════
@callback(
    Output("pa-gen-status",         "children",  allow_duplicate=True),
    Output("pa-graph-tables-area",  "children",  allow_duplicate=True),
    Output("pa-legacy-tables-area", "children",  allow_duplicate=True),
    Output("pa-tables-badge",       "children",  allow_duplicate=True),
    Output("pa-tables-badge",       "color",     allow_duplicate=True),
    Output("pa-push-btn",           "disabled",  allow_duplicate=True),
    Output("pa-pipe-summary",       "children",  allow_duplicate=True),
    Output("pa-quality-profile",    "children",  allow_duplicate=True),
    Output("pa-data-summary",       "children",  allow_duplicate=True),
    Output("pa-summary-mode-badge", "children",  allow_duplicate=True),
    Output("pipeline-state",        "data",      allow_duplicate=True),
    Output("pa-n-customers-store",  "data",      allow_duplicate=True),
    Input("pa-sc-small",  "n_clicks"),
    Input("pa-sc-medium", "n_clicks"),
    Input("pa-sc-large",  "n_clicks"),
    State("pa-gen-scope", "value"),
    State("pa-page-size", "value"),
    State("pa-seed",      "value"),
    prevent_initial_call=True,
)
@GlobalExceptionHandler.wrap(fallback=(no_update,) * 12)
def load_scenario(s, m, l, scope, page_size, seed_val):
    """
    Generate data for one of three quick preset sizes.

    Button → n_customers mapping:
      pa-sc-small  → 10  nodes  (tiny test)
      pa-sc-medium → 100 nodes  (small dataset)
      pa-sc-large  → 500 nodes  (medium dataset)

    v16.15 FIX: Checks actual click values (not just triggered_id) because
    Dash 4.x can fire this callback on page mount with non-None triggered_id
    but all n_clicks still None.

    Parameters
    ----------
    s, m, l    : int or None — n_clicks for small/medium/large buttons
    scope      : str         — current Data Type segmented control value
    page_size  : int         — current page size select value
    seed_val   : int         — current seed input value
    """
    print(
        f"[PA-TRACE] load_scenario FIRED: s={s}, m={m}, l={l}, "
        f"triggered={ctx.triggered_id}", flush=True
    )
    # Guard: page mount fires with triggered_id set but all clicks=None
    if ctx.triggered_id is None or not any([s, m, l]):
        return (no_update,) * 12

    # Map button id → (n_customers, display label)
    scenario_map = {
        "pa-sc-small":  (10,  "Small 10"),
        "pa-sc-medium": (100, "Medium 100"),
        "pa-sc-large":  (500, "Large 500"),
    }
    n_cust, sc_name = scenario_map.get(ctx.triggered_id, (100, "Default"))
    page_size = int(page_size or 5)
    seed_val  = int(seed_val if seed_val is not None else 42)
    t0        = time.time()

    # Generate all 13 tables; filter by scope
    all_tables = generate_all_samples(
        n_customers=n_cust, n_transactions=n_cust * 5, seed=seed_val
    )
    if scope == "graph":
        tables = {k: v for k, v in all_tables.items() if k in GRAPH_TABLE_KEYS}
    elif scope == "legacy":
        tables = {k: v for k, v in all_tables.items() if k in LEGACY_TABLE_KEYS}
    else:
        tables = all_tables

    # Persist to module cache AND singleton
    _pa_set_staged(dict(tables))
    pipeline = get_pipeline()
    pipeline._staged_seed        = seed_val
    pipeline._staged_source_type = "sample"
    pipeline._staged_n_customers = n_cust
    pipeline._staged_gen_scope   = scope

    elapsed = time.time() - t0
    graph_cards, legacy_cards, total, loaded = _build_split_table_cards(_pa_get_staged(), page_size)

    status = dmc.Group(
        [
            DashIconify(icon="mdi:check-circle", width=16, color="#00E676"),
            dmc.Text(f"{sc_name}: {loaded} tables, {total:,} rows in {elapsed:.1f}s", size="xs", c="#00E676"),
        ],
        gap="xs", mt="xs",
    )

    return (
        status,
        graph_cards,
        legacy_cards,
        f"{loaded} / 13 loaded | {total:,} rows",
        "green",
        False,
        _build_pipeline_summary(_pa_get_staged()),
        _build_quality_profile(_pa_get_staged()),
        _build_data_summary(_pa_get_staged(), "sample"),
        "Sample",
        {"staged": True, "tables": loaded, "rows": total},
        n_cust,
    )


# ═══════════════════════════════════════════════════════════════════════════
# CB4b: SYNC QUICK PRESET → NumberInput
# ═══════════════════════════════════════════════════════════════════════════
@callback(
    Output("pa-n-customers", "value", allow_duplicate=True),
    Input("pa-sc-small",  "n_clicks"),
    Input("pa-sc-medium", "n_clicks"),
    Input("pa-sc-large",  "n_clicks"),
    prevent_initial_call=True,
)
def sync_quick_preset_to_input(s, m, l):
    """
    Auto-fill the customers NumberInput when a quick preset is clicked.

    Keeps the NumberInput value in sync with the preset buttons so the
    user can see the node count they are about to generate.

    v16.15 FIX: Guard against page mount fires where all n_clicks=None.
    """
    if not any([s, m, l]):
        return no_update
    preset_map = {"pa-sc-small": 10, "pa-sc-medium": 100, "pa-sc-large": 500}
    return preset_map.get(ctx.triggered_id, no_update)


# ═══════════════════════════════════════════════════════════════════════════
# CB4c: PERSIST n-CUSTOMERS ON EVERY VALUE CHANGE
# ═══════════════════════════════════════════════════════════════════════════
@callback(
    Output("pa-n-customers-store", "data", allow_duplicate=True),
    Input("pa-n-customers", "value"),
    prevent_initial_call=True,
)
def sync_n_customers_to_singleton(val):
    """
    Persist the NumberInput value to the pipeline singleton on EVERY change.

    This ensures the number is saved even if the user edits it and navigates
    away without clicking Generate.  layout() reads it back on next visit.

    v16.11 T1: Introduced for cross-navigation form persistence.

    Parameters
    ----------
    val : int or None  — current NumberInput value
    """
    if val is not None and isinstance(val, (int, float)) and val >= 5:
        pipeline = get_pipeline()
        pipeline._staged_n_customers = int(val)
        return int(val)
    return no_update
