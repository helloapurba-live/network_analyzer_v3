"""
pages/port_authority/cb_grid.py
=====================================
PURPOSE
-------
Callbacks related to GRID data serving, URL reload hydration, and
async generation polling on the Port Authority page:

  CBN1 serve_grid_rows     — AG Grid server-side row model: filter + sort
  CBN2 url_reload_pa       — dcc.Location-driven hydration on page navigation
  CBN3 poll_gen_progress   — dcc.Interval 150 ms polling for async generation

AG GRID SERVER-SIDE MODEL (CBN1)
---------------------------------
When the AG Grid is configured with rowModelType="serverSide", it does NOT
send all rows to the browser.  Instead, it fires a "getRowsRequest" event
every time the user pages, sorts, or filters.

The callback responds with a "getRowsResponse" that includes:
  - rowData      : the requested slice of rows
  - rowCount     : total number of rows (for pagination)

Filtering logic supported:
  - text    : contains, notContains, equals, notEqual, startsWith, endsWith
  - number  : equals, notEqual, lessThan, lessThanOrEqual, greaterThan,
              greaterThanOrEqual, inRange
  - date    : same as number operators (on string-formatted dates)
  - set     : values list → isin()

URL HYDRATION (CBN2)
--------------------
CBN2 fires on every page navigation because pa-mount-ts (a dcc.Store whose
value is set to Date.now() in clientside_callback on every DCC page mount)
changes on navigation.

This is the PRIMARY mechanism for restoring data displays after the user
navigates away and back.  It reads from _pa_get_staged() and rebuilds all
displays from the current in-memory store.  If _PA_DATA_STORE is empty,
it falls back to pipeline._staged_tables.

ASYNC POLL (CBN3)
-----------------
When generate_sample starts an async job (n_cust > 1 000), pa-gen-interval
is ENABLED (disabled=False).  CBN3 fires every 150 ms checking _GEN_JOB.

States:
  "running" → return spinner (all no_update for data outputs)
  "done"    → render full results, DISABLE pa-gen-interval (stop polling)
  "error"   → render error card, DISABLE pa-gen-interval
  "idle"    → no_update (spurious fire, do nothing)

_GEN_OUTPUTS_COUNT = 15 (imported from _state.py):
  13 data outputs + 2 fingerprint badge outputs

IMPORT DEPENDENCY CHAIN
-----------------------
cb_grid.py imports:
  _state.py     — _GEN_JOB, _GEN_OUTPUTS_COUNT, _pa_get_staged,
                  _pa_set_staged, _compute_fingerprint, _no_mount_clicks
  _constants.py — (none direct, helpers use them)
  _helpers.py   — _build_split_table_cards, _build_pipeline_summary,
                  _build_quality_profile, _build_data_summary
"""

from __future__ import annotations

import dash_mantine_components as dmc
from dash import callback, ctx, no_update, Input, Output, State, MATCH
from dash_iconify import DashIconify

from utils.logger import GlobalExceptionHandler

from ._state import (
    _GEN_JOB,
    _GEN_OUTPUTS_COUNT,
    _pa_get_staged,
    _pa_set_staged,
    _compute_fingerprint,
    _no_mount_clicks,
)
from ._constants import GRAPH_TABLE_KEYS, LEGACY_TABLE_KEYS
from ._helpers import (
    _build_split_table_cards,
    _build_pipeline_summary,
    _build_quality_profile,
    _build_data_summary,
)


# ═══════════════════════════════════════════════════════════════════════════
# CBN1: AG GRID SERVER-SIDE ROW MODEL — filter + sort + paginate
# ═══════════════════════════════════════════════════════════════════════════
@callback(
    Output({"type": "pa-grid", "index": MATCH}, "getRowsResponse"),
    Input( {"type": "pa-grid", "index": MATCH}, "getRowsRequest"),
    prevent_initial_call=True,
)
@GlobalExceptionHandler.wrap(fallback={"rowData": [], "rowCount": 0})
def serve_grid_rows(request):
    """
    Respond to AG Grid server-side row requests.

    Called automatically by AG Grid whenever the user:
    - Pages forward/backward
    - Applies a column filter
    - Sorts a column

    The MATCH pattern means this callback fires for EACH grid independently.
    The "index" in Output/Input MATCH is the table name (e.g. "node_table").

    Parameters
    ----------
    request : dict or None  — AG Grid getRowsRequest payload:
        {
          "startRow": 0,
          "endRow":   100,
          "filterModel": {...},   # dict of column → filter spec
          "sortModel":  [...],    # list of {colId, sort} dicts
        }

    Returns
    -------
    dict with keys:
        rowData  : list of row dicts (JSON serialisable)
        rowCount : int  — total filtered row count
    """
    if request is None:
        return {"rowData": [], "rowCount": 0}

    # ctx.triggered_id is a dict {"type": "pa-grid", "index": "table_name"}
    table_key = (ctx.triggered_id or {}).get("index")
    if not table_key:
        return {"rowData": [], "rowCount": 0}

    staged = _pa_get_staged() or {}
    df     = staged.get(table_key)
    if df is None or len(df) == 0:
        return {"rowData": [], "rowCount": 0}

    # ── Apply filters ────────────────────────────────────────────────────
    filter_model = request.get("filterModel", {}) or {}
    filtered_df  = df.copy()

    for col, fspec in filter_model.items():
        if col not in filtered_df.columns:
            continue

        ftype     = fspec.get("filterType", "text")
        ftype_op  = fspec.get("type", "contains")
        fvalue    = fspec.get("filter")
        f_to      = fspec.get("filterTo")    # used by inRange
        fvalues   = fspec.get("values")      # used by set filter

        try:
            series = filtered_df[col]

            if ftype == "set" and fvalues is not None:
                # Set filter — values list
                filtered_df = filtered_df[series.isin(fvalues)]

            elif ftype == "number" and fvalue is not None:
                num_series = series.astype(float, errors="ignore")
                fv = float(fvalue)
                if ftype_op == "equals":
                    filtered_df = filtered_df[num_series == fv]
                elif ftype_op == "notEqual":
                    filtered_df = filtered_df[num_series != fv]
                elif ftype_op == "lessThan":
                    filtered_df = filtered_df[num_series < fv]
                elif ftype_op == "lessThanOrEqual":
                    filtered_df = filtered_df[num_series <= fv]
                elif ftype_op == "greaterThan":
                    filtered_df = filtered_df[num_series > fv]
                elif ftype_op == "greaterThanOrEqual":
                    filtered_df = filtered_df[num_series >= fv]
                elif ftype_op == "inRange" and f_to is not None:
                    filtered_df = filtered_df[(num_series >= fv) & (num_series <= float(f_to))]

            else:
                # Text filter — convert column to str for comparison
                if fvalue is None:
                    continue
                str_series = series.astype(str)
                fval_str   = str(fvalue).lower()
                if ftype_op == "contains":
                    filtered_df = filtered_df[str_series.str.lower().str.contains(fval_str, na=False)]
                elif ftype_op == "notContains":
                    filtered_df = filtered_df[~str_series.str.lower().str.contains(fval_str, na=False)]
                elif ftype_op == "equals":
                    filtered_df = filtered_df[str_series.str.lower() == fval_str]
                elif ftype_op == "notEqual":
                    filtered_df = filtered_df[str_series.str.lower() != fval_str]
                elif ftype_op == "startsWith":
                    filtered_df = filtered_df[str_series.str.lower().str.startswith(fval_str, na=False)]
                elif ftype_op == "endsWith":
                    filtered_df = filtered_df[str_series.str.lower().str.endswith(fval_str, na=False)]

        except Exception:  # noqa: BLE001
            # Bad filter value (e.g. parse float failure) — skip this column filter
            continue

    # ── Apply sorting ────────────────────────────────────────────────────
    sort_model = request.get("sortModel", []) or []
    if sort_model:
        sort_cols = [s["colId"] for s in sort_model if s.get("colId") in filtered_df.columns]
        sort_asc  = [s.get("sort", "asc") == "asc" for s in sort_model if s.get("colId") in filtered_df.columns]
        if sort_cols:
            filtered_df = filtered_df.sort_values(by=sort_cols, ascending=sort_asc)

    # ── Slice to requested page window ───────────────────────────────────
    start_row  = request.get("startRow", 0)
    end_row    = request.get("endRow",   100)
    total_rows = len(filtered_df)
    page_df    = filtered_df.iloc[start_row:end_row]

    return {
        "rowData":  page_df.to_dict("records"),
        "rowCount": total_rows,
    }


# ═══════════════════════════════════════════════════════════════════════════
# CBN2: URL RELOAD HYDRATION — restore displays on page navigation
# ═══════════════════════════════════════════════════════════════════════════
@callback(
    Output("pa-graph-tables-area",  "children",  allow_duplicate=True),
    Output("pa-legacy-tables-area", "children",  allow_duplicate=True),
    Output("pa-tables-badge",       "children",  allow_duplicate=True),
    Output("pa-tables-badge",       "color",     allow_duplicate=True),
    Output("pa-push-btn",           "disabled",  allow_duplicate=True),
    Output("pa-gen-status",         "children",  allow_duplicate=True),
    Output("pa-pipe-summary",       "children",  allow_duplicate=True),
    Output("pa-quality-profile",    "children",  allow_duplicate=True),
    Output("pa-data-summary",       "children",  allow_duplicate=True),
    Output("pa-fingerprint-badge",  "children",  allow_duplicate=True),
    Input("pa-mount-ts",  "data"),
    State("pa-page-size",   "value"),
    State("pa-source-mode", "data"),
    prevent_initial_call=True,
)
@GlobalExceptionHandler.wrap(fallback=(no_update,) * 10)
def url_reload_pa(mount_ts, page_size, source_mode):
    """
    Hydrate the Port Authority page from in-memory store on every navigation.

    pa-mount-ts is a dcc.Store whose value is set to Date.now() by a
    clientside_callback on every Dash page mount (Dash 4.x page system).
    When its value changes, this callback fires — which happens every time
    the user navigates TO the Port Authority page.

    v16.15 BUG FIX: Without this callback, navigating away and back would
    show blank cards even though _PA_DATA_STORE still had data.

    Fallback chain:
    1. Try _pa_get_staged()    (module-level dict — fastest)
    2. Try pipeline._staged_tables (singleton — cross-page persistence)

    If both are empty → render "no data" placeholders.

    Parameters
    ----------
    mount_ts    : int or None  — timestamp set by clientside_callback on mount
    page_size   : int          — current page size setting
    source_mode : str          — "sample" or "actual"
    """
    print(
        f"[PA-TRACE] url_reload_pa FIRED: mount_ts={mount_ts}, "
        f"triggered={ctx.triggered_id}", flush=True
    )
    if mount_ts is None:
        return (no_update,) * 10

    page_size   = int(page_size or 5)
    source_mode = source_mode or "sample"
    staged      = _pa_get_staged()

    if not staged:
        empty       = dmc.Center(
            dmc.Text("No data — use Generate or Upload to load.", size="sm", c="dimmed"),
            style={"minHeight": "60px"},
        )
        empty_group = [empty]
        return (
            empty_group, empty_group,
            "0 / 13 loaded", "gray", True,
            dmc.Text("No data loaded", size="xs", c="dimmed"),
            empty, empty, empty,
            "—",
        )

    graph_cards, legacy_cards, total, loaded = _build_split_table_cards(staged, page_size)
    fp  = _compute_fingerprint(staged)

    status = dmc.Group(
        [
            DashIconify(icon="mdi:database-check", width=16, color="#00BCD4"),
            dmc.Text(f"Restored from memory: {loaded} table(s) | {total:,} rows", size="xs", c="#00BCD4"),
        ],
        gap="xs", mt="xs",
    )

    return (
        graph_cards,
        legacy_cards,
        f"{loaded} / 13 loaded | {total:,} rows",
        "green" if loaded else "gray",
        loaded == 0,
        status,
        _build_pipeline_summary(staged),
        _build_quality_profile(staged),
        _build_data_summary(staged, source_mode),
        fp,
    )


# ═══════════════════════════════════════════════════════════════════════════
# CBN3: POLLING — check async generation progress every 150 ms
# ═══════════════════════════════════════════════════════════════════════════
@callback(
    # ── Data displays (13 outputs) ───────────────────────────────────────
    Output("pa-gen-status",         "children",  allow_duplicate=True),
    Output("pa-graph-tables-area",  "children",  allow_duplicate=True),
    Output("pa-legacy-tables-area", "children",  allow_duplicate=True),
    Output("pa-tables-badge",       "children",  allow_duplicate=True),
    Output("pa-tables-badge",       "color",     allow_duplicate=True),
    Output("pa-push-btn",           "disabled",  allow_duplicate=True),
    Output("pa-pipe-summary",       "children",  allow_duplicate=True),
    Output("pa-quality-profile",    "children",  allow_duplicate=True),
    Output("pa-data-summary",       "children",  allow_duplicate=True),
    Output("pa-summary-mode-badge", "children",  allow_duplicate=True),
    Output("pipeline-state",        "data",      allow_duplicate=True),
    Output("pa-n-customers-store",  "data",      allow_duplicate=True),
    Output("pa-gen-interval",       "disabled",  allow_duplicate=True),
    # ── Fingerprint badge (2 outputs) ────────────────────────────────────
    Output("pa-fingerprint-badge",  "children",  allow_duplicate=True),
    Output("pa-fingerprint-badge",  "color",     allow_duplicate=True),
    # ─────────────────────────────────────────────────────────────────────
    # TOTAL = 15 outputs → matches _GEN_OUTPUTS_COUNT = 15
    Input("pa-gen-interval", "n_intervals"),
    State("pa-page-size",    "value"),
    prevent_initial_call=True,
)
@GlobalExceptionHandler.wrap(fallback=(no_update,) * _GEN_OUTPUTS_COUNT)
def poll_gen_progress(n_intervals, page_size):
    """
    Poll the in-memory _GEN_JOB dict to check async generation status.

    This callback fires every 150 ms while pa-gen-interval is ENABLED.
    generate_sample() enables the interval when it starts a background thread.
    This callback DISABLES the interval (disabled=True) when job is done or error.

    States handled:
    ---------------
    "idle"    — job has not started yet.  Return all no_update.
    "running" — job still running.  Return spinner, keep interval enabled.
    "done"    — job completed.  Render full results, DISABLE interval.
    "error"   — job threw an exception.  Show error card, DISABLE interval.

    NOTE: _GEN_OUTPUTS_COUNT is defined in _state.py as 15.
    The fallback tuple in @GlobalExceptionHandler.wrap uses this constant
    so mismatches are caught at import time, not at runtime.

    Parameters
    ----------
    n_intervals : int  — dcc.Interval fire count
    page_size   : int  — current page size
    """
    status = _GEN_JOB.get("status", "idle")

    if status == "idle":
        # Never started — do nothing
        return (no_update,) * _GEN_OUTPUTS_COUNT

    if status == "running":
        # Still working — show elapsed time, keep interval enabled
        import time
        elapsed = time.monotonic() - (_GEN_JOB.get("start_ts") or time.monotonic())
        spinner = dmc.Group(
            [
                dmc.Loader(size="xs", color="#00D4FF"),
                dmc.Text(f"⏳ Generating locally… {elapsed:.1f}s elapsed", size="xs", c="#00D4FF"),
            ],
            gap="xs", mt="xs",
        )
        no_ops = [no_update] * (_GEN_OUTPUTS_COUNT - 2)   # -1 status -1 interval
        return (spinner, *no_ops, False, no_update, no_update)

    if status == "error":
        # Generation failed
        err_msg = _GEN_JOB.get("error", "Unknown error")
        _GEN_JOB["status"] = "idle"  # reset to idle so next attempt works
        err_ui = dmc.Group(
            [
                DashIconify(icon="mdi:close-circle", width=16, color="#FF5252"),
                dmc.Text(f"Generation failed: {str(err_msg)[:120]}", size="xs", c="#FF5252"),
            ],
            gap="xs", mt="xs",
        )
        no_ops = [no_update] * (_GEN_OUTPUTS_COUNT - 3)   # status + interval + fp_children
        return (err_ui, *no_ops, True, no_update, "red")

    if status == "done":
        # ── Job completed — render full results ───────────────────────────
        result     = _GEN_JOB.get("result") or {}
        tables     = result.get("tables", {})
        scope      = result.get("scope",    "all")
        n_cust     = result.get("n_cust",    100)
        elapsed    = result.get("elapsed",   0.0)
        page_size_ = int(result.get("page_size") or page_size or 5)

        # Reset job state so it doesn't fire again
        _GEN_JOB["status"] = "idle"
        _GEN_JOB["result"] = None

        # Update module cache
        _pa_set_staged(dict(tables))

        staged      = _pa_get_staged()
        total       = sum(len(v) for v in staged.values() if v is not None) if staged else 0
        loaded      = sum(1 for v in staged.values() if v is not None and len(v) > 0) if staged else 0
        fp          = _compute_fingerprint(staged)
        scope_label = {"graph": "Graph", "legacy": "Legacy", "all": "All"}.get(scope, scope)

        graph_cards, legacy_cards, total, loaded = _build_split_table_cards(staged, page_size_)

        status_ui = dmc.Group(
            [
                DashIconify(icon="mdi:check-circle", width=16, color="#00E676"),
                dmc.Text(
                    f"Async generated {scope_label}: {loaded} tables, {total:,} rows in {elapsed:.1f}s",
                    size="xs", c="#00E676",
                ),
            ],
            gap="xs", mt="xs",
        )

        return (
            status_ui,
            graph_cards,
            legacy_cards,
            f"{loaded} / 13 loaded | {total:,} rows",
            "green",
            False,    # push button enabled
            _build_pipeline_summary(staged),
            _build_quality_profile(staged),
            _build_data_summary(staged, "sample"),
            "Sample",
            {"staged": True, "tables": loaded, "rows": total},
            n_cust,
            True,     # DISABLE pa-gen-interval — stop polling
            fp,       # fingerprint badge children
            "green",  # fingerprint badge color
        )

    # Unknown status — do nothing
    return (no_update,) * _GEN_OUTPUTS_COUNT
