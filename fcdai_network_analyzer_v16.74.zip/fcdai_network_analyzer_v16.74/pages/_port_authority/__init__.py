"""
pages/port_authority/__init__.py
=====================================
PURPOSE
-------
Initialises the port_authority package:
  1. Exposes layout at the package level (imported by page.py)
  2. Imports ALL callback modules so every @callback decorator fires
  3. Registers the clientside callback for pa-mount-ts hydration

WHY register_page IS NOT HERE
------------------------------
Dash's page auto-discovery (use_pages=True) SKIPS files beginning with "_"
(including __init__.py).  register_page in this file would never execute.

Instead, page.py (a non-underscore file Dash CAN discover) calls:
  importlib.import_module("pages.port_authority")  → runs THIS __init__.py
  dash.register_page(__name__, path="/port-authority", layout=layout)

CALLBACK REGISTRATION
----------------------
All four cb_*.py modules are imported here.  Python executes their module-level
code which includes @callback decorators → callbacks are registered globally.
  cb_generate : CB1–CB4c (mode submit, scope info, generate, scenarios)
  cb_upload   : CB5–CB9  (upload, delete, download, page size)
  cb_pipeline : CB10–CB12 (push, reset, refresh)
  cb_grid     : CBN1–CBN3 (AG Grid rows, url reload, async poll)

CLIENTSIDE CALLBACK
-------------------
Sets pa-mount-ts on every navigation to /port-authority.
CBN2 (url_reload_pa in cb_grid.py) reads this to hydrate data displays.
"""

from dash import clientside_callback, Input, Output

# ── 1. Expose layout at package level ────────────────────────────────────
#    page.py imports this after running importlib.import_module("pages.port_authority")
from .layout import layout  # noqa: F401

# ── 2. Register ALL callback modules ────────────────────────────────────
#    Importing each module executes its @callback decorators → global registration
from . import cb_generate   # CB1–CB4c  # noqa: F401
from . import cb_upload     # CB5–CB9   # noqa: F401
from . import cb_pipeline   # CB10–CB12 # noqa: F401
from . import cb_grid       # CBN1–CBN3 # noqa: F401


# ── 3. Clientside callback: set pa-mount-ts on page navigation ───────────
#
# Fires in the BROWSER (no server round-trip) whenever the URL changes.
# When the user navigates to /port-authority, sets pa-mount-ts = Date.now().
# CBN2 (url_reload_pa) in cb_grid.py reads this change and hydrates displays.
#
# This is the Dash 4.x recommended pattern for detecting page navigation
# inside multi-page apps (replaces dcc.Location + PathnameTrigger).
#
clientside_callback(
    """
    function(pathname) {
        if (pathname === "/port-authority") {
            return Date.now();
        }
        return window.dash_clientside.no_update;
    }
    """,
    Output("pa-mount-ts", "data", allow_duplicate=True),
    Input("_pages_location", "pathname"),   # v16.24 fix: Dash Pages uses _pages_location, not "url"
    prevent_initial_call=True,
)

# ── Module summary ───────────────────────────────────────────────────────
print(
    "[PA-TRACE] pages.port_authority __init__: layout + 4 cb_* modules loaded",
    flush=True,
)
