"""
pages/port_authority/layout.py
=================================
PURPOSE
-------
Contains ONLY the layout() function for the Port Authority Dash page.

layout() is called by Dash every time a user navigates to /port-authority.
It reads the current state from _PA_DATA_STORE and pipeline singleton,
then returns the complete page component tree as a dmc.Box.

DESIGN PRINCIPLES
-----------------
1. layout() is the SOLE authority for the initial page skeleton.
2. It pre-builds table cards and summaries from _PA_DATA_STORE so the
   page renders immediately (no blank flash while waiting for callbacks).
3. The url_reload_pa callback (CBN2 in cb_grid.py) fires immediately
   after page mount to re-fill data areas — this handles edge cases where
   layout() and CBN2 see slightly different data (race condition guard).
4. Data PERSISTS until the user clicks "Reset All Data". Navigation away
   and back NEVER clears the data.

v16.15 persistence fix:
  - Removed dead localStorage stores (they caused spurious mount callbacks)
  - Changed remaining stores to storage_type="memory"
  - All callback outputs use allow_duplicate=True (layout is sole "primary")

IMPORT DEPENDENCY CHAIN
-----------------------
layout.py imports:
  _state.py      (_pa_get_staged, _compute_fingerprint)
  _constants.py  (GRAPH_TABLE_DEFS, LEGACY_TABLE_DEFS, GRAPH_TABLE_KEYS …)
  _helpers.py    (_build_split_table_cards, _build_data_summary, …)
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

import dash
import dash_mantine_components as dmc
from dash import dcc, html
from dash_iconify import DashIconify

# Ensure project root is importable
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from config import THEME, APP
from engine import get_pipeline

# Internal package imports
from ._state import _pa_get_staged, _compute_fingerprint, _PA_DATA_STORE
from ._constants import (
    GRAPH_UPLOAD_SLOTS,
    LEGACY_UPLOAD_SLOTS,
    LEGACY_TABLE_DEFS,
    GRAPH_TABLE_KEYS,
    LEGACY_TABLE_KEYS,
)
from ._helpers import (
    _build_upload_card,
    _build_split_table_cards,
    _build_pipeline_summary,
    _build_pipeline_stages_display,
    _build_quality_profile,
    _build_data_summary,
)


def layout():
    """
    Build and return the complete Port Authority page component tree.

    Called by Dash on EVERY navigation to /port-authority.

    Steps performed:
      1. Read live settings from pipeline singleton (last n_customers, scope,
         seed, source mode) so the form shows the user's last-used values.
      2. Read _PA_DATA_STORE to get currently staged tables.
      3. Pre-build table cards so data is visible immediately on page load.
      4. Return the full dmc.Box component tree.

    Returns
    -------
    dmc.Box
        The entire page layout wrapped in a dmc.Box container.
    """
    _pipe = get_pipeline()

    # ── Live settings from pipeline singleton ──────────────────────────────
    # Use getattr with defaults so this never crashes on first visit
    _live_n      = getattr(_pipe, '_staged_n_customers', None) or 100
    _prev_mode   = getattr(_pipe, '_staged_source_mode', None)   # None = first visit
    _live_mode   = _prev_mode or 'sample'
    _live_scope  = getattr(_pipe, '_staged_gen_scope',   None) or 'graph'
    _live_seed   = getattr(_pipe, '_staged_seed',        None)
    if _live_seed is None:
        _live_seed = 42

    # ── Read staged tables ─────────────────────────────────────────────────
    _staged     = _pa_get_staged()
    _has_data   = bool(_staged)
    _page_size  = 5   # default page size for initial render

    # Debug trace — visible in server console during development
    _tbl_keys   = list(_staged.keys()) if _staged else []
    _total_rows = sum(len(v) for v in _staged.values()) if _staged else 0
    print(
        f"[PA-TRACE] layout() called: has_data={_has_data}, "
        f"tables={_tbl_keys}, total_rows={_total_rows}, "
        f"_PA_DATA_STORE_len={len(_PA_DATA_STORE)}",
        flush=True,
    )

    # ── Panel visibility — drive by last-used source mode ─────────────────
    # On first visit (_prev_mode is None) we default to showing sample panel
    _sample_style   = {"display": "block"} if _live_mode == "sample" else {"display": "none"}
    _upload_style   = {"display": "none"}  if _live_mode == "sample" else {"display": "block"}
    # Generate button: enabled whenever sample panel is active (first visit defaults to sample)
    _gen_disabled   = (_live_mode != "sample")

    # ── Auto-open legacy accordion when legacy data is loaded ──────────────
    # If the user last loaded legacy tables, expand the accordion so they
    # can see the data without an extra click.
    _legacy_has_data = _has_data and any(
        k in _staged and len(_staged.get(k, [])) > 0
        for k, *_ in LEGACY_TABLE_DEFS
    )
    _accordion_value = "legacy-tables" if _legacy_has_data else None

    # ── Pre-build table cards ──────────────────────────────────────────────
    # This pre-renders data so the page is not blank on navigation.
    # CBN2 (url_reload_pa) will re-build them after the DOM is mounted too —
    # that is intentional: it handles any edge cases where layout() and CBN2
    # see different data momentarily.
    if _has_data:
        _graph_cards, _legacy_cards, _total_rows, _n_loaded = _build_split_table_cards(
            _staged, _page_size
        )
        _badge_text       = f"{_n_loaded} / 13 loaded | {_total_rows:,} rows"
        _badge_color      = "green"
        _push_disabled    = False
        _pipe_summary_ini = _build_pipeline_summary(_staged)
        _quality_ini      = _build_quality_profile(_staged)
        _datasummary_ini  = _build_data_summary(_staged, _live_mode)
    else:
        # ── Empty placeholders for first visit ────────────────────────────
        _empty_msg_g = dmc.Center(
            dmc.Text("No graph data — generate or upload above", c="dimmed", size="xs"),
            style={"minHeight": "60px"},
        )
        _empty_msg_l = dmc.Center(
            dmc.Text("No legacy data — generate or upload above", c="dimmed", size="xs"),
            style={"minHeight": "60px"},
        )
        _graph_cards      = [_empty_msg_g]
        _legacy_cards     = [_empty_msg_l]
        _badge_text       = "0 / 13 loaded"
        _badge_color      = "gray"
        _push_disabled    = True
        _pipe_summary_ini = dmc.Text("No tables loaded — generate or upload data first", c="dimmed", size="sm")
        _quality_ini      = dmc.Text("Load data to see quality profile", c="dimmed", size="sm")
        _datasummary_ini  = _build_data_summary(None)

    _mode_label_ini = "Sample" if _live_mode == "sample" else "Actual"

    # ── Mode status message ────────────────────────────────────────────────
    if _live_mode == "sample":
        _mode_status_ini = dmc.Group(
            [
                DashIconify(icon="mdi:check-circle", width=16, color="#00D4FF"),
                dmc.Text("Sample Data mode — configure and generate on the right", size="xs", c="#00D4FF"),
            ],
            gap="xs", mt="xs",
        )
    elif _live_mode == "actual":
        _mode_status_ini = dmc.Group(
            [
                DashIconify(icon="mdi:check-circle", width=16, color="#FF9800"),
                dmc.Text("Actual Data mode — upload files on the right", size="xs", c="#FF9800"),
            ],
            gap="xs", mt="xs",
        )
    else:
        _mode_status_ini = dmc.Text(
            "Select a mode and click Submit", size="xs", c="dimmed", mt="xs"
        )

    # ══════════════════════════════════════════════════════════════════════
    # RETURN THE FULL PAGE TREE
    # ══════════════════════════════════════════════════════════════════════
    return dmc.Box(
        [
            # Download components: CB7 writes pa-download-csv, CB8 writes pa-download-zip
            dcc.Download(id="pa-download-csv"),
            dcc.Download(id="pa-download-zip"),

            # ── MEMORY STORES ──────────────────────────────────────────────
            # storage_type="memory" — cleared on browser tab close ONLY.
            # v16.15: Removed localStorage stores which caused spurious
            # callback fires on page re-mount in Dash 4.x.
            dcc.Store(id="pa-source-mode",       storage_type="memory", data=_live_mode),
            dcc.Store(id="pa-n-customers-store", storage_type="memory", data=_live_n),

            # v16.16: pa-mount-ts is always set to time.time() in layout() so
            # CBN2 (url_reload_pa) fires on EVERY page navigation.
            dcc.Store(id="pa-mount-ts", storage_type="memory", data=time.time()),

            # v16.16: Async generation poll interval — starts DISABLED.
            # CB3 (generate_sample) enables it for large datasets;
            # CBN3 (poll_gen_progress) disables it when done.
            dcc.Interval(id="pa-gen-interval", interval=150, disabled=True, max_intervals=-1),

            # ══════════════════════════════════════════════════════════════
            # HEADER
            # ══════════════════════════════════════════════════════════════
            dmc.Group(
                [
                    dmc.Stack(
                        [
                            dmc.Title("Port Authority", order=2, c="white"),
                            dmc.Text(
                                "Data Source Hub — select mode, configure, load data, push to pipeline",
                                c="dimmed", size="sm",
                            ),
                        ],
                        gap=2,
                    ),
                    dmc.Group(
                        [
                            dmc.Badge(
                                f"v{APP.VERSION} | 13 tables | 15 upload slots",
                                color="cyan", variant="light", size="sm",
                            ),
                            # v16.16: Fingerprint badge shows 8-char SHA-256 of staged data.
                            # Lets analysts confirm they are running on the correct dataset.
                            dmc.Badge(
                                id="pa-fingerprint-badge",
                                children=f"🔒 FP: {_compute_fingerprint(_staged) if _staged else 'no data'}",
                                color="grape" if _staged else "gray",
                                variant="dot",
                                size="sm",
                            ),
                            dmc.ActionIcon(
                                DashIconify(icon="mdi:refresh", width=20),
                                id="pa-refresh-btn",
                                variant="gradient",
                                size="lg",
                                gradient={"from": "#00D4FF", "to": "#9D4EDD"},
                                radius="xl",
                            ),
                            dcc.Link(
                                dmc.Button(
                                    "Dashboard",
                                    size="xs", variant="subtle", color="gray",
                                    leftSection=DashIconify(icon="mdi:arrow-left", width=14),
                                ),
                                href="/",
                                style={"textDecoration": "none"},
                            ),
                        ],
                        gap="sm",
                    ),
                ],
                justify="space-between",
                mb="lg",
            ),

            # ══════════════════════════════════════════════════════════════
            # ROW 1: DATA SOURCE DECISION (two-column layout)
            # ══════════════════════════════════════════════════════════════
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            DashIconify(icon="mdi:swap-horizontal-bold", width=22, color="#00D4FF"),
                            dmc.Text("Data Source", fw=700, c="white", size="lg"),
                        ],
                        gap="sm", mb="md",
                    ),
                    dmc.Grid(
                        [
                            # ── LEFT COLUMN: Mode Selector ─────────────────────────
                            dmc.GridCol(
                                [
                                    dmc.Paper(
                                        [
                                            dmc.Text("Data Source Mode", fw=700, c="white", size="md", mb="md"),
                                            dmc.Text("Choose how to load data into the pipeline", size="xs", c="dimmed", mb="md"),
                                            dmc.RadioGroup(
                                                id="pa-mode",
                                                value=_live_mode,
                                                children=dmc.Stack(
                                                    [
                                                        dmc.Radio(
                                                            label=dmc.Group([
                                                                DashIconify(icon="mdi:database-plus", width=18, color="#00D4FF"),
                                                                dmc.Stack([
                                                                    dmc.Text("Sample Data", fw=600, size="sm", c="white"),
                                                                    dmc.Text("Auto-generate synthetic data for testing", size="xs", c="dimmed"),
                                                                ], gap=0),
                                                            ], gap="sm"),
                                                            value="sample",
                                                            color="cyan",
                                                            styles={"radio": {"cursor": "pointer"}, "label": {"cursor": "pointer"}},
                                                        ),
                                                        dmc.Radio(
                                                            label=dmc.Group([
                                                                DashIconify(icon="mdi:upload-multiple", width=18, color="#FF9800"),
                                                                dmc.Stack([
                                                                    dmc.Text("Actual Data", fw=600, size="sm", c="white"),
                                                                    dmc.Text("Upload real CSV / Excel / Parquet files", size="xs", c="dimmed"),
                                                                ], gap=0),
                                                            ], gap="sm"),
                                                            value="actual",
                                                            color="orange",
                                                            styles={"radio": {"cursor": "pointer"}, "label": {"cursor": "pointer"}},
                                                        ),
                                                    ],
                                                    gap="md",
                                                ),
                                                mb="lg",
                                            ),
                                            dmc.Button(
                                                "Submit Selection",
                                                id="pa-mode-submit",
                                                size="md",
                                                variant="gradient",
                                                gradient={"from": "#00D4FF", "to": "#7B2FBE"},
                                                leftSection=DashIconify(icon="mdi:check-bold", width=18),
                                                fullWidth=True,
                                                mb="xs",
                                            ),
                                            dmc.Button(
                                                "Reset All Data",
                                                id="pa-reset-btn",
                                                size="sm",
                                                variant="outline",
                                                color="red",
                                                fullWidth=True,
                                                leftSection=DashIconify(icon="mdi:delete-sweep", width=18),
                                            ),
                                            html.Div(id="pa-mode-status", children=_mode_status_ini),
                                        ],
                                        p="lg", radius="lg",
                                        style={"backgroundColor": "rgba(0,0,0,0.4)", "border": "1px solid rgba(0,212,255,0.2)", "minHeight": "320px"},
                                    ),
                                ],
                                span={"base": 12, "md": 4},
                            ),

                            # ── RIGHT COLUMN: Active Panel ───────────────────────────
                            dmc.GridCol(
                                [
                                    # SAMPLE CONFIG PANEL
                                    html.Div(
                                        id="pa-sample-panel",
                                        style=_sample_style,
                                        children=[
                                            dmc.Paper(
                                                [
                                                    dmc.Group(
                                                        [
                                                            DashIconify(icon="mdi:cog-outline", width=20, color="#00D4FF"),
                                                            dmc.Text("Sample Data Configuration", fw=700, c="white", size="md"),
                                                            dmc.Badge("SAMPLE MODE", color="cyan", variant="light", size="xs"),
                                                        ],
                                                        gap="sm", mb="md",
                                                    ),
                                                    dmc.Grid(
                                                        [
                                                            dmc.GridCol(
                                                                [
                                                                    dmc.Text("Number of Customers / Nodes", size="sm", c="dimmed", fw=500, mb=4),
                                                                    dmc.NumberInput(
                                                                        id="pa-n-customers",
                                                                        value=_live_n,
                                                                        min=5, max=50000, step=5,
                                                                        leftSection=DashIconify(icon="mdi:account-multiple", width=18),
                                                                        styles={"input": {"backgroundColor": THEME.DARK_BG, "color": "white", "border": f"1px solid {THEME.DARK_BORDER}", "fontSize": "14px"}},
                                                                    ),
                                                                ],
                                                                span=6,
                                                            ),
                                                            dmc.GridCol(
                                                                [
                                                                    dmc.Text("Data Type", size="sm", c="dimmed", fw=500, mb=4),
                                                                    dmc.SegmentedControl(
                                                                        id="pa-gen-scope",
                                                                        value=_live_scope,
                                                                        data=[
                                                                            {"value": "graph",  "label": dmc.Group([DashIconify(icon="mdi:graph",        width=14, color="#00D4FF"), dmc.Text("Graph",  size="xs")], gap=4)},
                                                                            {"value": "legacy", "label": dmc.Group([DashIconify(icon="mdi:table",         width=14, color="#FF9800"), dmc.Text("Legacy", size="xs")], gap=4)},
                                                                            {"value": "all",    "label": dmc.Group([DashIconify(icon="mdi:database-sync", width=14, color="#00E676"), dmc.Text("All",    size="xs")], gap=4)},
                                                                        ],
                                                                        fullWidth=True,
                                                                        styles={
                                                                            "root":      {"backgroundColor": "rgba(0,0,0,0.3)", "borderRadius": "6px"},
                                                                            "indicator": {"background": "linear-gradient(135deg, #00D4FF60, #7B2FBE60)"},
                                                                            "label":     {"color": "#C9D1D9", "fontSize": "12px"},
                                                                        },
                                                                    ),
                                                                ],
                                                                span=6,
                                                            ),
                                                        ],
                                                        gutter="md", mb="md",
                                                    ),
                                                    # Seed input
                                                    dmc.Grid(
                                                        [
                                                            dmc.GridCol(
                                                                [
                                                                    dmc.Group(
                                                                        [
                                                                            DashIconify(icon="mdi:dice-multiple-outline", width=16, color="#7B2FBE"),
                                                                            dmc.Text("Random Seed", size="sm", c="dimmed", fw=500),
                                                                            dmc.Tooltip(
                                                                                label="Same seed always produces identical data — useful for reproducible testing",
                                                                                withArrow=True, position="top",
                                                                                children=DashIconify(icon="mdi:information-outline", width=14, color="#888"),
                                                                            ),
                                                                        ],
                                                                        gap=4, mb=4,
                                                                    ),
                                                                    dmc.NumberInput(
                                                                        id="pa-seed",
                                                                        value=_live_seed,
                                                                        min=0, max=999999, step=1,
                                                                        leftSection=DashIconify(icon="mdi:lock-outline", width=16),
                                                                        styles={"input": {"backgroundColor": THEME.DARK_BG, "color": "white", "border": "1px solid rgba(123,47,190,0.5)", "fontSize": "14px"}},
                                                                    ),
                                                                ],
                                                                span=6,
                                                            ),
                                                            dmc.GridCol(
                                                                [
                                                                    dmc.Stack(
                                                                        [
                                                                            dmc.Text("", size="sm", mb=4),  # spacer
                                                                            dmc.Text(
                                                                                "💡 Change seed to generate a different dataset. "
                                                                                "Keep seed fixed for reproducible results.",
                                                                                size="xs", c="dimmed",
                                                                                style={"lineHeight": "1.4", "paddingTop": "4px"},
                                                                            ),
                                                                        ],
                                                                        gap=0,
                                                                    ),
                                                                ],
                                                                span=6,
                                                            ),
                                                        ],
                                                        gutter="md", mb="md",
                                                    ),
                                                    # Scope info box
                                                    dmc.Paper(
                                                        [
                                                            html.Div(
                                                                id="pa-scope-info",
                                                                children=[
                                                                    dmc.Group(
                                                                        [
                                                                            DashIconify(icon="mdi:information-outline", width=16, color="#00D4FF"),
                                                                            dmc.Text("All — will generate 5 graph + 8 legacy = 13 tables", size="xs", c="dimmed"),
                                                                        ],
                                                                        gap="xs",
                                                                    ),
                                                                ],
                                                            ),
                                                        ],
                                                        p="xs", radius="md", mb="md",
                                                        style={"backgroundColor": "rgba(0,212,255,0.05)", "border": "1px solid rgba(0,212,255,0.15)"},
                                                    ),
                                                    # Quick preset buttons
                                                    dmc.Group(
                                                        [
                                                            dmc.Text("Quick:", size="xs", c="dimmed", fw=600),
                                                            dmc.Button("10 nodes",  id="pa-sc-small",  variant="light", color="cyan",   size="compact-xs"),
                                                            dmc.Button("100 nodes", id="pa-sc-medium", variant="light", color="orange", size="compact-xs"),
                                                            dmc.Button("500 nodes", id="pa-sc-large",  variant="light", color="red",    size="compact-xs"),
                                                        ],
                                                        gap="xs", mb="md",
                                                    ),
                                                    # Main generate button
                                                    dmc.Button(
                                                        "Generate Sample Data",
                                                        id="pa-gen-btn",
                                                        size="md",
                                                        variant="gradient",
                                                        gradient={"from": "cyan", "to": "indigo"},
                                                        leftSection=DashIconify(icon="mdi:database-plus", width=20),
                                                        fullWidth=True,
                                                        disabled=_gen_disabled,
                                                    ),
                                                    html.Div(
                                                        id="pa-gen-status",
                                                        children=dmc.Text(
                                                            "Configure above and click Generate"
                                                            if _prev_mode == "sample"
                                                            else "Click 'Submit Selection' first",
                                                            size="xs", c="dimmed", mt="xs",
                                                        ),
                                                    ),
                                                ],
                                                p="lg", radius="lg",
                                                style={"backgroundColor": "rgba(0,0,0,0.4)", "border": "1px solid rgba(0,212,255,0.15)", "minHeight": "320px"},
                                            ),
                                        ],
                                    ),

                                    # ACTUAL UPLOAD PANEL
                                    html.Div(
                                        id="pa-upload-panel",
                                        style=_upload_style,
                                        children=[
                                            dmc.Paper(
                                                [
                                                    dmc.Group(
                                                        [
                                                            DashIconify(icon="mdi:upload-multiple", width=20, color="#FF9800"),
                                                            dmc.Text("Upload Actual Data", fw=700, c="white", size="md"),
                                                            dmc.Badge("ACTUAL MODE",         color="orange", variant="light", size="xs"),
                                                            dmc.Badge("CSV | Excel | Parquet", color="gray",   variant="light", size="xs"),
                                                        ],
                                                        gap="sm", mb="md",
                                                    ),
                                                    dmc.Group(
                                                        [
                                                            DashIconify(icon="mdi:graph", width=16, color="#00D4FF"),
                                                            dmc.Text("Graph Layer (6 slots)", fw=600, c="white", size="sm"),
                                                        ],
                                                        gap="sm", mb="xs",
                                                    ),
                                                    dmc.SimpleGrid(
                                                        cols={"base": 2, "md": 3, "lg": 6},
                                                        spacing="xs", mb="md",
                                                        children=[_build_upload_card(k, i, c, d) for k, i, c, d in GRAPH_UPLOAD_SLOTS],
                                                    ),
                                                    dmc.Divider(
                                                        my="xs", color="dark",
                                                        label=dmc.Group(
                                                            [
                                                                DashIconify(icon="mdi:table", width=14, color="#FF9800"),
                                                                dmc.Text("Legacy / Transaction (9 slots)", size="xs", c="dimmed"),
                                                            ],
                                                            gap=4,
                                                        ),
                                                    ),
                                                    dmc.SimpleGrid(
                                                        cols={"base": 2, "md": 3, "lg": 5},
                                                        spacing="xs",
                                                        children=[_build_upload_card(k, i, c, d) for k, i, c, d in LEGACY_UPLOAD_SLOTS],
                                                    ),
                                                    html.Div(
                                                        id="pa-upload-status",
                                                        children=dmc.Text("Drag & drop files into slots above", size="xs", c="dimmed", mt="sm"),
                                                    ),
                                                ],
                                                p="lg", radius="lg",
                                                style={"backgroundColor": "rgba(0,0,0,0.4)", "border": "1px solid rgba(255,152,0,0.2)", "minHeight": "320px"},
                                            ),
                                        ],
                                    ),
                                ],
                                span={"base": 12, "md": 8},
                            ),
                        ],
                        gutter="md",
                    ),
                ],
                p="lg", radius="lg", className="glass-card", mb="md",
            ),

            # ══════════════════════════════════════════════════════════════
            # ROW 2: DATA TABLES (always visible — all 13 table cards)
            # ══════════════════════════════════════════════════════════════
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            dmc.Group(
                                [
                                    DashIconify(icon="mdi:table-eye", width=22, color="#00E676"),
                                    dmc.Text("Data Tables", fw=700, c="white", size="lg"),
                                    dmc.Badge(
                                        id="pa-tables-badge",
                                        children=_badge_text,
                                        color=_badge_color,
                                        variant="light", size="sm",
                                    ),
                                ],
                                gap="sm",
                            ),
                            dmc.Group(
                                [
                                    dmc.Select(
                                        id="pa-page-size",
                                        value="5",
                                        data=[{"value": str(n), "label": f"{n} rows"} for n in [5, 10, 25, 50, 100]],
                                        size="xs", w=100,
                                        styles={"input": {"backgroundColor": "rgba(0,0,0,0.4)", "color": "white", "border": "1px solid #21262D"}},
                                    ),
                                    dmc.Button(
                                        "Download All",
                                        id="pa-dl-all",
                                        size="xs", variant="light", color="green",
                                        leftSection=DashIconify(icon="mdi:download-multiple", width=16),
                                    ),
                                ],
                                gap="sm",
                            ),
                        ],
                        justify="space-between", mb="md",
                    ),
                    # ── Graph DB section header ────────────────────────────
                    dmc.Group(
                        [
                            DashIconify(icon="mdi:graph", width=16, color="#00D4FF"),
                            dmc.Text("Graph DB Tables", fw=600, c="#00D4FF", size="sm"),
                            dmc.Badge("5 tables", color="cyan", variant="outline", size="xs"),
                        ],
                        gap="xs", mb="xs",
                    ),
                    html.Div(id="pa-graph-tables-area", children=_graph_cards),

                    # ── Legacy DB section — collapsible accordion ──────────
                    # Default: collapsed unless legacy data is already loaded
                    dmc.Accordion(
                        children=[
                            dmc.AccordionItem(
                                [
                                    dmc.AccordionControl(
                                        dmc.Group(
                                            [
                                                DashIconify(icon="mdi:table", width=16, color="#FF9800"),
                                                dmc.Text("Legacy / Transaction DB Tables", size="sm", fw=500, c="dimmed"),
                                                dmc.Badge("optional", color="orange", variant="outline", size="xs"),
                                            ],
                                            gap="xs",
                                        ),
                                        style={"padding": "8px 12px", "backgroundColor": "rgba(0,0,0,0.1)", "borderRadius": "8px"},
                                    ),
                                    dmc.AccordionPanel(
                                        html.Div(id="pa-legacy-tables-area", children=_legacy_cards),
                                        style={"padding": "8px 0"},
                                    ),
                                ],
                                value="legacy-tables",
                            ),
                        ],
                        value=_accordion_value,
                        variant="separated",
                        style={"marginTop": "12px"},
                    ),
                ],
                p="lg", radius="lg", className="glass-card", mb="md",
            ),

            # ══════════════════════════════════════════════════════════════
            # ROW 3: DATA SUMMARY & ANALYTICS
            # ══════════════════════════════════════════════════════════════
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            dmc.Group(
                                [
                                    DashIconify(icon="mdi:chart-areaspline-variant", width=24, color="#58A6FF"),
                                    dmc.Text("Data Summary & Analytics", fw=700, c="white", size="lg"),
                                ],
                                gap="sm",
                            ),
                            dmc.Group(
                                [
                                    dmc.Badge(f"v{APP.VERSION}",    color="blue",   variant="light",  size="sm"),
                                    dmc.Badge(id="pa-summary-mode-badge", children=_mode_label_ini, color="cyan", variant="filled", size="sm"),
                                ],
                                gap="xs",
                            ),
                        ],
                        justify="space-between", mb="md",
                    ),
                    html.Div(id="pa-data-summary", children=[_datasummary_ini]),
                ],
                p="lg", radius="lg", className="glass-card", mb="md",
                style={"border": "1px solid rgba(88,166,255,0.15)", "background": "linear-gradient(180deg, rgba(13,17,23,0.95) 0%, rgba(88,166,255,0.03) 100%)"},
            ),

            # ══════════════════════════════════════════════════════════════
            # ROW 4: PUSH TO PIPELINE
            # ══════════════════════════════════════════════════════════════
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            DashIconify(icon="mdi:pipe", width=22, color="#FF9800"),
                            dmc.Text("Push to Pipeline", fw=700, c="white", size="lg"),
                        ],
                        gap="sm", mb="md",
                    ),
                    html.Div(id="pa-pipe-summary", children=[_pipe_summary_ini]),
                    dmc.Divider(my="md", color="dark"),
                    dmc.Text("Pipeline Stages", fw=600, c="white", size="sm", mb="xs"),
                    html.Div(id="pa-pipe-stages", children=[_build_pipeline_stages_display()]),
                    dmc.Divider(my="md", color="dark"),
                    dmc.Grid(
                        [
                            dmc.GridCol(
                                [
                                    dmc.Button(
                                        "📦 Push to Pipeline",
                                        id="pa-push-btn",
                                        size="lg",
                                        variant="gradient",
                                        gradient={"from": "#FF9800", "to": "#FF1744"},
                                        leftSection=DashIconify(icon="mdi:database-arrow-right", width=22),
                                        fullWidth=True,
                                        disabled=_push_disabled,
                                    ),
                                    dmc.Text("Stages data for pipeline — run from Dashboard", size="xs", c="dimmed", mt="xs", ta="center"),
                                ],
                                span={"base": 12, "md": 6},
                            ),
                            dmc.GridCol(
                                [
                                    dmc.Paper(
                                        [
                                            html.Div(
                                                id="pa-pipe-run-status",
                                                children=[
                                                    dmc.Group(
                                                        [
                                                            DashIconify(icon="mdi:information-outline", width=16, color="#58A6FF"),
                                                            dmc.Text("Pipeline idle — waiting for data", size="sm", c="dimmed"),
                                                        ],
                                                        gap="xs",
                                                    ),
                                                ],
                                            ),
                                        ],
                                        p="md", radius="md",
                                        style={"backgroundColor": "rgba(0,0,0,0.3)", "border": f"1px solid {THEME.DARK_BORDER}"},
                                    ),
                                ],
                                span={"base": 12, "md": 6},
                            ),
                        ],
                        gutter="md",
                    ),
                ],
                p="lg", radius="lg", className="glass-card", mb="md",
            ),

            # ══════════════════════════════════════════════════════════════
            # DATA QUALITY PROFILE
            # ══════════════════════════════════════════════════════════════
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            DashIconify(icon="mdi:chart-box-outline", width=22, color="#E040FB"),
                            dmc.Text("Data Quality Profile", fw=700, c="white", size="md"),
                            dmc.Badge(f"v{APP.VERSION}", color="grape", variant="light", size="sm"),
                        ],
                        gap="sm", mb="md",
                    ),
                    html.Div(id="pa-quality-profile", children=[_quality_ini]),
                ],
                p="lg", radius="lg", className="glass-card", mb="md",
            ),

            # ══════════════════════════════════════════════════════════════
            # QUICK NAV
            # ══════════════════════════════════════════════════════════════
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            dmc.Text("Quick Links", size="xs", fw=600, c="dimmed"),
                            dcc.Link(dmc.Badge("Dashboard",    color="cyan",   variant="light"), href="/",              style={"textDecoration": "none"}),
                            dcc.Link(dmc.Badge("Radar",        color="green",  variant="light"), href="/radar",         style={"textDecoration": "none"}),
                            dcc.Link(dmc.Badge("Visualization",color="grape",  variant="light"), href="/visualization", style={"textDecoration": "none"}),
                            dcc.Link(dmc.Badge("Vault",        color="orange", variant="light"), href="/vault",         style={"textDecoration": "none"}),
                        ],
                        gap="sm",
                    ),
                ],
                p="sm", radius="md",
                style={"backgroundColor": "rgba(0,0,0,0.3)", "border": f"1px solid {THEME.GLASS_BORDER}"},
            ),
        ]
    )
