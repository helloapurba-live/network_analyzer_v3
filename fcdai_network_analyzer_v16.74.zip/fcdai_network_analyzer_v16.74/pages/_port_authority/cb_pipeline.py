"""
pages/port_authority/cb_pipeline.py
========================================
PURPOSE
-------
Callbacks for pipeline CONTROL on the Port Authority page:

  CB10 push_to_pipeline   — Validate staged tables and push to pipeline
  CB11 reset_all_data     — Clear ALL staged data + reset all UI displays
  CB12 refresh_page       — Re-render data cards from current store (no regen)

PUSH OPERATION (CB10)
---------------------
The push is a TWO-STEP process:
  1. Validate tables using ValidateLayer (l1 of the 7-layer stack)
  2. Call pipeline.set_staged_tables(tables) to hand data downstream

If validation fails, detailed error cards are shown but data is NOT pushed.
If validation passes, data flows to layers 2-7 automatically.

The push result is persisted as `_pa_push_summary` and `_last_pushed_tables`
on the pipeline singleton so other pages can read what was pushed.

RESET OPERATION (CB11)
----------------------
Clears:
  - _PA_DATA_STORE (module-level dict)
  - pipeline singleton staged tables
  - All displayed cards, badges, status texts
  - N-customers store (memory store for form persistence)

CB11 intentionally does NOT use @GlobalExceptionHandler.wrap because a
partial reset leaving inconsistent state would be dangerous.  If reset fails
the exception propagates to Dash's built-in error display.

IMPORT DEPENDENCY CHAIN
-----------------------
cb_pipeline.py imports:
  _state.py     — _PA_DATA_STORE, _pa_set_staged, _pa_get_staged,
                  _compute_fingerprint, _no_mount_clicks
  _constants.py — PIPELINE_STAGES, ALL_TABLE_DEFS
  _helpers.py   — _build_split_table_cards, _build_pipeline_summary,
                  _build_pipeline_stages_display, _build_quality_profile,
                  _build_data_summary
"""

from __future__ import annotations

import time
from datetime import datetime as _dt

import dash_mantine_components as dmc
from dash import callback, ctx, dcc, no_update, Input, Output, State
from dash_iconify import DashIconify

from engine import get_pipeline
from utils.logger import GlobalExceptionHandler

from ._state import (
    _PA_DATA_STORE,
    _pa_set_staged,
    _pa_get_staged,
    _compute_fingerprint,
)
from ._constants import PIPELINE_STAGES
from ._helpers import (
    _build_split_table_cards,
    _build_pipeline_summary,
    _build_pipeline_stages_display,
    _build_quality_profile,
    _build_data_summary,
)


# ═══════════════════════════════════════════════════════════════════════════
# CB10: PUSH TO PIPELINE — validate and hand off staged tables
# ═══════════════════════════════════════════════════════════════════════════
@callback(
    Output("pa-gen-status",       "children", allow_duplicate=True),
    Output("pa-push-btn",         "disabled", allow_duplicate=True),
    Output("pa-pipe-run-status",  "children", allow_duplicate=True),
    Output("pa-pipe-summary",     "children", allow_duplicate=True),
    Output("pa-pipe-stages",      "children", allow_duplicate=True),
    Output("pipeline-state",      "data",     allow_duplicate=True),
    Input("pa-push-btn", "n_clicks"),
    prevent_initial_call=True,
)
@GlobalExceptionHandler.wrap(fallback=(no_update,) * 6)
def push_to_pipeline(n_clicks):
    """
    Validate staged tables and push them into the 7-layer pipeline.

    VALIDATION
    ----------
    Uses ValidateLayer (Layer 1) from the FCDAI pipeline stack.
    If validation finds missing required columns or type mismatches,
    error cards are shown WITHOUT pushing data through.

    PUSH PATH
    ---------
    On success: calls pipeline.set_staged_tables(tables) which makes data
    available to all downstream layers (feature engineering, ML, UI layers).
    Also stores :
        pipeline._pa_push_summary — summary string for the dashboard banner
        pipeline._last_pushed_tables — copy of tables for cross-page access

    FINGERPRINT
    -----------
    An 8-character SHA-256 hash of all table shapes is computed and stored
    so the fingerprint badge on the header stays current.

    Parameters
    ----------
    n_clicks : int or None  — click count from Push button
    """
    print(
        f"[PA-TRACE] push_to_pipeline FIRED: n_clicks={n_clicks}, "
        f"triggered={ctx.triggered_id}", flush=True
    )
    if not n_clicks:
        return (no_update,) * 6

    staged = _pa_get_staged()
    if not staged:
        err = dmc.Group(
            [
                DashIconify(icon="mdi:alert-circle", width=16, color="#FF5252"),
                dmc.Text("No data staged — generate or upload first.", size="xs", c="#FF5252"),
            ],
            gap="xs", mt="xs",
        )
        return err, False, err, no_update, no_update, no_update

    # ── Layer-1 validation (local import to avoid circular imports) ───────
    # ValidateLayer is imported HERE (inside the function) because it uses
    # the engine which imports from config — importing at module level would
    # create a circular dependency chain.
    from layers.l1_validate import ValidateLayer   # noqa: PLC0415

    validator = ValidateLayer()
    try:
        # assess_all() is the actual API (V9 bulletproof — never throws)
        reports = validator.assess_all(staged)
        # Tables with overall_score < 0.5 are genuine data quality failures
        hard_fails = [
            f"{name}: DQ score {r.overall_score:.0%} (min 50%)"
            for name, r in reports.items()
            if r.overall_score < 0.5
        ]
        # All other issues surface as warnings (informational only)
        warnings_list = [
            f"[{name}] {issue}"
            for name, r in reports.items()
            for issue in r.issues
            if r.overall_score >= 0.5
        ]
        val_result = {"passed": len(hard_fails) == 0, "errors": hard_fails, "warnings": warnings_list}
    except Exception as exc:  # noqa: BLE001
        val_result = {"passed": False, "errors": [str(exc)], "warnings": []}

    if not val_result.get("passed", True):
        errors   = val_result.get("errors",   [])
        warnings = val_result.get("warnings", [])
        err_items = [
            dmc.Group(
                [DashIconify(icon="mdi:close-circle", width=14, color="#FF5252"),
                 dmc.Text(e, size="xs", c="#FF5252")],
                gap="xs",
            )
            for e in errors[:8]          # show max 8 errors
        ]
        warn_items = [
            dmc.Group(
                [DashIconify(icon="mdi:alert", width=14, color="#FFB300"),
                 dmc.Text(w, size="xs", c="#FFB300")],
                gap="xs",
            )
            for w in warnings[:4]        # show max 4 warnings
        ]
        push_result = dmc.Paper(
            dmc.Stack(
                [
                    dmc.Group(
                        [
                            DashIconify(icon="mdi:shield-alert", width=20, color="#FF5252"),
                            dmc.Text("Validation Failed — data NOT pushed", fw=700, c="#FF5252"),
                        ], gap="xs",
                    ),
                    *err_items,
                    *warn_items,
                ],
                gap="xs",
            ),
            p="sm", radius="md", withBorder=True,
            style={"borderColor": "#FF5252", "background": "rgba(255,82,82,0.05)"},
        )
        status = dmc.Group(
            [
                DashIconify(icon="mdi:shield-alert", width=16, color="#FF5252"),
                dmc.Text(f"Validation failed: {len(errors)} error(s)", size="xs", c="#FF5252"),
            ],
            gap="xs", mt="xs",
        )
        return status, False, push_result, no_update, no_update, no_update

    # ── Push validated tables to singleton ───────────────────────────────
    pipeline = get_pipeline()

    # Merge cleansed tables into pipeline.tables so dashboard Run Pipeline works
    from layers.l1_validate import ValidateLayer as _VL  # noqa: PLC0415
    _cleaner = _VL()
    clean_tables = {}
    for _name, _df in staged.items():
        try:
            clean_tables[_name] = _cleaner.cleanse(_df.copy())
        except Exception:  # noqa: BLE001
            clean_tables[_name] = _df.copy()

    if not hasattr(pipeline, 'tables') or not pipeline.tables:
        pipeline.tables = {}
    pipeline.tables.update(clean_tables)
    pipeline._staged_tables       = staged          # keep original staging ref
    pipeline._tables_cleansed     = True
    pipeline._selected_table_names = list(clean_tables.keys())
    pipeline._last_pushed_tables  = {k: v.copy() for k, v in clean_tables.items()}

    total  = sum(len(v) for v in clean_tables.values() if v is not None)
    loaded = sum(1 for v in clean_tables.values() if v is not None and len(v) > 0)
    fp     = _compute_fingerprint(staged)

    # Build push summary as a DICT (dashboard reads .get('n_nodes') etc.)
    _node_ref = (clean_tables.get('node') if 'node' in clean_tables
                 else clean_tables.get('customer') if 'customer' in clean_tables
                 else next(iter(clean_tables.values()), None))
    pipeline._pa_push_summary = {
        'pushed_at':   _dt.now().isoformat(),
        'tables':      sorted(clean_tables.keys()),
        'total_rows':  total,
        'n_nodes':     len(_node_ref) if _node_ref is not None else 0,
        'data_mode':   'graph' if 'node' in clean_tables else 'legacy',
        'seed':        getattr(pipeline, '_staged_seed', 42),
        'source_type': getattr(pipeline, '_staged_source_type', 'sample'),
        'fingerprint': fp,
    }

    # ── Build success stage display ───────────────────────────────────────
    done_status = {stage: "done" for stage in ["ingest", "validate"]}
    stage_display = _build_pipeline_stages_display(done_status)

    n_tables = len(clean_tables)
    table_names_str = ", ".join(sorted(clean_tables.keys()))
    n_nodes = len(_node_ref) if _node_ref is not None else 0

    done_cards = dmc.Paper(
        dmc.Stack(
            [
                dmc.Group(
                    [
                        DashIconify(icon="mdi:check-decagram", width=20, color="#00E676"),
                        dmc.Text("Pipeline Push Successful", fw=700, c="#00E676"),
                    ], gap="xs",
                ),
                dmc.SimpleGrid(cols=3, spacing="xs", children=[
                    dmc.Stack([dmc.Text("Tables", size="xs", c="dimmed"),
                               dmc.Text(f"{n_tables}", fw=700, c="white", size="sm")],
                              gap=0, align="center"),
                    dmc.Stack([dmc.Text("Total Rows", size="xs", c="dimmed"),
                               dmc.Text(f"{total:,}", fw=700, c="white", size="sm")],
                              gap=0, align="center"),
                    dmc.Stack([dmc.Text("Entities", size="xs", c="dimmed"),
                               dmc.Text(f"{n_nodes:,}", fw=700, c="white", size="sm")],
                              gap=0, align="center"),
                ]),
                dmc.Text(f"Tables: {table_names_str}", size="xs", c="dimmed"),
                dmc.Group(
                    [
                        dmc.Badge(f"SHA:{fp}", color="gray", variant="light"),
                    ], gap="xs",
                ),
                stage_display,
                dmc.Alert(
                    "Data is staged. Go to Dashboard to run the full pipeline.",
                    color="cyan", variant="light", radius="md",
                    icon=DashIconify(icon="mdi:information"),
                ),
                dcc.Link(
                    dmc.Button(
                        "Go to Dashboard → Run Pipeline", size="sm",
                        variant="light", color="cyan",
                        leftSection=DashIconify(icon="mdi:view-dashboard", width=16),
                    ),
                    href="/", style={"textDecoration": "none"},
                ),
            ], gap="xs",
        ),
        p="sm", radius="md", withBorder=True,
        style={"borderColor": "#00E676", "background": "rgba(0,230,118,0.05)"},
    )

    status = dmc.Group(
        [
            DashIconify(icon="mdi:check-decagram", width=16, color="#00E676"),
            dmc.Text(f"Pushed {loaded} tables ({total:,} rows) to pipeline", size="xs", c="#00E676"),
        ],
        gap="xs", mt="xs",
    )

    pipeline_state = {
        'data_pushed':   True,
        'tables_count':  n_tables,
        'total_rows':    total,
        'table_names':   list(clean_tables.keys()),
        'timestamp':     time.strftime('%Y-%m-%d %H:%M:%S'),
    }

    return (
        status,
        True,        # disable push button after successful push (prevent double-push)
        done_cards,
        _build_pipeline_summary(staged),
        stage_display,
        pipeline_state,
    )


# ═══════════════════════════════════════════════════════════════════════════
# CB11: RESET ALL DATA — clear store and all UI displays
# ═══════════════════════════════════════════════════════════════════════════
@callback(
    Output("pa-graph-tables-area",  "children",  allow_duplicate=True),
    Output("pa-legacy-tables-area", "children",  allow_duplicate=True),
    Output("pa-tables-badge",       "children",  allow_duplicate=True),
    Output("pa-tables-badge",       "color",     allow_duplicate=True),
    Output("pa-push-btn",           "disabled",  allow_duplicate=True),
    Output("pa-gen-status",         "children",  allow_duplicate=True),
    Output("pa-pipe-summary",       "children",  allow_duplicate=True),
    Output("pa-quality-profile",    "children",  allow_duplicate=True),
    Output("pa-data-summary",       "children",  allow_duplicate=True),
    Output("pa-pipe-run-status",    "children",  allow_duplicate=True),
    Output("pa-summary-mode-badge", "children",  allow_duplicate=True),
    Output("pipeline-state",        "data",      allow_duplicate=True),
    Output("pa-n-customers-store",  "data",      allow_duplicate=True),
    Output("pa-pipe-stages",        "children",  allow_duplicate=True),
    Input("pa-reset-btn", "n_clicks"),
    prevent_initial_call=True,
    # NOTE: Intentionally NO @GlobalExceptionHandler.wrap
    # A partial reset leaves inconsistent state which is more dangerous
    # than a visible error.  Let Dash show the traceback if reset fails.
)
def reset_all_data(n_clicks):
    """
    Completely wipe all staged data and reset every UI element to blank state.

    What gets cleared:
    - _PA_DATA_STORE          (module-level dict)
    - pipeline._staged_tables (singleton)
    - pipeline._pa_push_summary
    - pipeline._last_pushed_tables
    - All 14 output components (table cards, badges, status text, etc.)

    This is the "nuclear option" — use when starting a fresh analysis.

    NOTE: This callback intentionally skips @GlobalExceptionHandler.wrap.
    If reset throws, display a visible crash rather than a silent partial reset.

    Parameters
    ----------
    n_clicks : int or None  — click count from Reset button
    """
    print(
        f"[PA-TRACE] reset_all_data FIRED: n_clicks={n_clicks}, "
        f"triggered={ctx.triggered_id}", flush=True
    )
    if not n_clicks:
        return (no_update,) * 14

    # 1. Wipe module-level dict (all values removed, not replaced with new dict)
    _PA_DATA_STORE.clear()

    # 2. Wipe pipeline singleton
    pipeline = get_pipeline()
    try:
        pipeline._staged_tables = {}
    except Exception:  # noqa: BLE001
        pass   # pipeline may not have staged tables yet on first load
    pipeline._pa_push_summary    = ""
    pipeline._last_pushed_tables = {}

    # 3. Build empty placeholder displays
    empty_graph  = [dmc.Center(dmc.Text("No graph tables loaded", size="sm", c="dimmed"), style={"minHeight": "60px"})]
    empty_legacy = [dmc.Center(dmc.Text("No legacy tables loaded", size="sm", c="dimmed"), style={"minHeight": "60px"})]
    empty_status = dmc.Group(
        [
            DashIconify(icon="mdi:delete", width=16, color="#FF5252"),
            dmc.Text("All staged data cleared.", size="xs", c="#FF5252"),
        ],
        gap="xs", mt="xs",
    )

    return (
        empty_graph,
        empty_legacy,
        "0 / 13 loaded",
        "gray",
        True,       # push disabled
        empty_status,
        dmc.Center(dmc.Text("No data — generate or upload", size="sm", c="dimmed")),
        dmc.Center(dmc.Text("No data", size="sm", c="dimmed")),
        dmc.Center(dmc.Text("No data", size="sm", c="dimmed")),
        dmc.Center(dmc.Text("Cleared", size="sm", c="dimmed")),
        "—",
        {"staged": False, "tables": 0, "rows": 0},
        None,
        _build_pipeline_stages_display({}),
    )


# ═══════════════════════════════════════════════════════════════════════════
# CB12: REFRESH PAGE — re-render cards from current store (no regen)
# ═══════════════════════════════════════════════════════════════════════════
@callback(
    Output("pa-graph-tables-area",  "children",  allow_duplicate=True),
    Output("pa-legacy-tables-area", "children",  allow_duplicate=True),
    Output("pa-tables-badge",       "children",  allow_duplicate=True),
    Output("pa-tables-badge",       "color",     allow_duplicate=True),
    Output("pa-push-btn",           "disabled",  allow_duplicate=True),
    Output("pa-gen-status",         "children",  allow_duplicate=True),
    Output("pa-pipe-summary",       "children",  allow_duplicate=True),
    Output("pa-quality-profile",    "children",  allow_duplicate=True),
    Output("pa-data-summary",       "children",  allow_duplicate=True),
    Input("pa-refresh-btn", "n_clicks"),
    State("pa-page-size",   "value"),
    State("pa-source-mode", "data"),
    prevent_initial_call=True,
)
@GlobalExceptionHandler.wrap(fallback=(no_update,) * 9)
def refresh_page(n_clicks, page_size, source_mode):
    """
    Re-render all data displays from current in-memory data store.

    This DOES NOT re-generate or re-upload data.  It simply reads whatever
    is currently in _PA_DATA_STORE and rebuilds the card + chart displays.

    Useful after:
    - Navigating away and back (if cards somehow didn't hydrate)
    - Changing page-size without triggering CB9
    - Manual recovery if displays get out of sync

    Parameters
    ----------
    n_clicks    : int or None  — click count from Refresh button
    page_size   : int          — current page size value
    source_mode : str          — "sample" or "actual"
    """
    print(
        f"[PA-TRACE] refresh_page FIRED: n_clicks={n_clicks}, "
        f"triggered={ctx.triggered_id}", flush=True
    )
    if not n_clicks:
        return (no_update,) * 9

    page_size   = int(page_size or 5)
    source_mode = source_mode or "sample"
    staged      = _pa_get_staged()

    if not staged:
        empty = dmc.Center(dmc.Text("No data loaded — generate or upload first.", size="sm", c="dimmed"))
        return (
            [empty], [empty],
            "0 / 13 loaded", "gray", True,
            dmc.Text("No data to refresh", size="xs", c="dimmed"),
            empty, empty, empty,
        )

    graph_cards, legacy_cards, total, loaded = _build_split_table_cards(staged, page_size)

    status = dmc.Group(
        [
            DashIconify(icon="mdi:refresh", width=16, color="#00BCD4"),
            dmc.Text(f"Refreshed: {loaded} table(s) | {total:,} rows", size="xs", c="#00BCD4"),
        ],
        gap="xs", mt="xs",
    )

    return (
        graph_cards,
        legacy_cards,
        f"{loaded} / 13 loaded | {total:,} rows",
        "green" if loaded else "gray",
        loaded == 0,
        status,
        _build_pipeline_summary(staged),
        _build_quality_profile(staged),
        _build_data_summary(staged, source_mode),
    )
