"""
Page: Comparative Runs (v10 — A3)
====================================
Business Logic: Compare two pipeline runs side-by-side — risk drift,
tier migration, customer score changes. Uses run history from SQLite.
"""

import dash
from dash import html, dcc, callback, Input, Output, State, no_update
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.graph_objects as go
import pandas as pd
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, APP

dash.register_page(
    __name__,
    path="/comparative-runs",
    name="Comparative Runs",
    title=f"FCDAI v{APP.VERSION} | Comparative Runs",
)

TIER_COLORS = {"P1": "#FF1744", "P2": "#FF9800", "P3": "#FFD600", "P4": "#00E676"}

layout = dmc.Box(
    [
        dcc.Interval(id="comp-init", interval=1000, max_intervals=1),
        dmc.Group(
            [
                dmc.Stack(
                    [
                        dmc.Title("Comparative Runs", order=2, c="white"),
                        dmc.Text(
                            "Pipeline Run Comparison & Risk Drift Analysis", c="dimmed", size="sm"
                        ),
                    ],
                    gap=2,
                ),
                dmc.Group(
                    [],
                    gap="sm",
                ),
            ],
            justify="space-between",
            mb="lg",
        ),
        # v12.26 Task 5: Business purpose banner
        dmc.Paper(
            dmc.Group(
                [
                    DashIconify(icon="mdi:information-outline", width=18, color="#00D4FF"),
                    dmc.Text(
                        "📊 Why This Page? Compare two pipeline runs to detect risk drift — whether customers "
                        "are moving UP (escalating threat) or DOWN (resolving) in risk tier over time. "
                        "Essential for demonstrating to regulators that your AML controls are working. "
                        "Select Run A (baseline) and Run B (current), then click Compare.",
                        size="sm",
                        c="white",
                        style={"lineHeight": "1.6"},
                    ),
                ],
                gap="sm",
                align="flex-start",
            ),
            p="sm",
            radius="md",
            mb="md",
            style={"background": "rgba(0,212,255,0.06)", "border": "1px solid rgba(0,212,255,0.2)"},
        ),
        # Run selector
        dmc.Paper(
            [
                dmc.Group(
                    [
                        DashIconify(icon="mdi:compare-horizontal", width=22, color=THEME.PRIMARY),
                        dmc.Text("Select Runs to Compare", fw=600, c="white"),
                    ],
                    gap="sm",
                    mb="md",
                ),
                dmc.SimpleGrid(
                    cols={"base": 1, "md": 3},
                    spacing="md",
                    children=[
                        dmc.Select(
                            id="comp-run-a",
                            label="Run A (Baseline)",
                            placeholder="Select run...",
                            styles={
                                "input": {
                                    "backgroundColor": THEME.DARK_BG,
                                    "color": "white",
                                    "border": f"1px solid {THEME.DARK_BORDER}",
                                }
                            },
                        ),
                        dmc.Select(
                            id="comp-run-b",
                            label="Run B (Current)",
                            placeholder="Select run...",
                            styles={
                                "input": {
                                    "backgroundColor": THEME.DARK_BG,
                                    "color": "white",
                                    "border": f"1px solid {THEME.DARK_BORDER}",
                                }
                            },
                        ),
                        dmc.Stack(
                            [
                                dmc.Text(" ", size="xs"),
                                dmc.Button(
                                    "Compare",
                                    id="comp-compare-btn",
                                    color="cyan",
                                    variant="gradient",
                                    gradient={"from": "cyan", "to": "indigo"},
                                    leftSection=DashIconify(icon="mdi:compare", width=18),
                                ),
                            ],
                            gap="xs",
                            justify="flex-end",
                        ),
                    ],
                ),
            ],
            p="lg",
            radius="lg",
            className="glass-card",
            mb="md",
        ),
        # Export bar
        dmc.Paper(
            [
                dmc.Group(
                    [
                        DashIconify(icon="mdi:download-circle-outline", width=22, color="#00D4FF"),
                        dmc.Text("Export Run History", fw=600, c="white", size="sm"),
                        dmc.Button(
                            "⬇ Export CSV",
                            id="comp-export-csv",
                            size="xs",
                            variant="light",
                            color="cyan",
                            leftSection=DashIconify(icon="mdi:download", width=14),
                        ),
                    ],
                    gap="md",
                    align="center",
                ),
            ],
            p="sm",
            radius="lg",
            className="glass-card",
            mb="md",
            style={
                "background": "rgba(0,212,255,0.04)",
                "border": "1px solid rgba(0,212,255,0.15)",
            },
        ),
        dcc.Download(id="comp-download"),
        html.Div(id="comp-results"),
    ]
)


@callback(
    [Output("comp-run-a", "data"), Output("comp-run-b", "data")],
    Input("comp-init", "n_intervals"),
    Input("pipeline-state", "data"),
    Input("global-refresh-ts", "data"),
)
def populate_runs(_init, _pipeline_state, _gr):
    from engine import get_pipeline

    pipeline = get_pipeline()
    history = pipeline.get_run_history()
    if history is None or len(history) == 0:
        return [], []
    options = []
    for _, row in history.iterrows():
        rid = row.get("run_id", "?")
        custs = row.get("customers", 0)
        status = row.get("status", "?")
        ts = str(row.get("started_at", ""))[:19]
        options.append(
            {
                "value": str(rid),
                "label": f"Run #{rid} — {custs} customers — {status} — {ts}",
            }
        )
    return options, options


@callback(
    Output("comp-results", "children"),
    Input("comp-compare-btn", "n_clicks"),
    [State("comp-run-a", "value"), State("comp-run-b", "value")],
    prevent_initial_call=True,
)
def compare_runs(_, run_a, run_b):
    if not run_a or not run_b:
        return dmc.Alert("Select both Run A and Run B to compare", color="yellow")

    from engine import get_pipeline

    pipeline = get_pipeline()
    history = pipeline.get_run_history()

    if history is None or len(history) == 0:
        return dmc.Alert("No run history available", color="red")

    # Get run info
    run_a_id = int(run_a)
    run_b_id = int(run_b)

    info_a = history[history["run_id"] == run_a_id]
    info_b = history[history["run_id"] == run_b_id]

    if len(info_a) == 0 or len(info_b) == 0:
        return dmc.Alert("One or both runs not found", color="red")

    info_a = info_a.iloc[0]
    info_b = info_b.iloc[0]

    # Build comparison
    comparison_metrics = [
        ("Customers", info_a.get("customers", 0), info_b.get("customers", 0), "mdi:account-group"),
        ("Nodes", info_a.get("nodes", 0), info_b.get("nodes", 0), "mdi:graph"),
        ("Edges", info_a.get("edges", 0), info_b.get("edges", 0), "mdi:vector-polyline"),
        ("Duration (s)", info_a.get("duration", 0), info_b.get("duration", 0), "mdi:clock"),
        ("Status", info_a.get("status", "?"), info_b.get("status", "?"), "mdi:check-circle"),
    ]

    comparison_rows = []
    for metric, val_a, val_b, icon in comparison_metrics:
        try:
            va = float(val_a)
            vb = float(val_b)
            if va > 0:
                pct_change = ((vb - va) / va) * 100
                change_text = f"{pct_change:+.1f}%"
                change_color = (
                    "#FF1744" if pct_change > 20 else "#00E676" if pct_change < -20 else "#FFD600"
                )
            else:
                change_text = "N/A"
                change_color = "gray"
        except (ValueError, TypeError):
            change_text = "—"
            change_color = "gray"

        comparison_rows.append(
            dmc.Group(
                [
                    dmc.Group(
                        [
                            DashIconify(icon=icon, width=18, color="dimmed"),
                            dmc.Text(metric, c="white", size="sm", w=120),
                        ],
                        gap="xs",
                    ),
                    dmc.Text(str(val_a), c="#00D4FF", size="sm", w=100, ta="right"),
                    dmc.Text("→", c="dimmed", size="sm"),
                    dmc.Text(str(val_b), c="#00D4FF", size="sm", w=100),
                    dmc.Badge(change_text, color=change_color, size="xs", variant="light", w=80),
                ],
                gap="md",
                style={"padding": "8px 0", "borderBottom": f"1px solid {THEME.DARK_BORDER}"},
            ),
        )

    # Build bar chart
    metric_names = [m[0] for m in comparison_metrics[:4]]
    vals_a = []
    vals_b = []
    for m in comparison_metrics[:4]:
        try:
            vals_a.append(float(m[1]))
        except:
            vals_a.append(0)
        try:
            vals_b.append(float(m[2]))
        except:
            vals_b.append(0)

    bar_fig = go.Figure()
    bar_fig.add_trace(
        go.Bar(
            name=f"Run #{run_a_id}",
            x=metric_names,
            y=vals_a,
            marker_color="#00D4FF",
            opacity=0.8,
        )
    )
    bar_fig.add_trace(
        go.Bar(
            name=f"Run #{run_b_id}",
            x=metric_names,
            y=vals_b,
            marker_color="#9D4EDD",
            opacity=0.8,
        )
    )
    bar_fig.update_layout(
        barmode="group",
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(t=30, b=30, l=40, r=20),
        height=300,
        legend=dict(orientation="h", y=1.1),
    )

    return dmc.Stack(
        [
            dmc.SimpleGrid(
                cols={"base": 1, "md": 2},
                spacing="md",
                children=[
                    dmc.Paper(
                        [
                            dmc.Text("Metric Comparison", fw=600, c="white", mb="sm"),
                            dmc.Stack(comparison_rows, gap=0),
                        ],
                        p="lg",
                        radius="lg",
                        className="glass-card",
                    ),
                    dmc.Paper(
                        [
                            dmc.Text("Visual Comparison", fw=600, c="white", mb="sm"),
                            dcc.Graph(figure=bar_fig, config={"displayModeBar": False}),
                        ],
                        p="lg",
                        radius="lg",
                        className="glass-card",
                    ),
                ],
            ),
            dmc.Alert(
                "Comparative analysis shows changes between pipeline runs. "
                "Large positive changes in customer count may indicate data scope changes. "
                "Monitor risk tier migrations for compliance drift.",
                title="Analysis Notes",
                color="blue",
                icon=DashIconify(icon="mdi:information"),
            ),
        ],
        gap="md",
    )


# ── EXPORT CALLBACK ───────────────────────────────────────────────────────────
@callback(
    Output("comp-download", "data"),
    Input("comp-export-csv", "n_clicks"),
    prevent_initial_call=True,
)
def export_comp_csv(_):
    """Export pipeline run history as CSV."""
    from engine import get_pipeline

    pipeline = get_pipeline()
    history = pipeline.get_run_history()
    if history is not None and len(history) > 0:
        return dcc.send_data_frame(history.to_csv, "comparative_runs_history.csv", index=False)
    return no_update
