"""
Page: Data Quality Observatory (v16.35)
=========================================
v16.35 ENHANCEMENTS
-------------------
  • LIVE SYNC with Port Authority staged data — subscribes to pa-n-customers-store
    so the page refreshes instantly when the user generates or uploads data in
    Port Authority, *without* needing a full pipeline run.
  • ALL 13 TABLES monitored: 8 legacy (customer, account, kyc, transaction,
    historical, alert, relationship, case) + 5 graph (node, edge,
    relationship_edge, shared_attribute, temporal).
  • INLINE DQ COMPUTATION — metrics are computed directly from the staged
    DataFrames so the page is useful even before the pipeline is run.
  • SCHEMA NETWORK GRAPH — Plotly force-directed viz showing all 13 tables as
    nodes and FK joins as edges. Orphan mismatches highlighted in red.
  • NULL HEATMAP — per-column null-% heatmap across all loaded tables.
  • REFERENTIAL INTEGRITY MATRIX — a dedicated table showing every FK
    relationship, expected cardinality, and orphan counts.
  • AMOUNT / RISK-SCORE DISTRIBUTIONS — violin charts for key numeric columns
    (transaction.amount, transaction.risk_score, node.risk_score, etc.).
  • DUPLICATE RATE per table.
  • COLUMN TYPE COMPOSITION stacked bar.
  • DATA COVERAGE RADAR per quality dimension.

SYNC DESIGN
-----------
  Inputs:
    pa-n-customers-store : fires every time Port Authority generates/loads data
    pipeline-state       : fires after a full pipeline run
    global-refresh-ts    : manual refresh

  Data source:
    _pa_get_staged() — directly reads staged DataFrames (available immediately
    after Port Authority load, before pipeline run).

INDUSTRY ALIGNMENT
------------------
  DAMA-DMBOK2 · ISO 8000 · BCBS 239 · Basel III RDA

AIR-GAPPED | ZERO DATA LEAKAGE | PII PROTECTED | OFFLINE-ONLY
"""
from __future__ import annotations

import math
import sys
from datetime import datetime
from pathlib import Path

import dash
import dash_mantine_components as dmc
import pandas as pd
import plotly.graph_objects as go
from dash import Input, Output, callback, dcc, html
from dash_iconify import DashIconify

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import APP, THEME  # noqa: F401
from engine import get_pipeline  # noqa: F401

# Direct staged-data accessor — no pipeline run required
from pages._port_authority._state import _pa_get_staged  # noqa: E402

dash.register_page(
    __name__,
    path="/data-quality",
    name="Data Quality",
    title=f"AIM v{APP.VERSION} | Data Quality Observatory",
)

# ─────────────────────────────────────────────────────────────────
# COLOUR PALETTE
# ─────────────────────────────────────────────────────────────────
_C = {
    "ok":     "#00E676",
    "warn":   "#FFD600",
    "bad":    "#FF6B6B",
    "block":  "#FF1744",
    "blue":   "#00D4FF",
    "purple": "#9D4EDD",
    "dim":    "#8899AA",
    "card":   "#0D1221",
    "border": "#1E293B",
    "bg":     "#070C14",
    "muted":  "#111827",
}

# ─────────────────────────────────────────────────────────────────
# TABLE CATALOGUE  (all 13 PA tables)
# ─────────────────────────────────────────────────────────────────
_ALL_TABLES: dict = {
    # ── Legacy (8) ────────────────────────────────────────────────
    "customer":          {"icon": "mdi:account-group",          "color": "#00D4FF",  "group": "legacy", "label": "Customer",     "pk": "customer_id"},
    "account":           {"icon": "mdi:bank-outline",           "color": "#38BDF8",  "group": "legacy", "label": "Account",      "pk": "account_id"},
    "kyc":               {"icon": "mdi:shield-account",         "color": "#818CF8",  "group": "legacy", "label": "KYC",          "pk": "customer_id"},
    "transaction":       {"icon": "mdi:transfer",               "color": "#C084FC",  "group": "legacy", "label": "Transaction",  "pk": "txn_id"},
    "historical":        {"icon": "mdi:history",                "color": "#F472B6",  "group": "legacy", "label": "Historical",   "pk": "record_id"},
    "alert":             {"icon": "mdi:bell-alert",             "color": "#FB923C",  "group": "legacy", "label": "Alert",        "pk": "alert_id"},
    "relationship":      {"icon": "mdi:account-network",        "color": "#FBBF24",  "group": "legacy", "label": "Relationship", "pk": None},
    "case":              {"icon": "mdi:folder-open",            "color": "#34D399",  "group": "legacy", "label": "Case",         "pk": "case_id"},
    # ── Graph (5) ─────────────────────────────────────────────────
    "node":              {"icon": "mdi:circle-slice-8",         "color": "#22D3EE",  "group": "graph",  "label": "Node",         "pk": "node_id"},
    "edge":              {"icon": "mdi:swap-horizontal-circle", "color": "#818CF8",  "group": "graph",  "label": "Edge",         "pk": None},
    "relationship_edge": {"icon": "mdi:link-variant",           "color": "#A78BFA",  "group": "graph",  "label": "Rel. Edge",    "pk": None},
    "shared_attribute":  {"icon": "mdi:tag-multiple",           "color": "#C084FC",  "group": "graph",  "label": "Shared Attr.", "pk": None},
    "temporal":          {"icon": "mdi:timeline-clock",         "color": "#2DD4BF",  "group": "graph",  "label": "Temporal",     "pk": None},
}

# FK rules  [(child_table, child_col, parent_table, parent_col)]
_FK_RULES: list = [
    ("account",          "customer_id",  "customer", "customer_id"),
    ("kyc",              "customer_id",  "customer", "customer_id"),
    ("transaction",      "customer_id",  "customer", "customer_id"),
    ("historical",       "customer_id",  "customer", "customer_id"),
    ("alert",            "customer_id",  "customer", "customer_id"),
    ("relationship",     "source_id",    "customer", "customer_id"),
    ("relationship",     "target_id",    "customer", "customer_id"),
    ("case",             "customer_id",  "customer", "customer_id"),
    ("edge",             "from_node",    "node",     "node_id"),
    ("edge",             "to_node",      "node",     "node_id"),
    ("relationship_edge","from_node",    "node",     "node_id"),
    ("relationship_edge","to_node",      "node",     "node_id"),
    ("shared_attribute", "node_id",      "node",     "node_id"),
    ("temporal",         "node_id",      "node",     "node_id"),
]

_SELF_LOOP_TABLES: dict = {
    "edge":              ("from_node", "to_node"),
    "relationship_edge": ("from_node", "to_node"),
    "relationship":      ("source_id", "target_id"),
}

_DATE_COLS: dict = {
    "customer":         ["registration_date"],
    "account":          ["open_date"],
    "kyc":              ["kyc_date"],
    "transaction":      ["timestamp"],
    "historical":       ["event_date"],
    "alert":            ["alert_date"],
    "relationship":     ["start_date"],
    "case":             ["opened_date"],
    "edge":             ["date"],
    "relationship_edge":["start_date"],
    "shared_attribute": ["last_used_date"],
    "temporal":         ["date"],
}

_DIST_COLS: list = [
    ("transaction",  "amount",     "Txn Amount"),
    ("node",         "risk_score", "Node Risk Score"),
    ("temporal",     "value",      "Temporal Value"),
    ("kyc",          "kyc_score",  "KYC Score"),
    ("alert",        "score",      "Alert Score"),
]

_TODAY = datetime.now().date()


# ─────────────────────────────────────────────────────────────────
# INLINE DQ COMPUTATION
# ─────────────────────────────────────────────────────────────────

def _compute_dq(tables: dict) -> dict:
    per_table: dict = {}

    for tname in _ALL_TABLES:
        df = tables.get(tname)
        if df is None or not isinstance(df, pd.DataFrame) or len(df) == 0:
            per_table[tname] = {"present": False, "rows": 0, "cols": 0, "score": None, "null_total": 0}
            continue

        n_rows = len(df)
        n_cols = len(df.columns)
        n_cells = max(n_rows * n_cols, 1)

        # null stats
        null_per_col = df.isnull().sum()
        null_total = int(null_per_col.sum())
        null_pct = null_total / n_cells
        null_col_map = {c: round(float(null_per_col[c]) / n_rows, 4) for c in df.columns}

        # duplicates
        try:
            dup_count = int(df.duplicated().sum())
        except Exception:
            dup_count = 0
        dup_rate = dup_count / n_rows if n_rows else 0.0

        # column types
        type_counts = {"numeric": 0, "text": 0, "datetime": 0, "other": 0}
        for dtype in df.dtypes:
            if pd.api.types.is_numeric_dtype(dtype):
                type_counts["numeric"] += 1
            elif pd.api.types.is_datetime64_any_dtype(dtype):
                type_counts["datetime"] += 1
            elif pd.api.types.is_object_dtype(dtype) or pd.api.types.is_string_dtype(dtype):
                type_counts["text"] += 1
            else:
                type_counts["other"] += 1

        # future dates
        fd_count = 0
        for dc in _DATE_COLS.get(tname, []):
            if dc in df.columns:
                try:
                    col_s = pd.to_datetime(df[dc], errors="coerce")
                    fd_count += int((col_s.dt.date > _TODAY).sum())
                except Exception:
                    pass

        completeness = 1.0 - null_pct
        consistency  = 1.0 - dup_rate
        validity     = 1.0 - min(fd_count / n_rows, 1.0)
        score        = completeness * 0.40 + consistency * 0.30 + validity * 0.30
        mem_kb       = int(df.memory_usage(deep=False).sum() / 1024)

        per_table[tname] = {
            "present":      True,
            "rows":         n_rows,
            "cols":         n_cols,
            "null_total":   null_total,
            "null_pct":     round(null_pct, 4),
            "null_col_map": null_col_map,
            "dup_count":    dup_count,
            "dup_rate":     round(dup_rate, 4),
            "type_counts":  type_counts,
            "fd_count":     fd_count,
            "completeness": round(completeness, 4),
            "consistency":  round(consistency, 4),
            "validity":     round(validity, 4),
            "score":        round(score, 4),
            "mem_kb":       mem_kb,
        }

    # FK matrix
    fk_matrix = []
    for (ct, cc, pt, pc) in _FK_RULES:
        cdf = tables.get(ct)
        pdf = tables.get(pt)
        rule_str = f"{ct}.{cc} → {pt}.{pc}"
        if cdf is None or pdf is None:
            fk_matrix.append({"rule": rule_str, "child": ct, "parent": pt,
                               "orphan_count": None, "child_rows": 0, "ok": None})
            continue
        if cc not in cdf.columns or pc not in pdf.columns:
            fk_matrix.append({"rule": rule_str, "child": ct, "parent": pt,
                               "orphan_count": 0, "child_rows": len(cdf), "ok": True})
            continue
        parent_set = set(pdf[pc].dropna().astype(str))
        orphans = int((~cdf[cc].astype(str).isin(parent_set)).sum())
        fk_matrix.append({"rule": rule_str, "child": ct, "parent": pt,
                           "orphan_count": orphans, "child_rows": len(cdf),
                           "ok": orphans == 0})

    # self-loops
    self_loops: dict = {}
    for tname, (fc, tc) in _SELF_LOOP_TABLES.items():
        df = tables.get(tname)
        if df is None or fc not in df.columns or tc not in df.columns:
            continue
        cnt = int((df[fc].astype(str) == df[tc].astype(str)).sum())
        if cnt or tname == "edge":
            self_loops[tname] = cnt

    # future dates summary
    future_dates: dict = {t: per_table[t]["fd_count"]
                          for t in _ALL_TABLES
                          if per_table.get(t, {}).get("fd_count", 0) > 0}

    # readiness
    all_orphans = sum(r.get("orphan_count") or 0 for r in fk_matrix)
    all_sl      = sum(self_loops.values())
    loaded      = [t for t in _ALL_TABLES if per_table.get(t, {}).get("present")]
    avg_score   = (sum(per_table[t]["score"] for t in loaded) / len(loaded)) if loaded else None

    if not loaded:
        readiness = "NO_DATA"
    elif all_orphans > 50 or (avg_score is not None and avg_score < 0.65):
        readiness = "BLOCKED"
    elif all_orphans > 0 or all_sl > 0 or future_dates:
        readiness = "WARN"
    else:
        readiness = "READY"

    return {
        "per_table":   per_table,
        "fk_matrix":   fk_matrix,
        "self_loops":  self_loops,
        "future_dates":future_dates,
        "readiness":   readiness,
        "n_loaded":    len(loaded),
        "total_rows":  sum(per_table[t].get("rows", 0) for t in loaded),
    }


# ─────────────────────────────────────────────────────────────────
# CHART & UI HELPERS
# ─────────────────────────────────────────────────────────────────

_BASE_LAYOUT = dict(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(0,0,0,0)",
    font={"color": "#C9D1D9", "size": 11, "family": "Inter, sans-serif"},
    margin={"t": 40, "b": 60, "l": 60, "r": 20},
)
_GRID  = dict(gridcolor="#1E293B", zeroline=False)


def _hex_rgba(hex_color: str, alpha: float = 0.15) -> str:
    """Convert '#RRGGBB' → 'rgba(r,g,b,alpha)' for Plotly 6.x compatibility."""
    h = hex_color.lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    if len(h) != 6:
        return f"rgba(136,136,136,{alpha})"
    r = int(h[0:2], 16)
    g = int(h[2:4], 16)
    b = int(h[4:6], 16)
    return f"rgba({r},{g},{b},{alpha})"


def _no_fig(msg: str = "Generate or upload data in Port Authority first") -> go.Figure:
    fig = go.Figure()
    fig.add_annotation(text=msg, xref="paper", yref="paper",
                       x=0.5, y=0.5, showarrow=False,
                       font={"color": "#8899AA", "size": 12})
    fig.update_layout(paper_bgcolor="rgba(0,0,0,0)",
                      plot_bgcolor="rgba(0,0,0,0)",
                      margin={"t": 10, "b": 10, "l": 10, "r": 10}, height=200)
    return fig


def _score_color(score) -> str:
    if score is None:
        return _C["dim"]
    return _C["ok"] if score >= 0.90 else (_C["warn"] if score >= 0.70 else _C["bad"])


def _pct(v, d: int = 1) -> str:
    return "—" if v is None else f"{v * 100:.{d}f}%"


# ── CHART 1: Row distribution ─────────────────────────────────────────────
def _chart_row_dist(per_table: dict) -> go.Figure:
    loaded = [(t, per_table[t]) for t in _ALL_TABLES if per_table.get(t, {}).get("present")]
    if not loaded:
        return _no_fig()
    fig = go.Figure(go.Bar(
        y=[_ALL_TABLES[t]["label"] for t, _ in loaded],
        x=[p["rows"] for _, p in loaded],
        orientation="h",
        marker=dict(color=[_ALL_TABLES[t]["color"] for t, _ in loaded],
                    line=dict(color="rgba(255,255,255,0.06)", width=1)),
        text=[f"{p['rows']:,}" for _, p in loaded],
        textposition="outside",
        textfont=dict(size=10, color="white"),
        hovertemplate="<b>%{y}</b><br>Rows: %{x:,}<extra></extra>",
    ))
    fig.update_layout(**_BASE_LAYOUT,
                      title=dict(text="Row Count per Table", font=dict(size=13, color="#58A6FF")),
                      xaxis=dict(**_GRID, title=None, tickfont=dict(color="#8B949E")),
                      yaxis=dict(title=None, tickfont=dict(color="#C9D1D9", size=10)),
                      height=max(260, len(loaded) * 28 + 80), showlegend=False)
    return fig


# ── CHART 2: Null heatmap ─────────────────────────────────────────────────
def _chart_null_heatmap(per_table: dict) -> go.Figure:
    loaded = [(t, p) for t, p in per_table.items()
              if p.get("present") and p.get("null_col_map")]
    if not loaded:
        return _no_fig()

    all_cols: list = []
    for _, p in loaded:
        for c in p["null_col_map"]:
            if c not in all_cols:
                all_cols.append(c)
    if not all_cols:
        return _no_fig()

    z = [[p["null_col_map"].get(c, 0) * 100 for c in all_cols] for _, p in loaded]
    fig = go.Figure(go.Heatmap(
        z=z,
        x=all_cols,
        y=[_ALL_TABLES.get(t, {}).get("label", t) for t, _ in loaded],
        colorscale=[[0,"#0D1221"],[0.3,"#1A2C50"],[0.7,"#B45309"],[1,"#FF1744"]],
        text=[[f"{v:.1f}%" for v in row] for row in z],
        texttemplate="%{text}",
        textfont=dict(size=8),
        hovertemplate="<b>%{y}</b><br>Col: %{x}<br>Null: %{z:.1f}%<extra></extra>",
        showscale=True,
        colorbar=dict(title="Null %", ticksuffix="%",
                      tickfont=dict(color="#8B949E"),
                      title_font=dict(color="#8B949E")),
    ))
    fig.update_layout(**{**_BASE_LAYOUT, "margin": {"t":40,"b":180,"l":110,"r":70}},
                      title=dict(text="Null % per Column (red = high null rate)",
                                 font=dict(size=13, color="#58A6FF")),
                      xaxis=dict(tickangle=-50, tickfont=dict(size=8, color="#8B949E"), title=None),
                      yaxis=dict(tickfont=dict(size=10, color="#C9D1D9"), title=None),
                      height=max(320, len(loaded)*26+210))
    return fig


# ── CHART 3: Column type composition ─────────────────────────────────────
def _chart_col_types(per_table: dict) -> go.Figure:
    loaded = [(t, p) for t, p in per_table.items() if p.get("present")]
    if not loaded:
        return _no_fig()
    labels = [_ALL_TABLES.get(t, {}).get("label", t) for t, _ in loaded]
    fig = go.Figure()
    for dtype, color in [("numeric","#00D4FF"),("text","#FB923C"),
                          ("datetime","#A78BFA"),("other","#6B7280")]:
        vals = [p["type_counts"].get(dtype, 0) for _, p in loaded]
        if sum(vals) == 0:
            continue
        fig.add_trace(go.Bar(name=dtype.title(), x=labels, y=vals,
                             marker=dict(color=color),
                             hovertemplate=f"<b>%{{x}}</b><br>{dtype.title()}: %{{y}}<extra></extra>"))
    fig.update_layout(**_BASE_LAYOUT,
                      title=dict(text="Column Type Breakdown per Table", font=dict(size=13,color="#58A6FF")),
                      barmode="stack",
                      xaxis=dict(tickangle=-35, tickfont=dict(size=9,color="#C9D1D9"), **_GRID),
                      yaxis=dict(title="# Columns", tickfont=dict(color="#8B949E"), **_GRID),
                      legend=dict(orientation="h", y=1.12, x=0.5, xanchor="center"),
                      height=330)
    return fig


# ── CHART 4: Duplicate rate ───────────────────────────────────────────────
def _chart_dup_rate(per_table: dict) -> go.Figure:
    loaded = [(t, p) for t, p in per_table.items() if p.get("present")]
    if not loaded:
        return _no_fig()
    labels = [_ALL_TABLES.get(t, {}).get("label", t) for t, _ in loaded]
    rates  = [p.get("dup_rate", 0) * 100 for _, p in loaded]
    colors = [_C["bad"] if r > 5 else (_C["warn"] if r > 0 else _C["ok"]) for r in rates]
    fig = go.Figure(go.Bar(x=labels, y=rates,
                           marker=dict(color=colors),
                           text=[f"{r:.2f}%" for r in rates],
                           textposition="outside",
                           textfont=dict(size=9, color="white"),
                           hovertemplate="<b>%{x}</b><br>Dup Rate: %{y:.2f}%<extra></extra>"))
    fig.update_layout(**_BASE_LAYOUT,
                      title=dict(text="Duplicate Row Rate %  (green=0%, amber=low, red=>5%)",
                                 font=dict(size=13,color="#58A6FF")),
                      xaxis=dict(tickangle=-35,tickfont=dict(size=9,color="#C9D1D9"), **_GRID),
                      yaxis=dict(title="Dup Rate %", ticksuffix="%",
                                 tickfont=dict(color="#8B949E"), **_GRID),
                      height=310)
    return fig


# ── CHART 5: Quality radar ────────────────────────────────────────────────
def _chart_quality_radar(per_table: dict) -> go.Figure:
    loaded = [(t, p) for t, p in per_table.items() if p.get("present")]
    if not loaded:
        return _no_fig()
    max_rows = max((p["rows"] for _, p in loaded), default=1) or 1
    dims = ["Completeness", "Consistency", "Validity", "Rows (norm)", "Overall"]
    fig = go.Figure()
    for tname, p in loaded:
        vals = [
            p.get("completeness", 0) * 100,
            p.get("consistency",  0) * 100,
            p.get("validity",     0) * 100,
            min(p.get("rows", 0) / max_rows * 100, 100),
            p.get("score", 0) * 100,
        ]
        meta = _ALL_TABLES.get(tname, {})
        fig.add_trace(go.Scatterpolar(
            r=vals + [vals[0]], theta=dims + [dims[0]],
            fill="toself",
            fillcolor=_hex_rgba(meta.get("color", "#888888"), 0.13),
            line=dict(color=meta.get("color", "#888888"), width=2),
            name=meta.get("label", tname),
            hovertemplate="<b>%{theta}</b>: %{r:.1f}%<extra>" + meta.get("label", tname) + "</extra>",
        ))
    fig.update_layout(**{**_BASE_LAYOUT, "margin": {"t":50,"b":80,"l":50,"r":50}},
                      polar=dict(bgcolor="rgba(0,0,0,0)",
                                 radialaxis=dict(visible=True, range=[0,100],
                                                 tickfont=dict(size=8,color="#8B949E"),
                                                 gridcolor="#1E293B"),
                                 angularaxis=dict(tickfont=dict(size=10,color="#C9D1D9"),
                                                  gridcolor="#1E293B")),
                      title=dict(text="Quality Dimensions Radar (all loaded tables)",
                                 font=dict(size=13, color="#58A6FF")),
                      legend=dict(orientation="h", y=-0.1, x=0.5, xanchor="center",
                                  font=dict(size=9)),
                      height=440)
    return fig


# ── CHART 6: Schema network graph ─────────────────────────────────────────
def _chart_schema_network(per_table: dict, fk_matrix: list) -> go.Figure:
    loaded_set = {t for t, p in per_table.items() if p.get("present")}
    if not loaded_set:
        return _no_fig()

    legacy  = [t for t in _ALL_TABLES if _ALL_TABLES[t]["group"] == "legacy"]
    graph_t = [t for t in _ALL_TABLES if _ALL_TABLES[t]["group"] == "graph"]

    pos: dict = {}
    r_out, r_in = 2.6, 1.25
    for i, t in enumerate(legacy):
        a = 2 * math.pi * i / len(legacy) - math.pi / 2
        pos[t] = (r_out * math.cos(a), r_out * math.sin(a))
    for i, t in enumerate(graph_t):
        a = 2 * math.pi * i / len(graph_t) - math.pi / 2
        pos[t] = (r_in * math.cos(a) + 0.4, r_in * math.sin(a))

    edge_traces = []
    for rule in fk_matrix:
        ct, pt_name = rule["child"], rule["parent"]
        # v16.40 T2: only draw edges where BOTH endpoints are loaded
        if ct not in pos or pt_name not in pos:
            continue
        if ct not in loaded_set or pt_name not in loaded_set:
            continue
        orphans = rule.get("orphan_count", 0) or 0
        clr = _C["bad"] if orphans > 0 else "#1E3A5F"
        x0, y0 = pos[ct]
        x1, y1 = pos[pt_name]
        edge_traces.append(go.Scatter(x=[x0,x1,None], y=[y0,y1,None],
                                      mode="lines",
                                      line=dict(width=2.5 if orphans else 1.5, color=clr),
                                      hoverinfo="skip", showlegend=False))

    nx, ny, ntxt, nc, ns, nhover = [], [], [], [], [], []
    for t, (x, y) in pos.items():
        # v16.40 T2: hide tables that are not loaded — no grey ghost nodes
        if t not in loaded_set:
            continue
        meta    = _ALL_TABLES[t]
        nx.append(x); ny.append(y)
        ntxt.append(meta["label"])
        nc.append(meta["color"])
        ns.append(22)
        rows  = per_table.get(t, {}).get("rows", 0)
        score = per_table.get(t, {}).get("score")
        nhover.append(f"<b>{meta['label']}</b><br>"
                      f"Loaded<br>"
                      f"Rows: {rows:,}<br>Score: {_pct(score)}")

    node_trace = go.Scatter(x=nx, y=ny, mode="markers+text",
                            marker=dict(size=ns, color=nc,
                                        line=dict(color="rgba(255,255,255,0.15)", width=1.5)),
                            text=ntxt, textposition="top center",
                            textfont=dict(size=9, color="#C9D1D9"),
                            hovertext=nhover, hoverinfo="text", showlegend=False)

    fig = go.Figure(data=edge_traces + [node_trace])
    fig.add_annotation(x=0, y=-3.2, text="◉ Legacy Tables (outer ring)", showarrow=False,
                       font=dict(size=10, color="#FB923C"), xref="x", yref="y")
    fig.add_annotation(x=0, y=3.1, text="◉ Graph Tables (inner ring)", showarrow=False,
                       font=dict(size=10, color="#22D3EE"), xref="x", yref="y")
    fig.update_layout(**{**_BASE_LAYOUT, "margin": {"t":50,"b":60,"l":20,"r":20}},
                      title=dict(text="Schema Network — Tables & FK Joins  (red edge = orphan mismatch)",
                                 font=dict(size=13, color="#58A6FF")),
                      xaxis=dict(showgrid=False, zeroline=False, showticklabels=False, range=[-3.8,4.2]),
                      yaxis=dict(showgrid=False, zeroline=False, showticklabels=False, range=[-3.6,3.5]),
                      height=520)
    return fig


# ── CHART 7: FK orphan bar ────────────────────────────────────────────────
def _chart_fk_orphans(fk_matrix: list) -> go.Figure:
    rules = [r for r in fk_matrix if r.get("orphan_count") is not None]
    if not rules:
        return _no_fig("No FK data — generate data in Port Authority first")
    labels = [r["rule"].replace(" → ", "\n→ ") for r in rules]
    values = [r["orphan_count"] for r in rules]
    colors = [_C["bad"] if v > 0 else _C["ok"] for v in values]
    fig = go.Figure(go.Bar(x=labels, y=values,
                           marker=dict(color=colors),
                           text=[str(v) if v else "✓" for v in values],
                           textposition="outside",
                           textfont=dict(size=9, color="white"),
                           hovertemplate="<b>%{x}</b><br>Orphans: %{y}<extra></extra>"))
    fig.update_layout(**{**_BASE_LAYOUT, "margin": {"t":40,"b":200,"l":60,"r":20}},
                      title=dict(text="FK Orphan Counts  (green = clean, red = orphans)",
                                 font=dict(size=13, color="#58A6FF")),
                      xaxis=dict(tickangle=-55, tickfont=dict(size=8,color="#C9D1D9"), **_GRID),
                      yaxis=dict(title="Orphan Rows", tickfont=dict(color="#8B949E"), **_GRID),
                      height=350)
    return fig


# ── CHART 8: Numeric distributions ───────────────────────────────────────
def _chart_distributions(tables: dict) -> go.Figure:
    colors = ["#00D4FF","#9D4EDD","#2DD4BF","#FB923C","#00E676"]
    traces = []
    for i, (tname, col, label) in enumerate(_DIST_COLS):
        df = tables.get(tname)
        if df is None or col not in df.columns:
            continue
        series = pd.to_numeric(df[col], errors="coerce").dropna()
        if len(series) == 0:
            continue
        c = colors[i % len(colors)]
        traces.append(go.Violin(y=series, name=label,
                                fillcolor=_hex_rgba(c, 0.27), line_color=c,
                                box_visible=True, meanline_visible=True, points="outliers",
                                hovertemplate=f"<b>{label}</b><br>%{{y:.2f}}<extra></extra>"))
    if not traces:
        return _no_fig()
    fig = go.Figure(data=traces)
    fig.update_layout(**_BASE_LAYOUT,
                      title=dict(text="Key Numeric Column Distributions (violin + quartiles)",
                                 font=dict(size=13, color="#58A6FF")),
                      yaxis=dict(title="Value", **_GRID, tickfont=dict(color="#8B949E")),
                      xaxis=dict(tickfont=dict(color="#C9D1D9")),
                      violinmode="group", showlegend=True,
                      legend=dict(orientation="h", y=1.12, x=0.5, xanchor="center"),
                      height=380)
    return fig


# ─────────────────────────────────────────────────────────────────
# UI COMPONENT HELPERS
# ─────────────────────────────────────────────────────────────────

def _section_hdr(title: str, icon: str, subtitle: str | None = None):
    return dmc.Group([
        DashIconify(icon=icon, width=20, color=_C["blue"]),
        dmc.Stack([
            dmc.Text(title, fw=700, size="sm", c="white"),
            *([dmc.Text(subtitle, size="xs", c="dimmed")] if subtitle else []),
        ], gap=1),
    ], align="center", gap="xs", mb="sm")


def _paper(children, mb="md", **sty):
    base = {"background": _C["card"], "border": f"1px solid {_C['border']}"}
    base.update(sty)
    return dmc.Paper(children, p="md", radius="md", mb=mb, style=base)


def _readiness_banner(readiness: str):
    cfg = {
        "READY":   (_C["ok"],    "mdi:check-circle",          "PIPELINE READY",
                    "All mandatory tables loaded, FK integrity clean, quality checks passed."),
        "WARN":    (_C["warn"],  "mdi:alert-circle",           "QUALITY WARNINGS",
                    "Issues detected — orphans, self-loops, or future-dated records found."),
        "BLOCKED": (_C["block"], "mdi:close-circle",           "BLOCKED — CRITICAL ISSUES",
                    "Critical quality failure — orphan counts high or score below threshold."),
        "NO_DATA": (_C["dim"],   "mdi:database-off-outline",   "NO DATA",
                    "Generate or upload data in Port Authority first."),
    }
    k = readiness if readiness in cfg else "NO_DATA"
    col, icon, label, sub = cfg[k]
    return dmc.Paper(
        dmc.Group([
            DashIconify(icon=icon, width=52, color=col),
            dmc.Stack([
                dmc.Text("Pipeline Readiness", size="xs", c="dimmed"),
                dmc.Text(label, size="xl", fw=900, c=col),
                dmc.Text(sub, size="sm", c="dimmed"),
            ], gap=3),
        ], align="center", gap="xl"),
        p="xl", radius="lg",
        style={"background": _C["card"],
               "border": f"2px solid {col}",
               "boxShadow": f"0 0 28px {col}33"},
    )


def _table_card(tname: str, pt: dict):
    meta     = _ALL_TABLES[tname]
    present  = pt.get("present", False)
    score    = pt.get("score")
    rows     = pt.get("rows", 0)
    ring_val = round((score or 0) * 100)
    ring_col = _score_color(score)
    return dmc.Paper(
        dmc.Stack([
            dmc.Group([
                DashIconify(icon=meta["icon"], width=22,
                            color=meta["color"] if present else _C["dim"]),
                dmc.Text(meta["label"], fw=700, size="xs", c="white"),
                dmc.Badge("Graph" if meta["group"] == "graph" else "Legacy",
                          color="cyan" if meta["group"] == "graph" else "orange",
                          variant="light", size="xs"),
            ], gap=4, mb=4),
            dmc.RingProgress(
                sections=[{"value": ring_val, "color": ring_col}],
                label=dmc.Text(f"{ring_val}%" if present else "N/A",
                               size="10px", ta="center", fw=700, c="white"),
                size=72, thickness=7,
            ) if present else dmc.Text("—", size="lg", c="dimmed", ta="center"),
            dmc.SimpleGrid(cols=3, spacing=2, children=[
                dmc.Stack([dmc.Text("Rows",  size="9px", c="dimmed", ta="center"),
                           dmc.Text(f"{rows:,}", size="xs", fw=700, c="white", ta="center")], gap=0),
                dmc.Stack([dmc.Text("Nulls", size="9px", c="dimmed", ta="center"),
                           dmc.Text(_pct(pt.get("null_pct")), size="xs",
                                    fw=700, c="white", ta="center")], gap=0),
                dmc.Stack([dmc.Text("Dups",  size="9px", c="dimmed", ta="center"),
                           dmc.Text(str(pt.get("dup_count", 0)), size="xs",
                                    fw=700, c="white", ta="center")], gap=0),
            ]) if present else dmc.Text("Not loaded", size="xs", c="dimmed", ta="center"),
        ], align="center", gap=4),
        p="sm", radius="md",
        style={
            "background": _C["card"],
            "border": f"1px solid {meta['color'] if present else _C['border']}",
            "minWidth": 130, "flex": "1",
            "opacity": "1" if present else "0.45",
        },
    )


def _fk_table(fk_matrix: list):
    rows_html = []
    for r in fk_matrix:
        orp = r.get("orphan_count")
        # v16.40 T2: skip rows with no FK data — only show tables that are loaded
        if orp is None:
            continue
        if orp == 0:
            status = dmc.Badge("✓ Clean",         color="green", variant="filled", size="xs")
        else:
            status = dmc.Badge(f"⚠ {orp} orphans",color="red",   variant="filled", size="xs")
        rows_html.append(dmc.TableTr([
            dmc.TableTd(dmc.Text(r["rule"], size="xs", c="dimmed")),
            dmc.TableTd(dmc.Badge(_ALL_TABLES.get(r["child"],  {}).get("label", r["child"]),
                                  color="orange", variant="light", size="xs")),
            dmc.TableTd(dmc.Badge(_ALL_TABLES.get(r["parent"], {}).get("label", r["parent"]),
                                  color="cyan",   variant="light", size="xs")),
            dmc.TableTd(dmc.Text(str(r.get("child_rows", "—")), size="xs", c="dimmed")),
            dmc.TableTd(status),
        ]))
    if not rows_html:
        return dmc.Text(
            "No referential integrity data — load node/edge tables in Port Authority first.",
            size="sm", c="dimmed", fs="italic", p="sm",
        )
    return dmc.Table(
        [
            dmc.TableThead(dmc.TableTr([
                dmc.TableTh(dmc.Text(h, size="xs", fw=700, c=_C["blue"]))
                for h in ["FK Rule", "Child Table", "Parent Table", "Child Rows", "Status"]
            ])),
            dmc.TableTbody(rows_html),
        ],
        striped=True, highlightOnHover=True,
        withTableBorder=False, withColumnBorders=False,
        style={"fontSize": "11px",
               "--mantine-color-dark-4": _C["border"],
               "--mantine-color-dark-6": _C["muted"]},
    )


# ─────────────────────────────────────────────────────────────────
# PAGE LAYOUT
# ─────────────────────────────────────────────────────────────────

layout = dmc.Box(
    [
        dcc.Store(id="dq35-cache"),
        # Poll every 3 s so charts appear as soon as _PA_DATA_STORE has data.
        # This avoids any cross-page dcc.Store dependency (pa-n-customers-store
        # is scoped to the Port Authority page layout, not globally available).
        dcc.Interval(id="dq35-poll", interval=3_000, n_intervals=0),

        # ── Header ─────────────────────────────────────────────────────
        dmc.Group([
            dmc.Stack([
                dmc.Group([
                    DashIconify(icon="mdi:database-check-outline", width=28, color=_C["blue"]),
                    dmc.Title("Data Quality Observatory", order=2, c="white"),
                ], gap="xs"),
                dmc.Text("All 13 Port Authority tables · DAMA-DMBOK2 · ISO 8000 · BCBS 239",
                         c="dimmed", size="xs"),
            ], gap=2),
            dmc.Group([
                dmc.Badge("LIVE SYNC",       color="green", variant="dot",    size="sm"),
                html.Div(id="dq35-source-badge"),
            ], gap="sm"),
        ], justify="space-between", mb="lg"),

        # ── Info callout ────────────────────────────────────────────────
        _paper([
            dmc.Group([
                DashIconify(icon="mdi:information-outline", width=24, color=_C["blue"]),
                dmc.Stack([
                    dmc.Text("Live-Synced from Port Authority", fw=700, c="white", size="sm"),
                    dmc.Text(
                        "This page reads staged DataFrames directly — no pipeline run needed. "
                        "Generate or upload data in Port Authority, then return here for an "
                        "instant full quality audit across all 13 tables.",
                        size="xs", c="dimmed",
                    ),
                ], gap=1),
            ], align="flex-start", gap="sm"),
        ], style={"background": "#071830", "border": f"1px solid {_C['blue']}44"}),

        # ── S1: Per-table quality cards ─────────────────────────────────
        _paper([
            _section_hdr("All 13 Tables — Quality Overview", "mdi:view-grid",
                         "Legacy (8) + Graph (5) · score = completeness×0.4 + consistency×0.3 + validity×0.3"),
            html.Div(id="dq35-sec1-cards"),
        ]),

        # ── S2: KPI row ─────────────────────────────────────────────────
        html.Div(id="dq35-sec2-kpis", style={"marginBottom": "16px"}),

        # ── S3: Schema network ────────────────────────────────────────
        # v16.38: hidden until data loaded (blank graph with no nodes is meaningless)
        html.Div(id="dq35-sec3-outer", children=[
            _paper([
                _section_hdr("Schema Network Graph", "mdi:graph-outline",
                             "Tables = nodes · FK joins = edges · red edge = orphan mismatch"),
                dcc.Graph(id="dq35-chart-schema", config={"displayModeBar": False}),
            ]),
        ]),

        # ── S4: Row dist + Column types ─────────────────────────────────
        dmc.Grid([
            dmc.GridCol(_paper([_section_hdr("Row Distribution","mdi:chart-bar-stacked"),
                                dcc.Graph(id="dq35-chart-rows", config={"displayModeBar":False})]),
                        span={"base":12,"md":6}),
            dmc.GridCol(_paper([_section_hdr("Column Type Composition","mdi:variable"),
                                dcc.Graph(id="dq35-chart-coltypes", config={"displayModeBar":False})]),
                        span={"base":12,"md":6}),
        ], gutter="md", mb="md"),

        # ── S5: Null heatmap ────────────────────────────────────────────
        _paper([
            _section_hdr("Null Rate Heatmap", "mdi:grid",
                         "Red = high null %, dark = clean — per column per table"),
            dcc.Graph(id="dq35-chart-nullheat", config={"displayModeBar": False}),
        ]),

        # ── S6: Dup rate + Radar ────────────────────────────────────────
        dmc.Grid([
            dmc.GridCol(_paper([_section_hdr("Duplicate Row Rate","mdi:content-copy"),
                                dcc.Graph(id="dq35-chart-dups", config={"displayModeBar":False})]),
                        span={"base":12,"md":6}),
            dmc.GridCol(_paper([_section_hdr("Quality Dimensions Radar","mdi:radar",
                                             "All loaded tables on one radar"),
                                dcc.Graph(id="dq35-chart-radar", config={"displayModeBar":False})]),
                        span={"base":12,"md":6}),
        ], gutter="md", mb="md"),

        # ── S7: FK orphan bar ───────────────────────────────────────────
        _paper([
            _section_hdr("Referential Integrity — Orphan Counts", "mdi:link-off",
                         "Each bar = one FK join · green = clean · red = orphans detected"),
            dcc.Graph(id="dq35-chart-fk", config={"displayModeBar": False}),
        ]),

        # ── S8: FK matrix table ─────────────────────────────────────────
        # v16.38: hidden when FK matrix empty (blank table with just a header is confusing)
        html.Div(id="dq35-sec8-outer", children=[
            _paper([
                _section_hdr("Referential Integrity Matrix", "mdi:table-check",
                             f"{len(_FK_RULES)} FK rules across all 13 tables"),
                html.Div(id="dq35-sec8-fktable"),
            ]),
        ]),

        # ── S9: Distributions ───────────────────────────────────────────
        _paper([
            _section_hdr("Key Numeric Distributions (Violin)", "mdi:chart-violin",
                         "txn.amount · node.risk_score · temporal.value · kyc.kyc_score · alert.score"),
            dcc.Graph(id="dq35-chart-dist", config={"displayModeBar": False}),
        ]),

        # ── S10: Anomaly cards ──────────────────────────────────────────
        html.Div(id="dq35-sec10-anomalies", style={"marginBottom": "16px"}),

        # ── S11: Readiness banner ───────────────────────────────────────
        html.Div(id="dq35-sec11-readiness"),
    ],
    p="lg",
    style={"background": _C["bg"], "minHeight": "100vh"},
)


# ─────────────────────────────────────────────────────────────────
# CALLBACKS
# ─────────────────────────────────────────────────────────────────

@callback(
    Output("dq35-cache", "data"),
    Input("dq35-poll",        "n_intervals"),  # 3-second poller (self-contained)
    Input("pipeline-state",   "data"),          # Pipeline run completed
    Input("global-refresh-ts","data"),          # Manual refresh button
    prevent_initial_call=False,
)
def _refresh_cache(_tick, _ps, _ts):
    """
    Recompute full DQ metrics whenever:
      • The 3-second poller fires (catches PA data as soon as it is staged)
      • The full pipeline completes  (pipeline-state)
      • The user presses manual refresh (global-refresh-ts)

    Note: pa-n-customers-store intentionally NOT used here — it is a
    page-scoped store defined inside Port Authority's layout and does NOT
    exist in the DOM when the user is on the Data Quality page, which
    would cause Dash to throw a nonexistent-component error and silently
    break the entire callback chain.
    """
    # Try pipeline's get_dq_detail() first (richer, available post-run)
    pipeline_tables: dict = {}
    try:
        pipeline = get_pipeline()
        if hasattr(pipeline, "_staged_tables") and pipeline._staged_tables:
            pipeline_tables = dict(pipeline._staged_tables)
    except Exception:
        pass

    # _pa_get_staged() reads _PA_DATA_STORE directly, with _staged_tables fallback
    staged = _pa_get_staged()

    # Merge: prefer staged (more up-to-date), fill gaps from pipeline_tables
    tables = {**pipeline_tables, **staged} if staged else pipeline_tables

    if not tables:
        return {"has_data": False, "source": "none"}

    dq = _compute_dq(tables)
    dq["has_data"] = dq["n_loaded"] > 0
    dq["source"]   = "staged"
    dq["ts"]       = datetime.now().strftime("%H:%M:%S")
    return dq


@callback(
    Output("dq35-source-badge",    "children"),
    Output("dq35-sec1-cards",      "children"),
    Output("dq35-sec2-kpis",       "children"),
    Output("dq35-sec3-outer",      "style"),      # v16.38: hide/show S3
    Output("dq35-chart-schema",    "figure"),
    Output("dq35-chart-rows",      "figure"),
    Output("dq35-chart-coltypes",  "figure"),
    Output("dq35-chart-nullheat",  "figure"),
    Output("dq35-chart-dups",      "figure"),
    Output("dq35-chart-radar",     "figure"),
    Output("dq35-chart-fk",        "figure"),
    Output("dq35-sec8-outer",      "style"),      # v16.38: hide/show S8
    Output("dq35-sec8-fktable",    "children"),
    Output("dq35-chart-dist",      "figure"),
    Output("dq35-sec10-anomalies", "children"),
    Output("dq35-sec11-readiness", "children"),
    Input("dq35-cache", "data"),
    prevent_initial_call=False,
)
def _render(dq):
    _empty     = dmc.Center(dmc.Text("Generate data in Port Authority first.",
                                     c="dimmed", size="sm"), py="xl")
    _empty_fig = _no_fig()
    _no_badge  = dmc.Badge("No Data", color="gray", variant="dot", size="sm")
    _hide      = {"display": "none"}
    _show      = {}

    if not dq or not dq.get("has_data"):
        return (_no_badge, _empty, _empty,
                _hide, _empty_fig, _empty_fig, _empty_fig, _empty_fig,
                _empty_fig, _empty_fig, _empty_fig,
                _hide, _empty,
                _empty_fig, _empty,
                _readiness_banner("NO_DATA"))

    per_table  = dq.get("per_table", {})
    fk_matrix  = dq.get("fk_matrix", [])
    self_loops = dq.get("self_loops", {})
    fut_dates  = dq.get("future_dates", {})
    readiness  = dq.get("readiness", "NO_DATA")
    n_loaded   = dq.get("n_loaded", 0)
    total_rows = dq.get("total_rows", 0)
    ts         = dq.get("ts", "—")

    # Re-fetch raw tables for violin/distribution charts (reads module-level dict)
    _pipeline_t: dict = {}
    try:
        _pl = get_pipeline()
        if hasattr(_pl, "_staged_tables") and _pl._staged_tables:
            _pipeline_t = dict(_pl._staged_tables)
    except Exception:
        pass
    _staged = _pa_get_staged()
    tables = {**_pipeline_t, **_staged} if _staged else _pipeline_t

    # Source badge
    source_badge = dmc.Group([
        dmc.Badge(f"PA Synced · {n_loaded}/13 tables · {total_rows:,} rows",
                  color="green", variant="filled", size="sm"),
        dmc.Badge(f"Updated {ts}", color="gray", variant="light", size="xs"),
    ], gap="xs")

    # S1: Per-table cards
    sec1 = dmc.Flex([_table_card(t, per_table.get(t, {})) for t in _ALL_TABLES],
                    wrap="wrap", gap="sm")

    # S2: KPI row
    loaded_scores = [per_table[t]["score"]
                     for t in _ALL_TABLES if per_table.get(t, {}).get("present")]
    avg_score     = (sum(loaded_scores) / len(loaded_scores)) if loaded_scores else 0.0
    total_orphans = sum(r.get("orphan_count") or 0 for r in fk_matrix)
    total_sl      = sum(self_loops.values())
    total_fd      = sum(fut_dates.values())

    kpi_def = [
        ("mdi:table-multiple",    _C["blue"],                           f"{n_loaded}/13",         "Tables Loaded"),
        ("mdi:format-list-group", _C["ok"],                             f"{total_rows:,}",         "Total Rows"),
        ("mdi:gauge",             _score_color(avg_score),              f"{avg_score*100:.1f}%",   "Avg Quality Score"),
        ("mdi:link-off",          _C["bad"] if total_orphans else _C["ok"], f"{total_orphans:,}", "FK Orphans"),
        ("mdi:arrow-u-left-top",  _C["warn"] if total_sl else _C["ok"], f"{total_sl}",            "Self-Loops"),
        ("mdi:calendar-alert",    _C["warn"] if total_fd else _C["ok"], f"{total_fd}",            "Future Dates"),
    ]
    sec2 = dmc.Group([
        dmc.Paper(dmc.Stack([
            DashIconify(icon=ic, width=24, color=col),
            dmc.Text(val, fw=900, size="xl", c="white", style={"lineHeight": 1}),
            dmc.Text(lbl, size="xs", c=col, fw=600),
        ], align="center", gap=3),
        p="md", radius="lg",
        style={"background": f"linear-gradient(180deg,rgba(0,0,0,0.5)0%,{col}08 100%)",
               "border": f"1px solid {col}30", "flex": "1", "minWidth": 100})
        for ic, col, val, lbl in kpi_def
    ], gap="sm", style={"flexWrap": "wrap"})

    # Charts
    charts = (
        _chart_schema_network(per_table, fk_matrix),
        _chart_row_dist(per_table),
        _chart_col_types(per_table),
        _chart_null_heatmap(per_table),
        _chart_dup_rate(per_table),
        _chart_quality_radar(per_table),
        _chart_fk_orphans(fk_matrix),
    )
    c_schema, c_rows, c_coltypes, c_nullheat, c_dups, c_radar, c_fk = charts
    c_dist = _chart_distributions(tables)

    # FK matrix table
    sec8 = _fk_table(fk_matrix)

    # S10: Self-loop + future-date anomaly cards
    sl_cards = [
        dmc.Paper(dmc.Group([
            DashIconify(icon="mdi:arrow-u-left-top", width=28,
                        color=_C["bad"] if cnt else _C["ok"]),
            dmc.Stack([dmc.Text("Self-Loop Edges", fw=600, size="sm", c="white"),
                       dmc.Text(f"{tname}.{_SELF_LOOP_TABLES[tname][0]} == "
                                f"{_SELF_LOOP_TABLES[tname][1]}", size="xs", c="dimmed")], gap=1),
            dmc.Text(str(cnt), size="xl", fw=900,
                     c=_C["bad"] if cnt else _C["ok"], style={"marginLeft":"auto"}),
        ], align="center"),
        p="md", radius="md",
        style={"background":_C["card"],
               "border":f"1px solid {_C['bad'] if cnt else _C['ok']}",
               "flex":"1 1 260px"})
        for tname, cnt in self_loops.items()
    ]
    fd_cards = [
        dmc.Paper(dmc.Group([
            DashIconify(icon="mdi:calendar-alert", width=28, color=_C["warn"]),
            dmc.Stack([dmc.Text(f"Future Dates — {tname}", fw=600, size="sm", c="white"),
                       dmc.Text(f"{cnt} records with date > today", size="xs", c="dimmed")], gap=1),
            dmc.Text(str(cnt), size="xl", fw=900, c=_C["warn"], style={"marginLeft":"auto"}),
        ], align="center"),
        p="md", radius="md",
        style={"background":_C["card"], "border":f"1px solid {_C['warn']}", "flex":"1 1 260px"})
        for tname, cnt in fut_dates.items()
    ]
    all_cards = sl_cards + fd_cards
    sec10 = (
        dmc.Flex(all_cards, wrap="wrap", gap="md") if all_cards else
        dmc.Paper(dmc.Group([
            DashIconify(icon="mdi:check-circle", width=24, color=_C["ok"]),
            dmc.Text("No self-loops or future-dated records detected.", size="sm", c=_C["ok"]),
        ], gap="sm"), p="md", radius="md",
        style={"background":_C["card"], "border":f"1px solid {_C['ok']}"})
    )

    return (source_badge, sec1, sec2,
            # v16.38: S3 shown only when at least 1 table is loaded (blank network = no value)
            _show if any(p.get("present") for p in per_table.values()) else _hide,
            c_schema, c_rows, c_coltypes, c_nullheat, c_dups, c_radar, c_fk,
            # v16.38: S8 shown only when FK matrix has real entries (empty table = no value)
            _show if fk_matrix else _hide,
            sec8, c_dist, sec10,
            _readiness_banner(readiness))
