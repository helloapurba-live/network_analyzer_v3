"""
Page: The Radar (v12.22 — CEO / Business Presentation Format)
===============================================================
Business Purpose:
  This page displays every customer as a coloured dot in a live interactive
  network map. As a compliance officer or executive, you can:
    • See all P1 (red) customers at a glance — they are in the centre
    • Click any dot to see the customer name, risk score, and required action
    • Filter to show only the highest-risk groups (use the Legend chips below)
    • Export the view as a PNG for board presentations

  NODE COLOUR GUIDE (always visible below):
    Red   = P1 CRITICAL (score ≥80) — freeze account today
    Orange = P2 HIGH RISK (60–79)  — enhanced due diligence
    Yellow = P3 MEDIUM (40–59)     — schedule monitoring review
    Green  = P4 LOW (0–39)        — normal operations

  NODE SIZE = Risk level (bigger dot = higher risk score)
  EDGE THICKNESS = Money amount (thicker line = larger transaction)
"""

import dash
from dash import html, dcc, callback, Input, Output, State, no_update, ctx
import dash_mantine_components as dmc
import dash_cytoscape as cyto
from dash_iconify import DashIconify
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, APP
from engine import get_pipeline
from utils.logger import GlobalExceptionHandler

dash.register_page(
    __name__, path="/radar", name="The Radar", title=f"FCDAI v{APP.VERSION} | Customer Risk Network"
)


# =============================================================================
# LAYOUT PRESETS — optimised per scale tier
# =============================================================================
LAYOUT_PRESETS = {
    "cose": {
        "name": "cose",
        "animate": False,
        "padding": 30,
        "nodeRepulsion": 4000,
        "idealEdgeLength": 80,
        "nodeOverlap": 20,
        "gravity": 0.25,
    },
    "cose-bilkent": {
        "name": "cose-bilkent",
        "animate": False,
        "padding": 20,
        "nodeRepulsion": 8000,
        "idealEdgeLength": 50,
        "edgeElasticity": 0.45,
        "nestingFactor": 0.1,
        "gravity": 0.20,
        "gravityRange": 3.8,
        "tile": True,
    },
    "concentric": {
        "name": "concentric",
        "animate": False,
        "padding": 20,
        "minNodeSpacing": 10,
        "concentric": "function(node) { return node.data('risk_score') || 0; }",
        "levelWidth": "function(nodes) { return 2; }",
    },
    "circle": {
        "name": "circle",
        "animate": False,
        "padding": 20,
        "avoidOverlap": True,
    },
    "breadthfirst": {
        "name": "breadthfirst",
        "animate": False,
        "padding": 20,
        "spacingFactor": 1.0,
        "directed": True,
    },
    "grid": {
        "name": "grid",
        "animate": False,
        "padding": 10,
        "avoidOverlap": True,
    },
}


# =============================================================================
# CYTOSCAPE STYLESHEET (with weighted edges)
# =============================================================================
cyto_stylesheet = [
    # ── Default nodes ──
    {
        "selector": "node",
        "style": {
            "label": "data(label)",
            "font-size": "7px",
            "color": "#94A3B8",
            "text-valign": "bottom",
            "text-halign": "center",
            "background-color": "#00E676",
            "width": "mapData(degree, 0, 100, 8, 36)",
            "height": "mapData(degree, 0, 100, 8, 36)",
            "border-width": "1px",
            "border-color": "rgba(255,255,255,0.2)",
            "min-zoomed-font-size": 8,
            "text-max-width": "60px",
            "text-wrap": "ellipsis",
        },
    },
    # ── Risk tier colors ──
    {
        "selector": ".P1",
        "style": {
            "background-color": "#FF1744",
            "border-color": "#FF6B6B",
            "border-width": "2px",
        },
    },
    {
        "selector": ".P2",
        "style": {
            "background-color": "#FF9800",
            "border-color": "#FFB74D",
            "border-width": "1.5px",
        },
    },
    {
        "selector": ".P3",
        "style": {
            "background-color": "#FFD600",
            "border-color": "#FFF176",
        },
    },
    {
        "selector": ".P4",
        "style": {
            "background-color": "#00E676",
            "border-color": "#69F0AE",
        },
    },
    # ── Default edges ──
    {
        "selector": "edge",
        "style": {
            "curve-style": "bezier",
            "target-arrow-shape": "triangle",
            "target-arrow-color": "rgba(0, 212, 255, 0.3)",
            "line-color": "rgba(0, 212, 255, 0.15)",
            "width": "1px",
            "opacity": 0.6,
        },
    },
    # ── Weighted edge classes (transaction amount as thickness + color) ──
    {
        "selector": ".edge-thin",
        "style": {
            "width": "1px",
            "line-color": "rgba(0, 212, 255, 0.15)",
            "target-arrow-color": "rgba(0, 212, 255, 0.2)",
            "opacity": 0.4,
        },
    },
    {
        "selector": ".edge-medium",
        "style": {
            "width": "2px",
            "line-color": "rgba(0, 212, 255, 0.35)",
            "target-arrow-color": "rgba(0, 212, 255, 0.4)",
            "opacity": 0.6,
        },
    },
    {
        "selector": ".edge-thick",
        "style": {
            "width": "3.5px",
            "line-color": "rgba(255, 152, 0, 0.5)",
            "target-arrow-color": "rgba(255, 152, 0, 0.6)",
            "opacity": 0.75,
        },
    },
    {
        "selector": ".edge-heavy",
        "style": {
            "width": "5px",
            "line-color": "rgba(255, 23, 68, 0.6)",
            "target-arrow-color": "rgba(255, 23, 68, 0.7)",
            "opacity": 0.9,
        },
    },
    # ── Selected node ──
    {
        "selector": ":selected",
        "style": {
            "border-width": "3px",
            "border-color": "#00D4FF",
            "background-color": "#00D4FF",
        },
    },
]

# Performance mode stylesheet (no labels, simpler rendering)
perf_stylesheet = [
    {
        "selector": "node",
        "style": {
            "label": "",
            "background-color": "#00E676",
            "width": "mapData(degree, 0, 100, 4, 20)",
            "height": "mapData(degree, 0, 100, 4, 20)",
            "border-width": "0px",
        },
    },
    {"selector": ".P1", "style": {"background-color": "#FF1744"}},
    {"selector": ".P2", "style": {"background-color": "#FF9800"}},
    {"selector": ".P3", "style": {"background-color": "#FFD600"}},
    {"selector": ".P4", "style": {"background-color": "#00E676"}},
    {
        "selector": "edge",
        "style": {
            "curve-style": "haystack",
            "line-color": "rgba(0, 212, 255, 0.1)",
            "width": "0.5px",
            "opacity": 0.3,
        },
    },
    {"selector": ".edge-thin", "style": {"width": "0.5px", "opacity": 0.2}},
    {"selector": ".edge-medium", "style": {"width": "1px", "opacity": 0.3}},
    {
        "selector": ".edge-thick",
        "style": {"width": "1.5px", "opacity": 0.5, "line-color": "rgba(255,152,0,0.3)"},
    },
    {
        "selector": ".edge-heavy",
        "style": {"width": "2px", "opacity": 0.6, "line-color": "rgba(255,23,68,0.4)"},
    },
    {
        "selector": ":selected",
        "style": {
            "border-width": "2px",
            "border-color": "#00D4FF",
            "background-color": "#00D4FF",
        },
    },
]


def _customer_label(node_id):
    """Show customer name + last 4 digits of ID for readable labels."""
    if not node_id or not isinstance(node_id, str):
        return str(node_id or "Unknown")
    pipeline = get_pipeline()
    tables = pipeline.tables
    cust_df = tables.get("customer")
    if cust_df is not None and len(cust_df) > 0:
        match = (
            cust_df[cust_df["customer_id"] == node_id] if "customer_id" in cust_df.columns else None
        )
        if match is not None and len(match) > 0:
            row = match.iloc[0]
            name = row.get("customer_name", "") or row.get("name", "")
            if name:
                short_id = node_id[-4:] if len(node_id) >= 4 else node_id
                return f"{name} (...{short_id})"
    # Fallback: just last 4 digits
    if len(node_id) > 8:
        return f"...{node_id[-4:]}"
    return node_id


# Risk tier constants for legend
_RADAR_TIER_COLORS = {"P1": "#FF1744", "P2": "#FF9800", "P3": "#FFD600", "P4": "#00E676"}
_RADAR_TIER_LABELS = {
    "P1": ("CRITICAL", "80–100", "Freeze & Investigate immediately."),
    "P2": ("HIGH RISK", "60–79", "Enhanced Due Diligence required today."),
    "P3": ("MEDIUM", "40–59", "Active Monitoring — schedule review."),
    "P4": ("LOW", "0–39", "Normal Operations — standard monitoring."),
}


def _risk_tier_legend():
    """Always-visible P1-P4 risk priority panel for non-technical users."""
    items = []
    for code in ("P1", "P2", "P3", "P4"):
        label, score_range, desc = _RADAR_TIER_LABELS[code]
        color = _RADAR_TIER_COLORS[code]
        items.append(
            dmc.Group(
                [
                    html.Div(
                        style={
                            "width": "14px",
                            "height": "14px",
                            "borderRadius": "50%",
                            "backgroundColor": color,
                            "flexShrink": "0",
                            "border": "2px solid rgba(255,255,255,0.3)",
                        }
                    ),
                    dmc.Text(f"{code}  {label}", fw=700, c=color, size="xs"),
                    dmc.Text(
                        f"(Score {score_range}): {desc}",
                        size="xs",
                        c="dimmed",
                        style={"maxWidth": "280px"},
                    ),
                ],
                gap=6,
                wrap="nowrap",
            ),
        )
    return dmc.Paper(
        dmc.Stack(
            [
                dmc.Group(
                    [
                        DashIconify(icon="mdi:map-legend", width=18, color="#94A3B8"),
                        dmc.Text(
                            "Customer Risk Priority Guide — What the Colours Mean",
                            fw=600,
                            c="white",
                            size="sm",
                        ),
                    ],
                    gap="sm",
                ),
                dmc.SimpleGrid(cols={"base": 1, "md": 2, "xl": 4}, spacing="xs", children=items),
                dmc.Text(
                    "💡 How to use The Radar: "
                    "Each dot = one customer. Dot colour = risk tier. Bigger dot = higher risk. "
                    "Click a dot to see the customer name, risk score, and recommended action. "
                    "Use the chip filters below to hide/show specific risk groups.",
                    size="xs",
                    c="dimmed",
                    mt="xs",
                    style={"fontStyle": "italic", "lineHeight": "1.5"},
                ),
            ],
            gap="sm",
        ),
        p="md",
        radius="md",
        mb="md",
        style={"background": "rgba(17,24,39,0.8)", "border": "1px solid rgba(255,255,255,0.08)"},
    )


# =============================================================================
# LAYOUT
# =============================================================================
layout = dmc.Box(
    [
        # v16.21: page-mount trigger — ensures data refreshes when navigating here
        # after a pipeline run completed while the user was on another page.
        dcc.Interval(id="radar-init", interval=800, max_intervals=1),
        # Header
        dmc.Group(
            [
                dmc.Stack(
                    [
                        dmc.Title("Customer Risk Network Map", order=2, c="white"),
                        dmc.Text(
                            "Interactive map showing all customers as colour-coded dots. "
                            "Red = freeze now. Orange = investigate today. "
                            "Click any dot to see the customer name and required action.",
                            c="dimmed",
                            size="sm",
                        ),
                    ],
                    gap=2,
                ),
                dmc.Group(
                    [
                        dmc.Badge(f"v{APP.VERSION}", color="cyan", variant="outline", size="sm"),
                        dcc.Link(
                            dmc.Button("← Dashboard", size="xs", variant="subtle", color="gray"),
                            href="/",
                            style={"textDecoration": "none"},
                        ),
                    ],
                    gap="sm",
                ),
            ],
            justify="space-between",
            mb="md",
        ),
        # ━━━ CEO EXECUTIVE BRIEF ━━━
        dmc.Paper(
            [
                dmc.Group(
                    [
                        DashIconify(icon="mdi:briefcase-outline", width=22, color="#00D4FF"),
                        dmc.Stack(
                            [
                                dmc.Text(
                                    "What Is This Page? — Executive Overview",
                                    fw=700,
                                    c="white",
                                    size="sm",
                                ),
                                dmc.Text(
                                    "The Radar is your real-time, visual map of every customer in the system. "
                                    "Each dot is one customer — the colour tells you how dangerous they are. "
                                    "Red dots are your highest-risk customers who need immediate action (account freeze or investigation). "
                                    "The system automatically groups related customers together so you can see criminal networks at a glance. "
                                    "This page answers: 'Which customers do I need to act on today, and how are they connected?'",
                                    size="xs",
                                    c="dimmed",
                                    style={"lineHeight": "1.6"},
                                ),
                            ],
                            gap=4,
                        ),
                    ],
                    gap="md",
                    align="flex-start",
                ),
                dmc.Group(
                    [
                        dmc.Badge(
                            "Click any dot → see customer name + action",
                            color="cyan",
                            variant="light",
                            size="xs",
                        ),
                        dmc.Badge(
                            "Bigger dot = higher risk score",
                            color="orange",
                            variant="light",
                            size="xs",
                        ),
                        dmc.Badge(
                            "Thick line = large money transfer between customers",
                            color="grape",
                            variant="light",
                            size="xs",
                        ),
                    ],
                    gap="xs",
                    mt="sm",
                ),
            ],
            p="md",
            radius="md",
            mb="sm",
            style={
                "background": "linear-gradient(135deg, rgba(0,212,255,0.04) 0%, rgba(10,14,23,0.95) 100%)",
                "border": "1px solid rgba(0,212,255,0.12)",
            },
        ),
        # ━━━ RISK PRIORITY LEGEND — always visible ━━━
        _risk_tier_legend(),
        # ── Controls Strip ──
        dmc.Paper(
            [
                dmc.Group(
                    [
                        # Scale tier selector
                        dmc.SegmentedControl(
                            id="radar-scale-tier",
                            data=[
                                {"value": "1000", "label": "1K"},
                                {"value": "5000", "label": "5K"},
                                {"value": "10000", "label": "10K"},
                            ],
                            value="1000",
                            color="cyan",
                            size="xs",
                        ),
                        # Max Nodes (precise custom value)
                        dmc.NumberInput(
                            id="radar-max-nodes",
                            value=1000,
                            min=50,
                            max=50000,
                            step=100,
                            w=130,
                            size="xs",
                            label="Max Nodes",
                            styles={
                                "input": {
                                    "backgroundColor": THEME.DARK_BG,
                                    "color": "white",
                                    "border": f"1px solid {THEME.DARK_BORDER}",
                                }
                            },
                        ),
                        # Layout algorithm selector
                        dmc.Select(
                            id="radar-layout",
                            data=[
                                {"value": "cose", "label": "CoSE (Fast)"},
                                {"value": "cose-bilkent", "label": "CoSE-Bilkent (Quality)"},
                                {"value": "concentric", "label": "Concentric (Risk)"},
                                {"value": "circle", "label": "Circle"},
                                {"value": "breadthfirst", "label": "Breadth-First"},
                                {"value": "grid", "label": "Grid"},
                            ],
                            value="cose",
                            w=180,
                            size="xs",
                            label="Layout",
                            styles={
                                "input": {
                                    "backgroundColor": THEME.DARK_BG,
                                    "color": "white",
                                    "border": f"1px solid {THEME.DARK_BORDER}",
                                }
                            },
                        ),
                        # Node selection strategy
                        dmc.Select(
                            id="radar-selection",
                            data=[
                                {"value": "composite", "label": "Composite (Smart)"},
                                {"value": "degree", "label": "By Degree"},
                                {"value": "risk", "label": "By Risk Score"},
                            ],
                            value="composite",
                            w=170,
                            size="xs",
                            label="Selection",
                            styles={
                                "input": {
                                    "backgroundColor": THEME.DARK_BG,
                                    "color": "white",
                                    "border": f"1px solid {THEME.DARK_BORDER}",
                                }
                            },
                        ),
                        # Performance mode toggle
                        dmc.Switch(
                            id="radar-perf-mode",
                            label="Performance Mode",
                            size="xs",
                            color="orange",
                            checked=False,
                        ),
                        # Show edge weights toggle
                        dmc.Switch(
                            id="radar-show-weights",
                            label="Edge Weights",
                            size="xs",
                            color="cyan",
                            checked=True,
                        ),
                        # Reload
                        dmc.Button(
                            "Reload",
                            id="btn-load-graph",
                            leftSection=DashIconify(icon="mdi:radar"),
                            variant="gradient",
                            gradient={"from": "cyan", "to": "indigo"},
                            size="sm",
                        ),
                    ],
                    gap="sm",
                    wrap="wrap",
                ),
            ],
            p="sm",
            radius="lg",
            className="glass-card",
            mb="md",
        ),
        # ── Scale Info Bar ──
        dmc.Paper(
            [
                dmc.Group(
                    id="radar-scale-info",
                    children=[
                        dmc.Text("Load graph to see scale metrics", c="dimmed", size="xs"),
                    ],
                    gap="md",
                ),
            ],
            p="xs",
            px="md",
            radius="md",
            mb="md",
            style={
                "backgroundColor": "rgba(0,0,0,0.3)",
                "border": f"1px solid {THEME.GLASS_BORDER}",
            },
        ),
        # ━━━ FILTERS BAR — Risk Tier + Transaction Value at top (v12.43 TASK3) ━━━
        dmc.Paper(
            [
                dmc.SimpleGrid(
                    cols={"base": 1, "md": 2, "xl": 5},
                    spacing="md",
                    children=[
                        # Risk Tier Filter
                        dmc.Stack(
                            [
                                dmc.Group(
                                    [
                                        DashIconify(
                                            icon="mdi:circle-multiple",
                                            width=14,
                                            color=THEME.PRIMARY,
                                        ),
                                        dmc.Text("Risk Tier Filter", size="xs", fw=700, c="white"),
                                        dmc.Text(
                                            "— show/hide customer groups",
                                            size="xs",
                                            c="dimmed",
                                            fs="italic",
                                        ),
                                    ],
                                    gap=6,
                                ),
                                dmc.ChipGroup(
                                    id="radar-legend-tiers",
                                    multiple=True,
                                    value=["P1", "P2", "P3", "P4"],
                                    children=[
                                        dmc.Chip(
                                            "🔴 P1 Critical — Freeze NOW",
                                            value="P1",
                                            color="red",
                                            size="xs",
                                            variant="filled",
                                        ),
                                        dmc.Chip(
                                            "🟠 P2 High Risk — EDD today",
                                            value="P2",
                                            color="orange",
                                            size="xs",
                                            variant="filled",
                                        ),
                                        dmc.Chip(
                                            "🟡 P3 Medium — Monitor",
                                            value="P3",
                                            color="yellow",
                                            size="xs",
                                            variant="filled",
                                        ),
                                        dmc.Chip(
                                            "🟢 P4 Low — Normal ops",
                                            value="P4",
                                            color="green",
                                            size="xs",
                                            variant="filled",
                                        ),
                                    ],
                                ),
                            ],
                            gap=4,
                        ),
                        # Transaction Value Filter
                        dmc.Stack(
                            [
                                dmc.Group(
                                    [
                                        DashIconify(
                                            icon="mdi:cash-multiple", width=14, color="#26C6DA"
                                        ),
                                        dmc.Text(
                                            "Transaction Value Filter", size="xs", fw=700, c="white"
                                        ),
                                        dmc.Text(
                                            "— show/hide by money amount",
                                            size="xs",
                                            c="dimmed",
                                            fs="italic",
                                        ),
                                    ],
                                    gap=6,
                                ),
                                dmc.ChipGroup(
                                    id="radar-legend-edges",
                                    multiple=True,
                                    value=["edge-thin", "edge-medium", "edge-thick", "edge-heavy"],
                                    children=[
                                        dmc.Chip(
                                            "📘 Low < $10K",
                                            value="edge-thin",
                                            color="cyan",
                                            size="xs",
                                            variant="outline",
                                        ),
                                        dmc.Chip(
                                            "📖 Medium $10K–$100K",
                                            value="edge-medium",
                                            color="cyan",
                                            size="xs",
                                            variant="light",
                                        ),
                                        dmc.Chip(
                                            "📙 High $100K–$1M",
                                            value="edge-thick",
                                            color="orange",
                                            size="xs",
                                            variant="light",
                                        ),
                                        dmc.Chip(
                                            "📕 Heavy > $1M",
                                            value="edge-heavy",
                                            color="red",
                                            size="xs",
                                            variant="filled",
                                        ),
                                    ],
                                ),
                            ],
                            gap=4,
                        ),
                        # v16.28: node_type1 Filter — Internal / External (ChipGroup, colour-coded)
                        # v16.29 T3: Distinct visual style — pill-shaped "dot" variant, different from Risk Tier chips
                        dmc.Stack(
                            [
                                dmc.Group(
                                    [
                                        DashIconify(icon="mdi:swap-horizontal", width=14, color="#2196F3"),
                                        dmc.Text("Bank Ownership", size="xs", fw=700, c="#2196F3"),
                                        dmc.Text(
                                            "— Internal vs External nodes",
                                            size="xs",
                                            c="dimmed",
                                            fs="italic",
                                        ),
                                    ],
                                    gap=6,
                                ),
                                dmc.ChipGroup(
                                    id="radar-node-type1-filter",
                                    multiple=True,
                                    value=["Internal", "External"],
                                    children=[
                                        dmc.Chip(
                                            "🏦 Internal",
                                            value="Internal",
                                            color="blue",
                                            size="sm",
                                            variant="dot",
                                            radius="xl",
                                            styles={"label": {"fontSize": "11px", "fontStyle": "italic"}},
                                        ),
                                        dmc.Chip(
                                            "🌐 External",
                                            value="External",
                                            color="orange",
                                            size="sm",
                                            variant="dot",
                                            radius="xl",
                                            styles={"label": {"fontSize": "11px", "fontStyle": "italic"}},
                                        ),
                                    ],
                                ),
                            ],
                            gap=4,
                        ),
                        # v16.31: node_type3 Filter — Customer Segment (ChipGroup, colour-coded) [renamed from node_type2]
                        # v16.29 T3: Distinct visual style — tag/badge style with outline + smaller size
                        dmc.Stack(
                            [
                                dmc.Group(
                                    [
                                        DashIconify(icon="mdi:account-group-outline", width=14, color="#00BFA5"),
                                        dmc.Text("Customer Segment", size="xs", fw=700, c="#00BFA5"),
                                        dmc.Text(
                                            "— Retail / Corporate / Financial / Govt",
                                            size="xs",
                                            c="dimmed",
                                            fs="italic",
                                        ),
                                    ],
                                    gap=6,
                                ),
                                dmc.ChipGroup(
                                    id="radar-node-type3-filter",
                                    multiple=True,
                                    value=["Retail", "Corporate", "Financial", "Government"],
                                    children=[
                                        dmc.Chip(
                                            "▸ Retail",
                                            value="Retail",
                                            color="teal",
                                            size="xs",
                                            variant="outline",
                                            radius="xl",
                                            styles={"label": {"fontSize": "10px", "letterSpacing": "0.02em"}},
                                        ),
                                        dmc.Chip(
                                            "▸ Corporate",
                                            value="Corporate",
                                            color="violet",
                                            size="xs",
                                            variant="outline",
                                            radius="xl",
                                            styles={"label": {"fontSize": "10px", "letterSpacing": "0.02em"}},
                                        ),
                                        dmc.Chip(
                                            "▸ Financial",
                                            value="Financial",
                                            color="yellow",
                                            size="xs",
                                            variant="outline",
                                            radius="xl",
                                            styles={"label": {"fontSize": "10px", "letterSpacing": "0.02em"}},
                                        ),
                                        dmc.Chip(
                                            "▸ Govt",
                                            value="Government",
                                            color="gray",
                                            size="xs",
                                            variant="outline",
                                            radius="xl",
                                            styles={"label": {"fontSize": "10px", "letterSpacing": "0.02em"}},
                                        ),
                                    ],
                                ),
                            ],
                            gap=4,
                        ),
                    ],
                ),
            ],
            p="sm",
            radius="md",
            mb="md",
            style={
                "backgroundColor": "rgba(0,0,0,0.3)",
                "border": f"1px solid {THEME.GLASS_BORDER}",
            },
        ),
        # ── Main Content: 80% Graph + 20% Node Investigation (v12.43 TASK3 LANDSCAPE) ──
        html.Div(
            [
                # Cytoscape Graph — 80% LANDSCAPE (v12.43)
                dmc.Paper(
                    [
                        # ─ Title ─
                        dmc.Group(
                            [
                                DashIconify(icon="mdi:graph-outline", width=18, color="#00E676"),
                                dmc.Text(
                                    "Transaction Network Map — Who Transacts With Whom?",
                                    size="sm",
                                    fw=600,
                                    c="white",
                                ),
                            ],
                            gap=6,
                            mb=4,
                        ),
                        dmc.Text(
                            "Each dot = one customer (colour = risk tier).  Lines = money flows — thicker line = larger transaction. "
                            "Tight clusters indicate potential coordinated activity (e.g. layering schemes). "
                            "Click any dot to see customer name, risk score, and recommended action.  Red = P1 Critical (freeze now).",
                            size="xs",
                            c="dimmed",
                            mb="xs",
                            style={"lineHeight": "1.4", "fontStyle": "italic"},
                        ),
                        cyto.Cytoscape(
                            id="cytoscape-graph",
                            elements=[],
                            stylesheet=cyto_stylesheet,
                            layout={
                                "name": "cose",
                                "animate": False,
                                "padding": 30,
                                "nodeRepulsion": 4000,
                                "idealEdgeLength": 80,
                            },
                            style={"width": "100%", "height": "82vh"},
                            responsive=True,
                            minZoom=0.05,
                            maxZoom=3.0,
                            boxSelectionEnabled=True,
                        ),
                    ],
                    p="sm",
                    radius="lg",
                    className="glass-card",
                    style={"flex": "4 1 0%", "minWidth": "0"},
                ),
                # Node Investigation Panel — 20% RIGHT (v12.43)
                dmc.Paper(
                    [
                        dmc.Group(
                            [
                                DashIconify(
                                    icon="mdi:file-search-outline", width=18, color=THEME.PRIMARY
                                ),
                                dmc.Text("Node Investigation", size="sm", fw=600, c="white"),
                            ],
                            gap="sm",
                            mb="md",
                        ),
                        dmc.Text(
                            "Click any customer dot in the map to see their full risk profile, "
                            "money flow, and recommended compliance action here.",
                            size="xs",
                            c="dimmed",
                            mb="md",
                            style={"lineHeight": "1.4", "fontStyle": "italic"},
                        ),
                        dmc.Stack(
                            id="node-details-panel",
                            gap="xs",
                            children=[
                                dmc.Center(
                                    [
                                        dmc.Stack(
                                            [
                                                DashIconify(
                                                    icon="mdi:cursor-default-click-outline",
                                                    width=32,
                                                    color=THEME.TEXT_MUTED,
                                                ),
                                                dmc.Text(
                                                    "Click a node to investigate",
                                                    c="dimmed",
                                                    size="sm",
                                                ),
                                            ],
                                            align="center",
                                            gap="xs",
                                        ),
                                    ],
                                    style={"minHeight": "200px"},
                                ),
                            ],
                        ),
                    ],
                    p="lg",
                    radius="lg",
                    className="glass-card",
                    style={
                        "flex": "1 1 0%",
                        "minWidth": "240px",
                        "maxHeight": "90vh",
                        "overflowY": "auto",
                    },
                ),
            ],
            style={
                "display": "flex",
                "gap": "12px",
                "alignItems": "flex-start",
                "flexWrap": "nowrap",
            },
        ),
        # Hidden store for filtered stylesheet
        dcc.Store(id="radar-filtered-stylesheet", data=None),
        # Export bar
        dmc.Paper(
            [
                dmc.Group(
                    [
                        DashIconify(icon="mdi:download-circle-outline", width=22, color="#00D4FF"),
                        dmc.Text("Export Network Data", fw=600, c="white", size="sm"),
                        dmc.Button(
                            "⬇ Export CSV",
                            id="radar-export-csv",
                            size="xs",
                            variant="light",
                            color="cyan",
                            leftSection=DashIconify(icon="mdi:download", width=14),
                        ),
                    ],
                    gap="md",
                    align="center",
                ),
            ],
            p="sm",
            radius="lg",
            className="glass-card",
            mt="md",
            style={
                "background": "rgba(0,212,255,0.04)",
                "border": "1px solid rgba(0,212,255,0.15)",
            },
        ),
        dcc.Download(id="radar-download"),
        # Loading
        dcc.Loading(html.Div(id="radar-loading"), type="circle", color=THEME.PRIMARY),
    ]
)


# =============================================================================
# CALLBACKS
# =============================================================================
@callback(
    Output("cytoscape-graph", "elements"),
    Output("cytoscape-graph", "layout"),
    Output("cytoscape-graph", "stylesheet"),
    Output("radar-scale-info", "children"),
    Output("radar-loading", "children"),
    Input("btn-load-graph", "n_clicks"),
    Input("pipeline-state", "data"),
    Input("global-refresh-ts", "data"),
    Input("radar-init", "n_intervals"),
    State("radar-max-nodes", "value"),
    State("radar-scale-tier", "value"),
    State("radar-layout", "value"),
    State("radar-selection", "value"),
    State("radar-perf-mode", "checked"),
    State("radar-show-weights", "checked"),
    State("radar-legend-tiers", "value"),
    State("radar-legend-edges",       "value"),
    # v16.29 T3: Entity Type filter (radar-node-type-filter) removed — node_type1 + node_type3 are sufficient
    State("radar-node-type1-filter",  "value"),   # v16.24: Internal/External filter (ChipGroup list)
    State("radar-node-type3-filter",  "value"),   # v16.31: Customer Segment filter (renamed from node_type2)
)
@GlobalExceptionHandler.wrap(fallback=([], {"name": "cose"}, cyto_stylesheet, [], ""))
def load_graph(
    n_clicks,
    pipeline_state,
    _gr,
    _radar_init,
    max_nodes_input,
    scale_tier,
    layout_name,
    selection,
    perf_mode,
    show_weights,
    active_tiers,
    active_edges,
    node_type1_filter,
    node_type3_filter,
):
    """Scalable graph loader — handles custom max-nodes + legend filter."""
    pipeline = get_pipeline()
    empty_info = [dmc.Text("No graph data", c="dimmed", size="xs")]
    default_layout = LAYOUT_PRESETS.get(layout_name or "cose", LAYOUT_PRESETS["cose"])

    # On reset, clear graph
    if isinstance(pipeline_state, dict) and pipeline_state.get("reset"):
        return [], default_layout, cyto_stylesheet, empty_info, ""

    if pipeline.G is None:
        return [], default_layout, cyto_stylesheet, empty_info, ""

    # Max nodes: prefer NumberInput, fallback to SegmentedControl
    max_nodes = int(max_nodes_input or 0) if max_nodes_input else int(scale_tier or 1000)
    max_nodes = max(50, min(50000, max_nodes))

    # Get scale info for the info bar
    scale_info = pipeline.get_graph_scale_info()
    total_n = scale_info.get("total_nodes", 0)
    total_e = scale_info.get("total_edges", 0)
    rec_tier = scale_info.get("recommended_tier", "small")
    density = scale_info.get("density", 0)
    components = scale_info.get("components", 0)
    wmin, wmax = scale_info.get("weight_range", [0, 0])

    # Auto-enable performance mode for large graphs
    effective_perf = perf_mode or (max_nodes >= 5000 and total_n >= 5000)

    # Generate elements using the scalable engine
    elements = pipeline.get_cytoscape_elements_scaled(
        max_nodes=max_nodes,
        selection=selection or "composite",
        show_weights=show_weights if show_weights is not None else True,
        performance_mode=effective_perf,
    )

    # v16.23 T2: Enrich element data with node_type + node_type1 + node_type3 (for Cytoscape selector filtering)
    _nt_map_r: dict  = {}
    _nt1_map_r: dict = {}
    _nt3_map_r: dict = {}  # v16.31: Customer Segment (renamed from node_type2)
    for _tbl_name_r in ("node", "customer"):
        _tbl_r = pipeline.tables.get(_tbl_name_r) if hasattr(pipeline, "tables") else None
        if _tbl_r is not None:
            _id_col_r = "node_id" if "node_id" in _tbl_r.columns else "customer_id"
            if _id_col_r in _tbl_r.columns:
                if "node_type" in _tbl_r.columns:
                    for _nid_r, _ntype_r in zip(
                        _tbl_r[_id_col_r].astype(str),
                        _tbl_r["node_type"].fillna("Unknown").astype(str),
                    ):
                        _nt_map_r[_nid_r] = _ntype_r
                if "node_type1" in _tbl_r.columns:
                    for _nid_r, _ntype1_r in zip(
                        _tbl_r[_id_col_r].astype(str),
                        _tbl_r["node_type1"].fillna("External").astype(str),
                    ):
                        _nt1_map_r[_nid_r] = _ntype1_r
                if "node_type3" in _tbl_r.columns:
                    for _nid_r, _ntype3_r in zip(
                        _tbl_r[_id_col_r].astype(str),
                        _tbl_r["node_type3"].fillna("Retail").astype(str),
                    ):
                        _nt3_map_r[_nid_r] = _ntype3_r
            break
    for _el_r in elements:
        if "source" not in _el_r.get("data", {}):
            _nid_key_r = _el_r["data"].get("id", "")
            _el_r["data"]["node_type"]  = _nt_map_r.get(str(_nid_key_r), "Unknown")
            _el_r["data"]["node_type1"] = _nt1_map_r.get(str(_nid_key_r), "External")
            _el_r["data"]["node_type3"] = _nt3_map_r.get(str(_nid_key_r), "Retail")

    # Relabel nodes with customer names (skip in perf mode for speed)
    if not effective_perf:
        # v12.22 BUG-M02 FIX: build name map once; avoid per-node get_pipeline()+df-filter calls
        _cust_r = pipeline.tables.get("customer") if hasattr(pipeline, "tables") else None
        _nm_r: dict = {}
        if _cust_r is not None and len(_cust_r) > 0 and "customer_id" in _cust_r.columns:
            _nc_r = next((c for c in ("customer_name", "name") if c in _cust_r.columns), None)
            if _nc_r:
                for _cid_r, _cn_r in zip(
                    _cust_r["customer_id"].astype(str), _cust_r[_nc_r].fillna("")
                ):
                    if _cn_r:
                        _f_r = str(_cn_r).split()[0]
                        _s_r = _cid_r[-4:] if len(_cid_r) >= 4 else _cid_r
                        _nm_r[_cid_r] = f"{_f_r} (…{_s_r})"

        def _fast_radar(nid):
            s = str(nid)
            return _nm_r.get(s, f"…{s[-4:]}" if len(s) > 8 else s)

        for el in elements:
            if "source" not in el.get("data", {}):  # It's a node
                node_id = el.get("data", {}).get("id", "")
                el["data"]["label"] = _fast_radar(node_id)

    # Select layout
    layout_cfg = LAYOUT_PRESETS.get(layout_name or "cose", LAYOUT_PRESETS["cose"])

    # Select base stylesheet
    base_stylesheet = perf_stylesheet if effective_perf else cyto_stylesheet

    # ── Legend Filter: apply hide rules for deselected tiers / edges ──
    active_tiers = active_tiers or ["P1", "P2", "P3", "P4"]
    active_edges = active_edges or ["edge-thin", "edge-medium", "edge-thick", "edge-heavy"]
    hide_rules = []
    all_tiers = ["P1", "P2", "P3", "P4"]
    all_edges = ["edge-thin", "edge-medium", "edge-thick", "edge-heavy"]
    for t in all_tiers:
        if t not in active_tiers:
            hide_rules.append({"selector": f".{t}", "style": {"display": "none"}})
    for e in all_edges:
        if e not in active_edges:
            hide_rules.append({"selector": f".{e}", "style": {"display": "none"}})
    active_stylesheet = base_stylesheet + hide_rules

    # v16.23/v16.24/v16.28: Node type filters — dim non-matching nodes (AND logic)
    # v16.29 T3: node_type filter (entity type) removed — node_type1 + node_type3 cover all filter needs
    # node_type1_filter — ChipGroup multi-select list (["Internal","External"] = all = no filter)
    # node_type3_filter — ChipGroup multi-select list (all 4 = no filter)
    _nt1_sel   = set(node_type1_filter or ["Internal", "External"])
    _nt3_sel   = set(node_type3_filter or ["Retail", "Corporate", "Financial", "Government"])
    _ALL_NT1   = {"Internal", "External"}
    _ALL_NT3   = {"Retail", "Corporate", "Financial", "Government"}
    _NT1C_RADAR = {"Internal": "#2196F3", "External": "#FF9800"}  # v16.28 new External colour
    _NT3C_RADAR = {
        "Retail": "#00BFA5", "Corporate": "#9D4EDD",
        "Financial": "#FFD600", "Government": "#94A3B8",
    }

    # v16.29 T3: no entity-type filter — only node_type1 + node_type3
    _nt1_filtered = _nt1_sel != _ALL_NT1 and bool(_nt1_sel)
    _nt3_filtered = _nt3_sel != _ALL_NT3 and bool(_nt3_sel)

    if _nt1_filtered or _nt3_filtered:
        active_stylesheet = active_stylesheet + [
            {"selector": "node", "style": {"opacity": 0.08}},
        ]
        # Build Cartesian product of active filter values for highlight rules (AND-logic)
        _nt1_vals = sorted(_nt1_sel)   if _nt1_filtered else [None]
        _nt3_vals = sorted(_nt3_sel)   if _nt3_filtered else [None]
        for _n1v in _nt1_vals:
            for _n3v in _nt3_vals:
                _parts = []
                if _n1v: _parts.append(f"[node_type1 = '{_n1v}']")
                if _n3v: _parts.append(f"[node_type3 = '{_n3v}']")
                _sel = "node" + "".join(_parts)
                _bc  = _NT1C_RADAR.get(_n1v, _NT3C_RADAR.get(_n3v, "#9D4EDD"))
                active_stylesheet.append({
                    "selector": _sel,
                    "style": {
                        "opacity": 1.0,
                        "border-width": "2.5px",
                        "border-color": _bc,
                    },
                })

    # Count rendered nodes/edges
    rendered_nodes = sum(1 for el in elements if "source" not in el.get("data", {}))
    rendered_edges = len(elements) - rendered_nodes

    # Filtered counts
    hidden_tiers = [t for t in all_tiers if t not in active_tiers]
    filter_label = f" (hiding: {', '.join(hidden_tiers)})" if hidden_tiers else ""

    # Build scale info bar
    info_children = [
        dmc.Badge(
            f"Total: {total_n:,} nodes / {total_e:,} edges",
            color="cyan",
            variant="light",
            size="xs",
        ),
        dmc.Badge(
            f"Rendered: {rendered_nodes:,}N / {rendered_edges:,}E",
            color="green",
            variant="light",
            size="xs",
        ),
        dmc.Badge(f"Max Nodes: {max_nodes:,}", color="teal", variant="light", size="xs"),
        dmc.Badge(f"Tier: {rec_tier.upper()}", color="orange", variant="light", size="xs"),
        dmc.Badge(f"Density: {density:.4f}", color="gray", variant="light", size="xs"),
        dmc.Badge(f"Components: {components}", color="violet", variant="light", size="xs"),
        dmc.Badge(
            f"Weights: ${wmin:,.0f} — ${wmax:,.0f}", color="yellow", variant="light", size="xs"
        ),
    ]
    if effective_perf:
        info_children.append(
            dmc.Badge("⚡ PERFORMANCE MODE", color="orange", variant="filled", size="xs")
        )
    if filter_label:
        info_children.append(
            dmc.Badge(f"Filter{filter_label}", color="pink", variant="light", size="xs")
        )

    return elements, layout_cfg, active_stylesheet, info_children, ""


@callback(
    Output("node-details-panel", "children"),
    Input("cytoscape-graph", "tapNodeData"),
)
@GlobalExceptionHandler.wrap(fallback=[dmc.Text("Error loading details", c="red")])
def show_node_details(node_data):
    """Show details for clicked node with customer name + last 4 ID."""
    if not node_data:
        return [
            dmc.Center(
                [
                    dmc.Stack(
                        [
                            DashIconify(
                                icon="mdi:cursor-default-click-outline",
                                width=32,
                                color=THEME.TEXT_MUTED,
                            ),
                            dmc.Text("Click a node to investigate", c="dimmed", size="sm"),
                        ],
                        align="center",
                        gap="xs",
                    ),
                ],
                style={"minHeight": "200px"},
            )
        ]

    node_id = node_data.get("id", "Unknown")
    pipeline = get_pipeline()
    details = pipeline.get_node_details(node_id)

    items = []

    # Header — customer name + last 4
    # v12.22 BUG-M02 FIX: reuse already-fetched pipeline; avoid redundant get_pipeline() in _customer_label
    _cust_det = pipeline.tables.get("customer") if hasattr(pipeline, "tables") else None
    display_name = node_id
    if _cust_det is not None and len(_cust_det) > 0 and "customer_id" in _cust_det.columns:
        _m_det = _cust_det[_cust_det["customer_id"] == node_id]
        if len(_m_det) > 0:
            _n_det = _m_det.iloc[0].get("customer_name", "") or _m_det.iloc[0].get("name", "")
            if _n_det:
                display_name = f"{_n_det} (…{node_id[-4:]})"
    if display_name == node_id and len(node_id) > 8:
        display_name = f"…{node_id[-4:]}"
    tier = node_data.get("tier", "P4")
    tier_color = {"P1": "red", "P2": "orange", "P3": "yellow", "P4": "green"}.get(tier, "gray")
    items.append(
        dmc.Group(
            [
                dmc.Text(display_name, fw=700, c="white", size="md"),
                dmc.Badge(tier, color=tier_color, variant="filled"),
            ],
            justify="space-between",
        )
    )

    items.append(dmc.Divider(my="xs", color=THEME.DARK_BORDER))

    # Risk score
    risk_score = details.get("risk_score", 0) or 0
    items.append(
        dmc.Group(
            [
                dmc.Text("Risk Score", size="xs", c="dimmed"),
                dmc.Text(f"{risk_score:.1f}/100", fw=700, c="white"),
            ],
            justify="space-between",
        )
    )

    items.append(dmc.Progress(value=risk_score, color=tier_color, size="sm", my="xs"))

    # Network stats
    items.append(dmc.Text("Network Stats", size="xs", fw=600, c=THEME.PRIMARY, mt="sm"))
    for key in ["in_degree", "out_degree", "total_degree", "neighbor_count"]:
        val = details.get(key, 0)
        label = key.replace("_", " ").title()
        items.append(
            dmc.Group(
                [
                    dmc.Text(label, size="xs", c="dimmed"),
                    dmc.Text(str(val), size="xs", c="white", fw=600),
                ],
                justify="space-between",
            )
        )

    # Flow
    items.append(dmc.Text("Money Flow", size="xs", fw=600, c=THEME.PRIMARY, mt="sm"))
    for key in ["in_flow", "out_flow", "net_flow"]:
        val = details.get(key, 0)
        label = key.replace("_", " ").title()
        items.append(
            dmc.Group(
                [
                    dmc.Text(label, size="xs", c="dimmed"),
                    dmc.Text(
                        f"${val:,.2f}" if isinstance(val, (int, float)) else str(val),
                        size="xs",
                        c="white",
                        fw=600,
                    ),
                ],
                justify="space-between",
            )
        )

    # Additional attributes
    attrs = details.get("attributes", {})
    show_attrs = ["customer_type", "country", "segment", "occupation", "status"]
    found_attrs = {k: v for k, v in attrs.items() if k in show_attrs and v is not None}
    if found_attrs:
        items.append(dmc.Text("Profile", size="xs", fw=600, c=THEME.PRIMARY, mt="sm"))
        for key, val in found_attrs.items():
            label = key.replace("_", " ").title()
            items.append(
                dmc.Group(
                    [
                        dmc.Text(label, size="xs", c="dimmed"),
                        dmc.Text(str(val), size="xs", c="white"),
                    ],
                    justify="space-between",
                )
            )

    return items


# ── Sync SegmentedControl → Max Nodes NumberInput ──
@callback(
    Output("radar-max-nodes", "value"),
    Input("radar-scale-tier", "value"),
    prevent_initial_call=True,
)
def sync_tier_to_max_nodes(tier_value):
    """When user clicks a tier preset, update the NumberInput to match."""
    return int(tier_value or 1000)


# (v12.23: Legend toggle removed — filters are always visible in the horizontal bar above graph)


# ── Live Legend Filter (updates stylesheet without full reload) ──
@callback(
    Output("cytoscape-graph", "stylesheet", allow_duplicate=True),
    Input("radar-legend-tiers", "value"),
    Input("radar-legend-edges", "value"),
    State("radar-perf-mode", "checked"),
    prevent_initial_call=True,
)
def filter_by_legend(active_tiers, active_edges, perf_mode):
    """Dynamically show/hide risk tiers and edge bands via stylesheet."""
    base = perf_stylesheet if perf_mode else cyto_stylesheet
    active_tiers = active_tiers or []
    active_edges = active_edges or []
    hide_rules = []
    for t in ["P1", "P2", "P3", "P4"]:
        if t not in active_tiers:
            hide_rules.append({"selector": f".{t}", "style": {"display": "none"}})
    for e in ["edge-thin", "edge-medium", "edge-thick", "edge-heavy"]:
        if e not in active_edges:
            hide_rules.append({"selector": f".{e}", "style": {"display": "none"}})
    return base + hide_rules


# ── EXPORT CALLBACK ───────────────────────────────────────────────────────────
@callback(
    Output("radar-download", "data"),
    Input("radar-export-csv", "n_clicks"),
    prevent_initial_call=True,
)
def export_radar_csv(_):
    """Export scored network nodes as CSV for compliance records."""
    from engine import get_pipeline

    pipeline = get_pipeline()
    scored = pipeline.get_scored_df()
    if scored is not None:
        return dcc.send_data_frame(scored.to_csv, "radar_network_data.csv", index=False)
    return no_update


# ── v16.24 / v16.28: Entity-type filter options callback removed in v16.29 T3 ──
# radar-node-type-filter (Dropdown) was removed; node_type1 + node_type3 ChipGroups
# provide sufficient filtering without needing the generic entity-type dropdown.
