"""
Page 1: Dashboard (v12.43)
==========================
Bank AML | Financial Crime Detection AI — Command Centre

v12.43 Business Intelligence Upgrade:
  B1: Business-first language overhaul (executive-friendly labels)
  B2: Previous-run indicator banner (Run #X, date, customer count)
  B3: Progressive UI reset during re-run (stage-by-stage replacement)
  B4: Enhanced Data Readiness — business descriptions per table
v12.43: 2-layer Data Readiness, Risk Intelligence, Top Flagged, Network Health
"""

import dash
from dash import (
    html,
    dcc,
    callback,
    clientside_callback,
    Input,
    Output,
    State,
    no_update,
    dash_table,
    ctx,
)
import dash_mantine_components as dmc
import dash_ag_grid as dag
from dash_iconify import DashIconify
import plotly.graph_objects as go
import json
import time
import threading
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, APP
from engine import get_pipeline

# v16.53: Risk Tables suite (4 AG Grid tables auto-built from pipeline results)
from pages._dashboard_risk_tables import build_risk_tables_section  # noqa: E402

dash.register_page(__name__, path="/", name="Dashboard", title=f"FCDAI v{APP.VERSION} | Dashboard")

TIER_COLORS = {"P1": "#FF1744", "P2": "#FF9800", "P3": "#FFD600", "P4": "#00E676"}


def status_badge(label, loaded, color):
    return dmc.Badge(
        f"✓ {label}" if loaded else f"✗ {label}",
        color=color if loaded else "gray",
        variant="filled" if loaded else "outline",
        size="sm",
    )


# ─── v12.43: Enhanced Data Readiness with Business Context ───────────────────
GRAPH_TABLES = ["node", "edge"]
ENTITY_TABLES = ["customer", "account", "transaction", "kyc", "alert", "historical", "relationship"]
READINESS_TABLE_ORDER = GRAPH_TABLES + ENTITY_TABLES

TABLE_ICON_MAP = {
    "transaction": ("mdi:swap-horizontal-circle", "cyan"),
    "customer": ("mdi:account-group", "grape"),
    "account": ("mdi:bank", "green"),
    "kyc": ("mdi:shield-check", "yellow"),
    "alert": ("mdi:bell-alert", "red"),
    "historical": ("mdi:history", "teal"),
    "relationship": ("mdi:link-variant", "indigo"),
    "node": ("mdi:circle-double", "blue"),
    "edge": ("mdi:transit-connection-variant", "orange"),
}

# v12.43: Business context — what each table means for AML investigators
TABLE_BUSINESS_CONTEXT = {
    "node": "Entities in the transaction network (customers, accounts) used for relationship mapping",
    "edge": "Financial flows between entities — the transaction links that reveal money movement patterns",
    "customer": "Core customer profiles — the subjects of due diligence and risk assessment",
    "account": "Bank accounts held by customers — the vehicles through which funds flow",
    "transaction": "Individual financial transactions — the primary evidence for money laundering detection",
    "kyc": "Know Your Customer records — identity verification, risk ratings, and onboarding data",
    "alert": "System-generated alerts — flagged activities requiring investigation or escalation",
    "historical": "Historical investigation records — prior Narratives, case outcomes, and regulatory actions",
    "relationship": "Customer-to-customer and account linkages — beneficial ownership and authorized signers",
}

# v12.43: Business-friendly display names
TABLE_DISPLAY_NAMES = {
    "node": "Network Entities",
    "edge": "Transaction Links",
    "customer": "Customer Profiles",
    "account": "Account Registry",
    "transaction": "Financial Transactions",
    "kyc": "KYC Compliance Records",
    "alert": "Investigation Alerts",
    "historical": "Historical Case Data",
    "relationship": "Entity Relationships",
}


def _build_readiness_table_card(name, df):
    """Build a compact single-row card for a pipeline table (v12.11 — premium)."""
    icon, color = TABLE_ICON_MAP.get(name, ("mdi:table", "gray"))
    rows = len(df)
    cols = len(df.columns)

    # Completeness (non-null ratio)
    total_cells = rows * cols if rows > 0 and cols > 0 else 1
    non_null = df.count().sum()
    completeness = round((non_null / total_cells) * 100) if total_cells > 0 else 0
    comp_color = "green" if completeness >= 95 else "yellow" if completeness >= 80 else "red"

    return dmc.Group(
        [
            DashIconify(icon=icon, width=14, color=color),
            dmc.Text(
                name.replace("_", " ").title(),
                size="xs",
                fw=600,
                c="white",
                style={
                    "flex": "1",
                    "minWidth": "100px",
                    "whiteSpace": "nowrap",
                    "overflow": "hidden",
                    "textOverflow": "ellipsis",
                },
            ),
            dmc.Badge(
                f"{rows:,}",
                color="cyan",
                variant="light",
                size="xs",
                leftSection=DashIconify(icon="mdi:table-row", width=10),
            ),
            dmc.Badge(
                f"{cols}",
                color="grape",
                variant="light",
                size="xs",
                leftSection=DashIconify(icon="mdi:table-column", width=10),
            ),
            dmc.Badge(f"{completeness}%", color=comp_color, variant="filled", size="xs"),
        ],
        gap="xs",
        style={
            "padding": "4px 8px",
            "borderRadius": "6px",
            "backgroundColor": "rgba(0,0,0,0.12)",
            "border": "1px solid rgba(255,255,255,0.03)",
        },
    )


def _build_readiness_placeholder_box(name):
    """v12.43: Enhanced placeholder card with business context description."""
    icon, color = TABLE_ICON_MAP.get(name, ("mdi:table", "gray"))
    display_name = TABLE_DISPLAY_NAMES.get(name, name.replace("_", " ").title())
    biz_desc = TABLE_BUSINESS_CONTEXT.get(name, "")
    return dmc.Paper(
        [
            dmc.Stack(
                [
                    dmc.Group(
                        [
                            DashIconify(icon=icon, width=22, color=color),
                            dmc.Text(display_name, size="xs", fw=700, c="white"),
                        ],
                        gap="xs",
                    ),
                    (
                        dmc.Text(
                            biz_desc,
                            size="10px",
                            c="dimmed",
                            fs="italic",
                            lineClamp=2,
                            style={"minHeight": "24px"},
                        )
                        if biz_desc
                        else html.Div()
                    ),
                    dmc.SimpleGrid(
                        cols=3,
                        spacing=4,
                        children=[
                            dmc.Stack(
                                [
                                    dmc.Text("Records", size="10px", c="dimmed"),
                                    dmc.Text("—", size="sm", fw=700, c="dimmed"),
                                ],
                                gap=0,
                                align="center",
                            ),
                            dmc.Stack(
                                [
                                    dmc.Text("Fields", size="10px", c="dimmed"),
                                    dmc.Text("—", size="sm", fw=700, c="dimmed"),
                                ],
                                gap=0,
                                align="center",
                            ),
                            dmc.Stack(
                                [
                                    dmc.Text("Completeness", size="10px", c="dimmed"),
                                    dmc.Text("—", size="sm", fw=700, c="dimmed"),
                                ],
                                gap=0,
                                align="center",
                            ),
                        ],
                    ),
                    dmc.Badge(
                        "Awaiting Data", color="gray", variant="light", size="xs", fullWidth=True
                    ),
                ],
                gap=6,
            ),
        ],
        p="sm",
        radius="md",
        style={
            "backgroundColor": "rgba(0,0,0,0.25)",
            "border": f"1px solid {color}15",
            "minWidth": "130px",
        },
    )


def _build_readiness_live_box(name, df):
    """v12.43: Enhanced live box with business context + key column highlights."""
    icon, color = TABLE_ICON_MAP.get(name, ("mdi:table", "gray"))
    display_name = TABLE_DISPLAY_NAMES.get(name, name.replace("_", " ").title())
    biz_desc = TABLE_BUSINESS_CONTEXT.get(name, "")
    rows = len(df)
    cols = len(df.columns)
    total_cells = rows * cols if rows > 0 and cols > 0 else 1
    non_null = df.count().sum()
    completeness = round((non_null / total_cells) * 100) if total_cells > 0 else 0
    comp_color = "green" if completeness >= 95 else "yellow" if completeness >= 80 else "red"

    # v12.43: Key columns preview (first 4 non-trivial columns)
    key_cols = [c for c in df.columns if c not in ("index", "Unnamed: 0")][:4]
    col_badges = [
        dmc.Badge(
            c.replace("_", " ").title(),
            color="dark",
            variant="outline",
            size="xs",
            style={"fontSize": "9px"},
        )
        for c in key_cols
    ]

    return dmc.Paper(
        [
            dmc.Stack(
                [
                    dmc.Group(
                        [
                            DashIconify(icon=icon, width=22, color=color),
                            dmc.Text(display_name, size="xs", fw=700, c="white"),
                        ],
                        gap="xs",
                    ),
                    (
                        dmc.Text(
                            biz_desc,
                            size="10px",
                            c="dimmed",
                            fs="italic",
                            lineClamp=2,
                            style={"minHeight": "24px"},
                        )
                        if biz_desc
                        else html.Div()
                    ),
                    dmc.SimpleGrid(
                        cols=3,
                        spacing=4,
                        children=[
                            dmc.Stack(
                                [
                                    dmc.Text("Records", size="10px", c="dimmed"),
                                    dmc.Text(f"{rows:,}", size="sm", fw=700, c="cyan"),
                                ],
                                gap=0,
                                align="center",
                            ),
                            dmc.Stack(
                                [
                                    dmc.Text("Fields", size="10px", c="dimmed"),
                                    dmc.Text(str(cols), size="sm", fw=700, c="grape"),
                                ],
                                gap=0,
                                align="center",
                            ),
                            dmc.Stack(
                                [
                                    dmc.Text("Completeness", size="10px", c="dimmed"),
                                    dmc.Text(f"{completeness}%", size="sm", fw=700, c=comp_color),
                                ],
                                gap=0,
                                align="center",
                            ),
                        ],
                    ),
                    (
                        dmc.Group(col_badges, gap=4, style={"flexWrap": "wrap"})
                        if col_badges
                        else html.Div()
                    ),
                    dmc.Badge(
                        "✓ Loaded", color="green", variant="filled", size="xs", fullWidth=True
                    ),
                ],
                gap=6,
            ),
        ],
        p="sm",
        radius="md",
        style={
            "backgroundColor": "rgba(0,0,0,0.25)",
            "border": f"1px solid {color}40",
            "minWidth": "130px",
        },
    )


def _build_readiness_grouped_content(tables_loaded, pipeline=None):
    """v12.43 PREMIUM: Only renders loaded tables — blank/empty tables are hidden.
    Shows a clean empty state when nothing is loaded yet.
    Pending tables shown as a compact badge summary, not empty placeholder cards.
    """
    loaded_graph = [t for t in GRAPH_TABLES if t in tables_loaded]
    loaded_entity = [t for t in ENTITY_TABLES if t in tables_loaded]
    pending_graph = [t for t in GRAPH_TABLES if t not in tables_loaded]
    pending_entity = [t for t in ENTITY_TABLES if t not in tables_loaded]
    # Include any custom/extra tables not in the default taxonomy
    _extra_keys = [k for k in tables_loaded if k not in GRAPH_TABLES and k not in ENTITY_TABLES]
    total_loaded = len(loaded_graph) + len(loaded_entity) + len(_extra_keys)
    total_tables = len(GRAPH_TABLES) + len(ENTITY_TABLES)

    # ── Clean empty state when nothing is loaded ─────────────────────────────
    if total_loaded == 0:
        return dmc.Center(
            dmc.Stack(
                [
                    DashIconify(
                        icon="mdi:database-off-outline", width=44, color="rgba(255,255,255,0.12)"
                    ),
                    dmc.Text("No Data Loaded", fw=700, c="dimmed", size="sm"),
                    dmc.Text(
                        "Push data from Port Authority, then run the pipeline.",
                        c="dimmed",
                        size="xs",
                        ta="center",
                        style={"maxWidth": "260px"},
                    ),
                    dmc.Group(
                        [
                            dmc.Badge(
                                f"0 / {total_tables} tables ready",
                                color="gray",
                                variant="outline",
                                size="xs",
                                leftSection=DashIconify(icon="mdi:table-clock", width=10),
                            ),
                        ],
                        justify="center",
                    ),
                ],
                align="center",
                gap="xs",
            ),
            style={"minHeight": "110px", "padding": "28px"},
        )

    # ── Network context badges ────────────────────────────────────────────────
    net_badges = []
    if pipeline and pipeline.G:
        G = pipeline.G
        net_badges = [
            dmc.Badge(
                f"{G.number_of_nodes():,} entities", color="blue", variant="filled", size="xs"
            ),
            dmc.Badge(
                f"{G.number_of_edges():,} links", color="orange", variant="filled", size="xs"
            ),
        ]

    sections = []

    # ── Layer 1: Transaction Network (only if any loaded) ────────────────────
    if loaded_graph:
        sections.append(
            dmc.Group(
                [
                    dmc.Group(
                        [
                            DashIconify(icon="mdi:graph", width=15, color="#00D4FF"),
                            dmc.Text("Transaction Network", size="xs", fw=700, c="#00D4FF"),
                            dmc.Badge(
                                f"{len(loaded_graph)}/{len(GRAPH_TABLES)} ready",
                                color="blue",
                                variant="light",
                                size="xs",
                            ),
                        ]
                        + net_badges,
                        gap="xs",
                    ),
                    dmc.Divider(style={"flex": "1", "borderColor": "rgba(0,212,255,0.15)"}),
                ],
                gap="xs",
                mb="xs",
                align="center",
            )
        )
        sections.append(
            dmc.SimpleGrid(
                cols=2,
                spacing="sm",
                mb="md",
                children=[_build_readiness_live_box(t, tables_loaded[t]) for t in loaded_graph],
            )
        )

    # ── Layer 2: Business Intelligence (only if any loaded) ──────────────────
    if loaded_entity:
        sections.append(
            dmc.Group(
                [
                    dmc.Group(
                        [
                            DashIconify(icon="mdi:database", width=15, color="#9D4EDD"),
                            dmc.Text("Business Intelligence", size="xs", fw=700, c="#9D4EDD"),
                            dmc.Badge(
                                f"{len(loaded_entity)}/{len(ENTITY_TABLES)} ready",
                                color="grape",
                                variant="light",
                                size="xs",
                            ),
                        ],
                        gap="xs",
                    ),
                    dmc.Divider(style={"flex": "1", "borderColor": "rgba(157,78,221,0.15)"}),
                ],
                gap="xs",
                mb="xs",
                align="center",
            )
        )
        sections.append(
            dmc.SimpleGrid(
                cols={"base": 2, "md": 3},
                spacing="sm",
                children=[_build_readiness_live_box(t, tables_loaded[t]) for t in loaded_entity],
            )
        )

    # ── Layer 3: Extra / Custom tables (not in default taxonomy) ─────────────
    extra_tables = {
        k: v for k, v in tables_loaded.items() if k not in GRAPH_TABLES and k not in ENTITY_TABLES
    }
    if extra_tables:
        sections.append(
            dmc.Group(
                [
                    dmc.Group(
                        [
                            DashIconify(icon="mdi:table-plus", width=15, color="#00E5FF"),
                            dmc.Text("Custom / Additional Data", size="xs", fw=700, c="#00E5FF"),
                            dmc.Badge(
                                f"{len(extra_tables)} table{'s' if len(extra_tables) != 1 else ''}",
                                color="cyan",
                                variant="light",
                                size="xs",
                            ),
                        ],
                        gap="xs",
                    ),
                    dmc.Divider(style={"flex": "1", "borderColor": "rgba(0,229,255,0.15)"}),
                ],
                gap="xs",
                mb="xs",
                align="center",
            )
        )
        sections.append(
            dmc.SimpleGrid(
                cols={"base": 2, "md": 3},
                spacing="sm",
                mb="md",
                children=[_build_readiness_live_box(t, df) for t, df in extra_tables.items()],
            )
        )

    # ── Compact pending summary (badge row, not empty cards) ─────────────────
    pending_all = pending_graph + pending_entity
    if pending_all:
        pending_badges = [
            dmc.Badge(
                TABLE_DISPLAY_NAMES.get(t, t.replace("_", " ").title()),
                color="gray",
                variant="outline",
                size="xs",
                leftSection=DashIconify(
                    icon=TABLE_ICON_MAP.get(t, ("mdi:table", "gray"))[0], width=10
                ),
            )
            for t in pending_all
        ]
        sections.append(
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            DashIconify(
                                icon="mdi:clock-outline", width=13, color="rgba(255,255,255,0.2)"
                            ),
                            dmc.Text(
                                f"{len(pending_all)} tables awaiting:", size="10px", c="dimmed"
                            ),
                            dmc.Group(pending_badges, gap=4, style={"flexWrap": "wrap"}),
                        ],
                        gap="xs",
                        style={"flexWrap": "wrap"},
                    ),
                ],
                p="xs",
                radius="md",
                mt="sm",
                style={
                    "backgroundColor": "rgba(0,0,0,0.15)",
                    "border": "1px solid rgba(255,255,255,0.04)",
                },
            )
        )

    return html.Div(sections)


def _build_risk_tier_summary(scored_df):
    """v14.5: 4-tier portfolio breakdown cards.
    FIX-B: Always derives counts from risk_tier column (not score thresholds).
    Absolute score thresholds (80/60/40) are ONLY decorative labels — the
    actual tier assignment may use percentile mode, so score-based counting
    produces different numbers from tier-column counting. Both dashboard and
    executive summary now use the tier column → always consistent.
    """
    TIER_META = [
        ("P1", "Critical Risk", "#FF1744", "mdi:alert-octagon", 80, 100),
        ("P2", "High Risk", "#FF9800", "mdi:alert", 60, 80),
        ("P3", "Medium Risk", "#FFD600", "mdi:alert-circle-outline", 40, 60),
        ("P4", "Low Risk", "#00E676", "mdi:check-circle-outline", 0, 40),
    ]
    # v14.7 FIX-GAP5: Tiers are percentile-based (l6_scoring.py: top 1%=P1, 1-5%=P2, 5-15%=P3).
    # Badges show percentile bands, not absolute score thresholds.
    _TIER_PCT = {"P1": "Top 1%", "P2": "Top 1–5%", "P3": "Top 5–15%", "P4": "Standard"}

    if scored_df is None or len(scored_df) == 0:
        # Placeholder tier cards
        tier_cards = []
        for tier_key, tier_label, color, icon_name, lo, hi in TIER_META:
            tier_cards.append(
                dmc.Paper(
                    [
                        dmc.Group(
                            [
                                DashIconify(icon=icon_name, width=18, color=color),
                                dmc.Text(tier_label, size="xs", c="dimmed"),
                            ],
                            gap="xs",
                        ),
                        dmc.Text("\u2014", size="xl", fw=700, c="dimmed"),
                        dmc.Badge(
                            "Awaiting Data",
                            color="gray",
                            variant="light",
                            size="xs",
                            fullWidth=True,
                        ),
                    ],
                    p="sm",
                    radius="md",
                    style={"backgroundColor": "rgba(0,0,0,0.2)", "border": f"1px solid {color}15"},
                )
            )
        return html.Div(
            [
                dmc.SimpleGrid(cols={"base": 2, "md": 4}, spacing="sm", children=tier_cards),
            ]
        )

    total = len(scored_df)

    # v14.5 FIX-B: ALWAYS use the risk_tier column for counts.
    # Rationale: tier assignment uses percentile mode — top 1% = P1 regardless
    # of absolute score value. Score-threshold counting (score>=80 = P1) gives
    # a different number after post-propagation calibration. Both dashboard +
    # executive summary MUST read from the same risk_tier column.
    counts = {}
    tier_col = next((c for c in scored_df.columns if "tier" in c.lower()), None)
    if tier_col:
        vc = scored_df[tier_col].value_counts()
        for tk, *_ in TIER_META:
            counts[tk] = int(vc.get(tk, 0))
    else:
        # Ultimate fallback: derive tier from score using absolute thresholds
        score_col = next(
            (c for c in scored_df.columns if c in ("risk_score", "score", "composite_score")), None
        )
        if score_col is None:
            score_col = next((c for c in scored_df.columns if "score" in c.lower()), None)
        if score_col:
            # v14.7 FIX-GAP5: quantile-based fallback (percentile-consistent with tier algorithm)
            _s = scored_df[score_col]
            _n = len(_s)
            if _n >= 20:
                counts["P1"] = int((_s >= _s.quantile(0.99)).sum())
                counts["P2"] = int(((_s >= _s.quantile(0.95)) & (_s < _s.quantile(0.99))).sum())
                counts["P3"] = int(((_s >= _s.quantile(0.85)) & (_s < _s.quantile(0.95))).sum())
                counts["P4"] = int((_s < _s.quantile(0.85)).sum())
            else:
                # n<20: keep absolute thresholds but fix boundary by using strict upper (<, not <=)
                counts["P1"] = int((_s >= 80).sum())
                counts["P2"] = int(((_s >= 60) & (_s < 80)).sum())
                counts["P3"] = int(((_s >= 40) & (_s < 60)).sum())
                counts["P4"] = int((_s < 40).sum())
        else:
            for tk, *_ in TIER_META:
                counts[tk] = 0

    tier_cards = []
    for tier_key, tier_label, color, icon_name, lo, hi in TIER_META:
        cnt = counts.get(tier_key, 0)
        pct = round(cnt / total * 100) if total > 0 else 0
        # Safe rgba conversion
        try:
            r, g, b = int(color[1:3], 16), int(color[3:5], 16), int(color[5:7], 16)
            bg = f"rgba({r},{g},{b},0.07)"
            bd = f"1px solid rgba({r},{g},{b},0.25)"
        except Exception:
            bg, bd = "rgba(0,0,0,0.2)", f"1px solid {color}30"
        tier_cards.append(
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            DashIconify(icon=icon_name, width=18, color=color),
                            dmc.Text(tier_label, size="xs", c="dimmed"),
                        ],
                        gap="xs",
                        mb=4,
                    ),
                    dmc.Text(f"{cnt:,}", size="xl", fw=800, c=color),
                    dmc.Progress(value=pct, color=color, size="xs", radius="xl", mb=4),
                    dmc.Badge(
                        _TIER_PCT.get(tier_key, f"Score {lo}–{hi}"),
                        color="gray",
                        variant="outline",
                        size="xs",
                    ),
                ],
                p="sm",
                radius="md",
                style={"backgroundColor": bg, "border": bd},
            )
        )

    # Horizontal tier distribution bar chart
    bar_colors = [m[2] for m in TIER_META]
    bar_labels = [m[1] for m in TIER_META]
    bar_counts = [counts.get(m[0], 0) for m in TIER_META]
    fig = go.Figure(
        go.Bar(
            y=bar_labels,
            x=bar_counts,
            orientation="h",
            marker_color=bar_colors,
            text=bar_counts,
            textposition="outside",
            textfont=dict(color="#94A3B8", size=11),
        )
    )
    fig.update_layout(
        height=130,
        margin=dict(t=4, b=4, l=0, r=50),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        xaxis=dict(visible=False),
        yaxis=dict(color="#94A3B8", tickfont=dict(size=10), tickcolor="rgba(0,0,0,0)"),
        showlegend=False,
    )

    return html.Div(
        [
            dmc.SimpleGrid(cols={"base": 2, "md": 4}, spacing="sm", mb="sm", children=tier_cards),
            dcc.Graph(
                figure=fig,
                config={"displayModeBar": False, "staticPlot": True},
                style={"height": "130px"},
            ),
            # v16.45: Developer attribution — bottom-right of executive summary (Option A+C hybrid)
            dmc.Text(
                "FCDAI Analytics · Developed by Das Apurba · For modifications contact Das Apurba",
                size="10px",
                c="dimmed",
                ta="right",
                mt=2,
                style={"opacity": "0.40", "letterSpacing": "0.02em", "fontStyle": "italic"},
            ),
        ]
    )


# =============================================================================
# v16.42 T1: Scoring Model Summary — AG Grid with FCDAI theme
# Uses scored_df['score_{family}'] (properly normalised 0–1 per family) instead
# of analytics raw tables, which often lack a unified score column.
# =============================================================================
_SCORING_FAMILY_META = {
    "centrality": {
        "label": "Network Influence",
        "purpose": "Identifies high-power brokers & hub accounts",
    },
    "community": {
        "label": "Risk Group Detection",
        "purpose": "Detects suspicious clusters & criminal communities",
    },
    "pathflow": {
        "label": "Fund Flow Tracing",
        "purpose": "Traces money-movement paths & routing anomalies",
    },
    "link_prediction": {
        "label": "Hidden Relationships",
        "purpose": "Uncovers undisclosed financial connections",
    },
    "anomaly": {
        "label": "Behavioural Anomaly",
        "purpose": "Flags statistically abnormal transaction behaviour",
    },
    "temporal": {
        "label": "Time-Pattern Analysis",
        "purpose": "Detects velocity spikes, bursts & timed relays",
    },
    "multi_layer": {
        "label": "Cross-Entity Risk",
        "purpose": "Risk across financial + relationship networks",
    },
    "structuring": {
        "label": "Structuring / Smurfing",
        "purpose": "Identifies sub-threshold cash splitting",
    },
    "benfords": {
        "label": "Numeric Compliance",
        "purpose": "Statistical digit-frequency integrity check",
    },
    "motifs": {
        "label": "Transaction Patterns",
        "purpose": "Recognises known AML typology patterns",
    },
}

_DEFAULT_WEIGHTS = {
    "centrality": 0.15, "community": 0.10, "pathflow": 0.10,
    "link_prediction": 0.10, "anomaly": 0.15, "temporal": 0.10,
    "multi_layer": 0.10, "structuring": 0.10, "benfords": 0.05, "motifs": 0.05,
}


def _build_scoring_summary_grid(scored_df, analytics_data=None, weights_for_table=None):
    """v16.42 T1: Premium AG Grid — Scoring Model Summary.

    Uses scored_df['score_{family}'] (0–1 normalised) for accurate avg/peak.
    Families without a score column (e.g. motifs) show 0 with 'No Signal' status.
    All values displayed on 0–100 scale for business readability.
    """
    import pandas as pd

    if scored_df is None or len(scored_df) == 0:
        return dmc.Center(
            dmc.Text("Run pipeline to populate Scoring Model Summary", c="dimmed", size="sm"),
            style={"minHeight": "60px"},
        )

    if weights_for_table is None:
        weights_for_table = _DEFAULT_WEIGHTS

    rows = []
    for fkey, meta in _SCORING_FAMILY_META.items():
        sc_col   = f"score_{fkey}"
        weight   = weights_for_table.get(fkey, _DEFAULT_WEIGHTS.get(fkey, 0))
        node_cnt = len(scored_df)  # all nodes pass through all families

        # Use analytics_data node count if available (raw family output size)
        if analytics_data:
            _fdf = analytics_data.get(fkey)
            if _fdf is not None and len(_fdf) > 0:
                node_cnt = len(_fdf)

        if sc_col in scored_df.columns:
            _series  = scored_df[sc_col].fillna(0)
            avg_raw  = float(_series.mean())
            max_raw  = float(_series.max())
            # v16.56 BUG-FIX #2: use per-family node_cnt as denominator
            # (len(_series) = all scored_df rows; node_cnt = family output rows)
            coverage = float((_series > 0.001).sum()) / max(node_cnt, 1) * 100
            avg_100  = round(avg_raw * 100, 1)
            max_100  = round(max_raw * 100, 1)
            # Business-readable signal strength
            if avg_100 >= 40:
                status = "HIGH RISK"
            elif avg_100 >= 20:
                status = "ELEVATED"
            elif avg_100 >= 8:
                status = "MODERATE"
            elif avg_100 > 0.5:
                status = "LOW"
            else:
                status = "TRACE"
        else:
            avg_100  = 0.0
            max_100  = 0.0
            coverage = 0.0
            status   = "NO SIGNAL"

        rows.append({
            "Analytics Module":    meta["label"],
            "What It Detects":     meta["purpose"],
            "Weight":              round(weight * 100),       # numeric for sort
            "Entities Analysed":   node_cnt,                  # numeric
            "Avg Risk Signal":     avg_100,                   # numeric 0-100
            "Peak Risk Signal":    max_100,                   # numeric 0-100
            "Coverage %":          round(coverage, 1),        # numeric
            "Signal Strength":     status,
        })

    # Sort by Weight descending, then Avg Risk Signal desc
    rows.sort(key=lambda r: (-r["Weight"], -r["Avg Risk Signal"]))

    _STATUS_STYLE = {"function": (
        "params.value === 'HIGH RISK' ? {'color':'#FF4560','fontWeight':'700','background':'rgba(255,69,96,0.12)'} : "
        "params.value === 'ELEVATED' ? {'color':'#FF9800','fontWeight':'700','background':'rgba(255,152,0,0.10)'} : "
        "params.value === 'MODERATE' ? {'color':'#FFD600','fontWeight':'600'} : "
        "params.value === 'LOW'      ? {'color':'#00E676','fontWeight':'500'} : "
        "params.value === 'TRACE'    ? {'color':'#64FFDA'} : "
        "{'color':'#64748B'}"  # NO SIGNAL
    )}
    _AVG_STYLE = {"function": (
        "params.value >= 40 ? {'color':'#FF4560','fontWeight':'700'} : "
        "params.value >= 20 ? {'color':'#FF9800','fontWeight':'700'} : "
        "params.value >= 8  ? {'color':'#FFD600'} : "
        "params.value > 0   ? {'color':'#00E676'} : {'color':'#64748B'}"
    )}
    _PEAK_STYLE = {"function": (
        "params.value >= 60 ? {'color':'#FF4560','fontWeight':'700'} : "
        "params.value >= 40 ? {'color':'#FF9800'} : "
        "params.value >= 20 ? {'color':'#FFD600'} : "
        "params.value > 0   ? {'color':'#64FFDA'} : {'color':'#64748B'}"
    )}
    _COV_STYLE = {"function": (
        "params.value >= 60 ? {'color':'#00E676'} : "
        "params.value >= 30 ? {'color':'#FFD600'} : "
        "params.value > 0   ? {'color':'#FF9800'} : {'color':'#64748B'}"
    )}
    _WEIGHT_STYLE = {"function": "({'color':'#00D4FF','fontWeight':'600'})"}

    col_defs = [
        {
            "field": "Analytics Module", "headerName": "Analytics Module",
            "width": 155, "pinned": "left",
            "cellStyle": {"color": "#E2E8F0", "fontWeight": "600"},
        },
        {
            "field": "What It Detects", "headerName": "What It Detects",
            "flex": 1, "minWidth": 200,
            "wrapText": True, "autoHeight": True,
            "cellStyle": {"color": "#94A3B8", "fontSize": "11px"},
        },
        {
            "field": "Weight", "headerName": "Weight %",
            "width": 90, "type": "numericColumn",
            "cellStyle": _WEIGHT_STYLE,
            "valueFormatter": {"function": "params.value + '%'"},
        },
        {
            "field": "Entities Analysed", "headerName": "Entities",
            "width": 100, "type": "numericColumn",
            "cellStyle": {"color": "#CBD5E1"},
            "valueFormatter": {"function": "params.value.toLocaleString()"},
        },
        {
            "field": "Avg Risk Signal", "headerName": "Avg Signal",
            "width": 110, "type": "numericColumn",
            "sort": "desc",
            "cellStyle": _AVG_STYLE,
            "valueFormatter": {"function": "params.value.toFixed(1)"},
        },
        {
            "field": "Peak Risk Signal", "headerName": "Peak Signal",
            "width": 110, "type": "numericColumn",
            "cellStyle": _PEAK_STYLE,
            "valueFormatter": {"function": "params.value.toFixed(1)"},
        },
        {
            "field": "Coverage %", "headerName": "Coverage %",
            "width": 110, "type": "numericColumn",
            "cellStyle": _COV_STYLE,
            "valueFormatter": {"function": "params.value.toFixed(1) + '%'"},
        },
        {
            "field": "Signal Strength", "headerName": "Signal Strength",
            "width": 120,
            "cellStyle": _STATUS_STYLE,
        },
    ]

    return html.Div([
        dmc.Text(
            "Risk Analytics — Scoring Model Summary",
            fw=700, c="white", size="sm", mt="lg", mb="xs",
        ),
        dmc.Text(
            "Each analytics module independently analyses customer behaviour. "
            "Avg Signal and Peak Signal are on a 0–100 scale (higher = more suspicious).",
            c="dimmed", size="xs", mb="sm",
        ),
        dag.AgGrid(
            rowData=rows,
            columnDefs=col_defs,
            defaultColDef={
                "sortable": True, "filter": True, "resizable": True,
                "suppressMenu": False,
            },
            dashGridOptions={
                "domLayout": "autoHeight",
                "rowHeight": 44,
                "headerHeight": 36,
                "animateRows": True,
                "suppressCellFocus": True,
            },
            style={"height": None, "width": "100%"},
            className="ag-theme-fcdai",
        ),
    ])


def _compose_why_flagged(row: dict) -> str:
    """v16.43: Business-friendly risk summary for the Top Customers table.

    Always leads with how many of 10 detection engines raised concerns,
    which risk categories drove the alert, and what action is appropriate.
    No internal technical jargon — written for a compliance officer or business
    analyst who is NOT an algorithm expert.
    """
    _THRESHOLD = 0.08  # normalised score (0–1) to count a family as 'active'

    # Human-readable names for each detection engine
    _FAMILY_LABELS = {
        "score_centrality":      "network influence (hub behaviour)",
        "score_community":       "high-risk group membership",
        "score_pathflow":        "suspicious fund routing",
        "score_link_prediction": "undisclosed financial connections",
        "score_anomaly":         "behavioural anomaly",
        "score_temporal":        "unusual timing patterns",
        "score_multi_layer":     "cross-entity exposure",
        "score_structuring":     "sub-threshold cash splitting",
        "score_benfords":        "numeric integrity irregularity",
        "score_motifs":          "known money-laundering pattern",
    }

    # Count which families exceeded the signal threshold
    active = []
    for col, label in _FAMILY_LABELS.items():
        try:
            v = float(row.get(col) or 0)
            if v >= _THRESHOLD:
                active.append((v, label))
        except Exception:
            pass
    active.sort(reverse=True)
    n_active = len(active)

    # Also honour pre-computed consensus_count if it's higher
    try:
        cc = int(float(row.get("consensus_count", 0) or 0))
        if cc > n_active:
            n_active = cc
    except Exception:
        pass

    score = 0.0
    try:
        score = float(row.get("risk_score", 0) or 0)
    except Exception:
        pass

    tier = str(row.get("risk_tier", "P4") or "P4")

    # ── No signals ──────────────────────────────────────────────────────────
    if n_active == 0:
        return (
            f"No elevated risk signals detected across all 10 detection engines. "
            f"Risk score {score:.0f}/100 — standard monitoring applies."
        )

    # ── Build lead sentence ─────────────────────────────────────────────────
    noun = "detection engine" if n_active == 1 else "detection engines"
    top_labels = [lbl for _, lbl in active[:3]]
    if len(top_labels) == 1:
        signals_str = top_labels[0]
    elif len(top_labels) == 2:
        signals_str = f"{top_labels[0]} and {top_labels[1]}"
    else:
        signals_str = f"{top_labels[0]}, {top_labels[1]} and {top_labels[2]}"

    base = (
        f"{n_active} of 10 {noun} raised concerns — "
        f"primary signals: {signals_str}."
    )

    # ── Tier-specific action sentence ────────────────────────────────────────
    if tier == "P1":
        context = f" Risk score {score:.0f}/100 — immediate escalation required."
    elif tier == "P2":
        context = f" Risk score {score:.0f}/100 — assign to enhanced due diligence queue."
    elif tier == "P3":
        context = f" Risk score {score:.0f}/100 — review scheduled within 30 days."
    else:
        context = f" Risk score {score:.0f}/100 — continue standard monitoring."

    return base + context


def _build_top_flagged_table(scored_df):
    """v16.42 T2: Top Customers — AG Grid (ag-theme-fcdai).
    Columns: Node ID | Name | Entity Class (node_type) | Category (node_type1)
             | Profile (node_type3) | AML Risk Role (aml_role) | Risk Score
             | Priority | In Flow ($) | Out Flow ($) | Why Flagged
    node_type / node_type1 / node_type3 all sourced from node table (not derived).
    """
    import pandas as pd

    if scored_df is None or len(scored_df) == 0:
        return dmc.Center(
            dmc.Stack(
                [
                    DashIconify(icon="mdi:account-question", width=28, color="dimmed"),
                    dmc.Text("Run pipeline to see flagged customers", c="dimmed", size="sm"),
                ],
                align="center",
                gap="xs",
            ),
            style={"minHeight": "80px"},
        )

    # ── Step 1: Merge node attrs from engine.tables["node"] ────────────────
    # Pulls: name, node_type (Entity Class), node_type1 (Category),
    #        node_type3 (Profile), country, identifier
    try:
        from engine import get_pipeline as _gp
        _pipe = _gp()
        _tbl_dict = getattr(_pipe, "tables", {})
        _node_tbl = next(
            (_tbl_dict[k] for k in ("node", "nodes") if _tbl_dict.get(k) is not None), None
        )
        if _node_tbl is not None and len(_node_tbl) > 0:
            _id_col_node = next(
                (c for c in _node_tbl.columns if c in ("node_id", "customer_id", "id")), None
            )
            if _id_col_node:
                _want = ("name", "node_type", "node_type1", "node_type3", "country", "identifier")
                _extra = [c for c in _want
                          if c in _node_tbl.columns and c not in scored_df.columns]
                if _extra:
                    _attrs = _node_tbl[[_id_col_node] + _extra].copy()
                    _sdf_id = next(
                        (c for c in scored_df.columns if c in ("node_id", "customer_id", "id")), None
                    )
                    if _sdf_id:
                        _attrs = _attrs.rename(columns={_id_col_node: _sdf_id})
                        scored_df = scored_df.merge(_attrs, on=_sdf_id, how="left")
    except Exception:
        pass

    # ── Step 2: Pull in_flow / out_flow from graph G node attributes ──────
    _in_f_map: dict = {}
    _out_f_map: dict = {}
    try:
        from engine import get_pipeline as _gp2
        _pipe2 = _gp2()
        _G = None
        try:
            _G = _pipe2.graph.graph
        except Exception:
            _G = getattr(_pipe2, "G", None)
        if _G is not None:
            for _n in _G.nodes:
                _nd = _G.nodes[_n]
                _in_f_map[str(_n)]  = float(_nd.get("in_flow",  0) or 0)
                _out_f_map[str(_n)] = float(_nd.get("out_flow", 0) or 0)
    except Exception:
        pass

    # ── Column discovery ───────────────────────────────────────────────────
    score_col   = next((c for c in scored_df.columns if c in ("risk_score", "composite_score", "score")), None)
    if score_col is None:
        score_col = next((c for c in scored_df.columns if "score" in c.lower()), None)
    id_col      = next((c for c in scored_df.columns if c in ("customer_id", "node_id", "id")), None)
    tier_col    = next((c for c in scored_df.columns if "tier" in c.lower() and "change" not in c.lower()), None)
    name_col    = next((c for c in scored_df.columns if c in ("name", "customer_name", "full_name")), None)
    # Entity Class  → node_type  (e.g. Entity / Customer / Account)
    ent_col     = next((c for c in scored_df.columns if c == "node_type"), None)
    # Category      → node_type1 (e.g. External / Internal)
    cat_col     = next((c for c in scored_df.columns if c == "node_type1"), None)
    # Profile       → node_type3 (e.g. Corporate / Individual)
    prof_col    = next((c for c in scored_df.columns if c == "node_type3"), None)
    # AML Risk Role → aml_role   (e.g. PERIPHERAL / MULE / BROKER)
    role_col    = next((c for c in scored_df.columns if c in ("aml_role", "role")), None)

    if not score_col:
        return dmc.Text("Risk score column not found", c="dimmed", size="sm")

    # v16.71 H9: Auto-detect score scale (0-1 vs 0-100) and normalise to 0-100.
    # Pipeline stores risk_score as normalised 0-1 floats; display must show 0-100.
    _score_max = float(scored_df[score_col].fillna(0).max())
    _score_scale = 100.0 if _score_max <= 1.01 else 1.0   # multiply raw scores by this

    # ── Sort: tier priority first, then score desc ─────────────────────────
    _TIER_PRI = {"P1": 0, "P2": 1, "P3": 2, "P4": 3}
    _tier_p = (
        scored_df[tier_col].map(_TIER_PRI).fillna(4) if tier_col
        else pd.Series(4, index=scored_df.index)
    )
    top_df = (
        scored_df.assign(_tp=_tier_p)
        .sort_values(["_tp", score_col], ascending=[True, False])
        .drop(columns=["_tp"])
        .head(100)          # v16.65: load up to 100 for pagination; default page = 10
    )

    # ── Build row records ──────────────────────────────────────────────────
    def _clean(val, fallback="—"):
        s = str(val or "").strip()
        return fallback if s in ("", "nan", "None") else s

    rows = []
    for rank, (_, row) in enumerate(top_df.iterrows(), 1):
        raw_id = _clean(row.get(id_col, f"CUST-{rank:04d}"), f"CUST-{rank:04d}") if id_col else f"CUST-{rank:04d}"
        cid    = (raw_id[:4] + "\u2605\u2605\u2605" + raw_id[-3:]) if len(raw_id) > 8 else raw_id
        score  = round(float(row[score_col]) * _score_scale, 1)

        raw_name  = _clean(row.get(name_col, ""), "") if name_col else ""
        cust_name = (raw_name[:3] + "***" + raw_name[-2:]) if len(raw_name) > 6 else (raw_name[:3] + "***" if raw_name else cid)

        # Entity Class — from node_type (node table)
        ent_class = _clean(row.get(ent_col, ""), "Customer") if ent_col else "Customer"
        ent_class = ent_class.title()

        # Category — from node_type1 (node table: External / Internal)
        category  = _clean(row.get(cat_col, ""), "—") if cat_col else "—"
        if category not in ("—",):
            category = category.title()

        # Profile — from node_type3 (node table: Corporate / Individual)
        profile   = _clean(row.get(prof_col, ""), "—") if prof_col else "—"
        if profile not in ("—",):
            profile = profile.title()

        # AML Risk Role — from scored_df aml_role
        aml_role  = _clean(row.get(role_col, ""), "—") if role_col else "—"

        # Tier / Priority
        _tier_val = row.get(tier_col) if tier_col else None
        tier = str(_tier_val) if (_tier_val and str(_tier_val).startswith("P")) else (
            "P1" if score >= 80 else "P2" if score >= 60 else "P3" if score >= 40 else "P4"
        )
        priority = (
            "P1 \u2014 Critical" if tier == "P1" else
            "P2 \u2014 High"     if tier == "P2" else
            "P3 \u2014 Medium"   if tier == "P3" else
            "P4 \u2014 Monitor"
        )

        # In / Out Flow
        in_flow_v  = _in_f_map.get(raw_id, 0.0)
        out_flow_v = _out_f_map.get(raw_id, 0.0)

        # Why Flagged
        sar_raw = _clean(row.get("sar_narrative", ""), "")
        _boring = "No elevated AML indicators detected. Account shows patterns consistent with normal banking activity."
        why_flagged = sar_raw if (sar_raw and sar_raw != _boring) else \
            _compose_why_flagged(row.to_dict() if hasattr(row, "to_dict") else dict(row))

        rows.append({
            "Node ID":       cid,
            "Name":          cust_name,
            "Entity Class":  ent_class,
            "Category":      category,
            "Profile":       profile,
            "AML Risk Role": aml_role,
            "Risk Score":    score,
            "Priority":      priority,
            "Inbound ($)":   in_flow_v,
            "Outbound ($)":  out_flow_v,
            "Why Flagged":   why_flagged,
        })

    if not rows:
        return dmc.Text("No flagged customers in this run.", c="dimmed", size="sm")

    # ── AG Grid column definitions ─────────────────────────────────────────
    _PRIORITY_STYLE = {"function": (
        "params.value && params.value.startsWith('P1') ? "
        "{'color':'#FF3D71','fontWeight':'700','background':'rgba(255,61,113,0.12)'} : "
        "params.value && params.value.startsWith('P2') ? "
        "{'color':'#FFB300','fontWeight':'700','background':'rgba(255,179,0,0.10)'} : "
        "params.value && params.value.startsWith('P3') ? "
        "{'color':'#FFD600','fontWeight':'600','background':'rgba(255,214,0,0.08)'} : "
        "{'color':'#00E676','fontWeight':'500'}"
    )}
    _SCORE_STYLE = {"function": (
        "params.value >= 80 ? {'color':'#FF3D71','fontWeight':'700'} : "
        "params.value >= 60 ? {'color':'#FFB300','fontWeight':'700'} : "
        "params.value >= 40 ? {'color':'#FFD600'} : {'color':'#64748B'}"
    )}
    _ROLE_STYLE = {"function": (
        "params.value === 'MULE' ? {'color':'#FF3D71','background':'rgba(255,61,113,0.10)'} : "
        "params.value === 'BROKER' ? {'color':'#FFB300','background':'rgba(255,179,0,0.10)'} : "
        "params.value === 'ORIGINATOR' ? {'color':'#00D4FF','background':'rgba(0,212,255,0.08)'} : "
        "params.value === 'SINK' ? {'color':'#B39DDB','background':'rgba(179,157,219,0.10)'} : "
        "params.value === 'PERIPHERAL' ? {'color':'#8C9AB5'} : "
        "{'color':'#8C9AB5'}"
    )}
    _CAT_STYLE = {"function": (
        "params.value === 'External' ? {'color':'#FFB300','background':'rgba(255,179,0,0.08)'} : "
        "params.value === 'Internal' ? {'color':'#00E676','background':'rgba(0,230,118,0.08)'} : "
        "{'color':'#8C9AB5'}"
    )}
    _PROFILE_STYLE = {"function": (
        "params.value === 'Corporate' ? {'color':'#00D4FF','fontWeight':'600'} : "
        "params.value === 'Individual' ? {'color':'#64FFDA'} : "
        "{'color':'#8C9AB5'}"
    )}

    col_defs = [
        {
            "field": "Node ID", "headerName": "Node ID", "width": 120, "pinned": "left",
            "cellStyle": {"color": "#00D4FF", "fontWeight": "700", "fontFamily": "monospace"},
        },
        {
            "field": "Name", "headerName": "Name", "width": 110,
            "cellStyle": {"color": "#CBD5E1"},
        },
        {
            "field": "Entity Class", "headerName": "Entity Class", "width": 115,
            "cellStyle": {"color": "#64FFDA", "fontWeight": "500"},
        },
        {
            "field": "Category", "headerName": "Category", "width": 110,
            "cellStyle": _CAT_STYLE,
        },
        {
            "field": "Profile", "headerName": "Profile", "width": 110,
            "cellStyle": _PROFILE_STYLE,
        },
        {
            "field": "AML Risk Role", "headerName": "AML Risk Role", "width": 130,
            "cellStyle": _ROLE_STYLE,
        },
        {
            "field": "Risk Score", "headerName": "Score", "width": 80, "type": "numericColumn",
            "sort": "desc", "cellStyle": _SCORE_STYLE,
            "valueFormatter": {"function": "params.value.toFixed(1)"},
        },
        {
            "field": "Priority", "headerName": "Priority", "width": 130,
            "cellStyle": _PRIORITY_STYLE,
        },
        {
            "field": "Inbound ($)", "headerName": "Inbound ($)", "width": 115,
            "type": "numericColumn",
            "valueFormatter": {"function": "params.value > 0 ? '$' + params.value.toLocaleString('en-US', {maximumFractionDigits:0}) : '\u2014'"},
            "cellStyle": {"color": "#00E676", "fontFamily": "monospace"},
        },
        {
            "field": "Outbound ($)", "headerName": "Outbound ($)", "width": 115,
            "type": "numericColumn",
            "valueFormatter": {"function": "params.value > 0 ? '$' + params.value.toLocaleString('en-US', {maximumFractionDigits:0}) : '\u2014'"},
            "cellStyle": {"color": "#FFB300", "fontFamily": "monospace"},
        },
        {
            "field": "Why Flagged", "headerName": "Why Flagged", "flex": 1, "minWidth": 240,
            "wrapText": True, "autoHeight": True,
            "cellStyle": {"color": "#8C9AB5", "fontSize": "11px", "lineHeight": "1.4"},
        },
    ]

    return dag.AgGrid(
        rowData=rows,
        columnDefs=col_defs,
        defaultColDef={
            "sortable": True,
            "filter": True,
            "resizable": True,
            "suppressMenu": False,
            "floatingFilter": False,
        },
        dashGridOptions={
            "domLayout": "autoHeight",
            "rowHeight": 44,
            "headerHeight": 36,
            "animateRows": True,
            "suppressCellFocus": True,
            # v16.65: pagination — show 10 per page; user can navigate to see all
            "pagination": True,
            "paginationPageSize": 10,
            "paginationPageSizeSelector": [10, 25, 50, 100],
        },
        style={"height": None, "width": "100%"},
        className="ag-theme-fcdai",
    )


def _build_network_health_panel(pipeline):
    """v16.29 T1: 16 AML-relevant graph metrics — structural + risk-focused.

    METRIC GLOSSARY (each metric explained):
    ─────────────────────────────────────────
    • Total Entities     = # nodes in the transaction graph (customers + entities)
    • Financial Links    = # directed transaction edges
    • Network Density    = edges / max-possible-edges (0→1; high = tightly knit)
    • Avg Connections    = average degree per node (in+out transactions)
    • Avg Clustering     = tendency to form cliques/triangles (high = tight communities)
    • Risk Concentration = % of edges concentrated in top-10% highest-degree nodes
    • Graph Components   = count of disconnected sub-graphs (1 = fully connected, NORMAL for
                           dense financial networks — all accounts reachable via paths)
    • Largest Component  = biggest connected group (# nodes + % of total)
    • Communities        = Louvain-detected tight sub-clusters within the graph —
                           THIS is what users call 'clusters'; different from 'components'
    • Isolated Nodes     = accounts with zero transactions (ghost/dormant)
    • Hub Nodes          = accounts with unusually many links (potential mule hubs)
    • Circular Txns      = reciprocity: % of A→B edges also have B→A (round-trip signal)
    • Self-loops         = accounts sending money to themselves (structuring signal)
    • Circular Rings     = Strongly Connected Components (SCC): CONFIRMED money loops
    • Nodes in Rings     = total accounts involved in confirmed money rings
    • Largest Ring       = size of the biggest confirmed circular ring

    📍 WHERE TO SEE DRILL-DOWN DETAILS:
    • Lobby page  → tier distribution, top-risk table, full graph overview
    • Radar page  → interactive graph, visualise clusters and communities
    • Geo-Risk    → country + US state risk heatmaps
    """
    if pipeline.G is None:
        return dmc.Center(
            dmc.Stack(
                [
                    DashIconify(icon="mdi:graph-outline", width=28, color="dimmed"),
                    dmc.Text("Run pipeline to see network health metrics", c="dimmed", size="sm"),
                ],
                align="center",
                gap="xs",
            ),
            style={"minHeight": "80px"},
        )

    import networkx as nx

    G = pipeline.G
    n_nodes = G.number_of_nodes()
    n_edges = G.number_of_edges()
    density = nx.density(G)
    degrees = [d for _, d in G.degree()]
    avg_degree = (sum(degrees) / n_nodes) if n_nodes > 0 else 0

    # Connected components (weakly = reachability ignoring edge direction)
    # NOTE: 1 component is NORMAL for dense financial graphs.
    # Do NOT confuse with Communities (Louvain) — see below.
    try:
        if G.is_directed():
            comps = list(nx.weakly_connected_components(G))
        else:
            comps = list(nx.connected_components(G))
        n_comps = len(comps)
        largest = max(len(c) for c in comps) if comps else 0
    except Exception:
        n_comps = 0
        largest = 0
    l_pct = round(largest / n_nodes * 100) if n_nodes > 0 else 0

    # v16.29 T1: Community detection — Louvain or greedy modularity fallback
    # Communities = densely-connected sub-clusters (what users mean by "clusters").
    # 1 graph component can contain MANY communities.
    n_communities = 0
    try:
        _G_und_comm = G.to_undirected() if G.is_directed() else G
        try:
            _communities = list(nx.community.louvain_communities(_G_und_comm, seed=42))
        except AttributeError:
            _communities = list(nx.community.greedy_modularity_communities(_G_und_comm))
        n_communities = len(_communities)
    except Exception:
        n_communities = 0

    # v12.47: Additional AML-specific metrics
    # 1. Avg Clustering Coefficient — hub formation / clique signal
    try:
        G_und = G.to_undirected() if G.is_directed() else G
        avg_clustering = nx.average_clustering(G_und)
    except Exception:
        avg_clustering = 0.0

    # 2. Hub Nodes — high-degree nodes (potential money mule hubs)
    hub_threshold = max(5, int(avg_degree * 2.5))
    hub_nodes = sum(1 for d in degrees if d >= hub_threshold)
    hub_pct = round(hub_nodes / n_nodes * 100) if n_nodes > 0 else 0

    # 3. Isolated Nodes (degree = 0) — ghost/dormant accounts
    isolated_nodes = sum(1 for d in degrees if d == 0)

    # 4. Reciprocity — circular transaction signal (directed graphs only)
    try:
        if G.is_directed() and n_edges > 0:
            reciprocity = nx.overall_reciprocity(G)
        else:
            reciprocity = None
    except Exception:
        reciprocity = None

    # 5. Self-loops — structuring / round-tripping signal
    try:
        self_loops = G.number_of_selfloops()
    except Exception:
        self_loops = 0

    # 6. Risk Concentration — % of edges held by top-10% degree nodes
    try:
        if n_nodes > 0 and n_edges > 0:
            top_k = max(1, int(n_nodes * 0.1))
            top_deg = sorted(degrees, reverse=True)[:top_k]
            conc_pct = round(sum(top_deg) / (2 * n_edges) * 100) if n_edges > 0 else 0
        else:
            conc_pct = 0
    except Exception:
        conc_pct = 0

    # Build metrics list (13 total)
    recip_str = f"{reciprocity:.1%}" if reciprocity is not None else "N/A (undirected)"
    communities_str = f"{n_communities:,}" if n_communities > 0 else "—"
    metrics = [
        # 6 key business-readable network health metrics
        ("Total Entities",     f"{n_nodes:,}", "mdi:circle-double", "#00D4FF"),
        ("Financial Links",    f"{n_edges:,}", "mdi:transit-connection-variant", "#FF9800"),
        ("Network Density",    f"{density:.5f}", "mdi:grain", "#00E676"),
        ("Avg Connections",    f"{avg_degree:.2f}", "mdi:vector-polyline", "#9D4EDD"),
        ("Avg Clustering",     f"{avg_clustering:.4f}", "mdi:hexagon-multiple-outline", "#2196F3"),
        ("Risk Concentration", f"Top 10% = {conc_pct}%", "mdi:alert-circle-outline", "#FF1744"),
    ]

    # SCC values kept for internal reference (not displayed in health cards)
    ring_count = 0
    nodes_in_rings = 0
    largest_ring = 0
    try:
        _scc = getattr(getattr(pipeline, "graph", None), "scc_summary", None) or {}
        if not _scc:
            _scc = getattr(pipeline, "scc_summary", None) or {}
        ring_count = int(_scc.get("ring_count", 0))
        nodes_in_rings = int(_scc.get("nodes_in_rings", 0))
        largest_ring = int(_scc.get("largest_ring", 0))
    except Exception:
        pass

    _sim_edge_count = 0  # tracked internally; not shown in health cards

    cards = []
    for label, value, icon_name, color in metrics:
        try:
            r, g, b = int(color[1:3], 16), int(color[3:5], 16), int(color[5:7], 16)
            bg = f"rgba({r},{g},{b},0.06)"
            bd = f"1px solid rgba({r},{g},{b},0.18)"
        except Exception:
            bg, bd = "rgba(0,0,0,0.2)", f"1px solid {color}20"
        cards.append(
            dmc.Group(
                [
                    DashIconify(icon=icon_name, width=16, color=color),
                    dmc.Stack(
                        [
                            dmc.Text(label, size="10px", c="dimmed"),
                            dmc.Text(value, size="sm", fw=700, c=color),
                        ],
                        gap=0,
                    ),
                ],
                gap="xs",
                style={
                    "padding": "8px 10px",
                    "borderRadius": "6px",
                    "backgroundColor": bg,
                    "border": bd,
                },
            )
        )

    grid = dmc.SimpleGrid(cols={"base": 2, "sm": 3, "md": 6}, spacing="xs", children=cards)
    return dmc.Stack([grid], gap="xs")


def sparkline_fig(values, color="#00D4FF"):
    """Create a tiny sparkline figure for KPI cards (C5)."""
    if not values or len(values) < 2:
        return go.Figure()
    fig = go.Figure(
        go.Scatter(
            y=values,
            mode="lines",
            line=dict(color=color, width=1.5),
            fill="tozeroy",
            fillcolor=f"rgba({','.join(str(int(color.lstrip('#')[i:i+2], 16)) for i in (0,2,4))},0.1)",
        )
    )
    fig.update_layout(
        margin=dict(t=0, b=0, l=0, r=0),
        height=30,
        width=80,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        xaxis=dict(visible=False),
        yaxis=dict(visible=False),
        showlegend=False,
    )
    fig.update_xaxes(fixedrange=True)
    fig.update_yaxes(fixedrange=True)
    return fig


# =============================================================================
# LAYOUT — v12.45: function layout ensures fresh Interval on every page visit
# =============================================================================
def layout():
    return dmc.Box(
        [
            # Intervals for live updates
            dcc.Interval(id="dash-init", interval=1000, max_intervals=1),
            dcc.Interval(
                id="progress-poll", interval=500, max_intervals=0, disabled=True
            ),  # v15.12: 800→500ms
            # Header
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            dmc.Stack(
                                [
                                    dmc.Group(
                                        [
                                            DashIconify(
                                                icon="mdi:shield-lock", width=28, color="#00D4FF"
                                            ),
                                            dmc.Title("FCDAI Network Analyzer", order=2, c="white"),
                                        ],
                                        gap="sm",
                                    ),
                                    dmc.Text(
                                        "Financial Crime Detection AI — Pipeline Control Center",
                                        c="dimmed",
                                        size="sm",
                                    ),
                                ],
                                gap=2,
                            ),
                            dmc.Group(
                                [
        
                                    dmc.Badge(
                                        id="dash-run-version",
                                        color="grape",
                                        variant="light",
                                        size="sm",
                                    ),
                                    dmc.Badge(
                                        "AIR-GAPPED",
                                        color="green",
                                        variant="dot",
                                        size="sm",
                                        leftSection=DashIconify(icon="mdi:lock", width=12),
                                    ),
                                    dmc.Badge(
                                        "BANK AML",
                                        color="indigo",
                                        variant="light",
                                        size="sm",
                                        leftSection=DashIconify(icon="mdi:bank", width=12),
                                    ),
                                ],
                                gap="sm",
                            ),
                        ],
                        justify="space-between",
                    ),
                ],
                p="md",
                radius="lg",
                mb="lg",
                style={
                    "background": "linear-gradient(135deg, rgba(0,212,255,0.06) 0%, rgba(157,78,221,0.04) 50%, rgba(10,14,23,0.95) 100%)",
                    "border": "1px solid rgba(0,212,255,0.15)",
                },
            ),
            # ━━━ CEO EXECUTIVE BRIEF ━━━
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            DashIconify(icon="mdi:briefcase-outline", width=22, color="#00D4FF"),
                            dmc.Stack(
                                [
                                    dmc.Text(
                                        "How to Use This Application", fw=700, c="white", size="sm"
                                    ),
                                    dmc.Text(
                                        "This is your command centre for the Financial Crime Detection AI system. "
                                        "Use the Quick Navigation grid to jump to any analysis page. "
                                        "Press ▶ Start to run the detection pipeline — it will analyse all customers, "
                                        "score each one for financial crime risk (0–100), and populate every analysis page with live results. "
                                        "The Algorithm Run Summary shows you which of the 10 detection engines ran and what they found. "
                                        "Risk Scoring Weights let you tune how much each engine contributes to the final score.",
                                        size="xs",
                                        c="dimmed",
                                        style={"lineHeight": "1.6"},
                                    ),
                                ],
                                gap=4,
                            ),
                        ],
                        gap="md",
                        align="flex-start",
                    ),
                    dmc.Group(
                        [
                            dmc.Badge(
                                "Step 1: Load data on Port Authority",
                                color="cyan",
                                variant="light",
                                size="xs",
                            ),
                            dmc.Badge(
                                "Step 2: Click ▶ Start to run the AI pipeline",
                                color="green",
                                variant="light",
                                size="xs",
                            ),
                            dmc.Badge(
                                "Step 3: Navigate to any page to see results",
                                color="grape",
                                variant="light",
                                size="xs",
                            ),
                        ],
                        gap="xs",
                        mt="sm",
                    ),
                ],
                p="md",
                radius="md",
                mb="md",
                style={
                    "background": "linear-gradient(135deg, rgba(0,212,255,0.04) 0%, rgba(10,14,23,0.95) 100%)",
                    "border": "1px solid rgba(0,212,255,0.12)",
                },
            ),
            # =================== PIPELINE PROGRESS BAR ===================
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            DashIconify(icon="mdi:rocket-launch", width=22, color=THEME.PRIMARY),
                            dmc.Text("Pipeline Progress", fw=700, c="white", size="md"),
                            dmc.Badge(
                                id="progress-status-badge", color="gray", variant="light", size="sm"
                            ),
                        ],
                        gap="sm",
                        mb=4,
                    ),
                    dmc.Text(
                        "Shows the live progress of the 10-stage risk analysis pipeline. "
                        "Each stage represents one detection engine running against your customer data. "
                        "When all stages reach 100%, results are ready on all analysis pages.",
                        size="xs",
                        c="dimmed",
                        mb="sm",
                        fs="italic",
                    ),
                    dmc.Progress(
                        id="pipeline-progress-bar",
                        value=0,
                        size="lg",
                        color="cyan",
                        radius="md",
                        striped=True,
                        animated=True,
                        style={"marginBottom": "8px"},
                    ),
                    dmc.Text(id="progress-message", size="xs", c="dimmed", mb="xs"),
                    dmc.SimpleGrid(
                        cols={"base": 3, "md": 6}, spacing="xs", id="stage-indicators", children=[]
                    ),
                ],
                p="lg",
                radius="lg",
                className="glass-card",
                mb="md",
            ),
            # =================== CONTROLS ROW (v12.10: 2-col) ===================
            dmc.SimpleGrid(
                cols={"base": 1, "md": 2},
                spacing="md",
                mb="md",
                children=[
                    # Pipeline Controls
                    dmc.Paper(
                        [
                            dmc.Group(
                                [
                                    DashIconify(
                                        icon="mdi:play-circle", width=20, color=THEME.SUCCESS
                                    ),
                                    dmc.Text("Pipeline Controls", fw=600, c="white", size="sm"),
                                ],
                                gap="sm",
                                mb="md",
                            ),
                            # v15.4 Task1: Max Customers in Auto mode — placeholder="Auto",
                            # default = PA node count. User can edit; empty box = auto (PA max).
                            dmc.NumberInput(
                                id="dash-max-customers",
                                label="Max Customers",
                                value=None,
                                min=1,
                                max=50000,
                                step=5,
                                placeholder="Auto",
                                styles={
                                    "input": {
                                        "backgroundColor": THEME.DARK_BG,
                                        "color": "white",
                                        "border": f"1px solid {THEME.DARK_BORDER}",
                                    },
                                    "label": {"color": "#adb5bd", "fontSize": "12px"},
                                },
                                mb=2,
                            ),
                            # Live hint updates when PA data is pushed
                            html.Div(
                                id="dash-max-cust-hint",
                                style={"marginBottom": "8px"},
                                children=dmc.Text(
                                    "Auto — fill with max nodes from Port Authority",
                                    size="xs",
                                    c="dimmed",
                                    fs="italic",
                                ),
                            ),
                            dmc.Group(
                                [
                                    dmc.Button(
                                        "▶ Start",
                                        id="dash-run-btn",
                                        color="cyan",
                                        variant="gradient",
                                        gradient={"from": "cyan", "to": "indigo"},
                                        leftSection=DashIconify(icon="mdi:play", width=18),
                                        style={"flex": 1},
                                    ),
                                    dmc.Button(
                                        "⟳ Resume",
                                        id="dash-resume-btn",
                                        color="teal",
                                        variant="outline",
                                        leftSection=DashIconify(icon="mdi:restart", width=18),
                                    ),
                                    dmc.Button(
                                        "■",
                                        id="dash-stop-btn",
                                        color="red",
                                        variant="outline",
                                        leftSection=DashIconify(icon="mdi:stop", width=18),
                                    ),
                                ],
                                gap="sm",
                                grow=True,
                            ),
                            dcc.Link(
                                dmc.Button(
                                    "📦 Port Authority",
                                    id="dash-gen-sample-btn",
                                    color="teal",
                                    variant="light",
                                    fullWidth=True,
                                    mt="sm",
                                    leftSection=DashIconify(icon="mdi:database-plus", width=18),
                                ),
                                href="/port-authority",
                                style={"textDecoration": "none"},
                            ),
                            dmc.Text(
                                id="dash-gen-sample-status",
                                size="xs",
                                c="dimmed",
                                mt="xs",
                                children="Prepare data on Port Authority → Push → Run here",
                            ),
                            dmc.Button(
                                "🗑️ Reset All Data",
                                id="dash-reset-btn",
                                color="red",
                                variant="light",
                                fullWidth=True,
                                mt="xs",
                                leftSection=DashIconify(icon="mdi:delete-sweep", width=18),
                            ),
                            dmc.Text(id="dash-reset-status", size="xs", c="dimmed", mt="xs"),
                            dmc.Text(id="dash-last-run", size="xs", c="dimmed", mt="sm"),
                            # ── v12.43: Full Report Download ──────────────────────────────────
                            dmc.Divider(my="sm", style={"borderColor": "rgba(255,255,255,0.06)"}),
                            dmc.Button(
                                "📥 Download Full Report",
                                id="dash-download-btn",
                                color="indigo",
                                variant="light",
                                fullWidth=True,
                                leftSection=DashIconify(icon="mdi:microsoft-excel", width=18),
                            ),
                            dmc.Text(
                                id="dash-download-status",
                                size="xs",
                                c="dimmed",
                                mt="xs",
                                children="All scores · risk tiers · analytics metrics · Excel",
                            ),
                            dcc.Download(id="dash-download-excel"),
                            # ── v15.2 Task4: PA Push Summary ──────────────────────────────────
                            dmc.Divider(my="sm", style={"borderColor": "rgba(255,255,255,0.06)"}),
                            html.Div(
                                id="dash-pa-source-summary",
                                children=dmc.Text(
                                    "No data pushed from Port Authority yet.",
                                    size="xs",
                                    c="dimmed",
                                    fs="italic",
                                ),
                            ),
                        ],
                        p="lg",
                        radius="lg",
                        className="glass-card",
                    ),
                    # Data Readiness — v12.43: Enhanced with business context
                    dmc.Paper(
                        [
                            dmc.Group(
                                [
                                    DashIconify(
                                        icon="mdi:database-check", width=20, color=THEME.INFO
                                    ),
                                    dmc.Text(
                                        "Data Readiness Assessment", fw=600, c="white", size="sm"
                                    ),
                                    dmc.Badge(
                                        id="dash-table-count-badge",
                                        size="xs",
                                        variant="dot",
                                        color="green",
                                        children=f"{len(READINESS_TABLE_ORDER)} tables expected",
                                    ),
                                ],
                                gap="sm",
                                mb=4,
                            ),
                            # v12.43: Previous-run indicator banner
                            html.Div(id="dash-persistence-banner"),
                            dmc.Text(
                                "Transaction Network: entities and financial links for relationship analysis. "
                                "Business Intelligence: customer profiles, compliance records, and investigation history. "
                                "Green = data loaded and ready. Grey = awaiting pipeline run.",
                                size="xs",
                                c="dimmed",
                                mb="sm",
                                fs="italic",
                            ),
                            html.Div(
                                id="dash-data-readiness",
                                children=_build_readiness_grouped_content({}),
                            ),
                        ],
                        p="lg",
                        radius="lg",
                        className="glass-card",
                        style={"border": "1px solid rgba(0,212,255,0.08)"},
                    ),
                ],
            ),
            # =================== KPI ROW with sparklines (C5) ===================
            dmc.SimpleGrid(
                cols={"base": 2, "md": 5}, spacing="md", mb="md", id="dash-kpi-row", children=[]
            ),
            # =================== RISK INTELLIGENCE SUMMARY — v12.43 ===================
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            DashIconify(icon="mdi:chart-donut-variant", width=22, color="#FF1744"),
                            dmc.Text(
                                "Risk Intelligence — Portfolio Overview",
                                fw=700,
                                c="white",
                                size="md",
                            ),
                            dmc.Badge("4 Tiers", color="red", variant="light", size="sm"),
                            dmc.Badge(
                                "P1 Critical → P4 Low", color="gray", variant="outline", size="xs"
                            ),
                        ],
                        gap="sm",
                        mb=4,
                    ),
                    dmc.Text(
                        "Shows how the entire customer portfolio is distributed across four AML risk tiers. "
                        "P1 Critical (score 80–100) requires immediate Narrative filing or investigation. "
                        "P2 High (60–80) requires enhanced due diligence. "
                        "P3 Medium (40–60) is under routine monitoring. P4 Low (0–40) is standard processing.",
                        size="xs",
                        c="dimmed",
                        mb="sm",
                        fs="italic",
                    ),
                    html.Div(
                        id="dash-risk-tier-summary",
                        children=[
                            dmc.Center(
                                dmc.Text(
                                    "Run pipeline to see risk portfolio breakdown",
                                    c="dimmed",
                                    size="sm",
                                ),
                                style={"minHeight": "80px"},
                            ),
                        ],
                    ),
                ],
                p="lg",
                radius="lg",
                className="glass-card",
                mb="md",
                style={"border": "1px solid rgba(255,23,68,0.08)"},
            ),
            # =================== INTELLIGENCE GRID: Top Flagged + Network Health — v16.29 (T2: stacked rows) ===================
            # v16.29 T2: Both panels get their own full-width row so each is fully visible
            # Row 1: Top Flagged Customers
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            DashIconify(
                                icon="mdi:account-alert", width=20, color="#FF9800"
                            ),
                            dmc.Text("Top Flagged Customers", fw=600, c="white", size="sm"),
                            dmc.Badge("Top 10 | Paged", color="orange", variant="light", size="xs"),
                            dmc.Badge(
                                "Live | PII-Safe", color="teal", variant="dot", size="xs"
                            ),
                        ],
                        gap="sm",
                        mb=4,
                    ),
                    dmc.Text(
                        "The top-risk customers this run, ranked by composite crime risk score. "
                        "Shows 10 per page — use the page controls below the table to view more. "
                        "Customer IDs are masked for PII compliance. "
                        "P1 Critical customers require immediate case escalation under AML obligations.",
                        size="xs",
                        c="dimmed",
                        mb="sm",
                        fs="italic",
                    ),
                    html.Div(
                        id="dash-top-risks-table",
                        children=[
                            dmc.Center(
                                dmc.Text(
                                    "Run pipeline to see top flagged customers",
                                    c="dimmed",
                                    size="sm",
                                ),
                                style={"minHeight": "80px"},
                            ),
                        ],
                    ),
                ],
                p="lg",
                radius="lg",
                className="glass-card",
                mb="md",
            ),
            # Row 2: Network Health Monitor
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            DashIconify(icon="mdi:pulse", width=20, color="#00E676"),
                            dmc.Text(
                                "Network Health Monitor", fw=600, c="white", size="sm"
                            ),
                            dmc.Badge(
                                "Graph Metrics", color="green", variant="light", size="xs"
                            ),
                            dmc.Badge(
                                "16 AML Signals", color="cyan", variant="dot", size="xs"
                            ),
                        ],
                        gap="sm",
                        mb=4,
                    ),
                    dmc.Text(
                        "Structural metrics of the AML transaction graph. "
                        "Graph Components = 1 is NORMAL (all accounts are connected via transaction chains). "
                        "Communities shows Louvain-detected sub-clusters. "
                        "Circular Rings = SCC-confirmed money loops requiring immediate review.",
                        size="xs",
                        c="dimmed",
                        mb="sm",
                        fs="italic",
                    ),
                    html.Div(
                        id="dash-network-health",
                        children=[
                            dmc.Center(
                                dmc.Text(
                                    "Run pipeline to see network health metrics",
                                    c="dimmed",
                                    size="sm",
                                ),
                                style={"minHeight": "80px"},
                            ),
                        ],
                    ),
                ],
                p="lg",
                radius="lg",
                className="glass-card",
                mb="md",
            ),
            # =================== ALGORITHM RUN SUMMARY — v12.33: moved above Risk Weights (TASK 4) ===================
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            DashIconify(icon="mdi:brain", width=22, color="#9D4EDD"),
                            dmc.Text("Algorithm Run Summary", fw=700, c="white", size="md"),
                            dmc.Badge("10 Families", color="grape", variant="light", size="sm"),
                        ],
                        gap="sm",
                        mb=4,
                    ),
                    dmc.Text(
                        "After each pipeline run, this panel shows you the status of all 10 detection algorithms "
                        "(e.g. Network Influence, Cluster Engine, Velocity Analyzer). "
                        "Tick marks (✓) mean the engine ran successfully. You can see how many customers each engine flagged. "
                        "This helps management understand which detection technique found the most risk.",
                        size="xs",
                        c="dimmed",
                        mb="sm",
                        fs="italic",
                    ),
                    html.Div(
                        id="dash-algo-summary",
                        children=[
                            dmc.Center(
                                dmc.Text(
                                    "Run pipeline to see algorithm performance",
                                    c="dimmed",
                                    size="sm",
                                ),
                                style={"minHeight": "100px"},
                            ),
                        ],
                    ),
                ],
                p="lg",
                radius="lg",
                className="glass-card",
                mb="md",
            ),
            # =================== RISK WEIGHTS — v10: 10 families ===================
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            DashIconify(icon="mdi:tune-vertical", width=20, color=THEME.SECONDARY),
                            dmc.Text("Risk Scoring Weights", fw=600, c="white", size="sm"),
                            dmc.Badge("10 Families", color="grape", variant="light", size="xs"),
                        ],
                        gap="sm",
                        mb=4,
                    ),
                    dmc.Text(
                        "These sliders control how much each detection algorithm contributes to the final Risk Score (0–100). "
                        "A higher slider value means that algorithm has more influence on the score. "
                        "Total does not need to sum to 1 — the system normalises automatically. "
                        "Adjust only if a specific detection type is more relevant for your customer portfolio.",
                        size="xs",
                        c="dimmed",
                        mb="sm",
                        fs="italic",
                    ),
                    dmc.SimpleGrid(
                        cols={"base": 1, "md": 5},
                        spacing="md",
                        children=[
                            dmc.Stack(
                                [
                                    dmc.Text(name, size="xs", fw=600, c="white"),
                                    dmc.Text(desc, size="9px", c="dimmed", fs="italic",
                                             style={"lineHeight": "1.3", "marginBottom": "2px"}),
                                    dmc.Slider(
                                        id=f"w-{key}",
                                        value=val,
                                        min=0,
                                        max=1,
                                        step=0.05,
                                        marks=[{"value": 0}, {"value": 0.5}, {"value": 1}],
                                        color=col,
                                        size="sm",
                                        styles={"markLabel": {"color": "#64748B"}},
                                    ),
                                ],
                                gap=2,
                            )
                            for key, name, val, col, desc in [
                                ("centrality",    "Relationship Influence",        0.15, "cyan",    "Identifies customers acting as high-volume hubs or brokers in the transaction network."),
                                ("community",     "Risk Group Identification",     0.10, "grape",   "Detects clusters of accounts transacting predominantly with each other — potential criminal rings."),
                                ("pathflow",      "Money Flow Tracing",            0.10, "red",     "Traces suspicious fund movement paths through multiple intermediaries — layering signals."),
                                ("link_pred",     "Hidden Relationship Discovery", 0.10, "yellow",  "Predicts undisclosed financial relationships between customers from network neighbourhood."),
                                ("anomaly",       "Behavioural Anomaly Detection", 0.15, "orange",  "Flags statistically abnormal transaction behaviour relative to peer group norms."),
                                ("temporal",      "Time-Pattern Risk Analysis",    0.10, "green",   "Detects unusual timing: velocity spikes, after-hours bursts or structured timing sequences."),
                                ("multi_layer",   "Cross-Entity Risk Assessment",  0.10, "blue",    "Captures risk spanning both the financial transaction layer and corporate ownership layer."),
                                ("structuring",   "Structuring / Smurfing",        0.10, "#FF1744", "Identifies repeated sub-threshold transactions designed to avoid currency reporting rules."),
                                ("benfords",      "Benford’s Law Analysis",         0.05, "#E040FB", "Detects digit-frequency irregularities in transaction amounts — signals fabricated figures."),
                                ("motifs",        "Transaction Pattern Matching",  0.05, "#00BCD4", "Recognises known AML typologies: fan-in/fan-out, cyclic triangles, and relay chains."),
                            ]
                        ],
                    ),
                ],
                p="lg",
                radius="lg",
                className="glass-card",
                mb="md",
            ),
            # =================== RISK ANALYSIS TABLE SUITE (v16.53) ===================
            # Populated by cb_risk_tables callback below; refreshes on every pipeline run.
            html.Div(id="dash-risk-tables-section"),
            # =================== NAVIGATION GRID — v10: 21 pages (moved below Score by Family) ===================
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            DashIconify(icon="mdi:apps", width=20, color=THEME.INFO),
                            dmc.Text("Quick Navigation", fw=600, c="white", size="sm"),
                            dmc.Badge("22 Pages", color="indigo", variant="light", size="xs"),
                        ],
                        gap="sm",
                        mb="md",
                    ),
                    dmc.SimpleGrid(
                        cols={"base": 2, "md": 4, "xl": 7},
                        spacing="sm",
                        children=[
                            dcc.Link(
                                dmc.Paper(
                                    [
                                        dmc.Group(
                                            [
                                                DashIconify(icon=icon, width=20, color=color),
                                                dmc.Text(name, size="xs", fw=500, c="white"),
                                            ],
                                            gap="xs",
                                        ),
                                    ],
                                    p="sm",
                                    radius="md",
                                    className="nav-card",
                                    style={
                                        "backgroundColor": "rgba(0,0,0,0.3)",
                                        "border": f"1px solid {color}20",
                                        "cursor": "pointer",
                                    },
                                ),
                                href=href,
                                style={"textDecoration": "none"},
                            )
                            for icon, name, href, color in [
                                (
                                    "mdi:database-import",
                                    "Port Authority",
                                    "/port-authority",
                                    "#00D4FF",
                                ),
                                ("mdi:radar", "Radar", "/radar", "#00E676"),
                                ("mdi:chart-box", "Visualization", "/visualization", "#E040FB"),
                                ("mdi:safe-square", "Vault", "/vault", "#9D4EDD"),
                                (
                                    "mdi:shield-alert",
                                    "Command Center",
                                    "/command-center",
                                    "#FF1744",
                                ),
                                ("mdi:graph", "Network Intel", "/network-intelligence", "#00D4FF"),
                                (
                                    "mdi:account-group",
                                    "Lobby Analysis",
                                    "/lobby-analysis",
                                    "#FF6B6B",
                                ),
                                # v10: New pages
                                ("mdi:earth", "Geo-Risk", "/geo-risk", "#FF6B6B"),
                                ("mdi:account-details", "Customer 360", "/customer-360", "#00E5FF"),
                                (
                                    "mdi:compare-horizontal",
                                    "Comparative Runs",
                                    "/comparative-runs",
                                    "#9D4EDD",
                                ),
                                ("mdi:shield-lock", "Audit Trail", "/audit-trail", "#FFD600"),
                                # Analytics
                                (
                                    "mdi:star-four-points",
                                    "Influence",
                                    "/analytics/centrality",
                                    "#00D4FF",
                                ),
                                (
                                    "mdi:account-group",
                                    "Risk Groups",
                                    "/analytics/community",
                                    "#9D4EDD",
                                ),
                                (
                                    "mdi:transit-connection",
                                    "Money Flow",
                                    "/analytics/pathflow",
                                    "#FF6B6B",
                                ),
                                (
                                    "mdi:link-variant",
                                    "Hidden Links",
                                    "/analytics/link-prediction",
                                    "#FFD600",
                                ),
                                ("mdi:alert-decagram", "Anomaly", "/analytics/anomaly", "#FF9800"),
                                (
                                    "mdi:clock-fast",
                                    "Time-Patterns",
                                    "/analytics/temporal",
                                    "#00E676",
                                ),
                                (
                                    "mdi:layers-triple",
                                    "Cross-Entity",
                                    "/analytics/multi-layer",
                                    "#2196F3",
                                ),
                                # Data
                                ("mdi:history", "Pipeline Runs", "/pipeline-runs", "#26C6DA"),
                                ("mdi:database-search", "Database", "/database", "#AB47BC"),
                                # v16.32: Data Quality Observatory
                                ("mdi:shield-check", "Data Quality", "/data-quality", "#00E676"),
                            ]
                        ],
                    ),
                ],
                p="lg",
                radius="lg",
                className="glass-card",
                mb="md",
            ),
            # =================== STAGE RESULTS TABLE (v16.65: moved above Performance Settings) ===================
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            DashIconify(icon="mdi:table-check", width=20, color="#26C6DA"),
                            dmc.Text("Stage Results", fw=600, c="white", size="sm"),
                        ],
                        gap="sm",
                        mb=4,
                    ),
                    dmc.Text(
                        "A table summarising the output of each pipeline stage after a run. "
                        "Each row is one detection engine — you can see the result count, execution time, "
                        "and status. Useful for auditors and technical staff to verify all engines completed successfully.",
                        size="xs",
                        c="dimmed",
                        mb="sm",
                        fs="italic",
                    ),
                    html.Div(id="stage-results-table"),
                ],
                p="lg",
                radius="lg",
                className="glass-card",
                mb="md",
            ),
            # =================== PIPELINE SCORING CONFIGURATION (v16.66: moved below Stage Results) ===================
            dmc.Accordion(
                [
                    dmc.AccordionItem(
                        [
                            dmc.AccordionControl(
                                dmc.Group(
                                    [
                                        DashIconify(icon="mdi:tune-variant", width=20, color="#00E676"),
                                        dmc.Text(
                                            "Pipeline Scoring Configuration", fw=600, c="white", size="sm"
                                        ),
                                        dmc.Badge("Advanced", color="teal", variant="dot", size="xs"),
                                        dmc.Badge("Click to expand", color="gray", variant="outline", size="xs"),
                                    ],
                                    gap="sm",
                                ),
                            ),
                            dmc.AccordionPanel(
                                dmc.Stack(
                                    [
                                    dmc.Text(
                                        "Normalization controls how each detection family's features are scaled to [0–1] before fusion. "
                                        "Tier Classification controls how the final composite score maps to investigation priority (P1–P4). "
                                        "Both settings take effect on the next pipeline run — no restart required.",
                                        size="xs",
                                        c="dimmed",
                                        fs="italic",
                                    ),
                    dmc.SimpleGrid(
                        cols={"base": 1, "md": 2},
                        spacing="xl",
                        children=[
                            # ═══ Left: Normalization ═══
                            dmc.Stack(
                                [
                                    dmc.Group(
                                        [
                                            DashIconify(
                                                icon="mdi:function-variant",
                                                width=16,
                                                color="#00E676",
                                            ),
                                            dmc.Text(
                                                "Normalization Method", size="sm", fw=600, c="white"
                                            ),
                                        ],
                                        gap="xs",
                                    ),
                                    dmc.Text(
                                        "How raw feature values within each detection family are scaled to [0,1]. "
                                        "Applied at BOTH intra-family and cross-family (F1) levels for consistent treatment.",
                                        size="xs",
                                        c="dimmed",
                                    ),
                                    dmc.Select(
                                        id="norm-method-dd",
                                        data=[
                                            {
                                                "value": "rank",
                                                "label": "Rank (Recommended) — Outlier-agnostic, run-stable",
                                            },
                                            {
                                                "value": "minmax",
                                                "label": "Min-Max — Preserves magnitudes (outlier-sensitive)",
                                            },
                                            {
                                                "value": "zscore",
                                                "label": "Z-Score — Normal dist. assumption (±3σ window)",
                                            },
                                            {
                                                "value": "robust",
                                                "label": "Robust (Median/IQR) — Best for skewed AML data",
                                            },
                                        ],
                                        value="rank",
                                        allowDeselect=False,
                                        styles={
                                            "input": {
                                                "backgroundColor": THEME.DARK_BG,
                                                "color": "white",
                                                "border": f"1px solid {THEME.DARK_BORDER}",
                                            },
                                            "dropdown": {"backgroundColor": THEME.DARK_BG_CARD},
                                        },
                                    ),
                                    html.Div(
                                        id="norm-method-hint",
                                        children=dmc.Text(
                                            "Rank: (rank−1)/(n−1) — immune to single-outlier nodes, stable across run sizes.",
                                            size="10px",
                                            c="dimmed",
                                            fs="italic",
                                        ),
                                    ),
                                ],
                                gap="xs",
                            ),
                            # ═══ Right: Tier Classification ═══
                            dmc.Stack(
                                [
                                    dmc.Group(
                                        [
                                            DashIconify(
                                                icon="mdi:podium-gold", width=16, color="#FFD600"
                                            ),
                                            dmc.Text(
                                                "Tier Classification Mode",
                                                size="sm",
                                                fw=600,
                                                c="white",
                                            ),
                                        ],
                                        gap="xs",
                                    ),
                                    dmc.Text(
                                        "How final risk scores map to investigation priorities (P1–P4). "
                                        "Percentile adapts to any dataset size and capacity-caps P1. "
                                        "Absolute uses fixed score thresholds for regulatory cutpoints.",
                                        size="xs",
                                        c="dimmed",
                                    ),
                                    dmc.Select(
                                        id="tier-mode-dd",
                                        data=[
                                            {
                                                "value": "percentile",
                                                "label": "Percentile (Recommended) — Top X% = P1",
                                            },
                                            {
                                                "value": "absolute",
                                                "label": "Absolute Score Thresholds — Score ≥ T = P1",
                                            },
                                        ],
                                        value="percentile",
                                        allowDeselect=False,
                                        styles={
                                            "input": {
                                                "backgroundColor": THEME.DARK_BG,
                                                "color": "white",
                                                "border": f"1px solid {THEME.DARK_BORDER}",
                                            },
                                            "dropdown": {"backgroundColor": THEME.DARK_BG_CARD},
                                        },
                                    ),
                                    dmc.SimpleGrid(
                                        cols=3,
                                        spacing="sm",
                                        mt="xs",
                                        children=[
                                            dmc.Stack(
                                                [
                                                    dmc.Text(
                                                        id="tier-p1-label",
                                                        children="P1 Cutoff (%)",
                                                        size="xs",
                                                        c="#FF1744",
                                                    ),
                                                    dmc.NumberInput(
                                                        id="tier-p1-val",
                                                        value=1.0,
                                                        min=0.1,
                                                        max=100.0,
                                                        step=0.5,
                                                        styles={
                                                            "input": {
                                                                "backgroundColor": THEME.DARK_BG,
                                                                "color": "white",
                                                                "border": "1px solid rgba(255,23,68,0.3)",
                                                            }
                                                        },
                                                    ),
                                                ],
                                                gap=2,
                                            ),
                                            dmc.Stack(
                                                [
                                                    dmc.Text(
                                                        id="tier-p2-label",
                                                        children="P2 Cutoff (%)",
                                                        size="xs",
                                                        c="#FF9800",
                                                    ),
                                                    dmc.NumberInput(
                                                        id="tier-p2-val",
                                                        value=5.0,
                                                        min=0.1,
                                                        max=100.0,
                                                        step=0.5,
                                                        styles={
                                                            "input": {
                                                                "backgroundColor": THEME.DARK_BG,
                                                                "color": "white",
                                                                "border": "1px solid rgba(255,152,0,0.3)",
                                                            }
                                                        },
                                                    ),
                                                ],
                                                gap=2,
                                            ),
                                            dmc.Stack(
                                                [
                                                    dmc.Text(
                                                        id="tier-p3-label",
                                                        children="P3 Cutoff (%)",
                                                        size="xs",
                                                        c="#FFD600",
                                                    ),
                                                    dmc.NumberInput(
                                                        id="tier-p3-val",
                                                        value=15.0,
                                                        min=0.1,
                                                        max=100.0,
                                                        step=0.5,
                                                        styles={
                                                            "input": {
                                                                "backgroundColor": THEME.DARK_BG,
                                                                "color": "white",
                                                                "border": "1px solid rgba(255,214,0,0.3)",
                                                            }
                                                        },
                                                    ),
                                                ],
                                                gap=2,
                                            ),
                                        ],
                                    ),
                                    html.Div(
                                        id="tier-mode-hint",
                                        children=dmc.Text(
                                            "Percentile: Top 1% → P1 (Critical), Top 5% → P2 (High), Top 15% → P3 (Watch). "
                                            "Capacity-capped by investigation_capacity (default 1000).",
                                            size="10px",
                                            c="dimmed",
                                            fs="italic",
                                        ),
                                    ),
                                ],
                                gap="xs",
                            ),
                        ],
                    ),
                    ], gap="sm"),
                            ),
                        ],
                        value="scoring-config",
                    ),
                ],
                value=None,
                variant="separated",
                styles={
                    "root": {"marginBottom": "16px"},
                    "item": {
                        "backgroundColor": THEME.DARK_BG_CARD,
                        "borderRadius": "12px",
                        "border": f"1px solid {THEME.DARK_BORDER}",
                    },
                },
            ),
            # =================== ADVANCED SETTINGS (v12.10: moved to bottom) ===================
            dmc.Accordion(
                variant="separated",
                radius="lg",
                mb="md",
                children=[
                    dmc.AccordionItem(
                        value="perf-settings",
                        children=[
                            dmc.AccordionControl(
                                dmc.Group(
                                    [
                                        DashIconify(
                                            icon="mdi:speedometer", width=20, color="#FF9800"
                                        ),
                                        dmc.Text(
                                            "Performance Settings", fw=600, c="white", size="sm"
                                        ),
                                    ],
                                    gap="sm",
                                ),
                            ),
                            dmc.AccordionPanel(
                                [
                                    dmc.SimpleGrid(
                                        cols={"base": 2, "md": 4},
                                        spacing="md",
                                        children=[
                                            dmc.Stack(
                                                [
                                                    dmc.Switch(
                                                        id="perf-parallel",
                                                        label="Parallel Execution",
                                                        checked=True,
                                                        size="sm",
                                                        color="cyan",
                                                    ),
                                                    dmc.Text(
                                                        "Run 10 families simultaneously (3-5x faster)",
                                                        size="xs",
                                                        c="dimmed",
                                                    ),
                                                ],
                                                gap=2,
                                            ),
                                            dmc.Stack(
                                                [
                                                    dmc.Switch(
                                                        id="perf-cache",
                                                        label="Smart Caching",
                                                        checked=True,
                                                        size="sm",
                                                        color="green",
                                                    ),
                                                    dmc.Text(
                                                        "Skip recomputation if graph unchanged (5-10x re-run)",
                                                        size="xs",
                                                        c="dimmed",
                                                    ),
                                                ],
                                                gap=2,
                                            ),
                                            dmc.Stack(
                                                [
                                                    dmc.Switch(
                                                        id="perf-progressive",
                                                        label="Progressive Analytics",
                                                        checked=True,
                                                        size="sm",
                                                        color="grape",
                                                    ),
                                                    dmc.Text(
                                                        "Fast families first, then slow families",
                                                        size="xs",
                                                        c="dimmed",
                                                    ),
                                                ],
                                                gap=2,
                                            ),
                                            dmc.Stack(
                                                [
                                                    dmc.Badge(
                                                        "Fast Approximations Active",
                                                        color="cyan",
                                                        variant="filled",
                                                        size="sm",
                                                    ),
                                                    dmc.Text(
                                                        "Optimized algorithms (P3) + Scipy ops (P5)",
                                                        size="xs",
                                                        c="dimmed",
                                                    ),
                                                ],
                                                gap=2,
                                            ),
                                        ],
                                    ),
                                    dmc.Divider(
                                        my="md",
                                        label="Analytics Sampling (P2)",
                                        labelPosition="center",
                                        color="dimmed",
                                    ),
                                    dmc.Stack(
                                        [
                                            dmc.Group(
                                                [
                                                    dmc.Switch(
                                                        id="perf-sampling",
                                                        label="Enable Analytics Sampling",
                                                        checked=False,
                                                        size="sm",
                                                        color="orange",
                                                    ),
                                                    dmc.Text(
                                                        "Only activate when graph exceeds threshold",
                                                        size="xs",
                                                        c="dimmed",
                                                    ),
                                                ],
                                                gap="sm",
                                            ),
                                            dmc.SimpleGrid(
                                                cols={"base": 1, "md": 3},
                                                spacing="md",
                                                children=[
                                                    dmc.Stack(
                                                        [
                                                            dmc.Text(
                                                                "Sampling Threshold (nodes)",
                                                                size="xs",
                                                                c="dimmed",
                                                            ),
                                                            dmc.NumberInput(
                                                                id="perf-sample-threshold",
                                                                value=5000,
                                                                min=1000,
                                                                max=100000,
                                                                step=500,
                                                                styles={
                                                                    "input": {
                                                                        "backgroundColor": THEME.DARK_BG,
                                                                        "color": "white",
                                                                        "width": "100%",
                                                                        "border": f"1px solid {THEME.DARK_BORDER}",
                                                                    }
                                                                },
                                                            ),
                                                        ],
                                                        gap=4,
                                                    ),
                                                    dmc.Stack(
                                                        [
                                                            dmc.Text(
                                                                "Sample Size (top N nodes)",
                                                                size="xs",
                                                                c="dimmed",
                                                            ),
                                                            dmc.NumberInput(
                                                                id="perf-sample-size",
                                                                value=5000,
                                                                min=500,
                                                                max=100000,
                                                                step=500,
                                                                styles={
                                                                    "input": {
                                                                        "backgroundColor": THEME.DARK_BG,
                                                                        "color": "white",
                                                                        "width": "100%",
                                                                        "border": f"1px solid {THEME.DARK_BORDER}",
                                                                    }
                                                                },
                                                            ),
                                                        ],
                                                        gap=4,
                                                    ),
                                                    dmc.Stack(
                                                        [
                                                            dmc.Text(
                                                                "Quick Presets",
                                                                size="xs",
                                                                c="dimmed",
                                                            ),
                                                            dmc.SegmentedControl(
                                                                id="perf-sample-preset",
                                                                data=[
                                                                    {
                                                                        "value": "3000",
                                                                        "label": "3K",
                                                                    },
                                                                    {
                                                                        "value": "5000",
                                                                        "label": "5K",
                                                                    },
                                                                    {
                                                                        "value": "7000",
                                                                        "label": "7K",
                                                                    },
                                                                    {
                                                                        "value": "10000",
                                                                        "label": "10K",
                                                                    },
                                                                ],
                                                                value="5000",
                                                                size="xs",
                                                                color="orange",
                                                            ),
                                                        ],
                                                        gap=4,
                                                    ),
                                                ],
                                            ),
                                        ],
                                        gap="sm",
                                    ),
                                ]
                            ),
                        ],
                    ),
                    dmc.AccordionItem(
                        value="config-editor",
                        children=[
                            dmc.AccordionControl(
                                dmc.Group(
                                    [
                                        DashIconify(
                                            icon="mdi:cog-outline", width=20, color="#FFD600"
                                        ),
                                        dmc.Text("Config Editor", fw=600, c="white", size="sm"),
                                    ],
                                    gap="sm",
                                ),
                            ),
                            dmc.AccordionPanel(
                                [
                                    dmc.Text(
                                        "pipeline_config.json", size="xs", c="dimmed", mb="xs"
                                    ),
                                    dmc.Textarea(
                                        id="config-file-content",
                                        minRows=6,
                                        maxRows=10,
                                        placeholder='{"max_customers": 500, "scoring_weights": {...}}',
                                        styles={
                                            "input": {
                                                "backgroundColor": THEME.DARK_BG,
                                                "color": "#00D4FF",
                                                "fontFamily": "monospace",
                                                "fontSize": "11px",
                                                "border": f"1px solid {THEME.DARK_BORDER}",
                                            }
                                        },
                                    ),
                                    dmc.Group(
                                        [
                                            dmc.Button(
                                                "Load",
                                                id="config-load-btn",
                                                size="xs",
                                                variant="light",
                                                color="yellow",
                                            ),
                                            dmc.Button(
                                                "Save",
                                                id="config-save-btn",
                                                size="xs",
                                                variant="filled",
                                                color="yellow",
                                            ),
                                        ],
                                        gap="xs",
                                        mt="xs",
                                    ),
                                    dmc.Text(id="config-status", size="xs", c="dimmed", mt="xs"),
                                ]
                            ),
                        ],
                    ),
                ],
            ),
        ]
    )


# =============================================================================
# CALLBACKS
# =============================================================================

# v12.43: 10-family map — business-friendly labels for executive audience
FAMILY_MAP = {
    "centrality": ("Relationship Influence", "mdi:hub-outline", "#00D4FF"),
    "community": ("Risk Group Identification", "mdi:graph", "#9D4EDD"),
    "pathflow": ("Money Flow Tracing", "mdi:routes", "#00E676"),
    "link_prediction": ("Hidden Relationship Discovery", "mdi:link-variant", "#FFD600"),
    "anomaly": ("Behavioural Anomaly Detection", "mdi:alert-decagram", "#FF1744"),
    "temporal": ("Time-Pattern Risk Analysis", "mdi:clock-fast", "#FF9800"),
    "multi_layer": ("Cross-Entity Risk Assessment", "mdi:layers-triple", "#2196F3"),
    "structuring": ("Structuring / Smurfing", "mdi:cash-multiple", "#FF1744"),
    "benfords": ("Numeric Pattern Compliance", "mdi:chart-bell-curve", "#E040FB"),
    "motifs": ("Transaction Pattern Recognition", "mdi:shape-outline", "#00BCD4"),
}

# v12.43: Track which stages have been progressively sent to avoid redundant updates
_progressive_stages_sent = set()


@callback(
    Output("dash-data-readiness", "children"),
    Output("dash-table-count-badge", "children"),
    Output("dash-kpi-row", "children"),
    Output("dash-last-run", "children"),
    Output("dash-run-version", "children"),
    Output("stage-results-table", "children"),
    Output("config-file-content", "value"),
    Output("dash-algo-summary", "children"),
    Output("dash-risk-tier-summary", "children"),
    Output("dash-top-risks-table", "children"),
    Output("dash-network-health", "children"),
    Output("dash-persistence-banner", "children"),
    Output("dash-max-customers", "value"),  # v12.47 Task 3
    Output("global-refresh-ts", "data", allow_duplicate=True),  # v16.72 F1: broadcast to all pages on load
    Input("dash-init", "n_intervals"),
    Input("pipeline-state", "data"),
    prevent_initial_call="initial_duplicate",  # v16.72: allow_duplicate needs this
)
def init_dashboard(_, pipeline_state):
    pipeline = get_pipeline()
    tables = pipeline.tables

    # v12.26 Task 2: On initial page load (pipeline_state=None / no run this session),
    # show a neutral "ready" state instead of stale previous-run tables.
    # Only display real table data after a NEW pipeline run in this session.
    _session_ran = isinstance(pipeline_state, dict) and pipeline_state.get("success", False)
    # v12.43 PERSISTENCE FIX: Only show empty state when pipeline truly has no
    # data in memory.  If scored_df or any table exists (from the same server
    # session, or carried in the singleton across page navigations), fall
    # through to the full render path so nothing is lost when the user
    # navigates away and back.
    _has_live_data = pipeline.scored_df is not None and len(pipeline.scored_df) > 0
    _has_tables = bool(tables and any(v is not None and len(v) > 0 for v in tables.values()))

    # v15.3 Task2: Auto-fill dash-max-customers from PA push summary (most
    # accurate source after a push). Falls back to staged tables, then meta.
    # v15.3 fix: never use 'or' on DataFrames — use key-check pattern.
    _pa_summary = getattr(pipeline, "_pa_push_summary", None)
    if _pa_summary and _pa_summary.get("n_nodes", 0) > 0:
        _default_max_cust = _pa_summary["n_nodes"]
    else:
        staged = getattr(pipeline, "_staged_tables", None) or {}
        _node_tbl = next(
            (
                staged.get(k)
                for k in ("node", "customer", "account", "node_features")
                if staged.get(k) is not None
            ),
            None,
        )
        if _node_tbl is not None and len(_node_tbl) > 0:
            _default_max_cust = len(_node_tbl)
        else:
            _default_max_cust = int(pipeline.last_run_meta.get("customers", 0) or 0) or 100
    if (
        not _session_ran
        and ctx.triggered_id == "dash-init"
        and not _has_live_data
        and not _has_tables
    ):
        # v12.43: Show grouped placeholder structure on initial load
        readiness = _build_readiness_grouped_content({})
        table_count_text = f"0 / {len(READINESS_TABLE_ORDER)} tables loaded"
        # Fall through for KPIs / last-run label (read from meta — informational only)
        scored = pipeline.get_scored_df()
        meta = pipeline.last_run_meta
        total_ms = (
            sum(r.duration_ms for r in pipeline.stage_results) if pipeline.stage_results else 0
        )
        total_secs = total_ms / 1000
        time_str = f"{total_secs:.1f}s" if total_secs < 60 else f"{total_secs/60:.1f}m"
        history = pipeline.get_run_history()
        spark_customers, spark_nodes, spark_edges, spark_time = [], [], [], []
        if history is not None and len(history) > 0:
            for _, row in history.tail(10).iterrows():
                spark_customers.append(row.get("customers", 0))
                spark_nodes.append(row.get("nodes", 0))
                spark_edges.append(row.get("edges", 0))
                spark_time.append(row.get("duration", 0))
        _ps = pipeline_state if isinstance(pipeline_state, dict) else {}
        _kpi_nodes = (
            pipeline.G.number_of_nodes()
            if pipeline.G
            else max(_ps.get("graph_nodes", 0), meta.get("graph_nodes", 0))
        )
        _kpi_edges = (
            pipeline.G.number_of_edges()
            if pipeline.G
            else max(_ps.get("graph_edges", 0), meta.get("graph_edges", 0))
        )
        kpi_data = [
            (
                "Customers",
                f"{meta.get('customers', 0):,}",
                "mdi:account-multiple",
                THEME.PRIMARY,
                spark_customers,
            ),
            ("Entities", f"{_kpi_nodes:,}", "mdi:graph", THEME.SUCCESS, spark_nodes),
            ("Financial Links", f"{_kpi_edges:,}", "mdi:swap-horizontal", THEME.INFO, spark_edges),
            (
                "Total Time",
                time_str if total_ms > 0 else "—",
                "mdi:timer-outline",
                "#FFD600",
                spark_time,
            ),
            ("Run Version", f"#{pipeline.run_version}", "mdi:counter", "#E040FB", []),
        ]
        kpi_cards = []
        for label, value, icon, color, spark_data in kpi_data:
            card_children = [
                dmc.Group(
                    [
                        DashIconify(icon=icon, width=24, color=color),
                        dmc.Stack(
                            [
                                dmc.Text(label, size="xs", c="dimmed"),
                                dmc.Text(value, size="lg", fw=700, c="white"),
                            ],
                            gap=0,
                        ),
                    ],
                    gap="sm",
                ),
            ]
            if spark_data and len(spark_data) >= 2:
                card_children.append(
                    dcc.Graph(
                        figure=sparkline_fig(spark_data, color),
                        config={"displayModeBar": False, "staticPlot": True},
                        style={"height": "30px", "width": "100%", "marginTop": "4px"},
                    )
                )
            kpi_cards.append(
                dmc.Paper(card_children, p="md", radius="lg", className="stat-card glass-card")
            )
        last_run = f"Last run: {meta.get('saved_at', 'Never')}" if meta else "No previous run"
        rv_text = f"Run #{pipeline.run_version}"
        stage_table = dmc.Text("Run pipeline to see stage results", c="dimmed", size="sm")
        combined_stage = html.Div([stage_table])
        config_content = ""
        try:
            overrides = pipeline.load_config_overrides()
            if overrides:
                config_content = json.dumps(overrides, indent=2)
        except Exception:
            pass
        algo_summary = dmc.Center(
            dmc.Text("Run pipeline to see algorithm performance", c="dimmed", size="sm"),
            style={"minHeight": "100px"},
        )

        # v12.43: Build persistence banner for initial load
        _persistence_banner = html.Div()
        if meta and meta.get("saved_at"):
            run_id = meta.get("run_id", "?")
            saved_at = meta.get("saved_at", "Unknown")
            cust_count = meta.get("customers", 0)
            _persistence_banner = dmc.Alert(
                dmc.Group(
                    [
                        DashIconify(icon="mdi:database-clock", width=20),
                        dmc.Text(
                            f"Showing results from Run #{run_id} — {saved_at} — "
                            f"{cust_count:,} customers analysed. "
                            f"Click 'Run Pipeline' to generate fresh results.",
                            size="xs",
                            c="white",
                        ),
                    ],
                    gap="sm",
                ),
                color="indigo",
                variant="filled",
                radius="md",
                mb="sm",
                style={
                    "backgroundColor": "rgba(63,81,181,0.25)",
                    "border": "1px solid rgba(63,81,181,0.4)",
                },
            )

        return (
            readiness,
            table_count_text,
            kpi_cards,
            last_run,
            rv_text,
            combined_stage,
            config_content,
            algo_summary,
            dmc.Center(
                dmc.Text("Run pipeline to see risk portfolio breakdown", c="dimmed", size="sm"),
                style={"minHeight": "60px"},
            ),
            dmc.Center(
                dmc.Text("Run pipeline to see top flagged customers", c="dimmed", size="sm"),
                style={"minHeight": "60px"},
            ),
            dmc.Center(
                dmc.Text("Run pipeline to see network health metrics", c="dimmed", size="sm"),
                style={"minHeight": "60px"},
            ),
            _persistence_banner,
            None,
            no_update,  # v16.72 F1: no global-refresh on empty-state path
        )  # v15.4: None → show Auto placeholder

    # v12.44: Data Readiness displays ONLY tables that actually participated
    # in the pipeline run (post max-customers filter).  pipeline.tables is
    # the authoritative source — it contains the filtered data the engine
    # actually used.  No secondary "selected_tables" filter needed.
    # FIX: hoist meta assignment here so it is available inside the tables block below
    meta = pipeline.last_run_meta
    if tables and len(tables) > 0:
        non_empty = {k: v for k, v in tables.items() if v is not None and len(v) > 0}
        if non_empty:
            readiness = _build_readiness_grouped_content(non_empty, pipeline)
            _denom = max(len(non_empty), len(READINESS_TABLE_ORDER))
            # v12.44: Show actual record count used in pipeline (post-filter)
            _total_rows = sum(len(v) for v in non_empty.values())
            _max_applied = meta.get("max_customers_applied")
            _filter_note = (
                f" | Max Customers: {_max_applied}" if _max_applied and _max_applied < 50000 else ""
            )
            table_count_text = (
                f"{len(non_empty)} / {_denom} tables loaded"
                f" · {_total_rows:,} records{_filter_note}"
            )
        else:
            readiness = _build_readiness_grouped_content({})
            table_count_text = "0 tables loaded"
    else:
        readiness = _build_readiness_grouped_content({})
        table_count_text = "0 tables loaded"

    # KPIs with sparklines (C5)
    scored = pipeline.get_scored_df()
    meta = pipeline.last_run_meta
    _ps = pipeline_state if isinstance(pipeline_state, dict) else {}
    _sr_fallback = _ps.get("stage_results") or []
    total_ms = (
        sum(r.duration_ms for r in pipeline.stage_results)
        if pipeline.stage_results
        else sum(r.get("duration_ms", 0) for r in _sr_fallback)
    )
    total_secs = total_ms / 1000
    time_str = f"{total_secs:.1f}s" if total_secs < 60 else f"{total_secs/60:.1f}m"

    # Build sparkline data from run history
    history = pipeline.get_run_history()
    spark_customers = []
    spark_nodes = []
    spark_edges = []
    spark_time = []
    if history is not None and len(history) > 0:
        for _, row in history.tail(10).iterrows():
            spark_customers.append(row.get("customers", 0))
            spark_nodes.append(row.get("nodes", 0))
            spark_edges.append(row.get("edges", 0))
            spark_time.append(row.get("duration", 0))

    # v12.17 Task 6: robust graph KPI — prefer live G, then pipeline_state (completion dict), then meta
    _kpi_nodes = (
        pipeline.G.number_of_nodes()
        if pipeline.G
        else max(_ps.get("graph_nodes", 0), meta.get("graph_nodes", 0))
    )
    _kpi_edges = (
        pipeline.G.number_of_edges()
        if pipeline.G
        else max(_ps.get("graph_edges", 0), meta.get("graph_edges", 0))
    )

    kpi_data = [
        (
            "Customers",
            f"{meta.get('customers', 0):,}",
            "mdi:account-multiple",
            THEME.PRIMARY,
            spark_customers,
        ),
        ("Entities", f"{_kpi_nodes:,}", "mdi:graph", THEME.SUCCESS, spark_nodes),
        ("Financial Links", f"{_kpi_edges:,}", "mdi:swap-horizontal", THEME.INFO, spark_edges),
        (
            "Total Time",
            time_str if total_ms > 0 else "—",
            "mdi:timer-outline",
            "#FFD600",
            spark_time,
        ),
        ("Run Version", f"#{pipeline.run_version}", "mdi:counter", "#E040FB", []),
    ]

    kpi_cards = []
    for label, value, icon, color, spark_data in kpi_data:
        card_children = [
            dmc.Group(
                [
                    DashIconify(icon=icon, width=24, color=color),
                    dmc.Stack(
                        [
                            dmc.Text(label, size="xs", c="dimmed"),
                            dmc.Text(value, size="lg", fw=700, c="white"),
                        ],
                        gap=0,
                    ),
                ],
                gap="sm",
            ),
        ]
        # Add sparkline if data available (C5)
        if spark_data and len(spark_data) >= 2:
            card_children.append(
                dcc.Graph(
                    figure=sparkline_fig(spark_data, color),
                    config={"displayModeBar": False, "staticPlot": True},
                    style={"height": "30px", "width": "100%", "marginTop": "4px"},
                )
            )
        kpi_cards.append(
            dmc.Paper(card_children, p="md", radius="lg", className="stat-card glass-card")
        )

    last_run = f"Last run: {meta.get('saved_at', 'Never')}" if meta else "No previous run"
    rv_text = f"Run #{pipeline.run_version}"

    # Stage results table
    # v12.48 Task 1: Use live stage_results OR fall back to serialised data
    # embedded in pipeline_state (which persists across page navigations).
    stage_table = dmc.Text("Run pipeline to see stage results", c="dimmed", size="sm")
    _stage_cols = [
        {"name": "Stage", "id": "stage"},
        {"name": "Name", "id": "name"},
        {"name": "Duration (ms)", "id": "duration_ms"},
        {"name": "Records In", "id": "records_in"},
        {"name": "Records Out", "id": "records_out"},
        {"name": "Status", "id": "status"},
    ]
    _stage_style = dict(
        style_table={"overflowX": "auto"},
        style_header={
            "backgroundColor": "#111827",
            "color": "#94A3B8",
            "fontWeight": "600",
            "border": "1px solid #1E293B",
        },
        style_cell={
            "backgroundColor": "#0A0E17",
            "color": "#E2E8F0",
            "border": "1px solid #1E293B",
            "fontSize": "12px",
            "padding": "8px",
        },
    )
    if pipeline.stage_results:
        stage_table = dash_table.DataTable(
            columns=_stage_cols,
            data=[
                {
                    "stage": r.stage,
                    "name": r.name,
                    "duration_ms": f"{r.duration_ms:.0f}",
                    "records_in": f"{r.records_in:,}",
                    "records_out": f"{r.records_out:,}",
                    "status": "✓" if r.success else "✗",
                }
                for r in pipeline.stage_results
            ],
            **_stage_style,
        )
    elif isinstance(pipeline_state, dict) and pipeline_state.get("stage_results"):
        # Use serialised stage results from the pipeline-state store
        _sr_raw = pipeline_state["stage_results"]
        stage_table = dash_table.DataTable(
            columns=_stage_cols,
            data=[
                {
                    "stage": r.get("stage", ""),
                    "name": r.get("name", ""),
                    "duration_ms": f"{r.get('duration_ms', 0):.0f}",
                    "records_in": f"{r.get('records_in', 0):,}",
                    "records_out": f"{r.get('records_out', 0):,}",
                    "status": "✓" if r.get("success", False) else "✗",
                }
                for r in _sr_raw
            ],
            **_stage_style,
        )

    # Config file
    config_content = ""
    try:
        overrides = pipeline.load_config_overrides()
        if overrides:
            config_content = json.dumps(overrides, indent=2)
    except Exception:
        pass

    # v12.12: Build algo summary from persisted/current analytics on page load
    analytics = pipeline.get_analytics_results()
    if analytics and any(df is not None and len(df) > 0 for df in analytics.values()):
        weights = pipeline.last_run_meta.get(
            "weights",
            {
                "centrality": 0.15,
                "community": 0.10,
                "pathflow": 0.10,
                "link_prediction": 0.10,
                "anomaly": 0.15,
                "temporal": 0.10,
                "multi_layer": 0.10,
                "structuring": 0.10,
                "benfords": 0.05,
                "motifs": 0.05,
            },
        )
        algo_summary = _build_algo_summary(pipeline, weights)
    else:
        algo_summary = dmc.Center(
            dmc.Text("Run pipeline to see algorithm performance", c="dimmed", size="sm"),
            style={"minHeight": "100px"},
        )

    # v16.65: Scoring Model Summary removed — replaced by Table Suite (Tables 1–4).
    # Stage Results table stands alone; no combined wrapper needed.
    combined_stage = stage_table

    # v12.43: Premium intelligence sections
    risk_tier_summary = _build_risk_tier_summary(scored)
    top_risks_table = _build_top_flagged_table(scored)
    network_health = _build_network_health_panel(pipeline)

    # v12.43: Persistence banner — show when showing data from a prior session/run
    if not _session_ran and (_has_live_data or _has_tables):
        run_id = meta.get("run_id", "?")
        saved_at = meta.get("saved_at", "Unknown")
        cust_cnt = meta.get("customers", 0)
        fresh_banner = dmc.Alert(
            dmc.Group(
                [
                    DashIconify(icon="mdi:database-clock", width=20),
                    dmc.Text(
                        f"Showing results from Run #{run_id} — {saved_at} — "
                        f"{cust_cnt:,} customers analysed. "
                        f"Click 'Run Pipeline' to generate fresh results.",
                        size="xs",
                        c="white",
                    ),
                ],
                gap="sm",
            ),
            color="indigo",
            variant="filled",
            radius="md",
            mb="sm",
            style={
                "backgroundColor": "rgba(63,81,181,0.25)",
                "border": "1px solid rgba(63,81,181,0.4)",
            },
        )
    else:
        fresh_banner = html.Div()

    # v16.72 F1: On dash-init with live persisted data → push a new global-refresh-ts
    # so ALL report and analytics pages auto-populate without requiring a pipeline run.
    # When triggered by pipeline-state change, update_progress already handles this.
    _global_refresh_val = (
        int(time.time() * 1000)
        if ctx.triggered_id == "dash-init" and _has_live_data
        else no_update
    )

    return (
        readiness,
        table_count_text,
        kpi_cards,
        last_run,
        rv_text,
        combined_stage,
        config_content,
        algo_summary,
        risk_tier_summary,
        top_risks_table,
        network_health,
        fresh_banner,
        None,
        _global_refresh_val,  # v16.72 F1: broadcast refresh to all pages on startup
    )  # v15.4: None → Auto


# =============================================================================
# v16.4: Scoring Configuration UI callbacks — update hints and input labels
# when the user changes normalization method or tier classification mode.
# These are pure UI callbacks (no pipeline interaction, no server calls).
# =============================================================================
@callback(
    Output("norm-method-hint", "children"),
    Input("norm-method-dd", "value"),
    prevent_initial_call=True,
)
def update_norm_hint(method):
    """Update the hint text below Normalization dropdown."""
    _hints = {
        "rank": "Rank: (rank−1)/(n−1) — outlier-immune, run-size stable. Default v14–v16.3.",
        "minmax": "Min-Max: (x−min)/(max−min) — preserves score magnitudes, sensitive to extreme outliers.",
        "zscore": "Z-Score: (x−μ)/σ mapped ±3σ→[0,1]. Appropriate only for near-Normal distributions.",
        "robust": "Robust: (x−median)/IQR mapped ±3×IQR→[0,1]. Recommended for skewed AML data (Benford, IsoForest).",
    }
    return dmc.Text(_hints.get(method or "rank", ""), size="10px", c="dimmed", fs="italic")


@callback(
    Output("tier-mode-hint", "children"),
    Output("tier-p1-label", "children"),
    Output("tier-p2-label", "children"),
    Output("tier-p3-label", "children"),
    Output("tier-p1-val", "min"),
    Output("tier-p1-val", "max"),
    Output("tier-p1-val", "step"),
    Output("tier-p1-val", "value"),
    Output("tier-p2-val", "min"),
    Output("tier-p2-val", "max"),
    Output("tier-p2-val", "step"),
    Output("tier-p2-val", "value"),
    Output("tier-p3-val", "min"),
    Output("tier-p3-val", "max"),
    Output("tier-p3-val", "step"),
    Output("tier-p3-val", "value"),
    Input("tier-mode-dd", "value"),
    prevent_initial_call=True,
)
def update_tier_controls(mode):
    """
    When user switches tier mode, update input labels, ranges and default values.
    Percentile: 0.1–100 (%), defaults 1/5/15.
    Absolute:   0–100 (score), defaults 70/50/30.
    """
    if mode == "absolute":
        hint = (
            "Absolute: score ≥ P1-min → P1, score ≥ P2-min (but < P1) → P2, etc. "
            "Enter thresholds on the 0–100 risk score scale. No capacity cap applied."
        )
        labels = ("P1 Min Score", "P2 Min Score", "P3 Min Score")
        p1 = (0.0, 100.0, 1.0, 70.0)
        p2 = (0.0, 100.0, 1.0, 50.0)
        p3 = (0.0, 100.0, 1.0, 30.0)
    else:  # percentile (default)
        hint = (
            "Percentile: Top 1% → P1 (Critical), Top 5% → P2 (High), Top 15% → P3 (Watch). "
            "Capacity-capped by investigation_capacity (default 1000 investigators)."
        )
        labels = ("P1 Cutoff (%)", "P2 Cutoff (%)", "P3 Cutoff (%)")
        p1 = (0.1, 100.0, 0.5, 1.0)
        p2 = (0.1, 100.0, 0.5, 5.0)
        p3 = (0.1, 100.0, 0.5, 15.0)
    hint_el = dmc.Text(hint, size="10px", c="dimmed", fs="italic")
    return (
        hint_el,
        labels[0],
        labels[1],
        labels[2],
        p1[0],
        p1[1],
        p1[2],
        p1[3],
        p2[0],
        p2[1],
        p2[2],
        p2[3],
        p3[0],
        p3[1],
        p3[2],
        p3[3],
    )


@callback(
    Output("pipeline-state", "data"),
    Output("progress-poll", "disabled"),
    Output("progress-poll", "max_intervals"),
    Output("pipeline-progress-bar", "value", allow_duplicate=True),
    Output("progress-message", "children", allow_duplicate=True),
    Output("progress-status-badge", "children", allow_duplicate=True),
    Output("progress-status-badge", "color", allow_duplicate=True),
    Output("stage-indicators", "children", allow_duplicate=True),
    Output("dash-algo-summary", "children", allow_duplicate=True),
    # v12.43: Progressive reset — immediately show loading placeholders
    Output("dash-data-readiness", "children", allow_duplicate=True),
    Output("dash-kpi-row", "children", allow_duplicate=True),
    Output("dash-risk-tier-summary", "children", allow_duplicate=True),
    Output("dash-top-risks-table", "children", allow_duplicate=True),
    Output("dash-network-health", "children", allow_duplicate=True),
    Output("dash-persistence-banner", "children", allow_duplicate=True),
    Input("dash-run-btn", "n_clicks"),
    State("dash-max-customers", "value"),
    State("w-centrality", "value"),
    State("w-community", "value"),
    State("w-pathflow", "value"),
    State("w-link_pred", "value"),
    State("w-anomaly", "value"),
    State("w-temporal", "value"),
    State("w-multi_layer", "value"),
    State("w-structuring", "value"),
    State("w-benfords", "value"),
    State("w-motifs", "value"),
    State("perf-parallel", "checked"),
    State("perf-progressive", "checked"),
    State("perf-sampling", "checked"),
    State("perf-sample-size", "value"),
    # v16.4 GAP-7/2/9: Scoring Configuration controls
    State("norm-method-dd", "value"),
    State("tier-mode-dd", "value"),
    State("tier-p1-val", "value"),
    State("tier-p2-val", "value"),
    State("tier-p3-val", "value"),
    prevent_initial_call=True,
)
def run_pipeline(
    n_clicks,
    max_cust,
    w_c,
    w_co,
    w_pf,
    w_lp,
    w_an,
    w_te,
    w_ml,
    w_st,
    w_bf,
    w_mo,
    perf_parallel,
    perf_progressive,
    perf_sampling,
    perf_sample_size,
    norm_method_val,
    tier_mode_val,
    tier_p1,
    tier_p2,
    tier_p3,
):
    if not n_clicks:
        return (no_update,) * 15

    pipeline = get_pipeline()
    # Prevent double-start
    if pipeline.is_running():
        return (no_update,) * 15

    weights = {
        "centrality": w_c or 0.15,
        "community": w_co or 0.10,
        "pathflow": w_pf or 0.10,
        "link_prediction": w_lp or 0.10,
        "anomaly": w_an or 0.15,
        "temporal": w_te or 0.10,
        "multi_layer": w_ml or 0.10,
        "structuring": w_st or 0.10,
        "benfords": w_bf or 0.05,
        "motifs": w_mo or 0.05,
    }

    # v15.2 Task1+3: STRICT PA-ONLY gate — block run if no data from Port Authority.
    # Data MUST come exclusively from Port Authority (sample or actual upload).
    _last_pushed = getattr(pipeline, "_last_pushed_tables", None)
    if not _last_pushed:
        _block_msg = dmc.Alert(
            [
                dmc.Text("No data from Port Authority.", fw=600, size="sm"),
                dmc.Text(
                    "Generate or upload data on the Port Authority page, "
                    "then click '📦 Push to Pipeline' before running.",
                    size="xs",
                    c="dimmed",
                    mt=4,
                ),
            ],
            color="orange",
            variant="light",
            radius="md",
            icon=DashIconify(icon="mdi:lock-outline", width=18),
            title="Port Authority data required",
        )
        return (
            no_update,
            True,
            no_update,
            no_update,
            _block_msg,
            "Awaiting Data",
            "orange",
            no_update,
            no_update,
            no_update,
            no_update,
            no_update,
            no_update,
            no_update,
            no_update,
        )

    # v15.2 Task2: Always restore PA snapshot; cap max_customers to PA data size.
    pipeline.tables = {k: v.copy() for k, v in _last_pushed.items()}
    # v16.8 M3: use threading.Event for proper cross-thread memory visibility
    pipeline._cleansed_event.set()

    # Determine PA entity count (node table first, fall back to customer)
    # v15.3 Task1: fix DataFrame truthiness — use key-check instead of 'or'
    _pa_ref = (
        _last_pushed.get("node")
        if "node" in _last_pushed
        else (
            _last_pushed.get("customer")
            if "customer" in _last_pushed
            else next(iter(_last_pushed.values()), None)
        )
    )
    _pa_size = len(_pa_ref) if _pa_ref is not None else 0
    # Effective max = min(user input, PA size) — never inflate beyond PA data
    _effective_max = (
        max(1, min(max_cust or _pa_size, _pa_size)) if _pa_size > 0 else (max_cust or 10)
    )

    # v16.73: 4-layer deterministic run fingerprint — TRUE CACHE SKIP.
    # L1=full data content (ALL rows/cells), L2=scoring weights,
    # L3=pipeline config params, L4=app version.
    # ALL 4 layers must match for a cache hit — any single change → fresh run.
    _run_params_fp = {
        "max_customers": _effective_max,
        "norm_method":   (norm_method_val or "rank").lower().strip(),
        "tier_mode":     tier_mode_val or "percentile",
        "tier_p1":       round(float(tier_p1 or 1.0), 4),
        "tier_p2":       round(float(tier_p2 or 5.0), 4),
        "tier_p3":       round(float(tier_p3 or 15.0), 4),
        "parallel":      bool(perf_parallel if perf_parallel is not None else True),
        "progressive":   bool(perf_progressive if perf_progressive is not None else True),
        "sample_size":   int(perf_sample_size) if perf_sampling and perf_sample_size else None,
    }
    _new_fp, _new_layers = pipeline._compute_run_fingerprint(
        _last_pushed, weights, _run_params_fp, APP.VERSION
    )
    _is_exact_match = (
        pipeline._last_run_fingerprint is not None
        and _new_fp == pipeline._last_run_fingerprint
        and pipeline.scored_df is not None   # must have prior results in memory
    )
    pipeline._last_run_was_cache_hit = _is_exact_match

    # Build diff message — tell user WHICH layers changed
    if not _is_exact_match and pipeline._last_run_layer_hashes:
        _old_layers = pipeline._last_run_layer_hashes
        _diff_changed = []
        if _new_layers["data"]    != _old_layers.get("data"):    _diff_changed.append("Input data")
        if _new_layers["weights"] != _old_layers.get("weights"): _diff_changed.append("Scoring weights")
        if _new_layers["config"]  != _old_layers.get("config"):  _diff_changed.append("Pipeline config")
        if _new_layers["version"] != _old_layers.get("version"): _diff_changed.append("App version")
        pipeline._cache_miss_reason = (
            " + ".join(_diff_changed) + " changed → fresh run" if _diff_changed else ""
        )
    else:
        pipeline._cache_miss_reason = ""

    if _is_exact_match:
        # ── TRUE CACHE SKIP ────────────────────────────────────────────────
        # All 4 fingerprint layers match. Skip pipeline.run_background() entirely.
        # Reload from DB into memory if scored_df was cleared (e.g. browser refresh).
        if pipeline.scored_df is None:
            pipeline.load_last_run()
        _prev_run_id = pipeline.last_run_meta.get("run_id", "?")
        _prev_cust   = pipeline.last_run_meta.get("customers", 0)
        _hit_msg = (
            f"⚡ Exact match — data, weights, config and version all unchanged. "
            f"Loaded stored results from Run #{_prev_run_id} ({_prev_cust:,} customers). "
            f"No recomputation needed."
        )
        pipeline._cache_hit_msg = _hit_msg
        return (
            {"success": True, "run_id": _prev_run_id, "cache_hit": True},
            True,   # disable interval (no polling needed)
            0,      # max_intervals = 0
            100,    # progress bar → 100 %
            dmc.Alert(
                dmc.Stack([
                    dmc.Text(_hit_msg, size="sm"),
                    dmc.Text(
                        "All 4 fingerprint layers identical. Zero recomputation.",
                        c="dimmed", size="xs",
                    ),
                ], gap="xs"),
                color="teal",
                variant="light",
                radius="md",
                icon=DashIconify(icon="mdi:lightning-bolt", width=20),
                title="⚡ Exact Match — Results Reloaded",
            ),
            "⚡ Exact Match",
            "teal",
            [],
            dmc.Center(
                dmc.Stack([
                    DashIconify(icon="mdi:lightning-bolt", width=40, color="#00BFA5"),
                    dmc.Text(_hit_msg, c="teal", size="sm", ta="center"),
                ], align="center", gap="xs"),
                style={"minHeight": "100px"},
            ),
            no_update,
            no_update,
            no_update,
            no_update,
            no_update,
            no_update,
        )

    # ── FRESH RUN ──────────────────────────────────────────────────────────
    # Store new fingerprint in pipeline BEFORE run_background() so save_last_run()
    # can embed it in last_run_meta and persist it to the DB metadata blob.
    pipeline._last_run_fingerprint  = _new_fp
    pipeline._last_run_layer_hashes = _new_layers
    pipeline._last_run_params       = {"weights": weights, **_run_params_fp}
    pipeline._cache_hit_msg         = ""
    _is_cache_hit = False   # keep legacy variable name used in rest of callback

    # v12.33: Auto-reset all derived/stale results before each fresh run.
    pipeline.scored_df = None
    pipeline.analytics_results = {}
    pipeline.G = None
    pipeline.reports = {}
    pipeline.stage_results = []
    pipeline._cycles_cache = None
    pipeline._lobbies_cache = None
    pipeline._important_nodes_cache = None
    pipeline.progress.reset()

    # Store weights for poll callback to use on completion
    pipeline.last_run_meta["weights"] = weights

    # Performance settings
    parallel = perf_parallel if perf_parallel is not None else True
    progressive = perf_progressive if perf_progressive is not None else True
    effective_sample = int(perf_sample_size) if perf_sampling and perf_sample_size else None

    # Build mode label (v15.2: include PA data source info)
    mode_parts = []
    if parallel:
        mode_parts.append("parallel")
    if progressive:
        mode_parts.append("progressive")
    if effective_sample:
        mode_parts.append(f"sampling({effective_sample})")
    mode_str = " + ".join(mode_parts) if mode_parts else "standard"
    pa_info = f"PA: {_pa_size} → {_effective_max} entities"

    # v12.4: Start pipeline in BACKGROUND thread (v15.2: use _effective_max)
    # v16.4: pass norm_method and tier_override from Scoring Configuration panel
    _norm = (norm_method_val or "rank").lower().strip()
    _tier_override = None
    if tier_mode_val:
        _tier_override = {
            "mode": tier_mode_val,
            "p1": float(tier_p1 or (1.0 if tier_mode_val == "percentile" else 70.0)),
            "p2": float(tier_p2 or (5.0 if tier_mode_val == "percentile" else 50.0)),
            "p3": float(tier_p3 or (15.0 if tier_mode_val == "percentile" else 30.0)),
        }
    # v16.8 L5: explicitly clear stop_requested before each fresh run
    # (guards the millisecond window between Stop-click and new Run-click)
    pipeline.progress.stop_requested = False
    pipeline.run_background(
        max_customers=_effective_max,
        scoring_weights=weights,
        parallel=parallel,
        sample_size=effective_sample,
        progressive=progressive,
        norm_method=_norm,
        tier_override=_tier_override,
    )

    # v12.43: Reset progressive tracking
    _progressive_stages_sent.clear()

    # Return immediately — enable polling, show running state
    # v16.73: show diff reason (what changed) if this replaced a prior run
    _diff_banner = pipeline._cache_miss_reason  # e.g. "Scoring weights changed → fresh run"
    _run_msg = (
        f"Pipeline starting [{mode_str}]"
        + (f" — {_diff_banner}" if _diff_banner else "")
        + "..."
    )
    _loader_items = [
        dmc.Loader(color="cyan", size="md"),
        dmc.Text(_run_msg, c="dimmed", size="sm"),
    ]
    if _diff_banner:
        _loader_items.insert(
            0,
            dmc.Badge(_diff_banner, color="orange", variant="light", radius="sm", size="xs"),
        )
    loading_el = dmc.Center(
        dmc.Stack(
            _loader_items,
            align="center",
            gap="xs",
        ),
        style={"minHeight": "100px"},
    )

    # v12.43: Progressive reset — loading placeholders for all dashboard sections
    _loading_mini = lambda icon, text: dmc.Center(
        dmc.Group(
            [
                dmc.Loader(color="cyan", size="xs", type="dots"),
                DashIconify(icon=icon, width=16, color="dimmed"),
                dmc.Text(text, c="dimmed", size="xs"),
            ],
            gap="xs",
        ),
        style={"minHeight": "60px"},
    )

    loading_readiness = _loading_mini("mdi:database-search", "Ingesting data...")
    loading_kpi = [
        dmc.Paper(
            [
                dmc.Group(
                    [
                        dmc.Loader(color="cyan", size="xs", type="dots"),
                        dmc.Text(lab, size="xs", c="dimmed"),
                    ],
                    gap="xs",
                ),
            ],
            p="md",
            radius="lg",
            className="stat-card glass-card",
        )
        for lab in ("Customers", "Entities", "Financial Links", "Time", "Run")
    ]
    loading_tier = _loading_mini("mdi:shield-search", "Scoring risk tiers...")
    loading_top = _loading_mini("mdi:account-alert", "Identifying flagged customers...")
    loading_health = _loading_mini("mdi:graph-outline", "Constructing network...")

    return (
        no_update,
        False,
        -1,
        1,
        f"Starting pipeline [{mode_str}] · {pa_info}...",
        "Running",
        "cyan",
        [],
        loading_el,
        loading_readiness,
        loading_kpi,
        loading_tier,
        loading_top,
        loading_health,
        html.Div(),
    )


# v15.11: Resume pipeline callback (E1) — FIXED: background thread + re-enable poll
# Previously called pipeline.run() synchronously (blocked the Dash server thread).
# Now uses run_background() and immediately re-enables the progress poll interval.
@callback(
    Output("pipeline-state", "data", allow_duplicate=True),
    Output("progress-message", "children", allow_duplicate=True),
    Output("progress-status-badge", "children", allow_duplicate=True),
    Output("progress-status-badge", "color", allow_duplicate=True),
    Output("progress-poll", "disabled", allow_duplicate=True),  # v15.11: re-enable poll
    Output("progress-poll", "max_intervals", allow_duplicate=True),  # v15.11: unlimited intervals
    Input("dash-resume-btn", "n_clicks"),
    State("dash-max-customers", "value"),
    prevent_initial_call=True,
)
def resume_pipeline(n_clicks, max_cust):
    if not n_clicks:
        return (no_update,) * 6

    pipeline = get_pipeline()
    # Block resume if no PA data
    _last_pushed = getattr(pipeline, "_last_pushed_tables", None)
    if not _last_pushed:
        return (
            no_update,
            "No PA data — push data from Port Authority first",
            "Awaiting Data",
            "orange",
            no_update,
            no_update,
        )

    # v15.3 Task1: fix DataFrame truthiness — use key-check instead of 'or'
    _pa_ref = (
        _last_pushed.get("node")
        if "node" in _last_pushed
        else (
            _last_pushed.get("customer")
            if "customer" in _last_pushed
            else next(iter(_last_pushed.values()), None)
        )
    )
    _pa_size = len(_pa_ref) if _pa_ref is not None else 0
    _effective_max = (
        max(1, min(max_cust or _pa_size, _pa_size)) if _pa_size > 0 else (max_cust or 10)
    )

    # v15.11: clear any previous stop request, then kick off background thread
    pipeline.progress.stop_requested = False
    pipeline.run_background(max_customers=_effective_max, resume=True)

    state = {
        "run_version": pipeline.run_version,
        "nonce": int(time.time() * 1000),
    }
    # Return immediately — progress-poll will stream stage updates to the UI
    return state, "⟳ Resuming pipeline…", "Running", "cyan", False, -1


@callback(
    Output("pipeline-progress-bar", "value"),
    Output("progress-message", "children"),
    Output("progress-status-badge", "children"),
    Output("progress-status-badge", "color"),
    Output("stage-indicators", "children"),
    Output("pipeline-state", "data", allow_duplicate=True),
    Output("progress-poll", "disabled", allow_duplicate=True),
    Output("dash-algo-summary", "children", allow_duplicate=True),
    # v12.43: Progressive section updates
    Output("dash-data-readiness", "children", allow_duplicate=True),
    Output("dash-risk-tier-summary", "children", allow_duplicate=True),
    Output("dash-top-risks-table", "children", allow_duplicate=True),
    Output("dash-network-health", "children", allow_duplicate=True),
    # v14.5 FIX-C: Broadcast pipeline completion to all analytics pages
    Output("global-refresh-ts", "data", allow_duplicate=True),
    Input("progress-poll", "n_intervals"),
    Input("dash-init", "n_intervals"),
    prevent_initial_call=True,
)
def update_progress(poll_n, init_n):
    pipeline = get_pipeline()
    # v16.8 M4: atomic combined call — eliminates race window between
    # get_status() and is_running() being two separate non-atomic calls
    status = pipeline.get_current_status()

    pct = status["overall_pct"]
    msg = status["message"]
    running = status["running"]

    # v12.26 Task 1: On page load (dash-init), reset progress UI to Ready state.
    # v12.46 FIX: Also rebuild content sections from singleton so they survive
    # page navigation (a fresh layout() DOM starts empty; no_update would keep
    # them empty instead of restoring the last run's data).
    if ctx.triggered_id == "dash-init" and not running:
        if pct > 0:
            pipeline.progress.reset()
        _progressive_stages_sent.clear()
        # Rebuild content from singleton data (persists across page nav)
        _has_live = pipeline.scored_df is not None and len(pipeline.scored_df) > 0
        _has_tbls = bool(
            pipeline.tables and any(v is not None and len(v) > 0 for v in pipeline.tables.values())
        )
        if _has_live or _has_tbls:
            # Restore algo summary
            _analytics = pipeline.get_analytics_results()
            if _analytics and any(df is not None and len(df) > 0 for df in _analytics.values()):
                _weights = pipeline.last_run_meta.get(
                    "weights",
                    {
                        "centrality": 0.15,
                        "community": 0.10,
                        "pathflow": 0.10,
                        "link_prediction": 0.10,
                        "anomaly": 0.15,
                        "temporal": 0.10,
                        "multi_layer": 0.10,
                        "structuring": 0.10,
                        "benfords": 0.05,
                        "motifs": 0.05,
                    },
                )
                _algo_summ = _build_algo_summary(pipeline, _weights)
            else:
                _algo_summ = no_update
            _scored = pipeline.get_scored_df()
            # Rebuild data readiness from pipeline tables
            if _has_tbls:
                _ne = {k: v for k, v in pipeline.tables.items() if v is not None and len(v) > 0}
                _readiness = _build_readiness_grouped_content(_ne, pipeline)
            else:
                _readiness = no_update
            return (
                0,
                "Ready — click Run Pipeline to start",
                "Ready",
                "gray",
                [],
                no_update,
                True,
                _algo_summ,
                _readiness,
                _build_risk_tier_summary(_scored),
                _build_top_flagged_table(_scored),
                _build_network_health_panel(pipeline),
                no_update,
            )  # v14.5 FIX-C: no ts update on init restore
        # Nothing in memory — return all no_update (init_dashboard handles placeholders)
        return (
            0,
            "Ready — click Run Pipeline to start",
            "Ready",
            "gray",
            [],
            no_update,
            True,
            no_update,
            no_update,
            no_update,
            no_update,
            no_update,
            no_update,
        )

    # v12.4: Progressive family-level status
    if hasattr(pipeline, "get_analytics_status"):
        fam_info = pipeline.get_analytics_status()
        done_count = fam_info.get("completed", 0)
        total_count = fam_info.get("total", 10)
        cached_count = fam_info.get("cached", 0)
        if running and done_count > 0:
            extra = f" | Families: {done_count}/{total_count}"
            if cached_count > 0:
                extra += f" ({cached_count} cached)"
            msg = msg + extra

    # D5: ETA countdown — only show when pipeline is in progress and we have
    # enough elapsed time to make a meaningful estimate (pct > 5, elapsed > 2s)
    if running and pct > 5:
        elapsed = status.get("elapsed_sec", 0)
        if elapsed > 2:
            eta_sec = elapsed * (100 - pct) / max(pct, 1)
            if eta_sec < 60:
                msg += f" | ETA ~{eta_sec:.0f}s"
            else:
                msg += f" | ETA ~{eta_sec / 60:.1f}m"

    badge_text = "Running..." if running else ("Complete" if pct >= 100 else "Idle")
    badge_color = "cyan" if running else ("green" if pct >= 100 else "gray")
    stage_chips = _build_stage_chips(status)

    if not running and pct >= 100:
        # ── Pipeline complete — build final state + algo summary ──
        weights = pipeline.last_run_meta.get(
            "weights",
            {
                "centrality": 0.15,
                "community": 0.10,
                "pathflow": 0.10,
                "link_prediction": 0.10,
                "anomaly": 0.15,
                "temporal": 0.10,
                "multi_layer": 0.10,
                "structuring": 0.10,
                "benfords": 0.05,
                "motifs": 0.05,
            },
        )

        total_ms = (
            sum(r.duration_ms for r in pipeline.stage_results) if pipeline.stage_results else 0
        )
        total_secs = total_ms / 1000
        time_str = f"{total_secs:.1f}s" if total_secs < 60 else f"{total_secs/60:.1f}m"
        customers = len(pipeline.scored_df) if pipeline.scored_df is not None else 0

        final_msg = f"✓ Pipeline complete — {customers} customers, {time_str}"

        state = {
            "run_version": pipeline.run_version,
            "success": True,
            "customers": customers,
            "timestamp": str(pipeline.last_run_meta.get("saved_at", "")),
            "duration_ms": total_ms,
            # v12.17 Task 6: embed graph metrics so KPI boxes always update
            "graph_nodes": (
                pipeline.G.number_of_nodes()
                if pipeline.G
                else pipeline.last_run_meta.get("graph_nodes", 0)
            ),
            "graph_edges": (
                pipeline.G.number_of_edges()
                if pipeline.G
                else pipeline.last_run_meta.get("graph_edges", 0)
            ),
            "nonce": int(time.time() * 1000),
        }
        algo_summary = _build_algo_summary(pipeline, weights)
        # v12.44: On complete, build readiness from the ACTUAL tables the
        # pipeline used (post max-customers filter).  pipeline.tables is the
        # authoritative, filtered dataset at this point.
        _progressive_stages_sent.clear()
        if pipeline.tables:
            _non_empty_run = {
                k: v for k, v in pipeline.tables.items() if v is not None and len(v) > 0
            }
            final_readiness = _build_readiness_grouped_content(_non_empty_run, pipeline)
        else:
            final_readiness = no_update
        final_scored = pipeline.get_scored_df()
        final_tier = _build_risk_tier_summary(final_scored)
        final_top = _build_top_flagged_table(final_scored)
        final_health = _build_network_health_panel(pipeline)
        # v12.48 Task 1: Embed serialised stage results in pipeline-state so
        # init_dashboard can reliably display them even after page navigation.
        state["stage_results"] = [r.model_dump() for r in pipeline.stage_results]
        # v14.5 FIX-C: Broadcast completion timestamp — triggers refresh on all
        # analytics pages (anomaly, centrality, community, link_prediction,
        # multi_layer, pathflow, temporal, reports, visualization, workspace)
        return (
            100,
            final_msg,
            "Complete",
            "green",
            stage_chips,
            state,
            True,
            algo_summary,
            final_readiness,
            final_tier,
            final_top,
            final_health,
            int(time.time() * 1000),
        )

    # v12.12: Handle pipeline failure — not running but pct > 0 and < 100
    if not running and pct > 0 and pct < 100:
        analytics = pipeline.get_analytics_results()
        has_any = analytics and any(df is not None and len(df) > 0 for df in analytics.values())
        if has_any:
            # Partial success — show what we have
            weights = pipeline.last_run_meta.get(
                "weights",
                {
                    "centrality": 0.15,
                    "community": 0.10,
                    "pathflow": 0.10,
                    "link_prediction": 0.10,
                    "anomaly": 0.15,
                    "temporal": 0.10,
                    "multi_layer": 0.10,
                    "structuring": 0.10,
                    "benfords": 0.05,
                    "motifs": 0.05,
                },
            )
            algo_summary = _build_algo_summary(pipeline, weights)
        else:
            algo_summary = dmc.Center(
                dmc.Stack(
                    [
                        DashIconify(icon="mdi:alert-circle", width=32, color="#FF1744"),
                        dmc.Text(
                            "Pipeline failed — check logs and retry", c="#FF1744", size="sm", fw=600
                        ),
                    ],
                    align="center",
                    gap="xs",
                ),
                style={"minHeight": "100px"},
            )
        return (
            pct,
            "Pipeline stopped or failed",
            "Failed",
            "red",
            stage_chips,
            no_update,
            True,
            algo_summary,
            no_update,
            no_update,
            no_update,
            no_update,
            no_update,
        )

    # v12.43: Progressive stage-by-stage section updates while running
    done_indices = {i for i, s in enumerate(status["stages"]) if s["status"] == "done"}
    newly_done = done_indices - _progressive_stages_sent

    prog_readiness = no_update
    prog_tier = no_update
    prog_top = no_update
    prog_health = no_update

    if running and newly_done:
        if 0 in newly_done:  # Ingest complete → show real data readiness
            tables = pipeline.tables
            if tables:
                prog_readiness = _build_readiness_grouped_content(tables, pipeline)

        if 2 in newly_done:  # Graph Construction complete → show network health
            prog_health = _build_network_health_panel(pipeline)

        if 4 in newly_done:  # Risk Scoring complete → show tiering + top flagged
            scored = pipeline.get_scored_df()
            if scored is not None and len(scored) > 0:
                prog_tier = _build_risk_tier_summary(scored)
                prog_top = _build_top_flagged_table(scored)

        _progressive_stages_sent.update(newly_done)

    # Still running or idle — don't touch pipeline-state / poll / algo
    return (
        pct,
        msg,
        badge_text,
        badge_color,
        stage_chips,
        no_update,
        no_update,
        no_update,
        prog_readiness,
        prog_tier,
        prog_top,
        prog_health,
        no_update,
    )


# D1: stage-name → emoji mapping for richer visual feedback
_STAGE_EMOJI = {
    "Ingest & Validate": "📥",
    "Aggregation": "🔢",
    "Graph Construction": "🕸️",
    "Analytics (10-Family)": "🔬",
    "Risk Scoring": "🎯",
    "Reporting & Persist": "📊",
}


def _build_stage_chips(status):
    """D1: Build enriched stage chips with emoji, colour and duration badge."""
    stage_chips = []
    for s in status["stages"]:
        st = s["status"]
        emoji = _STAGE_EMOJI.get(s["name"], "▸")
        if st == "done":
            icon, color, variant = "mdi:check-circle", "green", "light"
        elif st == "running":
            icon, color, variant = "mdi:loading", "cyan", "filled"
        else:
            icon, color, variant = "mdi:circle-outline", "gray", "subtle"

        dur_text = f"{s['duration']:.1f}s" if s["duration"] > 0 else ""
        label = f"{emoji} {s['name']}"

        stage_chips.append(
            dmc.Badge(
                dmc.Group(
                    [
                        DashIconify(icon=icon, width=13),
                        dmc.Text(label, size="xs", fw=500 if st == "running" else 400),
                        dmc.Text(dur_text, size="xs", c="dimmed") if dur_text else None,
                    ],
                    gap=4,
                    align="center",
                ),
                color=color,
                variant=variant,
                size="sm",
                radius="sm",
                style={"paddingLeft": 6, "paddingRight": 6},
            )
        )
    return stage_chips


def _build_algo_summary(pipeline, weights):
    import pandas as pd

    analytics = pipeline.get_analytics_results()

    # v12.4: Get family timing/status info
    fam_metrics = {}
    if hasattr(pipeline, "get_analytics_status"):
        fam_info = pipeline.get_analytics_status()
        fam_metrics = fam_info.get("metrics", {})

    algo_cards = []
    for key, (label, icon, color) in FAMILY_MAP.items():
        df = analytics.get(key) if analytics else None
        has_data = df is not None and len(df) > 0
        num_metrics = (
            len([c for c in df.columns if c != "node_id" and pd.api.types.is_numeric_dtype(df[c])])
            if has_data
            else 0
        )
        rows = len(df) if has_data else 0
        weight_pct = int(weights.get(key, 0) * 100)

        # v12.4: Per-family performance badge
        perf = fam_metrics.get(key, {})
        time_ms = perf.get("time_ms", 0)
        fam_status = perf.get("status", "")

        if fam_status == "cached":
            perf_badge = dmc.Badge(
                "⚡ CACHED", color="green", variant="light", size="xs", mt="xs", fullWidth=True
            )
        elif time_ms > 0:
            perf_badge = dmc.Badge(
                f"✓ {time_ms:.0f}ms",
                color="cyan",
                variant="light",
                size="xs",
                mt="xs",
                fullWidth=True,
            )
        elif has_data:
            perf_badge = dmc.Badge(
                "✓ Computed", color="green", variant="light", size="xs", mt="xs", fullWidth=True
            )
        else:
            perf_badge = dmc.Badge(
                "✗ No data", color="red", variant="light", size="xs", mt="xs", fullWidth=True
            )

        algo_cards.append(
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            DashIconify(icon=icon, width=20, color=color),
                            dmc.Text(label, size="sm", fw=600, c="white"),
                        ],
                        gap="xs",
                        mb="xs",
                    ),
                    dmc.SimpleGrid(
                        cols=3,
                        spacing=4,
                        children=[
                            dmc.Stack(
                                [
                                    dmc.Text("Entities", size="xs", c="dimmed"),
                                    dmc.Text(
                                        f"{rows:,}",
                                        size="sm",
                                        fw=700,
                                        c="white" if has_data else "dimmed",
                                    ),
                                ],
                                gap=0,
                                align="center",
                            ),
                            dmc.Stack(
                                [
                                    dmc.Text("Signals", size="xs", c="dimmed"),
                                    dmc.Text(
                                        str(num_metrics),
                                        size="sm",
                                        fw=700,
                                        c="white" if has_data else "dimmed",
                                    ),
                                ],
                                gap=0,
                                align="center",
                            ),
                            dmc.Stack(
                                [
                                    dmc.Text("Score %", size="xs", c="dimmed"),
                                    dmc.Text(f"{weight_pct}%", size="sm", fw=700, c=color),
                                ],
                                gap=0,
                                align="center",
                            ),
                        ],
                    ),
                    perf_badge,
                ],
                p="sm",
                radius="md",
                style={"backgroundColor": "rgba(0,0,0,0.3)", "border": f"1px solid {color}30"},
            ),
        )

    return dmc.SimpleGrid(
        cols={"base": 2, "sm": 3, "md": 5, "xl": 10}, spacing="sm", children=algo_cards
    )


# v12.4: Sync sample preset → sample size
@callback(
    Output("perf-sample-size", "value"),
    Input("perf-sample-preset", "value"),
    prevent_initial_call=True,
)
def sync_sample_preset(preset):
    if preset:
        return int(preset)
    return no_update


@callback(
    Output("config-status", "children"),
    Input("config-load-btn", "n_clicks"),
    prevent_initial_call=True,
)
def load_config(_):
    pipeline = get_pipeline()
    overrides = pipeline.load_config_overrides()
    if overrides:
        return f"Loaded {len(overrides)} settings"
    return "No config file found"


@callback(
    Output("config-status", "children", allow_duplicate=True),
    Input("config-save-btn", "n_clicks"),
    State("config-file-content", "value"),
    prevent_initial_call=True,
)
def save_config(_, content):
    if not content:
        return "No content to save"
    try:
        data = json.loads(content)
        pipeline = get_pipeline()
        pipeline.save_config(data)
        return f"Saved {len(data)} settings ✓"
    except json.JSONDecodeError:
        return "Invalid JSON!"


@callback(
    Output("progress-status-badge", "children", allow_duplicate=True),
    Output("progress-status-badge", "color", allow_duplicate=True),
    Output("pipeline-progress-bar", "value", allow_duplicate=True),
    Output("progress-message", "children", allow_duplicate=True),
    Output("progress-poll", "disabled", allow_duplicate=True),  # v15.11: halt progress poll on stop
    Input("dash-stop-btn", "n_clicks"),
    prevent_initial_call=True,
)
def stop_pipeline(n_clicks):
    if not n_clicks:
        return no_update, no_update, no_update, no_update, no_update
    pipeline = get_pipeline()
    pipeline.progress.stop_requested = True
    return "Stopped", "red", 0, "Pipeline stopped by user", True


# v15.11: Clientside button state management
# Keeps Run / Resume / Stop buttons in sync with pipeline state via badge colour
# (cyan = running; anything else = idle / complete / stopped / failed)
clientside_callback(
    """
    function(badge_color) {
        var running = (badge_color === 'cyan');
        return [
            running,   // dash-run-btn disabled while running
            running,   // dash-resume-btn disabled while running
            !running   // dash-stop-btn disabled when not running
        ];
    }
    """,
    Output("dash-run-btn", "disabled", allow_duplicate=True),
    Output("dash-resume-btn", "disabled", allow_duplicate=True),
    Output("dash-stop-btn", "disabled", allow_duplicate=True),
    Input("progress-status-badge", "color"),
    prevent_initial_call=True,
)


@callback(
    Output("dash-gen-sample-status", "children", allow_duplicate=True),
    Input("dash-gen-sample-btn", "n_clicks"),
    prevent_initial_call=True,
)
def generate_sample_data(n_clicks):
    return "Navigate to Port Authority to generate data"


# =============================================================================
# RESET ALL DATA
# =============================================================================
@callback(
    Output("dash-reset-status", "children"),
    Output("dash-data-readiness", "children", allow_duplicate=True),
    Output("dash-kpi-row", "children", allow_duplicate=True),
    Output("pipeline-state", "data", allow_duplicate=True),
    Output("dash-risk-tier-summary", "children", allow_duplicate=True),
    Output("dash-top-risks-table", "children", allow_duplicate=True),
    Output("dash-network-health", "children", allow_duplicate=True),
    Output("dash-persistence-banner", "children", allow_duplicate=True),
    Input("dash-reset-btn", "n_clicks"),
    prevent_initial_call=True,
)
def reset_all_data(n_clicks):
    if not n_clicks:
        return (no_update,) * 8

    import shutil
    from config import PATHS

    removed = []
    try:
        db_path = PATHS.DATA / "fcdai.db"
        if db_path.exists():
            try:
                db_path.unlink()
                removed.append("DB")
            except Exception:
                pass

        vault_dir = PATHS.VAULT
        if vault_dir.exists():
            try:
                shutil.rmtree(vault_dir)
                vault_dir.mkdir(parents=True, exist_ok=True)
                removed.append("Vault")
            except Exception:
                pass

        sample_dir = PATHS.DATA / "samples"
        if sample_dir.exists():
            try:
                shutil.rmtree(sample_dir)
                sample_dir.mkdir(parents=True, exist_ok=True)
                removed.append("Samples")
            except Exception:
                pass

        log_dir = PATHS.LOGS
        if log_dir.exists():
            try:
                shutil.rmtree(log_dir)
                log_dir.mkdir(parents=True, exist_ok=True)
                removed.append("Logs")
            except Exception:
                pass

        pipeline = get_pipeline()
        pipeline.tables = {}
        pipeline.customer_features = None
        pipeline.edges = None
        pipeline.G = None
        pipeline.analytics_results = {}
        pipeline.scored_df = None
        pipeline.reports = {}
        pipeline.stage_results = []
        pipeline.last_run_meta = {}
        pipeline._cycles_cache = None
        pipeline._lobbies_cache = None
        pipeline._important_nodes_cache = None
        pipeline.run_version = 0
        pipeline.progress.reset()
        removed.append("State")

        # v12.43: Reset to grouped placeholder structure
        readiness = _build_readiness_grouped_content({})

        kpi_cards = [
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            DashIconify(icon=icon, width=24, color=color),
                            dmc.Stack(
                                [
                                    dmc.Text(label, size="xs", c="dimmed"),
                                    dmc.Text("0", size="lg", fw=700, c="white"),
                                ],
                                gap=0,
                            ),
                        ],
                        gap="sm",
                    ),
                ],
                p="md",
                radius="lg",
                className="stat-card glass-card",
            )
            for label, icon, color in [
                ("Customers", "mdi:account-multiple", THEME.PRIMARY),
                ("Entities", "mdi:graph", THEME.SUCCESS),
                ("Financial Links", "mdi:swap-horizontal", THEME.INFO),
                ("Total Time", "mdi:timer-outline", "#FFD600"),
                ("Run Version", "mdi:counter", "#E040FB"),
            ]
        ]

        reset_state = {"reset": True, "run_version": 0}
        empty_tier = dmc.Center(
            dmc.Text("Run pipeline to see risk portfolio breakdown", c="dimmed", size="sm"),
            style={"minHeight": "60px"},
        )
        empty_top = dmc.Center(
            dmc.Text("Run pipeline to see top flagged customers", c="dimmed", size="sm"),
            style={"minHeight": "60px"},
        )
        empty_health = dmc.Center(
            dmc.Text("Run pipeline to see network health metrics", c="dimmed", size="sm"),
            style={"minHeight": "60px"},
        )

        return (
            f"✓ Reset: {', '.join(removed)}",
            readiness,
            kpi_cards,
            reset_state,
            empty_tier,
            empty_top,
            empty_health,
            html.Div(),
        )  # Clear persistence banner
    except Exception as e:
        return (
            f"✗ Error: {str(e)[:80]}",
            no_update,
            no_update,
            no_update,
            no_update,
            no_update,
            no_update,
            no_update,
        )


# ═══════════════════════════════════════════════════════════════════════════════
# v12.43: DOWNLOAD FULL REPORT — Excel multi-sheet export
# Sheets: Executive Summary | Full Scored Portfolio | Risk Tier Matrix |
#         Per-Family Analytics (one sheet each) | Data Sources
# ═══════════════════════════════════════════════════════════════════════════════
@callback(
    Output("dash-download-excel", "data"),
    Output("dash-download-status", "children"),
    Input("dash-download-btn", "n_clicks"),
    prevent_initial_call=True,
)
def download_full_report(n_clicks):
    """v12.43: Generate and stream a multi-sheet Excel investigation package."""
    if not n_clicks:
        return no_update, no_update

    pipeline = get_pipeline()

    # Gate — need at least scores to produce a meaningful report
    if pipeline.scored_df is None or len(pipeline.scored_df) == 0:
        return (no_update, "⚠ No results yet — run the pipeline first, then download.")

    try:
        from utils.excel_export import export_investigation_excel
        from datetime import datetime

        analytics = (
            pipeline.get_analytics_results() if hasattr(pipeline, "get_analytics_results") else {}
        )
        analytics = analytics or {}

        # Task 1 fix: pass ALL tables that were actually used in this pipeline run.
        # This includes every table in pipeline.tables (source inputs + any derived
        # graph tables) so the report matches exactly what the analysis ran on.
        _all_tables = {
            k: v for k, v in (pipeline.tables or {}).items() if v is not None and len(v) > 0
        }
        filepath = export_investigation_excel(
            scored_df=pipeline.scored_df,
            analytics=analytics,
            tables=_all_tables,
        )

        ts_label = datetime.now().strftime("%d %b %Y %H:%M")
        customers = len(pipeline.scored_df)
        status = (
            f"✓ Downloaded — {customers:,} customers · "
            f"{len(analytics)} analytics tabs · {ts_label}"
        )
        return dcc.send_file(str(filepath)), status

    except Exception as e:
        return no_update, f"✗ Export error: {str(e)[:80]}"


# ── v15.4 Task1: Max Customers AUTO hint ─────────────────────────────────────
@callback(
    Output("dash-max-cust-hint", "children"),
    Input("pipeline-state", "data"),
    prevent_initial_call=False,
)
def update_max_cust_hint(_state):
    """Keep the hint below Max Customers box in sync with PA push data."""
    pipeline = get_pipeline()

    # Priority 1: published PA summary (set on push)
    summary = getattr(pipeline, "_pa_push_summary", None)
    if summary and summary.get("n_nodes", 0) > 0:
        n = summary["n_nodes"]
        mode = summary.get("data_mode", "graph")
        label = "nodes" if mode == "graph" else "customers"
        return dmc.Group(
            [
                DashIconify(icon="mdi:auto-fix", width=13, color="#00E676"),
                dmc.Text(
                    f"Auto = {n:,} {label} from Port Authority "
                    f"(leave blank to use all, or type a lower number)",
                    size="xs",
                    c="dimmed",
                    fs="italic",
                ),
            ],
            gap=4,
        )

    # Priority 2: staged but not yet pushed
    staged = getattr(pipeline, "_staged_tables", None) or {}
    _n_tbl = next(
        (
            staged.get(k)
            for k in ("node", "customer", "account", "node_features")
            if staged.get(k) is not None
        ),
        None,
    )
    if _n_tbl is not None and len(_n_tbl) > 0:
        return dmc.Text(
            f"Auto \u2248 {len(_n_tbl):,} entities staged (push first to confirm)",
            size="xs",
            c="dimmed",
            fs="italic",
        )

    # No PA data at all
    return dmc.Text(
        "Auto \u2014 max nodes from Port Authority push (no data yet)",
        size="xs",
        c="dimmed",
        fs="italic",
    )


# ── v15.2 Task4: PA Source Summary callback ──────────────────────────────────
@callback(
    Output("dash-pa-source-summary", "children"),
    Input("pipeline-state", "data"),
    Input("dash-init", "n_intervals"),  # v15.17: re-fire on every page nav
    Input("global-refresh-ts", "data"),  # v15.17: re-fire on global refresh
    prevent_initial_call=False,
)
def update_pa_source_summary(_state, _init, _grt):
    """Populate the PA push summary card in pipeline control panel.

    v15.9 FIX: When no explicit PA push has occurred (server restart / reload),
    synthesise the summary from live pipeline state so the card always shows
    meaningful information after any successful pipeline run instead of a
    permanent 'No data pushed' placeholder.
    """
    pipeline = get_pipeline()
    summary = getattr(pipeline, "_pa_push_summary", None)

    if not summary:
        # ── Fallback: synthesise from live pipeline state ──────────────────
        tables = getattr(pipeline, "tables", None) or {}
        meta = getattr(pipeline, "last_run_meta", None) or {}
        scored = getattr(pipeline, "scored_df", None)

        # Nothing at all — truly no data yet
        has_data = (
            bool(tables) or bool(meta.get("customers")) or (scored is not None and len(scored) > 0)
        )
        if not has_data:
            # v15.15 TASK 1: If data is staged (Port Authority) but pipeline not yet run,
            # show a "Data Summary" card so user can confirm what data is loaded.
            _staged = getattr(pipeline, "_staged_tables", None) or {}
            if _staged:
                _stg_names = list(_staged.keys())
                _stg_rows = sum(len(v) for v in _staged.values() if v is not None)
                _stg_nodes = next(
                    (
                        len(_staged[k])
                        for k in ("node", "customer", "account", "node_features")
                        if _staged.get(k) is not None
                    ),
                    _stg_rows,
                )
                return dmc.Stack(
                    [
                        dmc.Group(
                            [
                                DashIconify(icon="mdi:database-import", width=16, color="#00B0FF"),
                                dmc.Text("Data Summary", size="xs", fw=600, c="white"),
                                dmc.Badge("STAGED", color="blue", variant="light", size="xs"),
                                dmc.Badge("READY TO RUN", color="cyan", variant="light", size="xs"),
                            ],
                            gap=4,
                        ),
                        dmc.SimpleGrid(
                            cols=3,
                            spacing="xs",
                            children=[
                                dmc.Stack(
                                    [
                                        dmc.Text("Entities", size="xs", c="dimmed"),
                                        dmc.Text(f"{_stg_nodes:,}", fw=700, c="white", size="sm"),
                                    ],
                                    gap=0,
                                    align="center",
                                ),
                                dmc.Stack(
                                    [
                                        dmc.Text("Total Rows", size="xs", c="dimmed"),
                                        dmc.Text(f"{_stg_rows:,}", fw=700, c="white", size="sm"),
                                    ],
                                    gap=0,
                                    align="center",
                                ),
                                dmc.Stack(
                                    [
                                        dmc.Text("Tables", size="xs", c="dimmed"),
                                        dmc.Text(
                                            f"{len(_stg_names)}", fw=700, c="white", size="sm"
                                        ),
                                    ],
                                    gap=0,
                                    align="center",
                                ),
                            ],
                        ),
                        dmc.Text(
                            "Tables: " + ", ".join(_stg_names),
                            size="xs",
                            c="dimmed",
                            style={"fontSize": "10px", "lineHeight": "1.3"},
                        ),
                        dmc.Text(
                            "▶ Press Run Pipeline to generate AML scores from this data",
                            size="xs",
                            c="#00B0FF",
                            fs="italic",
                            style={"fontSize": "10px"},
                        ),
                    ],
                    gap=4,
                    style={
                        "backgroundColor": "rgba(0,176,255,0.04)",
                        "border": "1px solid rgba(0,176,255,0.15)",
                        "borderRadius": "6px",
                        "padding": "8px",
                    },
                )
            return dmc.Text(
                "No data pushed from Port Authority yet.", size="xs", c="dimmed", fs="italic"
            )

        # Build a synthetic summary dict matching the PA-push schema
        n_nodes = meta.get("customers", 0) or (len(scored) if scored is not None else 0)
        n_edges = meta.get("graph_edges", 0)
        table_names = list(tables.keys()) if tables else (meta.get("selected_tables") or [])
        total_rows = (
            sum(len(v) for v in tables.values() if v is not None)
            if tables
            else meta.get("total_rows", 0)
        )
        saved_at = meta.get("saved_at", "") or meta.get("run_at", "")
        data_mode = getattr(pipeline, "_data_mode", None) or meta.get("data_mode", "unknown")
        seed = meta.get("seed", "—")

        summary = {
            "pushed_at": saved_at,
            "tables": table_names,
            "total_rows": total_rows,
            "n_nodes": n_nodes,
            "data_mode": data_mode,
            "seed": seed,
            "source_type": "pipeline",  # distinguishes from explicit PA push
        }
        # ── End fallback ──────────────────────────────────────────────────

    pushed_at = summary.get("pushed_at", "")
    try:
        from datetime import datetime as _dt

        pushed_at = _dt.fromisoformat(pushed_at).strftime("%d %b %Y %H:%M")
    except Exception:
        pass

    tables = summary.get("tables", [])
    total_rows = summary.get("total_rows", 0)
    n_nodes = summary.get("n_nodes", 0)
    data_mode = summary.get("data_mode", "unknown")
    seed = summary.get("seed", "—")
    source_type = summary.get("source_type", "sample")

    mode_color = "cyan" if data_mode in ("graph", "graph_schema") else "orange"
    src_color = (
        "teal" if source_type == "actual" else ("violet" if source_type == "pipeline" else "blue")
    )

    return dmc.Stack(
        [
            dmc.Group(
                [
                    DashIconify(icon="mdi:database-check", width=16, color="#00E676"),
                    dmc.Text("Port Authority Data Source", size="xs", fw=600, c="white"),
                    dmc.Badge(data_mode.upper(), color=mode_color, variant="light", size="xs"),
                    dmc.Badge(source_type.upper(), color=src_color, variant="light", size="xs"),
                ],
                gap=4,
            ),
            dmc.SimpleGrid(
                cols=3,
                spacing="xs",
                children=[
                    dmc.Stack(
                        [
                            dmc.Text("Nodes / Entities", size="xs", c="dimmed"),
                            dmc.Text(f"{n_nodes:,}", fw=700, c="white", size="sm"),
                        ],
                        gap=0,
                        align="center",
                    ),
                    dmc.Stack(
                        [
                            dmc.Text("Total Rows", size="xs", c="dimmed"),
                            dmc.Text(f"{total_rows:,}", fw=700, c="white", size="sm"),
                        ],
                        gap=0,
                        align="center",
                    ),
                    dmc.Stack(
                        [
                            dmc.Text("Tables", size="xs", c="dimmed"),
                            dmc.Text(f"{len(tables)}", fw=700, c="white", size="sm"),
                        ],
                        gap=0,
                        align="center",
                    ),
                ],
            ),
            dmc.SimpleGrid(
                cols=2,
                spacing="xs",
                children=[
                    dmc.Stack(
                        [
                            dmc.Text("Seed", size="xs", c="dimmed"),
                            dmc.Text(f"{seed}", fw=600, c="#7B2FBE", size="xs"),
                        ],
                        gap=0,
                        align="center",
                    ),
                    dmc.Stack(
                        [
                            dmc.Text("Pushed", size="xs", c="dimmed"),
                            dmc.Text(pushed_at, fw=600, c="dimmed", size="xs"),
                        ],
                        gap=0,
                        align="center",
                    ),
                ],
            ),
            dmc.Text(
                "Tables: " + ", ".join(tables),
                size="xs",
                c="dimmed",
                style={"fontSize": "10px", "lineHeight": "1.3"},
            ),
        ],
        gap=4,
        style={
            "backgroundColor": "rgba(0,230,118,0.04)",
            "border": "1px solid rgba(0,230,118,0.15)",
            "borderRadius": "6px",
            "padding": "8px",
        },
    )

# =============================================================================
# v16.53 — Risk Analysis Table Suite callback
# =============================================================================
# Separate callback (independent of init_dashboard) so the 4-table suite
# refreshes whenever the pipeline-state store is updated OR on page load,
# without touching the existing large init_dashboard callback.
# Data source: live pipeline singleton (scored_df + analytics_results).
# =============================================================================

@callback(
    Output("dash-risk-tables-section", "children"),
    Input("dash-init", "n_intervals"),
    Input("pipeline-state", "data"),
    prevent_initial_call=False,
)
def cb_risk_tables(_, pipeline_state):  # noqa: ANN001
    """Populate the 4 AG Grid risk-analysis tables from the live pipeline singleton.

    Triggered by:
      - page load  (dash-init fires once)
      - pipeline completion  (pipeline-state store updated by run callback)

    Returns a fully rendered html.Div with Tables 1–4, or a placeholder if no
    scored results are available yet.
    """
    pipeline = get_pipeline()
    return build_risk_tables_section(pipeline)