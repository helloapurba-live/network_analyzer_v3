"""
Page: Network Intelligence (v12.22 — CEO / Business Presentation Format)
=========================================================================
BUSINESS PURPOSE:
  This page reveals hidden money-movement patterns between bank customers.
  Every element is designed for a non-technical audience — the Global AML
  Head, CEO, and board-level compliance officers. Each section explains
  WHY the analysis matters and WHAT to do about findings.

All V12.17 pipeline-mapping preserved:
  - pipeline_done bypass (is_running race fix)
  - max_intervals=-1 (unlimited polling)
  - LIVE DATA badges with run version
  - Positive empty framing for clean networks

V12.19 additions:
  - Customer NAMES shown instead of IDs (first name + last 4 of ID)
  - Business-language section headers explaining PURPOSE of each analysis
  - P1/P2/P3/P4 priority legend always visible with business actions
  - Network graph: multi-ring layout, tier-colored, proportional sizing,
    customer names on high-risk nodes, full legend
  - CEO-presentable table column headers and in-report legends

V12.20 ROOT-CAUSE FIX — Transaction Network Topology BLANK:
  ROOT CAUSE: l3_graph.py converts NaN attribute values to Python None
  when building the NetworkX graph (pd.isna(val) → None). Then in the
  NI page, G.nodes[n].get('in_flow', 0) returns None — not 0 — because
  the key IS present with value None. f-string ':.1f'/':,.0f' then
  throws TypeError on None, silently crashing the whole callback →
  blank graph returned to the browser.
  FIX: All node attribute reads now use _safe_float() / _safe_int()
  which coerce None / NaN / missing → 0 safely before formatting.
  ALSO FIXED IN V12.20:
  - try/except wraps entire live graph build code (prevents silent blank)
  - Improved edge visibility: opacity 0.35, width 1.0 (was invisible)
  - Explicit height=500 in figure layout (Plotly requires this, not HTML)
  - uirevision='network-topology' prevents resets on poll intervals
  - Larger min node size (8 vs 6) for better visibility at low risk scores
  - Spring layout (nx.spring_layout) with ring-tier positioning fallback

V12.21 FIXES:
  TASK1 — cycle_data TypeError: c['avg_risk']/c['risk_sum']/c['total_amount'] were
  formatted with ':.1f' OUTSIDE the graph try/except → crashed entire callback
  → blank graph. Fix: wrapped with _safe_float() / _safe_float().
  TASK3/4 — Added business P1-P4 explanation panel to each chart section.
  TASK5 — Customer name lookup applied consistently throughout.
"""

import dash
from dash import html, dcc, callback, Input, Output, State, no_update, dash_table
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.graph_objects as go
import pandas as pd
import networkx as nx
import json
import math
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, APP
from engine import get_pipeline

dash.register_page(
    __name__,
    path="/network-intelligence",
    name="Network Intelligence",
    title=f"FCDAI v{APP.VERSION} | Network Intelligence",
)


def _safe_float(val, default=0.0) -> float:
    """V12.20 FIX: Safely convert potentially-None/NaN node attribute to float.
    l3_graph.py sets pd.isna() attributes to None, so .get(key, 0) returns
    None (key present, value None) — this coerces safely to 0.0.
    """
    if val is None:
        return default
    try:
        f = float(val)
        import math

        return default if math.isnan(f) or math.isinf(f) else f
    except (TypeError, ValueError):
        return default


def _safe_int(val, default=0) -> int:
    """V12.20 FIX: Safely convert potentially-None/NaN node attribute to int."""
    return int(_safe_float(val, default))


# ═══════════════════════════════════════════════════════════════════════════════
# CONSTANTS
# ═══════════════════════════════════════════════════════════════════════════════

TIER_COLORS = {"P1": "#FF1744", "P2": "#FF9800", "P3": "#FFD600", "P4": "#00E676"}

# Business-friendly tier explanations
TIER_LABELS = {
    "P1": (
        "CRITICAL",
        "80–100",
        "Freeze & Investigate — Highest probability of financial crime. Account should be frozen pending investigation.",
    ),
    "P2": (
        "HIGH RISK",
        "60–79",
        "Enhanced Due Diligence — Significant suspicious patterns detected. Requires immediate senior analyst review.",
    ),
    "P3": (
        "MEDIUM",
        "40–59",
        "Active Monitoring — Some unusual activity warrants ongoing attention. Escalate if patterns persist.",
    ),
    "P4": (
        "LOW",
        "0–39",
        "Normal Operations — No significant concerns. Standard transaction monitoring continues.",
    ),
}

# Business-friendly stat labels
_STAT_BUSINESS_LABELS = {
    "nodes": "Customers Analyzed",
    "edges": "Transaction Links",
    "density": "Network Connectivity",
    "avg_in_degree": "Avg Incoming Connections",
    "avg_out_degree": "Avg Outgoing Connections",
    "components": "Separate Customer Groups",
    "is_dag": "Contains Circular Flows",
}

_STAT_BUSINESS_ICONS = {
    "nodes": ("mdi:account-network", "#00D4FF"),
    "edges": ("mdi:connection", "#9D4EDD"),
    "density": ("mdi:chart-scatter-plot", "#FFD600"),
    "avg_in_degree": ("mdi:arrow-collapse-right", "#00E676"),
    "avg_out_degree": ("mdi:arrow-expand-right", "#FF9800"),
    "components": ("mdi:view-module-outline", "#2196F3"),
    "is_dag": ("mdi:vector-polyline", "#E040FB"),
}

DARK_TEMPLATE = dict(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(0,0,0,0)",
    font=dict(color="#94A3B8", size=11),
    margin=dict(l=40, r=20, t=30, b=40),
    xaxis=dict(gridcolor="rgba(255,255,255,0.05)"),
    yaxis=dict(gridcolor="rgba(255,255,255,0.05)"),
)

_TH = {
    "backgroundColor": "#111827",
    "color": "#94A3B8",
    "fontWeight": "600",
    "border": "1px solid #1E293B",
}
_TC = {
    "backgroundColor": "#0A0E17",
    "color": "#E2E8F0",
    "border": "1px solid #1E293B",
    "fontSize": "11px",
    "padding": "6px",
}

_SEC = dict(
    p="xl",
    radius="lg",
    className="glass-card",
    mb="lg",
    style={"border": "1px solid rgba(255,255,255,0.06)"},
)

# Sample customer names for default/baseline data
_SAMPLE_NAMES = {
    "CUST-0847": "David Chen",
    "CUST-1204": "Maria Santos",
    "CUST-0553": "James Wilson",
    "CUST-0912": "Elena Kowalski",
    "CUST-1531": "Robert Nguyen",
    "CUST-0776": "Sarah Ahmed",
    "CUST-0234": "Michael Park",
    "CUST-0891": "Linda Torres",
    "CUST-1345": "Thomas Brown",
    "CUST-0667": "Priya Sharma",
    "CUST-1488": "Carlos Mendez",
    "CUST-1789": "Anna Volkov",
    "CUST-0445": "Kevin O'Brien",
    "CUST-1267": "Yuki Tanaka",
    "CUST-0923": "Fatima Hassan",
    "CUST-1055": "Daniel Berg",
    "CUST-0398": "Sophie Laurent",
    "CUST-1102": "Hassan Ali",
    "CUST-0612": "Jennifer Kim",
}


# ═══════════════════════════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════════════════════════


def empty_fig(msg="Run pipeline first"):
    fig = go.Figure()
    fig.add_annotation(text=msg, showarrow=False, font=dict(color="#64748B", size=14))
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=20, r=20, t=20, b=20),
    )
    return fig


def _hex_to_rgb(hex_color):
    """#RRGGBB → 'R,G,B' string for use in rgba()."""
    h = hex_color.lstrip("#")
    return f"{int(h[0:2], 16)},{int(h[2:4], 16)},{int(h[4:6], 16)}"


def _sn(cust_id):
    """Sample display name for default/baseline data: 'FirstName (…last4)'."""
    name = _SAMPLE_NAMES.get(cust_id, cust_id)
    first = name.split()[0] if " " in name else name
    short = cust_id[-4:] if len(cust_id) >= 4 else cust_id
    return f"{first} (…{short})"


def _build_name_map(pipeline):
    """Build {node_id → display_name} dict once for efficient lookups."""
    nm = {}
    cust_df = pipeline.tables.get("customer") if hasattr(pipeline, "tables") else None
    if cust_df is not None and len(cust_df) > 0 and "customer_id" in cust_df.columns:
        # v12.22 PERF-01 FIX: vectorized zip instead of iterrows() — 10-100x faster at scale
        _nc = next((c for c in ("customer_name", "name") if c in cust_df.columns), None)
        if _nc:
            for cid, name in zip(cust_df["customer_id"].astype(str), cust_df[_nc].fillna("")):
                if name:
                    first = str(name).split()[0]
                    short = cid[-4:] if len(cid) >= 4 else cid
                    nm[cid] = f"{first} (…{short})"
    G = pipeline.G
    if G:
        for nid in G.nodes():
            if nid not in nm:
                attrs = G.nodes[nid]
                name = attrs.get("customer_name", "") or attrs.get("name", "")
                if name:
                    first = str(name).split()[0]
                    s_nid = str(
                        nid
                    )  # v12.23 TASK3 FIX: str() before slicing — integer node IDs raise TypeError
                    short = s_nid[-4:] if len(s_nid) >= 4 else s_nid
                    nm[nid] = f"{first} (…{short})"
    return nm


def _dn(name_map, node_id):
    """Quick display-name lookup with fallback."""
    if node_id in name_map:
        return name_map[node_id]
    s = str(node_id)
    return f"Cust …{s[-4:]}" if len(s) > 8 else s


def _risk_tier_legend():
    """Always-visible risk priority legend bar — explains P1-P4 to business users."""
    items = []
    for code in ("P1", "P2", "P3", "P4"):
        label, score_range, desc = TIER_LABELS[code]
        color = TIER_COLORS[code]
        items.append(
            dmc.Group(
                [
                    html.Div(
                        style={
                            "width": "12px",
                            "height": "12px",
                            "borderRadius": "50%",
                            "backgroundColor": color,
                            "flexShrink": "0",
                            "border": "1px solid rgba(255,255,255,0.3)",
                        }
                    ),
                    dmc.Text(f"{code} {label}", fw=600, c=color, size="xs"),
                    dmc.Text(
                        f"(Score {score_range}): {desc}",
                        size="xs",
                        c="dimmed",
                        style={"maxWidth": "320px"},
                    ),
                ],
                gap=4,
                wrap="nowrap",
            ),
        )
    return dmc.Paper(
        dmc.Stack(
            [
                dmc.Group(
                    [
                        DashIconify(icon="mdi:shield-alert", width=18, color="#94A3B8"),
                        dmc.Text(
                            "Risk Priority Classification — What the Colours Mean",
                            fw=600,
                            c="white",
                            size="sm",
                        ),
                    ],
                    gap="sm",
                ),
                dmc.SimpleGrid(cols={"base": 1, "md": 2}, spacing="xs", children=items),
            ],
            gap="sm",
        ),
        p="md",
        radius="md",
        mb="lg",
        style={"background": "rgba(17,24,39,0.8)", "border": "1px solid rgba(255,255,255,0.08)"},
    )


def _section_header(icon, icon_color, title, purpose, extra=None):
    """Section header with icon, title, and business-purpose explanation."""
    children = [
        dmc.Stack(
            [
                dmc.Group(
                    [
                        DashIconify(icon=icon, width=24, color=icon_color),
                        dmc.Text(title, fw=700, c="white", size="lg"),
                    ]
                    + (extra or []),
                    gap="sm",
                ),
                dmc.Text(
                    purpose, size="xs", c="dimmed", style={"maxWidth": "900px", "lineHeight": "1.5"}
                ),
            ],
            gap=4,
        ),
    ]
    return html.Div(children, style={"marginBottom": "12px"})


def _stats_to_kpi(stats, pipeline_done=False, run_ver=""):
    """Convert network stats dict → executive KPI card strip with business labels."""
    if not stats:
        return dmc.Text("No network statistics available", c="dimmed", size="sm")

    cards = []
    for key, value in list(stats.items())[:7]:
        biz_label = _STAT_BUSINESS_LABELS.get(key, key.replace("_", " ").title())
        icon, color = _STAT_BUSINESS_ICONS.get(key, ("mdi:information-outline", "#00D4FF"))

        # Format value with business context
        if key == "is_dag":
            val_str = "No ✓ (loops found)" if not value else "Yes — No loops"
        elif isinstance(value, float):
            val_str = f"{value:.4f}" if abs(value) < 1 else f"{value:,.2f}"
        elif isinstance(value, int):
            val_str = f"{value:,}"
        else:
            val_str = str(value)

        badge = None
        if pipeline_done:
            badge = dmc.Badge(
                f"LIVE — #{run_ver}" if run_ver else "LIVE",
                color="green",
                variant="light",
                size="xs",
            )

        cards.append(
            dmc.Paper(
                dmc.Stack(
                    [
                        DashIconify(icon=icon, width=22, color=color),
                        dmc.Text(
                            val_str,
                            fw=700,
                            c="white",
                            style={"fontSize": "1.1rem", "lineHeight": "1"},
                        ),
                        dmc.Text(biz_label, size="xs", c="dimmed"),
                    ]
                    + ([badge] if badge else []),
                    gap=4,
                    align="center",
                ),
                p="xs",
                radius="lg",
                style={
                    "textAlign": "center",
                    "background": f"linear-gradient(180deg, rgba({_hex_to_rgb(color)},0.06) 0%, rgba(10,14,23,0.95) 100%)",
                    "border": f"1px solid rgba({_hex_to_rgb(color)},0.15)",
                },
            )
        )

    return dmc.SimpleGrid(
        cols={"base": 2, "sm": 4, "lg": 7}, spacing="xs", children=cards
    )


# ═══════════════════════════════════════════════════════════════════════════════
# DEFAULT FUNCTIONS — Pre-pipeline CEO-ready content with customer names
# ═══════════════════════════════════════════════════════════════════════════════


def _default_network_overview():
    """Build 5 CEO-ready defaults with customer names for pre-pipeline state.

    Returns: (cycles_table, cycle_count, nodes_table, network_graph_fig, stats_kpi)
    """

    # ── 1. SUSPICIOUS CYCLES TABLE (with names) ──
    sample_cycles = [
        {
            "#": 1,
            "Length": 4,
            "Started By": _sn("CUST-0847"),
            "Total Money Moved": "$1,247,500",
            "Avg Risk Score": "72.3",
            "Combined Risk": "289.2",
            "Money Path": f"{_sn('CUST-0847')} → {_sn('CUST-1204')} → {_sn('CUST-0553')} → {_sn('CUST-0912')}",
        },
        {
            "#": 2,
            "Length": 3,
            "Started By": _sn("CUST-1531"),
            "Total Money Moved": "$893,200",
            "Avg Risk Score": "65.8",
            "Combined Risk": "197.4",
            "Money Path": f"{_sn('CUST-1531')} → {_sn('CUST-0776')} → {_sn('CUST-1102')}",
        },
        {
            "#": 3,
            "Length": 5,
            "Started By": _sn("CUST-0234"),
            "Total Money Moved": "$2,150,000",
            "Avg Risk Score": "81.5",
            "Combined Risk": "407.5",
            "Money Path": f"{_sn('CUST-0234')} → {_sn('CUST-0891')} → {_sn('CUST-1345')} → {_sn('CUST-0667')} → {_sn('CUST-1488')}",
        },
        {
            "#": 4,
            "Length": 3,
            "Started By": _sn("CUST-0612"),
            "Total Money Moved": "$456,800",
            "Avg Risk Score": "58.2",
            "Combined Risk": "174.6",
            "Money Path": f"{_sn('CUST-0612')} → {_sn('CUST-1055')} → {_sn('CUST-0398')}",
        },
        {
            "#": 5,
            "Length": 4,
            "Started By": _sn("CUST-1789"),
            "Total Money Moved": "$1,834,000",
            "Avg Risk Score": "77.1",
            "Combined Risk": "308.4",
            "Money Path": f"{_sn('CUST-1789')} → {_sn('CUST-0445')} → {_sn('CUST-1267')} → {_sn('CUST-0923')}",
        },
    ]
    cycles_default = dmc.Stack(
        [
            dmc.Group(
                [
                    dmc.Badge("BASELINE REFERENCE", color="blue", variant="light", size="sm"),
                    dmc.Text(
                        "Sample cycle patterns — live data replaces after pipeline execution",
                        size="xs",
                        c="dimmed",
                    ),
                ],
                gap="sm",
            ),
            dash_table.DataTable(
                columns=[{"name": k, "id": k} for k in sample_cycles[0].keys()],
                data=sample_cycles,
                page_size=10,
                style_header=_TH,
                style_cell=_TC,
                style_data_conditional=[
                    {"if": {"filter_query": "{Avg Risk Score} > 70"}, "color": "#FF1744"},
                    {"if": {"filter_query": "{Avg Risk Score} > 55"}, "color": "#FF9800"},
                ],
                sort_action="native",
            ),
            dmc.Text(
                "💡 Reading Guide: Each row is a detected circular money flow. "
                "'Started By' is the customer who initiated the loop. "
                "'Avg Risk Score' above 70 (red) = Critical, 55-70 (orange) = High Risk.",
                size="xs",
                c="dimmed",
                mt="xs",
                style={"fontStyle": "italic", "lineHeight": "1.5"},
            ),
        ],
        gap="xs",
    )

    # ── 2. CYCLE COUNT ──
    count_default = "Pre-Analysis"

    # ── 3. KEY ENTITIES TABLE (with names and business headers) ──
    sample_nodes = [
        {
            "Customer": _sn("CUST-0847"),
            "Customer ID": "CUST-0847",
            "Overall Score": "0.9412",
            "Network Influence": "0.0847",
            "Bridge Score": "0.3215",
            "Risk Score": "87.3",
            "Priority": "P1",
            "Money In": "$2,450,000",
            "Money Out": "$2,180,000",
            "In/Out Ratio": "1.124",
        },
        {
            "Customer": _sn("CUST-1531"),
            "Customer ID": "CUST-1531",
            "Overall Score": "0.8876",
            "Network Influence": "0.0723",
            "Bridge Score": "0.2891",
            "Risk Score": "79.6",
            "Priority": "P1",
            "Money In": "$1,890,000",
            "Money Out": "$1,920,000",
            "In/Out Ratio": "0.984",
        },
        {
            "Customer": _sn("CUST-0234"),
            "Customer ID": "CUST-0234",
            "Overall Score": "0.8234",
            "Network Influence": "0.0612",
            "Bridge Score": "0.2456",
            "Risk Score": "72.1",
            "Priority": "P2",
            "Money In": "$1,345,000",
            "Money Out": "$1,567,000",
            "In/Out Ratio": "0.858",
        },
        {
            "Customer": _sn("CUST-0912"),
            "Customer ID": "CUST-0912",
            "Overall Score": "0.7891",
            "Network Influence": "0.0534",
            "Bridge Score": "0.2123",
            "Risk Score": "68.4",
            "Priority": "P2",
            "Money In": "$987,000",
            "Money Out": "$1,120,000",
            "In/Out Ratio": "0.881",
        },
        {
            "Customer": _sn("CUST-1789"),
            "Customer ID": "CUST-1789",
            "Overall Score": "0.7456",
            "Network Influence": "0.0489",
            "Bridge Score": "0.1987",
            "Risk Score": "64.7",
            "Priority": "P2",
            "Money In": "$756,000",
            "Money Out": "$834,000",
            "In/Out Ratio": "0.906",
        },
        {
            "Customer": _sn("CUST-0776"),
            "Customer ID": "CUST-0776",
            "Overall Score": "0.6923",
            "Network Influence": "0.0412",
            "Bridge Score": "0.1654",
            "Risk Score": "55.2",
            "Priority": "P3",
            "Money In": "$534,000",
            "Money Out": "$612,000",
            "In/Out Ratio": "0.873",
        },
    ]
    nodes_default = dmc.Stack(
        [
            dmc.Group(
                [
                    dmc.Badge("BASELINE REFERENCE", color="blue", variant="light", size="sm"),
                    dmc.Text(
                        "Sample customer importance ranking — live scores populate after pipeline",
                        size="xs",
                        c="dimmed",
                    ),
                ],
                gap="sm",
            ),
            dash_table.DataTable(
                columns=[{"name": k, "id": k} for k in sample_nodes[0].keys()],
                data=sample_nodes,
                page_size=15,
                style_header=_TH,
                style_cell=_TC,
                style_data_conditional=[
                    {
                        "if": {"column_id": "Priority", "filter_query": '{Priority} = "P1"'},
                        "color": "#FF1744",
                        "fontWeight": "bold",
                    },
                    {
                        "if": {"column_id": "Priority", "filter_query": '{Priority} = "P2"'},
                        "color": "#FF9800",
                    },
                ],
                sort_action="native",
            ),
            dmc.Text(
                "💡 Column Guide: "
                "Network Influence = how much money flows through this customer (PageRank). "
                "Bridge Score = does this customer connect otherwise separate groups (Betweenness). "
                "In/Out Ratio > 1 means more money flows IN than OUT.",
                size="xs",
                c="dimmed",
                mt="xs",
                style={"fontStyle": "italic", "lineHeight": "1.5"},
            ),
        ],
        gap="xs",
    )

    # ── 4. NETWORK GRAPH: Named multi-cluster topology ──
    fig = go.Figure()
    clusters = [
        {
            "cx": -2,
            "cy": 1,
            "label": "🔴 Critical Risk (P1 — Freeze & Investigate)",
            "color": "#FF1744",
            "nodes": ["CUST-0847", "CUST-1531", "CUST-0234", "CUST-0912", "CUST-1789"],
            "r": 0.8,
        },
        {
            "cx": 1.5,
            "cy": 1.5,
            "label": "🟠 High Risk (P2 — Enhanced Screening)",
            "color": "#FF9800",
            "nodes": ["CUST-1204", "CUST-0553", "CUST-0891", "CUST-0667", "CUST-1345", "CUST-1488"],
            "r": 0.9,
        },
        {
            "cx": 0,
            "cy": -1.5,
            "label": "🟢 Low Risk (P3/P4 — Standard Monitoring)",
            "color": "#00E676",
            "nodes": [
                "CUST-0776",
                "CUST-0445",
                "CUST-1267",
                "CUST-0923",
                "CUST-1055",
                "CUST-0398",
                "CUST-1102",
            ],
            "r": 1.0,
        },
    ]
    all_pos = {}
    for cl in clusters:
        n = len(cl["nodes"])
        for i, node in enumerate(cl["nodes"]):
            angle = 2 * math.pi * i / n - math.pi / 2
            all_pos[node] = (
                cl["cx"] + cl["r"] * math.cos(angle),
                cl["cy"] + cl["r"] * math.sin(angle),
            )
    # Intra-cluster edges
    for cl in clusters:
        nodes = cl["nodes"]
        edge_x, edge_y = [], []
        for i in range(len(nodes)):
            x0, y0 = all_pos[nodes[i]]
            x1, y1 = all_pos[nodes[(i + 1) % len(nodes)]]
            edge_x.extend([x0, x1, None])
            edge_y.extend([y0, y1, None])
            if i < len(nodes) - 2:
                x0b, y0b = all_pos[nodes[i]]
                x1b, y1b = all_pos[nodes[i + 2]]
                edge_x.extend([x0b, x1b, None])
                edge_y.extend([y0b, y1b, None])
        fig.add_trace(
            go.Scatter(
                x=edge_x,
                y=edge_y,
                mode="lines",
                line=dict(color=f"{cl['color']}40", width=1),
                hoverinfo="skip",
                showlegend=False,
            )
        )
    # Cross-cluster suspicious edges
    cross_edges = [
        ("CUST-0234", "CUST-1204", "#9D4EDD"),
        ("CUST-1789", "CUST-0398", "#9D4EDD"),
        ("CUST-1488", "CUST-1055", "#9D4EDD"),
        ("CUST-0553", "CUST-0847", "#9D4EDD"),
    ]
    for u, v, color in cross_edges:
        x0, y0 = all_pos.get(u, (0, 0))
        x1, y1 = all_pos.get(v, (0, 0))
        fig.add_trace(
            go.Scatter(
                x=[x0, x1, None],
                y=[y0, y1, None],
                mode="lines",
                line=dict(color=color, width=2, dash="dash"),
                hoverinfo="skip",
                showlegend=False,
            )
        )
    # Add dummy trace for cross-cluster legend
    fig.add_trace(
        go.Scatter(
            x=[None],
            y=[None],
            mode="lines",
            line=dict(color="#9D4EDD", width=2, dash="dash"),
            name="⚠ Cross-Group Transaction (Suspicious)",
        )
    )
    # Nodes per cluster (with first names)
    for cl in clusters:
        node_x = [all_pos[n][0] for n in cl["nodes"]]
        node_y = [all_pos[n][1] for n in cl["nodes"]]
        display_names = [_sn(n) for n in cl["nodes"]]
        fig.add_trace(
            go.Scatter(
                x=node_x,
                y=node_y,
                mode="markers+text",
                marker=dict(
                    color=cl["color"], size=12, opacity=0.85, line=dict(color="white", width=1)
                ),
                text=[_SAMPLE_NAMES.get(n, n).split()[0] for n in cl["nodes"]],
                textposition="top center",
                textfont=dict(size=9, color=cl["color"]),
                name=cl["label"],
                hovertemplate=[
                    f"<b>{display_names[i]}</b><br>ID: {cl['nodes'][i]}<extra>{cl['label']}</extra>"
                    for i in range(len(cl["nodes"]))
                ],
            )
        )
    fig.add_annotation(
        text="Reference Network Topology — Demonstrating P1/P2/P3 risk clusters and cross-group transactions",
        x=0,
        y=-3,
        showarrow=False,
        font=dict(color="#475569", size=10),
    )
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color="#94A3B8", size=11),
        margin=dict(l=20, r=20, t=30, b=50),
        xaxis=dict(showgrid=False, zeroline=False, showticklabels=False, range=[-3.5, 3.5]),
        yaxis=dict(showgrid=False, zeroline=False, showticklabels=False, range=[-3.2, 3]),
        legend=dict(
            font=dict(color="#94A3B8", size=10),
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="center",
            x=0.5,
        ),
        showlegend=True,
    )

    # ── 5. STATS KPI STRIP (pre-pipeline baseline) ──
    pre_stats = [
        ("Customers Analyzed", "0", "mdi:account-network", "#00D4FF"),
        ("Transaction Links", "0", "mdi:connection", "#9D4EDD"),
        ("Network Connectivity", "0.0000", "mdi:chart-scatter-plot", "#FFD600"),
        ("Avg Connections Per Customer", "0.00", "mdi:arrow-collapse-right", "#00E676"),
        ("Separate Customer Groups", "—", "mdi:view-module-outline", "#2196F3"),
    ]
    kpi_cards = []
    for label, value, icon, color in pre_stats:
        kpi_cards.append(
            dmc.Paper(
                dmc.Stack(
                    [
                        DashIconify(icon=icon, width=28, color=color),
                        dmc.Text(
                            value,
                            fw=700,
                            c="white",
                            style={"fontSize": "1.4rem", "lineHeight": "1"},
                        ),
                        dmc.Text(label, size="xs", c="dimmed"),
                        dmc.Badge("PRE-ANALYSIS", color="blue", variant="light", size="xs"),
                    ],
                    gap=4,
                    align="center",
                ),
                p="md",
                radius="lg",
                style={
                    "textAlign": "center",
                    "background": f"linear-gradient(180deg, rgba({_hex_to_rgb(color)},0.06) 0%, rgba(10,14,23,0.95) 100%)",
                    "border": f"1px solid rgba({_hex_to_rgb(color)},0.15)",
                },
            )
        )
    stats_default = dmc.Stack(
        [
            dmc.SimpleGrid(cols={"base": 2, "sm": 3, "lg": 5}, spacing="md", children=kpi_cards),
            dmc.Text(
                "Industry Benchmarks: Typical AML network 200–5,000 nodes · "
                "Suspicious density threshold > 0.015 · Flag if avg degree > 4.0",
                size="xs",
                c="dimmed",
                ta="center",
                mt="xs",
            ),
        ],
        gap="xs",
    )

    return cycles_default, count_default, nodes_default, fig, stats_default


def _default_view2_content():
    """Build 2 CEO-ready defaults for Deep Dive: cycle_detail, metrics_table."""

    # ── 1. CYCLE DETAIL (with names) ──
    cycle_detail = dmc.Stack(
        [
            dmc.Group(
                [
                    dmc.Badge("REFERENCE EXAMPLE", color="blue", variant="light", size="sm"),
                    dmc.Badge("Cycle #1", color="red", size="lg"),
                    dmc.Badge("4 customers", color="cyan", variant="light"),
                    dmc.Badge(f"Started by: {_sn('CUST-0847')}", color="orange", variant="light"),
                    dmc.Badge("Total: $1,247,500", color="green", variant="light"),
                    dmc.Badge("Avg Risk: 72.3 (P2)", color="yellow", variant="light"),
                ],
                gap="xs",
                mb="sm",
            ),
            dmc.Text(
                f"Money Path: {_sn('CUST-0847')} → {_sn('CUST-1204')} → "
                f"{_sn('CUST-0553')} → {_sn('CUST-0912')} → back to {_sn('CUST-0847')}",
                size="sm",
                c="#00D4FF",
                mb="sm",
            ),
            dmc.SimpleGrid(
                cols={"base": 1, "md": 2},
                spacing="md",
                children=[
                    dmc.Stack(
                        [
                            dmc.Text("Customers In This Loop", fw=600, c="white", size="sm"),
                            dash_table.DataTable(
                                columns=[
                                    {"name": k, "id": k}
                                    for k in [
                                        "Customer",
                                        "Risk Score",
                                        "Priority",
                                        "Money In",
                                        "Money Out",
                                    ]
                                ],
                                data=[
                                    {
                                        "Customer": _sn("CUST-0847"),
                                        "Risk Score": "87.3",
                                        "Priority": "P1",
                                        "Money In": "$412,500",
                                        "Money Out": "$380,000",
                                    },
                                    {
                                        "Customer": _sn("CUST-1204"),
                                        "Risk Score": "71.8",
                                        "Priority": "P2",
                                        "Money In": "$380,000",
                                        "Money Out": "$356,000",
                                    },
                                    {
                                        "Customer": _sn("CUST-0553"),
                                        "Risk Score": "64.2",
                                        "Priority": "P2",
                                        "Money In": "$356,000",
                                        "Money Out": "$299,000",
                                    },
                                    {
                                        "Customer": _sn("CUST-0912"),
                                        "Risk Score": "66.0",
                                        "Priority": "P2",
                                        "Money In": "$299,000",
                                        "Money Out": "$412,500",
                                    },
                                ],
                                style_header=_TH,
                                style_cell=_TC,
                                style_data_conditional=[
                                    {
                                        "if": {
                                            "column_id": "Priority",
                                            "filter_query": '{Priority} = "P1"',
                                        },
                                        "color": "#FF1744",
                                        "fontWeight": "bold",
                                    },
                                ],
                            ),
                        ],
                        gap="xs",
                    ),
                    dmc.Stack(
                        [
                            dmc.Text("Money Flow Between Customers", fw=600, c="white", size="sm"),
                            dash_table.DataTable(
                                columns=[{"name": k, "id": k} for k in ["From", "To", "Amount"]],
                                data=[
                                    {
                                        "From": _sn("CUST-0847"),
                                        "To": _sn("CUST-1204"),
                                        "Amount": "$412,500",
                                    },
                                    {
                                        "From": _sn("CUST-1204"),
                                        "To": _sn("CUST-0553"),
                                        "Amount": "$380,000",
                                    },
                                    {
                                        "From": _sn("CUST-0553"),
                                        "To": _sn("CUST-0912"),
                                        "Amount": "$356,000",
                                    },
                                    {
                                        "From": _sn("CUST-0912"),
                                        "To": _sn("CUST-0847"),
                                        "Amount": "$299,000",
                                    },
                                ],
                                style_header=_TH,
                                style_cell=_TC,
                            ),
                        ],
                        gap="xs",
                    ),
                ],
            ),
            dmc.Text(
                "Reference example — run the pipeline to analyze live transaction data.",
                size="xs",
                c="dimmed",
                ta="center",
                mt="sm",
            ),
        ]
    )

    # ── 2. METRICS TABLE (with names) ──
    sample_scored = [
        {
            "Customer": _sn("CUST-0847"),
            "Customer ID": "CUST-0847",
            "Risk Score": "87.3",
            "Priority": "P1",
            "Network Influence": "0.0847",
            "Bridge Score": "0.3215",
            "Incoming Links": "12",
            "Outgoing Links": "9",
            "Money In": "$2,450,000",
            "Money Out": "$2,180,000",
            "Group": "C-01",
            "Anomaly Score": "0.823",
            "Overall Score": "0.9412",
        },
        {
            "Customer": _sn("CUST-1531"),
            "Customer ID": "CUST-1531",
            "Risk Score": "79.6",
            "Priority": "P1",
            "Network Influence": "0.0723",
            "Bridge Score": "0.2891",
            "Incoming Links": "10",
            "Outgoing Links": "8",
            "Money In": "$1,890,000",
            "Money Out": "$1,920,000",
            "Group": "C-01",
            "Anomaly Score": "0.756",
            "Overall Score": "0.8876",
        },
        {
            "Customer": _sn("CUST-0234"),
            "Customer ID": "CUST-0234",
            "Risk Score": "72.1",
            "Priority": "P2",
            "Network Influence": "0.0612",
            "Bridge Score": "0.2456",
            "Incoming Links": "8",
            "Outgoing Links": "7",
            "Money In": "$1,345,000",
            "Money Out": "$1,567,000",
            "Group": "C-02",
            "Anomaly Score": "0.689",
            "Overall Score": "0.8234",
        },
        {
            "Customer": _sn("CUST-0912"),
            "Customer ID": "CUST-0912",
            "Risk Score": "68.4",
            "Priority": "P2",
            "Network Influence": "0.0534",
            "Bridge Score": "0.2123",
            "Incoming Links": "7",
            "Outgoing Links": "6",
            "Money In": "$987,000",
            "Money Out": "$1,120,000",
            "Group": "C-01",
            "Anomaly Score": "0.612",
            "Overall Score": "0.7891",
        },
        {
            "Customer": _sn("CUST-1789"),
            "Customer ID": "CUST-1789",
            "Risk Score": "64.7",
            "Priority": "P2",
            "Network Influence": "0.0489",
            "Bridge Score": "0.1987",
            "Incoming Links": "6",
            "Outgoing Links": "5",
            "Money In": "$756,000",
            "Money Out": "$834,000",
            "Group": "C-03",
            "Anomaly Score": "0.534",
            "Overall Score": "0.7456",
        },
    ]
    metrics_default = dmc.Stack(
        [
            dmc.Group(
                [
                    dmc.Badge("BASELINE REFERENCE", color="blue", variant="light", size="sm"),
                    dmc.Text(
                        "Sample composite metrics — live scores populate after pipeline",
                        size="xs",
                        c="dimmed",
                    ),
                ],
                gap="sm",
            ),
            dash_table.DataTable(
                columns=[{"name": k, "id": k} for k in sample_scored[0].keys()],
                data=sample_scored,
                page_size=20,
                style_header=_TH,
                style_cell={
                    **_TC,
                    "maxWidth": "120px",
                    "overflow": "hidden",
                    "textOverflow": "ellipsis",
                },
                style_data_conditional=[
                    {
                        "if": {"column_id": "Priority", "filter_query": '{Priority} = "P1"'},
                        "color": "#FF1744",
                        "fontWeight": "bold",
                    },
                    {
                        "if": {"column_id": "Priority", "filter_query": '{Priority} = "P2"'},
                        "color": "#FF9800",
                    },
                ],
                sort_action="native",
            ),
            dmc.Text(
                "💡 Column Guide: "
                "Network Influence (PageRank) = proportion of total network flow passing through this customer. "
                "Bridge Score (Betweenness) = how often this customer sits on the shortest path between others. "
                "Anomaly Score = statistical deviation from normal customer behaviour (1.0 = most anomalous).",
                size="xs",
                c="dimmed",
                mt="xs",
                style={"fontStyle": "italic", "lineHeight": "1.5"},
            ),
        ],
        gap="xs",
    )

    return cycle_detail, metrics_default


# ═══════════════════════════════════════════════════════════════════════════════
# LAYOUT — Executive Single-Page Presentation (no tabs)
# ═══════════════════════════════════════════════════════════════════════════════

layout = dmc.Box(
    [
        dcc.Interval(id="ni-init", interval=5000, max_intervals=-1),
        # ━━━ EXECUTIVE HEADER ━━━
        dmc.Paper(
            [
                dmc.Group(
                    [
                        dmc.Group(
                            [
                                DashIconify(icon="mdi:shield-search", width=40, color="#00D4FF"),
                                dmc.Stack(
                                    [
                                        dmc.Title(
                                            "Network Intelligence",
                                            order=2,
                                            c="white",
                                            style={"letterSpacing": "0.02em"},
                                        ),
                                        dmc.Text(
                                            "Revealing hidden money-movement patterns between customers — "
                                            "who is connected to whom and why it matters",
                                            c="dimmed",
                                            size="sm",
                                        ),
                                    ],
                                    gap=0,
                                ),
                            ],
                            gap="md",
                        ),
                        dmc.Group(
                            [
                                dmc.Badge(
                                    f"v{APP.VERSION}", color="cyan", variant="outline", size="lg"
                                ),
                                dmc.Button(
                                    "⟳ Refresh",
                                    id="ni-refresh-btn",
                                    size="xs",
                                    variant="light",
                                    color="cyan",
                                    leftSection=DashIconify(icon="mdi:refresh", width=16),
                                ),
                                dcc.Link(
                                    dmc.Button(
                                        "← Dashboard", size="xs", variant="subtle", color="gray"
                                    ),
                                    href="/",
                                    style={"textDecoration": "none"},
                                ),
                                dcc.Link(
                                    dmc.Button(
                                        "Lobby Analysis →", size="xs", variant="light", color="red"
                                    ),
                                    href="/lobby-analysis",
                                    style={"textDecoration": "none"},
                                ),
                            ],
                            gap="sm",
                        ),
                    ],
                    justify="space-between",
                ),
            ],
            p="xl",
            radius="lg",
            mb="lg",
            style={
                "background": "linear-gradient(135deg, rgba(0,212,255,0.05) 0%, rgba(10,14,23,0.95) 100%)",
                "border": "1px solid rgba(0,212,255,0.15)",
            },
        ),
        # ━━━ CEO EXECUTIVE BRIEF (v12.34 TASK3/4) ━━━
        dmc.Paper(
            [
                dmc.Group(
                    [
                        DashIconify(icon="mdi:briefcase-outline", width=22, color="#00D4FF"),
                        dmc.Stack(
                            [
                                dmc.Text(
                                    "What Is This Page? — Executive Overview",
                                    fw=700,
                                    c="white",
                                    size="sm",
                                ),
                                dmc.Text(
                                    "Network Intelligence tracks the financial connections between every bank customer. "
                                    "Using transaction data, the system builds a map of money flows and automatically "
                                    "identifies dangerous patterns: circular money loops (layering), high-risk hub accounts "
                                    "(conduits), and customers connected to known suspicious networks. "
                                    "This page answers: 'Who in our customer base is part of a suspicious financial network, "
                                    "and how are they connected to each other?'",
                                    size="xs",
                                    c="dimmed",
                                    style={"lineHeight": "1.6"},
                                ),
                            ],
                            gap=4,
                        ),
                    ],
                    gap="md",
                    align="flex-start",
                ),
                dmc.Group(
                    [
                        dmc.Badge(
                            "Circular flow = money laundering layering stage",
                            color="red",
                            variant="light",
                            size="xs",
                        ),
                        dmc.Badge(
                            "Larger node = higher-risk customer",
                            color="orange",
                            variant="light",
                            size="xs",
                        ),
                        dmc.Badge(
                            "Connected clusters = potential criminal networks",
                            color="cyan",
                            variant="light",
                            size="xs",
                        ),
                        dmc.Badge(
                            "Dashed lines = suspicious cross-group transfers",
                            color="grape",
                            variant="light",
                            size="xs",
                        ),
                    ],
                    gap="xs",
                    mt="sm",
                ),
            ],
            p="md",
            radius="md",
            mb="sm",
            style={
                "background": "linear-gradient(135deg, rgba(0,212,255,0.04) 0%, rgba(10,14,23,0.95) 100%)",
                "border": "1px solid rgba(0,212,255,0.12)",
            },
        ),
        # ━━━ RISK PRIORITY LEGEND — Always visible for business users ━━━
        _risk_tier_legend(),
        # ━━━ EXECUTIVE KPI STRIP ━━━
        html.Div(id="ni-network-stats", style={"marginBottom": "1.5rem"}),
        # ━━━ TRANSACTION NETWORK TOPOLOGY ━━━
        dmc.Paper(
            [
                _section_header(
                    "mdi:graph",
                    "#00E676",
                    "Transaction Network Topology — How Customers Are Connected",
                    "This interactive map shows the web of financial relationships between bank customers. "
                    "Each circle is a customer (larger = higher risk). Lines represent money flowing between them. "
                    "Red nodes require immediate compliance attention. Dashed purple lines are suspicious cross-group "
                    "transactions where customers from different risk groups are transacting — a key money-laundering indicator.",
                    extra=[
                        dmc.Badge(
                            "Interactive — hover for customer details",
                            color="gray",
                            variant="light",
                            size="sm",
                        )
                    ],
                ),
                dcc.Graph(
                    id="ni-network-graph",
                    config={
                        "displayModeBar": True,
                        "displaylogo": False,
                        "toImageButtonOptions": {"format": "png", "scale": 2},
                    },
                    style={"height": "500px"},
                ),
            ],
            **_SEC,
        ),
        # ━━━ ADVANCED FILTERS (collapsible) ━━━
        dmc.Accordion(
            [
                dmc.AccordionItem(
                    [
                        dmc.AccordionControl(
                            dmc.Group(
                                [
                                    DashIconify(
                                        icon="mdi:filter-outline", width=18, color=THEME.PRIMARY
                                    ),
                                    dmc.Text(
                                        "Advanced Filters — Search by Customer Name or ID",
                                        fw=600,
                                        c="white",
                                        size="sm",
                                    ),
                                ],
                                gap="sm",
                            ),
                        ),
                        dmc.AccordionPanel(
                            [
                                dmc.SimpleGrid(
                                    cols={"base": 1, "md": 6},
                                    spacing="sm",
                                    children=[
                                        dmc.TextInput(
                                            id="ni-filter-custid",
                                            placeholder="Customer Name or ID...",
                                            leftSection=DashIconify(icon="mdi:magnify", width=16),
                                            styles={
                                                "input": {
                                                    "backgroundColor": THEME.DARK_BG,
                                                    "color": "white",
                                                    "border": f"1px solid {THEME.DARK_BORDER}",
                                                }
                                            },
                                        ),
                                        dmc.NumberInput(
                                            id="ni-filter-ring",
                                            placeholder="Ring #",
                                            min=1,
                                            max=100,
                                            leftSection=DashIconify(
                                                icon="mdi:circle-outline", width=16
                                            ),
                                            styles={
                                                "input": {
                                                    "backgroundColor": THEME.DARK_BG,
                                                    "color": "white",
                                                    "border": f"1px solid {THEME.DARK_BORDER}",
                                                }
                                            },
                                        ),
                                        dmc.TextInput(
                                            id="ni-filter-node",
                                            placeholder="Node ID...",
                                            leftSection=DashIconify(icon="mdi:graph", width=16),
                                            styles={
                                                "input": {
                                                    "backgroundColor": THEME.DARK_BG,
                                                    "color": "white",
                                                    "border": f"1px solid {THEME.DARK_BORDER}",
                                                }
                                            },
                                        ),
                                        # v16.23 T2: Dynamic node_type filter — populated from pipeline data
                                        dcc.Dropdown(
                                            id="ni-node-type-filter",
                                            placeholder="Node Type (entity)",
                                            options=[{"label": "All Types", "value": "ALL"}],
                                            value="ALL",
                                            clearable=False,
                                            style={
                                                "backgroundColor": THEME.DARK_BG,
                                                "color": "white",
                                                "border": f"1px solid {THEME.DARK_BORDER}",
                                                "fontSize": "12px",
                                            },
                                        ),
                                        # v16.24: node_type1 filter — Internal vs External
                                        dcc.Dropdown(
                                            id="ni-node-type1-filter",
                                            placeholder="Int / Ext",
                                            options=[
                                                {"label": "All (Int/Ext)", "value": "ALL"},
                                                {"label": "Internal", "value": "Internal"},
                                                {"label": "External", "value": "External"},
                                            ],
                                            value="ALL",
                                            clearable=False,
                                            style={
                                                "backgroundColor": THEME.DARK_BG,
                                                "color": "white",
                                                "border": f"1px solid {THEME.DARK_BORDER}",
                                                "fontSize": "12px",
                                            },
                                        ),
                                        dmc.Button(
                                            "Apply Filters",
                                            id="ni-apply-filters",
                                            color="cyan",
                                            variant="light",
                                            leftSection=DashIconify(
                                                icon="mdi:filter-check", width=16
                                            ),
                                        ),
                                    ],
                                ),
                            ]
                        ),
                    ],
                    value="filters",
                ),
            ],
            variant="separated",
            radius="lg",
            mb="lg",
            styles={
                "control": {"backgroundColor": "rgba(17,24,39,0.7)"},
                "panel": {"backgroundColor": "rgba(17,24,39,0.3)"},
                "item": {"borderColor": "rgba(255,255,255,0.06)"},
            },
        ),
        # ━━━ SUSPICIOUS CYCLE DETECTION ━━━
        dmc.Paper(
            [
                _section_header(
                    "mdi:alert-circle-outline",
                    "#FF6B6B",
                    "Suspicious Cycle Detection — Circular Money Flows",
                    "When money moves in a loop (Customer A sends to B, B sends to C, C returns money to A), "
                    "it is a classic 'layering' pattern — the second stage of money laundering where criminals "
                    "disguise the trail of illicit funds. Each row below is a detected money loop that requires investigation.",
                    extra=[dmc.Badge(id="ni-cycle-count", color="red", variant="light", size="lg")],
                ),
                html.Div(id="ni-cycles-table"),
            ],
            **_SEC,
        ),
        # ━━━ KEY ENTITIES — IMPORTANCE RANKING ━━━
        dmc.Paper(
            [
                _section_header(
                    "mdi:star-four-points",
                    "#00D4FF",
                    "Key Entities — Most Influential Customers by Network Position",
                    "These customers hold strategically important positions in the transaction network — "
                    "they handle the most money flow or connect different customer groups. Even if their "
                    "individual transactions look normal, their network position makes them potential facilitators. "
                    "Crime networks need 'hubs' to move money — these are the candidates.",
                    extra=[dmc.Badge("Top 50", color="cyan", variant="light", size="sm")],
                ),
                html.Div(id="ni-nodes-table"),
            ],
            **_SEC,
        ),
        # ━━━ CYCLE FORENSICS — DEEP DIVE ━━━
        dmc.Paper(
            [
                _section_header(
                    "mdi:magnify-scan",
                    "#9D4EDD",
                    "Cycle Forensics — Detailed Investigation of a Money Loop",
                    "Select a cycle number to see exactly who was involved, how much money flowed at each step, "
                    "and the complete path. This breakdown is the evidence summary for compliance reporting "
                    "and Narrative filing.",
                    extra=[
                        dmc.NumberInput(
                            id="ni-cycle-selector",
                            placeholder="Cycle #",
                            value=1,
                            min=1,
                            max=50,
                            w=100,
                            styles={
                                "input": {
                                    "backgroundColor": THEME.DARK_BG,
                                    "color": "white",
                                    "fontSize": "12px",
                                    "border": f"1px solid {THEME.DARK_BORDER}",
                                }
                            },
                        ),
                    ],
                ),
                html.Div(id="ni-cycle-detail"),
            ],
            **_SEC,
        ),
        # ━━━ COMPLETE NETWORK METRICS ━━━
        dmc.Paper(
            [
                _section_header(
                    "mdi:table-large-plus",
                    "#2196F3",
                    "Complete Customer Scoring Matrix",
                    "Every customer's composite risk score broken down by analytical family. "
                    "This is the full data table used for regulatory reporting, audit trails, "
                    "and deep-dive investigation. Export for compliance records.",
                    extra=[
                        dmc.Group(
                            [
                                dmc.Button(
                                    "⬇ Export CSV",
                                    id="ni-export-csv",
                                    size="xs",
                                    variant="light",
                                    color="cyan",
                                    leftSection=DashIconify(icon="mdi:download", width=14),
                                ),
                                dmc.Button(
                                    "⬇ Export PNG",
                                    id="ni-export-png",
                                    size="xs",
                                    variant="light",
                                    color="green",
                                    leftSection=DashIconify(icon="mdi:image-outline", width=14),
                                ),
                            ],
                            gap="xs",
                        ),
                    ],
                ),
                dcc.Download(id="ni-download"),
                html.Div(id="ni-full-metrics-table"),
            ],
            **_SEC,
        ),
    ]
)


# ═══════════════════════════════════════════════════════════════════════════════
# CALLBACKS — All V12.17 pipeline logic preserved, now with customer names
# ═══════════════════════════════════════════════════════════════════════════════


@callback(
    Output("ni-cycles-table", "children"),
    Output("ni-cycle-count", "children"),
    Output("ni-nodes-table", "children"),
    Output("ni-network-graph", "figure"),
    Output("ni-network-stats", "children"),
    Input("ni-init", "n_intervals"),
    Input("pipeline-state", "data"),
    Input("global-refresh-ts", "data"),  # v14.7 FIX-GAP4: sync on Global Refresh
    Input("ni-apply-filters", "n_clicks"),
    Input("ni-refresh-btn", "n_clicks"),
    State("ni-filter-custid", "value"),
    State("ni-filter-ring", "value"),
    State("ni-filter-node", "value"),
    State("ni-node-type-filter",  "value"),   # v16.23 T2: entity-type filter
    State("ni-node-type1-filter", "value"),   # v16.24: Internal/External filter
)
def update_view1(_, pipeline_state, _grt, __, ___, filter_cust, filter_ring, filter_node, node_type_filter, node_type1_filter):
    pipeline = get_pipeline()

    # v12.17 Task7: bypass is_running race — dashboard signals completion
    pipeline_done = isinstance(pipeline_state, dict) and pipeline_state.get("success", False)

    if pipeline.is_running() and not pipeline_done:
        running_msg = dmc.Center(
            dmc.Stack(
                [
                    dmc.Loader(color="cyan", size="sm"),
                    dmc.Text(
                        "Pipeline is running... Data will refresh automatically.",
                        c="dimmed",
                        size="sm",
                    ),
                ],
                align="center",
                gap="xs",
            ),
            style={"minHeight": "80px"},
        )
        return (
            running_msg,
            "running...",
            running_msg,
            empty_fig("Pipeline running..."),
            running_msg,
        )

    if not pipeline.has_data():
        return _default_network_overview()

    # Build name lookup map once
    nm = _build_name_map(pipeline)

    # ── CYCLES (with customer names) ──
    cycles = pipeline.detect_cycles()
    if filter_ring:
        cycles = [c for c in cycles if c["cycle_id"] == filter_ring]
    if filter_cust:
        cycles = [
            c
            for c in cycles
            if any(
                filter_cust.lower() in n.lower() or filter_cust.lower() in _dn(nm, n).lower()
                for n in c["nodes"]
            )
        ]
    if filter_node:
        cycles = [c for c in cycles if filter_node in c["nodes"]]

    _run_ver = pipeline_state.get("run_version", "") if isinstance(pipeline_state, dict) else ""
    _live_badge = (
        dmc.Group(
            [
                dmc.Text(f"{len(cycles)} found", size="sm", fw=600, c="white"),
                dmc.Badge(
                    f"LIVE DATA — Run #{_run_ver}" if _run_ver else "LIVE DATA",
                    color="green",
                    variant="light",
                    size="xs",
                ),
            ],
            gap="xs",
        )
        if pipeline_done
        else f"{len(cycles)} found"
    )
    cycle_count = _live_badge

    if cycles:
        # V12.21 FIX: wrap numeric fields with _safe_float to prevent TypeError
        # when cycle['avg_risk'] / cycle['total_amount'] / cycle['risk_sum'] are None
        # (these come from pipeline and may be None → :.1f crashes outside graph try/except)
        cycle_data = [
            {
                "#": c["cycle_id"],
                "Length": c["length"],
                "Started By": _dn(nm, c.get("initiator", "")),
                "Total Money Moved": f"${_safe_float(c.get('total_amount', 0)):,.0f}",
                "Avg Risk Score": round(
                    _safe_float(c.get("avg_risk", 0)), 1
                ),  # v12.22 BUG-H03 FIX: float not str so filter_query > N works correctly
                "Combined Risk": f"{_safe_float(c.get('risk_sum', 0)):.1f}",
                "Money Path": " → ".join([_dn(nm, n) for n in c["nodes"][:5]])
                + ("..." if len(c["nodes"]) > 5 else ""),
            }
            for c in cycles
        ]
        cycles_table = dmc.Stack(
            [
                dash_table.DataTable(
                    columns=[{"name": k, "id": k} for k in cycle_data[0].keys()],
                    data=cycle_data,
                    page_size=10,
                    style_header=_TH,
                    style_cell=_TC,
                    style_data_conditional=[
                        {"if": {"filter_query": "{Avg Risk Score} > 50"}, "color": "#FF1744"},
                        {"if": {"filter_query": "{Avg Risk Score} > 30"}, "color": "#FF9800"},
                    ],
                    sort_action="native",
                    filter_action="native",
                ),
                dmc.Text(
                    "💡 Reading Guide: Each row is a circular money flow. "
                    "'Started By' = the customer who initiated the loop. "
                    "Red rows (Avg Risk > 50) = highest concern for potential laundering.",
                    size="xs",
                    c="dimmed",
                    style={"fontStyle": "italic"},
                ),
            ],
            gap="xs",
        )
    else:
        _nodes_n = pipeline.G.number_of_nodes() if pipeline.G else 0
        _edges_n = pipeline.G.number_of_edges() if pipeline.G else 0
        cycles_table = dmc.Paper(
            [
                dmc.Group(
                    [
                        DashIconify(icon="mdi:check-circle", width=22, color="#00E676"),
                        dmc.Text(
                            "Network Clean — 0 suspicious circular flows detected",
                            size="sm",
                            fw=600,
                            c="#00E676",
                        ),
                    ],
                    gap="sm",
                ),
                dmc.Text(
                    f"Good news: We analyzed {_nodes_n:,} customers and {_edges_n:,} transaction links — "
                    "no cyclical money-movement patterns were found. This indicates healthy, "
                    "non-circular transaction behaviour across the customer base.",
                    size="xs",
                    c="dimmed",
                    mt="xs",
                ),
            ],
            p="sm",
            radius="md",
            style={"background": "rgba(0,230,118,0.05)", "border": "1px solid rgba(0,230,118,0.2)"},
        )

    # ── IMPORTANT NODES (with customer names) ──
    imp_nodes = pipeline.get_important_nodes()
    if filter_cust and len(imp_nodes) > 0:
        imp_nodes = imp_nodes[imp_nodes["node_id"].str.contains(filter_cust, case=False, na=False)]
    if filter_node and len(imp_nodes) > 0:
        imp_nodes = imp_nodes[imp_nodes["node_id"].str.contains(filter_node, case=False, na=False)]

    if len(imp_nodes) > 0:
        # Add customer name column
        imp_display = imp_nodes.copy()
        imp_display.insert(0, "customer_name", imp_display["node_id"].map(lambda x: _dn(nm, x)))
        col_map = {
            "customer_name": "Customer",
            "node_id": "Customer ID",
            "composite_importance": "Overall Score",
            "pagerank": "Network Influence",
            "betweenness": "Bridge Score",
            "risk_score": "Risk Score",
            "risk_tier": "Priority",
            "in_flow": "Money In",
            "out_flow": "Money Out",
            "flow_ratio": "In/Out Ratio",
        }
        display_cols = [c for c in col_map if c in imp_display.columns]
        nodes_table = dmc.Stack(
            [
                dash_table.DataTable(
                    columns=[{"name": col_map.get(c, c), "id": c} for c in display_cols],
                    data=imp_display[display_cols].round(4).to_dict("records"),
                    page_size=15,
                    style_header=_TH,
                    style_cell=_TC,
                    style_data_conditional=[
                        {
                            "if": {"column_id": "risk_tier", "filter_query": '{risk_tier} = "P1"'},
                            "color": "#FF1744",
                            "fontWeight": "bold",
                        },
                        {
                            "if": {"column_id": "risk_tier", "filter_query": '{risk_tier} = "P2"'},
                            "color": "#FF9800",
                        },
                    ],
                    sort_action="native",
                    filter_action="native",
                ),
                dmc.Text(
                    "💡 Column Guide: "
                    "Network Influence (PageRank) = share of total network flow. "
                    "Bridge Score (Betweenness) = connects otherwise separate groups. "
                    "In/Out Ratio > 1 = more money coming in than going out.",
                    size="xs",
                    c="dimmed",
                    style={"fontStyle": "italic"},
                ),
            ],
            gap="xs",
        )
    else:
        nodes_table = dmc.Text("No important nodes found", c="dimmed", size="sm")

    # ── NETWORK GRAPH (V12.20: robust, None-safe, always visible) ──
    # V12.20 ROOT-CAUSE FIX: l3_graph.py stores NaN attrs as Python None.
    # G.nodes[n].get('in_flow', 0) returns None (not 0) when key present but value=None.
    # f-string ':.1f' on None → TypeError → silent crash → blank figure.
    # Solution: _safe_float() coerces None/NaN/missing → 0.0 everywhere.
    G = pipeline.G
    g_nodes = G.number_of_nodes() if G is not None else 0
    if G is not None and g_nodes > 0:
        try:
            scored = pipeline.get_scored_df()
            max_show = min(500, g_nodes)
            if scored is not None and len(scored) > 0 and "risk_score" in scored.columns:
                top_nodes = scored.nlargest(max_show, "risk_score")["node_id"].tolist()
            else:
                top_nodes = list(G.nodes())[:max_show]

            # Filter top_nodes to only those actually in G
            top_nodes = [n for n in top_nodes if n in G.nodes]
            subG = G.subgraph(top_nodes) if top_nodes else G.subgraph([])

            # --- GROUP NODES BY RISK TIER for ring layout ---
            tier_buckets = {"P1": [], "P2": [], "P3": [], "P4": []}
            for node in subG.nodes():
                raw_tier = G.nodes[node].get("risk_tier", None)
                tier = raw_tier if raw_tier in tier_buckets else "P4"
                tier_buckets[tier].append(node)

            # --- POSITIONS: multi-ring (P1 centre, P4 outer) ---
            # Falls back to spring_layout if any exception occurs
            ring_radii = {"P1": 0.3, "P2": 0.6, "P3": 0.85, "P4": 1.05}
            pos = {}
            try:
                for tier, tier_nodes in tier_buckets.items():
                    r = ring_radii[tier]
                    n_tier = max(len(tier_nodes), 1)
                    offset = {"P1": 0.0, "P2": 0.2, "P3": 0.4, "P4": 0.6}[tier]
                    for i, node in enumerate(tier_nodes):
                        angle = 2 * math.pi * i / n_tier + offset
                        pos[node] = (r * math.cos(angle), r * math.sin(angle))
                # Safety: any node not assigned a position gets (0, 0)
                for node in subG.nodes():
                    if node not in pos:
                        pos[node] = (0.0, 0.0)
            except Exception:
                # Fallback: spring layout
                try:
                    pos_raw = nx.spring_layout(subG, seed=42, k=0.8)
                    pos = {n: (float(xy[0]), float(xy[1])) for n, xy in pos_raw.items()}
                except Exception:
                    pos = {n: (0.0, 0.0) for n in subG.nodes()}

            fig_net = go.Figure()

            # --- EDGES: make them visible (V12.20 fix: opacity 0.35, width 1) ---
            edge_x, edge_y = [], []
            for u, v in subG.edges():
                x0, y0 = pos.get(u, (0.0, 0.0))
                x1, y1 = pos.get(v, (0.0, 0.0))
                edge_x.extend([float(x0), float(x1), None])
                edge_y.extend([float(y0), float(y1), None])
            if edge_x:
                fig_net.add_trace(
                    go.Scatter(
                        x=edge_x,
                        y=edge_y,
                        mode="lines",
                        line=dict(color="rgba(148,163,184,0.35)", width=1.0),
                        hoverinfo="skip",
                        showlegend=True,
                        name="💰 Transaction Flow (arrow = money direction)",
                    )
                )

            # --- NODES per tier with full legend and customer names ---
            # v16.23 T2: dynamic node_type coloring / v16.24: also node_type1
            _use_nt_color  = node_type_filter  and node_type_filter  != "ALL"
            _use_nt1_color = node_type1_filter and node_type1_filter != "ALL"
            _NT_FALLBACK = "#94A3B8"
            try:
                from utils.node_colormap import build_colormap as _build_cm, NODE_TYPE1_COLORS as _NT1C
                _nt_types = [G.nodes[n].get("node_type", None) for n in subG.nodes()]
                _nt_cm = _build_cm([t for t in _nt_types if t])
            except Exception:
                _nt_cm = {}
                _NT1C = {"Internal": "#2196F3", "External": "#00D4FF"}
                _use_nt_color = False

            tier_legend = {
                "P1": ("🔴 P1 CRITICAL — Freeze & Investigate", "#FF1744"),
                "P2": ("🟠 P2 HIGH RISK — Enhanced Due Diligence", "#FF9800"),
                "P3": ("🟡 P3 MEDIUM — Active Monitoring", "#FFD600"),
                "P4": ("🟢 P4 LOW — Normal Operations", "#00E676"),
            }
            for tier, (legend_name, color) in tier_legend.items():
                nodes_in_tier = tier_buckets.get(tier, [])
                if not nodes_in_tier:
                    continue
                nx_list = [float(pos[n][0]) for n in nodes_in_tier]
                ny_list = [float(pos[n][1]) for n in nodes_in_tier]

                # SIZE: risk_score / 4, min 8, max 28 (V12.20: min raised to 8)
                sizes = [
                    max(8, min(28, _safe_float(G.nodes[n].get("risk_score")) / 4))
                    for n in nodes_in_tier
                ]

                # v16.23/v16.24: override color + opacity when type filter(s) active
                # AND logic: node must satisfy BOTH filters if both are set
                if _use_nt_color or _use_nt1_color:
                    node_colors = []
                    node_opacities = []
                    for n in nodes_in_tier:
                        _ntype  = str(G.nodes[n].get("node_type",  ""))
                        _ntype1 = str(G.nodes[n].get("node_type1", ""))
                        _nt_ok  = (not _use_nt_color)  or (_ntype  == node_type_filter)
                        _nt1_ok = (not _use_nt1_color) or (_ntype1 == node_type1_filter)
                        if _nt_ok and _nt1_ok:
                            # Pick color: if type1 filter active use type1 color, else type color
                            if _use_nt1_color:
                                node_colors.append(_NT1C.get(_ntype1, _NT_FALLBACK))
                            else:
                                node_colors.append(_nt_cm.get(_ntype, _NT_FALLBACK))
                            node_opacities.append(0.90)
                        else:
                            node_colors.append(_NT_FALLBACK)
                            node_opacities.append(0.12)
                else:
                    node_colors = color
                    node_opacities = 0.90

                # HOVER TEXT: v12.23 FIX — wrap in try/except; use dict(G.degree()) for safe cross-version degree access
                try:
                    _deg_map = dict(G.degree())
                    _tier_action = TIER_LABELS[tier][2].split(" — ")[
                        -1
                    ]  # precompute outside f-string (no backslash in expr)
                    hover_texts = [
                        f"<b>{_dn(nm, n)}</b><br>"
                        f"Customer ID: {str(n)}<br>"
                        f"Risk Score: {_safe_float(G.nodes[n].get('risk_score')):.1f}<br>"
                        f"Priority: {tier} — {TIER_LABELS[tier][0]}<br>"
                        f"Action Required: {_tier_action}<br>"
                        f"Money In: ${_safe_float(G.nodes[n].get('in_flow')):,.0f}<br>"
                        f"Money Out: ${_safe_float(G.nodes[n].get('out_flow')):,.0f}<br>"
                        f"Transaction Links: {_safe_int(G.nodes[n].get('total_degree')) or int(_deg_map.get(n, 0))}"
                        for n in nodes_in_tier
                    ]
                except Exception:
                    hover_texts = [
                        f"{_dn(nm, n)}<br>Risk: {_safe_float(G.nodes[n].get('risk_score')):.0f}"
                        for n in nodes_in_tier
                    ]

                # LABELS: show first name on P1/P2 (up to 30 nodes to keep readable)
                show_text = tier in ("P1", "P2") and len(nodes_in_tier) <= 30
                text_labels = (
                    [_dn(nm, n).split(" (")[0] for n in nodes_in_tier] if show_text else None
                )

                fig_net.add_trace(
                    go.Scatter(
                        x=nx_list,
                        y=ny_list,
                        mode="markers+text" if show_text else "markers",
                        marker=dict(
                            color=node_colors,
                            size=sizes,
                            opacity=node_opacities,
                            line=dict(color="rgba(255,255,255,0.4)", width=0.8),
                        ),
                        text=text_labels,
                        textposition="top center",
                        textfont=dict(size=9, color="#FFFFFF"),
                        hovertemplate=[f"{ht}<extra></extra>" for ht in hover_texts],
                        name=legend_name,
                    )
                )

            # V12.24 FIX: build merged layout dict to avoid duplicate-kwarg TypeError.
            # DARK_TEMPLATE already contains xaxis/yaxis/paper_bgcolor/plot_bgcolor —
            # passing them again as explicit kwargs causes:
            #   TypeError: update_layout() got multiple values for keyword argument 'xaxis'
            _net_layout = {k: v for k, v in DARK_TEMPLATE.items()}
            _net_layout.update(
                dict(
                    paper_bgcolor="rgba(17,24,39,0.97)",  # explicit dark bg (not transparent)
                    plot_bgcolor="rgba(10,14,23,0.9)",
                    height=500,
                    uirevision="network-topology",  # prevents reset on poll
                    showlegend=True,
                    legend=dict(
                        font=dict(color="#94A3B8", size=10),
                        orientation="h",
                        yanchor="bottom",
                        y=1.02,
                        xanchor="center",
                        x=0.5,
                        bgcolor="rgba(0,0,0,0)",
                    ),
                    xaxis=dict(showgrid=False, zeroline=False, showticklabels=False, visible=True),
                    yaxis=dict(showgrid=False, zeroline=False, showticklabels=False, visible=True),
                    annotations=[
                        dict(
                            text=(
                                f"Live network: {g_nodes:,} customers, "
                                f"{G.number_of_edges():,} transaction links. "
                                "Node size = risk level. Hover for customer details."
                            ),
                            x=0.5,
                            y=-0.08,
                            xref="paper",
                            yref="paper",
                            showarrow=False,
                            font=dict(color="#475569", size=10),
                        )
                    ],
                )
            )
            fig_net.update_layout(**_net_layout)

        except Exception as _graph_err:
            # v12.23: always show error text + full detail for faster diagnosis
            fig_net = empty_fig(
                f"Graph rendering error \u2014 please refresh or re-run the pipeline. "
                f"({type(_graph_err).__name__}: {str(_graph_err)[:120]})"
            )
    else:
        fig_net = empty_fig("No graph data — run pipeline to build customer network")

    # ── NETWORK STATS → Executive KPI Cards ──
    stats = pipeline.get_network_stats()
    if stats:
        stats_panel = _stats_to_kpi(stats, pipeline_done, _run_ver)
    else:
        stats_panel = dmc.Text("No stats", c="dimmed", size="sm")

    return cycles_table, cycle_count, nodes_table, fig_net, stats_panel


@callback(
    Output("ni-cycle-detail", "children"),
    Output("ni-full-metrics-table", "children"),
    Input("ni-cycle-selector", "value"),
    Input("ni-init", "n_intervals"),
    Input("pipeline-state", "data"),
    Input("global-refresh-ts", "data"),  # v14.7 FIX-GAP4: sync on Global Refresh
    Input("ni-refresh-btn", "n_clicks"),
)
def update_view2(cycle_id, _, pipeline_state, _grt, ___):
    pipeline = get_pipeline()

    # v12.17 Task7: bypass is_running race
    pipeline_done = isinstance(pipeline_state, dict) and pipeline_state.get("success", False)

    if pipeline.is_running() and not pipeline_done:
        running_msg = dmc.Center(
            dmc.Stack(
                [
                    dmc.Loader(color="cyan", size="sm"),
                    dmc.Text("Pipeline running...", c="dimmed", size="sm"),
                ],
                align="center",
                gap="xs",
            ),
        )
        return running_msg, running_msg

    if not pipeline.has_data():
        return _default_view2_content()

    nm = _build_name_map(pipeline)

    # ── SELECTED CYCLE DETAIL (with customer names) ──
    cycles = pipeline.detect_cycles()
    cycle_detail = dmc.Text("Select a cycle number above to investigate", c="dimmed", size="sm")
    if cycles and cycle_id and cycle_id <= len(cycles):
        cyc = cycles[cycle_id - 1]
        edges_data = [
            {"From": _dn(nm, e["from"]), "To": _dn(nm, e["to"]), "Amount": f"${e['amount']:,.0f}"}
            for e in cyc["edges"]
        ]
        members_data = []
        G = pipeline.G
        for node in cyc["nodes"]:
            attrs = dict(G.nodes[node]) if (G and node in G.nodes) else {}
            tier = attrs.get("risk_tier", "P4") or "P4"
            tier = tier if tier in TIER_LABELS else "P4"
            tier_label = TIER_LABELS.get(tier, ("", "", ""))[0]
            members_data.append(
                {
                    "Customer": _dn(nm, node),
                    "Risk Score": f"{_safe_float(attrs.get('risk_score')):.1f}",
                    "Priority": f"{tier} — {tier_label}",
                    "Money In": f"${_safe_float(attrs.get('in_flow')):,.0f}",
                    "Money Out": f"${_safe_float(attrs.get('out_flow')):,.0f}",
                }
            )

        cycle_detail = dmc.Stack(
            [
                dmc.Group(
                    [
                        dmc.Badge(f"Cycle #{cyc['cycle_id']}", color="red", size="lg"),
                        dmc.Badge(f"{cyc['length']} customers", color="cyan", variant="light"),
                        dmc.Badge(
                            f"Started by: {_dn(nm, cyc['initiator'])}",
                            color="orange",
                            variant="light",
                        ),
                        dmc.Badge(
                            f"Total: ${cyc['total_amount']:,.0f}", color="green", variant="light"
                        ),
                        dmc.Badge(
                            f"Avg Risk: {cyc['avg_risk']:.1f}", color="yellow", variant="light"
                        ),
                    ],
                    gap="xs",
                    mb="sm",
                ),
                dmc.Text(
                    "Money Path: "
                    + " → ".join([_dn(nm, n) for n in cyc["nodes"]])
                    + " → back to "
                    + _dn(nm, cyc["nodes"][0]),
                    size="sm",
                    c="#00D4FF",
                    mb="sm",
                ),
                dmc.SimpleGrid(
                    cols={"base": 1, "md": 2},
                    spacing="md",
                    children=[
                        dmc.Stack(
                            [
                                dmc.Text("Customers In This Loop", fw=600, c="white", size="sm"),
                                dash_table.DataTable(
                                    columns=[{"name": k, "id": k} for k in members_data[0].keys()],
                                    data=members_data,
                                    style_header=_TH,
                                    style_cell=_TC,
                                ),
                            ],
                            gap="xs",
                        ),
                        dmc.Stack(
                            [
                                dmc.Text(
                                    "Money Flow Between Customers", fw=600, c="white", size="sm"
                                ),
                                dash_table.DataTable(
                                    columns=[{"name": k, "id": k} for k in edges_data[0].keys()],
                                    data=edges_data,
                                    style_header=_TH,
                                    style_cell=_TC,
                                ),
                            ],
                            gap="xs",
                        ),
                    ],
                ),
            ]
        )

    # ── FULL METRICS TABLE (with customer names) ──
    scored = pipeline.get_scored_df()
    if scored is not None and len(scored) > 0:
        display_df = scored.copy()
        # Add customer name as first column
        display_df.insert(0, "customer_name", display_df["node_id"].map(lambda x: _dn(nm, x)))

        # Business-friendly column names
        col_map = {
            "customer_name": "Customer",
            "node_id": "Customer ID",
            "risk_score": "Risk Score",
            "risk_tier": "Priority",
            "pagerank": "Network Influence",
            "betweenness": "Bridge Score",
            "in_degree": "Incoming Links",
            "out_degree": "Outgoing Links",
            "in_flow": "Money In",
            "out_flow": "Money Out",
            "flow_ratio": "In/Out Ratio",
            "community": "Group",
            "anomaly_score": "Anomaly Level",
            "composite_importance": "Overall Score",
        }
        display_cols = [c for c in display_df.columns if c not in ["__index_level_0__"]][:15]

        full_table = dmc.Stack(
            [
                dash_table.DataTable(
                    columns=[
                        {"name": col_map.get(c, c.replace("_", " ").title()), "id": c}
                        for c in display_cols
                    ],
                    data=display_df[display_cols].round(4).head(200).to_dict("records"),
                    page_size=20,
                    style_header=_TH,
                    style_cell={
                        **_TC,
                        "maxWidth": "120px",
                        "overflow": "hidden",
                        "textOverflow": "ellipsis",
                    },
                    style_data_conditional=[
                        {
                            "if": {"column_id": "risk_tier", "filter_query": '{risk_tier} = "P1"'},
                            "color": "#FF1744",
                            "fontWeight": "bold",
                        },
                        {
                            "if": {"column_id": "risk_tier", "filter_query": '{risk_tier} = "P2"'},
                            "color": "#FF9800",
                        },
                    ],
                    sort_action="native",
                    filter_action="native",
                    export_format="csv",
                ),
                dmc.Text(
                    "💡 Column Guide: "
                    "Network Influence (PageRank) = share of total network flow through this customer. "
                    "Bridge Score (Betweenness) = how often this customer sits on shortest paths. "
                    "Anomaly Level = statistical deviation from normal (closer to 1.0 = more unusual). "
                    "Priority: P1=Critical, P2=High, P3=Medium, P4=Low.",
                    size="xs",
                    c="dimmed",
                    style={"fontStyle": "italic"},
                ),
            ],
            gap="xs",
        )
    else:
        full_table = dmc.Text(
            "No scored data available — run pipeline first", c="dimmed", size="sm"
        )

    return cycle_detail, full_table


@callback(
    Output("ni-download", "data"),
    Input("ni-export-csv", "n_clicks"),
    prevent_initial_call=True,
)
def export_csv(_):
    pipeline = get_pipeline()
    scored = pipeline.get_scored_df()
    if scored is not None:
        return dcc.send_data_frame(scored.to_csv, "network_metrics.csv", index=False)
    return no_update


@callback(
    Output("ni-download", "data", allow_duplicate=True),
    Input("ni-export-png", "n_clicks"),
    State("ni-network-graph", "figure"),
    prevent_initial_call=True,
)
def export_png_ni(n_clicks, fig_data):
    """v12.22 BUG-H01 FIX: PNG export for network graph (requires kaleido)."""
    if not n_clicks or not fig_data:
        return no_update
    try:
        import plotly.io as pio

        img_bytes = pio.to_image(go.Figure(fig_data), format="png", width=1200, height=600, scale=2)
        return dcc.send_bytes(img_bytes, "network_intelligence.png")
    except Exception:
        return no_update


@callback(
    Output("ni-init", "max_intervals"),
    Input("pipeline-state", "data"),
)
def stop_ni_polling(pipeline_state):
    """v12.22 DESIGN-01 FIX: Stop polling once pipeline completes."""
    if isinstance(pipeline_state, dict) and pipeline_state.get("success", False):
        return 0
    return -1


# v16.23 T2: Populate node_type filter dropdown from live pipeline data
@callback(
    Output("ni-node-type-filter",  "options"),
    Output("ni-node-type1-filter", "options"),
    Input("pipeline-state", "data"),
    Input("global-refresh-ts", "data"),
)
def update_ni_node_type_options(pipeline_state, _grt):
    """Populate both node_type and node_type1 dropdowns from live pipeline data."""
    try:
        from utils.node_colormap import node_type_filter_options, node_type1_filter_options
        pipeline = get_pipeline()
        return node_type_filter_options(pipeline), node_type1_filter_options(pipeline)
    except Exception:
        default2 = [
            {"label": "All (Int/Ext)", "value": "ALL"},
            {"label": "Internal",      "value": "Internal"},
            {"label": "External",      "value": "External"},
        ]
        return [{"label": "All Types", "value": "ALL"}], default2
