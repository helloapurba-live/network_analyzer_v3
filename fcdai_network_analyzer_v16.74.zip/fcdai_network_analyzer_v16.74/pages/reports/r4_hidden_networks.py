"""
REPORT R4 — Hidden Networks & Rings
=====================================
Group: G5 — "Who Is Connected to Whom That We Cannot See Individually?"
Audience: Head of AML , MLRO, Senior Investigators, Financial Intelligence Unit
Update: Auto-syncs on every pipeline run

Story: The single most powerful capability of a graph-based AML system is
network detection — finding coordinated groups of customers who, individually,
look perfectly normal, but together form a suspicious money-movement ring.
This page makes those hidden networks visible to a business audience.
No knowledge of graph theory is needed to read here. A ring is a group.
A member is a customer. The hub is the customer doing the most connecting.
The only question that matters: should this group be investigated as a whole?
"""
from __future__ import annotations

import sys
from pathlib import Path

import dash
import dash_ag_grid      as dag
import dash_cytoscape    as cyto
import dash_mantine_components as dmc
import plotly.graph_objects as go
from dash import Input, Output, State, callback, dcc, html, ALL, MATCH, no_update
from dash_iconify import DashIconify

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from config import APP, THEME
from engine import get_pipeline
from utils.data_provider import get_latest_scored  # v16.72 F4
from pages.reports import (
    TIER_COLORS, TIER_LABELS, CHART_BG, CHART_TEXT, CHART_GRID, DIM,
    empty_fig, styled_layout, page_header, section_header,
    kpi_card, no_data_card, fallback_note, ACCENT_GOLD, _tbl,
)

dash.register_page(
    __name__,
    path="/reports/hidden-networks",
    name="Hidden Networks & Rings",
    title=f"FCDAI v{APP.VERSION} | Hidden Networks & Rings",
)

# ─────────────────────────────────────────────────────────────────────────────
# CYTOSCAPE STYLESHEET
# ─────────────────────────────────────────────────────────────────────────────
_CYTO_STYLE = [
    {"selector": "node",           "style": {"label": "data(label)", "font-size": "8px",
                                              "text-valign": "center", "color": "#CBD5E1",
                                              "text-outline-width": 1, "text-outline-color": "#0D1218",
                                              "text-wrap": "wrap", "text-max-width": 72,
                                              "width": "data(size)", "height": "data(size)"}},
    {"selector": ".P1",            "style": {"background-color": "#FF1744", "border-color": "#FF6B6B", "border-width": 2}},
    {"selector": ".P2",            "style": {"background-color": "#FF9800", "border-color": "#FFB74D", "border-width": 2}},
    {"selector": ".P3",            "style": {"background-color": "#FFD600", "border-color": "#FFEE58", "border-width": 2}},
    {"selector": ".P4",            "style": {"background-color": "#00E676", "border-color": "#69F0AE", "border-width": 2}},
    {"selector": ".hub",           "style": {"border-width": 4, "border-color": "#FFD700", "width": 50, "height": 50}},
    {"selector": "edge",           "style": {"line-color": "rgba(148,163,184,0.25)", "width": 1,
                                              "curve-style": "bezier", "target-arrow-shape": "triangle",
                                              "target-arrow-color": "rgba(148,163,184,0.3)",
                                              "arrow-scale": 0.7}},
    {"selector": "edge.flagged",   "style": {"line-color": "rgba(255,23,68,0.6)", "width": 2}},
    # v16.63 hover / selection highlighting
    {"selector": "node:selected",  "style": {"border-width": 4, "border-color": "#FFFFFF",
                                              "overlay-color": "#FFFFFF", "overlay-opacity": 0.12}},
    {"selector": "node.hover",     "style": {"border-width": 3, "border-color": "#00D4FF",
                                              "overlay-color": "#00D4FF", "overlay-opacity": 0.15}},
]

# ─────────────────────────────────────────────────────────────────────────────
# LAYOUT
# ─────────────────────────────────────────────────────────────────────────────
layout = dmc.Box(
    [
        dcc.Interval(id="r4-init", interval=800, max_intervals=1),

        page_header(
            icon="mdi:graph-outline",
            title="Hidden Networks & Rings",
            subtitle="Group G5 — The Connected Groups Your Individual Screening Cannot See",
            story=(
                "Traditional AML screening looks at one customer at a time. "
                "Graph-based detection looks at how customers are connected to each other. "
                "A 'ring' is a group of customers who collectively move money in a circular or hub-and-spoke "
                "pattern that only becomes visible when you map the full transaction network. "
                "Each ring on this page is a real group detected in your own customer data. "
                "The colour of each node (customer account) shows their individual risk tier: "
                "red = Critical (P1), orange = High Risk (P2), yellow = Medium, green = Low. "
                "A ring containing multiple red nodes is your highest-priority investigation target. "
                "The hub node (marked with a gold border) is the account doing the most connecting "
                "and is typically the first subject of a SAR filing."
            ),
            accent="#9C27B0",
        ),

        # ── SECTION 1: Network Danger Signal KPIs ────────────────────────────
        section_header(
            "mdi:alert-decagram",
            "Network Danger Signals — At a Glance",
            "Key metrics that define how dangerous the transaction network looks right now.",
            accent="#FF1744",
        ),
        dmc.SimpleGrid(id="r4-net-kpis", cols={"base": 2, "sm": 5}, spacing="md", mb="xl"),

        # ── SECTION 2: Suspicious Ring Summary Table ──────────────────────────
        section_header(
            "mdi:table-large",
            "Suspicious Ring Summary — All Detected Networks",
            "Every ring detected by the graph engine, ordered by severity. The case-ready reference list.",
            accent="#FF9800",
        ),
        dmc.Paper(
            [
                dmc.Group(
                    [
                        dmc.Text("All Detected Rings — Ranked by Risk", fw=700, size="sm", c="white"),
                        dmc.Badge(id="r4-ring-count", children="—", color="orange", variant="light", size="sm"),
                    ],
                    justify="space-between", mb=4,
                ),
                dmc.Text(
                    "Each row is one ring (connected group) detected in your transaction network. "
                    "Ring ID is for reference. Members = number of customer accounts in the group. "
                    "Total Flow is the sum of all transactions between ring members. "
                    "Highest Tier shows the most dangerous individual risk tier within the ring. "
                    "A ring with 5+ members, P1 highest tier, and high total flow is a priority SAR candidate.",
                    size="xs", c=DIM, mb="sm", style={"lineHeight": "1.6"},
                ),
                dcc.Loading(
                    html.Div(id="r4-ring-table"),
                    type="dot",
                    color="#00D4FF",
                    delay_show=300,
                ),
            ],
            p="lg", radius="lg", className="glass-card", mb="xl",
        ),

        # ── SECTION 3: Ring Size Distribution ────────────────────────────────
        section_header(
            "mdi:chart-bar",
            "Ring Size Distribution — How Large Are the Networks?",
            "Breakdown of detected rings by membership size. Large rings require more investigative resource.",
            accent="#26C6DA",
        ),
        dmc.SimpleGrid(
            cols={"base": 1, "md": 2},
            spacing="md",
            mb="xl",
            children=[
                dmc.Paper(
                    [
                        dmc.Text("Number of Rings by Size Group", fw=700, size="sm", c="white", mb=4),
                        dmc.Text(
                            "Small rings (2–3 members) are common and may be simple pass-through pairs. "
                            "Mid-size rings (4–9 members) are more complex and more suspicious. "
                            "Large rings (10+ members) represent organised networks and are the highest priority.",
                            size="xs", c=DIM, mb="sm", style={"lineHeight": "1.5"},
                        ),
                        dcc.Graph(id="r4-ring-size-bar", config={"displayModeBar": False}, style={"height": "300px"}),
                    ],
                    p="lg", radius="lg", className="glass-card",
                ),
                dmc.Paper(
                    [
                        dmc.Text("Ring Tier Composition — What Risk Tier Are Ring Members?", fw=700, size="sm", c="white", mb=4),
                        dmc.Text(
                            "This chart shows the distribution of individual risk tiers (P1/P2/P3/P4) "
                            "across all customers who are members of at least one detected ring. "
                            "A high proportion of P1/P2 members across ring populations signals "
                            "a systemic, coordinated risk rather than isolated individual behaviour.",
                            size="xs", c=DIM, mb="sm", style={"lineHeight": "1.5"},
                        ),
                        dcc.Graph(id="r4-ring-tier-donut", config={"displayModeBar": False}, style={"height": "300px"}),
                    ],
                    p="lg", radius="lg", className="glass-card",
                ),
            ],
        ),

        # ── SECTION 4: Top 5 Ring Networks — Visual Diagrams ─────────────────
        section_header(
            "mdi:graph",
            "Top 5 Highest-Risk Ring Networks — Visual Diagrams",
            "Each diagram below is a real suspected criminal network found in your customer data. "
            "Gold-bordered node = hub account (most connected). Colour = individual risk tier.",
            accent="#9C27B0",
        ),
        dcc.Loading(
            dmc.Box(id="r4-top5-rings", mb="md"),
            type="dot",
            color="#9C27B0",
            delay_show=300,
        ),

        # ── SECTION 5: Individual Customer Network View ───────────────────────
        section_header(
            "mdi:account-network",
            "Individual Customer Network View",
            "Select any customer to see their direct connections, second-degree links, and the risk "
            "tier of every account they connect to.",
            accent="#00E676",
        ),
        dmc.Paper(
            [
                dmc.Group(
                    [
                        dmc.Text("Select a customer to visualise their network:", size="sm", c="white", fw=600),
                        dmc.Select(
                            id="r4-cust-select",
                            placeholder="Select or search customer ID…",
                            searchable=True,
                            data=[],
                            w=280,
                            size="sm",
                        ),
                        dmc.TextInput(
                            id="r4-name-filter",
                            placeholder="Or search by customer name…",
                            w=260,
                            size="sm",
                            debounce=True,
                            leftSection=DashIconify(icon="mdi:magnify", width=16),
                        ),
                    ],
                    gap="md", mb="md",
                ),
                dmc.Text(
                    "This diagram shows the selected customer at the centre, their direct transaction "
                    "partners in the first ring out, and second-degree connections in the outer ring. "
                    "Node colour = risk tier (red=P1, orange=P2, yellow=P3, green=P4). "
                    "Node size is proportional to total transaction volume. "
                    "This is the diagram a compliance officer would include in a SAR narrative.",
                    size="xs", c=DIM, mb="sm", style={"lineHeight": "1.6"},
                ),
                dmc.Grid(
                    [
                dmc.GridCol(dcc.Loading(html.Div(id="r4-cust-cyto-container"), type="circle", color="#00D4FF"), span=8),
                        dmc.GridCol(
                            dmc.Paper(
                                [
                                    dmc.Group(
                                        [
                                            html.Span(
                                                className="mdi mdi-account-details-outline",
                                                style={"fontSize": "16px", "color": "#00E676"},
                                            ),
                                            dmc.Text("Node Details", fw=700, size="sm", c="white"),
                                        ],
                                        gap="xs", mb="sm",
                                    ),
                                    html.Div(
                                        id="r4-ego-node-panel",
                                        children=dmc.Text(
                                            "Hover over or click any node to see details.",
                                            size="xs", c=DIM, ta="center",
                                            style={"paddingTop": "24px"},
                                        ),
                                    ),
                                ],
                                p="md", radius="lg", className="glass-card",
                                style={"minHeight": "480px", "overflowY": "auto"},
                            ),
                            span=4,
                        ),
                    ],
                    gutter="md",
                ),
            ],
            p="lg", radius="lg", className="glass-card", mb="xl",
        ),
    ],
    p="lg",
)


# ─────────────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _find_col(df, candidates):
    for c in candidates:
        if c in df.columns:
            return c
    return None


def _ring_tier(ring: dict, G, scored) -> str:
    """Highest-risk tier among all ring members."""
    members = ring.get("members", [])
    if not members or scored is None:
        return ring.get("tier", "P4")
    # Support both {node_id: ...} and {id: ...} member dicts
    tier_map  = dict(zip(scored["node_id"].astype(str), scored["tier"])) if "node_id" in scored.columns and "tier" in scored.columns else {}
    tiers = [tier_map.get(str(m.get("node_id", m.get("id", m)) if isinstance(m, dict) else m), "P4") for m in members]
    for t in ["P1", "P2", "P3"]:
        if t in tiers:
            return t
    return "P4"


def _build_ring_cytoscape(ring: dict, G, scored, cyto_id: str, height: int = 420):
    """Build a Cytoscape element for one ring."""
    members  = ring.get("members", [])
    ring_id  = ring.get("ring_id", "?")
    initiator = str(ring.get("initiator", ""))
    tier_map = dict(zip(scored["node_id"].astype(str), scored["tier"])) if scored is not None and "node_id" in scored.columns and "tier" in scored.columns else {}
    name_map = {}
    node_tbl = None
    try:
        pipeline = get_pipeline()
        _dp_tbl  = get_latest_scored(pipeline)  # v16.72 F4
        node_tbl = _tbl(_dp_tbl["tables"], "node", "customer")
    except Exception:
        pass
    if node_tbl is not None:
        nc = _find_col(node_tbl, ["customer_name", "name", "full_name", "node_name"])
        ic = _find_col(node_tbl, ["node_id", "customer_id", "id"])
        if nc and ic:
            name_map = dict(zip(node_tbl[ic].astype(str), node_tbl[nc]))
    # Collect extra attrs for profile panel (type columns etc.)
    node_attr: dict[str, dict] = {}
    if node_tbl is not None and ic:
        type_cols = [c for c in ["node_type", "node_type1", "node_type3", "customer_type", "segment"] if c in node_tbl.columns]
        for _, nrow in node_tbl.iterrows():
            vid = str(nrow[ic])
            attrs: dict = {}
            for tc in type_cols:
                attrs[tc] = str(nrow.get(tc, "")) if not hasattr(nrow.get(tc), "__len__") else str(nrow[tc])
            node_attr[vid] = attrs

    member_ids = set()
    score_map: dict[str, float] = {}  # mid -> risk_score
    # Support both {node_id: ...} and {id: ...} member dicts
    for m in members:
        mid = str(m.get("node_id", m.get("id", m)) if isinstance(m, dict) else m)
        member_ids.add(mid)
        if isinstance(m, dict):
            score_map[mid] = float(m.get("risk_score", 0) or 0)

    # Build scored lookup for txn counts
    score_df_lookup: dict[str, dict] = {}
    if scored is not None:
        for _, sr in scored.iterrows():
            sid = str(sr.get("node_id", ""))
            if sid:
                score_df_lookup[sid] = {
                    "txn_in":  int(float(sr.get("txn_in",  sr.get("in_degree",  0)) or 0)),
                    "txn_out": int(float(sr.get("txn_out", sr.get("out_degree", 0)) or 0)),
                    "amount":  round(float(sr.get("total_flow", sr.get("amount", 0)) or 0), 0),
                }

    elements = []
    for mid in member_ids:
        tier       = tier_map.get(mid, "P4")
        short_name = name_map.get(mid, mid[:8] + "…" if len(mid) > 8 else mid)
        r_scr      = score_map.get(mid, 0)
        attr       = node_attr.get(mid, {})
        sdl        = score_df_lookup.get(mid, {})
        # Two-line label: name + tier/score
        line2      = f"{tier} | {r_scr:.0f}"
        full_label = f"{short_name}\n{line2}"
        elements.append({
            "data": {
                "id":         mid,
                "label":      full_label,
                "tier":       tier,
                "size":       max(24, min(52, 24 + int(r_scr / 5))),
                "full_name":  attr.get("name", short_name) or short_name,
                "node_type":  attr.get("node_type",  "—"),
                "node_type1": attr.get("node_type1", "—"),
                "node_type3": attr.get("node_type3", "—"),
                "risk_score": round(r_scr, 1),
                "txn_in":     sdl.get("txn_in",  0),
                "txn_out":    sdl.get("txn_out", 0),
                "amount":     sdl.get("amount",  0),
                "is_hub":     "Yes" if mid == initiator else "No",
            },
            "classes": tier + (" hub" if mid == initiator else ""),
        })

    # Edges within ring members
    if G is not None:
        for u, v in (G.edges() if not G.is_directed() else G.edges()):
            su, sv = str(u), str(v)
            if su in member_ids and sv in member_ids:
                is_flagged = tier_map.get(su, "P4") in ("P1", "P2") or tier_map.get(sv, "P4") in ("P1", "P2")
                elements.append({
                    "data": {"source": su, "target": sv},
                    "classes": "flagged" if is_flagged else "",
                })

    return cyto.Cytoscape(
        id=cyto_id,
        elements=elements,
        layout={"name": "concentric", "animate": False, "minNodeSpacing": 50},
        style={"height": f"{height}px", "background": "rgba(7,12,20,0.97)",
               "borderRadius": "8px", "border": "1px solid rgba(148,163,184,0.1)"},
        stylesheet=_CYTO_STYLE,
        zoom=1.1,
        minZoom=0.3,
        maxZoom=3.0,
        userZoomingEnabled=True,
        userPanningEnabled=True,
    )


# ─────────────────────────────────────────────────────────────────────────────
# MAIN CALLBACK
# ─────────────────────────────────────────────────────────────────────────────
@callback(
    Output("r4-net-kpis",          "children"),
    Output("r4-ring-count",        "children"),
    Output("r4-ring-table",        "children"),
    Output("r4-ring-size-bar",     "figure"),
    Output("r4-ring-tier-donut",   "figure"),
    Output("r4-top5-rings",        "children"),
    Output("r4-cust-select",       "data"),
    Input("pipeline-state",        "data"),
    Input("global-refresh-ts",     "data"),
    Input("r4-init",               "n_intervals"),
    prevent_initial_call=False,
)
def update_r4(_ps, _grt, _init):
    pipeline  = get_pipeline()  # kept for detect_lobbies, has_data
    # v16.72 F4+F5: unified loader — memory-first, DB fallback, score_* normalize
    _dp    = get_latest_scored(pipeline)
    scored = _dp["scored"]
    G      = _dp["graph"] or (pipeline.G if pipeline else None)

    # ── normalise engine column names so tier_map lookups are consistent ───
    if scored is not None:
        if "risk_tier" in scored.columns and "tier" not in scored.columns:
            scored = scored.rename(columns={"risk_tier": "tier"})
        if "node_id" not in scored.columns:
            for alt in ["customer_id", "id"]:
                if alt in scored.columns:
                    scored = scored.rename(columns={alt: "node_id"})
                    break

    no_pipe = scored is None or len(scored) == 0

    # ── RINGS ──────────────────────────────────────────────────────────────────
    rings = []
    if pipeline and pipeline.has_data():
        try:
            rings = pipeline.detect_lobbies(max_rings=200) or []
        except Exception:
            rings = []

    # ── NAME MAP (hub account display names) ───────────────────────────────────
    _r4_name_map: dict[str, str] = {}
    try:
        _ntbl = _tbl(_dp["tables"] or {}, "node", "customer")
        if _ntbl is not None:
            _nc = _find_col(_ntbl, ["customer_name", "name", "full_name", "entity_name"])
            _ni = _find_col(_ntbl, ["node_id", "customer_id", "id"])
            if _nc and _ni:
                _r4_name_map = dict(zip(_ntbl[_ni].astype(str), _ntbl[_nc].astype(str)))
    except Exception:
        pass

    # ── KPIs ───────────────────────────────────────────────────────────────────
    if no_pipe or G is None:
        net_kpis = [no_data_card("Run pipeline to see network intelligence.")]
    else:
        tier_map = dict(zip(scored["node_id"].astype(str), scored["tier"])) if "node_id" in scored.columns and "tier" in scored.columns else {}
        p1_nodes = sum(1 for t in tier_map.values() if t == "P1")
        avg_con  = 0
        if p1_nodes > 0:
            p1_ids = [k for k, v in tier_map.items() if v == "P1"]
            try:
                avg_con = round(sum(G.degree(n) for n in p1_ids if n in G) / p1_nodes, 1)
            except Exception:
                avg_con = "N/A"
        max_ring  = max((r.get("size", 0) for r in rings), default=0)
        p1_in_ring = 0
        for r in rings:
            mems = r.get("members", [])
            for m in mems:
                mid = str(m.get("node_id", m.get("id", m)) if isinstance(m, dict) else m)
                if tier_map.get(mid) == "P1":
                    p1_in_ring += 1
        most_connected = "—"
        try:
            if G.number_of_nodes() > 0:
                most_connected = str(max(G.degree(), key=lambda x: x[1])[0])[:12]
        except Exception:
            pass

        net_kpis = [
            kpi_card("Rings Detected", f"{len(rings):,}", "Suspected money-movement groups", "mdi:motion", "grape"),
            kpi_card("Largest Ring Size", f"{max_ring:,}", "Accounts in the biggest network", "mdi:circle-expand", "red"),
            kpi_card("P1 Customers In Rings", f"{p1_in_ring:,}", "Critical-risk accounts inside a ring", "mdi:account-alert", "red"),
            kpi_card("Avg P1 Connections", str(avg_con), "Each critical customer connects to this many others", "mdi:hub", "orange"),
            kpi_card("Most Connected Account", most_connected, "Highest degree-centrality node", "mdi:account-star", "yellow"),
        ]

    # ── RING TABLE ─────────────────────────────────────────────────────────────
    ring_count = f"{len(rings):,} rings" if rings else "0 rings"

    if not rings:
        if no_pipe:
            ring_table = no_data_card("Run pipeline to detect ring networks.")
        else:
            ring_table = dmc.Paper(
                dmc.Stack([
                    DashIconify(icon="mdi:check-circle-outline", width=36, color="#00E676"),
                    dmc.Text("No Ring Networks Detected", fw=600, c="#00E676", size="sm", ta="center"),
                    dmc.Text("The lobby detection engine found no circular or hub-and-spoke money-movement rings. "
                             "This is a positive result — document it in your compliance file.",
                             size="xs", c=DIM, ta="center", style={"lineHeight": "1.5"}),
                ], align="center", gap="sm", py="xl"),
                p="xl", radius="lg", className="glass-card",
            )
    else:
        rows = []
        for r in sorted(rings, key=lambda x: x.get("avg_risk", 0), reverse=True):
            highest_tier = _ring_tier(r, G, scored)
            amt = r.get("total_flow", r.get("total_amount", None))
            hub_id   = str(r.get("initiator", ""))
            hub_name = _r4_name_map.get(hub_id, "")
            hub_disp = f"{hub_name[:18]} ({hub_id[:8]})".strip() if hub_name and hub_name not in (hub_id, "nan", "None") else hub_id[:18]
            rows.append({
                "Ring ID":        r.get("ring_id", ""),
                "Members":        r.get("size", len(r.get("members", []))),
                "Total Flow ($)": round(float(amt), 2) if amt else 0,
                "Avg Risk Score": round(r.get("avg_risk", 0), 1),
                "Highest Tier":   highest_tier,
                "Hub Account":    hub_id[:16],
                "Hub Name":       hub_disp,
                "Pattern":        r.get("pattern", r.get("type", "Circular")),
            })
        # Premium AG Grid column definitions with cell styling
        col_defs = [
            {"field": "Ring ID", "headerName": "Ring #", "width": 80, "pinned": "left",
             "cellStyle": {"fontFamily": "monospace", "color": "#00D4FF", "fontWeight": "700"}},
            {"field": "Members", "headerName": "Members", "width": 100,
             "cellStyle": {"function": "params.value >= 10 ? {'color':'#FF1744','fontWeight':700} : params.value >= 5 ? {'color':'#FF9800','fontWeight':600} : {'color':'#00E676'}"}},
            {"field": "Total Flow ($)", "headerName": "Total Flow ($)",
             "valueFormatter": {"function": "'$' + d3.format(',.0f')(params.value)"},
             "cellStyle": {"color": "#FFD600", "fontWeight": "600"}, "flex": 1},
            {"field": "Avg Risk Score", "headerName": "Avg Risk Score",
             "cellStyle": {"function": "params.value >= 70 ? {'color':'#FF1744','fontWeight':700} : params.value >= 40 ? {'color':'#FF9800'} : {'color':'#00E676'}"}, "width": 140},
            {"field": "Highest Tier", "headerName": "Highest Tier", "width": 120,
             "cellStyle": {"function":
                 "params.value === 'P1' ? {'background':'rgba(255,23,68,.2)','color':'#FF1744','fontWeight':700,'textAlign':'center'} : "
                 "params.value === 'P2' ? {'background':'rgba(255,152,0,.15)','color':'#FF9800','fontWeight':600,'textAlign':'center'} : "
                 "params.value === 'P3' ? {'background':'rgba(255,214,0,.1)','color':'#FFD600','textAlign':'center'} : "
                 "{'color':'#00E676','textAlign':'center'}"}},
            {"field": "Hub Account", "headerName": "Hub Account ID",
             "cellStyle": {"fontFamily": "monospace", "color": "#94A3B8"}, "width": 140},
            {"field": "Hub Name", "headerName": "Hub Account Name",
             "cellStyle": {"color": "#00D4FF", "fontWeight": "500"}, "flex": 1,
             "tooltipField": "Hub Name"},
            {"field": "Pattern", "headerName": "Pattern Type", "flex": 1,
             "cellStyle": {"color": "#CBD5E1", "fontStyle": "italic"}},
        ]
        ring_table = dag.AgGrid(
            rowData=rows,
            columnDefs=col_defs,
            dashGridOptions={
                "animateRows": True,
                "pagination": True,
                "paginationPageSize": 15,
                "enableCellTextSelection": True,
                "rowSelection": "single",
                "getRowStyle": {"function": "return {'backgroundColor': '#060D1A', 'color': '#CBD5E1'}"},
            },
            defaultColDef={"sortable": True, "filter": True, "resizable": True,
                           "floatingFilter": True,
                           "cellStyle": {"color": "#CBD5E1", "backgroundColor": "#060D1A"},
                           "headerStyle": {"backgroundColor": "#0A1628", "color": "#00D4FF",
                                           "borderBottom": "2px solid rgba(0,212,255,0.45)"}},
            className="ag-theme-alpine-dark",
            # v16.62: CSS custom properties force dark background (overrides ag-theme-alpine-dark)
            style={
                "height": "420px",
                "borderRadius": "8px",
                "border": "1px solid rgba(0,212,255,0.25)",
                "--ag-background-color": "#060D1A",
                "--ag-foreground-color": "#CBD5E1",
                "--ag-header-background-color": "#0A1628",
                "--ag-header-foreground-color": "#00D4FF",
                "--ag-row-hover-background-color": "#0D1B2E",
                "--ag-odd-row-background-color": "#070E1A",
                "--ag-border-color": "rgba(0,212,255,0.2)",
                "--ag-row-border-color": "rgba(255,255,255,0.05)",
                "--ag-selected-row-background-color": "#0F2040",
            },
        )

    # ── RING SIZE BAR ──────────────────────────────────────────────────────────
    if not rings:
        size_bar = empty_fig("No rings detected yet.")
    else:
        buckets = {"2–3 (Pair)": 0, "4–5 (Small)": 0, "6–9 (Cluster)": 0,
                   "10–14 (Mid)": 0, "15–24 (Large)": 0, "25+ (Organised)": 0}
        for r in rings:
            sz = r.get("size", 0)
            if sz <= 3:     buckets["2–3 (Pair)"]       += 1
            elif sz <= 5:   buckets["4–5 (Small)"]       += 1
            elif sz <= 9:   buckets["6–9 (Cluster)"]     += 1
            elif sz <= 14:  buckets["10–14 (Mid)"]        += 1
            elif sz <= 24:  buckets["15–24 (Large)"]      += 1
            else:           buckets["25+ (Organised)"]    += 1
        # Only show size groups that actually contain rings (no blank bars)
        buckets = {k: v for k, v in buckets.items() if v > 0}
        clr_map = {
            "2–3 (Pair)": "#26C6DA", "4–5 (Small)": "#4CAF50",
            "6–9 (Cluster)": "#FF9800", "10–14 (Mid)": "#FF5722",
            "15–24 (Large)": "#FF3D00", "25+ (Organised)": "#FF1744",
        }
        clrs = [clr_map.get(k, "#8899AA") for k in buckets]
        actual_sizes = [r.get("size", 0) for r in rings]
        max_sz = max(actual_sizes) if actual_sizes else 0
        size_bar = go.Figure(go.Bar(
            x=list(buckets.keys()),
            y=list(buckets.values()),
            marker_color=clrs,
            text=[str(v) for v in buckets.values()],
            textposition="outside",
            textfont=dict(color=CHART_TEXT, size=12),
            hovertemplate="<b>%{x}</b><br>Rings in this size group: <b>%{y}</b><extra></extra>",
        ))
        styled_layout(size_bar, height=300, legend=False)
        size_bar.update_layout(
            xaxis_title="Ring Size Group (by member count)",
            yaxis_title="Number of Rings",
            yaxis=dict(range=[0, max(buckets.values()) * 1.25] if buckets else [0, 1]),
            margin=dict(b=60, t=20),
        )
        size_bar.add_annotation(
            text=f"<b>{len(rings)} rings detected</b> · Largest ring: {max_sz} members",
            xref="paper", yref="paper", x=0.5, y=-0.22,
            showarrow=False, font=dict(size=10, color="#94A3B8"), xanchor="center",
        )

    # ── RING TIER DONUT ────────────────────────────────────────────────────────
    # v16.62: Business view — count RINGS by highest-risk tier, not individual members.
    # Answers: "How many rings need urgent action?" — the question a MLRO asks first.
    if not rings or scored is None:
        tier_donut = empty_fig("No ring/scoring data available.")
    else:
        ring_tier_counts: dict[str, int] = {"P1": 0, "P2": 0, "P3": 0, "P4": 0}
        for r in rings:
            t = _ring_tier(r, G, scored)
            if t not in ring_tier_counts:
                t = "P4"
            ring_tier_counts[t] += 1
        _RING_TIER_BIZ = {
            "P1": "Critical Risk Rings",
            "P2": "High Risk Rings",
            "P3": "Medium Risk Rings",
            "P4": "Low Risk Rings",
        }
        tier_donut = go.Figure(go.Pie(
            labels=[_RING_TIER_BIZ.get(t, t) for t in ring_tier_counts.keys()],
            values=list(ring_tier_counts.values()),
            marker_colors=[TIER_COLORS.get(t, "#8899AA") for t in ring_tier_counts.keys()],
            hole=0.55,
            textinfo="percent+value",
            hovertemplate="<b>%{label}</b><br>Rings: %{value}<br>Click to investigate<extra></extra>",
        ))
        styled_layout(tier_donut, height=300)
        tier_donut.update_layout(
            title=dict(
                text="<b>Ring Risk Profile</b>",
                font=dict(size=13, color=CHART_TEXT),
                x=0.5, xanchor="center",
            ),
            annotations=[dict(
                text=f"<b>{len(rings)}</b><br>rings",
                x=0.5, y=0.5, font_size=13, showarrow=False,
                font_color=CHART_TEXT,
            )],
            legend=dict(orientation="h", y=-0.18, x=0.5, xanchor="center"),
        )

    # ── TOP 5 RING DIAGRAMS ────────────────────────────────────────────────────
    if not rings or no_pipe:
        top5_content = no_data_card("Run pipeline to visualise ring networks.", "Ring diagrams appear here after successful pipeline run.")
    else:
        top5 = sorted(rings, key=lambda x: x.get("avg_risk", 0), reverse=True)[:5]
        cards = []
        for i, ring in enumerate(top5):
            ring_id   = ring.get("ring_id", i + 1)
            sz        = ring.get("size", 0)
            tier_h    = _ring_tier(ring, G, scored)
            avg_r     = round(ring.get("avg_risk", 0), 1)
            tot_f     = ring.get("total_flow", ring.get("total_amount", None))
            tier_col  = TIER_COLORS.get(tier_h, "#8899AA")
            tier_clr  = {"P1": "red", "P2": "orange", "P3": "yellow", "P4": "green"}.get(tier_h, "gray")
            cyto_id   = {"type": "r4ring", "index": str(ring_id)}
            panel_id  = {"type": "r4ring-panel", "index": str(ring_id)}
            try:
                cyto_elem = _build_ring_cytoscape(ring, G, scored, cyto_id, height=400)
            except Exception as e:
                cyto_elem = dmc.Text(f"Could not render ring diagram: {e}", c="red", size="xs")

            # ── Static ring profile (right panel top section) ─────────────────
            def _stat(icon, label, val, col=CHART_TEXT):
                return dmc.Group([
                    DashIconify(icon=icon, width=14, color=col),
                    dmc.Text(f"{label}:", size="xs", c=DIM, style={"minWidth": "80px"}),
                    dmc.Text(str(val), size="xs", c=col, fw=600),
                ], gap=4, mb=3)

            ring_profile = dmc.Stack([
                dmc.Group([
                    DashIconify(icon="mdi:motion", width=16, color=tier_col),
                    dmc.Text("Ring Profile", size="xs", fw=700, c=CHART_TEXT),
                ], gap=4, mb=4),
                _stat("mdi:pound",                "Ring #",    ring_id,        "#00D4FF"),
                _stat("mdi:account-group",        "Members",   sz,              CHART_TEXT),
                _stat("mdi:alert-circle-outline", "Top Tier",  tier_h,          tier_col),
                _stat("mdi:trending-up",          "Avg Risk",  f"{avg_r}/100",  tier_col),
                _stat("mdi:cash-multiple",        "Total Flow",
                      f"${tot_f:,.0f}" if tot_f else "N/A",    "#FFD600"),
                dmc.Divider(my="xs", color="rgba(148,163,184,0.15)"),
                dmc.Text("Click a node →", size="xs", c=DIM, ta="center", mb=4),
                html.Div(id=panel_id, style={"minHeight": "80px"}),
            ], gap=0, style={
                "background": "#070E1D",
                "border": f"1px solid {tier_col}44",
                "borderRadius": "8px",
                "padding": "12px",
                "height": "400px",
                "overflowY": "auto",
            })

            cards.append(dmc.Paper(
                [
                    dmc.Group(
                        [
                            dmc.Badge(f"Ring #{ring_id}", color=tier_clr, variant="filled", size="md"),
                            dmc.Badge(f"{sz} members", color="grape", variant="light", size="sm"),
                            dmc.Badge(f"Avg Risk: {avg_r}", color="cyan", variant="light", size="sm"),
                            dmc.Badge(f"Highest: {tier_h}", variant="outline", size="sm",
                                      style={"borderColor": tier_col, "color": tier_col}),
                        ],
                        gap="xs", mb="sm",
                    ),
                    dmc.Grid([
                        dmc.GridCol(cyto_elem,    span=9),
                        dmc.GridCol(ring_profile, span=3),
                    ], gutter="xs"),
                ],
                p="md", radius="lg", className="glass-card", mb="md",
                style={"border": f"1px solid {tier_col}33"},
            ))
        top5_content = dmc.Stack(cards, gap="md")

    # ── CUSTOMER SELECT OPTIONS ───────────────────────────────────────────────
    # v16.62: DB-primary — load ALL customers ranked by risk_score (highest first).
    # No longer capped at top-100 or dependent on pipeline.tables being populated.
    import pandas as _pd
    cust_opts = []
    try:
        from database import get_db as _gdb_c
        _dbc = _gdb_c()
        _histc = _dbc.get_run_history(limit=1)
        _scored_c = None
        if _histc is not None and len(_histc) > 0:
            _ridc = int(_histc.iloc[0]["run_id"])
            _scored_c = _dbc.get_run_scored(_ridc)
            if _scored_c is not None:
                if "risk_tier" in _scored_c.columns and "tier" not in _scored_c.columns:
                    _scored_c = _scored_c.rename(columns={"risk_tier": "tier"})
        # Try to get customer names from pipeline raw tables
        nm = {}
        try:
            _plc = get_pipeline()
            if _plc:
                _ntbl = _plc.tables.get("node") or _plc.tables.get("customer")
                if _ntbl is not None:
                    nc_col = _find_col(_ntbl, ["customer_name", "name", "full_name"])
                    ni_col = _find_col(_ntbl, ["node_id", "customer_id", "id"])
                    if nc_col and ni_col:
                        nm = dict(zip(_ntbl[ni_col].astype(str), _ntbl[nc_col]))
        except Exception:
            pass
        if _scored_c is not None:
            _ic = _find_col(_scored_c, ["node_id", "customer_id", "id"])
            if _ic:
                _scored_c[_ic] = _scored_c[_ic].astype(str)
                if "risk_score" in _scored_c.columns:
                    _sorted_c = _scored_c.sort_values("risk_score", ascending=False)
                else:
                    _sorted_c = _scored_c
                for _, row in _sorted_c.iterrows():
                    vid    = str(row[_ic])
                    lname  = nm.get(vid, vid[:14])
                    ltier  = str(row["tier"]) if "tier" in row.index else ""
                    lscore = round(float(row["risk_score"]), 1) if "risk_score" in row.index and _pd.notna(row["risk_score"]) else 0
                    _tier_icon = {"P1": "🔴", "P2": "🟠", "P3": "🟡", "P4": "🟢"}.get(ltier, "⚪")
                    cust_opts.append({"value": vid,
                                      "label": f"{_tier_icon} {lname} — {ltier} (Risk: {lscore})"})
    except Exception:
        cust_opts = []

    return (
        net_kpis,
        ring_count, ring_table,
        size_bar, tier_donut,
        top5_content,
        cust_opts,
    )


# ─────────────────────────────────────────────────────────────────────────────
# NAME FILTER → AUTO-SELECT CUSTOMER CALLBACK
# ─────────────────────────────────────────────────────────────────────────────
@callback(
    Output("r4-cust-select", "value"),
    Input("r4-name-filter",  "value"),
    State("r4-cust-select",  "data"),
    prevent_initial_call=True,
)
def filter_cust_by_name(name_text, options):
    """Match typed customer name to the nearest Select option and auto-select it."""
    if not name_text or not options:
        return no_update
    needle = name_text.strip().lower()
    for opt in (options or []):
        label = (opt.get("label", "") if isinstance(opt, dict) else str(opt)).lower()
        if needle in label:
            return opt["value"] if isinstance(opt, dict) else opt
    return no_update


# ─────────────────────────────────────────────────────────────────────────────
# INDIVIDUAL CUSTOMER NETWORK CALLBACK
# ─────────────────────────────────────────────────────────────────────────────
@callback(
    Output("r4-cust-cyto-container", "children"),
    Input("r4-cust-select",          "value"),
    prevent_initial_call=True,
)
def render_customer_network(cust_id):
    if not cust_id:
        return dmc.Text("Select a customer above to view their network diagram.", c=DIM, size="sm", ta="center", py="xl")
    pipeline = get_pipeline()
    if not pipeline or not pipeline.has_data():
        return dmc.Text("Pipeline data not available.", c=DIM, size="sm", ta="center", py="xl")
    G      = pipeline.G
    scored = pipeline.scored_df
    # Normalise columns
    if scored is not None:
        if "risk_tier" in scored.columns and "tier" not in scored.columns:
            scored = scored.rename(columns={"risk_tier": "tier"})
        if "node_id" not in scored.columns:
            for alt in ["customer_id", "id"]:
                if alt in scored.columns:
                    scored = scored.rename(columns={alt: "node_id"})
                    break
    if G is None:
        return dmc.Text("Transaction graph not built. Run the pipeline first.", c=DIM, size="sm", ta="center", py="xl")
    # Handle both string and non-string node IDs in G
    target_id = cust_id
    if cust_id not in G:
        # Try matching by converting to G's node type
        if G.number_of_nodes() > 0:
            sample_node = next(iter(G.nodes()))
            try:
                target_id = type(sample_node)(cust_id)
            except Exception:
                pass
    if target_id not in G:
        return dmc.Text(
            f"Customer '{cust_id}' has no transaction links in the network graph. "
            "This customer may not appear in the edge table.",
            c=DIM, size="sm", ta="center", py="xl",
        )
    try:
        import networkx as nx
        ego = nx.ego_graph(G, target_id, radius=2, undirected=True)
        # Trim to manageable size
        if ego.number_of_nodes() > 80:
            # Keep 1st degree + top-scoring 2nd degree
            first_deg = set(G.neighbors(target_id))
            if hasattr(G, "predecessors"):
                first_deg |= set(G.predecessors(target_id))
            all_nodes = {target_id} | first_deg
            tier_map = dict(zip(scored["node_id"].astype(str), scored["tier"])) if scored is not None and "node_id" in scored.columns and "tier" in scored.columns else {}
            score_map = dict(zip(scored["node_id"].astype(str), scored["risk_score"].fillna(0))) if scored is not None and "risk_score" in scored.columns else {}
            # Add top 30 second-degree by score
            second = set(ego.nodes()) - all_nodes
            second_sorted = sorted(second, key=lambda n: float(score_map.get(str(n), 0)), reverse=True)[:30]
            all_nodes |= set(second_sorted)
            ego = ego.subgraph(all_nodes)

        tier_map = dict(zip(scored["node_id"].astype(str), scored["tier"])) if scored is not None and "node_id" in scored.columns and "tier" in scored.columns else {}
        score_map = dict(zip(scored["node_id"].astype(str), scored["risk_score"].fillna(0))) if scored is not None and "risk_score" in scored.columns else {}

        node_tbl = _tbl(pipeline.tables, "node", "customer")
        nm = {}
        if node_tbl is not None:
            nc = _find_col(node_tbl, ["customer_name", "name", "full_name"])
            ni = _find_col(node_tbl, ["node_id", "customer_id", "id"])
            if nc and ni:
                nm = dict(zip(node_tbl[ni].astype(str), node_tbl[nc]))

        elements = []
        for node in ego.nodes():
            nid   = str(node)
            tier  = tier_map.get(nid, "P4")
            label = nm.get(nid, nid[:8])
            scr   = float(score_map.get(nid, 0))
            size  = 55 if nid == str(target_id) else max(22, min(44, 22 + int(scr / 3)))
            is_hub = nid == str(target_id)
            elements.append({
                "data": {
                    "id": nid, "label": label, "size": size,
                    # v16.63: enriched data for hover/tap panel
                    "tier":       tier,
                    "risk_score": round(scr, 1),
                    "full_name":  nm.get(nid, nid),
                    "is_hub":     "Yes" if is_hub else "No",
                    "degree":     ego.degree(node),
                },
                "classes": tier + (" hub" if is_hub else ""),
            })
        for u, v in ego.edges():
            su, sv = str(u), str(v)
            flagged = tier_map.get(su, "P4") in ("P1", "P2") or tier_map.get(sv, "P4") in ("P1", "P2")
            elements.append({"data": {"source": su, "target": sv}, "classes": "flagged" if flagged else ""})

        return dmc.Box([
            dmc.Text(
                f"Showing {ego.number_of_nodes()} accounts connected to "
                f"'{nm.get(str(target_id), str(target_id))}' (up to 2 degrees of separation). "
                "Gold bordered node = selected customer. Colours = risk tier. "
                "Zoom and drag to explore.",
                size="xs", c=DIM, mb="sm",
            ),
            cyto.Cytoscape(
                id="r4-ego-cyto",
                elements=elements,
                layout={"name": "concentric", "animate": False, "minNodeSpacing": 45},
                style={"height": "520px", "background": "rgba(7,12,20,0.97)",
                       "borderRadius": "8px", "border": "1px solid rgba(148,163,184,0.1)"},
                stylesheet=_CYTO_STYLE,
                minZoom=0.3,
                maxZoom=4.0,
                userZoomingEnabled=True,
                userPanningEnabled=True,
            ),
        ])
    except Exception as e:
        return dmc.Text(f"Error rendering network: {e}", c="red", size="sm", ta="center", py="xl")


# ─────────────────────────────────────────────────────────────────────────────
# RING NODE PROFILE PANEL (tap on any node in top-5 ring diagrams)
# ─────────────────────────────────────────────────────────────────────────────
from dash import ctx, no_update, MATCH

# v16.62: Use MATCH pattern — each ring's cytoscape directly updates its own panel.
# This replaces the fragile ALL+index-map approach that was silently failing.
@callback(
    Output({"type": "r4ring-panel", "index": MATCH}, "children"),
    Input({"type": "r4ring", "index": MATCH}, "tapNodeData"),
    prevent_initial_call=True,
)
def show_ring_node_profile(node_data):
    """Show a compact node profile when a node is tapped in a ring diagram."""
    if not node_data:
        return no_update

    nid        = node_data.get("id", "")
    full_name  = node_data.get("full_name", nid)
    tier       = node_data.get("tier", "—")
    risk_score = node_data.get("risk_score", 0)
    node_type  = node_data.get("node_type",  "—")
    node_type1 = node_data.get("node_type1", "—")
    node_type3 = node_data.get("node_type3", "—")
    txn_in     = node_data.get("txn_in",  0)
    txn_out    = node_data.get("txn_out", 0)
    amount     = node_data.get("amount",  0)
    is_hub     = node_data.get("is_hub",  "No")

    tier_col = {"P1": "#FF1744", "P2": "#FF9800", "P3": "#FFD600", "P4": "#00E676"}.get(tier, "#8899AA")
    tier_bg  = {"P1": "rgba(255,23,68,.15)", "P2": "rgba(255,152,0,.12)",
                "P3": "rgba(255,214,0,.10)", "P4": "rgba(0,230,118,.10)"}.get(tier, "rgba(120,120,120,.08)")

    def _row(label, value, color=CHART_TEXT):
        return dmc.Group([
            dmc.Text(label + ":", size="xs", c=DIM, style={"minWidth": "75px", "flexShrink": 0}),
            dmc.Text(str(value), size="xs", c=color, fw=600),
        ], gap=4, mb=2)

    profile_card = dmc.Box(
        [
            dmc.Group([
                dmc.Badge(tier, color={"P1":"red","P2":"orange","P3":"yellow","P4":"green"}.get(tier,"gray"),
                          variant="filled", size="xs"),
                dmc.Badge("Hub" if is_hub == "Yes" else "Member",
                          color="yellow" if is_hub == "Yes" else "dark", variant="light", size="xs"),
            ], gap=4, mb=4),
            dmc.Text(full_name[:20] if len(full_name) > 20 else full_name,
                     size="xs", fw=700, c="white", mb=2),
            _row("ID",     nid[:14]),
            _row("Type",   node_type,  "#CBD5E1"),
            _row("Score",  f"{risk_score:.0f}/100", tier_col),
            _row("Txn In", f"{txn_in:,}"),
            _row("Txn Out",f"{txn_out:,}"),
            _row("Volume", f"${amount:,.0f}" if amount else "N/A", "#FFD600"),
        ],
        style={
            "background": tier_bg,
            "border": f"1px solid {tier_col}66",
            "borderRadius": "6px",
            "padding": "8px",
        },
    )

    return profile_card


# ─────────────────────────────────────────────────────────────────────────────
# v16.63: Individual Customer Network — hover / tap → node detail panel
# suppress_callback_exceptions=True in app.py allows r4-ego-cyto to be
# referenced before the user has selected a customer (graph not yet rendered).
# ─────────────────────────────────────────────────────────────────────────────
@callback(
    Output("r4-ego-node-panel", "children"),
    Input("r4-ego-cyto", "mouseoverNodeData"),
    Input("r4-ego-cyto", "tapNodeData"),
    prevent_initial_call=True,
)
def show_ego_node_panel(hover_data, tap_data):
    """Show node details when hovering or clicking a node in Individual Customer Network."""
    # tap takes priority over hover so the panel pins on click
    node_data = tap_data or hover_data
    if not node_data:
        return no_update

    nid        = node_data.get("id", "")
    full_name  = node_data.get("full_name", nid)
    tier       = node_data.get("tier", "—")
    risk_score = node_data.get("risk_score", 0)
    is_hub     = node_data.get("is_hub", "No")
    degree     = node_data.get("degree", 0)

    tier_col = {"P1": "#FF1744", "P2": "#FF9800", "P3": "#FFD600", "P4": "#00E676"}.get(tier, "#8899AA")
    tier_bg  = {"P1": "rgba(255,23,68,.15)", "P2": "rgba(255,152,0,.12)",
                "P3": "rgba(255,214,0,.10)", "P4": "rgba(0,230,118,.10)"}.get(tier, "rgba(120,120,120,.08)")
    tier_label = {
        "P1": "Critical Risk", "P2": "High Risk",
        "P3": "Medium Risk",   "P4": "Low Risk",
    }.get(tier, "Unknown")

    def _row(label, value, color=CHART_TEXT):
        return dmc.Group([
            dmc.Text(label + ":", size="xs", c=DIM,
                     style={"minWidth": "88px", "flexShrink": 0}),
            dmc.Text(str(value), size="xs", c=color, fw=600),
        ], gap=4, mb=3)

    # Determine whether this was a tap (pinned) or hover (transient)
    trig = ctx.triggered_id or ""
    action_note = "Click to pin" if "mouseover" in trig else "Pinned"

    card = dmc.Box(
        [
            dmc.Group([
                dmc.Badge(
                    tier, size="sm", variant="filled",
                    color={"P1": "red", "P2": "orange",
                           "P3": "yellow", "P4": "green"}.get(tier, "gray"),
                ),
                dmc.Badge(
                    "Selected Customer" if is_hub == "Yes" else "Connected Account",
                    size="xs", variant="light",
                    color="cyan" if is_hub == "Yes" else "dark",
                ),
            ], gap=4, mb=6),

            dmc.Text(
                full_name[:26] if len(full_name) > 26 else full_name,
                size="sm", fw=700, c="white", mb=4,
            ),

            dmc.Divider(mb=6, color="rgba(148,163,184,0.15)"),

            _row("Account ID",  nid[:16]),
            _row("Risk Tier",   tier_label,           tier_col),
            _row("Risk Score",  f"{risk_score:.0f} / 100", tier_col),
            _row("Connections", f"{degree} direct link{'s' if degree != 1 else ''}"),

            dmc.Divider(my=6, color="rgba(148,163,184,0.15)"),

            dmc.Text(
                "This is the selected customer — the central hub of the network view shown."
                if is_hub == "Yes" else
                (
                    f"This account has {degree} direct transaction partner"
                    f"{'s' if degree != 1 else ''} visible in this view. "
                    "A high connection count with critical-tier peers is a primary SAR indicator."
                    if degree >= 3 else
                    f"This account connects to {degree} other account"
                    f"{'s' if degree != 1 else ''} in this network."
                ),
                size="xs", c=DIM, style={"lineHeight": "1.55"},
            ),

            dmc.Text(
                action_note, size="xs", c="rgba(148,163,184,0.35)",
                mt=8, ta="right",
            ),
        ],
        style={
            "background": tier_bg,
            "border": f"1px solid {tier_col}55",
            "borderRadius": "8px",
            "padding": "12px",
        },
    )

    return card
