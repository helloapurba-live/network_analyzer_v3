"""
Shared helpers for FCDAI Report Pages.
--------------------------------------------------
All 7 report pages import from here:
  - empty_fig / styled_layout / chart helpers
  - Tier colour palette
  - Narrative card / page header builders
  - Common safe-data accessors
"""
from __future__ import annotations

import sys
from pathlib import Path

import dash_mantine_components as dmc
import plotly.graph_objects as go
from dash import dcc, html
from dash_iconify import DashIconify

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from config import THEME  # noqa: F401

# ─────────────────────────────────────────────────────────────────────────────
# COLOUR PALETTE
# ─────────────────────────────────────────────────────────────────────────────
TIER_COLORS = {
    "P1": "#FF1744",
    "P2": "#FF9800",
    "P3": "#FFD600",
    "P4": "#00E676",
}
TIER_LABELS = {
    "P1": "P1 — Critical",
    "P2": "P2 — High Risk",
    "P3": "P3 — Medium Risk",
    "P4": "P4 — Low Risk",
}
CHART_BG    = "rgba(0,0,0,0)"
CHART_TEXT  = "#94A3B8"
CHART_GRID  = "rgba(148,163,184,0.10)"
CARD_BG     = "rgba(13,18,33,0.95)"
BORDER      = "#1E293B"
DIM         = "#8899AA"
ACCENT_GOLD = "#FFD700"

# AML health thresholds
HEALTH_P1_CRITICAL  = 5   # >5% portfolio in P1 = RED
HEALTH_P1_AMBER     = 2   # >2% = AMBER
HEALTH_P2_HIGH      = 15  # >15% in P2 = RED
HEALTH_COVERAGE_OK  = 80  # <80% coverage = AMBER


# ─────────────────────────────────────────────────────────────────────────────
# PLOTLY HELPERS
# ─────────────────────────────────────────────────────────────────────────────
def empty_fig(msg: str = "Run pipeline to generate this report") -> go.Figure:
    fig = go.Figure()
    fig.add_annotation(
        text=msg,
        showarrow=False,
        font=dict(color="#4B5563", size=14),
        xref="paper",
        yref="paper",
        x=0.5,
        y=0.5,
    )
    fig.update_layout(
        paper_bgcolor=CHART_BG,
        plot_bgcolor=CHART_BG,
        margin=dict(l=30, r=30, t=30, b=30),
    )
    return fig


def styled_layout(
    fig: go.Figure,
    title: str = "",
    height: int | None = None,
    legend: bool = True,
    margin: dict | None = None,
) -> go.Figure:
    m = margin or dict(l=50, r=30, t=50 if title else 30, b=50)
    fig.update_layout(
        paper_bgcolor=CHART_BG,
        plot_bgcolor=CHART_BG,
        font=dict(color=CHART_TEXT, family="Inter, sans-serif"),
        title=dict(text=title, font=dict(color="white", size=13), x=0.01) if title else None,
        xaxis=dict(gridcolor=CHART_GRID, zerolinecolor=CHART_GRID, showgrid=True),
        yaxis=dict(gridcolor=CHART_GRID, zerolinecolor=CHART_GRID, showgrid=True),
        legend=dict(bgcolor="rgba(0,0,0,0)", font=dict(color=CHART_TEXT)) if legend else None,
        margin=m,
        hoverlabel=dict(bgcolor="#1E293B", font_color="white"),
    )
    if height:
        fig.update_layout(height=height)
    return fig


# ─────────────────────────────────────────────────────────────────────────────
# COMPONENT BUILDERS
# ─────────────────────────────────────────────────────────────────────────────
def page_header(
    icon: str,
    title: str,
    subtitle: str,
    story: str,
    accent: str = ACCENT_GOLD,
    last_run: str = "",
) -> dmc.Box:
    """Narrative page header with title, story, and last-run timestamp.

    Arg-order tolerance: if ``story`` looks like a CSS colour hex and
    ``accent`` is a long text, the two are automatically swapped.
    """
    # Auto-correct swapped story / accent args:
    #   page_header(icon,title,subtitle,"#HEX","long story text")
    if isinstance(story, str) and story.startswith("#") and len(story) in (4, 7, 9):
        story, accent = accent, story
    return dmc.Box(
        [
            dmc.Group(
                [
                    dmc.ThemeIcon(
                        DashIconify(icon=icon, width=32),
                        size=52,
                        radius="xl",
                        variant="gradient",
                        gradient={"from": accent, "to": "#1E293B", "deg": 135},
                    ),
                    dmc.Stack(
                        [
                            dmc.Title(title, order=2, c="white", style={"fontWeight": 800}),
                            dmc.Text(subtitle, c=DIM, size="sm"),
                        ],
                        gap=2,
                    ),
                ],
                gap="md",
                align="center",
            ),
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            DashIconify(icon="mdi:book-open-page-variant", width=16, color=accent),
                            dmc.Text("The Story", fw=700, size="sm", c=accent),
                        ],
                        gap="xs",
                        mb=6,
                    ),
                    dmc.Text(story, size="sm", c="dimmed", style={"lineHeight": "1.7"}),
                    dmc.Group(
                        [
                            DashIconify(icon="mdi:sync", width=14, color="#26C6DA"),
                            dmc.Text(
                                f"Auto-updates on every pipeline run.  {last_run}",
                                size="xs",
                                c="#26C6DA",
                            ),
                        ],
                        gap=6,
                        mt="sm",
                    ),
                ],
                p="md",
                radius="md",
                mt="md",
                style={
                    "background": f"linear-gradient(135deg, {accent}0D, rgba(7,12,20,0.9))",
                    "border": f"1px solid {accent}30",
                },
            ),
        ],
        mb="xl",
    )


def section_header(icon: str, title: str, description: str, accent: str = "#00D4FF") -> dmc.Group:
    """Section separator with icon, bold title, and plain description.

    Arg-order tolerance: if ``description`` looks like a CSS colour hex and
    ``accent`` is the real description text, the two are automatically swapped.
    """
    # Auto-correct swapped description / accent args:
    #   section_header(icon,title,"#HEX","actual description text")
    if isinstance(description, str) and description.startswith("#") and len(description) in (4, 7, 9):
        description, accent = accent, description
    return dmc.Group(
        [
            DashIconify(icon=icon, width=22, color=accent),
            dmc.Stack(
                [
                    dmc.Text(title, fw=700, size="sm", c="white"),
                    dmc.Text(description, size="xs", c="dimmed"),
                ],
                gap=0,
            ),
        ],
        gap="sm",
        mb="sm",
    )


def kpi_card(
    title: str,
    value: str,
    sub: str = "",
    icon: str = "mdi:counter",
    color: str = "cyan",
    trend: str = "",
    trend_up: bool = True,
    subtitle: str = "",        # accepted alias for sub (backward-compat)
) -> dmc.Paper:
    """Single KPI card with value, subtitle, optional trend arrow.

    Arg-order tolerance: if ``sub`` looks like an iconify name (starts with
    "mdi:" etc.) and ``icon`` looks like a CSS colour ("#…") the two are
    automatically swapped so callers that write
    ``kpi_card("Title","Val","mdi:icon","#color")`` still render correctly.
    """
    # Accept `subtitle` as alias when sub is not set
    if subtitle and not sub:
        sub = subtitle
    # Auto-correct swapped positional args:
    #   kpi_card("T","V","mdi:icon","#COLOR")  →  icon="mdi:icon", color="#COLOR"
    _ICON_PFXS = ("mdi:", "bi:", "fa:", "tabler:", "carbon:", "ic:", "ph:")
    if sub and any(sub.startswith(p) for p in _ICON_PFXS) and icon.startswith("#"):
        icon, color, sub = sub, icon, ""
    trend_color = "#00E676" if trend_up else "#FF6B6B"
    trend_icon = "mdi:trending-up" if trend_up else "mdi:trending-down"
    return dmc.Paper(
        [
            dmc.Group(
                [
                    dmc.ThemeIcon(
                        DashIconify(icon=icon, width=20),
                        size="lg",
                        radius="md",
                        variant="light",
                        color=color,
                    ),
                    dmc.Stack(
                        [
                            dmc.Text(title, size="xs", c="dimmed", fw=500, style={"letterSpacing": "0.3px"}),
                            dmc.Text(value, size="xl", fw=800, c="white"),
                            dmc.Group(
                                [
                                    dmc.Text(sub, size="xs", c="dimmed"),
                                    *(
                                        [
                                            DashIconify(icon=trend_icon, width=14, color=trend_color),
                                            dmc.Text(trend, size="xs", c=trend_color),
                                        ]
                                        if trend
                                        else []
                                    ),
                                ],
                                gap=4,
                            ),
                        ],
                        gap=1,
                    ),
                ],
                gap="md",
                align="flex-start",
            )
        ],
        p="md",
        radius="lg",
        className="glass-card",
    )


def rag_row(label: str, value: str, target: str, status: str, note: str = "") -> html.Tr:
    """Single row for RAG compliance scorecard table."""
    color_map = {"GREEN": "#00E676", "AMBER": "#FFD600", "RED": "#FF1744"}
    badge_color = {"GREEN": "green", "AMBER": "yellow", "RED": "red"}
    c = color_map.get(status.upper(), "#8899AA")
    bc = badge_color.get(status.upper(), "gray")
    cell_style = {"padding": "10px 14px", "borderBottom": "1px solid rgba(255,255,255,0.04)", "fontSize": "12px", "color": "#CBD5E1"}
    return html.Tr([
        html.Td(label, style=cell_style),
        html.Td(value, style={**cell_style, "fontWeight": 700, "color": "white"}),
        html.Td(target, style={**cell_style, "color": DIM}),
        html.Td(dmc.Badge(status.upper(), color=bc, variant="filled", size="sm"), style=cell_style),
        html.Td(note, style={**cell_style, "fontStyle": "italic", "color": DIM}),
    ])


def no_data_card(msg: str, sub: str = "", icon: str = "mdi:database-off") -> dmc.Paper:
    """Placeholder card when no pipeline data is available."""
    return dmc.Paper(
        dmc.Stack(
            [
                DashIconify(icon=icon, width=40, color="#374151"),
                dmc.Text(msg, fw=600, c="#4B5563", size="sm", ta="center"),
                dmc.Text(sub or "Upload data in Port Authority, then run the pipeline.", size="xs", c="#374151", ta="center"),
            ],
            align="center",
            gap="sm",
            py="xl",
        ),
        p="xl",
        radius="lg",
        className="glass-card",
    )


def fallback_note(msg: str, accent: str = "#FFD600") -> dmc.Paper:
    """Small inline note when optional data column is unavailable."""
    return dmc.Paper(
        dmc.Group(
            [
                DashIconify(icon="mdi:information-outline", width=14, color=accent),
                dmc.Text(msg, size="xs", c=accent),
            ],
            gap=6,
        ),
        p="xs",
        radius="md",
        style={"background": f"{accent}0D", "border": f"1px solid {accent}25"},
        mb="sm",
    )


def _tbl(tables: dict, *names: str):
    """Safe DataFrame lookup — avoids 'df or df2' which raises
    ValueError (truth value of a DataFrame is ambiguous).
    Returns the first non-None, non-empty DataFrame found, or None.
    """
    for n in names:
        df = tables.get(n) if tables else None
        if df is not None and hasattr(df, "empty") and not df.empty:
            return df
    return None


def _styled_kw(
    title: str = "",
    height: int | None = None,
    legend: bool = True,
    margin: dict | None = None,
) -> dict:
    """Return a plain layout *dict* (no figure needed).

    Use as:  ``fig.update_layout(**_styled_kw("My Title"), extra_param=value)``

    This is the dict-returning counterpart of ``styled_layout()``.
    Use when you need to merge layout settings with additional kwargs in
    a single ``update_layout`` call (e.g. funnelmode, yaxis overrides).
    """
    m = margin or dict(l=50, r=30, t=50 if title else 30, b=50)
    d: dict = dict(
        paper_bgcolor=CHART_BG,
        plot_bgcolor=CHART_BG,
        font=dict(color=CHART_TEXT, family="Inter, sans-serif"),
        xaxis=dict(gridcolor=CHART_GRID, zerolinecolor=CHART_GRID, showgrid=True),
        yaxis=dict(gridcolor=CHART_GRID, zerolinecolor=CHART_GRID, showgrid=True),
        margin=m,
        hoverlabel=dict(bgcolor="#1E293B", font_color="white"),
    )
    if title:
        d["title"] = dict(text=title, font=dict(color="white", size=13), x=0.01)
    if legend:
        d["legend"] = dict(bgcolor="rgba(0,0,0,0)", font=dict(color=CHART_TEXT))
    if height:
        d["height"] = height
    return d
