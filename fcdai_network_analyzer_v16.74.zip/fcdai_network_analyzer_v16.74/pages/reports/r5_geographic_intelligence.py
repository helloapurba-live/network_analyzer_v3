"""
REPORT R5 — Geographic Intelligence
=====================================
Group: G6 — "Is This a Local Problem or a Global One?"
Audience: MLRO, Head of Correspondent Banking, Chief Compliance Officer, Sanctions Team
Update: Auto-syncs on every pipeline run

Story: Risk does not respect branch boundaries. This page answers WHERE —
which states are generating the most suspicious activity, which countries are
appearing in flagged flows, and whether the bank has a concentration problem
in specific corridors. For correspondent banking teams and sanctions officers,
this page is their primary geographic intelligence tool. A cluster of P1
customers in a single state or country is not a coincidence — it is a pattern
that demands an immediate compliance response.
"""
from __future__ import annotations

import sys
from pathlib import Path

import dash
import dash_mantine_components as dmc
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from dash import Input, Output, callback, dcc, html
from dash_iconify import DashIconify

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from config import APP, THEME
from engine import get_pipeline
from utils.data_provider import get_latest_scored  # v16.72 F4
from pages.reports import (
    ACCENT_GOLD, CHART_BG, CHART_GRID, CHART_TEXT, DIM,
    TIER_COLORS, TIER_LABELS,
    empty_fig, fallback_note, kpi_card, no_data_card,
    page_header, section_header, styled_layout, _tbl, _styled_kw,
)

dash.register_page(
    __name__,
    path="/reports/geographic-intelligence",
    name="Geographic Intelligence",
    title=f"FCDAI v{APP.VERSION} | Geographic Intelligence",
)

# ─── US STATE ABBREVIATION MAP ────────────────────────────────────────────────
_US_STATE_ABBR = {
    "Alabama": "AL", "Alaska": "AK", "Arizona": "AZ", "Arkansas": "AR",
    "California": "CA", "Colorado": "CO", "Connecticut": "CT", "Delaware": "DE",
    "Florida": "FL", "Georgia": "GA", "Hawaii": "HI", "Idaho": "ID",
    "Illinois": "IL", "Indiana": "IN", "Iowa": "IA", "Kansas": "KS",
    "Kentucky": "KY", "Louisiana": "LA", "Maine": "ME", "Maryland": "MD",
    "Massachusetts": "MA", "Michigan": "MI", "Minnesota": "MN",
    "Mississippi": "MS", "Missouri": "MO", "Montana": "MT", "Nebraska": "NE",
    "Nevada": "NV", "New Hampshire": "NH", "New Jersey": "NJ",
    "New Mexico": "NM", "New York": "NY", "North Carolina": "NC",
    "North Dakota": "ND", "Ohio": "OH", "Oklahoma": "OK", "Oregon": "OR",
    "Pennsylvania": "PA", "Rhode Island": "RI", "South Carolina": "SC",
    "South Dakota": "SD", "Tennessee": "TN", "Texas": "TX", "Utah": "UT",
    "Vermont": "VT", "Virginia": "VA", "Washington": "WA",
    "West Virginia": "WV", "Wisconsin": "WI", "Wyoming": "WY",
    "District of Columbia": "DC",
}
# Reverse map: abbr → full name
_ABBR_TO_STATE = {v: k for k, v in _US_STATE_ABBR.items()}


def _normalise_state(val: str) -> str:
    """Accept full state name or 2-letter abbreviation, return abbreviation."""
    if not isinstance(val, str):
        return ""
    v = val.strip()
    if len(v) == 2:
        return v.upper()
    return _US_STATE_ABBR.get(v.title(), v.upper()[:2])


def _find_col(df: pd.DataFrame, candidates: list) -> str | None:
    for c in candidates:
        if c in df.columns:
            return c
    for c in candidates:
        matches = [col for col in df.columns if col.lower() == c.lower()]
        if matches:
            return matches[0]
    return None


# ─── LAYOUT ───────────────────────────────────────────────────────────────────
def layout():
    return dmc.Box(
        [
            dcc.Store(id="r5-geo-store"),
            dcc.Interval(id="r5-init", interval=800, max_intervals=1),
            page_header(
                "mdi:earth",
                "Geographic Intelligence",
                "G6 — Is This a Local Problem or a Global One?",
                "#4CAF50",
                (
                    "Risk does not respect branch boundaries. This page maps every customer "
                    "and transaction to its geographic origin — state by state, country by "
                    "country — revealing whether your AML exposure is concentrated in a handful "
                    "of locations or spread across the portfolio. A cluster of high-risk customers "
                    "in a single region is rarely coincidence. It is a pattern that demands "
                    "immediate compliance action, enhanced due diligence, and in some cases, "
                    "escalation to correspondent banking risk committees."
                ),
            ),

            # ── KPI Row ────────────────────────────────────────────────────────
            dmc.Grid(
                [
                    dmc.GridCol(html.Div(id="r5-kpi-states"), span=3),
                    dmc.GridCol(html.Div(id="r5-kpi-countries"), span=3),
                    dmc.GridCol(html.Div(id="r5-kpi-highest-state"), span=3),
                    dmc.GridCol(html.Div(id="r5-kpi-international-pct"), span=3),
                ],
                gutter="md", mb="xl",
            ),

            # ── Section 1: US Risk Concentration ───────────────────────────────
            section_header(
                "mdi:map-marker-radius",
                "US Risk Concentration — Where Are the Hot Spots?",
                "#4CAF50",
                (
                    "Every red patch on this map represents a US state where your customers "
                    "carry above-average AML risk. Regulators — from FinCEN to state banking "
                    "commissions — expect banks to maintain heightened surveillance in "
                    "geographically concentrated risk areas. Darker colours demand your "
                    "compliance team's attention first."
                ),
            ),
            dmc.Grid(
                [
                    dmc.GridCol(
                        dmc.Paper(
                            [
                                dmc.Text("Average Risk Score by State", fw=700, size="sm", mb="xs", c=CHART_TEXT),
                                dmc.Text(
                                    "Colour intensity = average risk score of all customers registered in that state. "
                                    "Darker red = higher concentration of AML risk.",
                                    size="xs", c=DIM, mb="sm",
                                ),
                                dcc.Loading(
                                    dcc.Graph(id="r5-us-avg-risk-map", config={"displayModeBar": False},
                                              style={"height": "420px"}),
                                    type="dot", color="#FF6B6B", delay_show=300,
                                ),
                            ],
                            p="lg", radius="lg", className="glass-card",
                        ),
                        span=6,
                    ),
                    dmc.GridCol(
                        dmc.Paper(
                            [
                                dmc.Text("Total Flagged Flow by State ($)", fw=700, size="sm", mb="xs", c=CHART_TEXT),
                                dmc.Text(
                                    "Colour intensity = total suspicious transaction value (P1 + P2 customers) "
                                    "originating from that state. This is the dollar exposure map.",
                                    size="xs", c=DIM, mb="sm",
                                ),
                                dcc.Loading(
                                    dcc.Graph(id="r5-us-flow-map", config={"displayModeBar": False},
                                              style={"height": "420px"}),
                                    type="dot", color="#FF1744", delay_show=300,
                                ),
                            ],
                            p="lg", radius="lg", className="glass-card",
                        ),
                        span=6,
                    ),
                ],
                gutter="md", mb="xl",
            ),

            # ── Section 2: Top 10 States Bar ───────────────────────────────────
            section_header(
                "mdi:podium",
                "Top 10 Highest-Risk States — The Priority List",
                "#FF9800",
                (
                    "These are the ten US states requiring the most immediate compliance attention. "
                    "The bar length represents the average risk score of customers registered "
                    "in that state. The number label shows how many customers are involved. "
                    "Any state with P1 customers exceeding 5% of its total should be escalated "
                    "to regional compliance leadership."
                ),
            ),
            dmc.Paper(
                dcc.Graph(id="r5-top-states-bar", config={"displayModeBar": False},
                          style={"height": "380px"}),
                p="lg", radius="lg", className="glass-card", mb="xl",
            ),

            # ── Section 3: International Flow ──────────────────────────────────
            section_header(
                "mdi:globe-model",
                "International Risk Exposure — Cross-Border Intelligence",
                "#2196F3",
                (
                    "Cross-border transactions with high-risk jurisdictions are a primary focus "
                    "of FATF, FinCEN, and correspondent banking guidance. This section maps "
                    "your customer base to their registered countries, showing where international "
                    "risk is concentrated. Countries appearing on FATF grey or black lists with "
                    "high-risk customers should be escalated to your sanctions and correspondent "
                    "banking compliance teams immediately."
                ),
            ),
            dmc.Grid(
                [
                    dmc.GridCol(
                        dmc.Paper(
                            [
                                dmc.Text("Global Risk Hotspot Map", fw=700, size="sm", mb="xs", c=CHART_TEXT),
                                dmc.Text(
                                    "Bubble size = number of flagged (P1+P2) customers from that country. "
                                    "Colour = average risk score. Hover for details.",
                                    size="xs", c=DIM, mb="sm",
                                ),
                                dcc.Graph(id="r5-world-bubble-map", config={"displayModeBar": False},
                                          style={"height": "400px"}),
                            ],
                            p="lg", radius="lg", className="glass-card",
                        ),
                        span=7,
                    ),
                    dmc.GridCol(
                        dmc.Paper(
                            [
                                dmc.Text("International Flow Risk Table", fw=700, size="sm", mb="xs", c=CHART_TEXT),
                                dmc.Text(
                                    "Country-level breakdown of flagged customers, total flow, "
                                    "and average risk score.",
                                    size="xs", c=DIM, mb="sm",
                                ),
                                html.Div(id="r5-country-table"),
                            ],
                            p="lg", radius="lg", className="glass-card",
                        ),
                        span=5,
                    ),
                ],
                gutter="md", mb="xl",
            ),
        ],
        p="xl",
    )


# ─── CALLBACK ─────────────────────────────────────────────────────────────────
@callback(
    Output("r5-kpi-states", "children"),
    Output("r5-kpi-countries", "children"),
    Output("r5-kpi-highest-state", "children"),
    Output("r5-kpi-international-pct", "children"),
    Output("r5-us-avg-risk-map", "figure"),
    Output("r5-us-flow-map", "figure"),
    Output("r5-top-states-bar", "figure"),
    Output("r5-world-bubble-map", "figure"),
    Output("r5-country-table", "children"),
    Input("pipeline-state", "data"),
    Input("global-refresh-ts", "data"),
    Input("r5-init", "n_intervals"),
    prevent_initial_call=False,
)
def update_r5(pipeline_state, _grt=None, _init=None):
    _empty = empty_fig("Run pipeline first")

    if isinstance(pipeline_state, dict) and pipeline_state.get("reset"):
        return (
            kpi_card("US States", "—", "mdi:map-marker", "#4CAF50"),
            kpi_card("Countries", "—", "mdi:earth", "#2196F3"),
            kpi_card("Highest Risk State", "—", "mdi:alert-circle", "#FF5252"),
            kpi_card("International %", "—", "mdi:globe-model", "#FF9800"),
            _empty, _empty, _empty, _empty,
            dmc.Text("No data loaded.", c=DIM, size="sm"),
        )

    pipeline = get_pipeline()
    # v16.72 F4+F5: unified loader — memory-first, DB fallback, score_* normalize
    _dp    = get_latest_scored(pipeline)
    scored = _dp["scored"]

    if scored is None or len(scored) == 0:
        nd = no_data_card("Geographic intelligence unavailable — run the pipeline first.")
        return (
            kpi_card("US States", "—", "mdi:map-marker", "#4CAF50"),
            kpi_card("Countries", "—", "mdi:earth", "#2196F3"),
            kpi_card("Highest Risk State", "—", "mdi:alert-circle", "#FF5252"),
            kpi_card("International %", "—", "mdi:globe-model", "#FF9800"),
            _empty, _empty, _empty, _empty,
            nd,
        )

    # v16.74 N2: Use _dp["tables"] (memory→DB fallback) instead of raw
    # pipeline.tables so geographic charts render after server restart/page refresh.
    node_tbl = _tbl(_dp["tables"], "node", "nodes", "customer")
    edge_tbl = _tbl(_dp["tables"], "edge", "edges", "transaction")

    # ── Merge scored with node table to get state/country ────────────────────
    try:
        node_id_col   = _find_col(scored, ["node_id", "customer_id", "id"])
        score_col     = _find_col(scored, ["risk_score", "score", "final_score"])
        tier_col      = _find_col(scored, ["tier", "risk_tier"])

        merged = scored.copy()
        state_col = country_col = None

        if node_tbl is not None:
            ni   = _find_col(node_tbl, ["node_id", "customer_id", "id"])
            sc   = _find_col(node_tbl, ["state", "State", "us_state"])
            cc   = _find_col(node_tbl, ["country", "Country", "country_code"])
            if ni and (sc or cc) and node_id_col:
                cols_to_merge = [ni] + ([sc] if sc else []) + ([cc] if cc else [])
                sub = node_tbl[cols_to_merge].rename(columns={ni: node_id_col})
                sub[node_id_col] = sub[node_id_col].astype(str)
                merged[node_id_col] = merged[node_id_col].astype(str)
                merged = merged.merge(sub, on=node_id_col, how="left")
                state_col   = sc
                country_col = cc

        # ── Merge edge amounts per node into scored ───────────────────────────
        amount_by_node = {}
        if edge_tbl is not None and node_id_col:
            src = _find_col(edge_tbl, ["source", "from_id", "sender_id", "from_node"])
            amt = _find_col(edge_tbl, ["amount", "transaction_amount", "value"])
            if src and amt:
                try:
                    agg = edge_tbl.groupby(edge_tbl[src].astype(str))[amt].sum()
                    amount_by_node = agg.to_dict()
                except Exception:
                    pass

        if node_id_col and amount_by_node:
            merged["_total_amount"] = merged[node_id_col].astype(str).map(amount_by_node).fillna(0)
        else:
            merged["_total_amount"] = 0

        # ───── STATE ANALYSIS ────────────────────────────────────────────────
        us_fig_risk = _empty
        us_fig_flow = _empty
        top_bar_fig = _empty
        kpi_states  = kpi_card("US States", "—", "mdi:map-marker", "#4CAF50")
        highest_state_kpi = kpi_card("Highest Risk State", "—", "mdi:alert-circle", "#FF5252")

        if state_col and state_col in merged.columns:
            merged["_state_abbr"] = merged[state_col].astype(str).apply(_normalise_state)
            state_df = merged[merged["_state_abbr"].str.len() == 2].copy()

            if len(state_df) > 0 and score_col:
                state_stats = (
                    state_df.groupby("_state_abbr")
                    .agg(
                        avg_score   = (score_col, "mean"),
                        customer_ct = (node_id_col if node_id_col else score_col, "count"),
                        total_flow  = ("_total_amount", "sum"),
                        p1_ct       = (tier_col, lambda x: (x == "P1").sum()) if tier_col else (score_col, "count"),
                    )
                    .reset_index()
                    .rename(columns={"_state_abbr": "state"})
                )
                state_stats["avg_score"] = state_stats["avg_score"].round(1)

                n_states = len(state_stats)
                kpi_states = kpi_card("US States Covered", str(n_states), "mdi:map-marker", "#4CAF50")

                highest_row = state_stats.loc[state_stats["avg_score"].idxmax()]
                kpi_highest = kpi_card(
                    "Highest Risk State",
                    f"{highest_row['state']} ({highest_row['avg_score']:.0f})",
                    "mdi:alert-circle", "#FF5252",
                )
                highest_state_kpi = kpi_highest

                # Map 1: avg risk
                us_fig_risk = go.Figure(
                    go.Choropleth(
                        locations=state_stats["state"],
                        z=state_stats["avg_score"],
                        locationmode="USA-states",
                        colorscale=[[0, "#0D1218"], [0.3, "#1A237E"],
                                    [0.6, "#FF9800"], [1.0, "#FF1744"]],
                        colorbar=dict(title="Avg Risk", tickfont=dict(color=CHART_TEXT)),
                        hovertemplate=(
                            "<b>%{location}</b><br>"
                            "Avg Risk Score: %{z:.1f}<br>"
                            "Customers: %{customdata[0]:,}<extra></extra>"
                        ),
                        customdata=state_stats[["customer_ct"]].values,
                        zmin=0, zmax=100,
                    )
                )
                us_fig_risk.update_layout(
                    geo=dict(scope="usa", bgcolor=CHART_BG, lakecolor=CHART_BG,
                             landcolor="#1A1E2E", showlakes=True),
                    paper_bgcolor=CHART_BG, plot_bgcolor=CHART_BG,
                    margin=dict(l=0, r=0, t=10, b=10),
                    font=dict(color=CHART_TEXT),
                )

                # Map 2: flagged flow $
                if state_stats["total_flow"].sum() > 0:
                    # Use 95th-percentile as zmax so all states are visually distinguishable
                    _flow_max = state_stats["total_flow"].max()
                    _flow_p90 = float(state_stats["total_flow"].quantile(0.90))
                    _zmax_flow = max(_flow_p90 * 1.05, _flow_max * 0.35, 1.0)
                    _zmax_flow = min(_zmax_flow, _flow_max)  # never exceed actual max
                    us_fig_flow = go.Figure(
                        go.Choropleth(
                            locations=state_stats["state"],
                            z=state_stats["total_flow"],
                            locationmode="USA-states",
                            colorscale=[[0, "#0D1218"], [0.3, "#0D47A1"],
                                        [0.6, "#FF6B6B"], [1.0, "#FF1744"]],
                            colorbar=dict(
                                title="Total Flow ($)",
                                tickfont=dict(color=CHART_TEXT),
                                tickformat="$,.0f",
                            ),
                            hovertemplate=(
                                "<b>%{location}</b><br>"
                                "Total Suspicious Flow: $%{z:,.0f}<br>"
                                "Customers: %{customdata[0]:,}<extra></extra>"
                            ),
                            customdata=state_stats[["customer_ct"]].values,
                            zmin=0,
                            zmax=_zmax_flow,
                        )
                    )
                    us_fig_flow.update_layout(
                        geo=dict(scope="usa", bgcolor=CHART_BG, lakecolor=CHART_BG,
                                 landcolor="#1A1E2E", showlakes=True),
                        paper_bgcolor=CHART_BG, plot_bgcolor=CHART_BG,
                        margin=dict(l=0, r=0, t=10, b=10),
                        font=dict(color=CHART_TEXT),
                    )
                    if _zmax_flow < _flow_max:
                        us_fig_flow.add_annotation(
                            text=f"Colour scale capped at ${_zmax_flow:,.0f} (90th pct) to show state-level differences. Max: ${_flow_max:,.0f}",
                            xref="paper", yref="paper", x=0.5, y=-0.07,
                            showarrow=False, font=dict(size=9, color="#94A3B8"),
                            xanchor="center",
                        )
                else:
                    us_fig_flow = empty_fig("No transaction amount data — upload edge table with 'amount' column")

                # Top 10 bar
                top10 = state_stats.nlargest(10, "avg_score").sort_values("avg_score")
                bar_colors = [TIER_COLORS["P1"] if s >= 70 else
                              TIER_COLORS["P2"] if s >= 50 else
                              TIER_COLORS["P3"] if s >= 30 else
                              TIER_COLORS["P4"] for s in top10["avg_score"]]
                top_bar_fig = go.Figure(
                    go.Bar(
                        x=top10["avg_score"],
                        y=top10["state"],
                        orientation="h",
                        marker_color=bar_colors,
                        text=[f"  {ct:,} customers" for ct in top10["customer_ct"]],
                        textposition="outside",
                        textfont=dict(color=CHART_TEXT, size=11),
                        hovertemplate=(
                            "<b>%{y}</b><br>Avg Risk: %{x:.1f}"
                            "<br>Customers: %{customdata:,}<extra></extra>"
                        ),
                        customdata=top10["customer_ct"],
                    )
                )
                top_bar_fig.update_layout(
                    **_styled_kw("Top 10 States by Average Customer Risk Score", height=380)
                )
                top_bar_fig.update_layout(
                    xaxis=dict(title="Average Risk Score (0–100)", range=[0, 115],
                               color=CHART_TEXT, gridcolor=CHART_GRID),
                    yaxis=dict(title="", color=CHART_TEXT),
                )
        else:
            kpi_states = kpi_card(
                "US States", "No state col",
                "mdi:map-marker-off", "#9E9E9E",
                subtitle="Add 'state' column to node table",
            )

        # ───── COUNTRY ANALYSIS ──────────────────────────────────────────────
        world_fig = _empty
        country_table = dmc.Text("No country data — add 'country' column to node table.", c=DIM, size="sm")
        kpi_countries = kpi_card("Countries", "—", "mdi:earth", "#2196F3")
        kpi_intl_pct  = kpi_card("International %", "—", "mdi:globe-model", "#FF9800")

        if country_col and country_col in merged.columns:
            cnt_df = merged[merged[country_col].notna()].copy()
            cnt_df["_country"] = cnt_df[country_col].astype(str).str.strip()
            cnt_df = cnt_df[cnt_df["_country"] != ""]

            # v16.71 M8: Normalise country abbreviations/codes to Plotly locationmode="country names"
            _COUNTRY_NORM = {
                "US": "United States", "USA": "United States", "U.S.A.": "United States",
                "U.S.": "United States", "UNITED STATES OF AMERICA": "United States",
                "UK": "United Kingdom", "GB": "United Kingdom", "GBR": "United Kingdom",
                "U.K.": "United Kingdom", "GREAT BRITAIN": "United Kingdom",
                "UAE": "United Arab Emirates", "U.A.E.": "United Arab Emirates",
                "KSA": "Saudi Arabia", "S.ARABIA": "Saudi Arabia",
                "KOR": "South Korea", "PRK": "North Korea",
                "CHN": "China", "CN": "China",
                "DEU": "Germany", "FRA": "France", "ITA": "Italy", "ESP": "Spain",
                "NLD": "Netherlands", "BEL": "Belgium", "CHE": "Switzerland",
                "AUT": "Austria", "SWE": "Sweden", "NOR": "Norway", "DNK": "Denmark",
                "FIN": "Finland", "PRT": "Portugal", "GRC": "Greece", "POL": "Poland",
                "CZE": "Czech Republic", "HUN": "Hungary", "ROU": "Romania",
                "RUS": "Russia", "TUR": "Turkey", "IND": "India", "PAK": "Pakistan",
                "BRA": "Brazil", "ARG": "Argentina", "MEX": "Mexico", "CAN": "Canada",
                "AUS": "Australia", "NZL": "New Zealand", "JPN": "Japan", "SGP": "Singapore",
                "HKG": "Hong Kong", "MYS": "Malaysia", "IDN": "Indonesia", "THA": "Thailand",
                "VNM": "Vietnam", "PHL": "Philippines", "ZAF": "South Africa",
                "NGA": "Nigeria", "KEN": "Kenya", "EGY": "Egypt", "MAR": "Morocco",
                "IRN": "Iran", "IRQ": "Iraq", "ISR": "Israel", "JOR": "Jordan",
                "LBN": "Lebanon", "KWT": "Kuwait", "BHR": "Bahrain", "QAT": "Qatar",
                "OMN": "Oman", "YEM": "Yemen", "LBY": "Libya", "TUN": "Tunisia",
                "DZA": "Algeria",
            }
            cnt_df["_country"] = cnt_df["_country"].apply(
                lambda x: _COUNTRY_NORM.get(x.upper(), _COUNTRY_NORM.get(x, x))
            )

            if len(cnt_df) > 0:
                non_us = cnt_df[cnt_df["_country"] != "United States"]
                n_countries = cnt_df["_country"].nunique()
                intl_pct = len(non_us) / len(merged) * 100 if len(merged) > 0 else 0

                kpi_countries = kpi_card(
                    "Countries Covered", str(n_countries), "mdi:earth", "#2196F3"
                )
                kpi_intl_pct = kpi_card(
                    "International Customers",
                    f"{intl_pct:.1f}%",
                    "mdi:globe-model", "#FF9800",
                )

                if tier_col and score_col:
                    country_stats = (
                        cnt_df.groupby("_country")
                        .agg(
                            flagged_ct   = (tier_col, lambda x: ((x == "P1") | (x == "P2")).sum()),
                            total_ct     = (node_id_col if node_id_col else score_col, "count"),
                            avg_score    = (score_col, "mean"),
                            total_flow   = ("_total_amount", "sum"),
                        )
                        .reset_index()
                        .rename(columns={"_country": "Country"})
                    )
                    country_stats["avg_score"] = country_stats["avg_score"].round(1)
                    country_stats = country_stats.sort_values("avg_score", ascending=False)

                    # World bubble map
                    flagged_df = country_stats[country_stats["flagged_ct"] > 0].copy()
                    if len(flagged_df) > 0:
                        world_fig = px.scatter_geo(
                            flagged_df,
                            locations="Country",
                            locationmode="country names",
                            size="flagged_ct",
                            color="avg_score",
                            color_continuous_scale=[[0, "#0D47A1"], [0.5, "#FF9800"], [1, "#FF1744"]],
                            size_max=50,
                            hover_data={"flagged_ct": ":,", "total_flow": ":,.0f"},
                            labels={"avg_score": "Avg Risk", "flagged_ct": "Flagged Customers",
                                    "total_flow": "Total Flow ($)"},
                        )
                        world_fig.update_layout(
                            geo=dict(bgcolor=CHART_BG, landcolor="#1A1E2E",
                                     showocean=True, oceancolor="#0A0F1A",
                                     showcoastlines=True, coastlinecolor="#2D3748"),
                            paper_bgcolor=CHART_BG,
                            coloraxis_colorbar=dict(title="Avg Risk", tickfont=dict(color=CHART_TEXT)),
                            margin=dict(l=0, r=0, t=10, b=10),
                            font=dict(color=CHART_TEXT),
                        )
                    else:
                        world_fig = empty_fig("No flagged (P1/P2) customers with country data")

                    # Country table
                    top_countries = country_stats.head(20)
                    rows = []
                    for _, row in top_countries.iterrows():
                        risk = row["avg_score"]
                        tier_color = (TIER_COLORS["P1"] if risk >= 70 else
                                      TIER_COLORS["P2"] if risk >= 50 else
                                      TIER_COLORS["P3"] if risk >= 30 else TIER_COLORS["P4"])
                        rows.append(
                            dmc.TableTr([
                                dmc.TableTd(dmc.Text(str(row["Country"])[:20], size="xs", fw=600, c=CHART_TEXT)),
                                dmc.TableTd(dmc.Text(f"{int(row['flagged_ct']):,}", size="xs",
                                                     c=TIER_COLORS["P1"] if row['flagged_ct'] > 0 else DIM)),
                                dmc.TableTd(dmc.Text(f"{int(row['total_ct']):,}", size="xs", c=DIM)),
                                dmc.TableTd(
                                    dmc.Badge(f"{risk:.0f}", color="red" if risk >= 70 else
                                              "orange" if risk >= 50 else "yellow" if risk >= 30 else "gray",
                                              variant="filled", size="xs"),
                                ),
                                dmc.TableTd(
                                    dmc.Text(f"${row['total_flow']:,.0f}" if row['total_flow'] > 0 else "—",
                                             size="xs", c="#00E676" if row['total_flow'] > 0 else DIM),
                                ),
                            ])
                        )
                    country_table = dmc.Box([
                        dmc.Table(
                            [
                                dmc.TableThead(dmc.TableTr([
                                    dmc.TableTh(dmc.Text("Country", size="xs", c=ACCENT_GOLD, fw=700)),
                                    dmc.TableTh(dmc.Text("Flagged", size="xs", c=ACCENT_GOLD, fw=700)),
                                    dmc.TableTh(dmc.Text("Total", size="xs", c=ACCENT_GOLD, fw=700)),
                                    dmc.TableTh(dmc.Text("Avg Risk", size="xs", c=ACCENT_GOLD, fw=700)),
                                    dmc.TableTh(dmc.Text("Flow $", size="xs", c=ACCENT_GOLD, fw=700)),
                                ])),
                                dmc.TableTbody(rows),
                            ],
                            striped=True,
                            highlightOnHover=True,
                            style={"fontSize": "11px"},
                        ),
                    ], style={"overflowY": "auto", "maxHeight": "360px"})

    except Exception as e:
        nd = no_data_card(f"Geographic analysis error: {e}")
        return (
            kpi_card("US States", "Error", "mdi:alert", "#FF5252"),
            kpi_card("Countries", "Error", "mdi:alert", "#FF5252"),
            kpi_card("Highest Risk State", "Error", "mdi:alert", "#FF5252"),
            kpi_card("International %", "Error", "mdi:alert", "#FF5252"),
            empty_fig(f"Error: {e}"), empty_fig(f"Error: {e}"),
            empty_fig(f"Error: {e}"), empty_fig(f"Error: {e}"),
            nd,
        )

    return (
        kpi_states,
        kpi_countries,
        highest_state_kpi,
        kpi_intl_pct,
        us_fig_risk,
        us_fig_flow,
        top_bar_fig,
        world_fig,
        country_table,
    )
