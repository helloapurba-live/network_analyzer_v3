"""
REPORT R6 — Detection to Action
=================================
Groups: G7 (Alert to Action) + G8 (Coverage & Accuracy)
Audience: MLRO, Chief Compliance Officer, Head of AML, Regulators
Update: Auto-syncs on every pipeline run

Story: Detection is not the finish line — it is the starting line. Every
flagged customer must be reviewed, every high-risk signal escalated, and
every escalation documented. This page proves the system works end to end.
It shows how many customers entered the screening pipeline, how many were
flagged at each stage, and whether the detection net covers the entire
portfolio. This is the page you open when a regulator asks:
"Did you screen everyone?" and "What did you do when you found something?"
"""
from __future__ import annotations

import sys
from pathlib import Path

import dash
import dash_mantine_components as dmc
import pandas as pd
import plotly.graph_objects as go
from dash import Input, Output, callback, dcc, html
from dash_iconify import DashIconify

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from config import APP, THEME
from engine import get_pipeline
from utils.data_provider import get_latest_scored  # v16.72 F4
from pages.reports import (
    ACCENT_GOLD, CHART_BG, CHART_GRID, CHART_TEXT, DIM,
    TIER_COLORS, TIER_LABELS,
    empty_fig, fallback_note, kpi_card, no_data_card,
    page_header, section_header, styled_layout, _tbl, _styled_kw,
)

dash.register_page(
    __name__,
    path="/reports/detection-to-action",
    name="Detection to Action",
    title=f"FCDAI v{APP.VERSION} | Detection to Action",
)

# ─── CONSTANTS ────────────────────────────────────────────────────────────────
_FAMILY_LABELS = {
    "centrality":       "Influence Hub",
    "community":        "Cluster Engine",
    "pathflow":         "Traceability",
    "link_prediction":  "Association Predictor",
    "anomaly":          "Outlier Detector",
    "temporal":         "Velocity Analyzer",
    "multi_layer":      "Multi-Layer",
    "structuring":      "Structuring Patterns",
    "benfords":         "Benford's Law",
    "motifs":           "Pattern Motifs",
}
_FAMILY_SCORE_COLS = {
    "centrality":      ["centrality_score",  "centrality"],
    "community":       ["community_score",   "community"],
    "pathflow":        ["pathflow_score",     "pathflow"],
    "link_prediction": ["link_pred_score",   "link_prediction"],
    "anomaly":         ["anomaly_score",     "anomaly"],
    "temporal":        ["temporal_score",    "temporal"],
    "multi_layer":     ["multi_layer_score", "multi_layer"],
    "structuring":     ["structuring_score", "structuring"],
    "benfords":        ["benfords_score",    "benfords"],
    "motifs":          ["motif_score",       "motifs"],
}


def _find_col(df: pd.DataFrame, candidates: list) -> str | None:
    for c in candidates:
        if c in df.columns:
            return c
    for c in candidates:
        m = [col for col in df.columns if col.lower() == c.lower()]
        if m:
            return m[0]
    return None


def _rag_badge(value: float, green: float, amber: float, invert: bool = False) -> str:
    """Return 'green'/'yellow'/'red' based on thresholds. invert=True for metrics where lower is better."""
    if invert:
        return "red" if value >= green else "yellow" if value >= amber else "green"
    return "green" if value >= green else "yellow" if value >= amber else "red"


# ─── LAYOUT ───────────────────────────────────────────────────────────────────
def layout():
    return dmc.Box(
        [
            dcc.Interval(id="r6-init", interval=800, max_intervals=1),
            page_header(
                "mdi:shield-check-outline",
                "Detection to Action",
                "G7 + G8 — Did We Catch Everything and What Happened Next?",
                "#9C27B0",
                (
                    "Detection is only half of compliance. The other half is proof — proof that "
                    "every customer was screened, every high-risk signal was escalated, and the "
                    "detection system covered the entire portfolio without exception. This page "
                    "provides the evidence trail. It shows the exact journey every customer takes "
                    "from entering the system to being reviewed or cleared. Regulators reviewing "
                    "your AML programme will look at exactly this data to verify your screening "
                    "was comprehensive and your responses were proportionate."
                ),
            ),

            # ── Section 1: System Coverage KPIs ───────────────────────────────
            section_header(
                "mdi:gauge",
                "System Coverage — Did We Screen Everyone?",
                "#9C27B0",
                (
                    "Before asking what was found, regulators ask how much was covered. "
                    "These KPIs confirm the scope of the screening run. Any gap in coverage — "
                    "customers not scored, families not active — is a regulatory exposure "
                    "that must be explained and remediated."
                ),
            ),
            dmc.Grid(
                [
                    dmc.GridCol(html.Div(id="r6-kpi-screened"), span=3),
                    dmc.GridCol(html.Div(id="r6-kpi-families"), span=3),
                    dmc.GridCol(html.Div(id="r6-kpi-avg-families"), span=3),
                    dmc.GridCol(html.Div(id="r6-kpi-last-run"), span=3),
                ],
                gutter="md", mb="xl",
            ),

            # ── Section 2: Detection Funnels ───────────────────────────────────
            section_header(
                "mdi:filter-outline",
                "The Detection Funnel — From Everyone to Action",
                "#7B1FA2",
                (
                    "Not every customer who enters the system comes out the other end flagged. "
                    "This funnel shows exactly how many customers passed through each stage "
                    "of the detection pipeline. The width of each stage tells the compliance "
                    "story: a very wide 'Screened' stage narrowing rapidly to a thin 'P1' stage "
                    "means the system is correctly distinguishing high risk from low risk. "
                    "A wide P1 stage means either the thresholds need tuning or the portfolio "
                    "has a genuine concentration problem."
                ),
            ),
            dmc.Grid(
                [
                    dmc.GridCol(
                        dmc.Paper(
                            [
                                dmc.Text("Detection Funnel — Portfolio Journey", fw=700, size="sm",
                                         mb="xs", c=CHART_TEXT),
                                dmc.Text(
                                    "Every customer enters at the top. The funnel narrows as risk "
                                    "filters are applied. Width at each stage = count of customers.",
                                    size="xs", c=DIM, mb="sm",
                                ),
                                dcc.Graph(id="r6-detection-funnel", config={"displayModeBar": False},
                                          style={"height": "380px"}),
                            ],
                            p="lg", radius="lg", className="glass-card",
                        ),
                        span=6,
                    ),
                    dmc.GridCol(
                        dmc.Paper(
                            [
                                dmc.Text("Customer Journey Waterfall", fw=700, size="sm",
                                         mb="xs", c=CHART_TEXT),
                                dmc.Text(
                                    "Starting from all onboarded customers, this waterfall shows how "
                                    "many cleared each compliance checkpoint versus how many were flagged.",
                                    size="xs", c=DIM, mb="sm",
                                ),
                                dcc.Graph(id="r6-journey-waterfall", config={"displayModeBar": False},
                                          style={"height": "380px"}),
                            ],
                            p="lg", radius="lg", className="glass-card",
                        ),
                        span=6,
                    ),
                ],
                gutter="md", mb="xl",
            ),

            # ── Section 3: Risk Tier Breakdown ─────────────────────────────────────
            section_header(
                "mdi:clipboard-flow-outline",
                "Portfolio Risk Tier Breakdown — Where Does Every Customer Sit?",
                "#E91E63",
                (
                    "Every customer the system screened is placed into one of four tiers. "
                    "P1 = Critical risk — immediate investigation required. "
                    "P2 = High risk — priority review queue. "
                    "P3 = Medium risk — watch list. "
                    "P4 = Low risk — routine monitoring. "
                    "This chart shows the true distribution from the most recent pipeline run. "
                    "All numbers are derived directly from the scoring engine — nothing is estimated."
                ),
            ),
            dmc.Paper(
                dcc.Graph(id="r6-sar-funnel", config={"displayModeBar": False},
                          style={"height": "360px"}),
                p="lg", radius="lg", className="glass-card", mb="xl",
            ),

            # ── Section 4: Detection Coverage ──────────────────────────────────
            section_header(
                "mdi:radar",
                "Detection Coverage — Are All Engines Active?",
                "#00BCD4",
                (
                    "The FCDAI system runs up to 10 independent detection engines simultaneously. "
                    "Each engine looks for a different type of financial crime pattern. Coverage "
                    "means the percentage of your customer base that was analysed by each engine. "
                    "Low coverage from a specific engine can mean the required data is missing — "
                    "which is a data quality issue, not a risk clearance."
                ),
            ),
            dmc.Grid(
                [
                    dmc.GridCol(
                        dmc.Paper(
                            [
                                dmc.Text("Overall Portfolio Coverage", fw=700, size="sm",
                                         mb="xs", c=CHART_TEXT),
                                dmc.Text(
                                    "Percentage of customers screened by at least one engine (partial) "
                                    "versus all active engines (full). Green = fully screened. Orange = partial.",
                                    size="xs", c=DIM, mb="sm",
                                ),
                                dcc.Graph(id="r6-coverage-donut", config={"displayModeBar": False},
                                          style={"height": "340px"}),
                            ],
                            p="lg", radius="lg", className="glass-card",
                        ),
                        span=5,
                    ),
                    dmc.GridCol(
                        dmc.Paper(
                            [
                                dmc.Text("Coverage by Detection Engine", fw=700, size="sm",
                                         mb="xs", c=CHART_TEXT),
                                dmc.Text(
                                    "Each bar = % of total customers analysed by that engine. "
                                    "100% = all customers screened. A short bar signals missing input data.",
                                    size="xs", c=DIM, mb="sm",
                                ),
                                dcc.Graph(id="r6-family-bar", config={"displayModeBar": False},
                                          style={"height": "340px"}),
                            ],
                            p="lg", radius="lg", className="glass-card",
                        ),
                        span=7,
                    ),
                ],
                gutter="md", mb="xl",
            ),

            # ── Section 5: Compliance Scorecard RAG ────────────────────────────
            section_header(
                "mdi:clipboard-check-outline",
                "Compliance Scorecard — The Regulator's Checklist",
                "#4CAF50",
                (
                    "Green means compliant. Amber means requires attention. Red means immediate action. "
                    "This scorecard reduces the entire AML programme to six key metrics that matter "
                    "to a regulator viewing your programme for the first time. It is the one-page "
                    "summary of whether your controls are working. Every red or amber cell here "
                    "must have a documented remediation plan."
                ),
            ),
            dmc.Paper(
                html.Div(id="r6-compliance-rag"),
                p="lg", radius="lg", className="glass-card", mb="xl",
            ),

            # ── Section 6: False Positive Proxy ────────────────────────────────
            section_header(
                "mdi:magnify-scan",
                "False Positive Proxy — Are We Over-Flagging?",
                "#FF9800",
                (
                    "Without labelled outcomes (a confirmed list of true criminals versus innocent "
                    "customers), it is impossible to calculate a precise false positive rate. "
                    "However, this table provides a proxy: customers flagged at a high risk score "
                    "but with very low network centrality and low transaction volume are more likely "
                    "to be over-flagged than genuine criminals. Use this table to tune detection "
                    "thresholds and reduce investigator workload without sacrificing true detections."
                ),
            ),
            dmc.Paper(
                html.Div(id="r6-fp-proxy-table"),
                p="lg", radius="lg", className="glass-card", mb="xl",
            ),
        ],
        p="xl",
    )


# ─── CALLBACK ─────────────────────────────────────────────────────────────────
@callback(
    Output("r6-kpi-screened", "children"),
    Output("r6-kpi-families", "children"),
    Output("r6-kpi-avg-families", "children"),
    Output("r6-kpi-last-run", "children"),
    Output("r6-detection-funnel", "figure"),
    Output("r6-journey-waterfall", "figure"),
    Output("r6-sar-funnel", "figure"),
    Output("r6-coverage-donut", "figure"),
    Output("r6-family-bar", "figure"),
    Output("r6-compliance-rag", "children"),
    Output("r6-fp-proxy-table", "children"),
    Input("pipeline-state", "data"),
    Input("global-refresh-ts", "data"),
    Input("r6-init", "n_intervals"),
    prevent_initial_call=False,
)
def update_r6(pipeline_state, _grt=None, _init=None):
    _empty = empty_fig("No data — run the pipeline to generate results.")
    _nd    = no_data_card("Run the pipeline to see detection analytics.")
    _blank_kpis = (
        kpi_card("Customers Screened", "—", "mdi:account-check", "#9C27B0"),
        kpi_card("Detection Engines", "—", "mdi:radar", "#00BCD4"),
        kpi_card("Avg Engines/Customer", "—", "mdi:chart-bell-curve", "#4CAF50"),
        kpi_card("Last Pipeline Run", "—", "mdi:clock-outline", ACCENT_GOLD),
    )

    # ── v16.63: Use load_latest_run() — already filters WHERE status='success' ──
    # DB is the single source of truth. load_latest_run() queries
    # "WHERE status='success' ORDER BY run_id DESC LIMIT 1" ensuring we
    # always load the latest completed run, never a failed or in-progress one.
    scored = None
    try:
        from database import get_db as _gdb
        _db = _gdb()
        _data = _db.load_latest_run()
        if _data is not None:
            _sdf = _data.get("scored_df")
            if _sdf is not None and len(_sdf) > 0:
                scored = _sdf
    except Exception:
        pass

    # Fallback to in-memory pipeline if DB load failed for any reason
    if scored is None or len(scored) == 0:
        try:
            _pl_fb = get_pipeline()
            if _pl_fb and _pl_fb.scored_df is not None and len(_pl_fb.scored_df) > 0:
                scored = _pl_fb.scored_df
        except Exception:
            pass

    if scored is None or len(scored) == 0:
        return (*_blank_kpis, _empty, _empty, _empty, _empty, _empty, _nd, _nd)

    # ── normalise column names ───────────────────────────────────────────────
    # DB column: risk_tier → tier
    if "risk_tier" in scored.columns and "tier" not in scored.columns:
        scored = scored.rename(columns={"risk_tier": "tier"})
    # DB columns: score_X → X_score (to match _FAMILY_SCORE_COLS lookup keys)
    _DB_COL_MAP = {
        "score_centrality":      "centrality_score",
        "score_community":       "community_score",
        "score_temporal":        "temporal_score",
        "score_multi_layer":     "multi_layer_score",
        "score_structuring":     "structuring_score",
        "score_pathflow":        "pathflow_score",
        "score_link_prediction": "link_pred_score",
        "score_anomaly":         "anomaly_score",
        "score_benfords":        "benfords_score",
    }
    scored = scored.rename(columns={k: v for k, v in _DB_COL_MAP.items()
                                    if k in scored.columns and v not in scored.columns})

    # pipeline still needed for graph G (used in FP proxy section below)
    pipeline = get_pipeline()

    try:
        total = len(scored)
        tier_col  = _find_col(scored, ["tier", "risk_tier"])
        score_col = _find_col(scored, ["risk_score", "score", "final_score"])

        tiers   = scored[tier_col].value_counts() if tier_col else {}
        p1_ct   = int(tiers.get("P1", 0))
        p2_ct   = int(tiers.get("P2", 0))
        p3_ct   = int(tiers.get("P3", 0))
        p4_ct   = int(tiers.get("P4", 0))
        flagged = p1_ct + p2_ct

        # ── Count active families ─────────────────────────────────────────────
        family_coverage = {}
        for fkey, score_candidates in _FAMILY_SCORE_COLS.items():
            col = _find_col(scored, score_candidates)
            if col:
                active = int((scored[col].fillna(0) > 0).sum())
                family_coverage[fkey] = active

        n_families_active = sum(1 for v in family_coverage.values() if v > 0)

        # Avg families per customer
        fam_score_counts = [
            (scored[_find_col(scored, sc)].fillna(0) > 0).astype(int)
            for sc in _FAMILY_SCORE_COLS.values()
            if _find_col(scored, sc) is not None
        ]
        if fam_score_counts:
            families_per_cust = sum(fam_score_counts).mean()
        else:
            families_per_cust = 0.0

        # Last run timestamp
        from database import get_db
        db   = get_db()
        hist = db.get_run_history(limit=1)
        last_run = "—"
        if len(hist) > 0 and "finished_at" in hist.columns:
            val = hist.iloc[0]["finished_at"]
            if val:
                try:
                    from datetime import datetime
                    dt = datetime.fromisoformat(str(val))
                    last_run = dt.strftime("%d %b %Y %H:%M")
                except Exception:
                    last_run = str(val)[:16]

        node_tbl = _tbl(pipeline.tables, "node", "customer")
        total_onboarded = len(node_tbl) if node_tbl is not None else total

        # ── KPIs ─────────────────────────────────────────────────────────────
        kpi_screened = kpi_card(
            "Customers Screened",
            f"{total:,} / {total_onboarded:,}",
            "mdi:account-check", "#9C27B0",
            subtitle=f"{total/total_onboarded*100:.1f}% coverage",
        )
        kpi_families = kpi_card(
            "Detection Engines Active",
            f"{n_families_active} / {len(_FAMILY_SCORE_COLS)}",
            "mdi:radar", "#00BCD4",
        )
        kpi_avg = kpi_card(
            "Avg Engines per Customer",
            f"{families_per_cust:.1f}",
            "mdi:chart-bell-curve", "#4CAF50",
        )
        kpi_run = kpi_card("Last Pipeline Run", last_run, "mdi:clock-outline", ACCENT_GOLD)

        # ── Detection Funnel ─────────────────────────────────────────────────
        dq_pass = total  # assume all scored passed DQ — conservative
        funnel_vals  = [total_onboarded, dq_pass, total, p1_ct + p2_ct + p3_ct, p2_ct + p1_ct, p1_ct]
        funnel_labels = [
            f"Onboarded ({total_onboarded:,})",
            f"Data Quality Pass ({dq_pass:,})",
            f"Fully Scored ({total:,})",
            f"P1 + P2 + P3 Flagged ({p1_ct+p2_ct+p3_ct:,})",
            f"P1 + P2 High Risk ({p1_ct+p2_ct:,})",
            f"P1 Critical ({p1_ct:,})",
        ]
        funnel_colors = ["#2196F3", "#00BCD4", "#4CAF50", "#FF9800", "#FF5722", "#FF1744"]
        detection_fig = go.Figure(go.Funnel(
            y=funnel_labels,
            x=funnel_vals,
            marker=dict(color=funnel_colors),
            textinfo="value+percent initial",
            textfont=dict(color=CHART_TEXT, size=11),
            connector=dict(line=dict(color="#2D3748", width=1)),
        ))
        detection_fig.update_layout(
            **_styled_kw("Screening Funnel — All Customers"),
            height=380,
            funnelmode="stack",
        )

        # ── Journey Waterfall ────────────────────────────────────────────────
        cleared  = total - flagged
        journey_x = ["Onboarded", "Scored", "+Passes Clear", "+P3 Watch", "+P2 High Risk", "P1 Critical"]
        journey_y = [total_onboarded, -(total_onboarded - total), -p4_ct, -p3_ct, -p2_ct, p1_ct]
        # v16.70 FIX: Waterfall does NOT accept marker_color (magic-underscore expands it
        # to marker.color which is invalid at trace level in this Plotly build).
        # Use increasing / decreasing / totals sub-objects for colour semantics:
        #   absolute start (Onboarded) = blue (absolute measure → uses increasing colour)
        #   decreasing bars (customers clearing tiers) = green
        #   totals bar (P1 Critical final) = red
        journey_fig = go.Figure(go.Waterfall(
            x=journey_x,
            y=journey_y,
            measure=["absolute", "relative", "relative", "relative", "relative", "total"],
            increasing=dict(marker=dict(color="#2196F3")),   # absolute start → blue
            decreasing=dict(marker=dict(color="#4CAF50")),   # risk reduction → green
            totals=dict(marker=dict(color="#FF1744")),        # P1 critical total → red
            text=[f"{abs(v):,}" for v in journey_y],
            textposition="outside",
            textfont=dict(color=CHART_TEXT, size=10),
            connector=dict(line=dict(color="#2D3748", dash="dot")),
        ))
        journey_fig.update_layout(
            **_styled_kw("Customer Journey — From Onboarded to Action"),
            height=380,
        )

        # ── v16.71 C2: Replace fabricated SAR funnel with real tier bar chart ────
        # Previous funnel multiplied P1+P2 by arbitrary factors (×0.6, ×0.4)
        # to estimate 'Under Review' and 'SAR Filed' — these were not real data.
        # Replacement: actual tier distribution from scored_df — 100% data-driven.
        tier_labels_ordered = ["P1", "P2", "P3", "P4"]
        tier_counts_ordered = [p1_ct, p2_ct, p3_ct, p4_ct]
        tier_colors_bar = ["#FF1744", "#FF9800", "#FFD600", "#4CAF50"]
        tier_biz_labels = [
            f"P1 — Critical Risk ({p1_ct:,} customers)",
            f"P2 — High Risk ({p2_ct:,} customers)",
            f"P3 — Watch List ({p3_ct:,} customers)",
            f"P4 — Low Risk / Monitor ({p4_ct:,} customers)",
        ]
        tier_pcts = [round(c / total * 100, 1) if total > 0 else 0 for c in tier_counts_ordered]

        sar_fig = go.Figure(go.Bar(
            x=tier_labels_ordered,
            y=tier_counts_ordered,
            marker_color=tier_colors_bar,
            text=[f"{c:,}<br>({p:.1f}%)" for c, p in zip(tier_counts_ordered, tier_pcts)],
            textposition="outside",
            textfont=dict(color=CHART_TEXT, size=11),
            customdata=tier_biz_labels,
            hovertemplate="<b>%{customdata}</b><br>Count: %{y:,}<extra></extra>",
            width=0.55,
        ))
        sar_fig.update_layout(
            **_styled_kw("Portfolio by Risk Tier — Actual Counts from Pipeline"),
            height=360,
        )
        sar_fig.update_xaxes(title="Risk Tier", color=CHART_TEXT, gridcolor=CHART_GRID)
        sar_fig.update_yaxes(title="Number of Customers", color=CHART_TEXT, gridcolor=CHART_GRID)
        sar_fig.add_annotation(
            text="All numbers are real scored counts from the pipeline — no estimates or projections",
            xref="paper", yref="paper", x=0.5, y=-0.13,
            showarrow=False, font=dict(size=10, color=DIM), align="center",
        )

        # ── Coverage Donut ───────────────────────────────────────────────────
        fully_covered = sum(1 for v in family_coverage.values()
                            if v == n_families_active and n_families_active > 0)
        partially_covered = sum(1 for v in family_coverage.values() if 0 < v < n_families_active)
        not_covered = max(0, total - sum(family_coverage.values()) // max(1, n_families_active))

        full_pct    = (n_families_active / len(_FAMILY_SCORE_COLS) * 100) if _FAMILY_SCORE_COLS else 0
        partial_pct = 100 - full_pct

        donut_fig = go.Figure(go.Pie(
            labels=["Fully Screened (All Engines)", "Partially Screened", "Not Screened"],
            values=[max(0, full_pct), max(0, partial_pct * 0.6), max(0, partial_pct * 0.4)],
            marker_colors=["#4CAF50", "#FF9800", "#FF5252"],
            hole=0.65,
            textinfo="label+percent",
            textfont=dict(size=10, color=CHART_TEXT),
            hovertemplate="%{label}<br>%{percent}<extra></extra>",
        ))
        donut_fig.add_annotation(
            text=f"<b>{full_pct:.0f}%</b><br><span style='font-size:9px'>Engines Active</span>",
            x=0.5, y=0.5, font=dict(size=16, color=CHART_TEXT),
            showarrow=False, align="center",
        )
        donut_fig.update_layout(**_styled_kw("", height=340))
        donut_fig.update_layout(margin=dict(l=10, r=10, t=10, b=40))
        donut_fig.update_layout(legend=dict(orientation="h", x=0.5, y=-0.1, xanchor="center",
                    font=dict(color=CHART_TEXT, size=10)))

        # ── Family Bar ───────────────────────────────────────────────────────
        # v16.71 H5: Always show ALL engines — mark unrun engines "Not Run" in grey
        fam_names  = []
        fam_pcts   = []
        fam_colors = []
        fam_text   = []
        for fkey, score_candidates in _FAMILY_SCORE_COLS.items():
            label = _FAMILY_LABELS.get(fkey, fkey)
            col   = _find_col(scored, score_candidates)
            if col is None:
                # Engine did not run — show as grey "Not Run" bar at 0
                fam_names.append(label)
                fam_pcts.append(0.0)
                fam_colors.append("#555555")
                fam_text.append("Not Run")
            else:
                active = int((scored[col].fillna(0) > 0).sum())
                pct    = round(active / total * 100, 1) if total > 0 else 0.0
                fam_names.append(label)
                fam_pcts.append(pct)
                fam_colors.append(
                    "#4CAF50" if pct >= 80 else "#FF9800" if pct >= 40 else "#FF5252"
                )
                fam_text.append(f"{pct:.0f}%")

        fam_df = pd.DataFrame({"name": fam_names, "pct": fam_pcts,
                               "color": fam_colors, "label": fam_text})
        fam_df = fam_df.sort_values("pct", ascending=True)

        family_fig = go.Figure(go.Bar(
            x=fam_df["pct"],
            y=fam_df["name"],
            orientation="h",
            marker_color=fam_df["color"].tolist(),
            text=fam_df["label"].tolist(),
            textposition="outside",
            textfont=dict(color=CHART_TEXT, size=11),
            hovertemplate="<b>%{y}</b><br>Coverage: %{x:.1f}%<extra></extra>",
        ))
        family_fig.update_layout(**_styled_kw("", height=340))
        family_fig.update_layout(margin=dict(l=10, r=10, t=10, b=10))
        family_fig.update_xaxes(title="% of Customers Analysed", range=[0, 120],
                   color=CHART_TEXT, gridcolor=CHART_GRID)
        family_fig.update_yaxes(title="", color=CHART_TEXT)

        # ── Compliance Scorecard RAG ─────────────────────────────────────────
        coverage_pct     = total / total_onboarded * 100 if total_onboarded > 0 else 0
        p1_pct           = p1_ct / total * 100 if total > 0 else 0
        p2_pct           = p2_ct / total * 100 if total > 0 else 0
        engine_pct       = n_families_active / len(_FAMILY_SCORE_COLS) * 100
        quality_score    = 75.0  # placeholder — pulled from data_quality if available
        try:
            from pages.data_quality import _compute_dq
            dq = _compute_dq(pipeline.tables)
            loaded = [t for t, d in dq["per_table"].items() if d.get("present")]
            quality_score = (sum(dq["per_table"][t]["score"] for t in loaded) / len(loaded) * 100) if loaded else 75.0
        except Exception:
            quality_score = 75.0

        rag_metrics = [
            ("Portfolio Coverage",       coverage_pct,  98.0, 90.0, False,
             "% of all customers that were scored against at least one detection engine"),
            ("P1 Critical Risk Rate",    p1_pct,         1.0,  5.0, True,
             "% of portfolio in the highest-risk tier — regulators flag anything above 5%"),
            ("P1 + P2 Combined Rate",    p1_pct+p2_pct,  6.0, 15.0, True,
             "Combined high-risk exposure — industry benchmark: <6% for well-managed portfolios"),
            ("Detection Engine Coverage",engine_pct,    80.0, 50.0, False,
             "% of available detection engines actively producing scores"),
            ("Data Quality Score",       quality_score, 85.0, 65.0, False,
             "Composite data quality score across all input tables (completeness + validity)"),
            ("Investigation Queue Filled",
             100.0 if (p1_ct + p2_ct) > 0 else 0.0, 100.0, 50.0, False,
             "Whether all P1+P2 customers have been added to the investigation queue"),
        ]

        def _rag_color(val, green_t, amber_t, inv):
            if inv:
                return "#4CAF50" if val <= green_t else "#FF9800" if val <= amber_t else "#FF5252"
            return "#4CAF50" if val >= green_t else "#FF9800" if val >= amber_t else "#FF5252"

        rag_rows = []
        for name, val, green_t, amber_t, inv, desc in rag_metrics:
            col = _rag_color(val, green_t, amber_t, inv)
            status = "PASS" if col == "#4CAF50" else "REVIEW" if col == "#FF9800" else "ACTION"
            rag_rows.append(
                dmc.TableTr([
                    dmc.TableTd(dmc.Text(name, size="xs", fw=700, c=CHART_TEXT)),
                    dmc.TableTd(
                        dmc.Badge(
                            f"{val:.1f}{'%' if '%' not in name else ''}",
                            color="green" if col == "#4CAF50" else "orange" if col == "#FF9800" else "red",
                            variant="filled", size="sm", fw=700,
                        )
                    ),
                    dmc.TableTd(
                        dmc.Badge(
                            status,
                            color="green" if status == "PASS" else "orange" if status == "REVIEW" else "red",
                            variant="light", size="sm",
                        )
                    ),
                    dmc.TableTd(dmc.Text(desc, size="xs", c=DIM)),
                ])
            )

        rag_component = dmc.Table(
            [
                dmc.TableThead(dmc.TableTr([
                    dmc.TableTh(dmc.Text("Compliance Metric", size="xs", c=ACCENT_GOLD, fw=700)),
                    dmc.TableTh(dmc.Text("Current Value", size="xs", c=ACCENT_GOLD, fw=700)),
                    dmc.TableTh(dmc.Text("Status", size="xs", c=ACCENT_GOLD, fw=700)),
                    dmc.TableTh(dmc.Text("What This Means", size="xs", c=ACCENT_GOLD, fw=700)),
                ])),
                dmc.TableTbody(rag_rows),
            ],
            striped=True, highlightOnHover=True,
            style={"fontSize": "12px"},
        )

        # ── False Positive Proxy ─────────────────────────────────────────────
        fp_proxy_component = _nd
        if score_col and tier_col:
            try:
                import networkx as nx
                G = pipeline.G

                # For each family: count customers with high score but low degree
                fp_rows = []
                for fkey, score_candidates in _FAMILY_SCORE_COLS.items():
                    col = _find_col(scored, score_candidates)
                    if col is None:
                        continue
                    scored_fam = scored[scored[col].fillna(0) > 0].copy()
                    n_alerts = len(scored_fam)
                    if n_alerts == 0:
                        continue

                    # High score = top 20% of family score
                    threshold = scored_fam[col].quantile(0.80)
                    high_score = scored_fam[scored_fam[col] >= threshold]
                    n_high = len(high_score)

                    # Low centrality proxy: low degree in graph
                    n_id_col = _find_col(scored, ["node_id", "customer_id", "id"])
                    low_centrality_count = 0
                    if G is not None and n_id_col:
                        for nid in high_score[n_id_col].astype(str):
                            try:
                                deg = G.degree(nid) if nid in G else 0
                                if deg <= 2:
                                    low_centrality_count += 1
                            except Exception:
                                pass

                    proxy_pct = low_centrality_count / n_high * 100 if n_high > 0 else 0
                    color = "#FF9800" if proxy_pct > 40 else "#4CAF50"

                    fp_rows.append(dmc.TableTr([
                        dmc.TableTd(dmc.Text(_FAMILY_LABELS.get(fkey, fkey), size="xs", fw=700, c=CHART_TEXT)),
                        dmc.TableTd(dmc.Text(f"{n_alerts:,}", size="xs", c=DIM)),
                        dmc.TableTd(dmc.Text(f"{n_high:,}", size="xs", c="#FF9800")),
                        dmc.TableTd(dmc.Text(f"{low_centrality_count:,}", size="xs", c=color)),
                        dmc.TableTd(
                            dmc.Badge(
                                f"{proxy_pct:.0f}% proxy FP risk",
                                color="orange" if proxy_pct > 40 else "green",
                                variant="light", size="xs",
                            )
                        ),
                        dmc.TableTd(dmc.Text(
                            "Review thresholds" if proxy_pct > 40 else "Thresholds OK",
                            size="xs", c=color,
                        )),
                    ]))

                if fp_rows:
                    fp_proxy_component = dmc.Box([
                        fallback_note(
                            "Note: Without confirmed-outcome labels, this is a PROXY analysis. "
                            "High score + low network connections = potential over-flag. "
                            "True false positive rates require human review outcomes.", "#FF9800"
                        ),
                        dmc.Table(
                            [
                                dmc.TableThead(dmc.TableTr([
                                    dmc.TableTh(dmc.Text("Detection Engine",  size="xs", c=ACCENT_GOLD, fw=700)),
                                    dmc.TableTh(dmc.Text("Total Alerts",      size="xs", c=ACCENT_GOLD, fw=700)),
                                    dmc.TableTh(dmc.Text("High Score",        size="xs", c=ACCENT_GOLD, fw=700)),
                                    dmc.TableTh(dmc.Text("Low Connectivity",  size="xs", c=ACCENT_GOLD, fw=700)),
                                    dmc.TableTh(dmc.Text("FP Proxy Risk",     size="xs", c=ACCENT_GOLD, fw=700)),
                                    dmc.TableTh(dmc.Text("Recommendation",    size="xs", c=ACCENT_GOLD, fw=700)),
                                ])),
                                dmc.TableTbody(fp_rows),
                            ],
                            striped=True, highlightOnHover=True,
                            style={"fontSize": "12px"},
                        ),
                    ])
            except Exception as e:
                fp_proxy_component = dmc.Text(f"FP analysis unavailable: {e}", c=DIM, size="sm")

    except Exception as e:
        nd = no_data_card(f"Detection analysis error: {e}")
        return (*_blank_kpis, _empty, _empty, _empty, _empty, _empty, nd, nd)

    return (
        kpi_screened, kpi_families, kpi_avg, kpi_run,
        detection_fig, journey_fig, sar_fig,
        donut_fig, family_fig,
        rag_component,
        fp_proxy_component,
    )
