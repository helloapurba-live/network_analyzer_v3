"""
REPORT R7 — System Quality
====================================
Group: G10 — "Can We Trust the Numbers?"
Audience: MLRO, Head of Data, Chief Compliance Officer, Internal Audit, Regulators
Update: Auto-syncs on every pipeline run

Story: The foundation story. Every risk score, ring detection, and geographic
flag in the entire FCDAI system is only as reliable as the data feeding it.
A perfect algorithm running on incomplete or stale data produces unreliable
results — and unreliable results in AML mean either missed criminals (risk)
or false accusations (legal exposure). This page is the MLRO's defence
when questioned by a regulator: "Our data was clean, current, and complete.
Here is the proof." It also shows whether the system's behaviour is stable
over time — or drifting in ways that require attention.
"""
from __future__ import annotations

import json
import sys
from datetime import datetime
from pathlib import Path

import dash
import dash_mantine_components as dmc
import pandas as pd
import plotly.graph_objects as go
from dash import Input, Output, callback, dcc, html
from dash_iconify import DashIconify

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from config import APP, THEME
from database import get_db
from engine import get_pipeline
from utils.data_provider import get_latest_scored  # v16.72 F4
from pages.reports import (
    ACCENT_GOLD, CHART_BG, CHART_GRID, CHART_TEXT, DIM,
    TIER_COLORS, TIER_LABELS,
    empty_fig, fallback_note, kpi_card, no_data_card,
    page_header, section_header, styled_layout, _styled_kw,
)

dash.register_page(
    __name__,
    path="/reports/data-system-quality",
    name="System Quality",
    title=f"FCDAI v{APP.VERSION} | System Quality",
)

# ─── TABLE DEFINITIONS ───────────────────────────────────────────────────────
_TABLE_META = {
    "node":        {"label": "Customer / Node Table",    "icon": "mdi:account-box",          "required": True,  "desc": "Core entity data — every customer must be here"},
    "edge":        {"label": "Transaction / Edge Table", "icon": "mdi:swap-horizontal",       "required": True,  "desc": "All financial transactions between customers"},
    "kyc":         {"label": "KYC Table",                "icon": "mdi:card-account-details",  "required": False, "desc": "Know Your Customer identity verification records"},
    "transaction": {"label": "Transaction Detail",       "icon": "mdi:cash-multiple",         "required": False, "desc": "Detailed transaction records with amounts and types"},
    "alert":       {"label": "Alert / SAR Table",        "icon": "mdi:alert-circle-outline",  "required": False, "desc": "Historical alerts and SAR filings"},
    "temporal":    {"label": "Temporal / Time Series",   "icon": "mdi:clock-outline",         "required": False, "desc": "Time-stamped activity data for velocity analysis"},
}
_ALL_TABLES = list(_TABLE_META.keys())


def _score_table(df: pd.DataFrame) -> dict:
    """Compute completeness, consistency, validity scores for a DataFrame."""
    if df is None or len(df) == 0:
        return {"present": False, "rows": 0, "cols": 0, "score": 0.0,
                "completeness": 0.0, "consistency": 0.0, "validity": 0.0,
                "null_pct": 1.0, "dup_pct": 0.0}
    rows, cols = len(df), len(df.columns)
    total_cells = rows * cols
    null_ct  = df.isnull().sum().sum()
    null_pct = null_ct / total_cells if total_cells > 0 else 0

    dup_ct  = int(df.duplicated().sum())
    dup_pct = dup_ct / rows if rows > 0 else 0

    # Numeric validity: check for obviously bad values
    numeric_cols = df.select_dtypes(include="number").columns
    invalid_ct = 0
    for col in numeric_cols:
        invalid_ct += int((df[col] < 0).sum())
    validity = max(0.0, 1.0 - (invalid_ct / (rows * max(1, len(numeric_cols)))))

    completeness = 1.0 - null_pct
    consistency  = 1.0 - dup_pct
    score = completeness * 0.40 + consistency * 0.30 + validity * 0.30

    return {
        "present": True, "rows": rows, "cols": cols,
        "score": round(score, 4), "null_pct": round(null_pct, 4),
        "dup_pct": round(dup_pct, 4), "completeness": round(completeness, 4),
        "consistency": round(consistency, 4), "validity": round(validity, 4),
    }


def _rag_color(val: float, green_t: float, amber_t: float) -> str:
    return "#4CAF50" if val >= green_t else "#FF9800" if val >= amber_t else "#FF5252"


# ─── LAYOUT ───────────────────────────────────────────────────────────────────
def layout():
    return dmc.Box(
        [
            page_header(
                "mdi:database-check-outline",
                "System Quality",
                'G10 — "Can We Trust the Numbers?"',
                "#26C6DA",
                (
                    "Every risk score, network detection, and geographic flag in this system is only "
                    "as reliable as the data that feeds it. Incomplete transaction records mean missed "
                    "connections. Stale KYC data means risk scores built on outdated information. "
                    "This page answers the regulator's foundational challenge before it is ever asked: "
                    "'Were your controls based on complete, accurate, and timely data?' "
                    "It also tracks whether the system's behaviour — the proportion of customers "
                    "flagged at each tier — is stable over time or drifting in a direction that "
                    "requires investigation."
                ),
            ),

            # ── Section 1: Data Health KPIs ────────────────────────────────────
            section_header(
                "mdi:database-sync",
                "Data Health at a Glance — Is the Foundation Solid?",
                "#26C6DA",
                (
                    "These four numbers summarise the health of every data source feeding the system. "
                    "A score below 85% on any metric requires investigation before the risk scores "
                    "produced in this pipeline run should be treated as authoritative. Think of this "
                    "as the 'pre-flight check' before any AML decision is made."
                ),
            ),
            dmc.Grid(
                [
                    dmc.GridCol(html.Div(id="r7-kpi-overall-quality"), span=3),
                    dmc.GridCol(html.Div(id="r7-kpi-tables-loaded"), span=3),
                    dmc.GridCol(html.Div(id="r7-kpi-completeness"), span=3),
                    dmc.GridCol(html.Div(id="r7-kpi-total-rows"), span=3),
                ],
                gutter="md", mb="xl",
            ),

            # ── Section 2: Per-Table Quality Scorecard ──────────────────────────
            section_header(
                "mdi:table-check",
                "Source Data Quality Scorecard — Table by Table",
                "#00BCD4",
                (
                    "This scorecard breaks down data quality for every input table individually. "
                    "Required tables (marked ★) must be present and of high quality — the system "
                    "cannot run without them. Optional tables enhance detection accuracy when "
                    "available. A red row here is actionable: fix the data source, then re-run "
                    "the pipeline."
                ),
            ),
            dmc.Paper(
                html.Div(id="r7-quality-scorecard"),
                p="lg", radius="lg", className="glass-card", mb="xl",
            ),

            # ── Section 3: Per-Table Detail ─────────────────────────────────────
            section_header(
                "mdi:table-eye",
                "Data Source Detail Table — Row Counts, Nulls, Duplicates",
                "#4CAF50",
                (
                    "A deeper look at each table: exact row and column counts, null rates, "
                    "and duplicate records. Null rates above 20% in key columns (like customer ID "
                    "or transaction amount) should be flagged for the data engineering team. "
                    "High duplicate rates suggest the ETL pipeline is double-loading records."
                ),
            ),
            dmc.Paper(
                html.Div(id="r7-detail-table"),
                p="lg", radius="lg", className="glass-card", mb="xl",
            ),

            # ── Section 4: Model Drift ─────────────────────────────────────────
            section_header(
                "mdi:trending-up",
                "Model Drift — Is the System Stable Over Time?",
                "#FF9800",
                (
                    "If the percentage of P1 (critical risk) customers is steadily increasing run "
                    "over run, one of three things is happening: (1) the underlying customer base "
                    "is genuinely becoming riskier, (2) the data quality is improving and previously "
                    "hidden risk is now visible, or (3) a model parameter has drifted and is now "
                    "over-flagging. This chart helps distinguish between these scenarios. "
                    "A stable, flat line is the expected outcome of a well-calibrated system."
                ),
            ),
            dmc.Paper(
                dcc.Graph(id="r7-drift-chart", config={"displayModeBar": False},
                          style={"height": "380px"}),
                p="lg", radius="lg", className="glass-card", mb="xl",
            ),

            # ── Section 5: Data Completeness Trend ─────────────────────────────
            section_header(
                "mdi:chart-line",
                "Data Completeness Trend — Are We Getting Better?",
                "#9C27B0",
                (
                    "Data quality is not a one-time fix — it is a continuous improvement programme. "
                    "This chart tracks the completeness score of each required data source across "
                    "every pipeline run. An upward trend means the data engineering team's efforts "
                    "are working. A downward trend means a data feed has degraded and needs "
                    "immediate investigation."
                ),
            ),
            dmc.Paper(
                dcc.Graph(id="r7-completeness-trend", config={"displayModeBar": False},
                          style={"height": "360px"}),
                p="lg", radius="lg", className="glass-card", mb="xl",
            ),

            # ── Section 6: Pipeline Performance ────────────────────────────────
            section_header(
                "mdi:timer-outline",
                "Pipeline Performance — Speed and Reliability",
                "#FF5722",
                (
                    "This chart shows how long each pipeline run has taken to complete. "
                    "Sudden spikes in runtime can indicate data volume increases, infrastructure "
                    "issues, or algorithm complexity problems. For a production AML system, "
                    "pipeline runs should complete within a predictable time window. "
                    "Monitoring this prevents silent failures where runs take hours instead of minutes."
                ),
            ),
            dmc.Paper(
                dcc.Graph(id="r7-pipeline-perf", config={"displayModeBar": False},
                          style={"height": "320px"}),
                p="lg", radius="lg", className="glass-card", mb="xl",
            ),
        ],
        p="xl",
    )


# ─── CALLBACK ─────────────────────────────────────────────────────────────────
@callback(
    Output("r7-kpi-overall-quality", "children"),
    Output("r7-kpi-tables-loaded",   "children"),
    Output("r7-kpi-completeness",    "children"),
    Output("r7-kpi-total-rows",      "children"),
    Output("r7-quality-scorecard",   "children"),
    Output("r7-detail-table",        "children"),
    Output("r7-drift-chart",         "figure"),
    Output("r7-completeness-trend",  "figure"),
    Output("r7-pipeline-perf",       "figure"),
    Input("pipeline-state", "data"),
    prevent_initial_call=False,
)
def update_r7(pipeline_state):
    _empty  = empty_fig("Run pipeline first")
    _nd     = no_data_card("Run the pipeline to populate data quality reports.")
    _blanks = (
        kpi_card("Overall Quality", "—", "mdi:database-check", "#26C6DA"),
        kpi_card("Tables Loaded",   "—", "mdi:table",          "#4CAF50"),
        kpi_card("Completeness",    "—", "mdi:check-all",      "#FF9800"),
        kpi_card("Total Rows",      "—", "mdi:counter",        "#9C27B0"),
    )

    if isinstance(pipeline_state, dict) and pipeline_state.get("reset"):
        return (*_blanks, _nd, _nd, _empty, _empty, _empty)

    pipeline = get_pipeline()
    # v16.72 F4+F5: unified loader — memory-first, DB fallback, score_* normalize
    _dp_r7 = get_latest_scored(pipeline)
    try:
        tables = _dp_r7["tables"] or {}

        # ── Score each table ─────────────────────────────────────────────────
        table_scores = {}
        for tname in _ALL_TABLES:
            df = tables.get(tname)
            table_scores[tname] = _score_table(df)

        loaded     = [t for t in _ALL_TABLES if table_scores[t]["present"]]
        n_loaded   = len(loaded)
        n_required = sum(1 for t in _ALL_TABLES if _TABLE_META[t]["required"] and table_scores[t]["present"])
        n_req_total = sum(1 for t in _ALL_TABLES if _TABLE_META[t]["required"])

        if not loaded:
            return (*_blanks, _nd, _nd, _empty, _empty, _empty)

        avg_score       = sum(table_scores[t]["score"] for t in loaded) / n_loaded * 100
        avg_completeness = sum(table_scores[t]["completeness"] for t in loaded) / n_loaded * 100
        total_rows      = sum(table_scores[t]["rows"] for t in loaded)

        # ── KPIs ─────────────────────────────────────────────────────────────
        qual_color = "#4CAF50" if avg_score >= 85 else "#FF9800" if avg_score >= 65 else "#FF5252"
        kpi_quality = kpi_card(
            "Overall Data Quality", f"{avg_score:.0f}%",
            "mdi:database-check", qual_color,
            subtitle=("Excellent" if avg_score >= 85 else "Needs Attention" if avg_score >= 65 else "Critical"),
        )
        req_color = "#4CAF50" if n_required == n_req_total else "#FF9800"
        kpi_tables = kpi_card(
            "Tables Loaded",
            f"{n_loaded} / {len(_ALL_TABLES)}",
            "mdi:table", req_color,
            subtitle=f"Required: {n_required}/{n_req_total}",
        )
        comp_color = "#4CAF50" if avg_completeness >= 90 else "#FF9800" if avg_completeness >= 70 else "#FF5252"
        kpi_comp = kpi_card(
            "Avg Completeness", f"{avg_completeness:.0f}%",
            "mdi:check-all", comp_color,
        )
        kpi_rows = kpi_card(
            "Total Records Loaded", f"{total_rows:,}",
            "mdi:counter", "#9C27B0",
        )

        # ── Quality Scorecard ────────────────────────────────────────────────
        scorecard_rows = []
        for tname in _ALL_TABLES:
            meta  = _TABLE_META[tname]
            stats = table_scores[tname]

            if not stats["present"]:
                continue  # Don't show rows for tables that haven't been loaded

            s = stats["score"] * 100
            c_col = _rag_color(stats["completeness"] * 100, 90, 70)
            v_col = _rag_color(stats["validity"] * 100, 90, 70)
            o_col = _rag_color(s, 85, 65)
            status = "PASS" if s >= 85 else "REVIEW" if s >= 65 else "ACTION REQUIRED"

            scorecard_rows.append(dmc.TableTr([
                dmc.TableTd(dmc.Group([
                    DashIconify(icon=meta["icon"], width=16, color=ACCENT_GOLD),
                    dmc.Text(meta["label"] + (" ★" if meta["required"] else ""), size="xs",
                             fw=700, c=CHART_TEXT),
                ], gap=4)),
                dmc.TableTd(
                    dmc.Badge(status,
                              color="green" if s >= 85 else "orange" if s >= 65 else "red",
                              variant="filled", size="xs")
                ),
                dmc.TableTd(
                    dmc.Text(f"{stats['completeness']*100:.0f}%", size="xs",
                             c=c_col, fw=700)
                ),
                dmc.TableTd(
                    dmc.Text(f"{stats['consistency']*100:.0f}%", size="xs",
                             c=_rag_color(stats['consistency']*100, 90, 70), fw=700)
                ),
                dmc.TableTd(
                    dmc.Text(f"{stats['validity']*100:.0f}%", size="xs",
                             c=v_col, fw=700)
                ),
                dmc.TableTd(
                    dmc.Badge(f"{s:.0f}%",
                              color="green" if s >= 85 else "orange" if s >= 65 else "red",
                              variant="light", size="sm", fw=700)
                ),
                dmc.TableTd(dmc.Text(meta["desc"], size="xs", c=DIM)),
            ]))

        scorecard = dmc.Box([
            dmc.Text("★ = Required table", size="xs", c=DIM, mb="sm"),
            dmc.Table(
                [
                    dmc.TableThead(dmc.TableTr([
                        dmc.TableTh(dmc.Text("Data Source",    size="xs", c=ACCENT_GOLD, fw=700)),
                        dmc.TableTh(dmc.Text("Status",         size="xs", c=ACCENT_GOLD, fw=700)),
                        dmc.TableTh(dmc.Text("Completeness",   size="xs", c=ACCENT_GOLD, fw=700)),
                        dmc.TableTh(dmc.Text("Consistency",    size="xs", c=ACCENT_GOLD, fw=700)),
                        dmc.TableTh(dmc.Text("Validity",       size="xs", c=ACCENT_GOLD, fw=700)),
                        dmc.TableTh(dmc.Text("Overall Score",  size="xs", c=ACCENT_GOLD, fw=700)),
                        dmc.TableTh(dmc.Text("Purpose",        size="xs", c=ACCENT_GOLD, fw=700)),
                    ])),
                    dmc.TableTbody(scorecard_rows),
                ],
                striped=True, highlightOnHover=True,
                style={"fontSize": "12px"},
            ),
        ])

        # ── Detail Table ─────────────────────────────────────────────────────
        detail_rows = []
        for tname in _ALL_TABLES:
            stats = table_scores[tname]
            if not stats["present"]:
                continue
            null_col = _rag_color((1 - stats["null_pct"]) * 100, 90, 70)
            dup_col  = _rag_color((1 - stats["dup_pct"])  * 100, 95, 80)
            detail_rows.append(dmc.TableTr([
                dmc.TableTd(dmc.Text(_TABLE_META[tname]["label"], size="xs", fw=700, c=CHART_TEXT)),
                dmc.TableTd(dmc.Text(f"{stats['rows']:,}",  size="xs", c=CHART_TEXT)),
                dmc.TableTd(dmc.Text(f"{stats['cols']}",    size="xs", c=DIM)),
                dmc.TableTd(
                    dmc.Text(f"{stats['null_pct']*100:.1f}%", size="xs",
                             c="#FF5252" if stats["null_pct"] > 0.2 else null_col)
                ),
                dmc.TableTd(
                    dmc.Text(f"{stats['dup_pct']*100:.1f}%", size="xs",
                             c="#FF5252" if stats["dup_pct"] > 0.05 else dup_col)
                ),
                dmc.TableTd(
                    dmc.Badge(
                        f"{stats['score']*100:.0f}%",
                        color="green" if stats["score"] >= 0.85
                              else "orange" if stats["score"] >= 0.65 else "red",
                        variant="light", size="xs",
                    )
                ),
            ]))

        detail_table = dmc.Table(
            [
                dmc.TableThead(dmc.TableTr([
                    dmc.TableTh(dmc.Text("Table",        size="xs", c=ACCENT_GOLD, fw=700)),
                    dmc.TableTh(dmc.Text("Row Count",    size="xs", c=ACCENT_GOLD, fw=700)),
                    dmc.TableTh(dmc.Text("Columns",      size="xs", c=ACCENT_GOLD, fw=700)),
                    dmc.TableTh(dmc.Text("Null Rate",    size="xs", c=ACCENT_GOLD, fw=700)),
                    dmc.TableTh(dmc.Text("Duplicate %",  size="xs", c=ACCENT_GOLD, fw=700)),
                    dmc.TableTh(dmc.Text("Quality Score",size="xs", c=ACCENT_GOLD, fw=700)),
                ])),
                dmc.TableTbody(detail_rows if detail_rows else [
                    dmc.TableTr([dmc.TableTd(
                        dmc.Text("No tables loaded — upload data in Port Authority first.",
                                 c=DIM, size="sm"), colSpan=6
                    )])
                ]),
            ],
            striped=True, highlightOnHover=True,
            style={"fontSize": "12px"},
        )

        # ── Model Drift Chart ────────────────────────────────────────────────
        db   = get_db()
        hist = db.get_run_history(limit=50)
        drift_fig = _empty

        if hist is not None and len(hist) >= 2:
            try:
                # Get scored results for each run to compute tier %
                run_drift_data = []
                for _, row in hist.iterrows():
                    rid      = int(row["run_id"])
                    n_custs  = int(row.get("customers", 0))
                    run_date = str(row.get("started_at", ""))[:10]
                    if n_custs == 0:
                        continue

                    # Try to get scored for this run
                    run_scored = db.get_run_scored(rid)
                    if run_scored is None or len(run_scored) == 0:
                        # Fallback: get metadata if stored
                        meta_row = db._conn.execute(
                            "SELECT metadata FROM pipeline_runs WHERE run_id=?", (rid,)
                        ).fetchone()
                        if meta_row:
                            try:
                                meta = json.loads(meta_row[0] or "{}")
                                tc   = meta.get("tier_counts", {})
                                if tc and n_custs > 0:
                                    run_drift_data.append({
                                        "run_id":  rid,
                                        "date":    run_date,
                                        "p1_pct":  tc.get("P1", 0) / n_custs * 100,
                                        "p2_pct":  tc.get("P2", 0) / n_custs * 100,
                                        "p3_pct":  tc.get("P3", 0) / n_custs * 100,
                                        "p4_pct":  tc.get("P4", 0) / n_custs * 100,
                                        "customers": n_custs,
                                    })
                            except Exception:
                                pass
                        continue

                    tier_c = next((c for c in ["tier", "risk_tier"] if c in run_scored.columns), None)
                    if tier_c:
                        counts = run_scored[tier_c].value_counts()
                        n = len(run_scored)
                        run_drift_data.append({
                            "run_id":    rid,
                            "date":      run_date,
                            "p1_pct":    counts.get("P1", 0) / n * 100,
                            "p2_pct":    counts.get("P2", 0) / n * 100,
                            "p3_pct":    counts.get("P3", 0) / n * 100,
                            "p4_pct":    counts.get("P4", 0) / n * 100,
                            "customers": n,
                        })

                if len(run_drift_data) >= 2:
                    ddf = pd.DataFrame(run_drift_data).sort_values("run_id")
                    x_vals = [f"Run {r['run_id']}<br>{r['date']}" for _, r in ddf.iterrows()]

                    drift_fig = go.Figure()
                    for tier, col, name in [("p1_pct", TIER_COLORS["P1"], "P1 — Critical"),
                                            ("p2_pct", TIER_COLORS["P2"], "P2 — High Risk"),
                                            ("p3_pct", TIER_COLORS["P3"], "P3 — Watch"),
                                            ("p4_pct", TIER_COLORS["P4"], "P4 — Low Risk")]:
                        drift_fig.add_trace(go.Scatter(
                            x=x_vals,
                            y=ddf[tier].tolist(),
                            name=name,
                            mode="lines+markers",
                            line=dict(color=col, width=2),
                            marker=dict(size=7, color=col),
                            hovertemplate=f"<b>{name}</b>: %{{y:.1f}}%<extra></extra>",
                        ))
                    drift_fig.update_layout(**_styled_kw("Risk Tier Distribution Trend Across Pipeline Runs", height=380))
                    drift_fig.update_xaxes(title="", color=CHART_TEXT, gridcolor=CHART_GRID)
                    drift_fig.update_yaxes(title="% of Portfolio", color=CHART_TEXT, gridcolor=CHART_GRID, ticksuffix="%")
                    drift_fig.update_layout(legend=dict(orientation="h", x=0.5, y=-0.18, xanchor="center",
                                    font=dict(color=CHART_TEXT, size=11)))
                    drift_fig.add_annotation(
                        text="Stable flat lines = well-calibrated model. Rising P1 line = escalating risk or threshold drift.",
                        xref="paper", yref="paper", x=0.5, y=1.05,
                        showarrow=False, font=dict(size=10, color=DIM), align="center",
                    )
                else:
                    drift_fig = empty_fig("Run the pipeline at least twice to see drift trends")
            except Exception as e:
                drift_fig = empty_fig(f"Drift analysis unavailable: {e}")
        elif len(hist) == 1:
            drift_fig = empty_fig(
                "Only 1 pipeline run recorded — run the pipeline again to track model drift"
            )

        # ── Data Completeness Trend ──────────────────────────────────────────
        completeness_fig = _empty
        if hist is not None and len(hist) >= 1:
            try:
                trend_rows = []
                hist_sorted = hist.sort_values("run_id")
                for _, row in hist_sorted.iterrows():
                    rid      = int(row["run_id"])
                    run_date = str(row.get("started_at", ""))[:10]
                    run_tables = db._conn.execute(
                        "SELECT name, rows FROM raw_tables WHERE run_id=?", (rid,)
                    ).fetchall()
                    if not run_tables:
                        continue
                    # Estimate completeness from row counts vs current (proxy)
                    for tname, rcount in run_tables:
                        trend_rows.append({
                            "run_id": rid,
                            "date": run_date,
                            "table": tname,
                            "rows": rcount,
                        })

                if trend_rows:
                    tdf = pd.DataFrame(trend_rows)
                    completeness_fig = go.Figure()
                    colors = ["#26C6DA", "#4CAF50", "#FF9800", "#9C27B0", "#FF5252", "#2196F3"]
                    for i, tname in enumerate(tdf["table"].unique()):
                        t_data = tdf[tdf["table"] == tname].sort_values("run_id")
                        label  = _TABLE_META.get(tname, {}).get("label", tname)
                        color  = colors[i % len(colors)]
                        completeness_fig.add_trace(go.Scatter(
                            x=[f"Run {r}" for r in t_data["run_id"]],
                            y=t_data["rows"].tolist(),
                            name=label,
                            mode="lines+markers",
                            line=dict(color=color, width=2),
                            marker=dict(size=6, color=color),
                            hovertemplate=f"<b>{label}</b>: %{{y:,}} rows<extra></extra>",
                        ))
                    completeness_fig.update_layout(**_styled_kw("Row Count per Data Source — Across Pipeline Runs", height=360))
                    completeness_fig.update_xaxes(title="", color=CHART_TEXT)
                    completeness_fig.update_yaxes(title="Number of Records", color=CHART_TEXT, gridcolor=CHART_GRID)
                    completeness_fig.update_layout(legend=dict(orientation="h", x=0.5, y=-0.22, xanchor="center",
                                    font=dict(color=CHART_TEXT, size=10)))
                    completeness_fig.add_annotation(
                        text="Falling lines indicate data feeds may have degraded — investigate before treating scores as authoritative.",
                        xref="paper", yref="paper", x=0.5, y=1.05,
                        showarrow=False, font=dict(size=10, color=DIM),
                    )
                else:
                    completeness_fig = empty_fig("No historical table data in database")
            except Exception as e:
                completeness_fig = empty_fig(f"Trend unavailable: {e}")

        # ── Pipeline Performance ─────────────────────────────────────────────
        perf_fig = _empty
        if hist is not None and len(hist) > 0:
            try:
                ph = hist[hist["status"] == "success"].sort_values("run_id") if "status" in hist.columns else hist.sort_values("run_id")
                if len(ph) > 0 and "duration_sec" in ph.columns:
                    durations = ph["duration_sec"].fillna(0).tolist()
                    run_ids   = [f"Run {r}" for r in ph["run_id"].tolist()]
                    cust_counts = ph["customers"].fillna(0).tolist()
                    bar_colors  = ["#4CAF50" if d < 60 else "#FF9800" if d < 300 else "#FF5252"
                                   for d in durations]

                    perf_fig = go.Figure()
                    perf_fig.add_trace(go.Bar(
                        x=run_ids,
                        y=durations,
                        marker_color=bar_colors,
                        text=[f"{d:.0f}s" if d < 120 else f"{d/60:.1f}m" for d in durations],
                        textposition="outside",
                        textfont=dict(color=CHART_TEXT, size=10),
                        hovertemplate=(
                            "<b>%{x}</b><br>Duration: %{y:.1f}s"
                            "<br>Customers: %{customdata:,}<extra></extra>"
                        ),
                        customdata=cust_counts,
                        name="Run Duration (seconds)",
                    ))
                    if len(durations) >= 3:
                        avg_dur = pd.Series(durations).mean()
                        perf_fig.add_hline(
                            y=avg_dur, line_color=ACCENT_GOLD, line_dash="dash",
                            annotation_text=f"Average: {avg_dur:.0f}s",
                            annotation_font=dict(color=ACCENT_GOLD, size=11),
                        )

                    perf_fig.update_layout(**_styled_kw("Pipeline Execution Time per Run (seconds)", height=320))
                    perf_fig.update_xaxes(title="", color=CHART_TEXT)
                    perf_fig.update_yaxes(title="Duration (seconds)", color=CHART_TEXT, gridcolor=CHART_GRID)
                else:
                    perf_fig = empty_fig("No duration data in run history")
            except Exception as e:
                perf_fig = empty_fig(f"Performance chart unavailable: {e}")

    except Exception as e:
        nd = no_data_card(f"Data quality report error: {e}")
        return (*_blanks, nd, nd, _empty, _empty, _empty)

    return (
        kpi_quality, kpi_tables, kpi_comp, kpi_rows,
        scorecard, detail_table,
        drift_fig, completeness_fig, perf_fig,
    )
