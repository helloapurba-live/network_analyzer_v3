"""
REPORT R2 — Customer Risk Profiles
=====================================
Group: G3 — "The People We Are Watching"
Audience: MLRO, Head of Compliance, Senior Investigators
Update: Auto-syncs on every pipeline run

Story: Every risk score is attached to a real human being or business entity.
This page zooms past the portfolio-level numbers and into the individuals
who are generating the risk. Who are the top 20 highest-risk customers?
What type — Personal, Business, Corporate — is driving the most P1 flags?
Is the average transaction size for high-risk customers increasing?
These are the conversations that happen at investigation case conferences.
"""
from __future__ import annotations

import sys
from pathlib import Path

import dash
import dash_mantine_components as dmc
import pandas as pd
import plotly.graph_objects as go
from dash import Input, Output, callback, dcc, html
from dash_iconify import DashIconify

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from config import APP, THEME
from engine import get_pipeline
from utils.data_provider import get_latest_scored  # v16.72 F4
from pages.reports import (
    TIER_COLORS, TIER_LABELS, CHART_BG, CHART_TEXT, CHART_GRID, DIM, ACCENT_GOLD,
    empty_fig, styled_layout, page_header, section_header,
    kpi_card, no_data_card, fallback_note, _tbl,
)

dash.register_page(
    __name__,
    path="/reports/customer-profiles",
    name="Customer Risk Profiles",
    title=f"FCDAI v{APP.VERSION} | Customer Risk Profiles",
)

# ─────────────────────────────────────────────────────────────────────────────
# LAYOUT
# ─────────────────────────────────────────────────────────────────────────────
layout = dmc.Box(
    [
        dcc.Interval(id="r2-init", interval=800, max_intervals=1),
        page_header(
            icon="mdi:account-search",
            title="Customer Risk Profiles",
            subtitle="Group G3 — Names, Segments, Patterns. Who Are the People We Are Watching?",
            story=(
                "Behind every tier label — P1, P2, P3 — is a customer: a person's name, a business entity, "
                "a loan account. This page moves from aggregate statistics into individual identity. "
                "The Top 20 table is your compliance team's action list for the week: the most dangerous customers "
                "ranked in order, with the primary reason each individual was flagged. "
                "The segment breakdown shows whether the risk is concentrated in one customer type — for example, "
                "are Corporate accounts overrepresented in P1 relative to their share of the portfolio? "
                "The distribution histogram shows whether risk is spread evenly or whether a small number of "
                "extreme cases are driving the average. "
                "This is the page you take into a case review meeting."
            ),
            accent="#FF6B6B",
        ),

        # ── SECTION 1: Top 20 Highest-Risk Customers ─────────────────────────
        section_header(
            "mdi:playlist-star",
            "Top 20 Highest-Risk Customers",
            "Ranked by risk score. The compliance team's priority action list for immediate investigation.",
            accent="#FF1744",
        ),
        dmc.Paper(
            [
                dmc.Group(
                    [
                        dmc.Text("Priority Investigation List", fw=700, size="sm", c="white"),
                        dmc.Badge(id="r2-top-count", children="0 customers", color="red", variant="light", size="sm"),
                    ],
                    justify="space-between",
                    mb="sm",
                ),
                dmc.Text(
                    "Every customer on this list has been scored by the full detection engine — all 10 analytical "
                    "methods — and ranked by their combined risk score. The 'Primary Signal' column explains "
                    "in plain language why this customer was flagged. Scores above 70 require case opening.",
                    size="xs", c=DIM, mb="md", style={"lineHeight": "1.5"},
                ),
                html.Div(id="r2-top20-table", style={"overflowX": "auto"}),
            ],
            p="lg", radius="lg", className="glass-card", mb="xl",
        ),

        # ── SECTION 2: Segment Breakdown ──────────────────────────────────────
        section_header(
            "mdi:account-group-outline",
            "Risk by Customer Segment",
            "Are certain customer types disproportionately represented in the high-risk tiers?",
            accent="#9D4EDD",
        ),
        # ROW 1: node_type — Person / Entity / Account / Merchant / Trust
        dmc.Text("Node Type  (Person · Entity · Account · Merchant · Trust)", fw=600, size="sm", c="#9D4EDD", mb=6),
        dmc.SimpleGrid(
            cols={"base": 1, "md": 2}, spacing="md", mb="md",
            children=[
                dmc.Paper(
                    [
                        dmc.Text("Node Type Distribution Table", fw=700, size="sm", c="white", mb=4),
                        dmc.Text("Each row = a node type. Counts per risk tier.", size="xs", c=DIM, mb="sm"),
                        html.Div(id="r2-seg1-table", style={"overflowX": "auto"}),
                    ],
                    p="lg", radius="lg", className="glass-card",
                ),
                dmc.Paper(
                    [
                        dmc.Text("Risk Tier Share — Node Type", fw=700, size="sm", c="white", mb=4),
                        dcc.Graph(id="r2-seg1-bar", config={"displayModeBar": False}, style={"height": "280px"}),
                    ],
                    p="lg", radius="lg", className="glass-card",
                ),
            ],
        ),
        # ROW 2: node_type1 — External / Internal
        dmc.Text("Client Relationship  (External · Internal)", fw=600, size="sm", c="#9D4EDD", mb=6),
        dmc.SimpleGrid(
            cols={"base": 1, "md": 2}, spacing="md", mb="md",
            children=[
                dmc.Paper(
                    [
                        dmc.Text("Client Relationship Distribution Table", fw=700, size="sm", c="white", mb=4),
                        dmc.Text("External vs Internal customers mapped to risk tiers.", size="xs", c=DIM, mb="sm"),
                        html.Div(id="r2-seg2-table", style={"overflowX": "auto"}),
                    ],
                    p="lg", radius="lg", className="glass-card",
                ),
                dmc.Paper(
                    [
                        dmc.Text("Risk Tier Share — Client Relationship", fw=700, size="sm", c="white", mb=4),
                        dcc.Graph(id="r2-seg2-bar", config={"displayModeBar": False}, style={"height": "280px"}),
                    ],
                    p="lg", radius="lg", className="glass-card",
                ),
            ],
        ),
        # ROW 3: node_type3 — Retail / Corporate / Financial / Government
        dmc.Text("Customer Segment  (Retail · Corporate · Financial · Government)", fw=600, size="sm", c="#9D4EDD", mb=6),
        dmc.SimpleGrid(
            cols={"base": 1, "md": 2}, spacing="md", mb="xl",
            children=[
                dmc.Paper(
                    [
                        dmc.Text("Customer Segment Distribution Table", fw=700, size="sm", c="white", mb=4),
                        dmc.Text("Retail / Corporate / Financial / Government — counts per risk tier.", size="xs", c=DIM, mb="sm"),
                        html.Div(id="r2-seg3-table", style={"overflowX": "auto"}),
                    ],
                    p="lg", radius="lg", className="glass-card",
                ),
                dmc.Paper(
                    [
                        dmc.Text("Risk Tier Share — Customer Segment", fw=700, size="sm", c="white", mb=4),
                        dcc.Graph(id="r2-seg3-bar", config={"displayModeBar": False}, style={"height": "280px"}),
                    ],
                    p="lg", radius="lg", className="glass-card",
                ),
            ],
        ),

        # ── SECTION 3: Risk Score Distribution ──────────────────────────────
        section_header(
            "mdi:chart-histogram",
            "Risk Score Distribution Across All Customers",
            "The full shape of risk in your portfolio — from the safest customer to the most dangerous.",
            accent="#FFD600",
        ),
        dmc.Paper(
            [
                dmc.Text("How Are Risk Scores Spread Across the Portfolio?", fw=700, size="sm", c="white", mb=4),
                dmc.Text(
                    "A healthy portfolio concentrates in the left side of this chart — most customers "
                    "scoring below 30 (green zone). A spike on the right (scores 70+) indicates a "
                    "cluster of high-risk customers that may represent an organised scheme or a data feed "
                    "quality issue. The shape of this distribution is a key indicator of overall portfolio health.",
                    size="xs", c=DIM, mb="sm", style={"lineHeight": "1.5"},
                ),
                dcc.Graph(
                    id="r2-histogram",
                    config={"displayModeBar": False},
                    style={"height": "320px"},
                ),
            ],
            p="lg", radius="lg", className="glass-card", mb="xl",
        ),

        # ── SECTION 4: Avg Transaction Size Trend ──────────────────────────
        section_header(
            "mdi:trending-up",
            "Average Transaction Size per Risk Tier",
            "Are high-risk customers transacting in larger amounts? Is that trend moving?",
            accent="#00E676",
        ),
        dmc.Paper(
            [
                dmc.Text("Average Transaction Amount by Risk Tier", fw=700, size="sm", c="white", mb=4),
                dmc.Text(
                    "High-risk customers transacting in unusually large amounts is a classic structuring "
                    "and layering indicator. If P1 customers consistently transact at multiples of P4 "
                    "customers, that pattern warrants portfolio-level review. "
                    "This chart uses the edge table 'amount' column.",
                    size="xs", c=DIM, mb="sm", style={"lineHeight": "1.5"},
                ),
                html.Div(id="r2-txn-note"),
                dcc.Graph(
                    id="r2-txn-bar",
                    config={"displayModeBar": False},
                    style={"height": "300px"},
                ),
            ],
            p="lg", radius="lg", className="glass-card", mb="xl",
        ),
    ],
    p="lg",
)


# ─────────────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────────────
_TH_STYLE = {
    "padding": "10px 14px",
    "borderBottom": "2px solid #1E293B",
    "fontSize": "11px",
    "fontWeight": 600,
    "textTransform": "uppercase",
    "letterSpacing": "0.5px",
    "color": "#94A3B8",
    "background": "rgba(0,0,0,0.3)",
    "whiteSpace": "nowrap",
}
_TD_STYLE = {
    "padding": "9px 14px",
    "borderBottom": "1px solid rgba(255,255,255,0.04)",
    "fontSize": "12px",
    "color": "#CBD5E1",
}


def _tier_badge(tier: str) -> dmc.Badge:
    colors = {"P1": "red", "P2": "orange", "P3": "yellow", "P4": "green"}
    return dmc.Badge(tier, color=colors.get(tier, "gray"), variant="filled", size="sm")


def _signal_label(row: pd.Series, analytics) -> str:
    """Return a plain-language primary signal for a scored customer row."""
    top_score, top_label = 0.0, "Multiple detection signals"
    # Check each family score column
    # N2 FIX v16.71: DB stores score_* prefix (score_centrality etc.), not *_score suffix
    signal_map = {
        "score_centrality":      "High network influence — connected to many flagged accounts",
        "score_community":       "Member of a suspicious customer cluster",
        "score_structuring":     "Structuring pattern detected — transactions designed to avoid reporting",
        "score_benfords":        "Unusual digit patterns in transaction amounts",
        "score_anomaly":         "Transaction behaviour deviates significantly from peers",
        "score_temporal":        "Suspicious timing pattern — unusual hours or days",
        "score_pathflow":        "On a financial flow path between flagged nodes",
        "score_multi_layer":     "Risk detected across multiple relationship types",
        "score_link_prediction": "High probability of undisclosed relationships",
    }
    for col, label in signal_map.items():
        if col in row.index:
            v = row.get(col, 0)
            try:
                v = float(v) if v is not None else 0
            except Exception:
                v = 0
            if v > top_score:
                top_score, top_label = v, label
    if top_score < 1e-6:
        return "Combined algorithm consensus — no single dominant signal"
    return top_label


def _build_top20_table(scored: pd.DataFrame, node_df) -> tuple:
    """Build top-20 HTML table. Returns (table, count_badge_text)."""
    # v16.74: handle normalized column names (risk_score may be score_risk after data_provider)
    _sc = next(
        (c for c in scored.columns if c in ("risk_score", "score_risk", "composite_score", "score")),
        None,
    ) or next((c for c in scored.columns if "risk" in c.lower() and "score" in c.lower()), None)
    top = scored.nlargest(20, _sc).copy() if _sc else scored.head(20).copy()

    # Enrich with name/type from node table
    name_map, type_map = {}, {}
    if node_df is not None:
        id_col = next((c for c in ["node_id", "id", "customer_id"] if c in node_df.columns), node_df.columns[0])
        nm_col = next((c for c in ["customer_name", "name", "full_name"] if c in node_df.columns), None)
        tp_col = next((c for c in ["customer_type", "type", "segment"] if c in node_df.columns), None)
        for _, nr in node_df.iterrows():
            nid = str(nr.get(id_col, ""))
            if nm_col:
                name_map[nid] = str(nr.get(nm_col, nid))
            if tp_col:
                type_map[nid] = str(nr.get(tp_col, "Unknown"))

    cols = ["#", "Customer ID", "Name", "Type", "Risk Score", "Tier", "Primary Detection Signal"]
    header = html.Thead(html.Tr([
        html.Th(c, style=_TH_STYLE) for c in cols
    ]))

    rows_ = []
    for rank, (_, row) in enumerate(top.iterrows(), 1):
        nid = str(row.get("node_id", ""))
        name = name_map.get(nid, nid[:20])
        ctype = type_map.get(nid, "Unknown")
        score = float(row.get(_sc, 0) or 0) if _sc else 0
        tier  = row.get("tier", "P4")
        signal = _signal_label(row, None)

        score_color = "#FF1744" if score >= 70 else ("#FF9800" if score >= 40 else "#00E676")
        row_bg = "rgba(255,23,68,0.06)" if tier == "P1" else "rgba(0,0,0,0)"
        cells = [
            html.Td(dmc.Badge(f"#{rank}", color="cyan", variant="light", size="xs"), style=_TD_STYLE),
            html.Td(html.Span(nid[:20], style={"fontFamily": "monospace", "color": "#94A3B8"}), style=_TD_STYLE),
            html.Td(name, style={**_TD_STYLE, "color": "white", "fontWeight": 600}),
            html.Td(ctype, style=_TD_STYLE),
            html.Td(
                dmc.Group([
                    html.Span(f"{score:.1f}", style={"color": score_color, "fontWeight": 700}),
                    dmc.Progress(value=score, color="red" if score >= 70 else ("orange" if score >= 40 else "green"),
                                 size="xs", style={"width": "60px"}),
                ], gap=6),
                style=_TD_STYLE,
            ),
            html.Td(_tier_badge(tier), style=_TD_STYLE),
            html.Td(
                html.Span(signal, style={"fontStyle": "italic", "color": DIM, "fontSize": "11px"}),
                style=_TD_STYLE,
            ),
        ]
        rows_.append(html.Tr(cells, style={"background": row_bg}))

    table = html.Table(
        [header, html.Tbody(rows_)],
        style={"width": "100%", "borderCollapse": "collapse"},
    )
    return table, f"Top {len(top)} customers"


def _build_segment_table(pivot: pd.DataFrame) -> html.Table:
    tiers = ["P1", "P2", "P3", "P4"]
    cols_ = ["Segment"] + tiers + ["Total", "P1 %"]
    header = html.Thead(html.Tr([html.Th(c, style=_TH_STYLE) for c in cols_]))
    rows_ = []
    for seg, row in pivot.iterrows():
        total = sum(row.get(t, 0) for t in tiers)
        p1_pct = row.get("P1", 0) / max(total, 1) * 100
        bg = "rgba(255,23,68,0.08)" if p1_pct >= 10 else "rgba(0,0,0,0)"
        cells = [html.Td(str(seg), style={**_TD_STYLE, "color": "white", "fontWeight": 600})]
        for t in tiers:
            cnt = row.get(t, 0)
            c_str = TIER_COLORS.get(t, "#8899AA")
            cells.append(html.Td(
                dmc.Text(str(cnt), c=c_str, fw=700, size="sm") if cnt > 0 else html.Span("—", style={"color": DIM}),
                style=_TD_STYLE,
            ))
        cells.append(html.Td(str(total), style={**_TD_STYLE, "color": "white"}))
        cells.append(html.Td(
            dmc.Badge(f"{p1_pct:.1f}%", color="red" if p1_pct >= 10 else "gray", variant="light", size="sm"),
            style=_TD_STYLE,
        ))
        rows_.append(html.Tr(cells, style={"background": bg}))
    return html.Table([header, html.Tbody(rows_)], style={"width": "100%", "borderCollapse": "collapse"})


# ─────────────────────────────────────────────────────────────────────────────
# CALLBACK
# ─────────────────────────────────────────────────────────────────────────────
@callback(
    Output("r2-top20-table",   "children"),
    Output("r2-top-count",     "children"),
    Output("r2-seg1-table",    "children"),
    Output("r2-seg1-bar",      "figure"),
    Output("r2-seg2-table",    "children"),
    Output("r2-seg2-bar",      "figure"),
    Output("r2-seg3-table",    "children"),
    Output("r2-seg3-bar",      "figure"),
    Output("r2-histogram",     "figure"),
    Output("r2-txn-bar",       "figure"),
    Output("r2-txn-note",      "children"),
    Input("pipeline-state",    "data"),
    Input("global-refresh-ts", "data"),
    Input("r2-init",           "n_intervals"),
    prevent_initial_call=False,
)
def update_r2(_ps, _grt, _init):
    pipeline = get_pipeline()  # kept for any direct pipeline method calls
    # v16.72 F4+F5: unified loader — memory-first, DB fallback, score_* normalize
    _dp    = get_latest_scored(pipeline)
    scored = _dp["scored"]
    tables = _dp["tables"]
    node_df  = _tbl(tables, "node", "nodes")
    edge_df  = _tbl(tables, "edge", "edges")

    # ── normalise engine column names ──────────────────────────────────────
    if scored is not None:
        if "risk_tier" in scored.columns and "tier" not in scored.columns:
            scored = scored.rename(columns={"risk_tier": "tier"})
        if "node_id" not in scored.columns:
            for alt in ["customer_id", "id"]:
                if alt in scored.columns:
                    scored = scored.rename(columns={alt: "node_id"})
                    break

    no_pipe = scored is None or len(scored) == 0

    null_fig = empty_fig()
    empty_table = dmc.Text("Run pipeline to populate this section.", c="dimmed", size="sm")

    # ── TOP 20 ────────────────────────────────────────────────────────────────
    if no_pipe:
        top_table  = no_data_card("No pipeline data yet.")
        top_count  = "0 customers"
    else:
        top_table, top_count = _build_top20_table(scored, node_df)

    # ── SEGMENT ROWS — node_type / node_type1 / node_type3 ───────────────────
    def _seg_pair(col):
        """Return (table_el, bar_fig) for one node-type column."""
        if no_pipe or node_df is None or col not in node_df.columns:
            lbl = "No pipeline data." if no_pipe else f"Column '{col}' not found in node table."
            return no_data_card(lbl), empty_fig(lbl)
        try:
            id_c = next((c for c in ["node_id", "id", "customer_id"] if c in node_df.columns), node_df.columns[0])
            merged = scored.merge(
                node_df[[id_c, col]].rename(columns={id_c: "node_id"}),
                on="node_id", how="left",
            )
            merged[col]    = merged[col].fillna("Unknown")
            merged["tier"] = merged["tier"].fillna("P4") if "tier" in merged.columns else "P4"
            pivot = (
                merged.groupby([col, "tier"])
                .size()
                .unstack(fill_value=0)
                .reindex(columns=["P1", "P2", "P3", "P4"], fill_value=0)
            )
            tbl = _build_segment_table(pivot)
            bar = go.Figure()
            segs = list(pivot.index)
            for t in ["P1", "P2", "P3", "P4"]:
                bar.add_trace(go.Bar(
                    x=segs,
                    y=[pivot.loc[s, t] if t in pivot.columns else 0 for s in segs],
                    name=TIER_LABELS.get(t, t),
                    marker_color=TIER_COLORS[t],
                    hovertemplate=f"<b>%{{x}}</b><br>{TIER_LABELS[t]}: %{{y}} customers<extra></extra>",
                ))
            bar.update_layout(barmode="stack")
            styled_layout(bar, height=280)
            return tbl, bar
        except Exception as e:
            return dmc.Text(f"Error: {e}", c="red", size="sm"), empty_fig(f"Error: {e}")

    seg1_table, seg1_bar = _seg_pair("node_type")
    seg2_table, seg2_bar = _seg_pair("node_type1")
    seg3_table, seg3_bar = _seg_pair("node_type3")

    # ── HISTOGRAM ─────────────────────────────────────────────────────────────
    # v16.74 N1: data_provider normalises risk_score → score_risk; find the
    # actual risk/composite column regardless of naming convention.
    _risk_col = next(
        (c for c in (scored.columns if not no_pipe else [])
         if c in ("risk_score", "score_risk", "composite_score", "score_composite", "score")),
        None,
    )
    if _risk_col is None and not no_pipe:
        _risk_col = next(
            (c for c in scored.columns if "risk" in c.lower() and "score" in c.lower()),
            None,
        )
    if no_pipe or _risk_col is None:
        hist_fig = empty_fig("Upload data and run the pipeline to see the risk score distribution")
    else:
        hist_fig = go.Figure()
        # Colour bands: 0–30 green, 30–60 amber, 60–80 orange, 80–100 red
        bins_def = [(0, 20, "#00E676"), (20, 40, "#64DD17"), (40, 60, "#FFD600"),
                    (60, 80, "#FF9800"), (80, 100, "#FF1744")]
        for lo, hi, clr in bins_def:
            band = scored[(scored[_risk_col] >= lo) & (scored[_risk_col] < hi)]
            hist_fig.add_trace(go.Histogram(
                x=band[_risk_col],
                nbinsx=5,
                marker_color=clr,
                opacity=0.85,
                name=f"{lo}–{hi} Risk",
                hovertemplate=f"Score range: {lo}–{hi}<br>Customers: %{{y}}<extra></extra>",
            ))
        hist_fig.update_layout(barmode="stack", bargap=0.05)
        styled_layout(hist_fig, height=320, legend=True)
        hist_fig.update_layout(
            xaxis_title="Risk Score",
            yaxis_title="Number of Customers",
        )
        # Add zone shading annotations
        for x0, x1, label, color in [
            (0, 30, "LOW RISK", "#00E676"),
            (30, 60, "MEDIUM RISK", "#FFD600"),
            (60, 100, "HIGH / CRITICAL", "#FF1744"),
        ]:
            hist_fig.add_vrect(x0=x0, x1=x1, fillcolor=color, opacity=0.04, line_width=0)
            hist_fig.add_annotation(
                x=(x0 + x1) / 2, y=1.05, text=label, showarrow=False,
                font=dict(color=color, size=9), yref="paper",
            )

    # ── AVG TRANSACTION SIZE BY TIER ──────────────────────────────────────────
    txn_note = html.Span()
    if no_pipe:
        txn_bar = empty_fig()
    elif edge_df is None:
        txn_bar = empty_fig("Edge table not loaded.")
        txn_note = fallback_note("Upload an edge table to see average transaction size by tier.")
    else:
        amt_col  = next((c for c in ["amount", "value", "transaction_amount"] if c in edge_df.columns), None)
        from_col = next((c for c in ["from_node", "source", "from_id", "from"] if c in edge_df.columns), None)
        if not amt_col or not from_col:
            txn_bar  = empty_fig("No 'amount' or 'from_node' column in edge table.")
            txn_note = fallback_note("Ensure edge table has 'amount' and 'from_node' columns.")
        else:
            try:
                avg_per_node = edge_df.groupby(from_col)[amt_col].mean().reset_index()
                avg_per_node.columns = ["node_id", "avg_txn"]
                merged_t = scored[["node_id", "tier"]].merge(avg_per_node, on="node_id", how="left")
                tier_avg = merged_t.groupby("tier")["avg_txn"].mean().reindex(["P1", "P2", "P3", "P4"])
                txn_bar = go.Figure(go.Bar(
                    x=[TIER_LABELS.get(t, t) for t in tier_avg.index],
                    y=tier_avg.values,
                    marker_color=[TIER_COLORS.get(t, "#8899AA") for t in tier_avg.index],
                    hovertemplate="<b>%{x}</b><br>Avg Transaction: $%{y:,.2f}<extra></extra>",
                ))
                styled_layout(txn_bar, height=300, legend=False)
                txn_bar.update_layout(
                    yaxis_title="Average Transaction Amount ($)",
                    xaxis_title="Risk Tier",
                )
            except Exception as e:
                txn_bar  = empty_fig(f"Could not compute avg transaction size: {e}")

    return (
        top_table, top_count,
        seg1_table, seg1_bar,
        seg2_table, seg2_bar,
        seg3_table, seg3_bar,
        hist_fig,
        txn_bar, txn_note,
    )
