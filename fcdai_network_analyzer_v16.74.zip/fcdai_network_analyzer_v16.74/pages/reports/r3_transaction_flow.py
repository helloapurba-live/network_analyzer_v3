"""
REPORT R3 — Transaction & Flow Patterns
=========================================
Group: G4 — "How Is Suspicious Money Actually Moving?"
Audience: Head of AML, Transaction Monitoring Team, MLRO
Update: Auto-syncs on every pipeline run

Story: Individual customer risk scores tell you WHO to watch. Transaction
patterns tell you HOW they are doing it. The timing of transactions, the
routes money takes, the counterparties involved — these are the behavioural
fingerprints of financial crime. This page translates raw ledger entries into
plain intelligence that any compliance officer can act on immediately.
Structuring patterns — breaking large sums into small deposits to avoid
reporting thresholds — are surfaced here as a standalone table, because they
are the most common, and most legally consequential, typology in AML.
"""
from __future__ import annotations

import sys
from pathlib import Path

import dash
import dash_ag_grid as dag
import dash_mantine_components as dmc
import pandas as pd
import plotly.graph_objects as go
from dash import Input, Output, callback, dcc, html
from dash_iconify import DashIconify

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from config import APP, THEME
from engine import get_pipeline
from utils.data_provider import get_latest_scored  # v16.72 F4
from pages.reports import (
    TIER_COLORS, TIER_LABELS, CHART_BG, CHART_TEXT, CHART_GRID, DIM,
    empty_fig, styled_layout, page_header, section_header,
    kpi_card, no_data_card, fallback_note, ACCENT_GOLD, _tbl,
)

dash.register_page(
    __name__,
    path="/reports/transaction-flow",
    name="Transaction & Flow Patterns",
    title=f"FCDAI v{APP.VERSION} | Transaction & Flow Patterns",
)

# Sankey link colours — rgba so opacity works without 9-char hex bug
_TIER_LINK_RGBA: dict[str, str] = {
    "P1": "rgba(255,23,68,0.35)",
    "P2": "rgba(255,152,0,0.35)",
    "P3": "rgba(255,214,0,0.35)",
    "P4": "rgba(0,230,118,0.35)",
}

# ─────────────────────────────────────────────────────────────────────────────
# LAYOUT
# ─────────────────────────────────────────────────────────────────────────────
layout = dmc.Box(
    [
        dcc.Interval(id="r3-init", interval=800, max_intervals=1),

        page_header(
            icon="mdi:bank-transfer",
            title="Transaction & Flow Patterns",
            subtitle="Group G4 — How Is Suspicious Money Actually Moving Through Your Accounts?",
            story=(
                "Every financial crime leaves a transaction trail. The question is whether you know what "
                "pattern to look for. This page answers: When is suspect activity happening — morning, "
                "evening, weekends? What route does money take from one customer to another? Which "
                "corridors — specific pairs of accounts — carry the most suspicious dollar flow? "
                "And are any customers structuring their activity to stay just below regulatory "
                "reporting thresholds? "
                "You do not need to understand graph algorithms to read this page. "
                "Every chart translates data signals into plain transaction intelligence. "
                "The patterns shown here are the same ones used in successful SAR filings."
            ),
            accent="#26C6DA",
        ),

        # ── SECTION 1: Network Complexity KPIs ───────────────────────────────
        section_header(
            "mdi:chart-scatter-plot",
            "Transaction Network — Scale & Complexity",
            "How large is the transaction network? These numbers define your screening universe.",
            accent="#00D4FF",
        ),
        dmc.SimpleGrid(id="r3-network-kpis", cols={"base": 2, "sm": 5}, spacing="md", mb="xl"),

        # ── SECTION 2: Money Movement Sankey ─────────────────────────────────
        section_header(
            "mdi:transit-connection-variant",
            "Money Flow Between Risk Tiers",
            "Where does money originate and where does it end up — when measured across risk tiers?",
            accent="#FF9800",
        ),
        dmc.Paper(
            [
                dmc.Text("Sankey Flow Diagram — Origin Tier → Destination Tier by Transaction Value ($)", fw=700, size="sm", c="white", mb=4),
                dmc.Text(
                    "Each flow band represents the total dollar value transacted from customers in one risk tier "
                    "to customers in another. "
                    "Flow from P4 (Low Risk) into P1 (Critical) is the most dangerous signal: it may indicate "
                    "pass-through layering where clean-looking accounts are funnelling funds into high-risk nodes. "
                    "The wider the band, the larger the total dollar flow in that corridor.",
                    size="xs", c=DIM, mb="sm", style={"lineHeight": "1.6"},
                ),
                html.Div(id="r3-sankey-note"),
                dcc.Graph(id="r3-sankey", config={"displayModeBar": False}, style={"height": "400px"}),
                dmc.Divider(color="rgba(255,255,255,0.07)", mt="md", mb="sm"),
                dmc.Group(
                    [
                        dmc.Text("Band Colour — Origin Tier:", size="xs", c="dimmed", fw=600),
                        *[
                            dmc.Group([
                                html.Div(style={
                                    "width": "18px", "height": "12px", "borderRadius": "3px",
                                    "backgroundColor": clr, "marginTop": "2px", "opacity": "0.85",
                                }),
                                dmc.Text(lbl, size="xs", c="dimmed"),
                            ], gap=4)
                            for clr, lbl in [
                                ("#FF1744", "P1 Critical — Highest-risk customers"),
                                ("#FF9800", "P2 High Risk"),
                                ("#FFD600", "P3 Medium Risk"),
                                ("#00E676", "P4 Low Risk — Clean-looking accounts"),
                            ]
                        ],
                    ],
                    gap="lg", wrap="wrap",
                ),
                dmc.Text(
                    "How to read: Each band shows total dollar value transferred from the origin tier (left) to the "
                    "destination tier (right). Band width is proportional to the dollar amount — wider = more money. "
                    "A green/yellow band (P4/P3) flowing into a red node (P1 Critical) is the highest-priority "
                    "signal: clean-looking accounts funnelling funds into high-risk entities — a classic layering pattern.",
                    size="10px", c="dimmed", mt="xs", fs="italic", style={"lineHeight": "1.6"},
                ),
            ],
            p="lg", radius="lg", className="glass-card", mb="xl",
        ),

        # ── SECTION 4: Top 10 Corridors ───────────────────────────────────────
        section_header(
            "mdi:arrow-decision",
            "Top 10 Highest-Value Transaction Corridors",
            "The ten most active account-to-account routes by total dollar flow — with risk tier of each party shown.",
            accent="#FF6B6B",
        ),
        dmc.Paper(
            [
                dmc.Text("Highest-Value Account Pairs — From → To, Total Flow", fw=700, size="sm", c="white", mb=4),
                dmc.Text(
                    "A 'corridor' is the direct link between two specific accounts. "
                    "The corridors listed here carry the most money in your transaction dataset. "
                    "Each row shows the two account identifiers, the risk tier of both parties, "
                    "and the total dollar value that passed between them. "
                    "A corridor between two P1 or P2 accounts at the top of this list is a "
                    "case-ready SAR candidate — the money, the accounts, and the risk scores are all present.",
                    size="xs", c=DIM, mb="sm", style={"lineHeight": "1.6"},
                ),
                html.Div(id="r3-corridors-note"),
                dcc.Graph(id="r3-corridors", config={"displayModeBar": False}, style={"height": "380px"}),
            ],
            p="lg", radius="lg", className="glass-card", mb="xl",
        ),

        # ── SECTION 5: Structuring Patterns ───────────────────────────────────
        section_header(
            "mdi:cash-multiple",
            "Structuring Pattern Detection",
            "Customers artificially keeping individual transactions below reporting thresholds. "
            "This is a primary AML red flag and a criminal offence in most jurisdictions.",
            accent="#FF1744",
        ),
        dmc.Paper(
            [
                dmc.Group(
                    [
                        dmc.Text("Detected Structuring Patterns", fw=700, size="sm", c="white"),
                        dmc.Badge(id="r3-struct-count", children="—", color="red", variant="filled", size="sm"),
                    ],
                    justify="space-between", mb=4,
                ),
                dmc.Text(
                    "Structuring (also called 'smurfing') is the practice of breaking a large cash sum into "
                    "multiple smaller transactions specifically to avoid the Currency Transaction Report (CTR) "
                    "threshold — typically $10,000 in the US. "
                    "The pattern detector looks for clusters of transactions that are individually small "
                    "but collectively large, with suspiciously consistent sizing. "
                    "Each row below is a customer where this pattern was detected. "
                    "The 'Confidence' column reflects how closely the pattern matches the textbook structuring "
                    "fingerprint. Any customer with High confidence warrants immediate investigation.",
                    size="xs", c=DIM, mb="sm", style={"lineHeight": "1.6"},
                ),
                html.Div(id="r3-struct-table"),
            ],
            p="lg", radius="lg", className="glass-card", mb="xl",
        ),

        # ── SECTION 5: Day × Hour Heatmap (moved to bottom) ──────────────────
        section_header(
            "mdi:calendar-clock",
            "Transaction Activity by Day & Time",
            "When are high-frequency transactions happening? Unusual timing — night transactions, "
            "weekend spikes — is one of the most reliable behavioural indicators of suspicious activity.",
            accent="#26C6DA",
        ),
        dmc.Paper(
            [
                dmc.Group(
                    [
                        dmc.Text("Transaction Frequency Heatmap — Day of Week × Hour of Day", fw=700, size="sm", c="white"),
                        dmc.Badge(id="r3-heatmap-badge", children="—", color="cyan", variant="light", size="sm"),
                    ],
                    justify="space-between", mb=4,
                ),
                dmc.Text(
                    "Each cell shows how many transactions occurred at that day/hour combination. "
                    "Dark red cells represent the highest-activity periods. "
                    "Normal banking activity concentrates on weekday business hours (9am–5pm). "
                    "Bright cells outside this window — late nights, early mornings, weekends — "
                    "warrant explanation. Structurers and round-tripping schemes often operate "
                    "in deliberate off-hours patterns to avoid detection.",
                    size="xs", c=DIM, mb="sm", style={"lineHeight": "1.6"},
                ),
                html.Div(id="r3-heatmap-note"),
                dcc.Graph(id="r3-heatmap", config={"displayModeBar": True}, style={"height": "380px"}),
            ],
            p="lg", radius="lg", className="glass-card", mb="xl",
        ),
    ],
    p="lg",
)


# ─────────────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _find_col(df: pd.DataFrame, candidates: list[str]) -> str | None:
    for c in candidates:
        if c in df.columns:
            return c
    return None


def _tier_of(node_id, scored: pd.DataFrame) -> str:
    if scored is None:
        return "P4"
    try:
        row = scored[scored["node_id"] == node_id]
        if len(row):
            return str(row.iloc[0]["tier"])
    except Exception:
        pass
    return "P4"


def _label(nid: str, nm: dict) -> str:
    """Return 'Name (ID)' when a customer name is available, else just the ID."""
    name = nm.get(str(nid), "")
    if name and str(name) not in (str(nid), "", "nan", "None", "none"):
        n = (name[:22] + "…") if len(name) > 22 else name
        return f"{n} ({nid})"
    return str(nid)


# ─────────────────────────────────────────────────────────────────────────────
# CALLBACK
# ─────────────────────────────────────────────────────────────────────────────
@callback(
    Output("r3-network-kpis",    "children"),
    Output("r3-heatmap-badge",   "children"),
    Output("r3-heatmap-note",    "children"),
    Output("r3-heatmap",         "figure"),
    Output("r3-sankey-note",     "children"),
    Output("r3-sankey",          "figure"),
    Output("r3-corridors-note",  "children"),
    Output("r3-corridors",       "figure"),
    Output("r3-struct-count",    "children"),
    Output("r3-struct-table",    "children"),
    Input("pipeline-state",      "data"),
    Input("global-refresh-ts",   "data"),
    Input("r3-init",             "n_intervals"),
    prevent_initial_call=False,
)
def update_r3(_ps, _grt, _init):
    pipeline  = get_pipeline()  # kept for any direct method calls
    # v16.72 F4+F5: unified loader — memory-first, DB fallback, score_* normalize
    _dp       = get_latest_scored(pipeline)
    scored    = _dp["scored"]
    tables    = _dp["tables"]
    G         = _dp["graph"] or (pipeline.G if pipeline else None)
    a_results = _dp["analytics"] or (getattr(pipeline, "analytics_results", None) or {})

    # ── normalise engine column names ────────────────────────────
    if scored is not None:
        if "risk_tier" in scored.columns and "tier" not in scored.columns:
            scored = scored.rename(columns={"risk_tier": "tier"})
        if "node_id" not in scored.columns:
            for alt in ["customer_id", "id"]:
                if alt in scored.columns:
                    scored = scored.rename(columns={alt: "node_id"})
                    break

    no_pipe = scored is None or len(scored) == 0

    edge_df     = _tbl(tables, "edge", "transaction")
    node_df     = _tbl(tables, "node", "nodes")
    temporal_df = tables.get("temporal")

    # ── Name lookup: node_id → display name (reused by corridors + structuring) ──
    _nc = _find_col(node_df, ["customer_name", "name", "full_name", "entity_name", "account_name"]) if node_df is not None else None
    _ic = _find_col(node_df, ["node_id", "customer_id", "id"]) if node_df is not None else None
    name_map: dict[str, str] = (
        dict(zip(node_df[_ic].astype(str), node_df[_nc].astype(str)))
        if (node_df is not None and _nc and _ic) else {}
    )

    # ── 1. NETWORK KPIs ───────────────────────────────────────────────────────
    if no_pipe or G is None:
        net_kpis = [no_data_card("Run pipeline to see network statistics.")]
    else:
        n_nodes   = G.number_of_nodes()
        n_edges   = G.number_of_edges()
        avg_deg   = round(sum(d for _, d in G.degree()) / max(n_nodes, 1), 1)
        # Bridge nodes — nodes whose removal disconnects the graph
        try:
            import networkx as nx
            bridges = len(list(nx.bridges(G.to_undirected() if G.is_directed() else G)))
        except Exception:
            bridges = "N/A"
        isolated = sum(1 for n, d in G.degree() if d == 0)
        net_kpis = [
            kpi_card("Nodes / Entities in Network", f"{n_nodes:,}", "Unique customers & accounts in the transaction network", "mdi:account-group", "cyan"),
            kpi_card("Transaction Links", f"{n_edges:,}", "Active money-movement edges", "mdi:arrow-left-right", "indigo"),
            kpi_card("Avg Connections Per Account", str(avg_deg), "More connections = more exposure", "mdi:hub", "grape"),
            kpi_card("Critical Bridge Nodes", str(bridges), "Accounts connecting separate networks", "mdi:bridge", "red"),
            kpi_card("Isolated Accounts", f"{isolated:,}", "No transaction links — check data", "mdi:account-off", "gray"),
        ]

    # ── 2. DAY × HOUR HEATMAP ─────────────────────────────────────────────────
    heatmap_note  = html.Span()
    heatmap_badge = "—"

    if no_pipe:
        heat_fig = empty_fig()
    elif temporal_df is None:
        heat_fig     = empty_fig("Upload a 'temporal' table to unlock the transaction timing heatmap.")
        heatmap_note = fallback_note(
            "Temporal table not found. Upload a CSV with a datetime column (transaction_date / timestamp / date).",
            accent="#26C6DA",
        )
    else:
        dt_col = _find_col(temporal_df, ["transaction_date", "timestamp", "date", "datetime", "created_at", "txn_date"])
        if dt_col is None:
            heat_fig     = empty_fig("No datetime column found in temporal table.")
            heatmap_note = fallback_note("Temporal table needs a column named 'transaction_date', 'timestamp', or 'date'.")
        else:
            try:
                t = temporal_df.copy()
                # v16.71 M9: Isolate timestamp parse — format failures only affect heatmap
                try:
                    t["_dt"] = pd.to_datetime(t[dt_col], errors="coerce")
                except Exception as _ts_err:
                    heat_fig = empty_fig(
                        f"Timestamp column '{dt_col}' could not be parsed: {_ts_err}. "
                        "Try format YYYY-MM-DD or ISO 8601."
                    )
                    heatmap_note = fallback_note(
                        f"Datetime parse failed on column '{dt_col}'. "
                        "Ensure values are in YYYY-MM-DD, DD/MM/YYYY, or ISO 8601 format.",
                        "#FF9800",
                    )
                    t = None  # signal skip
                if t is not None:
                    t = t.dropna(subset=["_dt"])
                    if len(t) == 0:
                        heat_fig = empty_fig("Datetime column could not be parsed — check format.")
                    else:
                        t["_day"] = t["_dt"].dt.day_name()
                        t["_hr"]  = t["_dt"].dt.hour
                        day_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
                        pivot = (
                            t.groupby(["_day", "_hr"]).size().unstack(fill_value=0)
                            .reindex(day_order, fill_value=0)
                            .reindex(columns=range(24), fill_value=0)  # ensure all 24 hours present
                        )
                        heat_fig = go.Figure(go.Heatmap(
                            z=pivot.values.tolist(),
                            x=[f"{h:02d}:00" for h in range(24)],
                            y=list(pivot.index),
                            colorscale=[
                                [0.0,  "#0D1218"],
                                [0.25, "#1E3A5F"],
                                [0.5,  "#FF9800"],
                                [0.75, "#FF5722"],
                                [1.0,  "#FF1744"],
                            ],
                            hovertemplate="<b>%{y} %{x}</b><br>Transactions: %{z:,}<extra></extra>",
                            showscale=True,
                            colorbar=dict(title="Count", tickfont=dict(color=CHART_TEXT)),
                        ))
                        styled_layout(heat_fig, height=380, legend=False)
                        # Business hours shading
                        heat_fig.add_vrect(x0="09:00", x1="17:00", fillcolor="#00E676", opacity=0.05, line_width=0)
                        heat_fig.add_annotation(x="13:00", y=1.03, text="Business Hours", showarrow=False,
                                                font=dict(color="#00E676", size=9), yref="paper")
                        heatmap_badge = f"{len(t):,} transactions"
            except Exception as e:
                heat_fig = empty_fig(f"Error building heatmap: {e}")

    # ── 3. SANKEY FLOW ────────────────────────────────────────────────────────
    sankey_note = html.Span()

    if no_pipe:
        sankey_fig = empty_fig()
    elif edge_df is None:
        sankey_fig  = empty_fig("Edge / transaction table not loaded.")
        sankey_note = fallback_note("Upload an edge table with 'from_node' and 'amount' columns.")
    else:
        from_col = _find_col(edge_df, ["from_node", "source", "from_id", "from"])
        to_col   = _find_col(edge_df, ["to_node",   "target", "to_id",   "to"])
        amt_col  = _find_col(edge_df, ["amount", "value", "transaction_amount", "amt"])
        if not from_col or not to_col:
            sankey_fig  = empty_fig("Edge table needs 'from_node' and 'to_node' columns.")
            sankey_note = fallback_note("Rename your source/target columns to 'from_node' and 'to_node'.")
        elif not amt_col:
            sankey_fig  = empty_fig("No 'amount' column in edge table — Sankey requires monetary values.")
            sankey_note = fallback_note("Add an 'amount' column to your edge table to enable this view.")
        elif scored is None:
            sankey_fig  = empty_fig("Pipeline scored data required.")
        else:
            try:
                tier_map = dict(zip(scored["node_id"].astype(str), scored["tier"])) if "node_id" in scored.columns and "tier" in scored.columns else {}
                e = edge_df[[from_col, to_col, amt_col]].copy()
                e["from_tier"] = e[from_col].astype(str).map(tier_map).fillna("P4")
                e["to_tier"]   = e[to_col].astype(str).map(tier_map).fillna("P4")
                flow = e.groupby(["from_tier", "to_tier"])[amt_col].sum().reset_index()

                tiers = ["P1", "P2", "P3", "P4"]
                tier_idx = {t: i for i, t in enumerate(tiers)}
                sources = [tier_idx.get(r["from_tier"], 3) for _, r in flow.iterrows()]
                targets = [tier_idx.get(r["to_tier"],   3) + 4 for _, r in flow.iterrows()]
                values  = [float(r[amt_col]) for _, r in flow.iterrows()]

                node_labels = [f"{t} (Source)" for t in tiers] + [f"{t} (Destination)" for t in tiers]
                node_colors = [TIER_COLORS.get(t, "#8899AA") for t in tiers] * 2

                sankey_fig = go.Figure(go.Sankey(
                    node=dict(
                        label=node_labels,
                        color=node_colors,
                        pad=20, thickness=25,
                        line=dict(color="rgba(0,0,0,0)", width=0),
                    ),
                    link=dict(
                        source=sources,
                        target=targets,
                        value=values,
                        color=[_TIER_LINK_RGBA.get(flow.iloc[i]["from_tier"], "rgba(136,153,170,0.35)") for i in range(len(flow))],
                        hovertemplate="<b>%{source.label}</b> → <b>%{target.label}</b><br>"
                                      "Total Flow: $%{value:,.0f}<extra></extra>",
                    ),
                ))
                styled_layout(sankey_fig, height=400, legend=False)
            except Exception as e:
                sankey_fig  = empty_fig(f"Could not build Sankey diagram: {e}")

    # ── 4. TOP 10 CORRIDORS ───────────────────────────────────────────────────
    corridors_note = html.Span()

    if no_pipe:
        corridors_fig = empty_fig()
    elif edge_df is None:
        corridors_fig  = empty_fig("Edge table not loaded.")
        corridors_note = fallback_note("Upload an edge / transaction table to see the top flow corridors.")
    else:
        from_col = _find_col(edge_df, ["from_node", "source", "from_id", "from"])
        to_col   = _find_col(edge_df, ["to_node",   "target", "to_id",   "to"])
        amt_col  = _find_col(edge_df, ["amount", "value", "transaction_amount", "amt"])
        if not from_col or not to_col:
            corridors_fig  = empty_fig("Edge table needs 'from_node' and 'to_node' columns.")
            corridors_note = fallback_note("Rename columns to 'from_node' and 'to_node' to enable this chart.")
        else:
            try:
                e2 = edge_df[[from_col, to_col] + ([amt_col] if amt_col else [])].copy()
                e2["pair"] = (
                    e2[from_col].astype(str).map(lambda x: _label(x, name_map))
                    + "  →  "
                    + e2[to_col].astype(str).map(lambda x: _label(x, name_map))
                )
                if amt_col:
                    top10 = e2.groupby("pair")[amt_col].sum().nlargest(10).reset_index()
                    top10.columns = ["pair", "total"]
                    x_lbl = "Total Flow ($)"
                else:
                    top10 = e2["pair"].value_counts().head(10).reset_index()
                    top10.columns = ["pair", "total"]
                    x_lbl = "Transaction Count"
                    corridors_note = fallback_note("No 'amount' column — showing transaction count instead of dollar value.")

                # Get tier of the 'from' node for colour
                tier_map2 = dict(zip(scored["node_id"].astype(str), scored["tier"])) if scored is not None and "node_id" in scored.columns and "tier" in scored.columns else {}
                top10["from_node"] = top10["pair"].str.split(" → ").str[0]
                top10["tier"]      = top10["from_node"].map(tier_map2).fillna("P4")

                corridors_fig = go.Figure(go.Bar(
                    x=top10["total"],
                    y=top10["pair"],
                    orientation="h",
                    marker_color=[TIER_COLORS.get(t, "#8899AA") for t in top10["tier"]],
                    hovertemplate="<b>%{y}</b><br>" + x_lbl + ": %{x:,.0f}<extra></extra>",
                ))
                styled_layout(corridors_fig, height=380, legend=False)
                corridors_fig.update_layout(
                    xaxis_title=x_lbl,
                    yaxis=dict(autorange="reversed"),
                )
            except Exception as e:
                corridors_fig = empty_fig(f"Could not build corridors chart: {e}")

    # ── 5. STRUCTURING TABLE ──────────────────────────────────────────────────
    struct_df = a_results.get("structuring") if a_results else None

    if no_pipe:
        struct_table = no_data_card("Run pipeline to detect structuring patterns.")
        struct_count = "—"
    elif struct_df is None or len(struct_df) == 0:
        struct_table = dmc.Paper(
            dmc.Stack(
                [
                    DashIconify(icon="mdi:check-circle-outline", width=36, color="#00E676"),
                    dmc.Text("No Structuring Patterns Detected", fw=600, c="#00E676", size="sm", ta="center"),
                    dmc.Text(
                        "The structuring detection engine found no customers with a statistically "
                        "significant pattern of transactions designed to avoid reporting thresholds. "
                        "This is a clean result — document it for your regulatory file.",
                        size="xs", c=DIM, ta="center", style={"lineHeight": "1.5"},
                    ),
                ],
                align="center", gap="sm", py="xl",
            ),
            p="xl", radius="lg", className="glass-card",
        )
        struct_count = "0 detected"
    else:
        try:
            # ── Sort by structuring score descending (highest risk first) ─────────────
            score_col = _find_col(struct_df, ["structuring_score", "score"])
            if score_col:
                struct_df = struct_df.sort_values(score_col, ascending=False).reset_index(drop=True)

            # ── Enrich struct_df with Customer Name from node lookup ────────────────────
            struct_df = struct_df.copy()
            if name_map and "node_id" in struct_df.columns:
                struct_df["Customer Name"] = struct_df["node_id"].astype(str).map(name_map).fillna("—")
            elif "Customer Name" not in struct_df.columns:
                struct_df["Customer Name"] = "—"

            display_cols = [c for c in [
                "node_id", "Customer Name", "customer_name", "name",
                "structuring_score", "score",
                "transaction_count", "txn_count",
                "total_amount", "total_value",
                "pattern_type", "type",
                "days_active", "tier",
            ] if c in struct_df.columns]
            if not display_cols:
                display_cols = list(struct_df.columns[:8])

            # Build premium column definitions
            score_col = _find_col(struct_df, ["structuring_score", "score"])
            struct_df = struct_df.copy()
            if score_col:
                struct_df["Confidence"] = struct_df[score_col].apply(
                    lambda x: "HIGH" if x >= 0.7 else ("MEDIUM" if x >= 0.4 else "LOW")
                )
                struct_df["Risk Level"] = struct_df[score_col].apply(
                    lambda x: round(float(x) * 100, 1) if x is not None else 0
                )

            col_defs = []
            for c in display_cols:
                d = {"field": c, "headerName": c.replace("_", " ").title(), "flex": 1,
                     "filter": True, "sortable": True, "resizable": True}
                if c == "Customer Name":
                    d["minWidth"]  = 160
                    d["pinned"]    = "left"
                    d["cellStyle"] = {"color": "#00D4FF", "fontWeight": "600"}
                elif c in ("structuring_score", "score"):
                    d["valueFormatter"] = {"function": "d3.format(',.3f')(params.value)"}
                    d["cellStyle"] = {"function":
                        "params.value >= 0.7 ? {'color':'#FF1744','fontWeight':700} : "
                        "params.value >= 0.4 ? {'color':'#FF9800','fontWeight':600} : "
                        "{'color':'#00E676'}"}
                elif c in ("total_amount", "total_value"):
                    d["valueFormatter"] = {"function": "'$' + d3.format(',.0f')(params.value)"}
                    d["cellStyle"] = {"color": "#FFD600", "fontWeight": "600"}
                elif c in ("transaction_count", "txn_count"):
                    d["valueFormatter"] = {"function": "d3.format(',d')(params.value)"}
                elif c == "tier":
                    d["cellStyle"] = {"function":
                        "params.value === 'P1' ? {'background':'rgba(255,23,68,.15)','color':'#FF1744','fontWeight':700} : "
                        "params.value === 'P2' ? {'background':'rgba(255,152,0,.12)','color':'#FF9800','fontWeight':600} : "
                        "{'color':'#CBD5E1'}"}
                col_defs.append(d)

            if score_col:
                col_defs.append({"field": "Confidence", "headerName": "Confidence", "width": 120,
                                  "pinned": "right", "sortable": True,
                                  "cellStyle": {"function":
                                      "params.value === 'HIGH' ? {'background':'rgba(255,23,68,.2)','color':'#FF1744','fontWeight':700,'textAlign':'center'} : "
                                      "params.value === 'MEDIUM' ? {'background':'rgba(255,152,0,.15)','color':'#FF9800','fontWeight':600,'textAlign':'center'} : "
                                      "{'background':'rgba(0,230,118,.1)','color':'#00E676','textAlign':'center'}"}})
                col_defs.append({"field": "Risk Level", "headerName": "Risk Level %", "width": 130,
                                  "pinned": "right", "sortable": True,
                                  "cellRenderer": "agAnimateShowChangeCellRenderer",
                                  "cellStyle": {"function": "{'color': params.value >= 70 ? '#FF1744' : params.value >= 40 ? '#FF9800' : '#00E676', 'fontWeight': '700'}"}})

            extra_cols = [c for c in ["Confidence", "Risk Level"] if score_col and c in struct_df.columns]
            struct_table = dag.AgGrid(
                rowData=struct_df[display_cols + extra_cols].to_dict("records"),
                columnDefs=col_defs,
                dashGridOptions={
                    "animateRows": True,
                    "pagination": True,
                    "paginationPageSize": 15,
                    "enableCellTextSelection": True,
                    "rowSelection": "single",
                    "suppressMovableColumns": False,
                    "domLayout": "autoHeight",
                    "getRowStyle": {"function": "return {'backgroundColor': '#060D1A', 'color': '#CBD5E1'}"},
                },
                defaultColDef={"sortable": True, "filter": True, "resizable": True,
                               "floatingFilter": True,
                               "cellStyle": {"color": "#CBD5E1", "backgroundColor": "#060D1A"},
                               "headerStyle": {"backgroundColor": "#0A1628", "color": "#00D4FF",
                                               "borderBottom": "2px solid rgba(0,212,255,0.45)"}},
                className="ag-theme-alpine-dark",
                # v16.62: CSS custom properties override ag-theme-alpine-dark for true dark background
                style={
                    "height": "420px",
                    "borderRadius": "8px",
                    "border": "1px solid rgba(0,212,255,0.25)",
                    "--ag-background-color": "#060D1A",
                    "--ag-foreground-color": "#CBD5E1",
                    "--ag-header-background-color": "#0A1628",
                    "--ag-header-foreground-color": "#00D4FF",
                    "--ag-row-hover-background-color": "#0D1B2E",
                    "--ag-odd-row-background-color": "#070E1A",
                    "--ag-border-color": "rgba(0,212,255,0.2)",
                    "--ag-row-border-color": "rgba(255,255,255,0.05)",
                    "--ag-selected-row-background-color": "#0F2040",
                    "--ag-range-selection-border-color": "#00D4FF",
                },
            )
            struct_count = f"{len(struct_df):,} detected"
        except Exception as e:
            struct_table = dmc.Text(f"Error building structuring table: {e}", c="red", size="sm")
            struct_count = "error"

    return (
        net_kpis,
        heatmap_badge, heatmap_note, heat_fig,
        sankey_note, sankey_fig,
        corridors_note, corridors_fig,
        struct_count, struct_table,
    )
