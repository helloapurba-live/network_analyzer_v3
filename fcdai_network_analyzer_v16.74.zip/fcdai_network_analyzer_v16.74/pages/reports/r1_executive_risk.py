"""
REPORT R1 — Risk & Exposure
=======================================
Groups: G1 (Morning Pulse) + G2 (Dollar Numbers)
Audience: CEO, CFO, MLRO
Update: Auto-syncs on every pipeline run

Story: The first page any senior leader opens. In under 60 seconds it
answers: How risky is our portfolio right now? Is it getting better or
worse over time? And critically — how many dollars are sitting inside
that risk? Every number uses business language. No algorithm names.
No model jargon. Just counts, percentages, and dollar amounts.
"""
from __future__ import annotations

import json
import sys
from datetime import datetime
from pathlib import Path

import dash
import dash_mantine_components as dmc
import pandas as pd
import plotly.graph_objects as go
from dash import Input, Output, callback, dcc, html
from dash_iconify import DashIconify

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from config import APP, THEME
from database import get_db
from engine import get_pipeline
from utils.data_provider import get_latest_scored  # v16.72 F4
from pages.reports import (
    TIER_COLORS, TIER_LABELS, CHART_BG, CHART_TEXT, CHART_GRID, DIM,
    ACCENT_GOLD, HEALTH_P1_CRITICAL, HEALTH_P1_AMBER, HEALTH_P2_HIGH,
    empty_fig, styled_layout, page_header, section_header,
    kpi_card, no_data_card, fallback_note, _tbl,
)

dash.register_page(
    __name__,
    path="/reports/executive-risk",
    name="Risk & Exposure",
    title=f"FCDAI v{APP.VERSION} | Risk & Exposure",
)

# ─────────────────────────────────────────────────────────────────────────────
# LAYOUT
# ─────────────────────────────────────────────────────────────────────────────
layout = dmc.Box(
    [
        dcc.Interval(id="r1-init", interval=800, max_intervals=1),
        page_header(
            icon="mdi:shield-crown-outline",
            title="Risk & Exposure",
            subtitle="Groups G1 + G2 — Portfolio Morning Pulse + Dollar Numbers",
            story=(
                "This page answers the two questions every senior leader asks before the morning "
                "compliance call: Is our risk posture better or worse than yesterday — and what is the "
                "actual dollar value sitting inside that risk? "
                "The left side shows customer counts by risk tier; the right side converts those tiers "
                "into estimated suspicious flow in dollars. "
                "The trend section below shows whether the portfolio is improving or deteriorating "
                "across consecutive screening runs — your early-warning signal that something in the "
                "customer base is changing. "
                "If P1 (Critical) customers are rising without a corresponding increase in investigated "
                "cases, that is your alert."
            ),
            accent=ACCENT_GOLD,
        ),

        # ── SECTION 1: Live Portfolio Snapshot (KPIs) ────────────────────────
        section_header(
            "mdi:gauge-full",
            "Portfolio Risk Snapshot — Right Now",
            "Live counts of customers in each risk tier from the most recent pipeline run.",
            accent="#00D4FF",
        ),
        dmc.SimpleGrid(
            id="r1-kpi-row",
            cols={"base": 2, "sm": 4},
            spacing="md",
            mb="xl",
        ),

        # ── SECTION 2: Composition + Health Score ────────────────────────────
        section_header(
            "mdi:chart-donut",
            "Portfolio Composition & AML Health Score",
            "How the portfolio splits across tiers — and a single composite score that summarises overall risk posture.",
            accent="#9D4EDD",
        ),
        dmc.SimpleGrid(
            cols={"base": 1, "md": 2},
            spacing="md",
            mb="xl",
            children=[
                dmc.Paper(
                    [
                        dmc.Text("Risk Tier Composition", fw=700, size="sm", c="white", mb=4),
                        dmc.Text(
                            "Each slice represents a share of the total monitored customer base. "
                            "A healthy portfolio concentrates in P3 and P4 (low/medium). "
                            "Any visible P1 slice (red) demands immediate attention.",
                            size="xs", c=DIM, mb="sm", style={"lineHeight": "1.5"},
                        ),
                        dcc.Graph(
                            id="r1-donut",
                            config={"displayModeBar": False},
                            style={"height": "320px"},
                        ),
                    ],
                    p="lg", radius="lg", className="glass-card",
                ),
                dmc.Paper(
                    [
                        dmc.Text("AML Health Score", fw=700, size="sm", c="white", mb=4),
                        dmc.Text(
                            "A single 0–100 composite score derived from your portfolio's tier distribution, "
                            "detection coverage, and data quality. Below 60 = regulatory risk. Above 80 = strong posture. "
                            "This is the number your MLRO presents to the board.",
                            size="xs", c=DIM, mb="sm", style={"lineHeight": "1.5"},
                        ),
                        dcc.Graph(
                            id="r1-health-gauge",
                            config={"displayModeBar": False},
                            style={"height": "300px"},
                        ),
                        html.Div(id="r1-health-formula"),
                    ],
                    p="lg", radius="lg", className="glass-card",
                ),
            ],
        ),

        # ── SECTION 3: Portfolio Heatmap — Customer Type × Risk Tier ──────────
        section_header(
            "mdi:grid",
            "Portfolio Heatmap — Customer Type × Risk Tier",
            "Which types of customers carry the most risk? Use the filter to switch classification dimension.",
            accent="#00E676",
        ),
        dmc.Paper(
            [
                dmc.Group(
                    [
                        dmc.Text("Customers by Type and Risk Tier", fw=700, size="sm", c="white"),
                        dmc.SegmentedControl(
                            id="r1-type-select",
                            value="node_type",
                            data=[
                                {"label": "Customer Category",  "value": "node_type"},
                                {"label": "Client Relationship", "value": "node_type1"},
                                {"label": "Customer Segment",    "value": "node_type3"},
                            ],
                            size="xs",
                            color="cyan",
                        ),
                    ],
                    justify="space-between", mb=4,
                ),
                dmc.Text(
                    "Filter by dimension above.  Rows = customer types.  Columns = risk tiers P1–P4. "
                    "Cell colour + count shows concentration per type. "
                    "Red cells in P1 (Critical) signal a segment-level risk requiring immediate policy review.",
                    size="xs", c=DIM, mb="sm", style={"lineHeight": "1.5"},
                ),
                html.Div(id="r1-heatmap-note"),
                dcc.Graph(
                    id="r1-heatmap",
                    config={"displayModeBar": False},
                    style={"height": "380px"},
                ),
            ],
            p="lg", radius="lg", className="glass-card", mb="xl",
        ),

        # ── SECTION 5: Dollar Exposure ────────────────────────────────────────
        section_header(
            "mdi:currency-usd",
            "Financial Exposure — The Dollar Numbers",
            "Converting risk tiers into monetary amounts. What is the actual suspicious flow value?",
            accent="#FFD600",
        ),
        dmc.SimpleGrid(
            cols={"base": 1, "md": 3},
            spacing="md",
            mb="md",
            children=[
                dmc.Paper(id="r1-exposure-p1", p="lg", radius="lg", className="glass-card"),
                dmc.Paper(id="r1-exposure-p2", p="lg", radius="lg", className="glass-card"),
                dmc.Paper(id="r1-exposure-total", p="lg", radius="lg", className="glass-card"),
            ],
        ),
        dmc.SimpleGrid(
            cols={"base": 1, "md": 2},
            spacing="md",
            mb="xl",
            children=[
                dmc.Paper(
                    [
                        dmc.Text("Financial Exposure by Risk Tier ($)", fw=700, size="sm", c="white", mb=4),
                        dmc.Text(
                            "Each bar shows the total transaction value attributed to customers in that risk tier. "
                            "Critical (P1) dollars represent the highest-priority suspicious funds requiring "
                            "immediate SAR review. High Risk (P2) dollars are the escalation pipeline.",
                            size="xs", c=DIM, mb="sm", style={"lineHeight": "1.5"},
                        ),
                        html.Div(id="r1-expo-note"),
                        dcc.Graph(
                            id="r1-exposure-bar",
                            config={"displayModeBar": False},
                            style={"height": "300px"},
                        ),
                    ],
                    p="lg", radius="lg", className="glass-card",
                ),
                dmc.Paper(
                    [
                        dmc.Text("Risk Score vs Transaction Volume", fw=700, size="sm", c="white", mb=4),
                        dmc.Text(
                            "Each dot is one customer. X-axis is their total transaction volume in dollars. "
                            "Y-axis is their risk score. Customers in the top-right corner are the highest "
                            "priority: large transaction volumes AND high risk scores. These are your "
                            "most consequential cases.",
                            size="xs", c=DIM, mb="sm", style={"lineHeight": "1.5"},
                        ),
                        dcc.Graph(
                            id="r1-scatter",
                            config={"displayModeBar": True},
                            style={"height": "300px"},
                        ),
                    ],
                    p="lg", radius="lg", className="glass-card",
                ),
            ],
        ),

        # ── SECTION 6: Run History Flags ──────────────────────────────────────
        section_header(
            "mdi:chart-bar",
            "Flags Generated Per Screening Run",
            "How many P1 and P2 customers were identified in each pipeline run — your operational cadence view.",
            accent="#26C6DA",
        ),
        dmc.Paper(
            [
                dmc.Text("P1 + P2 Flags Per Pipeline Run", fw=700, size="sm", c="white", mb=4),
                dmc.Text(
                    "Each group of bars represents one full screening run of your customer database. "
                    "Red bars (P1 Critical) should remain as flat as possible. "
                    "An increasing red trend means your portfolio risk is escalating.",
                    size="xs", c=DIM, mb="sm", style={"lineHeight": "1.5"},
                ),
                dcc.Graph(
                    id="r1-flags-bar",
                    config={"displayModeBar": True},
                    style={"height": "300px"},
                ),
                html.Div(id="r1-flags-note"),
            ],
            p="lg", radius="lg", className="glass-card", mb="xl",
        ),

        # ── SECTION 7: Risk Escalation Trend (moved to bottom) ───────────────
        section_header(
            "mdi:trending-up",
            "Risk Escalation Trend — Across Pipeline Runs",
            "P1 & P2 Customer Count Per Run + Average Risk Score. Is the portfolio improving or deteriorating?",
            accent="#FF6B6B",
        ),
        dmc.Paper(
            [
                dmc.Text("P1 & P2 Customer Count Per Run  +  Average Risk Score", fw=700, size="sm", c="white", mb=4),
                dmc.Text(
                    "Left axis: number of customers flagged as Critical (P1) or High Risk (P2) in each pipeline run. "
                    "Right axis: the portfolio average risk score. "
                    "Ideal: P1/P2 counts declining while coverage increases. "
                    "Warning signal: both lines rising simultaneously.",
                    size="xs", c=DIM, mb="sm", style={"lineHeight": "1.5"},
                ),
                dcc.Graph(
                    id="r1-trend-line",
                    config={"displayModeBar": True},
                    style={"height": "340px"},
                ),
                html.Div(id="r1-trend-note"),
            ],
            p="lg", radius="lg", className="glass-card", mb="xl",
        ),
    ],
    p="lg",
)


# ─────────────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────────────
def _safe(val, default=0):
    try:
        return float(val) if val is not None else default
    except Exception:
        return default


def _fmt_money(v: float) -> str:
    if v >= 1_000_000:
        return f"${v/1_000_000:.1f}M"
    if v >= 1_000:
        return f"${v/1_000:.0f}K"
    return f"${v:.0f}"


def _compute_health(p1_pct, p2_pct, coverage_pct, quality_pct) -> float:
    """v16.71 H1: Dynamic AML Health Score 0-100.
    Redesigned so the score moves meaningfully with real data:

    - P1 rate drives the score down hard: +1% P1 = -8 pts penalty (capped at 40)
    - P2 rate adds pressure: +1% P2 = -3 pts (capped at 20)
    - Coverage rewards: full portfolio screened = +20 pts; zero coverage = 0 pts
    - Quality rewards: excellent data = up to +15 pts
    - Combined P1+P2 above 10%: additional -5 pt emergency flag
    - Zones: 80+ = Green (Compliant), 60-79 = Amber (Needs Attention), <60 = Red (Action Required)

    A pristine portfolio with zero P1/P2 and full coverage scores ~95.
    A portfolio with 5% P1 rate scores ~55 (Amber borderline Red).
    A portfolio with 15% P1 rate scores ~15 (deep Red — immediate action).
    """
    # P-tier penalties — calibrated so scores are meaningful at industry benchmarks
    penalty_p1  = min(p1_pct * 8.0, 40)    # Dominant driver: 5% P1 → -40 pts (critical)
    penalty_p2  = min(p2_pct * 3.0, 20)    # Significant: 7% P2 → -21pts (capped at 20)
    # Emergency penalty: combined P1+P2 >10% signals systemic risk
    combined_penalty = 5.0 if (p1_pct + p2_pct) > 10.0 else 0.0
    # Coverage bonus: rewards complete screening (max +20)
    bonus_cov   = min(coverage_pct / 100.0 * 20.0, 20.0)
    # Quality bonus: rewards clean data (max +15)
    bonus_qual  = min(quality_pct  / 100.0 * 15.0, 15.0)
    # Base = 80 (good programme) — penalties bring it down; bonuses improve it
    score = 80.0 - penalty_p1 - penalty_p2 - combined_penalty + bonus_cov + bonus_qual
    return round(max(0.0, min(100.0, score)), 1)


def _get_run_tier_history(limit: int = 20):
    """Read tier distribution + avg_risk from run metadata stored in SQLite."""
    try:
        db = get_db()
        history = db.get_run_history(limit=limit)
        if history is None or len(history) == 0:
            return []
        # metadata is NOT in get_run_history — query it directly
        conn = db._conn
        rows = conn.execute(
            "SELECT run_id, started_at, metadata FROM pipeline_runs "
            "WHERE status='success' ORDER BY run_id ASC LIMIT ?",
            (limit,),
        ).fetchall()
        result = []
        for r in rows:
            rid, ts, meta_json = r
            try:
                meta = json.loads(meta_json or "{}")
                td = meta.get("tier_distribution", {})
                result.append({
                    "run_id": rid,
                    "label": f"Run #{rid}",
                    "date": ts[:10] if ts else "",
                    "p1": td.get("P1", 0),
                    "p2": td.get("P2", 0),
                    "p3": td.get("P3", 0),
                    "p4": td.get("P4", 0),
                    "customers": meta.get("customers", 0),
                    "avg_risk": meta.get("avg_risk", None),
                })
            except Exception:
                pass
        return result
    except Exception:
        return []


# ─────────────────────────────────────────────────────────────────────────────
# CALLBACK
# ─────────────────────────────────────────────────────────────────────────────
@callback(
    Output("r1-kpi-row",       "children"),
    Output("r1-donut",         "figure"),
    Output("r1-health-gauge",   "figure"),
    Output("r1-health-formula", "children"),
    Output("r1-trend-line",     "figure"),
    Output("r1-trend-note",    "children"),
    Output("r1-heatmap",       "figure"),
    Output("r1-heatmap-note",  "children"),
    Output("r1-exposure-p1",   "children"),
    Output("r1-exposure-p2",   "children"),
    Output("r1-exposure-total","children"),
    Output("r1-exposure-bar",  "figure"),
    Output("r1-expo-note",     "children"),
    Output("r1-scatter",       "figure"),
    Output("r1-flags-bar",     "figure"),
    Output("r1-flags-note",    "children"),
    Input("pipeline-state",    "data"),
    Input("global-refresh-ts", "data"),
    Input("r1-init",           "n_intervals"),
    Input("r1-type-select",    "value"),
    prevent_initial_call=False,
)
def update_r1(_ps, _grt, _init, type_col):
    pipeline = get_pipeline()  # kept for any direct pipeline method calls
    # v16.72 F4+F5: unified loader — memory-first, DB fallback, score_* normalize
    _dp    = get_latest_scored(pipeline)
    scored = _dp["scored"]
    tables = _dp["tables"]

    # ── normalise engine column names so the whole callback uses "tier" ───────
    if scored is not None:
        if "risk_tier" in scored.columns and "tier" not in scored.columns:
            scored = scored.rename(columns={"risk_tier": "tier"})
        # also make sure 'node_id' exists (some versions use 'customer_id')
        if "node_id" not in scored.columns:
            for alt in ["customer_id", "id"]:
                if alt in scored.columns:
                    scored = scored.rename(columns={alt: "node_id"})
                    break

    no_pipe = scored is None or len(scored) == 0

    # ── KPI ROW ───────────────────────────────────────────────────────────────
    if no_pipe:
        kpis = [no_data_card("No pipeline data yet.", "Run the pipeline to populate this page.")]
    else:
        tc = scored["tier"].value_counts().to_dict() if "tier" in scored.columns else {}
        total = max(len(scored), 1)
        tier_icons = {"P1": "mdi:alert-octagon", "P2": "mdi:alert", "P3": "mdi:shield-outline", "P4": "mdi:check-circle"}
        tier_colors_dash = {"P1": "red", "P2": "orange", "P3": "yellow", "P4": "green"}
        kpis = []
        for t in ["P1", "P2", "P3", "P4"]:
            cnt = tc.get(t, 0)
            pct = cnt / total * 100
            kpis.append(kpi_card(
                title=TIER_LABELS[t],
                value=f"{cnt:,}",
                sub=f"{pct:.1f}% of portfolio",
                icon=tier_icons[t],
                color=tier_colors_dash[t],
            ))

    # ── DONUT ─────────────────────────────────────────────────────────────────
    if no_pipe:
        donut_fig = empty_fig()
    else:
        tc = scored["tier"].value_counts().reindex(["P1", "P2", "P3", "P4"], fill_value=0).to_dict() if "tier" in scored.columns else {}
        labels = [TIER_LABELS.get(t, t) for t in tc.keys()]
        values = list(tc.values())
        colors = [TIER_COLORS.get(t, "#8899AA") for t in tc.keys()]
        donut_fig = go.Figure(go.Pie(
            labels=labels,
            values=values,
            marker_colors=colors,
            hole=0.55,
            textinfo="percent+value",
            hovertemplate="<b>%{label}</b><br>Customers: %{value:,}<br>Share: %{percent}<extra></extra>",
        ))
        total_c = sum(values)
        donut_fig.add_annotation(
            text=f"<b>{total_c:,}</b><br><span style='font-size:10px'>Total</span>",
            showarrow=False,
            font=dict(color="white", size=16),
            x=0.5, y=0.5,
        )
        styled_layout(donut_fig, height=320, legend=True)
        donut_fig.update_layout(legend=dict(orientation="h", yanchor="bottom", y=-0.15, x=0.5, xanchor="center"))

    # ── HEALTH GAUGE ──────────────────────────────────────────────────────────
    if no_pipe:
        gauge_fig = empty_fig()
    else:
        tc = scored["tier"].value_counts().to_dict() if "tier" in scored.columns else {}
        total = max(len(scored), 1)
        p1_pct = tc.get("P1", 0) / total * 100
        p2_pct = tc.get("P2", 0) / total * 100
        # coverage: fraction of customers with at least one non-null family score
        # N1 FIX v16.71: DB stores score_* prefix (score_centrality etc.), not *_score suffix
        _EXCL_SCORE = {"risk_score", "pre_calib_score", "risk_probability"}
        family_cols = [
            c for c in scored.columns
            if (c.startswith("score_") or c.endswith("_score"))
            and c not in _EXCL_SCORE
        ]
        if family_cols:
            covered = scored[family_cols].notna().any(axis=1).sum()
            cov_pct = min(covered / total * 100, 100.0)
        else:
            # No family-level scores available — partial coverage
            cov_pct = 50.0
        # Quality: penalise if fewer than 3 family engines produced scores
        active_fams = sum(1 for c in family_cols if scored[c].notna().any()) if family_cols else 0
        quality_pct = min(active_fams / 10 * 100, 100.0)  # 10 possible engines
        health = _compute_health(p1_pct, p2_pct, cov_pct, quality_pct)
        # Pre-compute components for the annotation breakdown (v16.71 H1 formula)
        _pen1   = min(p1_pct  * 8.0, 40)
        _pen2   = min(p2_pct  * 3.0, 20)
        _cpen   = 5.0 if (p1_pct + p2_pct) > 10.0 else 0.0
        _bcov   = min(cov_pct   / 100.0 * 20.0, 20.0)
        _bqual  = min(quality_pct / 100.0 * 15.0, 15.0)
        bar_color = "#FF1744" if health < 60 else ("#FFD600" if health < 80 else "#00E676")
        gauge_fig = go.Figure(go.Indicator(
            mode="gauge+number+delta",
            value=round(health, 1),
            title={"text": "AML Health Score", "font": {"color": "white", "size": 14}},
            number={"font": {"color": "white", "size": 36}, "suffix": " / 100"},
            gauge={
                "axis": {"range": [0, 100], "tickcolor": CHART_TEXT, "tickfont": {"color": CHART_TEXT}},
                "bar": {"color": bar_color, "thickness": 0.25},
                "bgcolor": "rgba(0,0,0,0.2)",
                "borderwidth": 0,
                "steps": [
                    {"range": [0,  60], "color": "rgba(255,23,68,0.15)"},    # Red: Action Required
                    {"range": [60, 80], "color": "rgba(255,214,0,0.12)"},    # Amber: Needs Attention
                    {"range": [80,100], "color": "rgba(0,230,118,0.12)"},    # Green: Compliant
                ],
                "threshold": {
                    "line": {"color": "#00D4FF", "width": 2},
                    "thickness": 0.75,
                    "value": 80,   # v16.71: green target line at 80
                },
            },
        ))
        gauge_fig.update_layout(
            paper_bgcolor=CHART_BG,
            font=dict(color=CHART_TEXT),
            height=300,
            margin=dict(l=40, r=40, t=60, b=20),
        )
        # ── Formula breakdown as a fully visible Dash component below chart ────
        health_formula = dmc.Paper(
            [
                dmc.Text("How this score is calculated", fw=700, size="xs", c="#00D4FF", mb="xs"),
                dmc.SimpleGrid(
                    cols={"base": 2, "sm": 6}, spacing="xs", mb="xs",
                    children=[
                        dmc.Stack([
                            dmc.Text("Base Score",          size="9px", c="dimmed"),
                            dmc.Text("80",                  fw=800, size="md", c="white"),
                            dmc.Text("Programme start",     size="9px", c="dimmed", fs="italic"),
                        ], gap=1, style={"backgroundColor": "rgba(0,212,255,0.06)",  "borderRadius": "6px", "padding": "8px"}),
                        dmc.Stack([
                            dmc.Text("P1 Critical Penalty",          size="9px", c="dimmed"),
                            dmc.Text(f"\u2212{_pen1:.1f}",               fw=800, size="md", c="#FF1744"),
                            dmc.Text(f"{p1_pct:.1f}% x 8.0 (max -40)", size="9px", c="dimmed", fs="italic"),
                        ], gap=1, style={"backgroundColor": "rgba(255,23,68,0.08)",   "borderRadius": "6px", "padding": "8px"}),
                        dmc.Stack([
                            dmc.Text("P2 High Risk Penalty",         size="9px", c="dimmed"),
                            dmc.Text(f"\u2212{_pen2:.1f}",               fw=800, size="md", c="#FF9800"),
                            dmc.Text(f"{p2_pct:.1f}% x 3.0 (max -20)", size="9px", c="dimmed", fs="italic"),
                        ], gap=1, style={"backgroundColor": "rgba(255,152,0,0.08)",   "borderRadius": "6px", "padding": "8px"}),
                        dmc.Stack([
                            dmc.Text("Coverage Bonus",               size="9px", c="dimmed"),
                            dmc.Text(f"+{_bcov:.1f}",                fw=800, size="md", c="#00E676"),
                            dmc.Text(f"{cov_pct:.0f}% screened \u2192 max +20", size="9px", c="dimmed", fs="italic"),
                        ], gap=1, style={"backgroundColor": "rgba(0,230,118,0.07)",   "borderRadius": "6px", "padding": "8px"}),
                        dmc.Stack([
                            dmc.Text("Data Quality Bonus",           size="9px", c="dimmed"),
                            dmc.Text(f"+{_bqual:.1f}",               fw=800, size="md", c="#26C6DA"),
                            dmc.Text(f"quality {quality_pct:.0f}% \u00d7 0.15 (max +15)", size="9px", c="dimmed", fs="italic"),
                        ], gap=1, style={"backgroundColor": "rgba(38,198,218,0.07)",  "borderRadius": "6px", "padding": "8px"}),
                        dmc.Stack([
                            dmc.Text("Combined P1+P2 Penalty",      size="9px", c="dimmed"),
                            dmc.Text(f"\u2212{_cpen:.0f}" if _cpen > 0 else "\u00b10", fw=800, size="md", c="#FF5722" if _cpen > 0 else DIM),
                            dmc.Text("\u22125 if P1+P2 > 10%",     size="9px", c="dimmed", fs="italic"),
                        ], gap=1, style={"backgroundColor": "rgba(255,87,34,0.07)",   "borderRadius": "6px", "padding": "8px"}),
                    ],
                ),
                dmc.Divider(color="rgba(0,212,255,0.12)", mb="xs"),
                dmc.Group(
                    [
                        dmc.Text("Score  =  80",            size="xs", c=DIM),
                        dmc.Text(f" - {_pen1:.1f}",         size="xs", fw=700, c="#FF1744"),
                        dmc.Text(f" - {_pen2:.1f}",         size="xs", fw=700, c="#FF9800"),
                        dmc.Text(f" - {_cpen:.0f}" if _cpen > 0 else "",  size="xs", fw=700, c="#FF5722"),
                        dmc.Text(f" + {_bcov:.1f}",         size="xs", fw=700, c="#00E676"),
                        dmc.Text(f" + {_bqual:.1f}",        size="xs", fw=700, c="#26C6DA"),
                        dmc.Text("  =  ",                   size="xs", c=DIM),
                        dmc.Text(f"{round(health,1)} / 100", size="sm", fw=800, c=bar_color),
                    ],
                    gap=2, wrap="wrap",
                ),
                dmc.Text(
                    "Below 60 = regulatory concern  |  60-79 = acceptable posture  |  80+ = strong programme",
                    size="9px", c="dimmed", mt=4, fs="italic",
                ),
            ],
            p="sm", radius="md",
            style={"backgroundColor": "rgba(0,0,0,0.35)", "border": "1px solid rgba(0,212,255,0.15)", "marginTop": "8px"},
        )

    # ── TREND LINE ────────────────────────────────────────────────────────────
    trend_note = html.Span()
    run_hist = _get_run_tier_history(limit=20)
    if len(run_hist) < 2:
        trend_fig = empty_fig("Run pipeline at least twice to see the risk escalation trend.")
        trend_note = fallback_note(
            "Trend requires ≥ 2 successful pipeline runs. Pipeline history accumulates automatically.",
            accent="#FFD600",
        )
    else:
        labels_ = [r["label"] for r in run_hist]
        p1_series = [r["p1"] for r in run_hist]
        p2_series = [r["p2"] for r in run_hist]

        # Try to get avg_risk from scored_df per run if not in metadata
        # For now compute p1+p2 total
        total_flags = [r["p1"] + r["p2"] for r in run_hist]

        trend_fig = go.Figure()
        trend_fig.add_trace(go.Scatter(
            x=labels_, y=p1_series,
            name="P1 Critical Customers",
            mode="lines+markers",
            line=dict(color=TIER_COLORS["P1"], width=2),
            marker=dict(size=7, color=TIER_COLORS["P1"]),
            yaxis="y",
            hovertemplate="<b>%{x}</b><br>P1 Critical: %{y} customers<extra></extra>",
        ))
        trend_fig.add_trace(go.Scatter(
            x=labels_, y=p2_series,
            name="P2 High Risk Customers",
            mode="lines+markers",
            line=dict(color=TIER_COLORS["P2"], width=2, dash="dot"),
            marker=dict(size=7, color=TIER_COLORS["P2"]),
            yaxis="y",
            hovertemplate="<b>%{x}</b><br>P2 High Risk: %{y} customers<extra></extra>",
        ))
        trend_fig.add_trace(go.Scatter(
            x=labels_, y=[r["customers"] for r in run_hist],
            name="Total Customers Screened",
            mode="lines",
            line=dict(color="#26C6DA", width=1.5, dash="longdash"),
            yaxis="y2",
            hovertemplate="<b>%{x}</b><br>Total screened: %{y:,}<extra></extra>",
        ))
        styled_layout(trend_fig, height=340)
        trend_fig.update_layout(
            yaxis=dict(title="Flagged Customers", gridcolor=CHART_GRID, side="left"),
            yaxis2=dict(title="Total Screened", overlaying="y", side="right", showgrid=False),
            legend=dict(orientation="h", yanchor="bottom", y=1.02, x=0),
        )

    # ── HEATMAP ───────────────────────────────────────────────────────────────
    heatmap_note = html.Span()
    node_df = _tbl(tables, "node", "nodes")
    # Prefer the dimension chosen in the SegmentedControl filter.
    # Fall back through all available type columns if the selected one is missing.
    _type_priority = ["node_type", "node_type1", "node_type3",
                      "customer_type", "type", "segment", "customer_segment"]
    if type_col and node_df is not None and type_col in node_df.columns:
        seg_col = type_col
    elif node_df is not None:
        seg_col = next((c for c in _type_priority if c in node_df.columns), None)
    else:
        seg_col = None

    if no_pipe or seg_col is None:
        heatmap_fig = empty_fig("No customer type data found. Ensure node table has node_type / node_type1 / node_type3 columns.")
        if not no_pipe:
            heatmap_note = fallback_note("No customer type column found. Node table should contain node_type, node_type1, or node_type3.")
    else:
        # Merge scored_df with node table on node_id
        try:
            id_col = "node_id" if "node_id" in node_df.columns else node_df.columns[0]
            # Ensure consistent string IDs on both sides to avoid int/str type mismatch
            scored_s = scored.copy()
            scored_s["node_id"] = scored_s["node_id"].astype(str)
            node_ref = node_df[[id_col, seg_col]].copy()
            node_ref[id_col] = node_ref[id_col].astype(str)
            merged = scored_s.merge(
                node_ref.rename(columns={id_col: "node_id"}),
                on="node_id",
                how="left",
            )
            merged[seg_col] = merged[seg_col].fillna("Unknown")
            merged["tier"] = merged["tier"].fillna("P4")
            pivot = (
                merged.groupby([seg_col, "tier"])
                .size()
                .unstack(fill_value=0)
                .reindex(columns=["P1", "P2", "P3", "P4"], fill_value=0)
            )
            z      = pivot.values
            x_labs = ["P1 Critical", "P2 High Risk", "P3 Medium Risk", "P4 Low Risk"]
            y_labs = list(pivot.index)
            heatmap_fig = go.Figure()
            _tier_order  = ["P1", "P2", "P3", "P4"]
            _tier_names  = ["P1 Critical", "P2 High Risk", "P3 Medium Risk", "P4 Low Risk"]
            _tier_clrs   = [TIER_COLORS["P1"], TIER_COLORS["P2"], TIER_COLORS["P3"], TIER_COLORS["P4"]]
            for _col, _lbl, _clr in zip(_tier_order, _tier_names, _tier_clrs):
                _col_idx = _tier_order.index(_col)
                _vals = z[:, _col_idx]
                heatmap_fig.add_trace(go.Bar(
                    name=_lbl,
                    x=y_labs,
                    y=_vals,
                    marker_color=_clr,
                    text=[str(int(v)) if v > 0 else "" for v in _vals],
                    textposition="auto",
                    textfont=dict(color="white", size=10),
                    hovertemplate=f"<b>%{{x}}</b><br>{_lbl}: <b>%{{y}}</b> customers<extra></extra>",
                ))
            heatmap_fig.update_layout(barmode="group")
            styled_layout(heatmap_fig, height=380, legend=True)
            heatmap_fig.update_layout(
                xaxis_title="Customer Segment",
                yaxis_title="Customer Count",
                legend=dict(orientation="h", y=-0.18, x=0.5, xanchor="center",
                            font=dict(color=CHART_TEXT, size=11)),
                margin=dict(l=50, r=20, t=20, b=100),
            )
        except Exception as e:
            heatmap_fig = empty_fig(f"Could not build segment heatmap: {e}")

    # ── DOLLAR EXPOSURE ───────────────────────────────────────────────────────
    expo_note = html.Span()
    edge_df = _tbl(tables, "edge", "edges")
    has_amount = False

    if not no_pipe and edge_df is not None:
        amt_col = next((c for c in ["amount", "value", "transaction_amount", "amt"] if c in edge_df.columns), None)
        if amt_col:
            has_amount = True
            # Aggregate total flow per node (as sender)
            from_col = next((c for c in ["from_node", "source", "from_id", "from"] if c in edge_df.columns), None)
            to_col   = next((c for c in ["to_node",   "target", "to_id",   "to"]   if c in edge_df.columns), None)
            if from_col and to_col:
                # Sum amount per node
                sent = edge_df.groupby(from_col)[amt_col].sum().reset_index()
                recd = edge_df.groupby(to_col)[amt_col].sum().reset_index()
                sent.columns = ["node_id", "amount_sent"]
                recd.columns = ["node_id", "amount_recd"]
                flow_df = sent.merge(recd, on="node_id", how="outer").fillna(0)
                flow_df["total_flow"] = flow_df["amount_sent"] + flow_df["amount_recd"]
                # safe column selection — only pick columns that actually exist
                _score_col = next((c for c in ["risk_score", "score"] if c in scored.columns), None)
                _keep = [c for c in ["node_id", "tier", _score_col] if c and c in scored.columns]
                merged_flow = scored[_keep].merge(flow_df, on="node_id", how="left").fillna(0)
                if _score_col and _score_col != "risk_score" and _score_col in merged_flow.columns:
                    merged_flow = merged_flow.rename(columns={_score_col: "risk_score"})
                if "risk_score" not in merged_flow.columns:
                    merged_flow["risk_score"] = 0
            else:
                has_amount = False

    if not has_amount:
        expo_note = fallback_note(
            "Edge table with 'amount' column not found. Showing customer counts instead of dollar values. "
            "Upload an edge table with an 'amount' column to unlock dollar exposure charts.",
        )

    def _expo_kpi(tier, label, icon, color_str, color_dash):
        if has_amount and not no_pipe:
            t_df = merged_flow[merged_flow["tier"] == tier]
            total_usd = t_df["total_flow"].sum()
            cnt = len(t_df)
            val = _fmt_money(total_usd)
            sub = f"{cnt:,} customers"
        elif not no_pipe:
            tc2 = scored["tier"].value_counts().to_dict() if "tier" in scored.columns else {}
            cnt = tc2.get(tier, 0)
            val = f"{cnt:,} customers"
            sub = "$ amount unavailable"
        else:
            val, sub, cnt = "—", "No data", 0
        return dmc.Stack([
            dmc.Group([
                dmc.ThemeIcon(DashIconify(icon=icon, width=20), size="lg", radius="md", variant="light", color=color_dash),
                dmc.Text(label, fw=700, c="white", size="sm"),
            ], gap="xs"),
            dmc.Text(val, size="2rem" if len(val) < 8 else "xl", fw=800, c=color_str, mt=4),
            dmc.Text(sub, size="xs", c=DIM),
        ], gap=4)

    expo_p1 = _expo_kpi("P1", "P1 Critical Exposure",   "mdi:alert-octagon", TIER_COLORS["P1"], "red")
    expo_p2 = _expo_kpi("P2", "P2 High Risk Exposure",  "mdi:alert",         TIER_COLORS["P2"], "orange")
    if has_amount and not no_pipe:
        flagged_total = merged_flow[merged_flow["tier"].isin(["P1", "P2"])]["total_flow"].sum()
        expo_tot_val = _fmt_money(flagged_total)
        expo_tot_sub = "Combined P1 + P2 suspicious flow"
    elif not no_pipe:
        tc2 = scored["tier"].value_counts().to_dict() if "tier" in scored.columns else {}
        flagged_total = tc2.get("P1", 0) + tc2.get("P2", 0)
        expo_tot_val = f"{flagged_total:,}"
        expo_tot_sub = "P1 + P2 customers ($ amount unavailable)"
    else:
        expo_tot_val, expo_tot_sub = "—", "No data"
    expo_total = dmc.Stack([
        dmc.Group([
            dmc.ThemeIcon(DashIconify(icon="mdi:currency-usd", width=20), size="lg", radius="md", variant="light", color="yellow"),
            dmc.Text("Total Suspicious Exposure", fw=700, c="white", size="sm"),
        ], gap="xs"),
        dmc.Text(expo_tot_val, size="2rem" if len(expo_tot_val) < 8 else "xl", fw=800, c="#FFD600", mt=4),
        dmc.Text(expo_tot_sub, size="xs", c=DIM),
    ], gap=4)

    # ── EXPOSURE BAR ──────────────────────────────────────────────────────────
    if no_pipe:
        expo_bar = empty_fig()
    else:
        tier_order = ["P1", "P2", "P3", "P4"]
        if has_amount:
            y_data = [merged_flow[merged_flow["tier"] == t]["total_flow"].sum() for t in tier_order]
            y_title = "Transaction Flow ($)"
            hover_t = "<b>%{x}</b><br>Flow: $%{y:,.0f}<extra></extra>"
        else:
            tc2 = scored["tier"].value_counts().to_dict() if "tier" in scored.columns else {}
            y_data = [tc2.get(t, 0) for t in tier_order]
            y_title = "Customer Count"
            hover_t = "<b>%{x}</b><br>Customers: %{y:,}<extra></extra>"
        expo_bar = go.Figure(go.Bar(
            x=[TIER_LABELS[t] for t in tier_order],
            y=y_data,
            marker_color=[TIER_COLORS[t] for t in tier_order],
            hovertemplate=hover_t,
        ))
        styled_layout(expo_bar, height=300, legend=False)
        expo_bar.update_layout(yaxis_title=y_title, xaxis_title="Risk Tier")

    # ── SCATTER ───────────────────────────────────────────────────────────────
    if no_pipe:
        scatter_fig = empty_fig()
    elif not has_amount:
        scatter_fig = empty_fig("Upload edge table with 'amount' column to enable Risk vs Volume scatter.")
    else:
        scatter_data = merged_flow.copy()
        scatter_data["tier_label"] = scatter_data["tier"].map(TIER_LABELS)
        scatter_fig = go.Figure()
        for t in ["P4", "P3", "P2", "P1"]:
            sub_ = scatter_data[scatter_data["tier"] == t]
            scatter_fig.add_trace(go.Scatter(
                x=sub_["total_flow"],
                y=sub_["risk_score"],
                mode="markers",
                name=TIER_LABELS.get(t, t),
                marker=dict(
                    size=8, opacity=0.75,
                    color=TIER_COLORS.get(t, "#8899AA"),
                    line=dict(width=0.5, color="rgba(0,0,0,0.3)"),
                ),
                hovertemplate=(
                    "<b>ID:</b> %{customdata[0]}<br>"
                    "<b>Tier:</b> " + t + "<br>"
                    "<b>Risk Score:</b> %{y:.1f}<br>"
                    "<b>Total Flow:</b> $%{x:,.0f}<extra></extra>"
                ),
                customdata=sub_[["node_id"]].values,
            ))
        styled_layout(scatter_fig, height=300)
        scatter_fig.update_layout(
            xaxis_title="Total Transaction Volume ($)",
            yaxis_title="Risk Score (0–100)",
        )

    # ── FLAGS PER RUN BAR ─────────────────────────────────────────────────────
    flags_note = html.Span()
    if len(run_hist) < 1:
        flags_bar = empty_fig("Run pipeline to see flag history.")
        flags_note = fallback_note("No run history available yet.")
    else:
        labels_ = [r["label"] for r in run_hist]
        flags_bar = go.Figure()
        flags_bar.add_trace(go.Bar(
            x=labels_, y=[r["p1"] for r in run_hist],
            name="P1 Critical", marker_color=TIER_COLORS["P1"],
            hovertemplate="Run: <b>%{x}</b><br>P1 Customers: %{y}<extra></extra>",
        ))
        flags_bar.add_trace(go.Bar(
            x=labels_, y=[r["p2"] for r in run_hist],
            name="P2 High Risk", marker_color=TIER_COLORS["P2"],
            hovertemplate="Run: <b>%{x}</b><br>P2 Customers: %{y}<extra></extra>",
        ))
        flags_bar.update_layout(barmode="group")
        styled_layout(flags_bar, height=300)

    return (
        kpis, donut_fig, gauge_fig, health_formula,
        trend_fig, trend_note,
        heatmap_fig, heatmap_note,
        expo_p1, expo_p2, expo_total,
        expo_bar, expo_note,
        scatter_fig,
        flags_bar, flags_note,
    )
