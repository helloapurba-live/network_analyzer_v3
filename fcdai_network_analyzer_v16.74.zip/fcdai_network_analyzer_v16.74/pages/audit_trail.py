"""
Page: Audit Trail (v10 — A4)
==================================
Business Logic: Display immutable pipeline audit trail with severity
filtering, search, and export. Shows all actions taken by the system
with PII-masked details and SHA-256 integrity hashes.
"""

import dash
from dash import html, dcc, callback, Input, Output, State, no_update
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.graph_objects as go
import pandas as pd
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, APP

dash.register_page(
    __name__, path="/audit-trail", name="Audit Trail", title=f"FCDAI v{APP.VERSION} | Audit Trail"
)

SEVERITY_COLORS = {
    "info": "#00D4FF",
    "warning": "#FFD600",
    "error": "#FF1744",
    "critical": "#FF1744",
}
SEVERITY_ICONS = {
    "info": "mdi:information",
    "warning": "mdi:alert",
    "error": "mdi:alert-octagon",
    "critical": "mdi:skull",
}

layout = dmc.Box(
    [
        dcc.Interval(id="audit-refresh", interval=5000, n_intervals=0),
        dmc.Group(
            [
                dmc.Stack(
                    [
                        dmc.Title("Audit Trail", order=2, c="white"),
                        dmc.Text(
                            f"Immutable Pipeline Audit Log with SHA-256 Integrity — v{APP.VERSION}",
                            c="dimmed",
                            size="sm",
                        ),
                    ],
                    gap=2,
                ),
                dmc.Badge(f"v{APP.VERSION}", color="cyan", variant="filled", size="lg"),
            ],
            justify="space-between",
            mb="lg",
        ),
        # CEO Business Context Panel
        dmc.Paper(
            [
                dmc.Group(
                    [
                        DashIconify(icon="mdi:information-outline", width=18, color="#FFD600"),
                        dmc.Text("What This Page Shows", fw=700, size="sm", c="#FFD600"),
                    ],
                    gap="xs",
                    mb="sm",
                ),
                dmc.SimpleGrid(
                    cols={"base": 1, "md": 3},
                    spacing="sm",
                    children=[
                        dmc.Box(
                            [
                                dmc.Text("Overview", size="xs", fw=700, c="#00D4FF", mb=4),
                                dmc.Text(
                                    "A tamper-evident, chronological record of every action the AML system has taken — "
                                    "which analysis ran, when, on what data, and the SHA-256 cryptographic hash proving "
                                    "the record has not been altered. This is your system's compliance diary.",
                                    size="xs",
                                    c="dimmed",
                                    style={"lineHeight": "1.5"},
                                ),
                            ],
                            style={
                                "background": "rgba(0,212,255,0.05)",
                                "border": "1px solid rgba(0,212,255,0.12)",
                                "borderRadius": "8px",
                                "padding": "10px",
                            },
                        ),
                        dmc.Box(
                            [
                                dmc.Text("Why It Matters", size="xs", fw=700, c="#FFD600", mb=4),
                                dmc.Text(
                                    "Every regulatory framework (FATF, FinCEN, FCA) requires a complete audit trail. "
                                    "During examinations, regulators will ask: 'Prove you ran AML checks on date X.' "
                                    "This page provides that proof with cryptographic integrity verification, "
                                    "making it impossible to forge or backdate records.",
                                    size="xs",
                                    c="dimmed",
                                    style={"lineHeight": "1.5"},
                                ),
                            ],
                            style={
                                "background": "rgba(255,214,0,0.05)",
                                "border": "1px solid rgba(255,214,0,0.12)",
                                "borderRadius": "8px",
                                "padding": "10px",
                            },
                        ),
                        dmc.Box(
                            [
                                dmc.Text("When to Act", size="xs", fw=700, c="#FF6B6B", mb=4),
                                dmc.Text(
                                    "Before any regulatory examination: export the full audit trail as evidence. "
                                    "If you see 'error' or 'critical' severity entries: investigate immediately — "
                                    "these indicate pipeline failures that may have left gaps in your AML coverage. "
                                    "Maintain records for the regulatory retention period (typically 5-7 years).",
                                    size="xs",
                                    c="dimmed",
                                    style={"lineHeight": "1.5"},
                                ),
                            ],
                            style={
                                "background": "rgba(255,107,107,0.05)",
                                "border": "1px solid rgba(255,107,107,0.12)",
                                "borderRadius": "8px",
                                "padding": "10px",
                            },
                        ),
                    ],
                ),
            ],
            p="md",
            radius="lg",
            className="glass-card",
            mb="md",
            style={"borderLeft": "3px solid #FFD600"},
        ),
        # Controls
        dmc.Paper(
            [
                dmc.Group(
                    [
                        DashIconify(icon="mdi:shield-lock", width=22, color=THEME.PRIMARY),
                        dmc.Text("Audit Controls", fw=600, c="white"),
                    ],
                    gap="sm",
                    mb="md",
                ),
                dmc.SimpleGrid(
                    cols={"base": 1, "md": 4},
                    spacing="md",
                    children=[
                        dmc.Select(
                            id="audit-severity",
                            label="Severity",
                            data=[
                                {"value": "all", "label": "All Levels"},
                                {"value": "info", "label": "Info"},
                                {"value": "warning", "label": "Warning"},
                                {"value": "error", "label": "Error"},
                                {"value": "critical", "label": "Critical"},
                            ],
                            value="all",
                            styles={
                                "input": {
                                    "backgroundColor": THEME.DARK_BG,
                                    "color": "white",
                                    "border": f"1px solid {THEME.DARK_BORDER}",
                                }
                            },
                        ),
                        dmc.NumberInput(
                            id="audit-limit",
                            label="Max Entries",
                            value=200,
                            min=10,
                            max=1000,
                            step=50,
                            styles={
                                "input": {
                                    "backgroundColor": THEME.DARK_BG,
                                    "color": "white",
                                    "border": f"1px solid {THEME.DARK_BORDER}",
                                }
                            },
                        ),
                        dmc.TextInput(
                            id="audit-search",
                            label="Search",
                            placeholder="Filter by action or details...",
                            leftSection=DashIconify(icon="mdi:magnify", width=16),
                            styles={
                                "input": {
                                    "backgroundColor": THEME.DARK_BG,
                                    "color": "white",
                                    "border": f"1px solid {THEME.DARK_BORDER}",
                                }
                            },
                        ),
                        dmc.Stack(
                            [
                                dmc.Text(" ", size="xs"),
                                dmc.Button(
                                    "Export CSV",
                                    id="audit-export-btn",
                                    variant="outline",
                                    color="cyan",
                                    leftSection=DashIconify(icon="mdi:download", width=18),
                                ),
                            ],
                            gap="xs",
                            justify="flex-end",
                        ),
                    ],
                ),
            ],
            p="lg",
            radius="lg",
            className="glass-card",
            mb="md",
        ),
        # Summary
        html.Div(id="audit-summary"),
        html.Div(id="audit-timeline"),
        dcc.Download(id="audit-csv-download"),
    ]
)


@callback(
    [Output("audit-summary", "children"), Output("audit-timeline", "children")],
    [
        Input("audit-refresh", "n_intervals"),
        Input("audit-severity", "value"),
        Input("audit-search", "value"),
        Input("pipeline-state", "data"),  # v15.20: react instantly to pipeline completion
        Input("global-refresh-ts", "data"),
    ],  # v15.20: react to Global Refresh button
    State("audit-limit", "value"),
)
def display_audit(_, severity, search_text, _pipeline_state, _refresh_ts, limit):
    from engine import get_pipeline

    pipeline = get_pipeline()
    entries = pipeline.get_audit_trail(limit=limit or 200)

    if not entries:
        return (
            dmc.Alert(
                "No audit entries yet. Run the pipeline to generate audit records.",
                color="blue",
                icon=DashIconify(icon="mdi:information"),
            ),
            html.Div(),
        )

    df = pd.DataFrame(entries)

    # Filter by severity
    if severity and severity != "all":
        df = df[df["severity"] == severity]

    # Filter by search
    if search_text:
        mask = df["action"].str.contains(search_text, case=False, na=False) | df[
            "details"
        ].str.contains(search_text, case=False, na=False)
        df = df[mask]

    total = len(df)
    sev_counts = df["severity"].value_counts().to_dict() if total > 0 else {}

    # Summary cards
    summary_cards = dmc.SimpleGrid(
        cols={"base": 2, "md": 5},
        spacing="md",
        mb="md",
        children=[
            _stat_card("Total Entries", str(total), "mdi:format-list-numbered", THEME.PRIMARY),
            _stat_card("Info", str(sev_counts.get("info", 0)), "mdi:information", "#00D4FF"),
            _stat_card("Warning", str(sev_counts.get("warning", 0)), "mdi:alert", "#FFD600"),
            _stat_card("Error", str(sev_counts.get("error", 0)), "mdi:alert-octagon", "#FF1744"),
            _stat_card("Critical", str(sev_counts.get("critical", 0)), "mdi:skull", "#FF1744"),
        ],
    )

    if total == 0:
        return summary_cards, dmc.Alert("No entries match filters", color="yellow")

    # Severity distribution chart
    sev_fig = go.Figure(
        go.Pie(
            labels=list(sev_counts.keys()),
            values=list(sev_counts.values()),
            marker_colors=[SEVERITY_COLORS.get(s, "gray") for s in sev_counts.keys()],
            hole=0.6,
            textinfo="label+value",
        )
    )
    sev_fig.update_layout(
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(t=10, b=10, l=20, r=20),
        height=250,
        showlegend=False,
    )

    # Timeline of entries
    timeline_items = []
    for _, row in df.head(100).iterrows():
        sev = row.get("severity", "info")
        color = SEVERITY_COLORS.get(sev, "gray")
        icon = SEVERITY_ICONS.get(sev, "mdi:information")
        ts = str(row.get("timestamp", ""))[:19]
        action = str(row.get("action", ""))
        details = str(row.get("details", ""))
        integrity = str(row.get("integrity_hash", ""))[:16] + "..."

        timeline_items.append(
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            DashIconify(icon=icon, width=20, color=color),
                            dmc.Text(action, fw=600, c="white", size="sm"),
                            dmc.Badge(sev.upper(), color=color, size="xs", variant="light"),
                            dmc.Text(ts, c="dimmed", size="xs", ml="auto"),
                        ],
                        gap="sm",
                    ),
                    dmc.Text(details, c="dimmed", size="xs", mt=4),
                    dmc.Code(
                        f"SHA-256: {integrity}",
                        style={
                            "fontSize": "10px",
                            "color": "#666",
                            "backgroundColor": "transparent",
                        },
                    ),
                ],
                p="sm",
                radius="md",
                className="glass-card",
                style={"borderLeft": f"3px solid {color}", "marginBottom": "4px"},
            ),
        )

    timeline = dmc.Stack(
        [
            dmc.SimpleGrid(
                cols={"base": 1, "md": 2},
                spacing="md",
                children=[
                    dmc.Paper(
                        [
                            dmc.Text("Severity Distribution", fw=600, c="white", mb="sm"),
                            dcc.Graph(figure=sev_fig, config={"displayModeBar": False}),
                        ],
                        p="lg",
                        radius="lg",
                        className="glass-card",
                    ),
                    dmc.Paper(
                        [
                            dmc.Text("Audit Integrity", fw=600, c="white", mb="sm"),
                            dmc.Text(f"Total logged: {total}", c="dimmed", size="sm"),
                            dmc.Text(
                                "Each entry is SHA-256 hashed with chained integrity.",
                                c="dimmed",
                                size="xs",
                            ),
                            dmc.Text(
                                "PII data is masked in all log entries.", c="dimmed", size="xs"
                            ),
                            dmc.Space(h="md"),
                            dmc.Badge("IMMUTABLE", color="green", variant="filled", size="lg"),
                            dmc.Badge(
                                "PII-MASKED", color="cyan", variant="filled", size="lg", ml="sm"
                            ),
                            dmc.Badge(
                                "AIR-GAPPED", color="indigo", variant="filled", size="lg", ml="sm"
                            ),
                        ],
                        p="lg",
                        radius="lg",
                        className="glass-card",
                    ),
                ],
            ),
            dmc.Text(
                f"Recent Entries (showing {min(100, total)} of {total})", fw=600, c="white", mt="md"
            ),
            dmc.Stack(timeline_items, gap=4),
        ],
        gap="md",
    )

    return summary_cards, timeline


@callback(
    Output("audit-csv-download", "data"),
    Input("audit-export-btn", "n_clicks"),
    prevent_initial_call=True,
)
def export_audit(_):
    from engine import get_pipeline
    from utils.pii_guard import mask_for_export

    pipeline = get_pipeline()
    entries = pipeline.get_audit_trail(limit=1000)
    if not entries:
        return no_update
    df = pd.DataFrame(entries)
    df = mask_for_export(df)
    return dcc.send_data_frame(df.to_csv, "audit_trail_export.csv", index=False)


def _stat_card(label, value, icon, color):
    return dmc.Paper(
        [
            dmc.Group(
                [
                    DashIconify(icon=icon, width=24, color=color),
                    dmc.Stack(
                        [
                            dmc.Text(value, fw=700, c="white", size="xl"),
                            dmc.Text(label, c="dimmed", size="xs"),
                        ],
                        gap=0,
                    ),
                ],
                gap="sm",
            ),
        ],
        p="md",
        radius="lg",
        className="glass-card",
    )
