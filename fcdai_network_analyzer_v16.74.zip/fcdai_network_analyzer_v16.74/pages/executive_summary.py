"""
FCDAI v12.48 — Executive Summary & Findings
=============================================
Financial Crime Detection Report

TEMPLATE-DRIVEN ARCHITECTURE:
  The full report structure is ALWAYS visible (15 sections).
  After each pipeline run, every chart, table, and KPI auto-populates.
  If the pipeline has not been run, clear "Pending" messages appear.

BUSINESS-DOMAIN LANGUAGE:
  Written for senior executives, board members, and compliance officers
  who need to understand risk exposure without technical jargon.
  No references to specific regulatory filing codes.

ROBUSTNESS:
  Each section is built independently with its own error handling.
  If one section fails, all other sections still render correctly.

Sections:
  1. Analysis Scope KPIs
  2. Risk Portfolio Overview
  3. Risk Distribution Charts (Donut + Bar + Histogram)
  4. Key Findings & Alerts
  5. Top 10 Highest-Risk Customers
  6. Financial Exposure Summary
  7. Circular Money-Movement Rings
  8. Network Structure Analysis
  9. Detection Methods Coverage (10 families)
  10. Investigation Priority Queue
  11. Operations & Data Quality
  12. Recommendations & Next Steps
"""

import dash
from dash import html, dcc, callback, clientside_callback, Input, Output, State, no_update
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.graph_objects as go
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime
from collections import Counter
import sys, traceback, logging

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, APP
from engine import get_pipeline

log = logging.getLogger("exec_summary")

dash.register_page(
    __name__,
    path="/executive-summary",
    name="Executive Summary",
    title=f"FCDAI v{APP.VERSION} | Executive Summary & Findings",
)

# =============================================================================
# CONSTANTS
# =============================================================================
TIER_COLORS = {"P1": "#FF1744", "P2": "#FF9800", "P3": "#FFD600", "P4": "#00E676"}
TIER_LABELS = {
    "P1": "CRITICAL — Immediate Action Required",
    "P2": "HIGH RISK — Enhanced Monitoring",
    "P3": "MEDIUM — Active Watch List",
    "P4": "LOW — Normal Operations",
}
TIER_DESCRIPTIONS = {
    "P1": (
        "These customers display the highest-probability indicators of "
        "financial crime. Immediate formal investigation should be "
        "initiated per regulatory requirements."
    ),
    "P2": (
        "Significant suspicious patterns detected. Enhanced review "
        "must be applied and a compliance reporting decision should "
        "be made promptly."
    ),
    "P3": (
        "Some unusual activity warrants continued attention. Customers "
        "remain on the active watch list with automated monitoring "
        "triggers in place."
    ),
    "P4": ("Standard transaction monitoring applies. No immediate " "compliance action required."),
}

FAMILY_BUSINESS_NAMES = {
    "centrality": (
        "Relationship Influence Analysis",
        "Identifies customers who sit at the centre of the transaction "
        "network — controlling the most connections and fund flows.",
        "mdi:star-four-points",
    ),
    "community": (
        "Cluster & Group Detection",
        "Discovers tightly-connected groups of customers who transact "
        "predominantly among themselves — a hallmark of layering and "
        "round-tripping schemes.",
        "mdi:account-group",
    ),
    "pathflow": (
        "Money-Trail Traceability",
        "Traces the path of funds through intermediaries from origin "
        "to destination, revealing multi-hop laundering chains.",
        "mdi:transit-connection-variant",
    ),
    "link_prediction": (
        "Hidden Relationship Prediction",
        "Uses predictive modelling to uncover relationships that are "
        "likely to form — flagging customers who may be collaborating "
        "covertly.",
        "mdi:link-variant",
    ),
    "anomaly": (
        "Behavioural Anomaly Detection",
        "Detects customers whose transaction patterns deviate "
        "significantly from their peer group, highlighting potential "
        "structuring or unusual activity.",
        "mdi:alert-decagram",
    ),
    "temporal": (
        "Transaction Velocity Analysis",
        "Measures the speed and frequency of transactions over time "
        "to detect sudden spikes indicating rapid fund movement.",
        "mdi:clock-fast",
    ),
    "multi_layer": (
        "Multi-Layer Risk Aggregation",
        "Combines risk signals across all layers (network, behavioural, "
        "temporal) into a unified composite score per customer.",
        "mdi:layers-triple",
    ),
    "bridge": (
        "Bridge Node Detection",
        "Identifies customers who connect otherwise separate parts of "
        "the network, acting as potential gatekeepers between groups.",
        "mdi:bridge",
    ),
    "risk_propagation": (
        "Risk Contagion Analysis",
        "Models how risk spreads through the network — if one customer "
        "is compromised, shows who else is likely affected.",
        "mdi:virus-outline",
    ),
    "motif": (
        "Transaction Pattern Matching",
        "Searches for known laundering patterns (fan-out, fan-in, "
        "cycles) across the transaction graph.",
        "mdi:shape-outline",
    ),
    "structuring": (
        "Structuring Detection",
        "Identifies customers splitting transactions to avoid reporting "
        "thresholds — a key indicator of intentional evasion.",
        "mdi:format-list-numbered",
    ),
    "benfords": (
        "Benford's Law Analysis",
        "Applies statistical digit analysis to transaction amounts to "
        "detect fabricated or manipulated financial data.",
        "mdi:chart-bell-curve-cumulative",
    ),
    "motifs": (
        "Transaction Motif Detection",
        "Detects recurring sub-graph patterns (fan-out, fan-in, chains) "
        "that characterise organised financial crime.",
        "mdi:shape-outline",
    ),
}

_GLASS = {
    "background": "rgba(17, 24, 39, 0.7)",
    "backdropFilter": "blur(20px)",
    "border": f"1px solid {THEME.GLASS_BORDER}",
    "borderRadius": "14px",
    "padding": "1.5rem",
}
_GOLD_ACCENT = "linear-gradient(135deg, #FFD700, #FFA000)"
_GOLD_BORDER = "1px solid rgba(255,215,0,0.35)"

DARK_CHART = dict(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(0,0,0,0)",
    font=dict(color="#94A3B8", size=11),
    margin=dict(l=50, r=20, t=30, b=40),
    xaxis=dict(gridcolor="rgba(255,255,255,0.05)", zerolinecolor="rgba(255,255,255,0.08)"),
    yaxis=dict(gridcolor="rgba(255,255,255,0.05)", zerolinecolor="rgba(255,255,255,0.08)"),
    legend=dict(font=dict(color="#94A3B8", size=10)),
)

_TH = {
    "backgroundColor": "#111827",
    "color": "#94A3B8",
    "fontWeight": "700",
    "border": "1px solid #1E293B",
    "padding": "10px 12px",
    "fontSize": "0.75rem",
    "textTransform": "uppercase",
    "letterSpacing": "0.5px",
}


# =============================================================================
# HELPER COMPONENTS
# =============================================================================
def _kpi(icon, label, value, color="#00D4FF", subtitle=""):
    """Large KPI metric card for board presentation."""
    return html.Div(
        [
            html.Div(
                [
                    DashIconify(icon=icon, width=28, color=color),
                    html.Div(
                        [
                            html.Div(
                                str(value),
                                style={
                                    "fontSize": "1.8rem",
                                    "fontWeight": "800",
                                    "color": color,
                                    "lineHeight": "1.1",
                                    "letterSpacing": "-0.5px",
                                },
                            ),
                            html.Div(
                                label,
                                style={
                                    "fontSize": "0.72rem",
                                    "color": "#94A3B8",
                                    "fontWeight": "600",
                                    "textTransform": "uppercase",
                                    "letterSpacing": "1px",
                                    "marginTop": "2px",
                                },
                            ),
                        ]
                    ),
                ],
                style={"display": "flex", "alignItems": "center", "gap": "0.8rem"},
            ),
            (
                html.Div(
                    subtitle,
                    style={
                        "fontSize": "0.7rem",
                        "color": "#64748B",
                        "marginTop": "0.5rem",
                        "lineHeight": "1.4",
                    },
                )
                if subtitle
                else None
            ),
        ],
        style={
            **_GLASS,
            "padding": "1.2rem 1.4rem",
            "minWidth": "180px",
            "borderTop": f"3px solid {color}",
        },
    )


def _section(icon, title, subtitle, color="#00D4FF"):
    """Section header with icon and explanatory subtitle."""
    return html.Div(
        [
            html.Div(
                [
                    DashIconify(icon=icon, width=26, color=color),
                    html.H2(
                        title,
                        style={
                            "margin": 0,
                            "fontSize": "1.15rem",
                            "fontWeight": "700",
                            "color": "#E2E8F0",
                        },
                    ),
                ],
                style={"display": "flex", "alignItems": "center", "gap": "0.7rem"},
            ),
            html.P(
                subtitle,
                style={
                    "margin": "0.3rem 0 0 2.25rem",
                    "color": "#94A3B8",
                    "fontSize": "0.78rem",
                    "lineHeight": "1.5",
                },
            ),
        ],
        style={"marginBottom": "1.2rem"},
    )


def _info(text, accent="#2196F3"):
    """Blue info box explaining what a section means to non-technical readers."""
    r, g, b = int(accent[1:3], 16), int(accent[3:5], 16), int(accent[5:7], 16)
    return html.Div(
        [
            DashIconify(icon="mdi:information-outline", width=16, color=accent),
            html.Span(
                text,
                style={
                    "color": "rgba(255,255,255,0.72)",
                    "fontSize": "0.75rem",
                    "lineHeight": "1.5",
                },
            ),
        ],
        style={
            "display": "flex",
            "gap": "0.5rem",
            "alignItems": "flex-start",
            "background": f"rgba({r},{g},{b},0.06)",
            "border": f"1px solid {accent}33",
            "borderRadius": "8px",
            "padding": "0.65rem 0.85rem",
            "marginBottom": "0.8rem",
        },
    )


def _finding(icon, text, color="#FF9800"):
    """Single finding bullet."""
    return html.Div(
        [
            DashIconify(icon=icon, width=18, color=color),
            html.Span(
                text, style={"color": "#E2E8F0", "fontSize": "0.82rem", "lineHeight": "1.55"}
            ),
        ],
        style={
            "display": "flex",
            "gap": "0.6rem",
            "alignItems": "flex-start",
            "marginBottom": "0.6rem",
        },
    )


def _stat(label, value, color="#E2E8F0"):
    """Compact inline stat."""
    return html.Span(
        [
            html.Span(f"{label}: ", style={"color": "#64748B", "fontSize": "0.75rem"}),
            html.Span(
                str(value), style={"color": color, "fontWeight": "700", "fontSize": "0.82rem"}
            ),
        ],
        style={"marginRight": "1.2rem"},
    )


def _pending(msg="Run the pipeline from the Dashboard to populate this section."):
    """Placeholder shown when pipeline data is not yet available."""
    return html.Div(
        dmc.Center(
            dmc.Stack(
                [
                    DashIconify(icon="mdi:timer-sand", width=32, color="#475569"),
                    dmc.Text(msg, c="dimmed", size="sm", ta="center"),
                ],
                align="center",
                gap="xs",
            ),
            style={"minHeight": "80px"},
        ),
        style={**_GLASS, "opacity": "0.8"},
    )


def _safe(fn, default=None):
    """Safely call fn, returning default on any exception."""
    try:
        return fn()
    except Exception:
        return default


# =============================================================================
# PAGE LAYOUT — FULL TEMPLATE (always visible)
# =============================================================================
layout = dmc.Box(
    [
        # Continuous auto-refresh — polls to pick up new pipeline data
        dcc.Interval(id="exec-init", interval=4000, max_intervals=-1),
        # ── CONFIDENTIAL BANNER ───────────────────────────────────────────────
        html.Div(
            [
                html.Div(
                    [
                        DashIconify(icon="mdi:shield-lock", width=18, color="#94A3B8"),
                        html.Span(
                            "Financial Crime Investigation Report",
                            style={
                                "fontWeight": "600",
                                "fontSize": "0.75rem",
                                "color": "#94A3B8",
                                "letterSpacing": "0.5px",
                            },
                        ),
                        DashIconify(icon="mdi:shield-lock", width=18, color="#94A3B8"),
                    ],
                    style={
                        "display": "flex",
                        "alignItems": "center",
                        "gap": "0.5rem",
                        "justifyContent": "center",
                    },
                ),
            ],
            style={
                "background": "rgba(100,116,139,0.08)",
                "border": "1px solid rgba(100,116,139,0.2)",
                "borderRadius": "8px",
                "padding": "0.55rem 1rem",
                "marginBottom": "1rem",
            },
        ),
        # ── PAGE HEADER ───────────────────────────────────────────────────────
        html.Div(
            [
                html.Div(
                    [
                        html.Div(
                            [
                                DashIconify(icon="mdi:presentation", width=42, color="#FFD700"),
                                html.Div(
                                    [
                                        html.H1(
                                            "Executive Summary & Findings",
                                            style={
                                                "margin": 0,
                                                "fontSize": "1.9rem",
                                                "fontWeight": "800",
                                                "background": _GOLD_ACCENT,
                                                "WebkitBackgroundClip": "text",
                                                "WebkitTextFillColor": "transparent",
                                            },
                                        ),
                                        html.P(
                                            "Financial Crime Detection Analysis",
                                            style={
                                                "margin": 0,
                                                "color": "#94A3B8",
                                                "fontSize": "0.82rem",
                                                "letterSpacing": "0.5px",
                                            },
                                        ),
                                    ]
                                ),
                            ],
                            style={"display": "flex", "alignItems": "center", "gap": "1rem"},
                        ),
                        html.Div(
                            id="exec-timestamp",
                            style={"textAlign": "right", "color": "#64748B", "fontSize": "0.72rem"},
                        ),
                    ],
                    style={
                        "display": "flex",
                        "justifyContent": "space-between",
                        "alignItems": "center",
                    },
                ),
            ],
            style={"borderBottom": _GOLD_BORDER, "paddingBottom": "1rem", "marginBottom": "1.5rem"},
        ),
        # ── LIVE STATUS BADGE ─────────────────────────────────────────────────
        html.Div(id="exec-live-badge", style={"marginBottom": "1.2rem"}),
        # ── VERSION BADGE ─────────────────────────────────────────────────────
        dmc.Badge(
            f"v{APP.VERSION}",
            color="cyan",
            variant="dot",
            size="sm",
            style={"marginBottom": "1rem"},
        ),
        # =====================================================================
        # v12.43 — 4-TAB EXECUTIVE REPORT SUITE
        # =====================================================================
        dmc.Tabs(
            id="exec-report-tabs",
            value="overview",
            color="cyan",
            variant="pills",
            style={"marginBottom": "0.5rem"},
            children=[
                dmc.TabsList(
                    [
                        dmc.TabsTab(
                            "Overview",
                            value="overview",
                            leftSection=DashIconify(icon="mdi:view-dashboard", width=16),
                        ),
                        dmc.TabsTab(
                            "Strategic",
                            value="strategic",
                            leftSection=DashIconify(icon="mdi:shield-crown-outline", width=16),
                        ),
                        dmc.TabsTab(
                            "Financial",
                            value="financial",
                            leftSection=DashIconify(icon="mdi:cash-multiple", width=16),
                        ),
                        dmc.TabsTab(
                            "Technical",
                            value="technical",
                            leftSection=DashIconify(icon="mdi:cpu-64-bit", width=16),
                        ),
                    ],
                    grow=True,
                    style={
                        "background": "rgba(255,255,255,0.03)",
                        "borderRadius": "12px",
                        "padding": "4px",
                        "marginBottom": "1.5rem",
                    },
                ),
                # ─── TAB 1: OVERVIEW (existing 12-section board report) ──────
                dmc.TabsPanel(
                    value="overview",
                    children=[
                        # =====================================================================
                        # SECTION 1: ANALYSIS SCOPE KPIs
                        # =====================================================================
                        _section(
                            "mdi:magnify-scan",
                            "Section 1 — Analysis Scope",
                            "Summary of the customer population and data ingested "
                            "for this analysis cycle.",
                        ),
                        _info(
                            "These numbers tell you exactly how many customers were analysed, "
                            "how many financial relationships (connections) exist between them, "
                            "and how many data tables the system ingested. A higher number of "
                            "relationships per customer indicates a denser, more complex network "
                            "which may warrant deeper investigation."
                        ),
                        html.Div(
                            id="exec-scope-kpis",
                            children=[_pending()],
                            style={"marginBottom": "1.5rem"},
                        ),
                        # =====================================================================
                        # SECTION 2: RISK PORTFOLIO OVERVIEW
                        # =====================================================================
                        _section(
                            "mdi:alert-circle-outline",
                            "Section 2 — Risk Portfolio Overview",
                            "Every customer is classified into one of four risk priority "
                            "tiers. This breakdown shows how many customers fall into "
                            "each category and what action is recommended.",
                            color="#FF6B6B",
                        ),
                        _info(
                            "P1 (Critical) customers require immediate investigation. "
                            "P2 (High Risk) need enhanced review. "
                            "P3 (Medium) are on the active watch list. P4 (Low) operate normally. "
                            "If P1 count exceeds 5% of total customers, this is a material finding.",
                            accent="#FF6B6B",
                        ),
                        html.Div(
                            id="exec-risk-overview",
                            children=[_pending()],
                            style={"marginBottom": "1.5rem"},
                        ),
                        # =====================================================================
                        # SECTION 3: RISK DISTRIBUTION CHARTS
                        # =====================================================================
                        _section(
                            "mdi:chart-arc",
                            "Section 3 — Risk Score Distribution",
                            "Visual representation of how risk scores are spread across "
                            "the customer population.",
                        ),
                        _info(
                            "The donut chart shows the percentage of customers in each tier. "
                            "The bar chart shows exact counts. The histogram reveals the "
                            "full distribution of scores from 0 to 100."
                        ),
                        html.Div(
                            id="exec-risk-charts",
                            children=[_pending()],
                            style={"marginBottom": "1.5rem"},
                        ),
                        # =====================================================================
                        # SECTION 4: KEY FINDINGS & ALERTS
                        # =====================================================================
                        _section(
                            "mdi:flag-variant",
                            "Section 4 — Key Findings & Alerts",
                            "The most significant discoveries from this analysis cycle — "
                            "items that require senior management attention.",
                            color="#FF9800",
                        ),
                        _info(
                            "Each finding below represents a material observation from the "
                            "analysis engine. 'Rings' are groups of customers moving money "
                            "in circular patterns — a classic indicator of layering. "
                            "'Top Risk Customers' are individuals whose combined behaviour "
                            "places them in the highest-risk category.",
                            accent="#FF9800",
                        ),
                        html.Div(
                            id="exec-key-findings",
                            children=[_pending()],
                            style={"marginBottom": "1.5rem"},
                        ),
                        # =====================================================================
                        # SECTION 5: TOP 10 HIGHEST-RISK CUSTOMERS
                        # =====================================================================
                        _section(
                            "mdi:account-alert",
                            "Section 5 — Highest-Risk Customers",
                            "The ten customers with the highest composite risk scores. "
                            "These individuals should be the immediate focus of the "
                            "investigative team.",
                            color="#FF1744",
                        ),
                        _info(
                            "The risk score combines network position, transaction velocity, "
                            "behavioural anomalies, and peer-group deviation into a single "
                            "0–100 metric. A score above 80 (P1) means the system has high "
                            "confidence this customer warrants formal investigation.",
                            accent="#FF1744",
                        ),
                        html.Div(
                            id="exec-top10-table",
                            children=[_pending()],
                            style={"marginBottom": "1.5rem"},
                        ),
                        # =====================================================================
                        # SECTION 6: FINANCIAL EXPOSURE SUMMARY
                        # =====================================================================
                        _section(
                            "mdi:cash-multiple",
                            "Section 6 — Financial Exposure Summary",
                            "Total transaction volumes monitored and the portion "
                            "associated with high-risk customers.",
                            color="#FFD600",
                        ),
                        _info(
                            "'Flagged Exposure' is the subset of transaction flow passing through "
                            "P1 and P2 customers — this is the amount at greatest risk of being "
                            "associated with financial crime and represents potential regulatory "
                            "exposure for the institution.",
                            accent="#FFD600",
                        ),
                        html.Div(
                            id="exec-financial-exposure",
                            children=[_pending()],
                            style={"marginBottom": "1.5rem"},
                        ),
                        # =====================================================================
                        # SECTION 7: CIRCULAR MONEY-MOVEMENT RINGS
                        # =====================================================================
                        _section(
                            "mdi:account-group-outline",
                            "Section 7 — Circular Money-Movement Rings",
                            "Groups of customers where money flows in circular patterns "
                            "(A → B → C → A). This is a classic technique for disguising "
                            "the origin of funds.",
                            color="#9D4EDD",
                        ),
                        _info(
                            "A 'ring' is a closed loop where funds travel through multiple "
                            "intermediaries and return to or near the origin. Smaller rings "
                            "(3–4 members) indicate tight collusion, while larger rings "
                            "(6–8 members) suggest more sophisticated multi-hop laundering. "
                            "The table below shows each detected ring, its member count, "
                            "the total dollar amount circulated, and the average risk.",
                            accent="#9D4EDD",
                        ),
                        html.Div(
                            id="exec-lobby-summary",
                            children=[_pending()],
                            style={"marginBottom": "1.5rem"},
                        ),
                        # =====================================================================
                        # SECTION 8: NETWORK STRUCTURE ANALYSIS
                        # =====================================================================
                        _section(
                            "mdi:graph",
                            "Section 8 — Network Structure & Intelligence",
                            "Key structural findings from the customer relationship "
                            "network — how connections are shaped and where risk "
                            "concentrations exist.",
                            color="#E040FB",
                        ),
                        _info(
                            "'Components' are isolated clusters of customers. "
                            "'Average Degree' shows how many connections each customer has "
                            "on average. Bridge nodes connect otherwise separate groups and "
                            "are critical gatekeepers that could enable illicit fund flows "
                            "across network boundaries.",
                            accent="#E040FB",
                        ),
                        html.Div(
                            id="exec-intelligence-insights",
                            children=[_pending()],
                            style={"marginBottom": "1.5rem"},
                        ),
                        # =====================================================================
                        # SECTION 9: DETECTION METHODS COVERAGE
                        # =====================================================================
                        _section(
                            "mdi:engine-outline",
                            "Section 9 — Detection Methods — Detailed Results",
                            "The system employs up to 10 independent analytical methods. "
                            "Each examines customer behaviour from a different perspective. "
                            "Below are the key findings from each method.",
                            color="#00D4FF",
                        ),
                        _info(
                            "Think of each method as a different detective examining the same "
                            "evidence from a different angle. One looks at who knows whom, "
                            "another at how fast money moves, another at unusual patterns. "
                            "The composite score combines all perspectives into one number "
                            "per customer.",
                            accent="#00D4FF",
                        ),
                        html.Div(
                            id="exec-analytics-coverage",
                            children=[_pending()],
                            style={"marginBottom": "1.5rem"},
                        ),
                        # =====================================================================
                        # SECTION 10: INVESTIGATION PRIORITY QUEUE
                        # =====================================================================
                        _section(
                            "mdi:clipboard-list-outline",
                            "Section 10 — Investigation Priority Queue",
                            "Customers flagged for investigation, ranked by priority. "
                            "This queue drives the compliance team's workload.",
                            color="#FF6B6B",
                        ),
                        _info(
                            "The Investigation Queue is the actionable output of the entire "
                            "analysis. It lists customers who need attention, ranked by "
                            "urgency. The queue size determines the compliance team's "
                            "workload for the next review cycle.",
                            accent="#FF6B6B",
                        ),
                        html.Div(
                            id="exec-investigation-queue",
                            children=[_pending()],
                            style={"marginBottom": "1.5rem"},
                        ),
                        # =====================================================================
                        # SECTION 11: OPERATIONS & DATA QUALITY
                        # =====================================================================
                        _section(
                            "mdi:database-check",
                            "Section 11 — Pipeline Operations & Data Quality",
                            "Confirms data integrity and completeness of the analysis.",
                            color="#00E676",
                        ),
                        _info(
                            "This section verifies that the analysis was completed successfully "
                            "and all required data sources were available. A 'PASS' status "
                            "confirms the results are reliable.",
                            accent="#00E676",
                        ),
                        html.Div(
                            id="exec-pipeline-status",
                            children=[_pending()],
                            style={"marginBottom": "1.5rem"},
                        ),
                        # =====================================================================
                        # SECTION 12: RECOMMENDATIONS & NEXT STEPS
                        # =====================================================================
                        _section(
                            "mdi:clipboard-check-outline",
                            "Section 12 — Recommendations & Next Steps",
                            "Actionable guidance for senior management based on the "
                            "analysis findings.",
                            color="#FFD700",
                        ),
                        html.Div(
                            id="exec-recommendations",
                            children=[_pending()],
                            style={"marginBottom": "1.5rem"},
                        ),
                    ],
                ),  # ← close TabsPanel("overview")
                # ─── TAB 2: STRATEGIC — CEO View ─────────────────────────────
                dmc.TabsPanel(
                    value="strategic",
                    children=[
                        html.Div(
                            id="exec-strategic-content",
                            children=[
                                _pending("Strategic view loading — run pipeline to populate.")
                            ],
                        ),
                    ],
                ),
                # ─── TAB 3: FINANCIAL — CFO View ─────────────────────────────
                dmc.TabsPanel(
                    value="financial",
                    children=[
                        html.Div(
                            id="exec-financial-content",
                            children=[
                                _pending("Financial view loading — run pipeline to populate.")
                            ],
                        ),
                    ],
                ),
                # ─── TAB 4: TECHNICAL — CTO View ─────────────────────────────
                dmc.TabsPanel(
                    value="technical",
                    children=[
                        html.Div(
                            id="exec-technical-content",
                            children=[
                                _pending("Technical view loading — run pipeline to populate.")
                            ],
                        ),
                    ],
                ),
            ],
        ),  # ← close dmc.Tabs
        # =====================================================================
        # METHODOLOGY NOTE
        # =====================================================================
        html.Div(
            [
                html.Div(
                    [
                        DashIconify(icon="mdi:information-outline", width=16, color="#64748B"),
                        html.Span(
                            "Methodology Note",
                            style={"color": "#64748B", "fontWeight": "600", "fontSize": "0.75rem"},
                        ),
                    ],
                    style={
                        "display": "flex",
                        "alignItems": "center",
                        "gap": "0.4rem",
                        "marginBottom": "0.5rem",
                    },
                ),
                html.P(
                    "This analysis was produced by the FCDAI Network Analyzer — a "
                    "graph-based analytics engine that ingests customer, transaction, "
                    "account, alert, and KYC data to construct a financial network "
                    "graph. Up to 10 independent analytical methods — ranging from "
                    "network centrality to temporal pattern detection — each produce "
                    "risk indicators that are combined into a single composite score "
                    "per customer. Customers are then classified into four priority "
                    "tiers (P1–P4) using statistically validated thresholds. The "
                    "system operates in an air-gapped, PII-protected environment with "
                    "full audit trails. All analysis is performed on-premises with "
                    "zero data leakage to external systems.",
                    style={
                        "color": "#64748B",
                        "fontSize": "0.72rem",
                        "lineHeight": "1.6",
                        "margin": 0,
                    },
                ),
            ],
            style={
                "background": "rgba(100,116,139,0.06)",
                "border": "1px solid rgba(100,116,139,0.15)",
                "borderRadius": "10px",
                "padding": "1rem 1.2rem",
                "marginBottom": "1.5rem",
            },
        ),
        # ── EXPORT BAR ────────────────────────────────────────────────────────
        dmc.Paper(
            [
                dmc.Group(
                    [
                        DashIconify(icon="mdi:download-circle-outline", width=22, color="#00D4FF"),
                        dmc.Text("Export Executive Summary", fw=600, c="white", size="sm"),
                        dmc.Button(
                            "⬇ Export CSV",
                            id="exec-export-csv",
                            size="xs",
                            variant="light",
                            color="cyan",
                            leftSection=DashIconify(icon="mdi:download", width=14),
                        ),
                        dmc.Button(
                            "🖨 Print / PDF",
                            id="exec-export-pdf",
                            size="xs",
                            variant="light",
                            color="grape",
                            leftSection=DashIconify(icon="mdi:printer", width=14),
                        ),
                    ],
                    gap="md",
                    align="center",
                ),
            ],
            p="sm",
            radius="lg",
            className="glass-card",
            mb="md",
            style={
                "background": "rgba(0,212,255,0.04)",
                "border": "1px solid rgba(0,212,255,0.15)",
            },
        ),
        dcc.Download(id="exec-download"),
        # ── FOOTER ────────────────────────────────────────────────────────────
        html.Div(
            [
                html.Div(
                    [
                        html.Span(
                            f"FCDAI Network Analyzer v{APP.VERSION}",
                            style={"color": "#64748B", "fontWeight": "600", "fontSize": "0.7rem"},
                        ),
                        html.Span(" · ", style={"color": "#334155"}),
                        html.Span(
                            "AIR-GAPPED · PII-PROTECTED · OFFLINE-ONLY",
                            style={
                                "color": "#475569",
                                "fontSize": "0.65rem",
                                "letterSpacing": "1px",
                            },
                        ),
                    ],
                    style={"textAlign": "center"},
                ),
                html.Div(
                    "© Financial Crime Detection & AI — All rights reserved",
                    style={
                        "textAlign": "center",
                        "color": "#475569",
                        "fontSize": "0.65rem",
                        "marginTop": "0.25rem",
                    },
                ),
            ],
            style={
                "borderTop": "1px solid rgba(255,255,255,0.06)",
                "paddingTop": "1rem",
                "marginTop": "0.5rem",
            },
        ),
    ],
    style={
        "padding": "1.5rem 2rem",
        "fontFamily": "'Inter', sans-serif",
        "background": THEME.DARK_BG,
        "minHeight": "100vh",
        "color": THEME.TEXT_PRIMARY,
        "maxWidth": "1200px",
        "marginLeft": "auto",
        "marginRight": "auto",
    },
)


# =============================================================================
# SECTION BUILDERS — each is independent, each handles its own errors
# =============================================================================


def _build_timestamp(meta, pipeline):
    """Build the report timestamp block."""
    saved_at = meta.get("saved_at", "")
    run_version = meta.get("run_id", getattr(pipeline, "run_version", "N/A"))
    if saved_at:
        try:
            dt = datetime.fromisoformat(str(saved_at))
            ts_display = dt.strftime("%B %d, %Y at %H:%M:%S")
        except Exception:
            ts_display = str(saved_at)
    else:
        ts_display = datetime.now().strftime("%B %d, %Y at %H:%M:%S")

    duration_sec = float(meta.get("duration_sec", 0) or 0)
    dur_str = f"{duration_sec:.1f}s" if duration_sec < 60 else f"{duration_sec/60:.1f}min"
    max_cust = meta.get("max_customers", "—")

    return html.Div(
        [
            html.Div(f"Report Generated: {ts_display}", style={"fontWeight": "600"}),
            html.Div(
                f"Analysis Duration: {dur_str}  ·  Run #{run_version}  ·  "
                f"Capacity: {max_cust} customers",
                style={"marginTop": "2px"},
            ),
            html.Div(f"Engine Version: {APP.VERSION}", style={"marginTop": "2px"}),
        ]
    )


def _build_live_badge(pipeline):
    """Build the LIVE or PENDING badge."""
    if pipeline.is_running():
        return html.Div(
            [
                html.Span("⬤ ", style={"color": "#FFD600", "fontSize": "0.6rem"}),
                html.Span(
                    "PIPELINE RUNNING — Report will populate when complete",
                    style={"color": "#FFD600", "fontSize": "0.72rem", "fontWeight": "600"},
                ),
            ]
        )
    scored = pipeline.get_scored_df()  # v14.7 FIX-GAP6: consistent with all other pages
    if scored is not None and len(scored) > 0:
        return html.Div(
            [
                html.Span("⬤ ", style={"color": "#00E676", "fontSize": "0.6rem"}),
                html.Span(
                    "LIVE — All figures auto-update with each pipeline run",
                    style={"color": "#00E676", "fontSize": "0.72rem", "fontWeight": "600"},
                ),
            ]
        )
    return html.Div(
        [
            html.Span("⬤ ", style={"color": "#FF9800", "fontSize": "0.6rem"}),
            html.Span(
                "AWAITING DATA — Run the pipeline from the Dashboard to " "generate this report",
                style={"color": "#FF9800", "fontSize": "0.72rem", "fontWeight": "600"},
            ),
        ]
    )


def _build_scope_kpis(scored, G, tables, analytics, geo_countries, meta):
    """Section 1: Analysis Scope KPIs."""
    total = len(scored)
    nodes = G.number_of_nodes() if G else total
    edges = G.number_of_edges() if G else 0
    density_pct = round((edges / max(nodes * (nodes - 1), 1)) * 100, 2)
    table_names = list((tables or {}).keys())
    table_count = len(table_names)
    total_records = sum(len(df) for df in (tables or {}).values() if isinstance(df, pd.DataFrame))
    max_cust = meta.get("max_customers", total)
    n_families = len(analytics) if analytics else 0
    n_geo = len(geo_countries) if geo_countries else 0
    n_geo_high = sum(
        1
        for c in (geo_countries or {}).values()
        if (c.get("high_risk_count", 0) or c.get("high_risk", 0)) > 0
    )

    return dmc.SimpleGrid(
        cols={"base": 2, "sm": 3, "lg": 6},
        spacing="md",
        children=[
            _kpi(
                "mdi:account-group",
                "Customers Analysed",
                f"{total:,}",
                "#00D4FF",
                f"Requested: {max_cust:,}",
            ),
            _kpi(
                "mdi:graph",
                "Financial Relationships",
                f"{edges:,}",
                "#9D4EDD",
                f"Avg {round(edges / max(nodes, 1), 1)} per customer",
            ),
            _kpi(
                "mdi:percent",
                "Network Density",
                f"{density_pct}%",
                "#2196F3",
                "Higher = more interconnected",
            ),
            _kpi(
                "mdi:table-large",
                "Data Tables Ingested",
                f"{table_count}",
                "#00E676",
                f"{total_records:,} total records",
            ),
            _kpi(
                "mdi:brain",
                "Detection Methods",
                f"{n_families}",
                "#E040FB",
                "Independent methods applied",
            ),
            _kpi(
                "mdi:earth",
                "Jurisdictions Covered",
                f"{n_geo}",
                "#FF6B6B",
                f"{n_geo_high} with high-risk customers",
            ),
        ],
    )


def _build_risk_overview(scored, total):
    """Section 2: Risk Portfolio Overview."""
    tier_counts = scored["risk_tier"].value_counts()
    cards = []
    for tc in ["P1", "P2", "P3", "P4"]:
        count = int(tier_counts.get(tc, 0))
        pct = round(count / max(total, 1) * 100, 1)
        color = TIER_COLORS[tc]
        cards.append(
            html.Div(
                [
                    html.Div(
                        [
                            html.Div(
                                style={
                                    "width": "14px",
                                    "height": "14px",
                                    "borderRadius": "50%",
                                    "backgroundColor": color,
                                    "border": "2px solid rgba(255,255,255,0.3)",
                                    "flexShrink": "0",
                                }
                            ),
                            html.Div(
                                [
                                    html.Div(
                                        f"{tc} — {TIER_LABELS[tc].split('—')[0].strip()}",
                                        style={
                                            "color": color,
                                            "fontWeight": "700",
                                            "fontSize": "0.9rem",
                                        },
                                    ),
                                    html.Div(
                                        f"{count:,} customers  ({pct}%)",
                                        style={
                                            "color": "#E2E8F0",
                                            "fontSize": "1.3rem",
                                            "fontWeight": "800",
                                            "marginTop": "0.2rem",
                                        },
                                    ),
                                ]
                            ),
                        ],
                        style={"display": "flex", "gap": "0.7rem", "alignItems": "flex-start"},
                    ),
                    html.P(
                        TIER_DESCRIPTIONS[tc],
                        style={
                            "color": "#94A3B8",
                            "fontSize": "0.75rem",
                            "lineHeight": "1.5",
                            "margin": "0.6rem 0 0 1.6rem",
                        },
                    ),
                ],
                style={**_GLASS, "padding": "1.1rem 1.3rem", "borderLeft": f"4px solid {color}"},
            )
        )

    avg_s = round(float(scored["risk_score"].mean()), 1)
    med_s = round(float(scored["risk_score"].median()), 1)
    max_s = round(float(scored["risk_score"].max()), 1)
    min_s = round(float(scored["risk_score"].min()), 1)
    std_s = round(float(scored["risk_score"].std()), 1)
    p1 = int(tier_counts.get("P1", 0))
    p2 = int(tier_counts.get("P2", 0))
    hr_total = p1 + p2
    hr_pct = round(hr_total / max(total, 1) * 100, 1)

    return html.Div(
        [
            dmc.SimpleGrid(cols={"base": 1, "sm": 2}, spacing="md", children=cards),
            html.Div(
                [
                    html.Div(
                        [
                            _stat("Average Score", avg_s),
                            _stat("Median", med_s),
                            _stat("Highest", max_s, "#FF1744"),
                            _stat("Lowest", min_s, "#00E676"),
                            _stat("Std Dev", std_s, "#94A3B8"),
                        ],
                        style={"marginTop": "1rem"},
                    ),
                    html.Div(
                        f"Combined P1 + P2 (High Risk): {hr_total:,} customers "
                        f"({hr_pct}% of portfolio)",
                        style={
                            "color": "#FF9800",
                            "fontSize": "0.82rem",
                            "fontWeight": "600",
                            "marginTop": "0.5rem",
                        },
                    ),
                ]
            ),
        ]
    )


def _build_risk_charts(scored, total):
    """Section 3: Risk distribution charts — donut + bar + histogram."""
    tier_counts = scored["risk_tier"].value_counts()
    tier_order = ["P1", "P2", "P3", "P4"]
    vals = [int(tier_counts.get(t, 0)) for t in tier_order]
    colors = [TIER_COLORS[t] for t in tier_order]

    # Donut
    fig_donut = go.Figure(
        go.Pie(
            labels=tier_order,
            values=vals,
            hole=0.65,
            marker=dict(colors=colors, line=dict(color="rgba(10,14,23,0.8)", width=2)),
            textfont=dict(color="white", size=12),
            textinfo="label+value+percent",
            hovertemplate="<b>%{label}</b><br>Count: %{value:,}<br>%{percent}<extra></extra>",
        )
    )
    fig_donut.update_layout(
        **DARK_CHART,
        annotations=[
            dict(
                text=f"{total:,}<br>Total",
                x=0.5,
                y=0.5,
                font=dict(size=18, color="white"),
                showarrow=False,
            )
        ],
        showlegend=False,
        height=320,
    )

    # Bar
    fig_bar = go.Figure(
        go.Bar(
            x=tier_order,
            y=vals,
            text=[f"{v:,}" for v in vals],
            textposition="outside",
            textfont=dict(color="white", size=12, family="Inter"),
            marker=dict(color=colors, line=dict(color="rgba(255,255,255,0.1)", width=1)),
        )
    )
    fig_bar.update_layout(
        **DARK_CHART, xaxis_title="Risk Tier", yaxis_title="Number of Customers", height=320
    )

    # Histogram
    scores = scored["risk_score"].dropna().values
    fig_hist = go.Figure(
        go.Histogram(
            x=scores,
            nbinsx=25,
            marker=dict(color="#00D4FF", line=dict(color="#0A0E17", width=1)),
            hovertemplate="Score Range: %{x}<br>Count: %{y}<extra></extra>",
        )
    )
    fig_hist.add_vline(
        x=80, line_dash="dash", line_color="#FF1744", annotation_text="P1 Threshold (80)"
    )
    fig_hist.add_vline(
        x=60, line_dash="dash", line_color="#FF9800", annotation_text="P2 Threshold (60)"
    )
    fig_hist.update_layout(
        **DARK_CHART,
        xaxis_title="Risk Score (0–100)",
        yaxis_title="Number of Customers",
        height=280,
    )

    return html.Div(
        [
            dmc.SimpleGrid(
                cols={"base": 1, "sm": 2},
                spacing="md",
                children=[
                    html.Div(
                        [
                            html.Div(
                                "Proportion by Risk Tier",
                                style={
                                    "color": "#94A3B8",
                                    "fontSize": "0.75rem",
                                    "fontWeight": "600",
                                    "textTransform": "uppercase",
                                    "letterSpacing": "1px",
                                    "marginBottom": "0.5rem",
                                    "textAlign": "center",
                                },
                            ),
                            dcc.Graph(
                                figure=fig_donut,
                                config={"displayModeBar": False},
                                style={"height": "320px"},
                            ),
                        ],
                        style=_GLASS,
                    ),
                    html.Div(
                        [
                            html.Div(
                                "Customer Count by Risk Tier",
                                style={
                                    "color": "#94A3B8",
                                    "fontSize": "0.75rem",
                                    "fontWeight": "600",
                                    "textTransform": "uppercase",
                                    "letterSpacing": "1px",
                                    "marginBottom": "0.5rem",
                                    "textAlign": "center",
                                },
                            ),
                            dcc.Graph(
                                figure=fig_bar,
                                config={"displayModeBar": False},
                                style={"height": "320px"},
                            ),
                        ],
                        style=_GLASS,
                    ),
                ],
            ),
            html.Div(
                [
                    html.Div(
                        "Full Score Distribution — Where Do Your Customers Fall?",
                        style={
                            "color": "#94A3B8",
                            "fontSize": "0.75rem",
                            "fontWeight": "600",
                            "textTransform": "uppercase",
                            "letterSpacing": "1px",
                            "marginBottom": "0.3rem",
                            "marginTop": "1rem",
                            "textAlign": "center",
                        },
                    ),
                    html.Div(
                        "Dashed lines mark the P1 (80) and P2 (60) thresholds. "
                        "Customers to the right need immediate attention.",
                        style={
                            "color": "#64748B",
                            "fontSize": "0.7rem",
                            "textAlign": "center",
                            "marginBottom": "0.5rem",
                        },
                    ),
                    dcc.Graph(
                        figure=fig_hist, config={"displayModeBar": False}, style={"height": "280px"}
                    ),
                ],
                style=_GLASS,
            ),
        ]
    )


def _build_key_findings(scored, G, lobbies, geo_countries, inv_queue_size):
    """Section 4: Key Findings — auto-generated bullets."""
    total = len(scored)
    tier_counts = scored["risk_tier"].value_counts()
    p1 = int(tier_counts.get("P1", 0))
    p2 = int(tier_counts.get("P2", 0))
    p1_pct = round(p1 / max(total, 1) * 100, 1)
    p2_pct = round(p2 / max(total, 1) * 100, 1)
    nodes = G.number_of_nodes() if G else total
    edges = G.number_of_edges() if G else 0

    findings = []
    if p1 > 0:
        findings.append(
            _finding(
                "mdi:alert-octagon",
                f"{p1:,} customer(s) classified as CRITICAL (P1) — "
                f"{p1_pct}% of total. Immediate investigation recommended.",
                "#FF1744",
            )
        )
    if p2 > 0:
        findings.append(
            _finding(
                "mdi:alert",
                f"{p2:,} customer(s) classified as HIGH RISK (P2) — "
                f"{p2_pct}% of portfolio. Enhanced review "
                f"required promptly.",
                "#FF9800",
            )
        )
    if lobbies:
        total_lobby_flow = sum(l.get("total_amount", 0) for l in lobbies)
        member_sizes = [len(l.get("members", l.get("nodes", []))) for l in lobbies]
        if member_sizes:
            min_r, max_r = min(member_sizes), max(member_sizes)
            ring_desc = (
                f"each with {min_r} members"
                if min_r == max_r
                else f"ranging from {min_r} to {max_r} members"
            )
        else:
            ring_desc = ""
        findings.append(
            _finding(
                "mdi:account-group",
                f"{len(lobbies)} circular money-movement ring(s) detected "
                f"({ring_desc}), involving ${total_lobby_flow:,.0f} in "
                f"transaction volume. Each ring requires separate "
                f"investigation review.",
                "#9D4EDD",
            )
        )

    # Financial flow through high-risk customers
    flagged_flow = 0.0
    total_flow = 0.0
    if G:
        for nid in G.nodes():
            attrs = G.nodes[nid]
            inf = float(attrs.get("in_flow", 0) or 0)
            outf = float(attrs.get("out_flow", 0) or 0)
            total_flow += inf + outf
            if attrs.get("risk_tier", "P4") in ("P1", "P2"):
                flagged_flow += inf + outf
    if flagged_flow > 0:
        findings.append(
            _finding(
                "mdi:cash-lock",
                f"${flagged_flow:,.0f} in transaction volume associated with "
                f"P1/P2 customers — "
                f"{round(flagged_flow / max(total_flow, 1) * 100, 1)}% "
                f"of total monitored flow.",
                "#FFD600",
            )
        )

    # Network components
    try:
        import networkx as nx

        if G:
            components = nx.number_weakly_connected_components(G)
            if components > 1:
                findings.append(
                    _finding(
                        "mdi:set-split",
                        (
                            f"Network contains {components} disconnected clusters — "
                            f"{'potentially isolated groups operating independently'}"
                            if components > 5
                            else f"Network contains {components} disconnected clusters — "
                            f"normal network segmentation."
                        ),
                        "#2196F3",
                    )
                )
    except Exception:
        pass

    # Geo-risk
    if geo_countries:
        high_risk_c = [
            c
            for c, v in geo_countries.items()
            if (v.get("high_risk_count", 0) or v.get("high_risk", 0)) > 0
        ]
        if high_risk_c:
            findings.append(
                _finding(
                    "mdi:earth",
                    f"{len(high_risk_c)} jurisdiction(s) contain high-risk "
                    f"customers: {', '.join(high_risk_c[:5])}"
                    f"{f' (+{len(high_risk_c)-5} more)' if len(high_risk_c) > 5 else ''}.",
                    "#FF6B6B",
                )
            )

    avg_rels = round(edges / max(nodes, 1), 1)
    findings.append(
        _finding(
            "mdi:swap-horizontal",
            f"Average {avg_rels} financial relationships per customer — "
            f"{'above' if avg_rels > 3 else 'within'} industry norms.",
            "#00D4FF",
        )
    )

    if inv_queue_size > 0:
        findings.append(
            _finding(
                "mdi:clipboard-list-outline",
                f"{inv_queue_size:,} customers queued for investigation — "
                f"compliance team workload is "
                f"{'heavy' if inv_queue_size > 100 else 'moderate' if inv_queue_size > 30 else 'manageable'}.",
                "#E040FB",
            )
        )

    if not findings:
        findings.append(
            _finding(
                "mdi:check-circle",
                "No material findings requiring immediate escalation.",
                "#00E676",
            )
        )

    return html.Div(
        findings, style={**_GLASS, "padding": "1.2rem 1.5rem", "borderLeft": "4px solid #FF9800"}
    )


def _build_top10(scored, G):
    """Section 5: Top-10 table."""
    top10 = scored.nlargest(10, "risk_score")
    rows = []
    for rank, (_, row) in enumerate(top10.iterrows(), 1):
        tier = row.get("risk_tier", "P4")
        score = float(row.get("risk_score", 0))
        nid = str(row.get("node_id", ""))
        label = nid.replace("CUST-", "Customer #") if "CUST-" in nid else nid
        color = TIER_COLORS.get(tier, "#64748B")
        in_d = G.in_degree(nid) if G and nid in G.nodes else 0
        out_d = G.out_degree(nid) if G and nid in G.nodes else 0
        nf = 0
        if G and nid in G.nodes:
            nf = float(G.nodes[nid].get("in_flow", 0) or 0) + float(
                G.nodes[nid].get("out_flow", 0) or 0
            )

        action = (
            "Proper Investigate"
            if tier == "P1"
            else (
                "Enhanced Review"
                if tier == "P2"
                else "Active Monitoring" if tier == "P3" else "Standard Monitoring"
            )
        )

        rows.append(
            html.Tr(
                [
                    html.Td(
                        str(rank),
                        style={
                            "color": "#94A3B8",
                            "fontWeight": "600",
                            "textAlign": "center",
                            "width": "40px",
                        },
                    ),
                    html.Td(label, style={"color": "#E2E8F0", "fontWeight": "600"}),
                    html.Td(
                        f"{score:.1f}",
                        style={"color": color, "fontWeight": "700", "textAlign": "center"},
                    ),
                    html.Td(
                        html.Div(
                            [
                                html.Div(
                                    style={
                                        "width": "10px",
                                        "height": "10px",
                                        "borderRadius": "50%",
                                        "backgroundColor": color,
                                        "display": "inline-block",
                                        "marginRight": "6px",
                                    }
                                ),
                                tier,
                            ],
                            style={
                                "display": "flex",
                                "alignItems": "center",
                                "justifyContent": "center",
                            },
                        ),
                        style={"textAlign": "center"},
                    ),
                    html.Td(f"{in_d + out_d}", style={"color": "#94A3B8", "textAlign": "center"}),
                    html.Td(
                        f"${nf:,.0f}",
                        style={"color": "#FFD600", "textAlign": "right", "fontSize": "0.78rem"},
                    ),
                    html.Td(action, style={"color": "#94A3B8", "fontSize": "0.78rem"}),
                ],
                style={"borderBottom": "1px solid rgba(255,255,255,0.05)"},
            )
        )

    return html.Div(
        [
            html.Table(
                [
                    html.Thead(
                        html.Tr(
                            [
                                html.Th(
                                    "Rank", style={**_TH, "textAlign": "center", "width": "50px"}
                                ),
                                html.Th("Customer", style=_TH),
                                html.Th("Risk Score", style={**_TH, "textAlign": "center"}),
                                html.Th("Priority", style={**_TH, "textAlign": "center"}),
                                html.Th("Connections", style={**_TH, "textAlign": "center"}),
                                html.Th("Total Flow", style={**_TH, "textAlign": "right"}),
                                html.Th("Recommended Action", style=_TH),
                            ]
                        )
                    ),
                    html.Tbody(rows),
                ],
                style={
                    "width": "100%",
                    "borderCollapse": "collapse",
                    "borderRadius": "10px",
                    "overflow": "hidden",
                },
            ),
        ],
        style=_GLASS,
    )


def _build_financial_exposure(G):
    """Section 6: Financial exposure KPIs."""
    total_in = 0.0
    total_out = 0.0
    flagged = 0.0
    if G:
        for nid in G.nodes():
            a = G.nodes[nid]
            inf = float(a.get("in_flow", 0) or 0)
            outf = float(a.get("out_flow", 0) or 0)
            total_in += inf
            total_out += outf
            if a.get("risk_tier", "P4") in ("P1", "P2"):
                flagged += inf + outf
    total_flow = total_in + total_out
    flagged_pct = round(flagged / max(total_flow, 1) * 100, 1)

    return dmc.SimpleGrid(
        cols={"base": 2, "lg": 4},
        spacing="md",
        children=[
            _kpi(
                "mdi:cash-plus",
                "Total Inbound Flow",
                f"${total_in:,.0f}",
                "#00E676",
                "Aggregate incoming transaction volume",
            ),
            _kpi(
                "mdi:cash-minus",
                "Total Outbound Flow",
                f"${total_out:,.0f}",
                "#2196F3",
                "Aggregate outgoing transaction volume",
            ),
            _kpi(
                "mdi:cash-multiple",
                "Total Monitored Volume",
                f"${total_flow:,.0f}",
                "#00D4FF",
                "Combined in + out transaction flow",
            ),
            _kpi(
                "mdi:cash-lock",
                "Flagged Exposure (P1+P2)",
                f"${flagged:,.0f}",
                "#FF1744" if flagged > 0 else "#00E676",
                f"{flagged_pct}% of total flow",
            ),
        ],
    )


def _build_lobby_summary(lobbies):
    """Section 7: Circular money-movement rings."""
    if not lobbies:
        return html.Div(
            [
                dmc.Text(
                    "No circular money-movement rings detected in this " "analysis cycle.",
                    c="dimmed",
                    size="sm",
                ),
                html.Div(
                    "This is a positive indicator — no evidence of "
                    "layering-type activity was found.",
                    style={"color": "#00E676", "fontSize": "0.78rem", "marginTop": "0.4rem"},
                ),
            ],
            style=_GLASS,
        )

    lobby_rows = []
    for ring in lobbies[:15]:
        ring_name = ring.get("ring_name", "Ring")
        members = ring.get("members", [])
        actual_count = len(members) if members else ring.get("size", 0)
        total_amt = ring.get("total_amount", 0)
        total_flw = ring.get("total_flow", 0)
        avg_risk = ring.get("avg_risk", 0)
        ring_p1 = sum(1 for m in members if m.get("risk_tier") == "P1")
        ring_p2 = sum(1 for m in members if m.get("risk_tier") == "P2")
        ring_hi = ring_p1 + ring_p2
        avg_color = "#FF1744" if avg_risk >= 80 else "#FF9800" if avg_risk >= 60 else "#FFD600"
        member_names = [str(m.get("node_id", "?")).replace("CUST-", "#") for m in members[:4]]
        preview = ", ".join(member_names)
        if len(members) > 4:
            preview += f" +{len(members)-4} more"

        lobby_rows.append(
            html.Tr(
                [
                    html.Td(ring_name, style={"color": "#E2E8F0", "fontWeight": "600"}),
                    html.Td(
                        f"{actual_count}",
                        style={"textAlign": "center", "color": "#9D4EDD", "fontWeight": "700"},
                    ),
                    html.Td(
                        preview,
                        style={"color": "#94A3B8", "fontSize": "0.72rem", "maxWidth": "200px"},
                    ),
                    html.Td(f"${total_amt:,.0f}", style={"textAlign": "right", "color": "#FFD600"}),
                    html.Td(
                        f"${total_flw:,.0f}",
                        style={"textAlign": "right", "color": "#00D4FF", "fontSize": "0.78rem"},
                    ),
                    html.Td(
                        f"{avg_risk:.1f}",
                        style={"textAlign": "center", "color": avg_color, "fontWeight": "600"},
                    ),
                    html.Td(
                        f"{ring_hi}" if ring_hi > 0 else "—",
                        style={
                            "textAlign": "center",
                            "color": "#FF1744" if ring_hi > 0 else "#64748B",
                        },
                    ),
                ],
                style={"borderBottom": "1px solid rgba(255,255,255,0.05)"},
            )
        )

    # Ring size distribution chart
    all_sizes = [len(r.get("members", r.get("nodes", []))) for r in lobbies]
    unique_in_rings = set()
    for r in lobbies:
        for m in r.get("members", []):
            unique_in_rings.add(m.get("node_id", ""))

    size_dist = Counter(all_sizes)
    size_labels = sorted(size_dist.keys())
    size_vals = [size_dist[s] for s in size_labels]
    palette = [
        "#9D4EDD",
        "#E040FB",
        "#FF6B6B",
        "#FF9800",
        "#FFD600",
        "#00E676",
        "#00D4FF",
        "#2196F3",
    ]
    fig_ring = go.Figure(
        go.Bar(
            x=[f"{s} Members" for s in size_labels],
            y=size_vals,
            text=[str(v) for v in size_vals],
            textposition="outside",
            textfont=dict(color="white", size=12),
            marker=dict(
                color=palette[: len(size_labels)], line=dict(color="rgba(255,255,255,0.1)", width=1)
            ),
        )
    )
    fig_ring.update_layout(
        **DARK_CHART,
        xaxis_title="Ring Size (Number of Members)",
        yaxis_title="Number of Rings Detected",
        height=250,
    )

    return html.Div(
        [
            html.Table(
                [
                    html.Thead(
                        html.Tr(
                            [
                                html.Th("Ring", style=_TH),
                                html.Th("Members", style={**_TH, "textAlign": "center"}),
                                html.Th("Participants", style=_TH),
                                html.Th("Ring Amount", style={**_TH, "textAlign": "right"}),
                                html.Th("Total Flow", style={**_TH, "textAlign": "right"}),
                                html.Th("Avg Risk", style={**_TH, "textAlign": "center"}),
                                html.Th("P1/P2", style={**_TH, "textAlign": "center"}),
                            ]
                        )
                    ),
                    html.Tbody(lobby_rows),
                ],
                style={"width": "100%", "borderCollapse": "collapse"},
            ),
            # Ring Size Distribution Chart
            html.Div(
                [
                    html.Div(
                        "Ring Size Distribution",
                        style={
                            "color": "#94A3B8",
                            "fontSize": "0.75rem",
                            "fontWeight": "600",
                            "textTransform": "uppercase",
                            "letterSpacing": "1px",
                            "marginBottom": "0.3rem",
                            "marginTop": "1rem",
                            "textAlign": "center",
                        },
                    ),
                    html.Div(
                        "How many rings were detected at each size — diverse sizes "
                        "indicate multiple independent laundering schemes.",
                        style={
                            "color": "#64748B",
                            "fontSize": "0.7rem",
                            "textAlign": "center",
                            "marginBottom": "0.5rem",
                        },
                    ),
                    dcc.Graph(
                        figure=fig_ring, config={"displayModeBar": False}, style={"height": "250px"}
                    ),
                ]
            ),
            html.Div(
                [
                    _stat("Total Rings", len(lobbies), "#9D4EDD"),
                    _stat(
                        "Ring Sizes",
                        (
                            f"{min(all_sizes)}–{max(all_sizes)}"
                            if len(set(all_sizes)) > 1
                            else str(all_sizes[0]) if all_sizes else "0"
                        ),
                        "#E040FB",
                    ),
                    _stat("Unique Individuals", f"{len(unique_in_rings)}", "#00D4FF"),
                    _stat(
                        "Total Circulated",
                        f"${sum(l.get('total_amount', 0) for l in lobbies):,.0f}",
                        "#FFD600",
                    ),
                ],
                style={"marginTop": "0.8rem"},
            ),
        ],
        style=_GLASS,
    )


def _build_intelligence(scored, G, pipeline):
    """Section 8: Network structure & intelligence insights."""
    import networkx as nx

    nodes = G.number_of_nodes() if G else len(scored)
    edges = G.number_of_edges() if G else 0
    net_stats = _safe(lambda: pipeline.get_network_stats(), {})
    components = net_stats.get("components", 0)
    avg_in = net_stats.get("avg_in_degree", 0)
    avg_out = net_stats.get("avg_out_degree", 0)
    is_dag = net_stats.get("is_dag", False)

    items = []
    items.append(
        _finding(
            "mdi:graph",
            f"Network Graph: {nodes:,} customers connected by {edges:,} "
            f"financial relationships across {components} cluster(s).",
            "#00D4FF",
        )
    )
    items.append(
        _finding(
            "mdi:hub-outline",
            f"Average connectivity: {avg_in} inbound, {avg_out} outbound "
            f"connections per customer. Network "
            f"{'is acyclic (tree-like)' if is_dag else 'contains circular patterns'}.",
            "#9D4EDD",
        )
    )

    # Top-connected nodes (PageRank)
    try:
        important = pipeline.get_important_nodes(top_n=10)
        if important is not None and isinstance(important, pd.DataFrame) and len(important) > 0:
            for _, imp in important.head(3).iterrows():
                nid = str(imp.get("node_id", ""))
                pr = imp.get("pagerank", 0) or 0
                cust = nid.replace("CUST-", "Customer #") if "CUST-" in nid else nid
                items.append(
                    _finding(
                        "mdi:star-circle",
                        f"{cust} — Network influence score: {pr:.4f}. "
                        f"This customer is among the most structurally "
                        f"important in the network.",
                        "#FFD700",
                    )
                )
    except Exception:
        pass

    # Network density insight
    density = net_stats.get("density", 0)
    if density:
        items.append(
            _finding(
                "mdi:chart-scatter-plot",
                f"Network density: {density:.6f}. "
                f"{'Dense network — many cross-connections warrant scrutiny.' if density > 0.01 else 'Sparse network — typical of standard banking relationships.'}",
                "#E040FB",
            )
        )

    return html.Div(
        items, style={**_GLASS, "padding": "1.2rem 1.5rem", "borderLeft": "4px solid #E040FB"}
    )


def _build_analytics_coverage(analytics):
    """Section 9: Detection methods coverage."""
    if not analytics:
        return _pending("No analytics results available yet.")

    cards = []
    for fam_key, fam_df in analytics.items():
        biz = FAMILY_BUSINESS_NAMES.get(fam_key)
        if biz:
            name, desc, icon = biz
        else:
            name = fam_key.replace("_", " ").title()
            desc = "Analytical detection module."
            icon = "mdi:chart-box-outline"

        records = len(fam_df) if fam_df is not None and hasattr(fam_df, "__len__") else 0
        status_color = "#00E676" if records > 0 else "#FF1744"

        stat_line = ""
        if fam_df is not None and isinstance(fam_df, pd.DataFrame) and len(fam_df) > 0:
            score_cols = [
                c
                for c in fam_df.columns
                if c not in ("node_id", "risk_tier")
                and fam_df[c].dtype in ("float64", "float32", "int64")
            ]
            if score_cols:
                mc = score_cols[0]
                mn = round(float(fam_df[mc].mean()), 2)
                mx = round(float(fam_df[mc].max()), 2)
                sd = fam_df[mc].std()
                outliers = int((fam_df[mc] > mn + 2 * sd).sum()) if sd > 0 else 0
                stat_line = (
                    f"{records:,} scored · avg: {mn} · " f"max: {mx} · {outliers} outlier(s)"
                )
            else:
                stat_line = f"{records:,} customers scored"
        else:
            stat_line = "No data in this run"

        cards.append(
            html.Div(
                [
                    html.Div(
                        [
                            DashIconify(icon=icon, width=18, color=status_color),
                            html.Div(
                                name,
                                style={
                                    "color": "#E2E8F0",
                                    "fontWeight": "600",
                                    "fontSize": "0.82rem",
                                },
                            ),
                        ],
                        style={"display": "flex", "gap": "0.5rem", "alignItems": "center"},
                    ),
                    html.Div(
                        desc,
                        style={
                            "color": "#94A3B8",
                            "fontSize": "0.7rem",
                            "lineHeight": "1.4",
                            "marginTop": "0.3rem",
                            "marginLeft": "1.6rem",
                        },
                    ),
                    html.Div(
                        stat_line,
                        style={
                            "color": status_color,
                            "fontSize": "0.72rem",
                            "fontWeight": "600",
                            "marginTop": "0.3rem",
                            "marginLeft": "1.6rem",
                        },
                    ),
                ],
                style={
                    "background": "rgba(255,255,255,0.02)",
                    "border": "1px solid rgba(255,255,255,0.06)",
                    "borderRadius": "8px",
                    "padding": "0.8rem 1rem",
                },
            )
        )

    # Analytics coverage chart — bar of records per family
    fam_names = []
    fam_counts = []
    for fk, fd in analytics.items():
        biz = FAMILY_BUSINESS_NAMES.get(fk)
        short_name = biz[0].split(" ")[0] if biz else fk[:10]
        fam_names.append(short_name)
        fam_counts.append(len(fd) if fd is not None and hasattr(fd, "__len__") else 0)

    fig_cov = go.Figure(
        go.Bar(
            x=fam_names,
            y=fam_counts,
            text=[f"{v:,}" for v in fam_counts],
            textposition="outside",
            textfont=dict(color="white", size=10),
            marker=dict(color="#00D4FF", line=dict(color="rgba(255,255,255,0.1)", width=1)),
        )
    )
    fig_cov.update_layout(
        **DARK_CHART, xaxis_title="Detection Method", yaxis_title="Customers Scored", height=250
    )

    return html.Div(
        [
            dmc.SimpleGrid(cols={"base": 1, "sm": 2}, spacing="sm", children=cards),
            html.Div(
                [
                    html.Div(
                        "Detection Coverage Across Methods",
                        style={
                            "color": "#94A3B8",
                            "fontSize": "0.75rem",
                            "fontWeight": "600",
                            "textTransform": "uppercase",
                            "letterSpacing": "1px",
                            "marginTop": "1rem",
                            "marginBottom": "0.3rem",
                            "textAlign": "center",
                        },
                    ),
                    dcc.Graph(
                        figure=fig_cov, config={"displayModeBar": False}, style={"height": "250px"}
                    ),
                ],
                style=_GLASS,
            ),
            html.Div(
                [
                    _stat("Active Methods", f"{len(analytics)}", "#00D4FF"),
                    _stat(
                        "Total Scores Produced",
                        f"{sum(len(df) for df in analytics.values() if df is not None and hasattr(df, '__len__')):,}",
                        "#9D4EDD",
                    ),
                ],
                style={"marginTop": "0.8rem"},
            ),
        ]
    )


def _build_investigation_queue(pipeline):
    """Section 10: Investigation priority queue."""
    inv_queue = _safe(lambda: pipeline.get_investigation_queue())
    if inv_queue is None or not isinstance(inv_queue, pd.DataFrame) or len(inv_queue) == 0:
        return _pending("Investigation queue will populate after pipeline execution.")

    total_q = len(inv_queue)
    iq_p1 = int((inv_queue["risk_tier"] == "P1").sum()) if "risk_tier" in inv_queue.columns else 0
    iq_p2 = int((inv_queue["risk_tier"] == "P2").sum()) if "risk_tier" in inv_queue.columns else 0
    iq_p3 = int((inv_queue["risk_tier"] == "P3").sum()) if "risk_tier" in inv_queue.columns else 0
    iq_p4 = int((inv_queue["risk_tier"] == "P4").sum()) if "risk_tier" in inv_queue.columns else 0

    # Top 5 table
    top5 = inv_queue.head(5)
    rows = []
    for qi, (_, qr) in enumerate(top5.iterrows(), 1):
        qt = qr.get("risk_tier", "P4")
        qs = float(qr.get("risk_score", 0))
        qn = str(qr.get("node_id", ""))
        qn_lbl = qn.replace("CUST-", "Customer #") if "CUST-" in qn else qn
        qc = TIER_COLORS.get(qt, "#64748B")
        q_deg = int(qr.get("degree", 0)) if "degree" in qr.index else 0
        rows.append(
            html.Tr(
                [
                    html.Td(str(qi), style={"color": "#94A3B8", "textAlign": "center"}),
                    html.Td(qn_lbl, style={"color": "#E2E8F0", "fontWeight": "600"}),
                    html.Td(
                        f"{qs:.1f}", style={"color": qc, "fontWeight": "700", "textAlign": "center"}
                    ),
                    html.Td(qt, style={"color": qc, "textAlign": "center"}),
                    html.Td(f"{q_deg}", style={"color": "#94A3B8", "textAlign": "center"}),
                ],
                style={"borderBottom": "1px solid rgba(255,255,255,0.05)"},
            )
        )

    # Queue composition pie chart
    q_labels = ["P1", "P2", "P3", "P4"]
    q_vals = [iq_p1, iq_p2, iq_p3, iq_p4]
    q_colors = [TIER_COLORS[t] for t in q_labels]
    fig_q = go.Figure(
        go.Pie(
            labels=q_labels,
            values=q_vals,
            hole=0.6,
            marker=dict(colors=q_colors, line=dict(color="rgba(10,14,23,0.8)", width=2)),
            textfont=dict(color="white", size=11),
            textinfo="label+value",
            hovertemplate="<b>%{label}</b><br>Count: %{value:,}<br>%{percent}<extra></extra>",
        )
    )
    fig_q.update_layout(
        **DARK_CHART,
        annotations=[
            dict(
                text=f"{total_q:,}<br>Queue",
                x=0.5,
                y=0.5,
                font=dict(size=14, color="white"),
                showarrow=False,
            )
        ],
        showlegend=False,
        height=250,
    )

    return html.Div(
        [
            dmc.SimpleGrid(
                cols={"base": 2, "lg": 4},
                spacing="sm",
                children=[
                    _kpi("mdi:clipboard-list-outline", "Queue Size", f"{total_q:,}", "#FF6B6B"),
                    _kpi("mdi:alert-octagon", "P1 in Queue", f"{iq_p1}", "#FF1744"),
                    _kpi("mdi:alert", "P2 in Queue", f"{iq_p2}", "#FF9800"),
                    _kpi("mdi:shield-half-full", "P3/P4 in Queue", f"{iq_p3 + iq_p4}", "#00E676"),
                ],
            ),
            dmc.SimpleGrid(
                cols={"base": 1, "sm": 2},
                spacing="md",
                style={"marginTop": "1rem"},
                children=[
                    html.Div(
                        [
                            html.Div(
                                "Top 5 — Highest Priority",
                                style={
                                    "color": "#94A3B8",
                                    "fontSize": "0.75rem",
                                    "fontWeight": "600",
                                    "textTransform": "uppercase",
                                    "letterSpacing": "1px",
                                    "marginBottom": "0.5rem",
                                },
                            ),
                            html.Table(
                                [
                                    html.Thead(
                                        html.Tr(
                                            [
                                                html.Th(
                                                    "#",
                                                    style={
                                                        **_TH,
                                                        "textAlign": "center",
                                                        "width": "40px",
                                                    },
                                                ),
                                                html.Th("Customer", style=_TH),
                                                html.Th(
                                                    "Score", style={**_TH, "textAlign": "center"}
                                                ),
                                                html.Th(
                                                    "Tier", style={**_TH, "textAlign": "center"}
                                                ),
                                                html.Th(
                                                    "Connections",
                                                    style={**_TH, "textAlign": "center"},
                                                ),
                                            ]
                                        )
                                    ),
                                    html.Tbody(rows),
                                ],
                                style={"width": "100%", "borderCollapse": "collapse"},
                            ),
                        ]
                    ),
                    html.Div(
                        [
                            html.Div(
                                "Queue Composition by Risk Tier",
                                style={
                                    "color": "#94A3B8",
                                    "fontSize": "0.75rem",
                                    "fontWeight": "600",
                                    "textTransform": "uppercase",
                                    "letterSpacing": "1px",
                                    "marginBottom": "0.3rem",
                                    "textAlign": "center",
                                },
                            ),
                            dcc.Graph(
                                figure=fig_q,
                                config={"displayModeBar": False},
                                style={"height": "250px"},
                            ),
                        ]
                    ),
                ],
            ),
        ],
        style=_GLASS,
    )


def _build_pipeline_status(pipeline, meta):
    """Section 11: Pipeline stages & data quality."""
    stages = getattr(pipeline, "stage_results", []) or []
    tables = getattr(pipeline, "tables", {}) or {}
    table_names = list(tables.keys())
    duration_sec = float(meta.get("duration_sec", 0) or 0)
    dur_str = f"{duration_sec:.1f}s" if duration_sec < 60 else f"{duration_sec/60:.1f}min"

    # DQ check
    dq_pass = True
    try:
        dq = pipeline.get_dq_reports()
        if isinstance(dq, dict):
            dq_pass = dq.get("overall_pass", True)
    except Exception:
        pass

    stage_rows = []
    for s in stages:
        s_status = "✓ PASS" if s.success else "⚠ FAILED"
        s_color = "#00E676" if s.success else "#FF9800"
        s_dur = f"{s.duration_ms / 1000:.1f}s" if s.duration_ms else "—"
        s_recs = f"{s.records_in:,} → {s.records_out:,}" if s.records_in else "—"
        stage_rows.append(
            html.Tr(
                [
                    html.Td(s.name, style={"color": "#E2E8F0"}),
                    html.Td(
                        s_status,
                        style={"color": s_color, "fontWeight": "600", "textAlign": "center"},
                    ),
                    html.Td(s_dur, style={"color": "#94A3B8", "textAlign": "center"}),
                    html.Td(s_recs, style={"color": "#94A3B8", "textAlign": "center"}),
                ],
                style={"borderBottom": "1px solid rgba(255,255,255,0.05)"},
            )
        )

    stages_completed = sum(1 for s in stages if s.success)
    stages_total = len(stages)

    # Alert count
    alert_count = 0
    if "alert" in tables and isinstance(tables["alert"], pd.DataFrame):
        alert_count = len(tables["alert"])
    total_records = sum(len(df) for df in tables.values() if isinstance(df, pd.DataFrame))

    return html.Div(
        [
            dmc.SimpleGrid(
                cols={"base": 2, "sm": 3, "lg": 6},
                spacing="sm",
                children=[
                    _kpi(
                        "mdi:play-circle-outline",
                        "Pipeline Run",
                        f"#{meta.get('run_id', getattr(pipeline, 'run_version', '?'))}",
                        "#00D4FF",
                        f"Completed in {dur_str}",
                    ),
                    _kpi(
                        "mdi:check-decagram",
                        "Stages Passed",
                        f"{stages_completed}/{stages_total}",
                        "#00E676" if stages_completed == stages_total else "#FF9800",
                        "All data processing stages",
                    ),
                    _kpi(
                        "mdi:database-import-outline",
                        "Data Ingested",
                        f"{total_records:,}",
                        "#9D4EDD",
                        f"{len(table_names)} tables",
                    ),
                    _kpi(
                        "mdi:radar",
                        "Risk Signals",
                        (
                            f"{int(getattr(pipeline, '_p1_count', 0)) + int(getattr(pipeline, '_p2_count', 0))}"
                            if hasattr(pipeline, "_p1_count")
                            else "—"
                        ),
                        "#FF1744",
                        "P1 + P2 customers",
                    ),
                    _kpi(
                        "mdi:shield-alert-outline",
                        "Alerts Ingested",
                        f"{alert_count:,}",
                        "#FF9800",
                        "From alert table",
                    ),
                    _kpi(
                        "mdi:check-circle-outline",
                        "Data Quality",
                        "PASS" if dq_pass else "REVIEW",
                        "#00E676" if dq_pass else "#FF9800",
                        "All validation checks",
                    ),
                ],
            ),
            (
                html.Div(
                    [
                        html.Div(
                            "Pipeline Stage Results",
                            style={
                                "color": "#94A3B8",
                                "fontSize": "0.75rem",
                                "fontWeight": "600",
                                "textTransform": "uppercase",
                                "letterSpacing": "1px",
                                "marginTop": "1rem",
                                "marginBottom": "0.5rem",
                            },
                        ),
                        html.Table(
                            [
                                html.Thead(
                                    html.Tr(
                                        [
                                            html.Th("Pipeline Stage", style=_TH),
                                            html.Th("Status", style={**_TH, "textAlign": "center"}),
                                            html.Th(
                                                "Duration", style={**_TH, "textAlign": "center"}
                                            ),
                                            html.Th(
                                                "Records", style={**_TH, "textAlign": "center"}
                                            ),
                                        ]
                                    )
                                ),
                                html.Tbody(stage_rows),
                            ],
                            style={"width": "100%", "borderCollapse": "collapse"},
                        ),
                    ]
                )
                if stage_rows
                else html.Div()
            ),
            html.Div(
                [
                    _stat("Total Duration", dur_str, "#00D4FF"),
                    _stat(
                        "Data Tables",
                        ", ".join(t.title() for t in table_names) if table_names else "None",
                        "#94A3B8",
                    ),
                ],
                style={"marginTop": "0.8rem"},
            ),
        ],
        style=_GLASS,
    )


def _build_recommendations(scored, lobbies, G, geo_countries):
    """Section 12: Recommendations & next steps."""
    total = len(scored)
    tier_counts = scored["risk_tier"].value_counts()
    p1 = int(tier_counts.get("P1", 0))
    p2 = int(tier_counts.get("P2", 0))

    flagged_flow = 0.0
    if G:
        for nid in G.nodes():
            a = G.nodes[nid]
            if a.get("risk_tier", "P4") in ("P1", "P2"):
                flagged_flow += float(a.get("in_flow", 0) or 0) + float(a.get("out_flow", 0) or 0)

    high_risk_countries = []
    if geo_countries:
        high_risk_countries = [
            c
            for c, v in geo_countries.items()
            if (v.get("high_risk_count", 0) or v.get("high_risk", 0)) > 0
        ]

    recs = []
    if p1 > 0:
        recs.append(
            _finding(
                "mdi:numeric-1-circle",
                f"IMMEDIATE: Initiate formal investigation for all {p1:,} P1 "
                f"customers. Consider precautionary account restrictions "
                f"pending investigation outcome.",
                "#FF1744",
            )
        )
    if p2 > 0:
        recs.append(
            _finding(
                "mdi:numeric-2-circle",
                f"30-DAY ACTION: Complete enhanced review for all {p2:,} P2 "
                f"customers. Schedule compliance reporting decisions for "
                f"any customer where the review reveals additional concerns.",
                "#FF9800",
            )
        )
    if lobbies:
        recs.append(
            _finding(
                "mdi:numeric-3-circle",
                f"INVESTIGATION: The {len(lobbies)} detected ring(s) should "
                f"each be assigned to a separate investigator for independent "
                f"compliance review. Cross-reference ring members with "
                f"existing case history.",
                "#9D4EDD",
            )
        )
    if flagged_flow > 1_000_000:
        recs.append(
            _finding(
                "mdi:numeric-4-circle",
                f"FINANCIAL EXPOSURE: ${flagged_flow:,.0f} in flagged "
                f"transaction volume warrants a board-level briefing on "
                f"potential regulatory exposure.",
                "#FFD600",
            )
        )
    if high_risk_countries:
        recs.append(
            _finding(
                "mdi:earth",
                f"GEO-RISK: Review exposure to {len(high_risk_countries)} "
                f"jurisdiction(s) with high-risk customers. Consider "
                f"enhanced country-level controls.",
                "#FF6B6B",
            )
        )
    recs.append(
        _finding(
            "mdi:calendar-clock",
            f"NEXT RUN: Schedule the next analysis cycle based on your "
            f"risk appetite. For this portfolio size ({total:,} customers), "
            f"quarterly runs are recommended at minimum.",
            "#00D4FF",
        )
    )
    recs.append(
        _finding(
            "mdi:file-document-check",
            "DOCUMENTATION: Archive this Executive Summary for regulatory "
            "examination readiness. Ensure all investigation decisions are "
            "recorded in the Audit Trail.",
            "#00E676",
        )
    )

    return html.Div(
        recs, style={**_GLASS, "padding": "1.2rem 1.5rem", "borderLeft": "4px solid #FFD700"}
    )


# =============================================================================
# v12.43: THREE NEW EXECUTIVE VIEWS — Strategic (CEO), Financial (CFO), Technical (CTO)
# =============================================================================


def _build_strategic_view(
    scored, G, lobbies, geo_countries, meta, pipeline, analytics, inv_queue_size
):
    """TAB 2 — Strategic Report: Risk posture, top escalations, trend
    arrows, regulatory exposure, and key decision points."""
    total = len(scored)
    tier_counts = scored["risk_tier"].value_counts()
    p1 = int(tier_counts.get("P1", 0))
    p2 = int(tier_counts.get("P2", 0))
    p3 = int(tier_counts.get("P3", 0))
    p4 = int(tier_counts.get("P4", 0))
    high_risk = p1 + p2
    high_risk_pct = round(high_risk / max(total, 1) * 100, 1)
    avg_score = round(float(scored["risk_score"].mean()), 1)
    max_score = round(float(scored["risk_score"].max()), 1)
    portfolio_health = max(0, round(100 - avg_score, 1))

    # --- Flagged flow ---
    flagged_flow = 0.0
    total_flow = 0.0
    if G:
        for nid in G.nodes():
            a = G.nodes[nid]
            inf = float(a.get("in_flow", 0) or 0)
            outf = float(a.get("out_flow", 0) or 0)
            total_flow += inf + outf
            if a.get("risk_tier", "P4") in ("P1", "P2"):
                flagged_flow += inf + outf

    sections = []

    # ── S1: Board Risk Posture ────────────────────────────────────────
    sections.append(
        _section(
            "mdi:shield-alert-outline",
            "Risk Posture",
            "High-level risk classification of the entire customer portfolio.",
            color="#FF1744",
        )
    )
    sections.append(
        _info(
            f"Of {total:,} customers analysed, {high_risk:,} ({high_risk_pct}%) "
            f"are classified as high-risk (P1 + P2). Portfolio Health Index: "
            f"{portfolio_health}/100 — {'CRITICAL' if portfolio_health < 40 else 'ELEVATED' if portfolio_health < 60 else 'MODERATE' if portfolio_health < 80 else 'HEALTHY'}.",
            accent="#FF1744",
        )
    )

    posture_cards = dmc.SimpleGrid(
        cols={"base": 2, "sm": 4},
        spacing="md",
        children=[
            _kpi(
                "mdi:alert-octagon",
                "P1 — Critical",
                f"{p1:,}",
                "#FF1744",
                f"{round(p1/max(total,1)*100,1)}% of portfolio",
            ),
            _kpi(
                "mdi:alert",
                "P2 — High Risk",
                f"{p2:,}",
                "#FF9800",
                f"{round(p2/max(total,1)*100,1)}% of portfolio",
            ),
            _kpi(
                "mdi:heart-pulse",
                "Portfolio Health",
                f"{portfolio_health}",
                "#00E676" if portfolio_health >= 60 else "#FF9800",
                "100 = no risk, 0 = all critical",
            ),
            _kpi(
                "mdi:account-group",
                "Total Analysed",
                f"{total:,}",
                "#00D4FF",
                f"Run #{meta.get('run_id', getattr(pipeline, 'run_version', '?'))}",
            ),
        ],
    )
    sections.append(html.Div(posture_cards, style={"marginBottom": "1.5rem"}))

    # Donut chart for risk posture
    tier_order = ["P1", "P2", "P3", "P4"]
    vals = [p1, p2, p3, p4]
    colors = [TIER_COLORS[t] for t in tier_order]
    fig_posture = go.Figure(
        go.Pie(
            labels=tier_order,
            values=vals,
            hole=0.7,
            marker=dict(colors=colors, line=dict(color="rgba(10,14,23,0.8)", width=2)),
            textfont=dict(color="white", size=13),
            textinfo="label+percent",
            hovertemplate="<b>%{label}</b><br>Count: %{value:,}<br>%{percent}<extra></extra>",
        )
    )
    fig_posture.update_layout(
        **DARK_CHART,
        showlegend=False,
        height=280,
        annotations=[
            dict(
                text=f"<b>{high_risk_pct}%</b><br>High Risk",
                x=0.5,
                y=0.5,
                font=dict(size=16, color="#FF6B6B"),
                showarrow=False,
            )
        ],
    )
    sections.append(
        html.Div(
            [
                dcc.Graph(
                    figure=fig_posture, config={"displayModeBar": False}, style={"height": "280px"}
                ),
            ],
            style={**_GLASS, "marginBottom": "1.5rem"},
        )
    )

    # ── S2: Top 5 Critical Escalations ────────────────────────────────
    sections.append(
        _section(
            "mdi:fire",
            "Top 5 Critical Escalations",
            "Customers requiring immediate attention and action.",
            color="#FF1744",
        )
    )
    sections.append(
        _info(
            "These are the highest-risk individuals in the portfolio. Each "
            "requires immediate action: formal investigation or regulatory "
            "filing decision.",
            accent="#FF1744",
        )
    )

    top5 = scored.nlargest(5, "risk_score")
    esc_rows = []
    for rank, (_, row) in enumerate(top5.iterrows(), 1):
        tier = row.get("risk_tier", "P4")
        score = float(row.get("risk_score", 0))
        nid = str(row.get("node_id", ""))
        label = nid.replace("CUST-", "Customer #") if "CUST-" in nid else nid
        color = TIER_COLORS.get(tier, "#64748B")
        nf = 0.0
        if G and nid in G.nodes:
            nf = float(G.nodes[nid].get("in_flow", 0) or 0) + float(
                G.nodes[nid].get("out_flow", 0) or 0
            )
        action = (
            "PROPER INVESTIGATE"
            if tier == "P1"
            else "ENHANCED REVIEW" if tier == "P2" else "ACTIVE MONITORING"
        )
        esc_rows.append(
            html.Tr(
                [
                    html.Td(
                        str(rank),
                        style={
                            "color": "#94A3B8",
                            "fontWeight": "700",
                            "textAlign": "center",
                            "width": "40px",
                        },
                    ),
                    html.Td(label, style={"color": "#E2E8F0", "fontWeight": "700"}),
                    html.Td(
                        f"{score:.1f}",
                        style={
                            "color": color,
                            "fontWeight": "800",
                            "textAlign": "center",
                            "fontSize": "1rem",
                        },
                    ),
                    html.Td(
                        tier, style={"color": color, "fontWeight": "700", "textAlign": "center"}
                    ),
                    html.Td(f"${nf:,.0f}", style={"color": "#FFD600", "textAlign": "right"}),
                    html.Td(
                        action, style={"color": color, "fontWeight": "600", "fontSize": "0.78rem"}
                    ),
                ],
                style={"borderBottom": "1px solid rgba(255,255,255,0.05)"},
            )
        )

    sections.append(
        html.Div(
            [
                html.Table(
                    [
                        html.Thead(
                            html.Tr(
                                [
                                    html.Th(
                                        "#", style={**_TH, "textAlign": "center", "width": "40px"}
                                    ),
                                    html.Th("Customer", style=_TH),
                                    html.Th("Risk Score", style={**_TH, "textAlign": "center"}),
                                    html.Th("Tier", style={**_TH, "textAlign": "center"}),
                                    html.Th(
                                        "Financial Exposure", style={**_TH, "textAlign": "right"}
                                    ),
                                    html.Th("Action Required", style=_TH),
                                ]
                            )
                        ),
                        html.Tbody(esc_rows),
                    ],
                    style={"width": "100%", "borderCollapse": "collapse"},
                ),
            ],
            style={**_GLASS, "marginBottom": "1.5rem", "borderLeft": "4px solid #FF1744"},
        )
    )

    # ── S3: Trend Indicators ──────────────────────────────────────────
    sections.append(
        _section(
            "mdi:trending-up",
            "Risk Trend Indicators",
            "Directional indicators showing whether portfolio risk is "
            "increasing or decreasing compared to previous analysis cycles.",
            color="#2196F3",
        )
    )

    history = _safe(lambda: pipeline.get_run_history())
    if history is not None and isinstance(history, pd.DataFrame) and len(history) >= 2:
        prev = history.iloc[-2] if len(history) >= 2 else None
        curr_customers = total
        prev_customers = int(prev.get("customers", 0)) if prev is not None else 0
        # Build trend arrows
        trend_items = []
        if prev is not None:
            cust_delta = curr_customers - prev_customers
            arrow = "↑" if cust_delta > 0 else "↓" if cust_delta < 0 else "→"
            color_t = "#FF9800" if cust_delta > 0 else "#00E676" if cust_delta < 0 else "#94A3B8"
            trend_items.append(
                _finding(
                    "mdi:account-multiple",
                    f"Customers Analysed: {curr_customers:,} "
                    f"({arrow} {abs(cust_delta):,} vs previous run)",
                    color_t,
                )
            )
        trend_items.append(
            _finding(
                "mdi:chart-line",
                f"Average Risk Score: {avg_score} — "
                f"{'Above critical threshold' if avg_score > 60 else 'Within acceptable range'}",
                "#FF9800" if avg_score > 60 else "#00E676",
            )
        )
        trend_items.append(
            _finding(
                "mdi:alert-octagon",
                f"P1 Customers: {p1:,} — "
                f"{'Requires senior management review' if p1 > max(total * 0.05, 1) else 'Within tolerances'}",
                "#FF1744" if p1 > max(total * 0.05, 1) else "#00E676",
            )
        )
        sections.append(
            html.Div(
                trend_items,
                style={
                    **_GLASS,
                    "padding": "1rem 1.3rem",
                    "borderLeft": "4px solid #2196F3",
                    "marginBottom": "1.5rem",
                },
            )
        )
    else:
        sections.append(
            _info(
                "Trend analysis requires at least 2 completed pipeline runs. "
                "Run the pipeline again to see directional indicators.",
                accent="#94A3B8",
            )
        )
        sections.append(html.Div(style={"marginBottom": "1.5rem"}))

    # ── S4: Regulatory Exposure ───────────────────────────────────────
    sections.append(
        _section(
            "mdi:gavel",
            "Regulatory Exposure Assessment",
            "Financial volume flowing through high-risk accounts and "
            "potential compliance implications.",
            color="#FFD600",
        )
    )
    sections.append(
        _info(
            "This section quantifies the dollar amount of transaction flow "
            "passing through P1 and P2 customers. This represents the "
            "institution's maximum potential regulatory exposure.",
            accent="#FFD600",
        )
    )
    reg_kpis = dmc.SimpleGrid(
        cols={"base": 2, "lg": 4},
        spacing="md",
        children=[
            _kpi(
                "mdi:cash-lock",
                "Flagged Volume (P1+P2)",
                f"${flagged_flow:,.0f}",
                "#FF1744",
                f"{round(flagged_flow/max(total_flow,1)*100,1)}% of total",
            ),
            _kpi(
                "mdi:cash-multiple",
                "Total Monitored Volume",
                f"${total_flow:,.0f}",
                "#00D4FF",
                "All customer transactions",
            ),
            _kpi(
                "mdi:account-group",
                "Rings Detected",
                f"{len(lobbies) if lobbies else 0}",
                "#9D4EDD",
                "Circular money-movement patterns",
            ),
            _kpi(
                "mdi:clipboard-list",
                "Investigation Queue",
                f"{inv_queue_size:,}",
                "#FF6B6B",
                "Customers awaiting review",
            ),
        ],
    )
    sections.append(html.Div(reg_kpis, style={"marginBottom": "1.5rem"}))

    # ── S5: CEO Decision Matrix ───────────────────────────────────────
    sections.append(
        _section(
            "mdi:clipboard-check-outline",
            "Decision Matrix",
            "Specific actions requiring senior management authorisation.",
            color="#FFD700",
        )
    )

    decisions = []
    if p1 > 0:
        decisions.append(
            html.Tr(
                [
                    html.Td(
                        "1", style={"color": "#FF1744", "fontWeight": "700", "textAlign": "center"}
                    ),
                    html.Td(
                        "Formal Investigation", style={"color": "#E2E8F0", "fontWeight": "600"}
                    ),
                    html.Td(
                        f"Investigate {p1} P1 account(s) immediately",
                        style={"color": "#94A3B8", "fontSize": "0.82rem"},
                    ),
                    html.Td(
                        "IMMEDIATE",
                        style={"color": "#FF1744", "fontWeight": "700", "fontSize": "0.78rem"},
                    ),
                ],
                style={"borderBottom": "1px solid rgba(255,255,255,0.05)"},
            )
        )
    if p2 > 0:
        decisions.append(
            html.Tr(
                [
                    html.Td(
                        "2", style={"color": "#FF9800", "fontWeight": "700", "textAlign": "center"}
                    ),
                    html.Td("Enhanced Review", style={"color": "#E2E8F0", "fontWeight": "600"}),
                    html.Td(
                        f"Assign {p2} P2 customer(s) for enhanced compliance review",
                        style={"color": "#94A3B8", "fontSize": "0.82rem"},
                    ),
                    html.Td(
                        "PRIORITY",
                        style={"color": "#FF9800", "fontWeight": "700", "fontSize": "0.78rem"},
                    ),
                ],
                style={"borderBottom": "1px solid rgba(255,255,255,0.05)"},
            )
        )
    if lobbies:
        decisions.append(
            html.Tr(
                [
                    html.Td(
                        "3", style={"color": "#9D4EDD", "fontWeight": "700", "textAlign": "center"}
                    ),
                    html.Td("Ring Investigation", style={"color": "#E2E8F0", "fontWeight": "600"}),
                    html.Td(
                        f"Assign investigators to {len(lobbies)} detected ring(s)",
                        style={"color": "#94A3B8", "fontSize": "0.82rem"},
                    ),
                    html.Td(
                        "PRIORITY",
                        style={"color": "#9D4EDD", "fontWeight": "700", "fontSize": "0.78rem"},
                    ),
                ],
                style={"borderBottom": "1px solid rgba(255,255,255,0.05)"},
            )
        )
    if flagged_flow > 500_000:
        decisions.append(
            html.Tr(
                [
                    html.Td(
                        "4", style={"color": "#FFD600", "fontWeight": "700", "textAlign": "center"}
                    ),
                    html.Td("Management Briefing", style={"color": "#E2E8F0", "fontWeight": "600"}),
                    html.Td(
                        f"Brief management on ${flagged_flow:,.0f} regulatory exposure",
                        style={"color": "#94A3B8", "fontSize": "0.82rem"},
                    ),
                    html.Td(
                        "NEXT MEETING",
                        style={"color": "#FFD600", "fontWeight": "700", "fontSize": "0.78rem"},
                    ),
                ],
                style={"borderBottom": "1px solid rgba(255,255,255,0.05)"},
            )
        )
    decisions.append(
        html.Tr(
            [
                html.Td(
                    str(len(decisions) + 1),
                    style={"color": "#00E676", "fontWeight": "700", "textAlign": "center"},
                ),
                html.Td("Archive & Schedule", style={"color": "#E2E8F0", "fontWeight": "600"}),
                html.Td(
                    "Archive this report and schedule next analysis cycle",
                    style={"color": "#94A3B8", "fontSize": "0.82rem"},
                ),
                html.Td(
                    "STANDARD",
                    style={"color": "#00E676", "fontWeight": "700", "fontSize": "0.78rem"},
                ),
            ],
            style={"borderBottom": "1px solid rgba(255,255,255,0.05)"},
        )
    )

    sections.append(
        html.Div(
            [
                html.Table(
                    [
                        html.Thead(
                            html.Tr(
                                [
                                    html.Th(
                                        "#", style={**_TH, "textAlign": "center", "width": "40px"}
                                    ),
                                    html.Th("Decision", style=_TH),
                                    html.Th("Description", style=_TH),
                                    html.Th("Timeline", style={**_TH, "textAlign": "center"}),
                                ]
                            )
                        ),
                        html.Tbody(decisions),
                    ],
                    style={"width": "100%", "borderCollapse": "collapse"},
                ),
            ],
            style={**_GLASS, "borderLeft": "4px solid #FFD700", "marginBottom": "1.5rem"},
        )
    )

    return html.Div(sections)


def _build_financial_view(scored, G, tables, meta, pipeline, analytics):
    """TAB 3 — Financial Report: Dollar-denominated exposure, compliance
    cost projections, flow analysis, and financial risk concentration."""
    total = len(scored)
    tier_counts = scored["risk_tier"].value_counts()
    p1 = int(tier_counts.get("P1", 0))
    p2 = int(tier_counts.get("P2", 0))
    p3 = int(tier_counts.get("P3", 0))
    p4 = int(tier_counts.get("P4", 0))

    # --- Financial flows ---
    total_in = 0.0
    total_out = 0.0
    flagged_flow = 0.0
    tier_flow = {"P1": 0.0, "P2": 0.0, "P3": 0.0, "P4": 0.0}
    if G:
        for nid in G.nodes():
            a = G.nodes[nid]
            inf = float(a.get("in_flow", 0) or 0)
            outf = float(a.get("out_flow", 0) or 0)
            total_in += inf
            total_out += outf
            tier = a.get("risk_tier", "P4")
            tier_flow[tier] = tier_flow.get(tier, 0) + inf + outf
            if tier in ("P1", "P2"):
                flagged_flow += inf + outf
    total_flow = total_in + total_out
    clean_flow = total_flow - flagged_flow

    sections = []

    # ── F1: Financial Exposure Dashboard ──────────────────────────────
    sections.append(
        _section(
            "mdi:cash-multiple",
            "Financial Exposure Dashboard",
            "Total transaction volumes monitored and the portion associated "
            "with high-risk customers.",
            color="#FFD600",
        )
    )
    sections.append(
        _info(
            "'Flagged Exposure' is the dollar amount passing through P1 and P2 "
            "customers — representing the institution's maximum potential "
            "regulatory liability. 'Clean Flow' is the monitored volume through "
            "customers with acceptable risk profiles.",
            accent="#FFD600",
        )
    )

    fin_kpis = dmc.SimpleGrid(
        cols={"base": 2, "lg": 4},
        spacing="md",
        children=[
            _kpi(
                "mdi:cash-multiple",
                "Total Monitored",
                f"${total_flow:,.0f}",
                "#00D4FF",
                "All customer transaction volume",
            ),
            _kpi(
                "mdi:cash-lock",
                "Flagged Exposure",
                f"${flagged_flow:,.0f}",
                "#FF1744" if flagged_flow > 0 else "#00E676",
                f"{round(flagged_flow/max(total_flow,1)*100,1)}% of total",
            ),
            _kpi(
                "mdi:cash-check",
                "Clean Flow",
                f"${clean_flow:,.0f}",
                "#00E676",
                "Through P3/P4 customers",
            ),
            _kpi(
                "mdi:cash-plus",
                "Net Flow (In − Out)",
                f"${abs(total_in - total_out):,.0f}",
                "#9D4EDD",
                f"{'Inbound surplus' if total_in > total_out else 'Outbound surplus'}",
            ),
        ],
    )
    sections.append(html.Div(fin_kpis, style={"marginBottom": "1.5rem"}))

    # ── F2: Exposure by Risk Tier ─────────────────────────────────────
    sections.append(
        _section(
            "mdi:chart-bar",
            "Exposure by Risk Tier",
            "Dollar amount flowing through customers in each risk tier.",
            color="#FF9800",
        )
    )

    tier_order = ["P1", "P2", "P3", "P4"]
    tier_vals = [tier_flow.get(t, 0) for t in tier_order]
    tier_colors = [TIER_COLORS[t] for t in tier_order]
    fig_tier_flow = go.Figure(
        go.Bar(
            x=tier_order,
            y=tier_vals,
            text=[f"${v:,.0f}" for v in tier_vals],
            textposition="outside",
            textfont=dict(color="white", size=11),
            marker=dict(color=tier_colors, line=dict(color="rgba(255,255,255,0.1)", width=1)),
        )
    )
    fig_tier_flow.update_layout(
        **DARK_CHART, height=300, xaxis_title="Risk Tier", yaxis_title="Transaction Volume ($)"
    )
    sections.append(
        html.Div(
            [
                dcc.Graph(
                    figure=fig_tier_flow,
                    config={"displayModeBar": False},
                    style={"height": "300px"},
                ),
            ],
            style={**_GLASS, "marginBottom": "1.5rem"},
        )
    )

    # Tier breakdown table
    tier_table_rows = []
    for t in tier_order:
        cnt = int(tier_counts.get(t, 0))
        flow = tier_flow.get(t, 0)
        pct_cust = round(cnt / max(total, 1) * 100, 1)
        pct_flow = round(flow / max(total_flow, 1) * 100, 1)
        avg_per = round(flow / max(cnt, 1), 0)
        tier_table_rows.append(
            html.Tr(
                [
                    html.Td(
                        html.Div(
                            [
                                html.Div(
                                    style={
                                        "width": "10px",
                                        "height": "10px",
                                        "borderRadius": "50%",
                                        "backgroundColor": TIER_COLORS[t],
                                        "display": "inline-block",
                                        "marginRight": "6px",
                                    }
                                ),
                                t,
                            ],
                            style={"display": "flex", "alignItems": "center"},
                        ),
                        style={"fontWeight": "700", "color": TIER_COLORS[t]},
                    ),
                    html.Td(f"{cnt:,}", style={"color": "#E2E8F0", "textAlign": "center"}),
                    html.Td(f"{pct_cust}%", style={"color": "#94A3B8", "textAlign": "center"}),
                    html.Td(f"${flow:,.0f}", style={"color": "#FFD600", "textAlign": "right"}),
                    html.Td(f"{pct_flow}%", style={"color": "#94A3B8", "textAlign": "center"}),
                    html.Td(f"${avg_per:,.0f}", style={"color": "#E2E8F0", "textAlign": "right"}),
                ],
                style={"borderBottom": "1px solid rgba(255,255,255,0.05)"},
            )
        )

    sections.append(
        html.Div(
            [
                html.Table(
                    [
                        html.Thead(
                            html.Tr(
                                [
                                    html.Th("Tier", style=_TH),
                                    html.Th("Customers", style={**_TH, "textAlign": "center"}),
                                    html.Th("% Portfolio", style={**_TH, "textAlign": "center"}),
                                    html.Th("$ Volume", style={**_TH, "textAlign": "right"}),
                                    html.Th("% of Flow", style={**_TH, "textAlign": "center"}),
                                    html.Th(
                                        "Avg per Customer", style={**_TH, "textAlign": "right"}
                                    ),
                                ]
                            )
                        ),
                        html.Tbody(tier_table_rows),
                    ],
                    style={"width": "100%", "borderCollapse": "collapse"},
                ),
            ],
            style={**_GLASS, "marginBottom": "1.5rem"},
        )
    )

    # ── F3: Transaction Flow Analysis ─────────────────────────────────
    sections.append(
        _section(
            "mdi:swap-horizontal-bold",
            "Transaction Flow Analysis",
            "Inbound vs outbound transaction volumes across the portfolio.",
            color="#2196F3",
        )
    )

    fig_flow = go.Figure()
    fig_flow.add_trace(
        go.Bar(
            x=["Inbound", "Outbound"],
            y=[total_in, total_out],
            text=[f"${total_in:,.0f}", f"${total_out:,.0f}"],
            textposition="outside",
            textfont=dict(color="white", size=12),
            marker=dict(
                color=["#00E676", "#FF6B6B"], line=dict(color="rgba(255,255,255,0.1)", width=1)
            ),
        )
    )
    fig_flow.update_layout(**DARK_CHART, height=260, yaxis_title="Transaction Volume ($)")
    sections.append(
        html.Div(
            [
                dcc.Graph(
                    figure=fig_flow, config={"displayModeBar": False}, style={"height": "260px"}
                ),
            ],
            style={**_GLASS, "marginBottom": "1.5rem"},
        )
    )

    # ── F4: Compliance Cost Projection ────────────────────────────────
    sections.append(
        _section(
            "mdi:calculator-variant",
            "Compliance Cost Projection",
            "Estimated investigation and compliance workload cost based on "
            "queue size and industry benchmarks.",
            color="#E040FB",
        )
    )
    sections.append(
        _info(
            "Industry average: ~$5,000 per enhanced investigation (analyst time, "
            "legal review, documentation). Regulatory filing costs additional. "
            "These are estimates for planning purposes.",
            accent="#E040FB",
        )
    )

    inv_q = _safe(lambda: pipeline.get_investigation_queue())
    queue_size = len(inv_q) if inv_q is not None and hasattr(inv_q, "__len__") else 0
    cost_per_inv = 5000
    total_cost = queue_size * cost_per_inv
    p1_cost = p1 * 15000  # P1 investigations are more expensive
    p2_cost = p2 * cost_per_inv
    narrative_filing_cost = p1 * 2500  # Estimated Narrative filing cost

    cost_kpis = dmc.SimpleGrid(
        cols={"base": 2, "lg": 4},
        spacing="md",
        children=[
            _kpi(
                "mdi:clipboard-list",
                "Investigation Queue",
                f"{queue_size:,}",
                "#FF6B6B",
                f"{p1} critical + {p2} high priority",
            ),
            _kpi(
                "mdi:currency-usd",
                "Est. Investigation Cost",
                f"${total_cost:,.0f}",
                "#E040FB",
                f"@ ${cost_per_inv:,} avg per case",
            ),
            _kpi(
                "mdi:file-document-alert",
                "P1 Investigation Cost",
                f"${p1_cost:,.0f}",
                "#FF1744",
                f"{p1} cases @ $15,000 ea (complex)",
            ),
            _kpi(
                "mdi:file-sign",
                "Est. Filing Cost",
                f"${narrative_filing_cost:,.0f}",
                "#FFD600",
                f"{p1} potential filings @ $2,500 ea",
            ),
        ],
    )
    sections.append(html.Div(cost_kpis, style={"marginBottom": "1.5rem"}))

    # ── F5: Top Financial Exposure Accounts ───────────────────────────
    sections.append(
        _section(
            "mdi:account-cash",
            "Top 10 Financial Exposure Accounts",
            "Customers with the highest transaction volumes who also carry "
            "elevated risk — the largest dollar-denominated exposure.",
            color="#FFD600",
        )
    )

    # Get flow data per customer
    if G:
        flow_data = []
        for nid in G.nodes():
            a = G.nodes[nid]
            inf = float(a.get("in_flow", 0) or 0)
            outf = float(a.get("out_flow", 0) or 0)
            tier = a.get("risk_tier", "P4")
            score = float(a.get("risk_score", 0) or 0)
            flow_data.append(
                {
                    "node_id": nid,
                    "total_flow": inf + outf,
                    "in_flow": inf,
                    "out_flow": outf,
                    "risk_tier": tier,
                    "risk_score": score,
                }
            )
        flow_df = pd.DataFrame(flow_data)
        # Filter to high-risk and sort by flow
        high_flow = flow_df[flow_df["risk_tier"].isin(["P1", "P2"])].nlargest(10, "total_flow")
        if len(high_flow) == 0:
            high_flow = flow_df.nlargest(10, "total_flow")

        exp_rows = []
        for rank, (_, r) in enumerate(high_flow.iterrows(), 1):
            nid = str(r["node_id"])
            label = nid.replace("CUST-", "Customer #") if "CUST-" in nid else nid
            tier = r["risk_tier"]
            color = TIER_COLORS.get(tier, "#64748B")
            exp_rows.append(
                html.Tr(
                    [
                        html.Td(
                            str(rank),
                            style={"color": "#94A3B8", "fontWeight": "700", "textAlign": "center"},
                        ),
                        html.Td(label, style={"color": "#E2E8F0", "fontWeight": "600"}),
                        html.Td(
                            f"${r['total_flow']:,.0f}",
                            style={"color": "#FFD600", "fontWeight": "700", "textAlign": "right"},
                        ),
                        html.Td(
                            f"${r['in_flow']:,.0f}",
                            style={"color": "#00E676", "textAlign": "right", "fontSize": "0.78rem"},
                        ),
                        html.Td(
                            f"${r['out_flow']:,.0f}",
                            style={"color": "#FF6B6B", "textAlign": "right", "fontSize": "0.78rem"},
                        ),
                        html.Td(
                            tier, style={"color": color, "fontWeight": "700", "textAlign": "center"}
                        ),
                        html.Td(
                            f"{r['risk_score']:.1f}", style={"color": color, "textAlign": "center"}
                        ),
                    ],
                    style={"borderBottom": "1px solid rgba(255,255,255,0.05)"},
                )
            )

        sections.append(
            html.Div(
                [
                    html.Table(
                        [
                            html.Thead(
                                html.Tr(
                                    [
                                        html.Th(
                                            "#",
                                            style={**_TH, "textAlign": "center", "width": "40px"},
                                        ),
                                        html.Th("Customer", style=_TH),
                                        html.Th("Total Flow", style={**_TH, "textAlign": "right"}),
                                        html.Th("Inbound", style={**_TH, "textAlign": "right"}),
                                        html.Th("Outbound", style={**_TH, "textAlign": "right"}),
                                        html.Th("Tier", style={**_TH, "textAlign": "center"}),
                                        html.Th("Score", style={**_TH, "textAlign": "center"}),
                                    ]
                                )
                            ),
                            html.Tbody(exp_rows),
                        ],
                        style={"width": "100%", "borderCollapse": "collapse"},
                    ),
                ],
                style={**_GLASS, "borderLeft": "4px solid #FFD600", "marginBottom": "1.5rem"},
            )
        )
    else:
        sections.append(_pending("Graph data required for flow analysis."))

    return html.Div(sections)


def _build_technical_view(pipeline, scored, analytics, meta, tables):
    """TAB 4 — Technical Report: Algorithm performance, graph health,
    data quality, system throughput, detection coverage, and technical
    recommendations."""
    import networkx as nx

    total = len(scored)
    G = getattr(pipeline, "G", None)
    stages = getattr(pipeline, "stage_results", []) or []
    total_ms = sum(r.duration_ms for r in stages) if stages else 0

    sections = []

    # ── T1: Algorithm Performance Dashboard ───────────────────────────
    sections.append(
        _section(
            "mdi:speedometer",
            "Algorithm Performance Dashboard",
            "Execution metrics for each of the 10 detection families — "
            "time, coverage, and hit rates.",
            color="#00D4FF",
        )
    )
    sections.append(
        _info(
            "Each detection family independently analyses the customer graph. "
            "'Hit Rate' = percentage of scored nodes with a non-zero signal. "
            "'Execution Time' = wall-clock milliseconds per family.",
            accent="#00D4FF",
        )
    )

    fam_metrics = {}
    if hasattr(pipeline, "get_analytics_status"):
        fam_info = pipeline.get_analytics_status()
        fam_metrics = fam_info.get("metrics", {})

    algo_rows = []
    fam_times = []
    fam_names_chart = []
    for fam_key in [
        "centrality",
        "community",
        "pathflow",
        "link_prediction",
        "anomaly",
        "temporal",
        "multi_layer",
        "structuring",
        "benfords",
        "motifs",
    ]:
        biz = FAMILY_BUSINESS_NAMES.get(fam_key)
        name = biz[0] if biz else fam_key.replace("_", " ").title()
        fam_df = analytics.get(fam_key) if analytics else None
        records = len(fam_df) if fam_df is not None and hasattr(fam_df, "__len__") else 0
        perf = fam_metrics.get(fam_key, {})
        time_ms = perf.get("time_ms", 0)
        status = perf.get("status", "computed" if records > 0 else "no data")

        # Hit rate: non-zero scores / total scored
        hit_rate = 0.0
        if fam_df is not None and isinstance(fam_df, pd.DataFrame) and len(fam_df) > 0:
            score_cols = [
                c
                for c in fam_df.columns
                if c not in ("node_id", "risk_tier")
                and fam_df[c].dtype in ("float64", "float32", "int64")
            ]
            if score_cols:
                # v16.56 BUG-FIX #4: use composite score_{fam_key} column from
                # scored_df to avoid PageRank-always->0 false 100% hit-rate
                _sc_col = f"score_{fam_key}"
                if scored is not None and isinstance(scored, pd.DataFrame) and _sc_col in scored.columns:
                    hits = (scored[_sc_col] > 0).sum()
                    hit_rate = round(hits / max(len(scored), 1) * 100, 1)
                else:
                    hits = (fam_df[score_cols[0]] > 0).sum()
                    hit_rate = round(hits / max(len(fam_df), 1) * 100, 1)

        status_color = "#00E676" if records > 0 else "#FF1744"
        if status == "cached":
            status_display = "⚡ CACHED"
            status_color = "#00BCD4"
        elif records > 0:
            status_display = "✓ ACTIVE"
        else:
            status_display = "✗ INACTIVE"

        fam_times.append(time_ms)
        fam_names_chart.append(name.split(" ")[0])

        algo_rows.append(
            html.Tr(
                [
                    html.Td(
                        name, style={"color": "#E2E8F0", "fontWeight": "600", "fontSize": "0.82rem"}
                    ),
                    html.Td(f"{records:,}", style={"color": "#00D4FF", "textAlign": "center"}),
                    html.Td(
                        f"{time_ms:.0f}ms" if time_ms > 0 else "—",
                        style={"color": "#FFD600", "textAlign": "center"},
                    ),
                    html.Td(
                        f"{hit_rate}%",
                        style={
                            "color": (
                                "#00E676"
                                if hit_rate > 50
                                else "#FF9800" if hit_rate > 0 else "#64748B"
                            ),
                            "textAlign": "center",
                            "fontWeight": "600",
                        },
                    ),
                    html.Td(
                        status_display,
                        style={
                            "color": status_color,
                            "fontWeight": "600",
                            "textAlign": "center",
                            "fontSize": "0.78rem",
                        },
                    ),
                ],
                style={"borderBottom": "1px solid rgba(255,255,255,0.05)"},
            )
        )

    sections.append(
        html.Div(
            [
                html.Table(
                    [
                        html.Thead(
                            html.Tr(
                                [
                                    html.Th("Detection Family", style=_TH),
                                    html.Th("Nodes Scored", style={**_TH, "textAlign": "center"}),
                                    html.Th("Exec Time", style={**_TH, "textAlign": "center"}),
                                    html.Th("Hit Rate", style={**_TH, "textAlign": "center"}),
                                    html.Th("Status", style={**_TH, "textAlign": "center"}),
                                ]
                            )
                        ),
                        html.Tbody(algo_rows),
                    ],
                    style={"width": "100%", "borderCollapse": "collapse"},
                ),
            ],
            style={**_GLASS, "marginBottom": "1rem"},
        )
    )

    # Execution time bar chart
    if any(t > 0 for t in fam_times):
        fig_perf = go.Figure(
            go.Bar(
                x=fam_names_chart,
                y=fam_times,
                text=[f"{t:.0f}ms" for t in fam_times],
                textposition="outside",
                textfont=dict(color="white", size=10),
                marker=dict(color="#00D4FF", line=dict(color="rgba(255,255,255,0.1)", width=1)),
            )
        )
        fig_perf.update_layout(
            **DARK_CHART,
            height=250,
            xaxis_title="Detection Family",
            yaxis_title="Execution Time (ms)",
        )
        sections.append(
            html.Div(
                [
                    html.Div(
                        "Family Execution Time Comparison",
                        style={
                            "color": "#94A3B8",
                            "fontSize": "0.75rem",
                            "fontWeight": "600",
                            "textTransform": "uppercase",
                            "letterSpacing": "1px",
                            "textAlign": "center",
                            "marginBottom": "0.3rem",
                        },
                    ),
                    dcc.Graph(
                        figure=fig_perf, config={"displayModeBar": False}, style={"height": "250px"}
                    ),
                ],
                style={**_GLASS, "marginBottom": "1.5rem"},
            )
        )
    else:
        sections.append(html.Div(style={"marginBottom": "1.5rem"}))

    # ── T2: Graph Infrastructure Health ───────────────────────────────
    sections.append(
        _section(
            "mdi:graph",
            "Graph Infrastructure Health",
            "Structural metrics of the customer relationship graph — "
            "the underlying data structure for all network analytics.",
            color="#9D4EDD",
        )
    )

    nodes = G.number_of_nodes() if G else total
    edges = G.number_of_edges() if G else 0
    density = round((edges / max(nodes * (nodes - 1), 1)) * 100, 4)
    components = 0
    largest_cc_size = 0
    avg_degree = round(edges * 2 / max(nodes, 1), 2)
    try:
        if G:
            components = nx.number_weakly_connected_components(G)
            largest_cc = max(nx.weakly_connected_components(G), key=len)
            largest_cc_size = len(largest_cc)
    except Exception:
        pass

    graph_kpis = dmc.SimpleGrid(
        cols={"base": 2, "sm": 3, "lg": 6},
        spacing="sm",
        children=[
            _kpi(
                "mdi:circle-double",
                "Total Entities",
                f"{nodes:,}",
                "#9D4EDD",
                "Customer entities in graph",
            ),
            _kpi(
                "mdi:transit-connection",
                "Financial Links",
                f"{edges:,}",
                "#00D4FF",
                "Financial relationships",
            ),
            _kpi(
                "mdi:percent",
                "Network Density",
                f"{density}%",
                "#2196F3",
                "Actual vs possible edges",
            ),
            _kpi(
                "mdi:set-split", "Components", f"{components}", "#FF9800", "Disconnected sub-graphs"
            ),
            _kpi(
                "mdi:hub-outline",
                "Avg Connections",
                f"{avg_degree}",
                "#E040FB",
                "Avg connections per node",
            ),
            _kpi(
                "mdi:relative-scale",
                "Largest Cluster",
                f"{largest_cc_size:,}",
                "#00E676",
                f"{round(largest_cc_size/max(nodes,1)*100,1)}% of graph",
            ),
        ],
    )
    sections.append(html.Div(graph_kpis, style={"marginBottom": "1.5rem"}))

    # ── T3: Data Quality Scorecard ────────────────────────────────────
    sections.append(
        _section(
            "mdi:database-check",
            "Data Quality Scorecard",
            "Per-table completeness and structural integrity of ingested data.",
            color="#00E676",
        )
    )

    dq_rows = []
    for tbl_name, tbl_df in (tables or {}).items():
        if not isinstance(tbl_df, pd.DataFrame) or len(tbl_df) == 0:
            continue
        rows_count = len(tbl_df)
        cols_count = len(tbl_df.columns)
        total_cells = rows_count * cols_count
        non_null = int(tbl_df.count().sum())
        completeness = round(non_null / max(total_cells, 1) * 100, 1)
        nulls = total_cells - non_null
        null_pct = round(nulls / max(total_cells, 1) * 100, 1)
        comp_color = (
            "#00E676" if completeness >= 95 else "#FFD600" if completeness >= 80 else "#FF1744"
        )
        dq_rows.append(
            html.Tr(
                [
                    html.Td(
                        tbl_name.replace("_", " ").title(),
                        style={"color": "#E2E8F0", "fontWeight": "600"},
                    ),
                    html.Td(f"{rows_count:,}", style={"color": "#00D4FF", "textAlign": "center"}),
                    html.Td(f"{cols_count}", style={"color": "#9D4EDD", "textAlign": "center"}),
                    html.Td(
                        f"{completeness}%",
                        style={"color": comp_color, "fontWeight": "700", "textAlign": "center"},
                    ),
                    html.Td(
                        f"{nulls:,} ({null_pct}%)",
                        style={
                            "color": "#FF9800" if null_pct > 5 else "#94A3B8",
                            "textAlign": "center",
                            "fontSize": "0.78rem",
                        },
                    ),
                ],
                style={"borderBottom": "1px solid rgba(255,255,255,0.05)"},
            )
        )

    if dq_rows:
        sections.append(
            html.Div(
                [
                    html.Table(
                        [
                            html.Thead(
                                html.Tr(
                                    [
                                        html.Th("Table", style=_TH),
                                        html.Th("Rows", style={**_TH, "textAlign": "center"}),
                                        html.Th("Columns", style={**_TH, "textAlign": "center"}),
                                        html.Th(
                                            "Completeness", style={**_TH, "textAlign": "center"}
                                        ),
                                        html.Th("Null Cells", style={**_TH, "textAlign": "center"}),
                                    ]
                                )
                            ),
                            html.Tbody(dq_rows),
                        ],
                        style={"width": "100%", "borderCollapse": "collapse"},
                    ),
                ],
                style={**_GLASS, "marginBottom": "1.5rem"},
            )
        )
    else:
        sections.append(_pending("No table data available for quality analysis."))

    # ── T4: Pipeline Throughput Analysis ──────────────────────────────
    sections.append(
        _section(
            "mdi:timer-outline",
            "Pipeline Throughput Analysis",
            "Stage-by-stage execution timing and system throughput metrics.",
            color="#FFD600",
        )
    )

    total_secs = total_ms / 1000
    cust_per_sec = round(total / max(total_secs, 0.001), 1) if total_secs > 0 else 0
    edges_per_sec = round(edges / max(total_secs, 0.001), 0) if total_secs > 0 else 0

    throughput_kpis = dmc.SimpleGrid(
        cols={"base": 2, "lg": 4},
        spacing="md",
        children=[
            _kpi(
                "mdi:timer-outline",
                "Total Pipeline Time",
                f"{total_secs:.1f}s" if total_secs < 60 else f"{total_secs/60:.1f}m",
                "#FFD600",
                f"{len(stages)} stages executed",
            ),
            _kpi(
                "mdi:account-clock",
                "Throughput (Customers)",
                f"{cust_per_sec:,.1f}/s",
                "#00D4FF",
                "Customers processed per second",
            ),
            _kpi(
                "mdi:transit-connection",
                "Throughput (Edges)",
                f"{edges_per_sec:,.0f}/s",
                "#9D4EDD",
                "Relationships analysed per second",
            ),
            _kpi(
                "mdi:layers-triple",
                "Active Detectors",
                f"{sum(1 for v in (analytics or {}).values() if v is not None and len(v) > 0)}/10",
                "#00E676",
                "Detection families with output",
            ),
        ],
    )
    sections.append(html.Div(throughput_kpis, style={"marginBottom": "1rem"}))

    # Stage timing breakdown chart
    if stages:
        stage_names = [s.name for s in stages]
        stage_times = [s.duration_ms for s in stages]
        fig_stages = go.Figure(
            go.Bar(
                x=stage_names,
                y=stage_times,
                text=[f"{t:.0f}ms" for t in stage_times],
                textposition="outside",
                textfont=dict(color="white", size=10),
                marker=dict(
                    color=["#00D4FF" if s.success else "#FF1744" for s in stages],
                    line=dict(color="rgba(255,255,255,0.1)", width=1),
                ),
            )
        )
        fig_stages.update_layout(
            **DARK_CHART, height=250, xaxis_title="Pipeline Stage", yaxis_title="Duration (ms)"
        )
        sections.append(
            html.Div(
                [
                    html.Div(
                        "Stage-by-Stage Execution Time",
                        style={
                            "color": "#94A3B8",
                            "fontSize": "0.75rem",
                            "fontWeight": "600",
                            "textTransform": "uppercase",
                            "letterSpacing": "1px",
                            "textAlign": "center",
                            "marginBottom": "0.3rem",
                        },
                    ),
                    dcc.Graph(
                        figure=fig_stages,
                        config={"displayModeBar": False},
                        style={"height": "250px"},
                    ),
                ],
                style={**_GLASS, "marginBottom": "1.5rem"},
            )
        )
    else:
        sections.append(html.Div(style={"marginBottom": "1.5rem"}))

    # ── T5: Detection Coverage Matrix ─────────────────────────────────
    sections.append(
        _section(
            "mdi:view-grid-outline",
            "Detection Coverage Summary",
            "Which detection families produced actionable output and "
            "their contribution to the final risk scores.",
            color="#E040FB",
        )
    )

    cov_items = []
    total_scores = 0
    active_families = 0
    for fam_key, fam_df in (analytics or {}).items():
        biz = FAMILY_BUSINESS_NAMES.get(fam_key)
        name = biz[0] if biz else fam_key.replace("_", " ").title()
        records = len(fam_df) if fam_df is not None and hasattr(fam_df, "__len__") else 0
        active = records > 0
        if active:
            active_families += 1
            total_scores += records
        cov_items.append(
            _finding(
                "mdi:check-circle" if active else "mdi:close-circle",
                (
                    f"{name}: {'Active' if active else 'Inactive'} — " f"{records:,} nodes scored"
                    if active
                    else f"{name}: No output in this run"
                ),
                "#00E676" if active else "#FF1744",
            )
        )

    sections.append(
        html.Div(
            cov_items,
            style={
                **_GLASS,
                "padding": "1rem 1.3rem",
                "borderLeft": "4px solid #E040FB",
                "marginBottom": "1rem",
            },
        )
    )

    sections.append(
        html.Div(
            [
                _stat("Active Families", f"{active_families}/10", "#00E676"),
                _stat("Total Scores Produced", f"{total_scores:,}", "#00D4FF"),
                _stat(
                    "Avg per Family", f"{round(total_scores/max(active_families,1)):,}", "#9D4EDD"
                ),
            ],
            style={"marginBottom": "1.5rem"},
        )
    )

    # ── T6: Technical Recommendations ─────────────────────────────────
    sections.append(
        _section(
            "mdi:wrench-cog",
            "Technical Recommendations",
            "Auto-generated recommendations based on current system metrics.",
            color="#FF9800",
        )
    )

    tech_recs = []
    if total_secs > 120:
        tech_recs.append(
            _finding(
                "mdi:lightning-bolt",
                f"Pipeline took {total_secs:.0f}s — consider enabling sampling "
                f"for graphs with >{nodes} nodes to reduce execution time.",
                "#FF9800",
            )
        )
    if density > 0.1:
        tech_recs.append(
            _finding(
                "mdi:chart-scatter-plot",
                f"High graph density ({density}%) may cause slow community "
                f"detection. Consider edge pruning by weight threshold.",
                "#FFD600",
            )
        )
    if components > 10:
        tech_recs.append(
            _finding(
                "mdi:set-split",
                f"{components} disconnected components detected. Some may "
                f"represent data quality issues (orphan nodes).",
                "#2196F3",
            )
        )
    inactive = 10 - active_families
    if inactive > 3:
        tech_recs.append(
            _finding(
                "mdi:alert-decagram",
                f"{inactive} detection families produced no output. Check data "
                f"schema compatibility and minimum node requirements.",
                "#FF1744",
            )
        )
    # Data quality recommendation
    for tbl_name, tbl_df in (tables or {}).items():
        if isinstance(tbl_df, pd.DataFrame) and len(tbl_df) > 0:
            tc = len(tbl_df) * len(tbl_df.columns)
            nn = int(tbl_df.count().sum())
            comp = nn / max(tc, 1) * 100
            if comp < 80:
                tech_recs.append(
                    _finding(
                        "mdi:database-alert",
                        f"Table '{tbl_name}' has only {comp:.0f}% data completeness. "
                        f"Consider data cleansing before next run.",
                        "#FF9800",
                    )
                )
                break  # Only show worst table

    if not tech_recs:
        tech_recs.append(
            _finding(
                "mdi:check-decagram",
                "All systems operating within normal parameters. No immediate "
                "technical action required.",
                "#00E676",
            )
        )

    tech_recs.append(
        _finding(
            "mdi:calendar-clock",
            f"Current capacity: {cust_per_sec:.1f} customers/sec. "
            f"For portfolios exceeding {int(cust_per_sec * 300):,} customers, "
            f"consider parallel execution with increased thread pool.",
            "#00D4FF",
        )
    )

    sections.append(
        html.Div(
            tech_recs,
            style={
                **_GLASS,
                "padding": "1.2rem 1.5rem",
                "borderLeft": "4px solid #FF9800",
                "marginBottom": "1.5rem",
            },
        )
    )

    return html.Div(sections)


# =============================================================================
# CALLBACK — Auto-populate everything from pipeline state
# =============================================================================
@callback(
    Output("exec-timestamp", "children"),
    Output("exec-live-badge", "children"),
    Output("exec-scope-kpis", "children"),
    Output("exec-risk-overview", "children"),
    Output("exec-risk-charts", "children"),
    Output("exec-key-findings", "children"),
    Output("exec-top10-table", "children"),
    Output("exec-financial-exposure", "children"),
    Output("exec-lobby-summary", "children"),
    Output("exec-intelligence-insights", "children"),
    Output("exec-analytics-coverage", "children"),
    Output("exec-investigation-queue", "children"),
    Output("exec-pipeline-status", "children"),
    Output("exec-recommendations", "children"),
    # v12.43 — 3 new executive views
    Output("exec-strategic-content", "children"),
    Output("exec-financial-content", "children"),
    Output("exec-technical-content", "children"),
    Input("pipeline-state", "data"),
    Input("exec-init", "n_intervals"),
    Input("global-refresh-ts", "data"),  # v14.7 FIX-GAP4: sync on Global Refresh
    prevent_initial_call=False,
)
def update_executive_summary(_pipeline_state, _n_intervals, _grt):
    """
    Master callback — fires on pipeline-state change AND every 4s interval.
    Each section is built independently with its own error handling.
    If one section fails, all other sections still render properly.
    """
    N = 17  # number of outputs (14 original + 3 executive views)

    try:
        pipeline = get_pipeline()
    except Exception as e:
        log.error(f"Cannot access pipeline: {e}")
        err = _pending(f"Pipeline access error: {e}")
        return tuple(["", html.Div()] + [err] * (N - 2))

    # ── Base data ─────────────────────────────────────────────────────
    scored = pipeline.get_scored_df()  # v14.7 FIX-GAP6: consistent with all other pages
    G = getattr(pipeline, "G", None)
    meta = getattr(pipeline, "last_run_meta", {}) or {}
    tables = getattr(pipeline, "tables", {}) or {}

    # ── Live badge (always render) ────────────────────────────────────
    try:
        live_badge = _build_live_badge(pipeline)
    except Exception:
        live_badge = html.Div()

    # ── Guard: no data → show pending for all sections ────────────────
    if scored is None or len(scored) == 0:
        pending = _pending()
        try:
            ts = _build_timestamp(meta, pipeline) if meta.get("saved_at") else ""
        except Exception:
            ts = ""
        return tuple([ts, live_badge] + [pending] * (N - 2))

    # ── Ensure required columns ───────────────────────────────────────
    if "risk_score" not in scored.columns:
        scored["risk_score"] = 0.0
    if "risk_tier" not in scored.columns:
        scored["risk_tier"] = "P4"

    total = len(scored)

    # ── Extract shared data safely ────────────────────────────────────
    analytics = _safe(lambda: pipeline.get_analytics_results(), {}) or {}
    geo_data = _safe(lambda: pipeline.get_geo_risk_data(), {}) or {}
    geo_countries = geo_data.get("country_stats", {}) if isinstance(geo_data, dict) else {}
    lobbies = _safe(lambda: pipeline.detect_lobbies(), []) or []  # v15.16: dynamic
    inv_queue = _safe(lambda: pipeline.get_investigation_queue())
    inv_queue_size = (
        len(inv_queue) if inv_queue is not None and hasattr(inv_queue, "__len__") else 0
    )

    # ── Build each section independently ──────────────────────────────
    # 1. Timestamp
    try:
        timestamp = _build_timestamp(meta, pipeline)
    except Exception as e:
        log.error(f"Exec timestamp error: {e}")
        timestamp = html.Div(f"Report Time: {datetime.now():%Y-%m-%d %H:%M}")

    # 2. Scope KPIs
    try:
        scope_kpis = _build_scope_kpis(scored, G, tables, analytics, geo_countries, meta)
    except Exception as e:
        log.error(f"Exec scope error: {e}\n{traceback.format_exc()}")
        scope_kpis = _pending(f"Scope section error — {e}")

    # 3. Risk overview
    try:
        risk_overview = _build_risk_overview(scored, total)
    except Exception as e:
        log.error(f"Exec risk overview error: {e}")
        risk_overview = _pending(f"Risk overview error — {e}")

    # 4. Risk charts
    try:
        risk_charts = _build_risk_charts(scored, total)
    except Exception as e:
        log.error(f"Exec risk charts error: {e}")
        risk_charts = _pending(f"Risk charts error — {e}")

    # 5. Key findings
    try:
        key_findings = _build_key_findings(scored, G, lobbies, geo_countries, inv_queue_size)
    except Exception as e:
        log.error(f"Exec findings error: {e}")
        key_findings = _pending(f"Findings error — {e}")

    # 6. Top 10
    try:
        top10_table = _build_top10(scored, G)
    except Exception as e:
        log.error(f"Exec top10 error: {e}")
        top10_table = _pending(f"Top-10 table error — {e}")

    # 7. Financial exposure
    try:
        financial_exposure = _build_financial_exposure(G)
    except Exception as e:
        log.error(f"Exec financial error: {e}")
        financial_exposure = _pending(f"Financial exposure error — {e}")

    # 8. Lobby summary
    try:
        lobby_summary = _build_lobby_summary(lobbies)
    except Exception as e:
        log.error(f"Exec lobby error: {e}")
        lobby_summary = _pending(f"Ring summary error — {e}")

    # 9. Intelligence
    try:
        intelligence = _build_intelligence(scored, G, pipeline)
    except Exception as e:
        log.error(f"Exec intelligence error: {e}")
        intelligence = _pending(f"Intelligence error — {e}")

    # 10. Analytics coverage
    try:
        analytics_cov = _build_analytics_coverage(analytics)
    except Exception as e:
        log.error(f"Exec analytics error: {e}")
        analytics_cov = _pending(f"Analytics coverage error — {e}")

    # 11. Investigation queue
    try:
        investigation_q = _build_investigation_queue(pipeline)
    except Exception as e:
        log.error(f"Exec investigation error: {e}")
        investigation_q = _pending(f"Investigation queue error — {e}")

    # 12. Pipeline status
    try:
        pipeline_status = _build_pipeline_status(pipeline, meta)
    except Exception as e:
        log.error(f"Exec pipeline status error: {e}")
        pipeline_status = _pending(f"Pipeline status error — {e}")

    # 13. Recommendations
    try:
        recommendations = _build_recommendations(scored, lobbies, G, geo_countries)
    except Exception as e:
        log.error(f"Exec recommendations error: {e}")
        recommendations = _pending(f"Recommendations error — {e}")

    # 14. Strategic view (CEO)
    try:
        strategic_view = _build_strategic_view(
            scored, G, lobbies, geo_countries, meta, pipeline, analytics, inv_queue_size
        )
    except Exception as e:
        log.error(f"Exec strategic view error: {e}\n{traceback.format_exc()}")
        strategic_view = _pending(f"Strategic view error — {e}")

    # 15. Financial view (CFO)
    try:
        financial_view = _build_financial_view(scored, G, tables, meta, pipeline, analytics)
    except Exception as e:
        log.error(f"Exec financial view error: {e}\n{traceback.format_exc()}")
        financial_view = _pending(f"Financial view error — {e}")

    # 16. Technical view (CTO)
    try:
        technical_view = _build_technical_view(pipeline, scored, analytics, meta, tables)
    except Exception as e:
        log.error(f"Exec technical view error: {e}\n{traceback.format_exc()}")
        technical_view = _pending(f"Technical view error — {e}")

    return (
        timestamp,
        live_badge,
        scope_kpis,
        risk_overview,
        risk_charts,
        key_findings,
        top10_table,
        financial_exposure,
        lobby_summary,
        intelligence,
        analytics_cov,
        investigation_q,
        pipeline_status,
        recommendations,
        strategic_view,
        financial_view,
        technical_view,
    )


# ── EXPORT CALLBACK ───────────────────────────────────────────────────────────
@callback(
    Output("exec-download", "data"),
    Input("exec-export-csv", "n_clicks"),
    prevent_initial_call=True,
)
def export_exec_csv(_):
    """Export full scored DataFrame as CSV for compliance records."""
    pipeline = get_pipeline()
    scored = pipeline.get_scored_df()
    if scored is not None:
        return dcc.send_data_frame(scored.to_csv, "executive_summary_risk_scores.csv", index=False)
    return no_update


# ── PDF PRINT CALLBACK ──────────────────────────────────────────────────────────────────
clientside_callback(
    """function(n) {
        if (n) { window.print(); }
        return window.dash_clientside.no_update;
    }""",
    Output("exec-export-pdf", "n_clicks"),
    Input("exec-export-pdf", "n_clicks"),
    prevent_initial_call=True,
)
