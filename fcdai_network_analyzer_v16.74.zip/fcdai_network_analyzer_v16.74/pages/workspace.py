"""
FCDAI v12.4 - Investigation Workspace
=====================================
Pinboard for analysts: pin customers, add notes, export workspace PDF.
Registered at /workspace.
v12.4: Added unpin/save-note/export callbacks, localStorage persistence.
"""

import dash
from dash import html, dcc, callback, Input, Output, State, no_update, ctx
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import pandas as pd
from pathlib import Path
from datetime import datetime
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, PATHS, APP
from engine import get_pipeline
from utils.pii_guard import mask_value
from utils.logger import GlobalExceptionHandler, log_audit

dash.register_page(
    __name__,
    path="/workspace",
    name="Workspace",
    title=f"FCDAI v{APP.VERSION} | Investigation Workspace",
)

_GLASS = {
    "background": THEME.GLASS_BG,
    "backdropFilter": "blur(20px)",
    "border": f"1px solid {THEME.GLASS_BORDER}",
    "borderRadius": "12px",
    "padding": "1.25rem",
}

TIER_COLORS = {"P1": "#FF1744", "P2": "#FF9800", "P3": "#FFD600", "P4": "#00E676"}


def _get_db():
    from database import get_db

    return get_db()


def _pin_card(pin_data: dict) -> html.Div:
    """Render a pinned customer card."""
    nid = pin_data.get("node_id", "")
    tier = pin_data.get("risk_tier", "?")
    score = pin_data.get("risk_score", 0)
    typologies = pin_data.get("typologies", "None")
    note = pin_data.get("note", "")
    pinned_at = pin_data.get("pinned_at", "")
    tier_color = TIER_COLORS.get(tier, "#64748B")

    return html.Div(
        [
            # Card header
            html.Div(
                [
                    html.Div(
                        [
                            dmc.Badge(
                                tier,
                                size="sm",
                                variant="filled",
                                style={"background": tier_color, "color": "#fff"},
                            ),
                            html.Div(
                                [
                                    html.Span(
                                        mask_value(nid, "partial"),
                                        style={
                                            "color": THEME.TEXT_PRIMARY,
                                            "fontWeight": "600",
                                            "fontSize": "0.9rem",
                                            "marginLeft": "0.5rem",
                                        },
                                    ),
                                    *(
                                        [html.Div(
                                            pin_data.get("customer_name", ""),
                                            style={
                                                "color": "#94A3B8",
                                                "fontSize": "0.75rem",
                                                "marginLeft": "0.5rem",
                                            },
                                        )]
                                        if pin_data.get("customer_name") else []
                                    ),
                                ],
                            ),
                        ],
                        style={"display": "flex", "alignItems": "center"},
                    ),
                    dmc.ActionIcon(
                        DashIconify(icon="mdi:pin-off", width=16),
                        id={"type": "unpin-btn", "index": nid},
                        size="sm",
                        variant="subtle",
                        color="red",
                    ),
                ],
                style={
                    "display": "flex",
                    "justifyContent": "space-between",
                    "alignItems": "center",
                    "marginBottom": "0.75rem",
                },
            ),
            # Metrics
            dmc.SimpleGrid(
                cols=2,
                spacing="xs",
                style={"marginBottom": "0.75rem"},
                children=[
                    html.Div(
                        [
                            html.Div(
                                f"{float(score):.1f}",
                                style={
                                    "fontSize": "1.4rem",
                                    "fontWeight": "800",
                                    "color": tier_color,
                                },
                            ),
                            html.Div(
                                "Risk Score",
                                style={"color": THEME.TEXT_MUTED, "fontSize": "0.72rem"},
                            ),
                        ]
                    ),
                    html.Div(
                        [
                            html.Div(
                                (
                                    typologies[:20] + "..."
                                    if len(str(typologies)) > 20
                                    else str(typologies)
                                ),
                                style={
                                    "fontSize": "0.78rem",
                                    "color": THEME.TEXT_SECONDARY,
                                    "fontWeight": "600",
                                },
                            ),
                            html.Div(
                                "Typologies",
                                style={"color": THEME.TEXT_MUTED, "fontSize": "0.72rem"},
                            ),
                        ]
                    ),
                ],
            ),
            # Note
            dmc.Textarea(
                id={"type": "workspace-note", "index": nid},
                placeholder="Add investigation notes...",
                value=note,
                minRows=2,
                maxRows=4,
                styles={
                    "input": {
                        "background": "rgba(255,255,255,0.04)",
                        "border": "1px solid rgba(255,255,255,0.08)",
                        "color": THEME.TEXT_PRIMARY,
                        "fontSize": "0.8rem",
                    }
                },
            ),
            dmc.Button(
                "Save Note",
                id={"type": "save-note-btn", "index": nid},
                size="xs",
                variant="subtle",
                color="cyan",
                style={"marginTop": "0.4rem"},
                leftSection=DashIconify(icon="mdi:content-save", width=14),
            ),
            html.Div(
                f"Pinned: {pinned_at[:16] if pinned_at else ''}",
                style={"color": THEME.TEXT_MUTED, "fontSize": "0.7rem", "marginTop": "0.4rem"},
            ),
        ],
        style={
            **_GLASS,
            "borderLeft": f"3px solid {tier_color}",
            "padding": "1rem",
        },
    )


# ─── Layout ───────────────────────────────────────────────────────────────────

layout = html.Div(
    [
        dcc.Store(id="workspace-pins", storage_type="local", data=[]),
        # Header
        html.Div(
            [
                html.Div(
                    [
                        DashIconify(icon="mdi:pin-outline", width=36, color=THEME.PRIMARY),
                        html.Div(
                            [
                                html.H1(
                                    "Investigation Workspace",
                                    style={
                                        "margin": 0,
                                        "fontSize": "1.8rem",
                                        "fontWeight": "800",
                                        "background": f"linear-gradient(135deg, {THEME.PRIMARY}, {THEME.SECONDARY})",
                                        "WebkitBackgroundClip": "text",
                                        "WebkitTextFillColor": "transparent",
                                    },
                                ),
                                html.P(
                                    "Pin customers · Add notes · Export workspace",
                                    style={
                                        "margin": 0,
                                        "color": THEME.TEXT_MUTED,
                                        "fontSize": "0.8rem",
                                    },
                                ),
                            ]
                        ),
                    ],
                    style={"display": "flex", "alignItems": "center", "gap": "1rem"},
                ),
                html.Div(
                    [
                        dmc.Button(
                            "Export PDF",
                            id="workspace-export-btn",
                            size="sm",
                            leftSection=DashIconify(icon="mdi:file-pdf-box", width=16),
                            variant="subtle",
                            color="red",
                        ),
                        dmc.Button(
                            "Clear All",
                            id="workspace-clear-btn",
                            size="sm",
                            leftSection=DashIconify(icon="mdi:delete-sweep", width=16),
                            variant="subtle",
                            color="gray",
                        ),
                    ],
                    style={"display": "flex", "gap": "0.5rem", "alignItems": "center"},
                ),
            ],
            style={
                "display": "flex",
                "justifyContent": "space-between",
                "alignItems": "center",
                "marginBottom": "1.5rem",
            },
        ),
        # ── CEO Context Panel ─────────────────────────────────────────────────────
        html.Div(
            [
                html.Div(
                    [
                        html.Div(
                            [
                                DashIconify(
                                    icon="mdi:information-outline", width=18, color="#9D4EDD"
                                ),
                                html.Span(
                                    "What is the Investigation Workspace?",
                                    style={
                                        "color": "#9D4EDD",
                                        "fontWeight": "700",
                                        "fontSize": "0.85rem",
                                        "marginLeft": "0.4rem",
                                    },
                                ),
                            ],
                            style={
                                "display": "flex",
                                "alignItems": "center",
                                "marginBottom": "0.75rem",
                            },
                        ),
                        dmc.SimpleGrid(
                            cols=3,
                            spacing="md",
                            children=[
                                html.Div(
                                    [
                                        html.Div(
                                            "📋 Overview",
                                            style={
                                                "color": "#9D4EDD",
                                                "fontWeight": "700",
                                                "fontSize": "0.78rem",
                                                "marginBottom": "0.35rem",
                                            },
                                        ),
                                        html.P(
                                            "A collaborative investigation logbook. Analysts can pin any customer to this "
                                            "board, attach investigation notes, record findings, and export a full audit "
                                            "trail as a PDF for compliance files — all secured with masked customer IDs "
                                            "to protect data privacy.",
                                            style={
                                                "color": "rgba(255,255,255,0.75)",
                                                "fontSize": "0.78rem",
                                                "margin": 0,
                                                "lineHeight": "1.5",
                                            },
                                        ),
                                    ]
                                ),
                                html.Div(
                                    [
                                        html.Div(
                                            "💡 Why It Matters",
                                            style={
                                                "color": "#FFD600",
                                                "fontWeight": "700",
                                                "fontSize": "0.78rem",
                                                "marginBottom": "0.35rem",
                                            },
                                        ),
                                        html.P(
                                            "Investigations require documentation at every step. This workspace provides a "
                                            "structured, auditable record of who was reviewed, by whom, on what date, "
                                            "and what conclusion was reached — essential for internal audit, regulatory "
                                            "examination, and Narrative defence.",
                                            style={
                                                "color": "rgba(255,255,255,0.75)",
                                                "fontSize": "0.78rem",
                                                "margin": 0,
                                                "lineHeight": "1.5",
                                            },
                                        ),
                                    ]
                                ),
                                html.Div(
                                    [
                                        html.Div(
                                            "⚡ When to Act",
                                            style={
                                                "color": "#FF6B6B",
                                                "fontWeight": "700",
                                                "fontSize": "0.78rem",
                                                "marginBottom": "0.35rem",
                                            },
                                        ),
                                        html.P(
                                            "Pin customers immediately after any P1 risk flag or watchlist hit. "
                                            "Add notes within 24 hours of an investigation decision. "
                                            "Export the workspace PDF before any regulatory examination or "
                                            "internal audit to evidence a complete, timestamped investigation trail.",
                                            style={
                                                "color": "rgba(255,255,255,0.75)",
                                                "fontSize": "0.78rem",
                                                "margin": 0,
                                                "lineHeight": "1.5",
                                            },
                                        ),
                                    ]
                                ),
                            ],
                        ),
                        html.Div(
                            [
                                html.Span("⚫ ", style={"color": "#00E676", "fontSize": "0.65rem"}),
                                html.Span(
                                    "LIVE — Auto-updates with every pipeline run",
                                    style={
                                        "color": "#00E676",
                                        "fontSize": "0.72rem",
                                        "fontWeight": "600",
                                    },
                                ),
                            ],
                            style={
                                "marginTop": "0.75rem",
                                "display": "flex",
                                "alignItems": "center",
                                "gap": "0.25rem",
                            },
                        ),
                    ]
                ),
            ],
            style={
                "background": "rgba(157,78,221,0.04)",
                "border": "1px solid rgba(157,78,221,0.2)",
                "borderLeft": "4px solid #9D4EDD",
                "borderRadius": "10px",
                "padding": "1rem 1.25rem",
                "marginBottom": "1.5rem",
            },
        ),
        # Pin a customer
        html.Div(
            [
                html.Div(
                    [
                        DashIconify(icon="mdi:pin-plus", width=20, color=THEME.PRIMARY),
                        html.Span(
                            "Pin Customer to Workspace",
                            style={
                                "color": THEME.TEXT_PRIMARY,
                                "fontWeight": "600",
                                "marginLeft": "0.5rem",
                            },
                        ),
                    ],
                    style={"display": "flex", "alignItems": "center", "marginBottom": "0.75rem"},
                ),
                html.Div(
                    [
                        dmc.Select(
                            id="workspace-node-select",
                            placeholder="Search and select a customer...",
                            searchable=True,
                            data=[],
                            style={"flex": 1},
                            styles={
                                "input": {
                                    "background": "rgba(255,255,255,0.05)",
                                    "border": "1px solid rgba(255,255,255,0.1)",
                                    "color": "#E2E8F0",
                                }
                            },
                        ),
                        dmc.Button(
                            "Pin",
                            id="workspace-pin-btn",
                            size="md",
                            leftSection=DashIconify(icon="mdi:pin", width=16),
                            style={
                                "background": "rgba(0,212,255,0.1)",
                                "border": "1px solid rgba(0,212,255,0.3)",
                                "color": "#00D4FF",
                            },
                        ),
                    ],
                    style={"display": "flex", "gap": "0.75rem", "alignItems": "center"},
                ),
            ],
            style={**_GLASS, "marginBottom": "1.5rem"},
        ),
        dcc.Interval(id="workspace-init", interval=500, max_intervals=1),
        html.Div(id="workspace-notification"),
        # Pinboard
        html.Div(id="workspace-pinboard"),
        # Empty state
        html.Div(id="workspace-empty-state"),
        dcc.Download(id="workspace-download"),
    ],
    style={
        "padding": "1.5rem",
        "fontFamily": "'Inter', sans-serif",
        "background": THEME.DARK_BG,
        "minHeight": "100vh",
        "color": THEME.TEXT_PRIMARY,
    },
)


# ─── Callbacks ────────────────────────────────────────────────────────────────


@callback(
    Output("workspace-node-select", "data"),
    Input("workspace-init", "n_intervals"),
    Input("pipeline-state", "data"),
    Input("global-refresh-ts", "data"),
)
@GlobalExceptionHandler.wrap()
def populate_workspace_nodes(_init, _pipeline_state, _gr):
    pipeline = get_pipeline()
    scored_df = pipeline.get_scored_df()
    if scored_df is None or scored_df.empty:
        return []
    # v16.69: build name map from node/customer table
    _name_map = {}
    try:
        for _tbl_name in ("node", "customer"):
            _tbl = pipeline.tables.get(_tbl_name) if hasattr(pipeline, "tables") else None
            if _tbl is not None:
                _nc = next((c for c in ("customer_name", "name", "full_name", "entity_name") if c in _tbl.columns), None)
                _ni = next((c for c in ("node_id", "customer_id", "id") if c in _tbl.columns), None)
                if _nc and _ni:
                    _name_map = dict(zip(_tbl[_ni].astype(str), _tbl[_nc].astype(str)))
                    break
    except Exception:
        pass
    options = []
    for _, row in scored_df.head(500).iterrows():
        nid = str(row.get("node_id", ""))
        tier = str(row.get("risk_tier", ""))
        score = float(row.get("risk_score", 0))
        cust_name = _name_map.get(nid, "")
        if cust_name:
            label = f"{cust_name} ({mask_value(nid, 'partial')}) | {tier} | {score:.1f}"
        else:
            label = f"{mask_value(nid, 'partial')} | {tier} | {score:.1f}"
        options.append({"value": nid, "label": label})
    return options


@callback(
    Output("workspace-pins", "data"),
    Output("workspace-notification", "children"),
    Input("workspace-pin-btn", "n_clicks"),
    Input("workspace-clear-btn", "n_clicks"),
    Input({"type": "unpin-btn", "index": dash.ALL}, "n_clicks"),
    State("workspace-node-select", "value"),
    State("workspace-pins", "data"),
    prevent_initial_call=True,
)
@GlobalExceptionHandler.wrap()
def manage_pins(pin_click, clear_click, unpin_clicks, node_id, pins):
    triggered = ctx.triggered_id
    pins = pins or []

    if triggered == "workspace-clear-btn":
        log_audit("WORKSPACE_CLEARED", f"Cleared {len(pins)} pins")
        return [], dmc.Alert(
            "Workspace cleared.", color="gray", variant="light", style={"marginBottom": "1rem"}
        )

    # Handle unpin via pattern-matching callback
    if isinstance(triggered, dict) and triggered.get("type") == "unpin-btn":
        unpin_nid = triggered["index"]
        pins = [p for p in pins if p.get("node_id") != unpin_nid]
        log_audit("WORKSPACE_UNPIN", f"Unpinned {mask_value(str(unpin_nid), 'partial')}")
        return pins, dmc.Alert(
            f"Unpinned {mask_value(str(unpin_nid), 'partial')}",
            color="orange",
            variant="light",
            style={"marginBottom": "1rem"},
        )

    if triggered == "workspace-pin-btn" and node_id:
        # Check if already pinned
        if any(p.get("node_id") == node_id for p in pins):
            return pins, dmc.Alert(
                "Already pinned.", color="yellow", variant="light", style={"marginBottom": "1rem"}
            )

        pipeline = get_pipeline()
        scored_df = pipeline.get_scored_df()
        analytics = pipeline.get_analytics_results() or {}

        # v16.69: lookup customer name for the pin card
        _pin_name = ""
        try:
            for _tbl_name in ("node", "customer"):
                _tbl = pipeline.tables.get(_tbl_name) if hasattr(pipeline, "tables") else None
                if _tbl is not None:
                    _nc = next((c for c in ("customer_name", "name", "full_name", "entity_name") if c in _tbl.columns), None)
                    _ni = next((c for c in ("node_id", "customer_id", "id") if c in _tbl.columns), None)
                    if _nc and _ni:
                        _rows = _tbl[_tbl[_ni].astype(str) == node_id]
                        if len(_rows) > 0:
                            _pin_name = str(_rows.iloc[0][_nc])
                        break
        except Exception:
            pass
        pin_data = {
            "node_id": node_id,
            "customer_name": _pin_name,
            "risk_tier": "?",
            "risk_score": 0,
            "typologies": "None",
            "note": "",
            "pinned_at": datetime.now().isoformat(),
        }

        if scored_df is not None and "node_id" in scored_df.columns:
            matches = scored_df[scored_df["node_id"] == node_id]
            if len(matches) > 0:
                row = matches.iloc[0]
                pin_data["risk_tier"] = str(row.get("risk_tier", "?"))
                pin_data["risk_score"] = float(row.get("risk_score", 0))
                from utils.intelligence import tag_typologies

                tags = tag_typologies(row, analytics)
                pin_data["typologies"] = ", ".join(tags) if tags else "None"

        pins.append(pin_data)
        log_audit("WORKSPACE_PIN", f"Pinned {mask_value(node_id, 'partial')}")
        return pins, dmc.Alert(
            f"Pinned {mask_value(node_id, 'partial')}",
            color="green",
            variant="light",
            style={"marginBottom": "1rem"},
        )

    return pins, no_update


@callback(
    Output("workspace-pinboard", "children"),
    Output("workspace-empty-state", "children"),
    Input("workspace-pins", "data"),
)
def render_pinboard(pins):
    pins = pins or []
    if not pins:
        empty = html.Div(
            [
                DashIconify(icon="mdi:pin-outline", width=64, color="#1E293B"),
                html.P(
                    "No customers pinned yet.",
                    style={"color": THEME.TEXT_MUTED, "marginTop": "1rem"},
                ),
                html.P(
                    "Use the selector above to pin customers for investigation.",
                    style={"color": THEME.TEXT_MUTED, "fontSize": "0.85rem"},
                ),
            ],
            style={"textAlign": "center", "padding": "4rem"},
        )
        return html.Div(), empty

    cards = [_pin_card(p) for p in pins]
    grid = dmc.SimpleGrid(
        cols=3,
        spacing="md",
        children=cards,
    )
    return grid, html.Div()


# ─── Save Note Callback (HIGH-03) ───────────────────────────────────────────
@callback(
    Output("workspace-pins", "data", allow_duplicate=True),
    Output("workspace-notification", "children", allow_duplicate=True),
    Input({"type": "save-note-btn", "index": dash.ALL}, "n_clicks"),
    State({"type": "workspace-note", "index": dash.ALL}, "value"),
    State("workspace-pins", "data"),
    prevent_initial_call=True,
)
@GlobalExceptionHandler.wrap()
def save_workspace_note(clicks, notes, pins):
    """Persist note text back into the workspace-pins store (v12.4 fix)."""
    if not ctx.triggered_id or not isinstance(ctx.triggered_id, dict):
        return no_update, no_update
    nid = ctx.triggered_id.get("index")
    if not nid:
        return no_update, no_update
    pins = pins or []
    notes = notes or []
    # Pattern-matching ALL callbacks return values in the same DOM order as
    # the components. Pins are rendered in order, so pin[i] <-> notes[i].
    for i, pin in enumerate(pins):
        if pin.get("node_id") == nid and i < len(notes):
            pins[i]["note"] = notes[i] or ""
            log_audit("WORKSPACE_NOTE", f"Note saved for {mask_value(str(nid), 'partial')}")
            return pins, dmc.Alert(
                "Note saved.", color="green", variant="light", style={"marginBottom": "1rem"}
            )
    return no_update, no_update


# ─── Export PDF Callback (HIGH-03) ──────────────────────────────────────────
@callback(
    Output("workspace-download", "data"),
    Input("workspace-export-btn", "n_clicks"),
    State("workspace-pins", "data"),
    prevent_initial_call=True,
)
@GlobalExceptionHandler.wrap()
def export_workspace_pdf(n_clicks, pins):
    """Generate a simple PDF of the workspace pinboard."""
    if not pins:
        return no_update
    try:
        from fpdf import FPDF

        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 16)
        pdf.cell(0, 10, "FCDAI v12.43 - Investigation Workspace", ln=True, align="C")
        pdf.set_font("Helvetica", "", 10)
        pdf.cell(0, 8, f"Exported: {datetime.now().strftime('%Y-%m-%d %H:%M')}", ln=True, align="C")
        pdf.ln(8)

        for pin in pins:
            nid = mask_value(str(pin.get("node_id", "")), "partial")
            tier = pin.get("risk_tier", "?")
            score = float(pin.get("risk_score", 0))
            note = pin.get("note", "") or "(no notes)"
            typo = pin.get("typologies", "None")

            pdf.set_font("Helvetica", "B", 11)
            pdf.cell(0, 7, f"Customer: {nid}  |  Tier: {tier}  |  Score: {score:.1f}", ln=True)
            pdf.set_font("Helvetica", "", 9)
            pdf.cell(0, 6, f"Typologies: {typo}", ln=True)
            pdf.multi_cell(0, 5, f"Notes: {note}")
            pdf.ln(4)

        out_path = PATHS.EXPORTS / f"workspace_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        PATHS.EXPORTS.mkdir(parents=True, exist_ok=True)
        pdf.output(str(out_path))
        log_audit("WORKSPACE_EXPORT", f"Exported {len(pins)} pins to PDF")
        return dcc.send_file(str(out_path))
    except Exception as e:
        log_audit("WORKSPACE_EXPORT_ERROR", str(e))
        return no_update
