"""
FCDAI v12.4 - Intelligence Hub
================================
New page at /intelligence — all 5 intelligence features:
I1: Explainability, I2: Alert Dedup, I3: Typology Library,
I4: Watchlist Cross-Reference, I5: Threshold Tuning
"""

import dash
from dash import html, dcc, callback, Input, Output, State, no_update
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.graph_objects as go
import pandas as pd
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, PATHS, PIPELINE, APP
from engine import get_pipeline
from utils.intelligence import (
    get_top_features,
    apply_typologies,
    apply_watchlist_flags,
    preview_threshold_impact,
    apply_custom_thresholds,
    TYPOLOGY_DESCRIPTIONS,
)
from utils.pii_guard import mask_value
from utils.logger import GlobalExceptionHandler

dash.register_page(
    __name__,
    path="/intelligence",
    name="Intelligence",
    title=f"FCDAI v{APP.VERSION} | Intelligence Hub",
)

_GLASS = {
    "background": THEME.GLASS_BG,
    "backdropFilter": "blur(20px)",
    "border": f"1px solid {THEME.GLASS_BORDER}",
    "borderRadius": "12px",
    "padding": "1.25rem",
}

TIER_COLORS = {"P1": "#FF1744", "P2": "#FF9800", "P3": "#FFD600", "P4": "#00E676"}


def _section_header(icon, title, subtitle=""):
    return html.Div(
        [
            html.Div(
                [
                    DashIconify(icon=icon, width=24, color=THEME.PRIMARY),
                    html.H3(
                        title,
                        style={
                            "margin": 0,
                            "color": THEME.TEXT_PRIMARY,
                            "fontSize": "1.1rem",
                            "fontWeight": "700",
                        },
                    ),
                ],
                style={"display": "flex", "alignItems": "center", "gap": "0.6rem"},
            ),
            html.P(
                subtitle,
                style={
                    "margin": "0.25rem 0 0 2rem",
                    "color": THEME.TEXT_MUTED,
                    "fontSize": "0.8rem",
                },
            ),
        ],
        style={"marginBottom": "1rem"},
    )


# ─── Layout ───────────────────────────────────────────────────────────────────

layout = html.Div(
    [
        # Header
        html.Div(
            [
                html.Div(
                    [
                        DashIconify(icon="mdi:brain", width=36, color=THEME.PRIMARY),
                        html.Div(
                            [
                                html.H1(
                                    "Intelligence Hub",
                                    style={
                                        "margin": 0,
                                        "fontSize": "1.8rem",
                                        "fontWeight": "800",
                                        "background": f"linear-gradient(135deg, {THEME.PRIMARY}, {THEME.SECONDARY})",
                                        "WebkitBackgroundClip": "text",
                                        "WebkitTextFillColor": "transparent",
                                    },
                                ),
                                html.P(
                                    "Explainability · Deduplication · Typologies · Watchlist · Threshold Tuning",
                                    style={
                                        "margin": 0,
                                        "color": THEME.TEXT_MUTED,
                                        "fontSize": "0.8rem",
                                    },
                                ),
                            ]
                        ),
                    ],
                    style={"display": "flex", "alignItems": "center", "gap": "1rem"},
                ),
                dmc.Button(
                    "Refresh",
                    id="intel-refresh-btn",
                    size="sm",
                    leftSection=DashIconify(icon="mdi:refresh", width=16),
                    variant="subtle",
                    color="cyan",
                ),
            ],
            style={
                "display": "flex",
                "justifyContent": "space-between",
                "alignItems": "center",
                "marginBottom": "1.5rem",
            },
        ),
        dcc.Interval(id="intel-init", interval=500, max_intervals=1),
        # ── CEO Context Panel ─────────────────────────────────────────────────────
        html.Div(
            [
                html.Div(
                    [
                        html.Div(
                            [
                                DashIconify(
                                    icon="mdi:information-outline", width=18, color="#00D4FF"
                                ),
                                html.Span(
                                    "What is the Intelligence Hub?",
                                    style={
                                        "color": "#00D4FF",
                                        "fontWeight": "700",
                                        "fontSize": "0.85rem",
                                        "marginLeft": "0.4rem",
                                    },
                                ),
                            ],
                            style={
                                "display": "flex",
                                "alignItems": "center",
                                "marginBottom": "0.75rem",
                            },
                        ),
                        dmc.SimpleGrid(
                            cols=3,
                            spacing="md",
                            children=[
                                html.Div(
                                    [
                                        html.Div(
                                            "📋 Overview",
                                            style={
                                                "color": "#00D4FF",
                                                "fontWeight": "700",
                                                "fontSize": "0.78rem",
                                                "marginBottom": "0.35rem",
                                            },
                                        ),
                                        html.P(
                                            "Your AI-powered intelligence layer. Five automated tools explain "
                                            "why every risk score was assigned, eliminate duplicate alerts, "
                                            "identify AML typologies, cross-reference global watchlists, and "
                                            "let your compliance team fine-tune detection thresholds — all in one place.",
                                            style={
                                                "color": "rgba(255,255,255,0.75)",
                                                "fontSize": "0.78rem",
                                                "margin": 0,
                                                "lineHeight": "1.5",
                                            },
                                        ),
                                    ]
                                ),
                                html.Div(
                                    [
                                        html.Div(
                                            "💡 Why It Matters",
                                            style={
                                                "color": "#FFD600",
                                                "fontWeight": "700",
                                                "fontSize": "0.78rem",
                                                "marginBottom": "0.35rem",
                                            },
                                        ),
                                        html.P(
                                            "Regulators and audit committees require explainability — not just a score, but "
                                            'the reason behind it. This page answers the "why" question for every '
                                            "flagged customer, giving compliance officers the evidence they need to "
                                            "defend decisions confidently.",
                                            style={
                                                "color": "rgba(255,255,255,0.75)",
                                                "fontSize": "0.78rem",
                                                "margin": 0,
                                                "lineHeight": "1.5",
                                            },
                                        ),
                                    ]
                                ),
                                html.Div(
                                    [
                                        html.Div(
                                            "⚡ When to Act",
                                            style={
                                                "color": "#FF6B6B",
                                                "fontWeight": "700",
                                                "fontSize": "0.78rem",
                                                "marginBottom": "0.35rem",
                                            },
                                        ),
                                        html.P(
                                            "If Watchlist Cross-Reference shows any match: escalate immediately and "
                                            "notify the MLRO. If Threshold Tuning preview shows more than 20% of "
                                            "customers would be reclassified: review thresholds in a calibration meeting "
                                            "before the next pipeline run. Alert Deduplication results directly reduce "
                                            "investigation queue size.",
                                            style={
                                                "color": "rgba(255,255,255,0.75)",
                                                "fontSize": "0.78rem",
                                                "margin": 0,
                                                "lineHeight": "1.5",
                                            },
                                        ),
                                    ]
                                ),
                            ],
                        ),
                        html.Div(
                            [
                                html.Span("⚫ ", style={"color": "#00E676", "fontSize": "0.65rem"}),
                                html.Span(
                                    "LIVE — Auto-updates with every pipeline run",
                                    style={
                                        "color": "#00E676",
                                        "fontSize": "0.72rem",
                                        "fontWeight": "600",
                                    },
                                ),
                            ],
                            style={
                                "marginTop": "0.75rem",
                                "display": "flex",
                                "alignItems": "center",
                                "gap": "0.25rem",
                            },
                        ),
                    ]
                ),
            ],
            style={
                "background": "rgba(0,212,255,0.04)",
                "border": "1px solid rgba(0,212,255,0.15)",
                "borderLeft": "4px solid #00D4FF",
                "borderRadius": "10px",
                "padding": "1rem 1.25rem",
                "marginBottom": "1.5rem",
            },
        ),
        # Watchlist Alert Banner (hidden by default)
        html.Div(id="intel-watchlist-banner"),
        # ── Row 1: Typology Summary + Watchlist Hits ──────────────────────────────
        dmc.SimpleGrid(
            cols=2,
            spacing="md",
            style={"marginBottom": "1rem"},
            children=[
                # Typology Distribution
                html.Div(
                    [
                        _section_header(
                            "mdi:tag-multiple",
                            "Typology Distribution",
                            "AML pattern classification across all customers",
                        ),
                        dcc.Graph(
                            id="intel-typology-chart",
                            config={"displayModeBar": False},
                            style={"height": "220px"},
                        ),
                    ],
                    style=_GLASS,
                ),
                # Watchlist Summary
                html.Div(
                    [
                        _section_header(
                            "mdi:alert-octagon",
                            "Watchlist Cross-Reference",
                            "Customers matched against local watchlist",
                        ),
                        html.Div(id="intel-watchlist-summary"),
                    ],
                    style=_GLASS,
                ),
            ],
        ),
        # ── Row 2: Explainability ─────────────────────────────────────────────────
        html.Div(
            [
                _section_header(
                    "mdi:chart-bar",
                    "Risk Score Explainability",
                    "Select a customer to see which analytics families drove their risk score",
                ),
                dmc.SimpleGrid(
                    cols=2,
                    spacing="md",
                    children=[
                        html.Div(
                            [
                                dmc.Select(
                                    id="intel-node-select",
                                    placeholder="Select customer...",
                                    searchable=True,
                                    data=[],
                                    style={"marginBottom": "1rem"},
                                    styles={
                                        "input": {
                                            "background": "rgba(255,255,255,0.05)",
                                            "border": "1px solid rgba(255,255,255,0.1)",
                                            "color": "#E2E8F0",
                                        }
                                    },
                                ),
                                html.Div(id="intel-explain-details"),
                            ]
                        ),
                        dcc.Graph(
                            id="intel-explain-chart",
                            config={"displayModeBar": False},
                            style={"height": "260px"},
                        ),
                    ],
                ),
            ],
            style={**_GLASS, "marginBottom": "1rem"},
        ),
        # ── Row 3: Alert Dedup + Threshold Tuning ────────────────────────────────
        dmc.SimpleGrid(
            cols=2,
            spacing="md",
            style={"marginBottom": "1rem"},
            children=[
                # Alert Deduplication
                html.Div(
                    [
                        _section_header(
                            "mdi:content-duplicate",
                            "Alert Deduplication",
                            "NEW vs SEEN vs ESCALATED across pipeline runs",
                        ),
                        html.Div(id="intel-dedup-summary"),
                    ],
                    style=_GLASS,
                ),
                # Threshold Tuning
                html.Div(
                    [
                        _section_header(
                            "mdi:tune",
                            "Threshold Tuning",
                            "Adjust risk tier boundaries and preview impact",
                        ),
                        html.Div(
                            [
                                *[
                                    html.Div(
                                        [
                                            html.Div(
                                                [
                                                    dmc.Badge(
                                                        tier,
                                                        color={
                                                            "P1": "red",
                                                            "P2": "orange",
                                                            "P3": "yellow",
                                                            "P4": "green",
                                                        }[tier],
                                                        size="sm",
                                                    ),
                                                    html.Span(
                                                        f"Min score:",
                                                        style={
                                                            "color": THEME.TEXT_MUTED,
                                                            "fontSize": "0.8rem",
                                                            "marginLeft": "0.5rem",
                                                        },
                                                    ),
                                                ],
                                                style={
                                                    "display": "flex",
                                                    "alignItems": "center",
                                                    "marginBottom": "0.25rem",
                                                },
                                            ),
                                            dcc.Slider(
                                                id=f"thresh-{tier.lower()}",
                                                min=0,
                                                max=100,
                                                step=1,
                                                value={"P1": 80, "P2": 60, "P3": 40, "P4": 0}[tier],
                                                marks={0: "0", 50: "50", 100: "100"},
                                                tooltip={
                                                    "placement": "bottom",
                                                    "always_visible": False,
                                                },
                                            ),
                                        ],
                                        style={"marginBottom": "0.75rem"},
                                    )
                                    for tier in ["P1", "P2", "P3"]
                                ],
                                dmc.Button(
                                    "Preview Impact",
                                    id="thresh-preview-btn",
                                    size="sm",
                                    leftSection=DashIconify(icon="mdi:eye", width=16),
                                    style={
                                        "background": "rgba(0,212,255,0.1)",
                                        "border": "1px solid rgba(0,212,255,0.3)",
                                        "color": "#00D4FF",
                                        "marginTop": "0.5rem",
                                    },
                                ),
                                html.Div(
                                    id="thresh-preview-result", style={"marginTop": "0.75rem"}
                                ),
                            ]
                        ),
                    ],
                    style=_GLASS,
                ),
            ],
        ),
        # ── Row 4: Typology Detail Cards ─────────────────────────────────────────
        html.Div(
            [
                _section_header(
                    "mdi:library", "Typology Library", "Reference guide to AML pattern definitions"
                ),
                dmc.SimpleGrid(
                    cols=5,
                    spacing="sm",
                    children=[
                        html.Div(
                            [
                                html.Div(
                                    [
                                        DashIconify(icon=icon, width=20, color=color),
                                        html.Strong(
                                            name,
                                            style={
                                                "color": THEME.TEXT_PRIMARY,
                                                "fontSize": "0.85rem",
                                                "marginLeft": "0.4rem",
                                            },
                                        ),
                                    ],
                                    style={
                                        "display": "flex",
                                        "alignItems": "center",
                                        "marginBottom": "0.5rem",
                                    },
                                ),
                                html.P(
                                    desc,
                                    style={
                                        "color": THEME.TEXT_MUTED,
                                        "fontSize": "0.75rem",
                                        "margin": 0,
                                        "lineHeight": "1.4",
                                    },
                                ),
                            ],
                            style={
                                "background": f"rgba(0,0,0,0.3)",
                                "border": f"1px solid {color}33",
                                "borderRadius": "8px",
                                "padding": "0.75rem",
                            },
                        )
                        for name, desc, icon, color in [
                            (
                                "Structuring",
                                TYPOLOGY_DESCRIPTIONS["Structuring"],
                                "mdi:layers-triple",
                                "#FF6B6B",
                            ),
                            (
                                "Smurfing",
                                TYPOLOGY_DESCRIPTIONS["Smurfing"],
                                "mdi:account-group",
                                "#FFD600",
                            ),
                            (
                                "Layering",
                                TYPOLOGY_DESCRIPTIONS["Layering"],
                                "mdi:sitemap",
                                "#9D4EDD",
                            ),
                            (
                                "Round-Tripping",
                                TYPOLOGY_DESCRIPTIONS["Round-Tripping"],
                                "mdi:sync-circle",
                                "#00D4FF",
                            ),
                            (
                                "Trade-Based",
                                TYPOLOGY_DESCRIPTIONS["Trade-Based"],
                                "mdi:earth",
                                "#00E676",
                            ),
                        ]
                    ],
                ),
            ],
            style=_GLASS,
        ),
    ],
    style={
        "padding": "1.5rem",
        "fontFamily": "'Inter', sans-serif",
        "background": THEME.DARK_BG,
        "minHeight": "100vh",
        "color": THEME.TEXT_PRIMARY,
    },
)


# ─── Callbacks ────────────────────────────────────────────────────────────────


@callback(
    Output("intel-node-select", "data"),
    Output("intel-typology-chart", "figure"),
    Output("intel-watchlist-summary", "children"),
    Output("intel-watchlist-banner", "children"),
    Output("intel-dedup-summary", "children"),
    Input("intel-init", "n_intervals"),
    Input("intel-refresh-btn", "n_clicks"),
    Input("pipeline-state", "data"),
    Input("global-refresh-ts", "data"),  # v14.7 FIX-GAP4: sync on Global Refresh
)
@GlobalExceptionHandler.wrap()
def load_intelligence(_init, _refresh, _pipeline_state, _grt):
    pipeline = get_pipeline()
    scored_df = pipeline.get_scored_df()
    analytics = pipeline.get_analytics_results() or {}

    # ── Node selector ────────────────────────────────────────────────────────
    node_options = []
    if scored_df is not None and not scored_df.empty and "node_id" in scored_df.columns:
        for _, row in scored_df.head(200).iterrows():
            nid = str(row["node_id"])
            tier = str(row.get("risk_tier", ""))
            score = float(row.get("risk_score", 0))
            node_options.append(
                {
                    "value": nid,
                    "label": f"{mask_value(nid, 'partial')} | {tier} | {score:.1f}",
                }
            )

    # ── Typology chart ───────────────────────────────────────────────────────
    typology_counts = {
        "Structuring": 0,
        "Smurfing": 0,
        "Layering": 0,
        "Round-Tripping": 0,
        "Trade-Based": 0,
        "None": 0,
    }
    if scored_df is not None and not scored_df.empty:
        tagged = apply_typologies(scored_df, analytics)
        for tags in tagged.get("typologies", []):
            if tags:
                for t in tags:
                    typology_counts[t] = typology_counts.get(t, 0) + 1
            else:
                typology_counts["None"] += 1

    colors = ["#FF6B6B", "#FFD600", "#9D4EDD", "#00D4FF", "#00E676", "#64748B"]
    fig_typo = go.Figure(
        go.Bar(
            x=list(typology_counts.keys()),
            y=list(typology_counts.values()),
            marker_color=colors,
            marker_line_width=0,
        )
    )
    fig_typo.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=10, r=10, t=10, b=30),
        font=dict(color=THEME.TEXT_SECONDARY, size=11),
        xaxis=dict(showgrid=False),
        yaxis=dict(showgrid=True, gridcolor="rgba(255,255,255,0.05)"),
    )

    # ── Watchlist ────────────────────────────────────────────────────────────
    watchlist_path = PATHS.BASE / "data" / "watchlist.csv"
    hits = {}
    if scored_df is not None and not scored_df.empty and "node_id" in scored_df.columns:
        from utils.intelligence import check_watchlist

        node_ids = scored_df["node_id"].tolist()
        hits = check_watchlist(node_ids, watchlist_path)

    wl_summary = html.Div(
        [
            dmc.SimpleGrid(
                cols=2,
                spacing="xs",
                children=[
                    html.Div(
                        [
                            html.Div(
                                str(len(hits)),
                                style={
                                    "fontSize": "2rem",
                                    "fontWeight": "800",
                                    "color": "#FF1744" if hits else "#00E676",
                                },
                            ),
                            html.Div(
                                "Watchlist Hits",
                                style={"color": THEME.TEXT_MUTED, "fontSize": "0.8rem"},
                            ),
                        ]
                    ),
                    html.Div(
                        [
                            html.Div(
                                str(
                                    len(
                                        [
                                            h
                                            for h in hits.values()
                                            if h.get("severity") == "CRITICAL"
                                        ]
                                    )
                                ),
                                style={"fontSize": "2rem", "fontWeight": "800", "color": "#FF1744"},
                            ),
                            html.Div(
                                "Critical", style={"color": THEME.TEXT_MUTED, "fontSize": "0.8rem"}
                            ),
                        ]
                    ),
                ],
            ),
            html.Div(
                [
                    html.Div(
                        [
                            dmc.Badge(
                                f"{mask_value(nid, 'partial')} — {info['severity']}",
                                color="red" if info["severity"] == "CRITICAL" else "orange",
                                size="sm",
                                variant="filled",
                                style={"marginBottom": "0.25rem"},
                            )
                        ]
                    )
                    for nid, info in list(hits.items())[:5]
                ],
                style={"marginTop": "0.75rem"},
            ),
        ]
    )

    # Banner
    banner = html.Div()
    if hits:
        banner = dmc.Alert(
            f"{len(hits)} watchlist hit(s) detected in current pipeline run. "
            f"Review immediately.",
            color="red",
            title="WATCHLIST ALERT",
            icon=DashIconify(icon="mdi:alert-octagon", width=20),
            style={"marginBottom": "1rem"},
        )

    # ── Dedup summary (v12.4: functional — calls deduplicate_alerts) ────────
    new_count, seen_count, esc_count = 0, 0, 0
    if scored_df is not None and not scored_df.empty:
        try:
            from utils.intelligence import deduplicate_alerts
            from database import get_db

            db = get_db()
            deduped = deduplicate_alerts(scored_df, db)
            if deduped is not None and "dedup_status" in deduped.columns:
                status_counts = deduped["dedup_status"].value_counts()
                new_count = int(status_counts.get("NEW", 0))
                seen_count = int(status_counts.get("SEEN", 0))
                esc_count = int(status_counts.get("ESCALATED", 0))
        except Exception:
            pass

    dedup_summary = html.Div(
        [
            dmc.SimpleGrid(
                cols=3,
                spacing="xs",
                children=[
                    html.Div(
                        [
                            html.Div(
                                str(new_count),
                                style={
                                    "fontSize": "1.8rem",
                                    "fontWeight": "800",
                                    "color": "#00E676",
                                },
                            ),
                            html.Div(
                                "NEW", style={"color": THEME.TEXT_MUTED, "fontSize": "0.8rem"}
                            ),
                        ]
                    ),
                    html.Div(
                        [
                            html.Div(
                                str(seen_count),
                                style={
                                    "fontSize": "1.8rem",
                                    "fontWeight": "800",
                                    "color": "#FFD600",
                                },
                            ),
                            html.Div(
                                "SEEN", style={"color": THEME.TEXT_MUTED, "fontSize": "0.8rem"}
                            ),
                        ]
                    ),
                    html.Div(
                        [
                            html.Div(
                                str(esc_count),
                                style={
                                    "fontSize": "1.8rem",
                                    "fontWeight": "800",
                                    "color": "#FF6B6B",
                                },
                            ),
                            html.Div(
                                "ESCALATED", style={"color": THEME.TEXT_MUTED, "fontSize": "0.8rem"}
                            ),
                        ]
                    ),
                ],
            ),
            html.P(
                f"Dedup across {new_count + seen_count + esc_count} alerts. "
                f"NEW={new_count} SEEN={seen_count} ESCALATED={esc_count}",
                style={"color": THEME.TEXT_MUTED, "fontSize": "0.78rem", "marginTop": "0.75rem"},
            ),
        ]
    )

    return node_options, fig_typo, wl_summary, banner, dedup_summary


@callback(
    Output("intel-explain-chart", "figure"),
    Output("intel-explain-details", "children"),
    Input("intel-node-select", "value"),
)
@GlobalExceptionHandler.wrap()
def explain_customer(node_id):
    if not node_id:
        empty = go.Figure()
        empty.update_layout(
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            annotations=[
                dict(
                    text="Select a customer above",
                    showarrow=False,
                    font=dict(color="#64748B", size=14),
                )
            ],
        )
        return empty, html.P(
            "Select a customer to see explainability.", style={"color": THEME.TEXT_MUTED}
        )

    pipeline = get_pipeline()
    scored_df = pipeline.get_scored_df()
    analytics = pipeline.get_analytics_results() or {}
    weights = PIPELINE.RISK_WEIGHTS or {
        "centrality": 0.20,
        "community": 0.10,
        "pathflow": 0.15,
        "anomaly": 0.25,
        "temporal": 0.15,
        "link_prediction": 0.05,
        "multi_layer": 0.10,
    }

    features = get_top_features(node_id, scored_df, analytics, weights)

    if not features:
        empty = go.Figure()
        empty.update_layout(
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            annotations=[
                dict(
                    text="No data for this customer",
                    showarrow=False,
                    font=dict(color="#64748B", size=14),
                )
            ],
        )
        return empty, html.P("No explainability data available.", style={"color": THEME.TEXT_MUTED})

    labels = [f["label"] for f in features]
    values = [f["pct"] for f in features]
    bar_colors = ["#00D4FF", "#9D4EDD", "#FF6B6B", "#FFD600", "#00E676"]

    fig = go.Figure(
        go.Bar(
            x=values,
            y=labels,
            orientation="h",
            marker_color=bar_colors[: len(features)],
            marker_line_width=0,
            text=[f"{v:.1f}%" for v in values],
            textposition="outside",
            textfont=dict(color=THEME.TEXT_SECONDARY, size=11),
        )
    )
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=10, r=60, t=10, b=10),
        font=dict(color=THEME.TEXT_SECONDARY, size=11),
        xaxis=dict(showgrid=True, gridcolor="rgba(255,255,255,0.05)", range=[0, max(values) * 1.3]),
        yaxis=dict(showgrid=False),
    )

    # Get customer details
    row = None
    if scored_df is not None and "node_id" in scored_df.columns:
        matches = scored_df[scored_df["node_id"] == node_id]
        if len(matches) > 0:
            row = matches.iloc[0]

    details = html.Div(
        [
            html.Div(
                [
                    html.Span(
                        "Customer: ", style={"color": THEME.TEXT_MUTED, "fontSize": "0.8rem"}
                    ),
                    html.Span(
                        mask_value(node_id, "partial"),
                        style={"color": THEME.TEXT_PRIMARY, "fontWeight": "600"},
                    ),
                ],
                style={"marginBottom": "0.4rem"},
            ),
            html.Div(
                [
                    html.Span(
                        "Risk Score: ", style={"color": THEME.TEXT_MUTED, "fontSize": "0.8rem"}
                    ),
                    html.Span(
                        f"{float(row['risk_score']):.1f}/100" if row is not None else "N/A",
                        style={"color": "#FF6B6B", "fontWeight": "700", "fontSize": "1.1rem"},
                    ),
                ],
                style={"marginBottom": "0.4rem"},
            ),
            html.Div(
                [
                    html.Span("Tier: ", style={"color": THEME.TEXT_MUTED, "fontSize": "0.8rem"}),
                    dmc.Badge(
                        str(row.get("risk_tier", "?")) if row is not None else "?",
                        color="red",
                        size="sm",
                    ),
                ]
            ),
        ]
    )

    return fig, details


@callback(
    Output("thresh-preview-result", "children"),
    Input("thresh-preview-btn", "n_clicks"),
    State("thresh-p1", "value"),
    State("thresh-p2", "value"),
    State("thresh-p3", "value"),
    prevent_initial_call=True,
)
@GlobalExceptionHandler.wrap()
def preview_thresholds(n_clicks, p1_min, p2_min, p3_min):
    pipeline = get_pipeline()
    scored_df = pipeline.get_scored_df()
    if scored_df is None or scored_df.empty:
        return dmc.Alert("No pipeline data. Run pipeline first.", color="yellow")

    thresholds = {
        "P1": (p1_min or 80, 100),
        "P2": (p2_min or 60, p1_min or 80),
        "P3": (p3_min or 40, p2_min or 60),
        "P4": (0, p3_min or 40),
    }
    impact = preview_threshold_impact(scored_df, thresholds)

    rows = []
    for tier in ["P1", "P2", "P3", "P4"]:
        info = impact.get(tier, {"old": 0, "new": 0, "delta": 0})
        delta = info["delta"]
        color = "red" if delta > 0 else "green" if delta < 0 else "gray"
        rows.append(
            html.Div(
                [
                    dmc.Badge(
                        tier,
                        color={"P1": "red", "P2": "orange", "P3": "yellow", "P4": "green"}[tier],
                        size="xs",
                    ),
                    html.Span(
                        f"{info['old']} → {info['new']}",
                        style={
                            "color": THEME.TEXT_PRIMARY,
                            "fontSize": "0.85rem",
                            "margin": "0 0.5rem",
                        },
                    ),
                    html.Span(
                        f"({'+' if delta > 0 else ''}{delta})",
                        style={
                            "color": TIER_COLORS.get(tier, "#fff"),
                            "fontSize": "0.8rem",
                            "fontWeight": "600",
                        },
                    ),
                ],
                style={"display": "flex", "alignItems": "center", "marginBottom": "0.3rem"},
            )
        )

    return html.Div(rows)
