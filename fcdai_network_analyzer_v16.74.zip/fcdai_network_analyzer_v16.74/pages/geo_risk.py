"""
Page: Geo-Risk Heat Map (v10 — A1)
=====================================
Business Logic: Geographical risk analysis — country-based risk distribution,
sanctions screening, cross-border flow analysis. Air-gapped, no map tiles.
Uses Plotly treemap/sunburst instead of actual map (offline-safe).
"""

import dash
from dash import html, dcc, callback, Input, Output, no_update
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, GEO_RISK, APP

dash.register_page(
    __name__, path="/geo-risk", name="Geo-Risk", title=f"FCDAI v{APP.VERSION} | Geo-Risk Heat Map"
)

TIER_COLORS = {"P1": "#FF1744", "P2": "#FF9800", "P3": "#FFD600", "P4": "#00E676"}
GEO_COLORS = {"high": "#FF1744", "medium": "#FF9800", "low": "#00E676", "sanctions": "#9C27B0"}


layout = dmc.Box(
    [
        dcc.Interval(id="geo-init", interval=1000, max_intervals=1),
        dmc.Group(
            [
                dmc.Stack(
                    [
                        dmc.Title("Geo-Risk Heat Map", order=2, c="white"),
                        dmc.Text(
                            "Country-Based Risk Distribution — Air-Gapped",
                            c="dimmed",
                            size="sm",
                        ),
                    ],
                    gap=2,
                ),
                dmc.Group(
                    [
                        dmc.Badge("AIR-GAPPED", color="red", variant="light", size="sm"),
                    ],
                    gap="sm",
                ),
            ],
            justify="space-between",
            mb="lg",
        ),
        # CEO Business Context Panel
        dmc.Paper(
            [
                dmc.Group(
                    [
                        DashIconify(icon="mdi:information-outline", width=18, color="#FF6B6B"),
                        dmc.Text("What This Page Shows", fw=700, size="sm", c="#FF6B6B"),
                    ],
                    gap="xs",
                    mb="sm",
                ),
                dmc.SimpleGrid(
                    cols={"base": 1, "md": 3},
                    spacing="sm",
                    children=[
                        dmc.Box(
                            [
                                dmc.Text("Overview", size="xs", fw=700, c="#00D4FF", mb=4),
                                dmc.Text(
                                    "Maps every customer and transaction by country of origin, revealing which "
                                    "geographies carry the highest concentration of financial crime risk. Uses a "
                                    "treemap (block size = volume) and a sunburst (nested ring = risk tier) to "
                                    "show both scale and severity at a glance.",
                                    size="xs",
                                    c="dimmed",
                                    style={"lineHeight": "1.5"},
                                ),
                            ],
                            style={
                                "background": "rgba(0,212,255,0.05)",
                                "border": "1px solid rgba(0,212,255,0.12)",
                                "borderRadius": "8px",
                                "padding": "10px",
                            },
                        ),
                        dmc.Box(
                            [
                                dmc.Text("Why It Matters", size="xs", fw=700, c="#FFD600", mb=4),
                                dmc.Text(
                                    "Geographic risk is the foundation of AML compliance. FATF and all major regulators "
                                    "require institutions to assess and document their country-level risk exposure. "
                                    "This page directly supports the Country Risk Assessment (CRA) mandated by "
                                    "regulatory frameworks worldwide.",
                                    size="xs",
                                    c="dimmed",
                                    style={"lineHeight": "1.5"},
                                ),
                            ],
                            style={
                                "background": "rgba(255,214,0,0.05)",
                                "border": "1px solid rgba(255,214,0,0.12)",
                                "borderRadius": "8px",
                                "padding": "10px",
                            },
                        ),
                        dmc.Box(
                            [
                                dmc.Text("When to Act", size="xs", fw=700, c="#FF6B6B", mb=4),
                                dmc.Text(
                                    "If sanctioned jurisdictions appear: freeze activity and file regulatory reports "
                                    "within 24 hours. If a single country dominates P1/P2 accounts: escalate to MLRO "
                                    "and consider enhanced due diligence for all customers in that geography. "
                                    "Review quarterly for emerging geographic risk trends.",
                                    size="xs",
                                    c="dimmed",
                                    style={"lineHeight": "1.5"},
                                ),
                            ],
                            style={
                                "background": "rgba(255,107,107,0.05)",
                                "border": "1px solid rgba(255,107,107,0.12)",
                                "borderRadius": "8px",
                                "padding": "10px",
                            },
                        ),
                    ],
                ),
            ],
            p="md",
            radius="lg",
            className="glass-card",
            mb="md",
            style={"borderLeft": "3px solid #FF6B6B"},
        ),
        # ─── v16.28: Tabbed layout — Country | US States ─────────────────────
        dmc.Tabs(
            [
                dmc.TabsList(
                    [
                        dmc.TabsTab(
                            [DashIconify(icon="mdi:earth", width=14), " 🌍 Country Analysis"],
                            value="country",
                        ),
                        dmc.TabsTab(
                            [DashIconify(icon="mdi:flag-outline", width=14), " 🇺🇸 US State Analysis"],
                            value="state",
                        ),
                        dmc.TabsTab(
                            [DashIconify(icon="mdi:earth-box", width=14), " 🗺️ World Map"],
                            value="world",
                        ),
                    ],
                    mb="md",
                ),
                # ── Tab 1: Country Analysis (existing content) ────────────────
                dmc.TabsPanel(
                    value="country",
                    children=[
                        # Stats row
                        dmc.SimpleGrid(
                            cols={"base": 2, "md": 4}, spacing="md", mb="md",
                            id="geo-stats", children=[],
                        ),
                        # Charts row
                        dmc.SimpleGrid(
                            cols={"base": 1, "md": 2},
                            spacing="md",
                            mb="md",
                            children=[
                                dmc.Paper(
                                    [
                                        dmc.Text(
                                            "Country Risk Treemap — Where Is the Money Coming From?",
                                            fw=600, c="white", mb=4,
                                        ),
                                        dmc.Text(
                                            "Each block represents a country — bigger blocks mean more customers "
                                            "transacting there. Darker red indicates higher AML risk. "
                                            "Business use: Identify which geographies drive the most financial-crime exposure "
                                            "and flag cross-border flows to high-risk or sanctioned jurisdictions.",
                                            size="xs", c="dimmed", mb="sm",
                                            style={"lineHeight": "1.4", "fontStyle": "italic"},
                                        ),
                                        dcc.Graph(
                                            id="geo-treemap",
                                            config={"displayModeBar": False},
                                            style={"height": "400px"},
                                        ),
                                    ],
                                    p="lg", radius="lg", className="glass-card",
                                ),
                                dmc.Paper(
                                    [
                                        dmc.Text(
                                            "Risk Level Distribution — P1/P2/P3/P4 Breakdown by Geography",
                                            fw=600, c="white", mb=4,
                                        ),
                                        dmc.Text(
                                            "Shows the proportion of customers in each risk tier (P1–P4) across countries. "
                                            "A large P1/P2 slice in a specific country signals a concentrated risk cluster. "
                                            "Business use: Allocate compliance resources to the highest-risk geographies first.",
                                            size="xs", c="dimmed", mb="sm",
                                            style={"lineHeight": "1.4", "fontStyle": "italic"},
                                        ),
                                        dcc.Graph(
                                            id="geo-sunburst",
                                            config={"displayModeBar": False},
                                            style={"height": "400px"},
                                        ),
                                    ],
                                    p="lg", radius="lg", className="glass-card",
                                ),
                            ],
                        ),
                        # Country table
                        dmc.Paper(
                            [
                                dmc.Text("Country Risk Summary", fw=600, c="white", mb="sm"),
                                dmc.ScrollArea(
                                    [html.Div(id="geo-country-table")],
                                    h=400,
                                ),
                            ],
                            p="lg", radius="lg", className="glass-card", mb="md",
                        ),
                        # Sanctions alert
                        dmc.Paper(
                            [
                                dmc.Group(
                                    [
                                        DashIconify(icon="mdi:alert-octagon", width=22, color="#9C27B0"),
                                        dmc.Text("Sanctions & High-Risk Jurisdictions", fw=700, c="white"),
                                    ],
                                    gap="sm", mb="sm",
                                ),
                                html.Div(id="geo-sanctions-alert"),
                            ],
                            p="lg", radius="lg", className="glass-card",
                        ),
                    ],
                ),
                # ── Tab 2: US State Analysis ──────────────────────────────────
                dmc.TabsPanel(
                    value="state",
                    children=[
                        # Context note
                        dmc.Alert(
                            "State-level data is derived from the 'state' column of the node table. "
                            "Only US-registered nodes are included. Upload node data with a 'state' "
                            "column to populate this tab.",
                            title="US State Analysis",
                            color="cyan",
                            icon=DashIconify(icon="mdi:information-outline"),
                            mb="md",
                        ),
                        # State Stats row
                        dmc.SimpleGrid(
                            cols={"base": 2, "md": 4}, spacing="md", mb="md",
                            id="geo-state-stats", children=[],
                        ),
                        # Choropleth + Bar side-by-side
                        dmc.SimpleGrid(
                            cols={"base": 1, "md": 2},
                            spacing="md",
                            mb="md",
                            children=[
                                dmc.Paper(
                                    [
                                        dmc.Group(
                                            [
                                                DashIconify(icon="mdi:map-outline", width=18, color="#00D4FF"),
                                                dmc.Text(
                                                    "US State Risk Choropleth — Average AML Score per State",
                                                    fw=600, c="white",
                                                ),
                                            ],
                                            gap=6, mb=4,
                                        ),
                                        dmc.Text(
                                            "Darker red = higher average risk score in that state. "
                                            "Business use: identify domestic geographic concentration of risk "
                                            "and allocate state-level compliance resources.",
                                            size="xs", c="dimmed", mb="sm",
                                            style={"lineHeight": "1.4", "fontStyle": "italic"},
                                        ),
                                        dcc.Graph(
                                            id="geo-us-state-map",
                                            config={"displayModeBar": False},
                                            style={"height": "450px"},
                                        ),
                                    ],
                                    p="lg", radius="lg", className="glass-card",
                                ),
                                dmc.Paper(
                                    [
                                        dmc.Group(
                                            [
                                                DashIconify(icon="mdi:chart-bar", width=18, color="#FFD600"),
                                                dmc.Text(
                                                    "Top States by Average Risk Score",
                                                    fw=600, c="white",
                                                ),
                                            ],
                                            gap=6, mb=4,
                                        ),
                                        dmc.Text(
                                            "Top 20 US states ranked by average AML risk score of registered customers. "
                                            "Business use: flag high-risk states for enhanced due-diligence reviews.",
                                            size="xs", c="dimmed", mb="sm",
                                            style={"lineHeight": "1.4", "fontStyle": "italic"},
                                        ),
                                        dcc.Graph(
                                            id="geo-state-bar",
                                            config={"displayModeBar": False},
                                            style={"height": "450px"},
                                        ),
                                    ],
                                    p="lg", radius="lg", className="glass-card",
                                ),
                            ],
                        ),
                        # State Table
                        dmc.Paper(
                            [
                                dmc.Text("US State Risk Summary", fw=600, c="white", mb="sm"),
                                dmc.ScrollArea(
                                    [html.Div(id="geo-state-table")],
                                    h=450,
                                ),
                            ],
                            p="lg", radius="lg", className="glass-card",
                        ),
                        # v16.69: State density map (node count)
                        dmc.Paper(
                            [
                                dmc.Group(
                                    [
                                        DashIconify(icon="mdi:blur", width=18, color="#B39DDB"),
                                        dmc.Text(
                                            "US State Customer Density — Node Count per State",
                                            fw=600, c="white",
                                        ),
                                    ],
                                    gap=6, mb=4,
                                ),
                                dmc.Text(
                                    "Shows the raw number of customers registered per US state — independent of risk score. "
                                    "Business use: identify geographic concentration of customer base; states with high count "
                                    "and high risk score require amplified compliance resources.",
                                    size="xs", c="dimmed", mb="sm",
                                    style={"lineHeight": "1.4", "fontStyle": "italic"},
                                ),
                                dcc.Graph(
                                    id="geo-us-state-density-map",
                                    config={"displayModeBar": False},
                                    style={"height": "450px"},
                                ),
                            ],
                            p="lg", radius="lg", className="glass-card", mt="md",
                        ),
                    ],
                ),
                # ── Tab 3: World Choropleth Map ───────────────────────────────
                dmc.TabsPanel(
                    value="world",
                    children=[
                        dmc.Alert(
                            "Global country-level choropleth built from your customer/node country data. "
                            "Colour intensity = average AML risk score per country. Requires a 'country' column in the node/customer table.",
                            title="Global Risk Map",
                            color="blue",
                            icon=DashIconify(icon="mdi:earth-box"),
                            mb="md",
                        ),
                        dmc.Paper(
                            [
                                dmc.Group(
                                    [
                                        DashIconify(icon="mdi:earth-box", width=18, color="#00D4FF"),
                                        dmc.Text(
                                            "Global AML Risk Choropleth — Average Risk Score by Country",
                                            fw=600, c="white",
                                        ),
                                    ],
                                    gap=6, mb=4,
                                ),
                                dmc.Text(
                                    "Each country is shaded by the average composite AML risk score of customers registered there. "
                                    "Red/dark = elevated risk; green = standard. Business use: supports FATF-aligned Country Risk "
                                    "Assessment (CRA) and cross-border correspondent banking due diligence.",
                                    size="xs", c="dimmed", mb="sm",
                                    style={"lineHeight": "1.4", "fontStyle": "italic"},
                                ),
                                dcc.Graph(
                                    id="geo-world-map",
                                    config={"displayModeBar": False},
                                    style={"height": "550px"},
                                ),
                            ],
                            p="lg", radius="lg", className="glass-card",
                        ),
                    ],
                ),
            ],
            value="country",   # default active tab
            color="cyan",
        ),
        # Export bar (shared — below both tabs)
        dmc.Paper(
            [
                dmc.Group(
                    [
                        DashIconify(icon="mdi:download-circle-outline", width=22, color="#00D4FF"),
                        dmc.Text("Export Geo-Risk Data", fw=600, c="white", size="sm"),
                        dmc.Button(
                            "⬇ Export CSV",
                            id="geo-export-csv",
                            size="xs",
                            variant="light",
                            color="cyan",
                            leftSection=DashIconify(icon="mdi:download", width=14),
                        ),
                    ],
                    gap="md",
                    align="center",
                ),
            ],
            p="sm",
            radius="lg",
            className="glass-card",
            mt="md",
            style={
                "background": "rgba(0,212,255,0.04)",
                "border": "1px solid rgba(0,212,255,0.15)",
            },
        ),
        dcc.Download(id="geo-download"),
    ]
)


@callback(
    [
        Output("geo-stats", "children"),
        Output("geo-treemap", "figure"),
        Output("geo-sunburst", "figure"),
        Output("geo-country-table", "children"),
        Output("geo-sanctions-alert", "children"),
        Output("geo-us-state-map", "figure"),          # choropleth avg risk
        Output("geo-state-stats", "children"),          # v16.28 Tab2 stats cards
        Output("geo-state-bar", "figure"),              # v16.28 Tab2 bar chart
        Output("geo-state-table", "children"),          # v16.28 Tab2 table
        Output("geo-us-state-density-map", "figure"),  # v16.69 density map
        Output("geo-world-map", "figure"),              # v16.69 global choropleth
    ],
    Input("geo-init", "n_intervals"),
    Input("pipeline-state", "data"),
    Input("global-refresh-ts", "data"),
)
def update_geo_risk(_init, _pipeline_state, _gr):
    from engine import get_pipeline

    pipeline = get_pipeline()

    if not pipeline.has_data():
        empty_fig = go.Figure()
        empty_fig.update_layout(
            template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)"
        )
        _no_data = dmc.Text("No data available", c="dimmed")
        return (
            [_stat_card("No Data", "Run pipeline first", "mdi:alert", "gray")],
            empty_fig,
            empty_fig,
            _no_data,
            _no_data,
            empty_fig,
            [_stat_card("No Data", "Run pipeline first", "mdi:alert", "gray")],
            empty_fig,
            _no_data,
            empty_fig,
            empty_fig,
        )

    geo_data = pipeline.get_geo_risk_data()
    nodes = geo_data.get("nodes", [])
    country_stats = geo_data.get("country_stats", {})

    # Stats
    total_countries = len(country_stats)
    high_risk = sum(1 for v in country_stats.values() if v["geo_level"] == "high")
    sanctions_count = sum(1 for v in country_stats.values() if v["geo_level"] == "sanctions")
    total_flow = sum(v["total_flow"] for v in country_stats.values())

    stats = [
        _stat_card(str(total_countries), "Countries", "mdi:earth", "cyan"),
        _stat_card(str(high_risk), "High-Risk", "mdi:alert", "red"),
        _stat_card(str(sanctions_count), "Sanctioned", "mdi:shield-alert", "grape"),
        _stat_card(f"${total_flow:,.0f}", "Total Flow", "mdi:cash-multiple", "green"),
    ]

    # Treemap
    tree_data = []
    for country, st in country_stats.items():
        tree_data.append(
            {
                "country": country,
                "risk_level": st["geo_level"].title(),
                "count": st["count"],
                "avg_risk": round(st["total_risk"] / max(st["count"], 1), 1),
                "total_flow": round(st["total_flow"], 0),
            }
        )
    tree_df = (
        pd.DataFrame(tree_data)
        if tree_data
        else pd.DataFrame(
            {"country": ["N/A"], "risk_level": ["low"], "count": [0], "avg_risk": [0]}
        )
    )

    treemap_fig = px.treemap(
        tree_df,
        path=["risk_level", "country"],
        values="count",
        color="avg_risk",
        color_continuous_scale=["#00E676", "#FFD600", "#FF1744"],
    )
    treemap_fig.update_layout(
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        margin=dict(t=10, b=10, l=10, r=10),
    )

    # Sunburst
    sunburst_fig = px.sunburst(
        tree_df,
        path=["risk_level", "country"],
        values="count",
        color="avg_risk",
        color_continuous_scale=["#00E676", "#FFD600", "#FF1744"],
    )
    sunburst_fig.update_layout(
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        margin=dict(t=10, b=10, l=10, r=10),
    )

    # Country table
    table_rows = []
    for country, st in sorted(
        country_stats.items(), key=lambda x: x[1]["total_risk"], reverse=True
    ):
        avg_risk = round(st["total_risk"] / max(st["count"], 1), 1)
        table_rows.append(
            dmc.Group(
                [
                    dmc.Badge(
                        st["geo_level"].upper(),
                        color=GEO_COLORS.get(st["geo_level"], "gray"),
                        size="xs",
                        variant="filled",
                        w=80,
                    ),
                    dmc.Text(country, c="white", size="sm", w=120),
                    dmc.Text(f"{st['count']} nodes", c="dimmed", size="xs", w=80),
                    dmc.Text(f"Avg Risk: {avg_risk}", c="white", size="xs", w=100),
                    dmc.Text(f"Flow: ${st['total_flow']:,.0f}", c="dimmed", size="xs", w=120),
                    dmc.Text(
                        f"High-Risk: {st['high_risk_count']}",
                        c="#FF1744" if st["high_risk_count"] > 0 else "dimmed",
                        size="xs",
                    ),
                ],
                gap="md",
                style={"padding": "6px 0", "borderBottom": f"1px solid {THEME.DARK_BORDER}"},
            ),
        )
    country_table = (
        dmc.Stack(table_rows, gap=0) if table_rows else dmc.Text("No countries", c="dimmed")
    )

    # Sanctions alert
    sanctions_countries = [c for c, st in country_stats.items() if st["geo_level"] == "sanctions"]
    high_risk_countries = [c for c, st in country_stats.items() if st["geo_level"] == "high"]

    sanctions_alert = dmc.Stack(
        [
            dmc.Alert(
                (
                    f"Sanctioned jurisdictions detected: {', '.join(sanctions_countries)}"
                    if sanctions_countries
                    else "No sanctioned jurisdictions detected in current dataset"
                ),
                title="Sanctions Screening",
                color="grape" if sanctions_countries else "green",
                icon=DashIconify(
                    icon="mdi:shield-alert" if sanctions_countries else "mdi:shield-check"
                ),
            ),
            dmc.Alert(
                (
                    f"High-risk jurisdictions: {', '.join(high_risk_countries)}"
                    if high_risk_countries
                    else "No high-risk jurisdictions detected"
                ),
                title="High-Risk Jurisdictions",
                color="red" if high_risk_countries else "green",
                icon=DashIconify(icon="mdi:alert" if high_risk_countries else "mdi:check-circle"),
            ),
        ],
        gap="sm",
    )

    # v16.23 T3: US state choropleth (requires 'state' column in customer/node table)
    us_state_fig = _build_us_state_map(pipeline)

    # v16.28: US State Analysis — stats + bar chart + table
    state_stats, state_bar_fig, state_table = _build_state_analysis(pipeline)

    # v16.69: density map + global world map
    us_density_fig = _build_us_state_density_map(pipeline)
    world_fig = _build_world_map(pipeline, country_stats)

    return stats, treemap_fig, sunburst_fig, country_table, sanctions_alert, us_state_fig, state_stats, state_bar_fig, state_table, us_density_fig, world_fig


# ── v16.23 T3 helper: US State choropleth ─────────────────────────────────────
def _build_us_state_map(pipeline) -> go.Figure:
    """
    v16.29 T4: Build a US state choropleth from node/edge data.
    Priority data source order:
      1. Node table directly (node_id + state + risk_score) — works with ONLY node+edge tables
      2. Scored_df merged with node table state — requires full pipeline run
    Falls back to informative empty figure if no state data is available.
    """
    _empty = go.Figure()
    _empty.update_layout(
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        template="plotly_dark",
        annotations=[dict(
            text="No US state data — upload node table with 'state' + 'risk_score' columns.",
            showarrow=False, font=dict(color="#64748B", size=13),
            x=0.5, y=0.5, xref="paper", yref="paper",
        )],
    )
    try:
        # v16.29 T4: Priority 1 — direct node table (no scored_df needed)
        us = None
        id_col_direct = None
        risk_col_direct = None
        for tbl_name in ("node", "customer"):
            df = pipeline.tables.get(tbl_name) if hasattr(pipeline, "tables") else None
            if df is None or "state" not in df.columns:
                continue
            id_col_direct = "node_id" if "node_id" in df.columns else (
                "customer_id" if "customer_id" in df.columns else None
            )
            risk_col_direct = next(
                (c for c in ("risk_score", "score", "composite_score") if c in df.columns), None
            )
            if id_col_direct is not None and risk_col_direct is not None:
                _tmp = df[[id_col_direct, "state", risk_col_direct]].copy()
                _tmp = _tmp[_tmp["state"].notna() & (_tmp["state"] != "N/A") & (_tmp["state"].str.len() == 2)]
                if not _tmp.empty:
                    us = _tmp.rename(columns={risk_col_direct: "risk_score", id_col_direct: "node_id"})
                    break

        # Priority 2 — scored_df merged with state (requires full pipeline scoring run)
        if us is None:
            scored = None
            try:
                scored = pipeline.get_scored_df()
            except Exception:
                pass
            if scored is not None:
                source_df = None
                state_col = None
                for tbl_name in ("customer", "node"):
                    df = pipeline.tables.get(tbl_name) if hasattr(pipeline, "tables") else None
                    if df is not None and "state" in df.columns:
                        id_col = "customer_id" if "customer_id" in df.columns else (
                            "node_id" if "node_id" in df.columns else None
                        )
                        if id_col:
                            state_col = id_col
                            source_df = df[[id_col, "state"]].copy()
                            break
                if source_df is not None and state_col is not None:
                    scored_id_col = "node_id" if "node_id" in scored.columns else "customer_id"
                    merged = scored.merge(
                        source_df.rename(columns={state_col: scored_id_col}),
                        on=scored_id_col, how="inner"
                    )
                    _tmp2 = merged[merged["state"].notna() & (merged["state"] != "N/A")].copy()
                    risk_col_s = next((c for c in ("risk_score", "score", "composite_score") if c in _tmp2.columns), None)
                    if risk_col_s and not _tmp2.empty:
                        us = _tmp2.rename(columns={risk_col_s: "risk_score", scored_id_col: "node_id"})

        if us is None or us.empty:
            return _empty

        state_agg = (
            us.groupby("state").agg(
                avg_risk=("risk_score", "mean"),
                node_count=("node_id", "count"),
            ).reset_index()
        )
        # Keep only valid 2-letter US state codes
        state_agg = state_agg[state_agg["state"].str.len() == 2]
        if state_agg.empty:
            return _empty
        state_agg["avg_risk"] = state_agg["avg_risk"].round(1)
        fig = go.Figure(go.Choropleth(
            locations=state_agg["state"],
            z=state_agg["avg_risk"],
            locationmode="USA-states",
            colorscale=[[0.0, "#00E676"], [0.4, "#FFD600"], [0.7, "#FF9800"], [1.0, "#FF1744"]],
            zmin=0,
            zmax=100,
            colorbar=dict(
                title="Avg Risk Score",
                tickfont=dict(color="#94A3B8"),
                titlefont=dict(color="#94A3B8"),
                bgcolor="rgba(0,0,0,0)",
            ),
            customdata=state_agg[["avg_risk", "node_count"]].values,
            hovertemplate=(
                "<b>%{location}</b><br>"
                "Avg Risk Score: %{customdata[0]:.1f}<br>"
                "Customers: %{customdata[1]}<extra></extra>"
            ),
            marker_line_color="rgba(255,255,255,0.2)",
            marker_line_width=0.5,
        ))
        fig.update_layout(
            geo=dict(
                scope="usa",
                showlakes=False,
                lakecolor="rgba(0,0,0,0)",
                bgcolor="rgba(0,0,0,0)",
                landcolor="rgba(30,41,59,0.6)",
                coastlinecolor="rgba(255,255,255,0.1)",
                showcoastlines=True,
            ),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            font=dict(color="#94A3B8"),
            margin=dict(l=0, r=0, t=0, b=0),
            height=480,
        )
        return fig
    except Exception:
        return _empty


# ── v16.28 / v16.29 / v16.69: US State Analysis helper ──────────────────────
def _build_state_analysis(pipeline):
    """
    v16.69: Build state-level stats cards, bar chart, and summary table.
    Priority data source:
      0. Node table directly (state column only, no risk_score) — count-only analysis
      1. Node table directly (state + risk_score) — works with ONLY node+edge tables
      2. Scored_df merged with state — requires full pipeline run
    Returns: (state_stats_children, state_bar_fig, state_table_children)
    """
    _empty_fig = go.Figure()
    _empty_fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        template="plotly_dark",
        annotations=[dict(
            text="No US state data — upload node table with 'state' column.",
            showarrow=False, font=dict(color="#64748B", size=12),
            x=0.5, y=0.5, xref="paper", yref="paper",
        )],
    )
    _no_data_cards = [
        _stat_card("—", "US Nodes", "mdi:account-group", "cyan"),
        _stat_card("—", "States Covered", "mdi:map-marker-multiple", "blue"),
        _stat_card("—", "Avg Risk Score", "mdi:gauge", "orange"),
        _stat_card("—", "Highest Risk State", "mdi:alert", "red"),
    ]
    _no_data_table = dmc.Text("No US state data available — add 'state' column to node table", c="dimmed", size="sm")
    try:
        us = None
        has_risk = False
        id_col_found = None

        # Priority 0 + 1: direct node table
        for tbl_name in ("node", "customer"):
            df = pipeline.tables.get(tbl_name) if hasattr(pipeline, "tables") else None
            if df is None or "state" not in df.columns:
                continue
            id_col_found = "node_id" if "node_id" in df.columns else (
                "customer_id" if "customer_id" in df.columns else None
            )
            if id_col_found is None:
                continue
            risk_col_direct = next(
                (c for c in ("risk_score", "score", "composite_score") if c in df.columns), None
            )
            _tmp = df.copy()
            _tmp = _tmp[_tmp["state"].notna() & (_tmp["state"] != "N/A")]
            # normalise to 2-letter abbreviations where possible
            _tmp = _tmp[_tmp["state"].astype(str).str.len() <= 20]
            if not _tmp.empty:
                if risk_col_direct is not None:
                    us = _tmp[[id_col_found, "state", risk_col_direct]].copy()
                    us = us.rename(columns={risk_col_direct: "risk_score", id_col_found: "node_id"})
                    has_risk = True
                else:
                    # Priority 0: count-only
                    us = _tmp[[id_col_found, "state"]].copy()
                    us = us.rename(columns={id_col_found: "node_id"})
                    us["risk_score"] = 0.0  # placeholder
                    has_risk = False
                break

        # Priority 2 — scored_df merged with state
        if us is None:
            scored = None
            try:
                scored = pipeline.get_scored_df()
            except Exception:
                pass
            if scored is not None:
                source_df = None
                id_col_src = None
                for tbl_name in ("node", "customer"):
                    df = pipeline.tables.get(tbl_name) if hasattr(pipeline, "tables") else None
                    if df is not None and "state" in df.columns:
                        id_col_src = "node_id" if "node_id" in df.columns else (
                            "customer_id" if "customer_id" in df.columns else None
                        )
                        if id_col_src:
                            source_df = df[[id_col_src, "state"]].copy()
                            break
                if source_df is not None and id_col_src is not None:
                    scored_id_col = "node_id" if "node_id" in scored.columns else "customer_id"
                    merged = scored.merge(
                        source_df.rename(columns={id_col_src: scored_id_col}),
                        on=scored_id_col, how="inner",
                    )
                    _tmp2 = merged[merged["state"].notna() & (merged["state"] != "N/A")].copy()
                    risk_col_s = next((c for c in ("risk_score", "score", "composite_score") if c in _tmp2.columns), None)
                    if not _tmp2.empty:
                        if risk_col_s:
                            us = _tmp2.rename(columns={risk_col_s: "risk_score", scored_id_col: "node_id"})
                            has_risk = True
                        else:
                            us = _tmp2.rename(columns={scored_id_col: "node_id"})
                            us["risk_score"] = 0.0
                            has_risk = False

        if us is None or us.empty:
            return _no_data_cards, _empty_fig, _no_data_table

        state_agg = (
            us.groupby("state").agg(
                avg_risk=("risk_score", "mean"),
                node_count=("node_id", "count"),
            ).reset_index()
        )
        # Keep only reasonable state codes (length 2 = US abbreviations; allow up to 3 for territories)
        state_agg = state_agg[state_agg["state"].astype(str).str.len() <= 3]
        if state_agg.empty:
            return _no_data_cards, _empty_fig, _no_data_table
        state_agg["avg_risk"] = state_agg["avg_risk"].round(1)

        top_risk_state = (
            state_agg.loc[state_agg["avg_risk"].idxmax(), "state"]
            if (has_risk and len(state_agg) > 0) else
            state_agg.loc[state_agg["node_count"].idxmax(), "state"]
            if len(state_agg) > 0 else "—"
        )
        overall_avg = round(float(us["risk_score"].mean()), 1) if (has_risk and len(us) > 0) else 0

        # Stats cards
        state_stats = [
            _stat_card(str(len(us)), "US Nodes", "mdi:account-group", "cyan"),
            _stat_card(str(len(state_agg)), "States Covered", "mdi:map-marker-multiple", "blue"),
            _stat_card(str(overall_avg) if has_risk else "N/A", "Avg Risk Score", "mdi:gauge", "orange"),
            _stat_card(str(top_risk_state), "Top State", "mdi:alert", "red"),
        ]

        # Bar chart — top 20 states by avg risk (or by count if no risk)
        sort_col = "avg_risk" if has_risk else "node_count"
        top20 = state_agg.nlargest(20, sort_col).sort_values(sort_col, ascending=True)
        bar_color_vals = top20["avg_risk"].tolist() if has_risk else top20["node_count"].tolist()
        bar_fig = go.Figure(go.Bar(
            x=top20[sort_col],
            y=top20["state"],
            orientation="h",
            marker=dict(
                color=bar_color_vals,
                colorscale=[[0.0, "#00E676"], [0.4, "#FFD600"], [0.7, "#FF9800"], [1.0, "#FF1744"]],
                cmin=0, cmax=100 if has_risk else max(bar_color_vals),
            ),
            customdata=top20[["avg_risk", "node_count"]].values,
            hovertemplate=(
                "<b>%{y}</b><br>Avg Risk Score: %{customdata[0]:.1f}<br>"
                "Customers: %{customdata[1]}<extra></extra>"
            ),
        ))
        bar_fig.update_layout(
            template="plotly_dark",
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            xaxis=dict(
                title="Avg Risk Score" if has_risk else "Customer Count",
                range=[0, 100] if has_risk else None,
                gridcolor="rgba(255,255,255,0.05)",
            ),
            yaxis=dict(title="", gridcolor="rgba(255,255,255,0.05)"),
            margin=dict(l=60, r=20, t=10, b=40),
            font=dict(color="#94A3B8"),
        )

        # State table — sorted by avg risk DESC (or count if no risk)
        sorted_agg = state_agg.sort_values(sort_col, ascending=False)
        table_rows = []
        for _, row in sorted_agg.iterrows():
            risk_val = float(row["avg_risk"]) if has_risk else 0
            risk_color = (
                "#FF1744" if risk_val >= 75 else
                "#FF9800" if risk_val >= 50 else
                "#FFD600" if risk_val >= 30 else "#00E676"
            ) if has_risk else "#94A3B8"
            bar_color = (
                "red" if risk_val >= 75 else
                "orange" if risk_val >= 50 else
                "yellow" if risk_val >= 30 else "green"
            ) if has_risk else "blue"
            table_rows.append(
                dmc.Group(
                    [
                        dmc.Text(str(row["state"]), c="white", size="sm", fw=600, w=50),
                        dmc.Text(f"{int(row['node_count'])} nodes", c="dimmed", size="xs", w=90),
                        dmc.Text(
                            f"Avg Risk: {risk_val:.1f}" if has_risk else "Risk: N/A",
                            c=risk_color, size="xs", fw=600, w=120,
                        ),
                        dmc.Progress(
                            value=min(risk_val, 100) if has_risk else min(int(row["node_count"]) / max(state_agg["node_count"].max(), 1) * 100, 100),
                            color=bar_color,
                            size="sm",
                            style={"flex": "1 1 0%", "minWidth": "80px"},
                        ),
                    ],
                    gap="md",
                    style={"padding": "6px 0", "borderBottom": f"1px solid {THEME.DARK_BORDER}"},
                )
            )
        state_table = (
            dmc.Stack(table_rows, gap=0) if table_rows
            else dmc.Text("No state data", c="dimmed")
        )
        return state_stats, bar_fig, state_table

    except Exception:
        return _no_data_cards, _empty_fig, _no_data_table


# ── v16.69: US State Customer Density helper ─────────────────────────────────
def _build_us_state_density_map(pipeline) -> go.Figure:
    """Build a US state choropleth showing raw customer COUNT per state (density)."""
    _empty = go.Figure()
    _empty.update_layout(
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        template="plotly_dark",
        annotations=[dict(
            text="No US state data — add 'state' column to node table.",
            showarrow=False, font=dict(color="#64748B", size=13),
            x=0.5, y=0.5, xref="paper", yref="paper",
        )],
    )
    try:
        us = None
        for tbl_name in ("node", "customer"):
            df = pipeline.tables.get(tbl_name) if hasattr(pipeline, "tables") else None
            if df is None or "state" not in df.columns:
                continue
            id_col = "node_id" if "node_id" in df.columns else (
                "customer_id" if "customer_id" in df.columns else None
            )
            if id_col is None:
                continue
            _tmp = df[[id_col, "state"]].copy()
            _tmp = _tmp[_tmp["state"].notna() & (_tmp["state"] != "N/A")]
            if not _tmp.empty:
                us = _tmp.rename(columns={id_col: "node_id"})
                break
        if us is None:
            scored = None
            try:
                scored = pipeline.get_scored_df()
            except Exception:
                pass
            if scored is not None:
                for tbl_name in ("node", "customer"):
                    df = pipeline.tables.get(tbl_name) if hasattr(pipeline, "tables") else None
                    if df is not None and "state" in df.columns:
                        id_src = "node_id" if "node_id" in df.columns else (
                            "customer_id" if "customer_id" in df.columns else None
                        )
                        if id_src:
                            scored_id = "node_id" if "node_id" in scored.columns else "customer_id"
                            merged = scored.merge(df[[id_src, "state"]].rename(columns={id_src: scored_id}), on=scored_id, how="inner")
                            _tmp2 = merged[merged["state"].notna() & (merged["state"] != "N/A")]
                            if not _tmp2.empty:
                                us = _tmp2.rename(columns={scored_id: "node_id"})
                                break
        if us is None or us.empty:
            return _empty
        state_cnt = us.groupby("state")["node_id"].count().reset_index(name="node_count")
        state_cnt = state_cnt[state_cnt["state"].astype(str).str.len() <= 3]
        if state_cnt.empty:
            return _empty
        fig = go.Figure(go.Choropleth(
            locations=state_cnt["state"],
            z=state_cnt["node_count"],
            locationmode="USA-states",
            colorscale=[[0.0, "#0D3349"], [0.5, "#00D4FF"], [1.0, "#B39DDB"]],
            zmin=0,
            zmax=max(state_cnt["node_count"].max(), 1),
            colorbar=dict(
                title="Customer Count",
                tickfont=dict(color="#94A3B8"),
                titlefont=dict(color="#94A3B8"),
                bgcolor="rgba(0,0,0,0)",
            ),
            customdata=state_cnt[["node_count"]].values,
            hovertemplate="<b>%{location}</b><br>Customers: %{customdata[0]}<extra></extra>",
            marker_line_color="rgba(255,255,255,0.2)",
            marker_line_width=0.5,
        ))
        fig.update_layout(
            geo=dict(
                scope="usa",
                showlakes=False,
                lakecolor="rgba(0,0,0,0)",
                bgcolor="rgba(0,0,0,0)",
                landcolor="rgba(30,41,59,0.6)",
                coastlinecolor="rgba(255,255,255,0.1)",
                showcoastlines=True,
            ),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            font=dict(color="#94A3B8"),
            margin=dict(l=0, r=0, t=0, b=0),
            height=450,
        )
        return fig
    except Exception:
        return _empty


# ── v16.69: Global World Choropleth helper ────────────────────────────────────
def _build_world_map(pipeline, country_stats: dict) -> go.Figure:
    """Build a global choropleth map coloured by average AML risk score per country."""
    _empty = go.Figure()
    _empty.update_layout(
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        template="plotly_dark",
        annotations=[dict(
            text="No country data — run pipeline first.",
            showarrow=False, font=dict(color="#64748B", size=13),
            x=0.5, y=0.5, xref="paper", yref="paper",
        )],
    )
    try:
        if not country_stats:
            return _empty
        rows = []
        for country, st in country_stats.items():
            avg_risk = round(st["total_risk"] / max(st["count"], 1), 1)
            rows.append({"country": country, "avg_risk": avg_risk, "node_count": st["count"]})
        cdf = pd.DataFrame(rows)
        if cdf.empty:
            return _empty
        fig = go.Figure(go.Choropleth(
            locations=cdf["country"],
            locationmode="country names",
            z=cdf["avg_risk"],
            colorscale=[[0.0, "#00E676"], [0.4, "#FFD600"], [0.7, "#FF9800"], [1.0, "#FF1744"]],
            zmin=0,
            zmax=100,
            colorbar=dict(
                title="Avg Risk Score",
                tickfont=dict(color="#94A3B8"),
                titlefont=dict(color="#94A3B8"),
                bgcolor="rgba(0,0,0,0)",
            ),
            customdata=cdf[["avg_risk", "node_count"]].values,
            hovertemplate=(
                "<b>%{location}</b><br>"
                "Avg Risk Score: %{customdata[0]:.1f}<br>"
                "Customers: %{customdata[1]}<extra></extra>"
            ),
            marker_line_color="rgba(255,255,255,0.15)",
            marker_line_width=0.5,
        ))
        fig.update_layout(
            geo=dict(
                showframe=False,
                showcoastlines=True,
                coastlinecolor="rgba(255,255,255,0.1)",
                showland=True,
                landcolor="rgba(30,41,59,0.6)",
                showocean=True,
                oceancolor="rgba(10,14,23,0.8)",
                showlakes=False,
                bgcolor="rgba(0,0,0,0)",
                projection_type="natural earth",
            ),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            font=dict(color="#94A3B8"),
            margin=dict(l=0, r=0, t=0, b=0),
            height=520,
        )
        return fig
    except Exception:
        return _empty


def _stat_card(value, label, icon, color):    return dmc.Paper(
        [
            dmc.Group(
                [
                    dmc.ThemeIcon(
                        DashIconify(icon=icon, width=20),
                        size="lg",
                        radius="md",
                        variant="light",
                        color=color,
                    ),
                    dmc.Stack(
                        [
                            dmc.Text(value, fw=700, c="white", size="lg"),
                            dmc.Text(label, c="dimmed", size="xs"),
                        ],
                        gap=0,
                    ),
                ],
                gap="sm",
            ),
        ],
        p="md",
        radius="lg",
        className="glass-card stat-card",
    )


# ── EXPORT CALLBACK ───────────────────────────────────────────────────────
@callback(
    Output("geo-download", "data"),
    Input("geo-export-csv", "n_clicks"),
    prevent_initial_call=True,
)
def export_geo_csv(_):
    """Export scored customer data with geo-risk columns as CSV."""
    from engine import get_pipeline

    pipeline = get_pipeline()
    scored = pipeline.get_scored_df()
    if scored is not None:
        geo_cols = [
            c
            for c in scored.columns
            if any(
                k in c.lower()
                for k in [
                    "country",
                    "geo",
                    "jurisdiction",
                    "sanction",
                    "node_id",
                    "risk_score",
                    "risk_tier",
                    "customer_name",
                ]
            )
        ]
        if not geo_cols:
            geo_cols = scored.columns.tolist()
        return dcc.send_data_frame(scored[geo_cols].to_csv, "geo_risk_data.csv", index=False)
    return no_update
