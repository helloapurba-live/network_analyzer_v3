"""
Analytics Subpage: Network Influence Hub (Centrality)
======================================================
Metrics: PageRank, Betweenness, Closeness, Degree, Eigenvector
v7: Approx Betweenness (cutoff=4), Personalized PageRank
"""

import dash
from dash import html, dcc, callback, Input, Output, State
import dash_mantine_components as dmc
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from config import THEME
from engine import get_pipeline
from utils.logger import GlobalExceptionHandler
from pages.analytics import (
    empty_fig,
    styled_layout,
    make_family_layout,
    make_data_table,
    CHART_BG,
    CHART_TEXT,
    CHART_GRID,
)

dash.register_page(
    __name__,
    path="/analytics/centrality",
    name="Relationship Influence",
    title="FCDAI | Network Influence Hub",
)

layout = make_family_layout(
    family_key="centrality",
    family_title="Relationship Influence",
    family_icon="mdi:star-four-points",
    family_color="#00D4FF",
    description="PageRank, Approx Betweenness, Closeness, Degree & Eigenvector — igraph C-backend",
    chart_ids=[
        "chart-centrality-dist",
        "chart-centrality-scatter",
        "chart-centrality-top20",
        "chart-centrality-correlation",
        "chart-centrality-kcore",
    ],
    chart_labels=[
        "Centrality Distribution (All Metrics)",
        "PageRank vs Betweenness",
        "Top 20 by PageRank",
        "Centrality Correlation Heatmap",
        "Top 20 by K-Core (Ring Embedding Depth)",
    ],
    business_context=dict(
        summary=(
            "This page identifies the most powerful connectors in the transaction network. "
            "Using five mathematical influence measures, it scores each customer by how much "
            "control they have over money flows — even if their individual transactions look normal."
        ),
        why_it_matters=(
            "A money launderer does not need to be the biggest spender — they need to be the "
            "best connector. High-influence customers act as hubs or bridges that route funds "
            "through the network undetected. These customers appear at the centre of suspicious flows."
        ),
        when_to_act=(
            "Escalate any customer in the Top 20 by PageRank who also carries a P1 or P2 risk tier. "
            "A high betweenness score combined with high risk score means the customer is a critical "
            "choke point for illicit money movement — flag for immediate investigation."
        ),
    ),
    chart_descriptions=[
        "Shows the spread of all five influence scores across every customer. A cluster of customers "
        "with very high scores (right side of each box) indicates a concentrated group of "
        "network controllers worth deeper scrutiny.",
        "Each dot is a customer. Customers in the top-right corner score high on BOTH PageRank "
        "(overall importance) AND Betweenness (bridge control) — they are the highest-priority "
        "targets as they both direct and route suspicious money.",
        "The 20 most influential customers ranked by PageRank. Longer bars mean higher network "
        "power. Cross-reference with the risk tier: a P1/P2 customer here is a top investigation priority.",
        "Shows how strongly the five influence measures agree with each other (dark red = strong "
        "agreement, dark blue = opposite behaviour). Strong correlation confirms a consistent "
        "signal; weak correlation means different metrics are catching different suspect profiles.",
        # v15.6 K-Core description
        "K-Core depth measures how deeply embedded each customer is inside transaction rings. "
        "A K-Core of 1 means peripheral (one connection). K-Core 3+ means inside a tight loop. "
        "Investigators should focus on customers with K-Core ≥5 who also carry P1 or P2 risk tiers — "
        "they sit at the very centre of potential criminal ring structures.",
    ],
)


@callback(
    Output("chart-centrality-dist", "figure"),
    Output("chart-centrality-scatter", "figure"),
    Output("chart-centrality-top20", "figure"),
    Output("chart-centrality-correlation", "figure"),
    Output("chart-centrality-kcore", "figure"),
    Output("table-centrality", "children"),
    Output("rows-centrality", "children"),
    Output("status-centrality", "children"),
    Input("btn-run-centrality", "n_clicks"),
    Input("pipeline-state", "data"),
    Input("global-refresh-ts", "data"),
    prevent_initial_call=False,
)
@GlobalExceptionHandler.wrap(
    fallback=(
        empty_fig(),
        empty_fig(),
        empty_fig(),
        empty_fig(),
        empty_fig(),
        "No data",
        "0 rows",
        dmc.Badge("Error", color="red", variant="light"),
    )
)
def update_centrality(n_clicks, _ps, _gr):
    pipeline = get_pipeline()

    if n_clicks:
        try:
            pipeline.run_single_family("centrality")
        except Exception:
            pass

    df = pipeline.get_family_results("centrality")
    if df is None or len(df) == 0:
        return (
            empty_fig(),
            empty_fig(),
            empty_fig(),
            empty_fig(),
            empty_fig(),
            "No data",
            "0 rows",
            dmc.Badge("No data", color="yellow", variant="light"),
        )

    metrics = [c for c in df.columns if c != "node_id"]

    # 1. Distribution box plot
    fig1 = go.Figure()
    for m in metrics:
        fig1.add_trace(go.Box(y=df[m], name=m.replace("_", " ").title(), marker_color="#00D4FF"))
    styled_layout(fig1)
    fig1.update_layout(title_text="", showlegend=False)

    # 2. PageRank vs Betweenness scatter
    fig2 = go.Figure()
    if "pagerank" in df.columns and "betweenness" in df.columns:
        fig2.add_trace(
            go.Scatter(
                x=df["pagerank"],
                y=df["betweenness"],
                mode="markers",
                marker=dict(
                    size=5,
                    color=df.get("degree_centrality", df["pagerank"]),
                    colorscale="Viridis",
                    showscale=True,
                    colorbar=dict(title="Degree"),
                ),
                text=df["node_id"],
                hovertemplate="<b>%{text}</b><br>PR: %{x:.4f}<br>BC: %{y:.4f}<extra></extra>",
            )
        )
    styled_layout(fig2)
    fig2.update_layout(xaxis_title="PageRank", yaxis_title="Betweenness")

    # 3. Top 20 by PageRank
    fig3 = go.Figure()
    if "pagerank" in df.columns:
        top = df.nlargest(20, "pagerank")
        fig3.add_trace(
            go.Bar(
                x=top["pagerank"],
                y=top["node_id"],
                orientation="h",
                marker=dict(color=top["pagerank"], colorscale="Cividis"),
            )
        )
    styled_layout(fig3)
    fig3.update_layout(yaxis=dict(autorange="reversed"), xaxis_title="PageRank Score")

    # 4. Correlation heatmap
    fig4 = go.Figure()
    if len(metrics) > 1:
        corr = df[metrics].corr()
        fig4.add_trace(
            go.Heatmap(
                z=corr.values,
                x=corr.columns,
                y=corr.columns,
                colorscale="RdBu_r",
                zmin=-1,
                zmax=1,
                text=corr.values.round(2),
                texttemplate="%{text}",
            )
        )
    styled_layout(fig4)

    # v15.6: K-Core bar chart — Ring Embedding Depth
    # Business: K-core 1 = peripheral, 3+ = inside tight loop, 5+ = deep ring centre
    fig5 = empty_fig()
    if "k_core" in df.columns:
        try:
            top_kc = df.nlargest(20, "k_core")[["node_id", "k_core"]].copy()
            # Colour nodes by depth: shallow=blue, deep=red
            _max_k = max(top_kc["k_core"].max(), 1)
            fig5 = go.Figure()
            fig5.add_trace(
                go.Bar(
                    x=top_kc["k_core"],
                    y=top_kc["node_id"],
                    orientation="h",
                    marker=dict(
                        color=top_kc["k_core"],
                        colorscale=[[0, "#00D4FF"], [0.5, "#FF9800"], [1.0, "#FF1744"]],
                        cmin=0,
                        cmax=_max_k,
                        showscale=True,
                        colorbar=dict(title="K-Core Depth"),
                    ),
                    hovertemplate="<b>%{y}</b><br>K-Core: %{x}<extra></extra>",
                )
            )
            styled_layout(fig5)
            fig5.update_layout(
                yaxis=dict(autorange="reversed"),
                xaxis_title="K-Core Depth (higher = deeper in ring)",
            )
        except Exception:
            pass

    table = make_data_table(df)
    status = dmc.Badge(f"{len(df):,} nodes analyzed", color="green", variant="light")
    return fig1, fig2, fig3, fig4, fig5, table, f"{len(df):,} rows", status


@callback(
    Output("download-centrality", "data"),
    Input("btn-export-centrality", "n_clicks"),
    prevent_initial_call=True,
)
def export_centrality(n):
    df = get_pipeline().get_family_results("centrality")
    if df is not None:
        return dcc.send_data_frame(df.to_csv, "centrality_analysis.csv", index=False)
