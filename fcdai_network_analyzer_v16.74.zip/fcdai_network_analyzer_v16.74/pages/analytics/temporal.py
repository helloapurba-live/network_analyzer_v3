"""
Analytics Subpage: Dynamic Velocity Analyzer (Temporal)
========================================================
Metrics: Velocity Ratio, Burst Detection, Burst Score
v7: NumPy vectorized (zero-loop)
"""

import dash
from dash import html, dcc, callback, Input, Output
import dash_mantine_components as dmc
import plotly.graph_objects as go
import pandas as pd
import numpy as np
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from config import THEME
from engine import get_pipeline
from utils.logger import GlobalExceptionHandler
from pages.analytics import empty_fig, styled_layout, make_family_layout, make_data_table

dash.register_page(
    __name__,
    path="/analytics/temporal",
    name="Time-Pattern Risk Analysis",
    title="FCDAI | Dynamic Velocity Analyzer",
)

layout = make_family_layout(
    family_key="temporal",
    family_title="Time-Pattern Risk Analysis",
    family_icon="mdi:clock-fast",
    family_color="#00E676",
    description="Velocity ratio, burst detection & activity spike analysis — NumPy vectorized",
    chart_ids=["chart-temp-velocity", "chart-temp-burst", "chart-temp-scatter", "chart-temp-pie"],
    business_context=dict(
        summary=(
            "This page measures how fast customers are moving money relative to their typical "
            "pattern. It detects sudden bursts of activity that are a classic signature of "
            "structuring, layering, and rapid fund movement designed to evade detection."
        ),
        why_it_matters=(
            "Criminals deliberately accelerate transactions during layering phases to move "
            "funds before investigators can react. A customer who normally makes 2 transactions "
            "a week suddenly making 40 in a day is a high-urgency flag that requires same-day response."
        ),
        when_to_act=(
            "Customers with velocity ratio above 3.0 or a burst score in the top decile "
            "should be placed on priority review. If their risk tier is P1 or P2, escalate "
            "immediately to a compliance officer for a same-day transaction freeze assessment."
        ),
    ),
    chart_descriptions=[
        "Distribution of velocity ratios across all customers. A ratio of 1.0 is normal "
        "(matching their historical average). Customers with ratios above 3.0 are moving "
        "money 3x faster than usual — a strong indicator of layering in progress.",
        "Distribution of burst scores. A burst score measures sudden spikes — customers with "
        "a high burst score had periods of dramatically increased transaction frequency. "
        "Even a single burst event in a P1 customer warrants immediate investigation.",
        "Each customer plotted by both velocity and burst score. The top-right quadrant "
        "represents customers who are both consistently fast AND have had sudden spikes — "
        "the highest-risk velocity profile and the most urgent escalation candidates.",
        "Breakdown of customers by activity tier: Normal, Elevated, High Velocity, and Burst. "
        "The proportion in the Burst and High Velocity segments is a key risk indicator for "
        "the overall health of the portfolio.",
    ],
    chart_labels=[
        "Velocity Ratio Distribution",
        "Burst Score Distribution",
        "Velocity vs Burst Score",
        "Burst Flag Breakdown",
    ],
)


@callback(
    Output("chart-temp-velocity", "figure"),
    Output("chart-temp-burst", "figure"),
    Output("chart-temp-scatter", "figure"),
    Output("chart-temp-pie", "figure"),
    Output("table-temporal", "children"),
    Output("rows-temporal", "children"),
    Output("status-temporal", "children"),
    Input("btn-run-temporal", "n_clicks"),
    Input("pipeline-state", "data"),
    Input("global-refresh-ts", "data"),
    prevent_initial_call=False,
)
@GlobalExceptionHandler.wrap(
    fallback=(
        empty_fig(),
        empty_fig(),
        empty_fig(),
        empty_fig(),
        "No data",
        "0 rows",
        dmc.Badge("Error", color="red", variant="light"),
    )
)
def update_temporal(n_clicks, _ps, _gr):
    pipeline = get_pipeline()
    if n_clicks:
        try:
            pipeline.run_single_family("temporal")
        except Exception:
            pass

    df = pipeline.get_family_results("temporal")
    if df is None or len(df) == 0:
        return (
            empty_fig(),
            empty_fig(),
            empty_fig(),
            empty_fig(),
            "No data",
            "0 rows",
            dmc.Badge("No data", color="yellow", variant="light"),
        )

    # 1. Velocity distribution
    fig1 = go.Figure()
    if "velocity_ratio" in df.columns:
        fig1.add_trace(
            go.Histogram(
                x=df["velocity_ratio"],
                nbinsx=50,
                marker=dict(color="#00E676"),
            )
        )
    styled_layout(fig1)
    fig1.update_layout(xaxis_title="Velocity Ratio", yaxis_title="Count")

    # 2. Burst score distribution
    fig2 = go.Figure()
    if "burst_score" in df.columns:
        fig2.add_trace(
            go.Histogram(
                x=df["burst_score"],
                nbinsx=50,
                marker=dict(color="#76FF03"),
            )
        )
    styled_layout(fig2)
    fig2.update_layout(xaxis_title="Burst Score", yaxis_title="Count")

    # 3. Velocity vs Burst scatter
    fig3 = go.Figure()
    if "velocity_ratio" in df.columns and "burst_score" in df.columns:
        colors = df.get("is_burst", pd.Series([0] * len(df)))
        fig3.add_trace(
            go.Scatter(
                x=df["velocity_ratio"],
                y=df["burst_score"],
                mode="markers",
                marker=dict(
                    size=5, color=["#FF1744" if b else "#00E676" for b in colors], opacity=0.6
                ),
                text=df["node_id"],
                hovertemplate="<b>%{text}</b><br>Velocity: %{x:.2f}<br>Burst: %{y:.4f}<extra></extra>",
            )
        )
    styled_layout(fig3)
    fig3.update_layout(xaxis_title="Velocity Ratio", yaxis_title="Burst Score")

    # 4. Burst flag pie
    fig4 = go.Figure()
    if "is_burst" in df.columns:
        burst_counts = df["is_burst"].value_counts()
        labels = ["Normal" if k == 0 else "Burst Detected" for k in burst_counts.index]
        fig4.add_trace(
            go.Pie(
                labels=labels,
                values=burst_counts.values,
                hole=0.5,
                marker=dict(colors=["#00E676", "#FF1744"]),
                textfont=dict(color="white"),
            )
        )
    styled_layout(fig4)

    burst_count = df["is_burst"].sum() if "is_burst" in df.columns else 0
    table = make_data_table(df)
    status = dmc.Badge(f"{burst_count} bursts detected", color="orange", variant="light")
    return fig1, fig2, fig3, fig4, table, f"{len(df):,} rows", status


@callback(
    Output("download-temporal", "data"),
    Input("btn-export-temporal", "n_clicks"),
    prevent_initial_call=True,
)
def export_temporal(n):
    df = get_pipeline().get_family_results("temporal")
    if df is not None:
        return dcc.send_data_frame(df.to_csv, "temporal_analysis.csv", index=False)
