"""
Shared helper module for analytics family subpages.
Provides reusable layout components for all 7 analytics family pages.
"""

import dash
from dash import html, dcc, callback, Input, Output, State, no_update
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import io
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME
from engine import get_pipeline


# =============================================================================
# SHARED THEME
# =============================================================================
CHART_BG = "rgba(0,0,0,0)"
CHART_TEXT = "#94A3B8"
CHART_GRID = "rgba(148,163,184,0.1)"


def empty_fig(msg="No data available — run the pipeline first"):
    fig = go.Figure()
    fig.add_annotation(text=msg, showarrow=False, font=dict(color="#64748B", size=14))
    fig.update_layout(
        paper_bgcolor=CHART_BG, plot_bgcolor=CHART_BG, margin=dict(l=30, r=30, t=30, b=30)
    )
    return fig


def styled_layout(fig):
    """Apply dark theme to a plotly figure."""
    fig.update_layout(
        paper_bgcolor=CHART_BG,
        plot_bgcolor=CHART_BG,
        font=dict(color=CHART_TEXT),
        xaxis=dict(gridcolor=CHART_GRID, zerolinecolor=CHART_GRID),
        yaxis=dict(gridcolor=CHART_GRID, zerolinecolor=CHART_GRID),
        margin=dict(l=40, r=30, t=40, b=40),
        legend=dict(font=dict(color=CHART_TEXT)),
    )
    return fig


def make_family_layout(
    family_key,
    family_title,
    family_icon,
    family_color,
    description,
    chart_ids,
    chart_labels,
    business_context=None,
    chart_descriptions=None,
):
    """Generate a standard layout for an analytics family page.

    Parameters
    ----------
    business_context : dict, optional
        Keys: summary (str), why_it_matters (str), when_to_act (str)
        Shown as a CEO-level 'What This Page Does' panel at the top.
    chart_descriptions : list[str], optional
        One plain-English sentence per chart explaining what a non-technical
        person should take away from it.  Rendered under each chart title.
    """
    # ── CEO Business Context Panel ────────────────────────────────────────────
    ceo_panel = None
    if business_context:
        ceo_panel = dmc.Paper(
            [
                dmc.Group(
                    [
                        dmc.ThemeIcon(
                            DashIconify(icon="mdi:information-outline", width=20),
                            size="md",
                            radius="xl",
                            color="cyan",
                            variant="light",
                        ),
                        dmc.Text("What This Page Does", fw=700, size="sm", c="white"),
                        dmc.Badge(
                            "LIVE — Auto-updates with every pipeline run",
                            color="green",
                            variant="light",
                            size="xs",
                            leftSection=DashIconify(icon="mdi:sync", width=12),
                        ),
                    ],
                    gap="xs",
                    mb="sm",
                ),
                dmc.SimpleGrid(
                    cols={"base": 1, "md": 3},
                    spacing="sm",
                    children=[
                        # Summary
                        dmc.Box(
                            [
                                dmc.Group(
                                    [
                                        DashIconify(
                                            icon="mdi:book-open-outline", width=16, color="#00D4FF"
                                        ),
                                        dmc.Text("Overview", size="xs", fw=700, c="#00D4FF"),
                                    ],
                                    gap=4,
                                    mb=4,
                                ),
                                dmc.Text(
                                    business_context.get("summary", ""),
                                    size="xs",
                                    c="dimmed",
                                    style={"lineHeight": "1.5"},
                                ),
                            ],
                            style={
                                "background": "rgba(0,212,255,0.05)",
                                "border": "1px solid rgba(0,212,255,0.12)",
                                "borderRadius": "8px",
                                "padding": "10px",
                            },
                        ),
                        # Why it matters
                        dmc.Box(
                            [
                                dmc.Group(
                                    [
                                        DashIconify(
                                            icon="mdi:briefcase-outline", width=16, color="#FFD600"
                                        ),
                                        dmc.Text("Why It Matters", size="xs", fw=700, c="#FFD600"),
                                    ],
                                    gap=4,
                                    mb=4,
                                ),
                                dmc.Text(
                                    business_context.get("why_it_matters", ""),
                                    size="xs",
                                    c="dimmed",
                                    style={"lineHeight": "1.5"},
                                ),
                            ],
                            style={
                                "background": "rgba(255,214,0,0.05)",
                                "border": "1px solid rgba(255,214,0,0.12)",
                                "borderRadius": "8px",
                                "padding": "10px",
                            },
                        ),
                        # When to act
                        dmc.Box(
                            [
                                dmc.Group(
                                    [
                                        DashIconify(
                                            icon="mdi:alert-circle-outline",
                                            width=16,
                                            color="#FF6B6B",
                                        ),
                                        dmc.Text("When to Act", size="xs", fw=700, c="#FF6B6B"),
                                    ],
                                    gap=4,
                                    mb=4,
                                ),
                                dmc.Text(
                                    business_context.get("when_to_act", ""),
                                    size="xs",
                                    c="dimmed",
                                    style={"lineHeight": "1.5"},
                                ),
                            ],
                            style={
                                "background": "rgba(255,107,107,0.05)",
                                "border": "1px solid rgba(255,107,107,0.12)",
                                "borderRadius": "8px",
                                "padding": "10px",
                            },
                        ),
                    ],
                ),
            ],
            p="md",
            radius="lg",
            className="glass-card",
            mb="md",
            style={"borderLeft": f"3px solid {family_color}"},
        )

    # ── Charts with inline explanations ──────────────────────────────────────
    charts = []
    for i, (chart_id, label) in enumerate(zip(chart_ids, chart_labels)):
        chart_desc = (
            chart_descriptions[i] if chart_descriptions and i < len(chart_descriptions) else None
        )
        charts.append(
            dmc.Paper(
                [
                    dmc.Text(label, size="sm", fw=600, c="white"),
                    (
                        dmc.Text(
                            chart_desc, size="xs", c="dimmed", mb="sm", style={"lineHeight": "1.4"}
                        )
                        if chart_desc
                        else dmc.Space(h=6)
                    ),
                    dcc.Graph(
                        id=chart_id,
                        config={
                            "displayModeBar": True,
                            "toImageButtonOptions": {"format": "png", "scale": 2},
                        },
                        style={"height": "350px"},
                    ),
                ],
                p="lg",
                radius="lg",
                className="glass-card",
            )
        )

    return dmc.Box(
        [
            # Header — v12.29: refresh button top-right
            dmc.Group(
                [
                    dmc.Group(
                        [
                            dmc.ThemeIcon(
                                DashIconify(icon=family_icon, width=28),
                                size="xl",
                                radius="md",
                                variant="gradient",
                                gradient={"from": family_color, "to": "indigo"},
                            ),
                            dmc.Stack(
                                [
                                    dmc.Title(family_title, order=2, c="white"),
                                    dmc.Text(description, c="dimmed", size="sm"),
                                ],
                                gap=2,
                            ),
                        ],
                        gap="md",
                    ),
                ],
                justify="space-between",
                mb="lg",
            ),
            # CEO Panel
            *([ceo_panel] if ceo_panel else []),
            # Controls Row
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            dmc.Button(
                                f"Re-run {family_title}",
                                id=f"btn-run-{family_key}",
                                leftSection=DashIconify(icon="mdi:play-circle"),
                                color="cyan",
                                variant="gradient",
                                gradient={"from": "cyan", "to": "indigo"},
                                size="sm",
                            ),
                            dmc.Button(
                                "Export CSV",
                                id=f"btn-export-{family_key}",
                                leftSection=DashIconify(icon="mdi:download"),
                                color="green",
                                variant="outline",
                                size="sm",
                            ),
                            dcc.Download(id=f"download-{family_key}"),
                            html.Div(
                                id=f"status-{family_key}",
                                children=dmc.Badge("Ready", color="gray", variant="light"),
                            ),
                            dmc.Badge(
                                "Auto-syncs with main pipeline",
                                color="cyan",
                                variant="dot",
                                size="xs",
                                leftSection=DashIconify(icon="mdi:sync-circle", width=12),
                                style={"marginLeft": "auto"},
                            ),
                        ],
                        gap="md",
                    ),
                ],
                p="md",
                radius="lg",
                className="glass-card",
                mb="md",
            ),
            # Charts
            dmc.SimpleGrid(
                cols={"base": 1, "lg": 2},
                spacing="md",
                children=charts,
            ),
            dmc.Space(h="md"),
            # Data Table
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            dmc.Text("Raw Data Table", size="sm", fw=600, c="white"),
                            dmc.Text(
                                "Every row is one customer. Each column is a metric score produced by this engine.",
                                size="xs",
                                c="dimmed",
                            ),
                            dmc.Badge(
                                id=f"rows-{family_key}",
                                children="0 rows",
                                color="cyan",
                                variant="light",
                                size="sm",
                            ),
                        ],
                        justify="space-between",
                        mb="sm",
                    ),
                    html.Div(
                        id=f"table-{family_key}",
                        style={"maxHeight": "400px", "overflowY": "auto", "overflowX": "auto"},
                    ),
                ],
                p="lg",
                radius="lg",
                className="glass-card",
            ),
        ]
    )


def make_data_table(df, max_rows=200):
    """Create an HTML table from a DataFrame. v16.69: auto-injects Customer Name column."""
    if df is None or len(df) == 0:
        return dmc.Text("No data available", c="dimmed", size="sm")

    display_df = df.head(max_rows).copy()

    # v16.69: inject Customer Name after the node/customer id column
    _id_col = next(
        (c for c in ("node_id", "customer_id", "id") if c in display_df.columns), None
    )
    if _id_col:
        try:
            _p = get_pipeline()
            _name_map = {}
            for _tbl_name in ("node", "customer"):
                _tbl = _p.tables.get(_tbl_name) if hasattr(_p, "tables") else None
                if _tbl is not None:
                    _nc = next(
                        (c for c in ("customer_name", "name", "full_name", "entity_name") if c in _tbl.columns),
                        None,
                    )
                    _ni = next(
                        (c for c in ("node_id", "customer_id", "id") if c in _tbl.columns), None
                    )
                    if _nc and _ni:
                        _name_map = dict(zip(_tbl[_ni].astype(str), _tbl[_nc].astype(str)))
                        break
            if _name_map and "Customer Name" not in display_df.columns:
                _insert_pos = list(display_df.columns).index(_id_col) + 1
                display_df.insert(
                    _insert_pos,
                    "Customer Name",
                    display_df[_id_col].astype(str).map(_name_map).fillna("—"),
                )
        except Exception:
            pass

    # Round numeric columns
    for col in display_df.select_dtypes(include=["float64", "float32"]).columns:
        display_df[col] = display_df[col].round(6)

    header = html.Thead(
        html.Tr(
            [
                html.Th(
                    col,
                    style={
                        "padding": "8px 12px",
                        "color": THEME.TEXT_PRIMARY,
                        "borderBottom": f"1px solid {THEME.DARK_BORDER}",
                        "fontSize": "12px",
                        "whiteSpace": "nowrap",
                    },
                )
                for col in display_df.columns
            ]
        )
    )
    rows = []
    for _, row in display_df.iterrows():
        cells = []
        for val in row:
            cells.append(
                html.Td(
                    str(val)[:50],
                    style={
                        "padding": "6px 12px",
                        "color": "#CBD5E1",
                        "borderBottom": "1px solid rgba(255,255,255,0.05)",
                        "fontSize": "12px",
                        "whiteSpace": "nowrap",
                    },
                )
            )
        rows.append(html.Tr(cells))
    body = html.Tbody(rows)

    return html.Table(
        [header, body],
        style={
            "width": "100%",
            "borderCollapse": "collapse",
            "backgroundColor": "rgba(0,0,0,0.2)",
            "borderRadius": "8px",
        },
    )
