"""
Analytics Subpage: Laundering Traceability Logic (PathFlow)
============================================================
Metrics: K-Shortest Path Length, Flow Centrality
v7: K-shortest paths (top-k=5), betweenness with cutoff
"""

import dash
from dash import html, dcc, callback, Input, Output
import dash_mantine_components as dmc
import plotly.graph_objects as go
import pandas as pd
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from config import THEME
from engine import get_pipeline
from utils.logger import GlobalExceptionHandler
from pages.analytics import empty_fig, styled_layout, make_family_layout, make_data_table

dash.register_page(
    __name__,
    path="/analytics/pathflow",
    name="Money Flow Tracing",
    title="FCDAI | Laundering Traceability Logic",
)

layout = make_family_layout(
    family_key="pathflow",
    family_title="Money Flow Tracing",
    family_icon="mdi:transit-connection-variant",
    family_color="#FF6B6B",
    description="K-shortest paths & flow centrality — reveals money laundering chains",
    chart_ids=["chart-pf-dist", "chart-pf-scatter", "chart-pf-top20", "chart-pf-hist"],
    business_context=dict(
        summary=(
            "This page traces how money travels through the network, mapping the exact routes "
            "funds take between customers. It reveals multi-hop laundering chains where money "
            "passes through several accounts before reaching its destination."
        ),
        why_it_matters=(
            "Professional money launderers add layers specifically to confuse investigators. "
            "Traceability cuts through those layers by computing the shortest and most-used "
            "paths between every customer pair, exposing the hidden highways dirty money uses."
        ),
        when_to_act=(
            "Customers with very high Flow Centrality scores are the critical waypoints in "
            "money laundering routes. If any of these customers carry P1/P2 risk tiers, "
            "freeze their accounts and trace all transactions two hops upstream and downstream."
        ),
    ),
    chart_descriptions=[
        "Shows how many steps (hops between accounts) funds typically travel in this network. "
        "A peak at 2–3 hops is normal; a peak at 5+ hops suggests deliberate layering "
        "to disguise the money trail.",
        "Each customer plotted by both path length and how often their account appears on "
        "shortest paths. Customers in the top-right control the most important routes and "
        "should be treated as potential laundering conduits.",
        "The 20 customers whose accounts appear most often on shortest-paths through the "
        "network. Being a frequent waypoint is a strong indicator of deliberate routing "
        "even when individual transaction amounts look unremarkable.",
        "Overall distribution of flow centrality scores. A long right tail "
        "(a few customers with very high scores) indicates a concentrated small group "
        "managing the vast majority of the money routing — an immediate red flag.",
    ],
    chart_labels=[
        "Path Length Distribution",
        "Path Length vs Flow Centrality",
        "Top 20 by Flow Centrality",
        "Flow Centrality Histogram",
    ],
)


@callback(
    Output("chart-pf-dist", "figure"),
    Output("chart-pf-scatter", "figure"),
    Output("chart-pf-top20", "figure"),
    Output("chart-pf-hist", "figure"),
    Output("table-pathflow", "children"),
    Output("rows-pathflow", "children"),
    Output("status-pathflow", "children"),
    Input("btn-run-pathflow", "n_clicks"),
    Input("pipeline-state", "data"),
    Input("global-refresh-ts", "data"),
    prevent_initial_call=False,
)
@GlobalExceptionHandler.wrap(
    fallback=(
        empty_fig(),
        empty_fig(),
        empty_fig(),
        empty_fig(),
        "No data",
        "0 rows",
        dmc.Badge("Error", color="red", variant="light"),
    )
)
def update_pathflow(n_clicks, _ps, _gr):
    pipeline = get_pipeline()
    if n_clicks:
        try:
            pipeline.run_single_family("pathflow")
        except Exception:
            pass

    df = pipeline.get_family_results("pathflow")
    if df is None or len(df) == 0:
        return (
            empty_fig(),
            empty_fig(),
            empty_fig(),
            empty_fig(),
            "No data",
            "0 rows",
            dmc.Badge("No data", color="yellow", variant="light"),
        )

    # 1. Path length distribution
    fig1 = go.Figure()
    if "avg_path_length" in df.columns:
        fig1.add_trace(
            go.Histogram(
                x=df["avg_path_length"],
                nbinsx=40,
                marker=dict(color="#FF6B6B"),
            )
        )
    styled_layout(fig1)
    fig1.update_layout(xaxis_title="Avg Path Length", yaxis_title="Count")

    # 2. Path vs Flow scatter
    fig2 = go.Figure()
    if "avg_path_length" in df.columns and "flow_centrality" in df.columns:
        fig2.add_trace(
            go.Scatter(
                x=df["avg_path_length"],
                y=df["flow_centrality"],
                mode="markers",
                marker=dict(size=4, color="#FF6B6B", opacity=0.5),
                text=df["node_id"],
                hovertemplate="<b>%{text}</b><br>Path: %{x:.3f}<br>Flow: %{y:.4f}<extra></extra>",
            )
        )
    styled_layout(fig2)
    fig2.update_layout(xaxis_title="Avg Path Length", yaxis_title="Flow Centrality")

    # 3. Top 20 by flow centrality
    fig3 = go.Figure()
    if "flow_centrality" in df.columns:
        top = df.nlargest(20, "flow_centrality")
        fig3.add_trace(
            go.Bar(
                x=top["flow_centrality"],
                y=top["node_id"],
                orientation="h",
                marker=dict(color=top["flow_centrality"], colorscale="Reds"),
            )
        )
    styled_layout(fig3)
    fig3.update_layout(yaxis=dict(autorange="reversed"), xaxis_title="Flow Centrality")

    # 4. Flow centrality histogram
    fig4 = go.Figure()
    if "flow_centrality" in df.columns:
        fig4.add_trace(
            go.Histogram(
                x=df["flow_centrality"],
                nbinsx=40,
                marker=dict(color="#FF9800"),
            )
        )
    styled_layout(fig4)
    fig4.update_layout(xaxis_title="Flow Centrality", yaxis_title="Count")

    table = make_data_table(df)
    status = dmc.Badge(f"{len(df):,} nodes analyzed", color="green", variant="light")
    return fig1, fig2, fig3, fig4, table, f"{len(df):,} rows", status


@callback(
    Output("download-pathflow", "data"),
    Input("btn-export-pathflow", "n_clicks"),
    prevent_initial_call=True,
)
def export_pathflow(n):
    df = get_pipeline().get_family_results("pathflow")
    if df is not None:
        return dcc.send_data_frame(df.to_csv, "pathflow_analysis.csv", index=False)
