"""
Page: Vault (v12.22 — CEO / Business Presentation Format)
============================================================
Business Purpose:
  The Vault is your evidence library. It holds the detailed outputs from
  all 7 categories of financial crime detection algorithms. Each category
  reveals a different dimension of suspicious behaviour:

    Network Influence Hub   — Which customers control the flow of money?
    Cluster Engine          — Which groups of customers move money together?
    Laundering Traceability — Can we trace the path of suspicious funds?
    Hidden Association      — Who is likely to transact but hasn't yet?
    Topological Outlier     — Which customers behave abnormally vs. their peers?
    Dynamic Velocity        — Are transactions speeding up suspiciously?
    Multi-Layer Module      — How are different risk signals combining?

  RISK PRIORITY (P1–P4) always shown at top.
  Use this page to drill into any specific detection family for evidence
  to support Narrative filings or regulatory questions.
"""

import dash
from dash import html, dcc, callback, Input, Output, State, no_update
import dash_mantine_components as dmc
import dash_ag_grid as dag
from dash_iconify import DashIconify
import plotly.graph_objects as go
import numpy as np
import pandas as pd
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, APP
from engine import get_pipeline
from utils.logger import GlobalExceptionHandler
from utils.pii_guard import mask_for_export, mask_value

dash.register_page(
    __name__, path="/vault", name="Vault", title=f"FCDAI v{APP.VERSION} | Evidence Vault"
)

# =============================================================================
# FAMILY NAME MAPPING
# =============================================================================
FAMILY_MAP = {
    "centrality": "Relationship Influence",
    "community": "Risk Group Identification",
    "pathflow": "Money Flow Tracing",
    "link_prediction": "Hidden Relationship Discovery",
    "anomaly": "Behavioural Anomaly Detection",
    "temporal": "Time-Pattern Risk Analysis",
    "multi_layer": "Cross-Entity Risk Assessment",
}

FAMILY_ICONS = {
    "centrality": ("mdi:hub-outline", "#00D4FF"),
    "community": ("mdi:graph", "#9D4EDD"),
    "pathflow": ("mdi:routes", "#00E676"),
    "link_prediction": ("mdi:link-variant", "#FFD600"),
    "anomaly": ("mdi:alert-decagram", "#FF1744"),
    "temporal": ("mdi:clock-fast", "#FF9800"),
    "multi_layer": ("mdi:layers-triple", "#2196F3"),
}

AG_GRID_STYLE = {
    "--ag-background-color": "#0D1117",
    "--ag-header-background-color": "#161B22",
    "--ag-odd-row-background-color": "#0D1117",
    "--ag-row-hover-color": "#1C2333",
    "--ag-header-foreground-color": "#58A6FF",
    "--ag-foreground-color": "#C9D1D9",
    "--ag-border-color": "#21262D",
    "--ag-row-border-color": "#21262D",
    "--ag-font-size": "12px",
    "--ag-grid-size": "4px",
}


# Business-facing description for each analytics family
FAMILY_BUSINESS_DESC = {
    "centrality": (
        "Who controls the money flow? Customers with high Network Influence "
        "are critical nodes — removing or freezing them disrupts the entire network."
    ),
    "community": (
        "Which customers move money together as a coordinated group? "
        "Large communities with shared P1/P2 members are prime Narrative candidates."
    ),
    "pathflow": (
        "Can we follow the money? Shows the shortest paths between suspicious customers, "
        "enabling investigators to trace exactly how funds moved."
    ),
    "link_prediction": (
        "Who is likely to transact next but hasn't yet? Predicts hidden connections "
        "that may indicate undisclosed relationships or future layering."
    ),
    "anomaly": (
        "Which customers behave completely unlike their peers? "
        "Statistical outliers warrant investigation even if individual transactions look normal."
    ),
    "temporal": (
        "Are transactions accelerating? Sudden bursts of activity "
        "(velocity spikes) are a classic layering signal in money laundering."
    ),
    "multi_layer": (
        "When multiple risk signals combine — high network influence AND velocity AND anomaly — "
        "the probability of financial crime rises dramatically. This module shows combined signals."
    ),
}

_VAULT_TIER_COLORS = {"P1": "#FF1744", "P2": "#FF9800", "P3": "#FFD600", "P4": "#00E676"}
_VAULT_TIER_LABELS = {
    "P1": ("CRITICAL", "80–100", "Freeze & Investigate NOW."),
    "P2": ("HIGH RISK", "60–79", "Enhanced due diligence required."),
    "P3": ("MEDIUM", "40–59", "Active monitoring — schedule review."),
    "P4": ("LOW", "0–39", "Standard monitoring continues."),
}


def _risk_tier_legend():
    """Always-visible P1-P4 risk priority panel."""
    items = []
    for code in ("P1", "P2", "P3", "P4"):
        label, score_range, desc = _VAULT_TIER_LABELS[code]
        color = _VAULT_TIER_COLORS[code]
        items.append(
            dmc.Group(
                [
                    html.Div(
                        style={
                            "width": "12px",
                            "height": "12px",
                            "borderRadius": "50%",
                            "backgroundColor": color,
                            "flexShrink": "0",
                            "border": "1px solid rgba(255,255,255,0.3)",
                        }
                    ),
                    dmc.Text(f"{code}  {label}", fw=600, c=color, size="xs"),
                    dmc.Text(
                        f"(Score {score_range}): {desc}",
                        size="xs",
                        c="dimmed",
                        style={"maxWidth": "280px"},
                    ),
                ],
                gap=4,
                wrap="nowrap",
            ),
        )
    return dmc.Paper(
        dmc.Stack(
            [
                dmc.Group(
                    [
                        DashIconify(icon="mdi:shield-alert", width=18, color="#94A3B8"),
                        dmc.Text(
                            "Risk Priority Reference — P1 to P4", fw=600, c="white", size="sm"
                        ),
                    ],
                    gap="sm",
                ),
                dmc.SimpleGrid(cols={"base": 1, "md": 2}, spacing="xs", children=items),
                dmc.Text(
                    "💡 How to use The Vault: Select a detection category from the dropdown. "
                    "The Score Distribution chart shows how scores are spread. "
                    "The Top 20 chart shows the highest-scoring customers for that category — "
                    "these are the customers most implicated by that particular detection method.",
                    size="xs",
                    c="dimmed",
                    mt="xs",
                    style={"fontStyle": "italic", "lineHeight": "1.5"},
                ),
            ],
            gap="sm",
        ),
        p="md",
        radius="md",
        mb="lg",
        style={"background": "rgba(17,24,39,0.8)", "border": "1px solid rgba(255,255,255,0.08)"},
    )


def _customer_label(node_id):
    # v12.22 BUG-C01 FIX: restored missing 'def' — function body was orphaned inside _risk_tier_legend
    """Show PII-safe label: masked ID only. Never expose raw customer names."""
    if not node_id or not isinstance(node_id, str):
        return str(node_id or "")
    # PII GUARD: only show partial-masked node_id, never raw name
    return mask_value(node_id, "partial")


def _is_numeric(series):
    """Check if a pandas Series is numeric (covers float32, float64, int32, int64, etc.)."""
    return pd.api.types.is_numeric_dtype(series)


def _empty_fig(msg="Run pipeline first"):
    fig = go.Figure()
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=20, r=20, t=20, b=20),
    )
    fig.add_annotation(text=msg, showarrow=False, font=dict(color="#64748B", size=14))
    return fig


# =============================================================================
# LAYOUT
# =============================================================================
layout = dmc.Box(
    [
        # v12.31: init trigger fires once on page mount to ensure fresh data on navigation
        dcc.Interval(id="vault-init", interval=1000, max_intervals=1),
        # Header
        dmc.Group(
            [
                dmc.Stack(
                    [
                        dmc.Title(
                            "Evidence Vault — Detection Analytics Deep Dive", order=2, c="white"
                        ),
                        dmc.Text(
                            "Drill into any of the 7 financial crime detection categories. "
                            "Each shows which customers scored highest — with names and IDs. "
                            "Use this evidence to support Narrative filings and regulatory queries.",
                            c="dimmed",
                            size="sm",
                        ),
                    ],
                    gap=2,
                ),
                dmc.Group(
                    [
                        dmc.Badge(f"v{APP.VERSION}", color="cyan", variant="outline", size="sm"),
                        dmc.Select(
                            id="vault-family-select",
                            data=[{"value": k, "label": v} for k, v in FAMILY_MAP.items()],
                            value="centrality",
                            w=250,
                            size="sm",
                            leftSection=DashIconify(icon="mdi:filter", width=16),
                            styles={
                                "input": {
                                    "backgroundColor": THEME.DARK_BG,
                                    "color": "white",
                                    "border": f"1px solid {THEME.DARK_BORDER}",
                                }
                            },
                        ),
                        dmc.Button(
                            "Export CSV",
                            leftSection=DashIconify(icon="mdi:download"),
                            id="btn-vault-export",
                            variant="outline",
                            color="cyan",
                            size="sm",
                        ),
                        dcc.Link(
                            dmc.Button("← Dashboard", size="xs", variant="subtle", color="gray"),
                            href="/",
                            style={"textDecoration": "none"},
                        ),
                    ],
                    gap="sm",
                ),
            ],
            justify="space-between",
            mb="lg",
        ),
        # ━━━ RISK PRIORITY LEGEND — always visible ━━━
        _risk_tier_legend(),
        # Active family business description
        html.Div(id="vault-family-desc", style={"marginBottom": "1rem"}),
        # Family Summary Cards
        dmc.SimpleGrid(
            cols={"base": 2, "sm": 4, "lg": 7},
            spacing="sm",
            mb="lg",
            children=[
                dmc.Paper(
                    [
                        dmc.Group(
                            [
                                DashIconify(
                                    icon=FAMILY_ICONS[k][0], width=16, color=FAMILY_ICONS[k][1]
                                ),
                                dmc.Text(v, size="xs", c="dimmed", fw=600),
                            ],
                            gap=4,
                        ),
                        dmc.Text("—", id=f"vault-{k}-count", size="lg", fw=700, c="white"),
                    ],
                    p="sm",
                    radius="md",
                    className="stat-card",
                    ta="center",
                )
                for k, v in FAMILY_MAP.items()
            ],
        ),
        # Charts Row
        dmc.SimpleGrid(
            cols={"base": 1, "lg": 2},
            spacing="md",
            mb="lg",
            children=[
                dmc.Paper(
                    [
                        dmc.Text(
                            "Score Distribution — How Are Customers Spread Across This Risk Dimension?",
                            size="sm",
                            fw=600,
                            c="white",
                            mb="xs",
                        ),
                        dmc.Text(
                            "A spike on the right means more customers are highly implicated. "
                            "Low scores across all customers means this dimension is clean.",
                            size="xs",
                            c="dimmed",
                            mb="sm",
                        ),
                        dcc.Graph(
                            id="vault-distribution-chart",
                            config={"displayModeBar": False},
                            style={"height": "280px"},
                        ),
                    ],
                    p="lg",
                    radius="lg",
                    className="glass-card",
                ),
                dmc.Paper(
                    [
                        dmc.Text(
                            "🚨 Top 20 Most Implicated Customers — by This Detection Method",
                            size="sm",
                            fw=600,
                            c="white",
                            mb="xs",
                        ),
                        dmc.Text(
                            "Longer bar = more suspected involvement based on this specific signal. "
                            "Customer names shown for direct investigation follow-up.",
                            size="xs",
                            c="dimmed",
                            mb="sm",
                        ),
                        dcc.Graph(
                            id="vault-topn-chart",
                            config={"displayModeBar": False},
                            style={"height": "280px"},
                        ),
                    ],
                    p="lg",
                    radius="lg",
                    className="glass-card",
                ),
            ],
        ),
        # AG Grid Results Table
        dmc.Paper(
            [
                dmc.Group(
                    [
                        dmc.Stack(
                            [
                                dmc.Text(
                                    "Full Analytics Results Table — All Customers",
                                    size="sm",
                                    fw=600,
                                    c="white",
                                ),
                                dmc.Text(
                                    "Sorted by score. Hover column headers for explanation. "
                                    "Use the search box to find a specific customer.",
                                    size="xs",
                                    c="dimmed",
                                ),
                            ],
                            gap=2,
                        ),
                        dmc.Badge(id="vault-table-badge", color="cyan", variant="light", size="sm"),
                    ],
                    gap="sm",
                    mb="md",
                ),
                html.Div(id="vault-results-table"),
            ],
            p="lg",
            radius="lg",
            className="glass-card",
        ),
        # Download + Loading
        dcc.Download(id="vault-download"),
    ]
)


# =============================================================================
# CALLBACKS
# =============================================================================
@callback(
    Output("vault-distribution-chart", "figure"),
    Output("vault-topn-chart", "figure"),
    Output("vault-results-table", "children"),
    Output("vault-table-badge", "children"),
    Output("vault-family-desc", "children"),
    *[Output(f"vault-{k}-count", "children") for k in FAMILY_MAP],
    Input("vault-family-select", "value"),
    Input("pipeline-state", "data"),
    Input("global-refresh-ts", "data"),
    Input("vault-init", "n_intervals"),
)
@GlobalExceptionHandler.wrap(
    fallback=(
        _empty_fig(),
        _empty_fig(),
        dmc.Text("No data", c="dimmed"),
        "",
        None,
        *["\u2014"] * 7,
    )
)
def update_vault(family, _pipeline_state, _gr, _init=None):
    """Update vault display for selected analytics family."""
    pipeline = get_pipeline()
    results = pipeline.get_analytics_results()

    # v12.31: Always show real counts when data exists — removed session-ran gate
    # that caused stale data after app restarts and cross-session re-runs
    counts = []
    for k in FAMILY_MAP:
        df = results.get(k) if results else None
        counts.append(f"{len(df):,}" if df is not None else "—")

    # Build business description banner for selected family
    _desc_text = FAMILY_BUSINESS_DESC.get(family, "")
    _family_desc_ui = (
        dmc.Paper(
            dmc.Group(
                [
                    DashIconify(icon="mdi:information-outline", width=18, color="#00D4FF"),
                    dmc.Text(
                        f"{FAMILY_MAP.get(family, family)}: {_desc_text}",
                        size="sm",
                        c="white",
                        style={"lineHeight": "1.6"},
                    ),
                ],
                gap="sm",
                align="flex-start",
            ),
            p="sm",
            radius="md",
            mb="sm",
            style={"background": "rgba(0,212,255,0.06)", "border": "1px solid rgba(0,212,255,0.2)"},
        )
        if _desc_text
        else None
    )

    # Handle reset
    if isinstance(_pipeline_state, dict) and _pipeline_state.get("reset"):
        e = _empty_fig("Data was reset — generate data and run pipeline")
        return (
            e,
            e,
            dmc.Center(dmc.Text("Data was reset", c="dimmed"), style={"minHeight": "200px"}),
            "",
            _family_desc_ui,
            *["—"] * 7,
        )

    if not results or family not in results:
        e = _empty_fig("Run pipeline first")
        return (
            e,
            e,
            dmc.Center(
                dmc.Text("Run pipeline to see analytics", c="dimmed"), style={"minHeight": "200px"}
            ),
            "",
            _family_desc_ui,
            *counts,
        )

    df = results[family]
    if df is None or len(df) == 0:
        e = _empty_fig("No data for this family")
        return (e, e, dmc.Text("No data", c="dimmed"), "", _family_desc_ui, *counts)

    # Use pd.api.types.is_numeric_dtype to catch float32, float64, int32, int64
    numeric_cols = [c for c in df.columns if c != "node_id" and _is_numeric(df[c])]

    if not numeric_cols:
        e = _empty_fig("No numeric metrics")
        return (
            e,
            e,
            dmc.Text("No numeric metrics in this family", c="dimmed"),
            f"{len(df)} rows",
            _family_desc_ui,
            *counts,
        )

    # ── Distribution Histogram ──
    fig1 = go.Figure()
    colors = ["#00D4FF", "#9D4EDD", "#FF6B6B", "#00E676", "#FFD600"]
    for i, col in enumerate(numeric_cols[:4]):
        fig1.add_trace(
            go.Histogram(
                x=df[col].values.astype(float),
                name=col.replace("_", " ").title(),
                opacity=0.7,
                nbinsx=40,
                marker_color=colors[i % len(colors)],
            )
        )
    fig1.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=40, r=20, t=20, b=40),
        legend=dict(font=dict(color="#94A3B8", size=10)),
        xaxis=dict(gridcolor="rgba(255,255,255,0.05)", color="#94A3B8"),
        yaxis=dict(gridcolor="rgba(255,255,255,0.05)", color="#94A3B8"),
        barmode="overlay",
        font=dict(color="#94A3B8", size=11),
    )
    # v12.31: mean annotations per column
    _vault_colors = ["#00D4FF", "#9D4EDD", "#FF6B6B", "#00E676", "#FFD600"]
    _col_annots = [
        dict(
            text=f"{col.replace(chr(95), chr(32)).title()}: μ={df[col].mean():.3f}",
            x=0.98,
            y=0.97 - idx * 0.1,
            xref="paper",
            yref="paper",
            showarrow=False,
            font=dict(color=_vault_colors[idx % len(_vault_colors)], size=9),
            align="right",
            xanchor="right",
        )
        for idx, col in enumerate(numeric_cols[:4])
    ]
    if _col_annots:
        fig1.update_layout(annotations=_col_annots)

    # ── Top-N Bar Chart ──
    main_col = numeric_cols[0]
    top_n = df.nlargest(20, main_col)
    labels = [_customer_label(nid) for nid in top_n["node_id"].values]
    fig2 = go.Figure(
        go.Bar(
            y=labels[::-1],
            x=top_n[main_col].values[::-1].astype(float),
            orientation="h",
            text=[f"{v:.3f}" for v in top_n[main_col].values[::-1]],
            textposition="outside",
            textfont=dict(size=9, color="white"),
            marker=dict(
                color=top_n[main_col].values[::-1].astype(float),
                colorscale=[[0, "#1A2332"], [0.5, "#00D4FF"], [1, "#9D4EDD"]],
            ),
            hovertemplate="<b>%{y}</b><br>Score: %{x:.4f}<extra></extra>",
        )
    )
    fig2.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=140, r=20, t=20, b=40),
        xaxis=dict(gridcolor="rgba(255,255,255,0.05)", color="#94A3B8"),
        yaxis=dict(gridcolor="rgba(255,255,255,0.05)", color="#94A3B8"),
        font=dict(color="#94A3B8", size=11),
    )

    # ── AG Grid Table — add Customer Name as first column ──
    show_df = df.head(100).copy()
    # Convert float32 to float64 for JSON serialization
    for col in show_df.columns:
        if show_df[col].dtype == np.float32:
            show_df[col] = show_df[col].astype(float)
    # Prepend customer name for business readability
    show_df.insert(0, "Customer Name", show_df["node_id"].apply(_customer_label))

    grid_cols = []
    for col in show_df.columns:
        col_def = {
            "field": col,
            "headerName": col.replace("_", " ").title(),
            "sortable": True,
            "filter": True,
            "resizable": True,
        }
        if col == "Customer Name":
            col_def["pinned"] = "left"
            col_def["width"] = 180
            col_def["headerName"] = "Customer Name"
        elif col == "node_id":
            col_def["width"] = 140
        else:
            col_def["valueFormatter"] = {"function": "d3.format('.4f')(params.value)"}
        grid_cols.append(col_def)

    grid = dag.AgGrid(
        rowData=show_df.to_dict("records"),
        columnDefs=grid_cols,
        defaultColDef={"flex": 1, "minWidth": 100},
        dashGridOptions={
            "animateRows": True,
            "pagination": True,
            "paginationPageSize": 20,
            "domLayout": "autoHeight",
        },
        style={"height": None, **AG_GRID_STYLE},
        className="ag-theme-alpine-dark",
    )

    badge = f"{FAMILY_MAP.get(family, family)} — {len(df)} rows, {len(numeric_cols)} metrics"
    return (fig1, fig2, grid, badge, _family_desc_ui, *counts)


@callback(
    Output("vault-download", "data"),
    Input("btn-vault-export", "n_clicks"),
    State("vault-family-select", "value"),
    prevent_initial_call=True,
)
@GlobalExceptionHandler.wrap(fallback=None)
def export_vault_csv(n_clicks, family):
    if not n_clicks:
        return None
    pipeline = get_pipeline()
    results = pipeline.get_analytics_results()
    if results and family in results:
        # PII GUARD: mask before export
        safe_df = mask_for_export(results[family])
        return dcc.send_data_frame(safe_df.to_csv, f"analytics_{family}_masked.csv", index=False)
    return None
