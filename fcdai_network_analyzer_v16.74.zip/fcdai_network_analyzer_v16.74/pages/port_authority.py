"""
pages/port_authority.py
========================
PURPOSE
-------
Thin dispatch file that Dash's page auto-discovery CAN and WILL import.

WHY THIS FILE EXISTS
--------------------
Dash's _import_layouts_from_pages() skips:
  - Files starting with "_"  (skips __init__.py, _state.py, _helpers.py …)
  - Directories starting with "_"  (skips _port_authority/ entirely)

This file sits at pages/port_authority.py — no leading underscore — so
Dash finds it, sees "register_page" in its content, and imports it.

WHAT THIS FILE DOES
-------------------
1. Calls dash.register_page() to register the URL path /port-authority
2. Imports `pages._port_authority` package  →  this runs _port_authority/__init__.py which:
     a. Imports layout.py           (builds the page UI function)
     b. Imports cb_generate.py      (registers CB1–CB4c @callback decorators)
     c. Imports cb_upload.py        (registers CB5–CB9 @callback decorators)
     d. Imports cb_pipeline.py      (registers CB10–CB12 @callback decorators)
     e. Imports cb_grid.py          (registers CBN1–CBN3 @callback decorators)
     f. Registers the clientside_callback for pa-mount-ts hydration
3. Re-exports `layout` at this module level so Dash can call layout() on page load

DIRECTORY STRUCTURE (port_authority split)
------------------------------------------
pages/
  port_authority.py            ← THIS FILE (Dash discovers this)
  _port_authority/             ← Package (Dash skips; imported by this file)
    __init__.py                  imports cb_*, layout, clientside_callback
    _state.py                    shared mutable state + helpers
    _constants.py                styles, table defs, upload slots
    _helpers.py                  pure UI-builder functions
    layout.py                    layout() function
    cb_generate.py               generation callbacks (CB1–CB4c)
    cb_upload.py                 upload callbacks (CB5–CB9)
    cb_pipeline.py               pipeline callbacks (CB10–CB12)
    cb_grid.py                   grid/poll/hydration callbacks (CBN1–CBN3)
"""

import dash
from config import APP

# ── 1. Register this page with the Dash multi-page router ─────────────────
#
# path  : URL path — user navigates to http://host:8131/port-authority
# name  : Nav menu label
# title : Browser tab title (includes version from config.yaml)
# order : Position in auto-generated nav menus
#
dash.register_page(
    __name__,
    path="/port-authority",
    name="Port Authority",
    title=f"FCDAI v{APP.VERSION} | Port Authority",
    order=10,
)

# ── 2. Import the _port_authority package ─────────────────────────────────
#
# This single import triggers _port_authority/__init__.py which:
#   - imports layout.py
#   - imports all cb_*.py modules  →  registers all @callback decorators
#   - registers the clientside_callback for pa-mount-ts
#
# Python module caching (sys.modules) guarantees this runs exactly ONCE
# per server process, regardless of how many times this file is imported.
#
import pages._port_authority as _pa_pkg  # noqa: E402,F401

# ── 3. Expose layout at this module level ────────────────────────────────
#
# Dash looks for `layout` on the imported module.
# Since layout is a function, Dash calls layout() on each page request
# → fresh render each visit → current data from _pa_get_staged().
#
from pages._port_authority import layout  # noqa: E402,F401
