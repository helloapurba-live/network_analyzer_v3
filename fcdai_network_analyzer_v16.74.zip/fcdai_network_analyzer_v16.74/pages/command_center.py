"""
Page 4: Command Center (v12.22 — CEO / Business Presentation Format)
=====================================================================
Business Purpose:
  This is your AML investigation control room. Use it to:
    • See a count of P1 (freeze now), P2 (investigate today), P3 (monitor),
      P4 (normal) customers updated every time the pipeline runs
    • Work through the Investigation Queue — a prioritised list of customers
      that need compliance action, shown by name and customer ID
    • Generate a Narrative for any customer
      with one click — ready to submit to the regulator
    • Export the full investigation list for your compliance team

  RISK PRIORITY DEFINITIONS:
    P1 CRITICAL (score ≥80) — Freeze account immediately. Open investigation.
    P2 HIGH RISK (60–79)   — Enhanced due diligence required within 24 hrs.
    P3 MEDIUM (40–59)      — Schedule pro-active monitoring review.
    P4 LOW (0–39)          — Standard monitoring. No immediate action.
"""

import dash
from dash import html, dcc, callback, Input, Output, State, dash_table
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.graph_objects as go
import pandas as pd
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, APP
from engine import get_pipeline
from utils.logger import GlobalExceptionHandler

dash.register_page(
    __name__,
    path="/command-center",
    name="Command Center",
    title=f"FCDAI v{APP.VERSION} | Investigation Command Center",
)


# =============================================================================
# CONSTANTS & HELPERS
# =============================================================================
_TIER_COLORS = {"P1": "#FF1744", "P2": "#FF9800", "P3": "#FFD600", "P4": "#00E676"}
_TIER_LABELS = {
    "P1": ("CRITICAL", "80–100", "Freeze account & open investigation NOW."),
    "P2": ("HIGH RISK", "60–79", "Enhanced due diligence required within 24 hours."),
    "P3": ("MEDIUM", "40–59", "Active monitoring — schedule compliance review."),
    "P4": ("LOW", "0–39", "Standard monitoring. No immediate action required."),
}


def _risk_tier_legend():
    """Always-visible P1-P4 risk priority panel for CEO/business users."""
    items = []
    for code in ("P1", "P2", "P3", "P4"):
        label, score_range, desc = _TIER_LABELS[code]
        color = _TIER_COLORS[code]
        items.append(
            dmc.Group(
                [
                    html.Div(
                        style={
                            "width": "12px",
                            "height": "12px",
                            "borderRadius": "50%",
                            "backgroundColor": color,
                            "flexShrink": "0",
                            "border": "1px solid rgba(255,255,255,0.3)",
                        }
                    ),
                    dmc.Text(f"{code}  {label}", fw=600, c=color, size="xs"),
                    dmc.Text(
                        f"(Score {score_range}): {desc}",
                        size="xs",
                        c="dimmed",
                        style={"maxWidth": "300px"},
                    ),
                ],
                gap=4,
                wrap="nowrap",
            ),
        )
    return dmc.Paper(
        dmc.Stack(
            [
                dmc.Group(
                    [
                        DashIconify(icon="mdi:shield-alert", width=18, color="#94A3B8"),
                        dmc.Text(
                            "Risk Priority Reference — What the Colours Mean",
                            fw=600,
                            c="white",
                            size="sm",
                        ),
                    ],
                    gap="sm",
                ),
                dmc.SimpleGrid(cols={"base": 1, "md": 2}, spacing="xs", children=items),
                dmc.Text(
                    "💡 This page shows exactly which customers need compliance action and in what priority order. "
                    "The Investigation Queue lists every customer by name, their risk tier, and the specific "
                    "score drivers. Click a customer name in the Narrative Generator to produce an instant "
                    "Narrative ready for regulatory submission.",
                    size="xs",
                    c="dimmed",
                    mt="xs",
                    style={"fontStyle": "italic", "lineHeight": "1.5"},
                ),
            ],
            gap="sm",
        ),
        p="md",
        radius="md",
        mb="lg",
        style={"background": "rgba(17,24,39,0.8)", "border": "1px solid rgba(255,255,255,0.08)"},
    )


def _customer_label(node_id):
    """V12.21: Show customer name + last 4 of ID for readable labels."""
    if not node_id or not isinstance(node_id, str):
        return str(node_id or "")
    pipeline = get_pipeline()
    cust_df = pipeline.tables.get("customer")
    if cust_df is not None and len(cust_df) > 0 and "customer_id" in cust_df.columns:
        match = cust_df[cust_df["customer_id"] == node_id]
        if len(match) > 0:
            name = match.iloc[0].get("customer_name", "") or match.iloc[0].get("name", "")
            if name:
                return f"{name} (…{node_id[-4:]})"
    return f"…{node_id[-4:]}" if len(node_id) > 8 else node_id


# =============================================================================
# LAYOUT
# =============================================================================
layout = dmc.Box(
    [
        # v12.31: fires once on page mount to refresh data on navigation
        dcc.Interval(id="cc-init", interval=1000, max_intervals=1),
        # Header
        dmc.Group(
            [
                dmc.Stack(
                    [
                        dmc.Title("Investigation Command Center", order=2, c="white"),
                        dmc.Text(
                            "AML Investigation Priority Queue, Risk Matrix & Narrative Generator. "
                            "Filter by risk tier to see which customers need action today.",
                            c="dimmed",
                            size="sm",
                        ),
                    ],
                    gap=2,
                ),
                dmc.Group(
                    [
                        dmc.Badge(f"v{APP.VERSION}", color="cyan", variant="outline", size="sm"),
                        dmc.MultiSelect(
                            id="cc-tier-filter",
                            data=[
                                {"value": "P1", "label": "🔴 P1 — CRITICAL: Freeze Now"},
                                {"value": "P2", "label": "🟠 P2 — HIGH: Due Diligence"},
                                {"value": "P3", "label": "🟡 P3 — MEDIUM: Monitor"},
                                {"value": "P4", "label": "🟢 P4 — LOW: Normal"},
                            ],
                            value=["P1", "P2"],
                            w=320,
                            size="sm",
                            placeholder="Filter by risk tier",
                        ),
                        dmc.Button(
                            "Export Investigation Report",
                            leftSection=DashIconify(icon="mdi:file-export"),
                            id="btn-cc-export",
                            variant="gradient",
                            gradient={"from": "red", "to": "orange"},
                        ),
                    ],
                    gap="sm",
                ),
            ],
            justify="space-between",
            mb="lg",
        ),
        # ━━━ CEO EXECUTIVE BRIEF (v12.34 TASK3/4) ━━━
        dmc.Paper(
            [
                dmc.Group(
                    [
                        DashIconify(icon="mdi:briefcase-outline", width=22, color="#FF6B6B"),
                        dmc.Stack(
                            [
                                dmc.Text(
                                    "What Is This Page? — Executive Overview",
                                    fw=700,
                                    c="white",
                                    size="sm",
                                ),
                                dmc.Text(
                                    "The Investigation Command Center is your action management hub. "
                                    "After the AI pipeline runs, every high-risk customer is listed here, "
                                    "ranked by their danger score. P1 (red) customers require immediate account freeze. "
                                    "P2 (orange) require enhanced due diligence today. Use the Risk Matrix to see "
                                    "how customers cluster by risk level, and the Narrative Generator to produce "
                                    "Narratives for regulatory filing.",
                                    size="xs",
                                    c="dimmed",
                                    style={"lineHeight": "1.6"},
                                ),
                            ],
                            gap=4,
                        ),
                    ],
                    gap="md",
                    align="flex-start",
                ),
                dmc.Group(
                    [
                        dmc.Badge(
                            "P1 = Freeze account immediately",
                            color="red",
                            variant="light",
                            size="xs",
                        ),
                        dmc.Badge(
                            "P2 = Enhanced due diligence required today",
                            color="orange",
                            variant="light",
                            size="xs",
                        ),
                        dmc.Badge(
                            "Narrative Report for regulatory submission",
                            color="cyan",
                            variant="light",
                            size="xs",
                        ),
                    ],
                    gap="xs",
                    mt="sm",
                ),
            ],
            p="md",
            radius="md",
            mb="sm",
            style={
                "background": "linear-gradient(135deg, rgba(255,107,107,0.04) 0%, rgba(10,14,23,0.95) 100%)",
                "border": "1px solid rgba(255,107,107,0.12)",
            },
        ),
        # Risk Matrix Summary Cards
        dmc.SimpleGrid(
            cols={"base": 1, "sm": 2, "lg": 4},
            spacing="md",
            mb="lg",
            id="cc-tier-cards",
            children=[
                dmc.Paper(
                    [
                        dmc.Group(
                            [
                                dmc.Badge(tier, color=color, variant="filled", size="sm"),
                                dmc.Text("—", id=f"cc-{tier}-count", size="xl", fw=800, c="white"),
                            ],
                            justify="space-between",
                        ),
                        dmc.Text(desc, size="xs", c="dimmed", mt="xs"),
                        dmc.Text(action, size="xs", fw=600, c=_TIER_COLORS[tier], mt=2),
                    ],
                    p="lg",
                    radius="lg",
                    className="stat-card",
                )
                for tier, color, desc, action in [
                    (
                        "P1",
                        "red",
                        "Score 80–100: Highest probability of financial crime or money laundering.",
                        "⚠️ Action: Freeze account & open investigation immediately",
                    ),
                    (
                        "P2",
                        "orange",
                        "Score 60–79: Significant suspicious patterns detected.",
                        "🔍 Action: Enhanced due diligence within 24 hours",
                    ),
                    (
                        "P3",
                        "yellow",
                        "Score 40–59: Some unusual activity warrants attention.",
                        "📅 Action: Schedule compliance review this week",
                    ),
                    (
                        "P4",
                        "green",
                        "Score 0–39: No significant concerns found.",
                        "✔️ Action: Standard monitoring continues",
                    ),
                ]
            ],
        ),
        # Score Distribution & Investigation Queue
        dmc.SimpleGrid(
            cols={"base": 1, "lg": 2},
            spacing="md",
            mb="lg",
            children=[
                # Risk Score Histogram
                dmc.Paper(
                    [
                        dmc.Text(
                            "How Are Risk Scores Distributed? (Red = high risk customers)",
                            size="sm",
                            fw=600,
                            c="white",
                            mb="xs",
                        ),
                        dmc.Text(
                            "Each bar is how many customers scored in that range. "
                            "A spike on the right means more customers at high risk.",
                            size="xs",
                            c="dimmed",
                            mb="sm",
                        ),
                        dcc.Graph(
                            id="cc-score-histogram",
                            config={"displayModeBar": False},
                            style={"height": "280px"},
                        ),
                    ],
                    p="lg",
                    radius="lg",
                    className="glass-card",
                ),
                # Risk Matrix Heatmap
                dmc.Paper(
                    [
                        dmc.Text(
                            "Priority Tier Breakdown — Count & Avg Score by P1/P2/P3/P4",
                            size="sm",
                            fw=600,
                            c="white",
                            mb="xs",
                        ),
                        dmc.Text(
                            "Shows customer count per priority tier with average and maximum risk scores. "
                            "P1 (red) = freeze immediately. Use alongside histogram for full picture.",
                            size="xs",
                            c="dimmed",
                            mb="sm",
                        ),
                        dcc.Graph(
                            id="cc-risk-matrix",
                            config={"displayModeBar": False},
                            style={"height": "280px"},
                        ),
                    ],
                    p="lg",
                    radius="lg",
                    className="glass-card",
                ),
            ],
        ),
        # Investigation Queue Table
        dmc.Paper(
            [
                dmc.Group(
                    [
                        dmc.Stack(
                            [
                                dmc.Text(
                                    "Investigation Queue — Customers Requiring Compliance Action",
                                    size="sm",
                                    fw=600,
                                    c="white",
                                ),
                                dmc.Text(
                                    "Sorted by risk score (highest first). Customer name and ID shown. "
                                    "P1 (red rows) = freeze immediately. P2 (orange) = enhanced due diligence today.",
                                    size="xs",
                                    c="dimmed",
                                ),
                            ],
                            gap=2,
                        ),
                        dmc.Badge(
                            id="cc-queue-count",
                            color="red",
                            variant="light",
                            size="sm",
                            children="0 items",
                        ),
                    ],
                    justify="space-between",
                    mb="md",
                ),
                html.Div(id="cc-investigation-table"),
            ],
            p="lg",
            radius="lg",
            className="glass-card",
            mb="lg",
        ),
        # Narrative Generator Panel
        dmc.Paper(
            [
                dmc.Group(
                    [
                        dmc.Stack(
                            [
                                dmc.Text("Narrative Generator", size="sm", fw=600, c="white"),
                                dmc.Text(
                                    "Select a P1 or P2 customer to generate a ready-to-submit regulatory narrative. "
                                    "The system compiles all risk factors, transaction patterns, and network "
                                    "position into a regulatory-grade summary.",
                                    size="xs",
                                    c="dimmed",
                                ),
                            ],
                            gap=2,
                        ),
                        dmc.Select(
                            id="cc-narrative-node-select",
                            data=[],
                            placeholder="Select customer by name...",
                            clearable=True,
                            searchable=True,
                            w=300,
                            size="sm",
                        ),
                    ],
                    justify="space-between",
                    mb="md",
                ),
                dmc.Paper(
                    id="cc-narrative-content",
                    p="lg",
                    radius="md",
                    style={
                        "backgroundColor": THEME.DARK_BG,
                        "border": f"1px solid {THEME.DARK_BORDER}",
                        "fontFamily": "monospace",
                        "whiteSpace": "pre-wrap",
                        "minHeight": "200px",
                        "maxHeight": "500px",
                        "overflowY": "auto",
                    },
                    children=dmc.Center(
                        dmc.Text("Select a customer to generate narrative", c="dimmed", size="sm"),
                        style={"minHeight": "200px"},
                    ),
                ),
            ],
            p="lg",
            radius="lg",
            className="glass-card",
        ),
        # Download component
        dcc.Download(id="cc-download"),
        dcc.Loading(html.Div(id="cc-loading"), type="circle", color=THEME.PRIMARY),
    ]
)


# =============================================================================
# CALLBACKS
# =============================================================================
@callback(
    Output("cc-P1-count", "children"),
    Output("cc-P2-count", "children"),
    Output("cc-P3-count", "children"),
    Output("cc-P4-count", "children"),
    Output("cc-score-histogram", "figure"),
    Output("cc-risk-matrix", "figure"),
    Output("cc-investigation-table", "children"),
    Output("cc-queue-count", "children"),
    Output("cc-narrative-node-select", "data"),
    Input("cc-tier-filter", "value"),
    Input("pipeline-state", "data"),
    Input("global-refresh-ts", "data"),
    Input("cc-init", "n_intervals"),
)
@GlobalExceptionHandler.wrap(
    fallback=("—", "—", "—", "—", go.Figure(), go.Figure(), dmc.Text("No data", c="dimmed"), "0 items", [])
)
def update_command_center(tiers, _pipeline_state, _gr, _init=None):
    """Update command center display."""
    pipeline = get_pipeline()
    scored = pipeline.get_scored_df()

    empty_fig = go.Figure()
    empty_fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=20, r=20, t=20, b=20),
    )
    empty_fig.add_annotation(
        text="Run pipeline first", showarrow=False, font=dict(color="#64748B", size=14)
    )

    if scored is None or len(scored) == 0:
        return (
            "—", "—", "—", "—",
            empty_fig,
            empty_fig,
            dmc.Center(
                dmc.Text("Run pipeline to populate", c="dimmed"), style={"minHeight": "100px"}
            ),
            "0 items",
            [],
        )

    tiers = tiers or ["P1", "P2"]

    # Tier counts for summary cards — computed directly from scored_df
    _tier_counts = {t: int((scored["risk_tier"] == t).sum()) if "risk_tier" in scored.columns else 0
                    for t in ["P1", "P2", "P3", "P4"]}
    p1_cnt = f"{_tier_counts['P1']:,}"
    p2_cnt = f"{_tier_counts['P2']:,}"
    p3_cnt = f"{_tier_counts['P3']:,}"
    p4_cnt = f"{_tier_counts['P4']:,}"

    # Score histogram
    colors = {"P1": "#FF1744", "P2": "#FF9800", "P3": "#FFD600", "P4": "#00E676"}
    fig1 = go.Figure()
    for tier in ["P1", "P2", "P3", "P4"]:
        tier_data = scored[scored["risk_tier"] == tier]
        if len(tier_data) > 0:
            fig1.add_trace(
                go.Histogram(
                    x=tier_data["risk_score"].values,
                    name=tier,
                    marker_color=colors.get(tier, "#64748B"),
                    opacity=0.8,
                    nbinsx=30,
                )
            )
    fig1.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=40, r=20, t=20, b=40),
        barmode="stack",
        legend=dict(font=dict(color="#94A3B8", size=10)),
        xaxis=dict(title="Risk Score", gridcolor="rgba(255,255,255,0.05)", color="#94A3B8"),
        yaxis=dict(title="Count", gridcolor="rgba(255,255,255,0.05)", color="#94A3B8"),
    )
    # v12.31: add tier count annotations
    _tc_annots = [
        dict(
            text=f"{t}: {len(scored[scored['risk_tier']==t]):,}",
            x=0.98,
            y=0.97 - idx * 0.1,
            xref="paper",
            yref="paper",
            showarrow=False,
            font=dict(color=colors.get(t, "#64748B"), size=10),
            align="right",
            xanchor="right",
        )
        for idx, t in enumerate(["P1", "P2", "P3", "P4"])
        if len(scored[scored["risk_tier"] == t]) > 0
    ]
    if _tc_annots:
        fig1.update_layout(annotations=_tc_annots)

    # Risk matrix — Tier breakdown: count bars + avg-score labels
    # Deliberately different from histogram above (which shows raw score distribution)
    # This shows ACTIONABLE tier counts with average scores for each priority tier.
    _tier_names = ["P1", "P2", "P3", "P4"]
    _tier_bar_colors = {"P1": "#FF1744", "P2": "#FF9800", "P3": "#FFD600", "P4": "#00E676"}
    _t_counts = []
    _t_avgs = []
    _t_max = []
    for _t in _tier_names:
        _tdf = scored[scored["risk_tier"] == _t] if "risk_tier" in scored.columns else scored.iloc[0:0]
        _t_counts.append(len(_tdf))
        _t_avgs.append(round(float(_tdf["risk_score"].mean()), 1) if len(_tdf) > 0 else 0)
        _t_max.append(round(float(_tdf["risk_score"].max()), 1) if len(_tdf) > 0 else 0)
    fig2 = go.Figure(go.Bar(
        x=_tier_names,
        y=_t_counts,
        marker_color=[_tier_bar_colors[t] for t in _tier_names],
        text=[f"{c:,} customers<br>avg {a:.0f} | max {m:.0f}"
              for c, a, m in zip(_t_counts, _t_avgs, _t_max)],
        textposition="outside",
        textfont=dict(size=9, color="white"),
        opacity=0.85,
    ))
    fig2.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=40, r=20, t=20, b=40),
        xaxis=dict(title="Risk Tier", color="#94A3B8",
                   ticktext=["P1 CRITICAL", "P2 HIGH", "P3 MEDIUM", "P4 LOW"],
                   tickvals=["P1", "P2", "P3", "P4"]),
        yaxis=dict(title="Customer Count", gridcolor="rgba(255,255,255,0.05)", color="#94A3B8"),
    )

    # Investigation queue (filtered by selected tiers)
    filtered = scored[scored["risk_tier"].isin(tiers)].sort_values("risk_score", ascending=False)
    filtered_display = filtered.head(200).copy()

    # v12.22 BUG-M02 FIX: build name map once; avoid per-row get_pipeline()+df-filter calls
    _cust_cc = pipeline.tables.get("customer") if hasattr(pipeline, "tables") else None
    _nm_cc: dict = {}
    if _cust_cc is not None and len(_cust_cc) > 0 and "customer_id" in _cust_cc.columns:
        _nc_cc = next((c for c in ("customer_name", "name") if c in _cust_cc.columns), None)
        if _nc_cc:
            for _cid_cc, _cn_cc in zip(
                _cust_cc["customer_id"].astype(str), _cust_cc[_nc_cc].fillna("")
            ):
                if _cn_cc:
                    _f_cc = str(_cn_cc).split()[0]
                    _s_cc = _cid_cc[-4:] if len(_cid_cc) >= 4 else _cid_cc
                    _nm_cc[_cid_cc] = f"{_f_cc} (…{_s_cc})"

    def _fast_cc(nid):
        s = str(nid)
        return _nm_cc.get(s, f"…{s[-4:]}" if len(s) > 8 else s)

    # V12.21: Add customer name to investigation queue (TASK5)
    filtered_display.insert(0, "Customer Name", filtered_display["node_id"].apply(_fast_cc))

    # Columns to show — customer name first, then risk columns
    score_cols = [c for c in filtered_display.columns if c.startswith("score_")][:5]
    show_cols = ["Customer Name"] + [
        c
        for c in ["node_id", "risk_score", "risk_tier"] + score_cols
        if c in filtered_display.columns
    ]

    col_labels = {
        "Customer Name": "Customer Name",
        "node_id": "Customer ID",
        "risk_score": "Risk Score",
        "risk_tier": "Priority",
    }

    table = dash_table.DataTable(
        data=filtered_display[show_cols].to_dict("records") if len(show_cols) > 0 else [],
        columns=[
            {"name": col_labels.get(c, c.replace("_", " ").title()), "id": c} for c in show_cols
        ],
        page_size=15,
        sort_action="native",
        style_header={
            "backgroundColor": THEME.DARK_BG_ELEVATED,
            "color": THEME.PRIMARY,
            "fontWeight": "600",
            "fontSize": "11px",
            "textTransform": "uppercase",
            "border": f"1px solid {THEME.DARK_BORDER}",
        },
        style_cell={
            "backgroundColor": THEME.DARK_BG_CARD,
            "color": THEME.TEXT_PRIMARY,
            "border": f"1px solid {THEME.DARK_BORDER}",
            "fontSize": "12px",
        },
        style_data_conditional=[
            {"if": {"row_index": "odd"}, "backgroundColor": THEME.DARK_BG_ELEVATED},
            {
                "if": {"filter_query": "{risk_tier} = P1"},
                "backgroundColor": "rgba(255, 23, 68, 0.1)",
            },
            {
                "if": {"filter_query": "{risk_tier} = P2"},
                "backgroundColor": "rgba(255, 152, 0, 0.08)",
            },
        ],
    )

    queue_count = f"{len(filtered):,} items"

    # Narrative select options — show customer name + risk tier + score
    p1p2 = scored[scored["risk_tier"].isin(["P1", "P2"])].sort_values("risk_score", ascending=False)
    narrative_options = [
        {
            "value": row["node_id"],
            "label": f"{_fast_cc(row['node_id'])} — {row['risk_tier']} (Score: {row['risk_score']:.0f})",
        }
        for _, row in p1p2.head(100).iterrows()
    ]

    return p1_cnt, p2_cnt, p3_cnt, p4_cnt, fig1, fig2, table, queue_count, narrative_options


@callback(
    Output("cc-narrative-content", "children"),
    Input("cc-narrative-node-select", "value"),
)
@GlobalExceptionHandler.wrap(fallback=dmc.Text("Error generating narrative", c="red"))
def show_narrative(node_id):
    """Display narrative for selected customer."""
    if not node_id:
        return dmc.Center(
            dmc.Text("Select a customer to generate narrative", c="dimmed", size="sm"),
            style={"minHeight": "200px"},
        )

    pipeline = get_pipeline()
    narrative = pipeline.get_narrative(node_id)
    return dmc.Text(
        narrative,
        size="sm",
        c=THEME.TEXT_PRIMARY,
        style={"fontFamily": "monospace", "whiteSpace": "pre-wrap"},
    )


@callback(
    Output("cc-download", "data"),
    Input("btn-cc-export", "n_clicks"),
    prevent_initial_call=True,
)
@GlobalExceptionHandler.wrap(fallback=None)
def export_report(n_clicks):
    """Export investigation report to CSV."""
    if not n_clicks:
        return None
    pipeline = get_pipeline()
    scored = pipeline.get_scored_df()
    if scored is not None:
        return dcc.send_data_frame(scored.to_csv, "fcdai_investigation_report.csv", index=False)
    return None
