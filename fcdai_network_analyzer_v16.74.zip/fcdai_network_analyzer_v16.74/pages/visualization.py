"""
Page 5: Visualization (v12.22 — CEO / Business Presentation Format)
======================================================================
Business Purpose: This page is your analytics dashboard overview.
It answers in one look: Who are the riskiest customers? How is money
moving? What types of transactions dominate? Every chart is labelled
with plain-English business context for compliance officers and
executives who are not data scientists.

Risk Priority Quick Reference (always visible at top):
  P1 (Red, ≥80)  → CRITICAL — Freeze account & open investigation now
  P2 (Orange 60-79) → HIGH RISK — Enhanced due diligence required today
  P3 (Yellow 40-59) → MEDIUM — Schedule increased monitoring
  P4 (Green 0-39) → LOW — Normal operations, standard monitoring
"""

import dash
from dash import html, dcc, callback, Input, Output
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.graph_objects as go
import plotly.express as px
import numpy as np
import pandas as pd
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, APP
from engine import get_pipeline
from utils.logger import GlobalExceptionHandler

dash.register_page(
    __name__,
    path="/visualization",
    name="Visualization",
    title=f"FCDAI v{APP.VERSION} | Analytics Overview",
)


def _customer_label(node_id):
    """Show customer name + last 4 digits of ID."""
    if not node_id or not isinstance(node_id, str):
        return str(node_id or "")
    pipeline = get_pipeline()
    cust_df = pipeline.tables.get("customer")
    if cust_df is not None and len(cust_df) > 0 and "customer_id" in cust_df.columns:
        match = cust_df[cust_df["customer_id"] == node_id]
        if len(match) > 0:
            name = match.iloc[0].get("customer_name", "") or match.iloc[0].get("name", "")
            if name:
                return f"{name} (...{node_id[-4:]})"
    return f"...{node_id[-4:]}" if len(node_id) > 8 else node_id


# =============================================================================
# CONSTANTS
# =============================================================================
TIER_COLORS = {"P1": "#FF1744", "P2": "#FF9800", "P3": "#FFD600", "P4": "#00E676"}
CHART_COLORS = [
    "#00D4FF",
    "#9D4EDD",
    "#FF6B6B",
    "#00E676",
    "#FFD600",
    "#FF9800",
    "#2196F3",
    "#E040FB",
    "#26C6DA",
    "#AB47BC",
]
DARK_TEMPLATE = dict(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(0,0,0,0)",
    font=dict(color="#94A3B8", size=11),
    margin=dict(l=50, r=20, t=30, b=40),
    xaxis=dict(gridcolor="rgba(255,255,255,0.05)", zerolinecolor="rgba(255,255,255,0.08)"),
    yaxis=dict(gridcolor="rgba(255,255,255,0.05)", zerolinecolor="rgba(255,255,255,0.08)"),
    legend=dict(font=dict(color="#94A3B8", size=10)),
)


_TH = {
    "backgroundColor": "#111827",
    "color": "#94A3B8",
    "fontWeight": "600",
    "border": "1px solid #1E293B",
}
_TC = {
    "backgroundColor": "#0A0E17",
    "color": "#E2E8F0",
    "border": "1px solid #1E293B",
    "fontSize": "11px",
    "padding": "6px",
}
_SEC = dict(
    p="xl",
    radius="lg",
    className="glass-card",
    mb="lg",
    style={"border": "1px solid rgba(255,255,255,0.06)"},
)

# ─────────────────────────────────────────────────────────
# RISK TIER LEGEND (always visible — same across all pages)
# ─────────────────────────────────────────────────────────
_TIER_LABELS = {
    "P1": ("CRITICAL", "80–100", "Freeze & Investigate — Highest probability of financial crime."),
    "P2": ("HIGH RISK", "60–79", "Enhanced Due Diligence — Significant suspicious patterns."),
    "P3": ("MEDIUM", "40–59", "Active Monitoring — Some unusual activity warrants attention."),
    "P4": ("LOW", "0–39", "Normal Operations — Standard transaction monitoring."),
}


def _risk_tier_legend():
    """Always-visible P1-P4 risk priority panel for CEO/business users."""
    items = []
    for code in ("P1", "P2", "P3", "P4"):
        label, score_range, desc = _TIER_LABELS[code]
        color = TIER_COLORS[code]
        items.append(
            dmc.Group(
                [
                    html.Div(
                        style={
                            "width": "12px",
                            "height": "12px",
                            "borderRadius": "50%",
                            "backgroundColor": color,
                            "flexShrink": "0",
                            "border": "1px solid rgba(255,255,255,0.3)",
                        }
                    ),
                    dmc.Text(f"{code}  {label}", fw=600, c=color, size="xs"),
                    dmc.Text(
                        f"(Score {score_range}): {desc}",
                        size="xs",
                        c="dimmed",
                        style={"maxWidth": "320px"},
                    ),
                ],
                gap=4,
                wrap="nowrap",
            ),
        )
    return dmc.Paper(
        dmc.Stack(
            [
                dmc.Group(
                    [
                        DashIconify(icon="mdi:shield-alert", width=18, color="#94A3B8"),
                        dmc.Text(
                            "Risk Priority Classification — What the Colours Mean",
                            fw=600,
                            c="white",
                            size="sm",
                        ),
                        dmc.Badge("Always Visible", color="blue", variant="light", size="xs"),
                    ],
                    gap="sm",
                ),
                dmc.SimpleGrid(cols={"base": 1, "md": 2}, spacing="xs", children=items),
                dmc.Text(
                    "💡 How to use this page: Each chart answers one business question. "
                    "Hover over any bar or dot for the customer name and full details. "
                    "Red = act now, Orange = escalate today, Yellow = monitor, Green = normal.",
                    size="xs",
                    c="dimmed",
                    mt="xs",
                    style={"fontStyle": "italic", "lineHeight": "1.5"},
                ),
            ],
            gap="sm",
        ),
        p="md",
        radius="md",
        mb="lg",
        style={"background": "rgba(17,24,39,0.8)", "border": "1px solid rgba(255,255,255,0.08)"},
    )


def empty_fig(msg: str = "Run pipeline to see results") -> go.Figure:
    fig = go.Figure()
    fig.add_annotation(text=msg, showarrow=False, font=dict(color="#64748B", size=14))
    tmpl = {k: v for k, v in DARK_TEMPLATE.items()}
    tmpl["margin"] = dict(l=20, r=20, t=20, b=20)
    fig.update_layout(**tmpl)
    return fig


def _section_header(icon, color, title, purpose):
    """Business-facing section header for CEO/non-technical users."""
    return html.Div(
        [
            dmc.Stack(
                [
                    dmc.Group(
                        [
                            DashIconify(icon=icon, width=22, color=color),
                            dmc.Text(title, fw=700, c="white", size="md"),
                        ],
                        gap="sm",
                    ),
                    dmc.Text(
                        purpose,
                        size="xs",
                        c="dimmed",
                        style={"maxWidth": "860px", "lineHeight": "1.5"},
                    ),
                ],
                gap=2,
            ),
        ],
        style={"marginBottom": "10px"},
    )


# =============================================================================
# ARCHITECTURE REFERENCE DATA
# =============================================================================
ARCH_LAYERS = [
    (
        "Layer 0: Raw Data Sources",
        "#FF6B6B",
        "5 data sources: Transaction (Wire/RTGS/NEFT/IMPS/Cash), Customer, Account, KYC, Alert. "
        "No device/phone data. CSV/SQL ingestion → Raw DataFrames.",
    ),
    (
        "Layer 1: Data Ingestion & Validation",
        "#FF9800",
        "Load raw data → Schema validation (required columns, types, ranges) → "
        "Data cleaning (nulls, formats, dedup) → Data quality report.",
    ),
    (
        "Layer 2: Data Aggregation & Enrichment",
        "#FFD600",
        "Account→Customer mapping → Transaction aggregation (SUM, COUNT, LIST channels) → "
        "Node feature engineering → Similarity computation (address).",
    ),
    (
        "Layer 3: Graph Construction",
        "#00E676",
        "Build G_TXN (DiGraph, weighted) → G_TEMPORAL (timestamps) → "
        "Multi-layer fusion → Graph stats validation.",
    ),
    (
        "Layer 4: Risk Analytics Engine",
        "#00D4FF",
        "10 analytics families: Influence Analysis (importance, brokerage, authority) · "
        "Risk Groups (Louvain, K-Core) · Money Flow (shortest paths, cycles) · "
        "Hidden Links (relationship prediction) · Anomaly Detection (behavioural outliers) · "
        "Time-Patterns (burstiness, velocity) · Cross-Entity (multi-layer correlation) · "
        "Structuring · Benford's Law · Transaction Patterns.",
    ),
    (
        "Layer 5: Risk Scoring Engine",
        "#9D4EDD",
        "Score aggregation → Weighted composite risk (0-100) → "
        "Priority classification: P1≥70 RESTRICT, P2 50-69 EDD, P3 30-49 MONITOR, P4<30 CLEAR.",
    ),
    (
        "Layer 6: Visualization Engine",
        "#E040FB",
        "Network graph (colour by risk, size by influence) → Risk dashboard → "
        "Money trail (Sankey) → Community view → Temporal timeline.",
    ),
    (
        "Layer 7: Web Application (Dash)",
        "#2196F3",
        "Multi-page Dash app: Dashboard, Port Authority, Radar, Visualization, "
        "Vault, Command Center, 7 Analytics subpages, Pipeline Runs, Database Browser.",
    ),
]


def chart_card(title, chart_id, icon, color, link_href=None, link_text=None, purpose=None):
    """Create a chart card with optional cross-page link and business purpose text."""
    footer = []
    if purpose:
        footer.append(
            dmc.Text(
                purpose,
                size="xs",
                c="dimmed",
                style={"lineHeight": "1.4", "fontStyle": "italic", "marginTop": "4px"},
            )
        )
    if link_href and link_text:
        footer.append(
            dmc.Divider(my="xs", color="rgba(255,255,255,0.05)"),
        )
        footer.append(
            dcc.Link(
                dmc.Group(
                    [
                        dmc.Text(link_text, size="xs", c=color),
                        DashIconify(icon="mdi:arrow-right", width=14, color=color),
                    ],
                    gap=4,
                ),
                href=link_href,
                style={"textDecoration": "none"},
            ),
        )

    return dmc.Paper(
        [
            dmc.Group(
                [
                    dmc.Text(title, size="sm", fw=600, c="white"),
                    DashIconify(icon=icon, width=18, color=color),
                ],
                justify="space-between",
                mb="xs",
            ),
            dcc.Graph(id=chart_id, config={"displayModeBar": False}, style={"height": "320px"}),
            *footer,
        ],
        p="lg",
        radius="lg",
        className="glass-card",
    )


# =============================================================================
# LAYOUT
# =============================================================================
layout = dmc.Box(
    [
        # Header
        dmc.Group(
            [
                dmc.Stack(
                    [
                        dmc.Title("Analytics Overview", order=2, c="white"),
                        dmc.Text(
                            "10 charts answering the most important compliance questions. "
                            "Each chart is labelled in plain business language. "
                            "Red = act now. Orange = escalate. Yellow = monitor. Green = normal.",
                            c="dimmed",
                            size="sm",
                        ),
                    ],
                    gap=2,
                ),
                dmc.Group(
                    [
                        dmc.Badge(f"v{APP.VERSION}", color="cyan", variant="outline", size="sm"),
                        dmc.Badge("10 Charts", color="cyan", variant="filled", size="lg"),
                        dcc.Link(
                            dmc.Button("← Dashboard", size="xs", variant="subtle", color="gray"),
                            href="/",
                            style={"textDecoration": "none"},
                        ),
                    ],
                    gap="sm",
                ),
            ],
            justify="space-between",
            mb="lg",
        ),
        # ━━━ RISK PRIORITY LEGEND — always visible ━━━
        _risk_tier_legend(),
        # =================== ARCHITECTURE REFERENCE ===================
        dmc.Accordion(
            [
                dmc.AccordionItem(
                    [
                        dmc.AccordionControl(
                            dmc.Group(
                                [
                                    DashIconify(
                                        icon="mdi:layers-outline", width=20, color=THEME.PRIMARY
                                    ),
                                    dmc.Text(
                                        "Architecture Reference — Layer 0 to Layer 7",
                                        fw=600,
                                        c="white",
                                        size="sm",
                                    ),
                                    dmc.Badge("8 Layers", color="cyan", variant="light", size="xs"),
                                ],
                                gap="sm",
                            ),
                        ),
                        dmc.AccordionPanel(
                            dmc.SimpleGrid(
                                cols={"base": 1, "md": 2, "xl": 4},
                                spacing="sm",
                                children=[
                                    dmc.Paper(
                                        [
                                            dmc.Group(
                                                [
                                                    dmc.Box(
                                                        style={
                                                            "width": "4px",
                                                            "height": "36px",
                                                            "borderRadius": "2px",
                                                            "backgroundColor": color,
                                                        },
                                                    ),
                                                    dmc.Stack(
                                                        [
                                                            dmc.Text(
                                                                name, fw=600, size="xs", c="white"
                                                            ),
                                                            dmc.Text(
                                                                desc,
                                                                size="xs",
                                                                c="dimmed",
                                                                style={"lineHeight": "1.4"},
                                                            ),
                                                        ],
                                                        gap=2,
                                                    ),
                                                ],
                                                gap="sm",
                                                align="flex-start",
                                            ),
                                        ],
                                        p="sm",
                                        radius="md",
                                        style={
                                            "backgroundColor": "rgba(0,0,0,0.3)",
                                            "border": f"1px solid {color}20",
                                        },
                                    )
                                    for name, color, desc in ARCH_LAYERS
                                ],
                            ),
                        ),
                    ],
                    value="arch-ref",
                ),
            ],
            variant="separated",
            radius="lg",
            mb="lg",
            styles={
                "control": {
                    "backgroundColor": THEME.DARK_BG_CARD,
                    "border": f"1px solid {THEME.DARK_BORDER}",
                    "borderRadius": "12px",
                },
                "panel": {
                    "backgroundColor": THEME.DARK_BG_CARD,
                    "border": f"1px solid {THEME.DARK_BORDER}",
                },
                "item": {"border": "none"},
            },
        ),
        # Hidden interval for initial load
        dcc.Interval(id="viz-init-trigger", interval=1000, max_intervals=1),
        # =================== ROW 1: Risk Overview ===================
        dmc.SimpleGrid(
            cols={"base": 1, "lg": 2},
            spacing="md",
            mb="md",
            children=[
                chart_card(
                    "How Many Customers Are in Each Risk Group?",
                    "viz-risk-histogram",
                    "mdi:chart-histogram",
                    "#00D4FF",
                    "/command-center",
                    "Investigate in Command Center →",
                    purpose="Shows how risk scores are distributed across all customers. "
                    "A cluster near the right (high scores) indicates a high-risk customer base.",
                ),
                chart_card(
                    "Risk Tier Breakdown — How Many Customers Need Action Today?",
                    "viz-tier-donut",
                    "mdi:chart-donut",
                    "#9D4EDD",
                    purpose="P1 (red) and P2 (orange) customers need immediate compliance action. "
                    "A healthy portfolio has mostly green (P4) with a small red/orange segment.",
                ),
            ],
        ),
        # =================== ROW 2: Network ===================
        dmc.SimpleGrid(
            cols={"base": 1, "lg": 2},
            spacing="md",
            mb="md",
            children=[
                chart_card(
                    "How Connected Are Customers? (Transaction Links per Customer)",
                    "viz-degree-dist",
                    "mdi:scatter-plot",
                    "#FF6B6B",
                    "/analytics/centrality",
                    "Explore Influence Analysis →",
                    purpose="Customers with unusually many connections could be laundering hubs. "
                    "Most customers should cluster at low-connection values (left of chart).",
                ),
                chart_card(
                    "🚨 Top 20 Highest Risk Customers — Who Needs Attention Now?",
                    "viz-top-risk",
                    "mdi:sort-descending",
                    "#FF1744",
                    "/radar",
                    "View in Radar →",
                    purpose="The 20 customers scoring highest in our risk model. "
                    "Longer bars = higher combined risk from all monitoring factors. "
                    "Names and IDs shown for direct investigation.",
                ),
            ],
        ),
        # =================== ROW 3: Flow & Community ===================
        dmc.SimpleGrid(
            cols={"base": 1, "lg": 2},
            spacing="md",
            mb="md",
            children=[
                chart_card(
                    "Money Flow Pattern — Who Brings Money In vs. Sends It Out?",
                    "viz-money-flow",
                    "mdi:swap-horizontal",
                    "#00E676",
                    "/analytics/pathflow",
                    "Explore PathFlow →",
                    purpose="Each dot is a customer. Dots far above the diagonal line have more money going "
                    "out than coming in — a classic structuring or placement signal.",
                ),
                chart_card(
                    "Customer Groups — How Big Are the Connected Clusters?",
                    "viz-community",
                    "mdi:account-group",
                    "#FFD600",
                    "/analytics/community",
                    "Explore Community →",
                    purpose="Large groups (tall bars) may indicate organised networks. "
                    "Unusually large single clusters deserve investigation.",
                ),
            ],
        ),
        # =================== ROW 4: Radar & Transactions ===================
        dmc.SimpleGrid(
            cols={"base": 1, "lg": 2},
            spacing="md",
            mb="md",
            children=[
                chart_card(
                    "Detection Coverage — How Much of Each Risk Dimension Is Active?",
                    "viz-analytics-radar",
                    "mdi:radar",
                    "#E040FB",
                    "/vault",
                    "View in Vault →",
                    purpose="Each axis is one category of monitoring (network influence, timing, hidden links, etc.). "
                    "A full coverage polygon means all risk dimensions are being monitored.",
                ),
                chart_card(
                    "Transaction Type Mix — What Kinds of Transactions Are Being Made?",
                    "viz-txn-types",
                    "mdi:chart-pie",
                    "#2196F3",
                    "/port-authority",
                    "Manage in Port Authority →",
                    purpose="Unusual concentrations in cash or wire transfers can indicate structuring. "
                    "Healthy portfolios show a balanced mix of transaction types.",
                ),
            ],
        ),
        # =================== ROW 5: Alerts & KYC ===================
        dmc.SimpleGrid(
            cols={"base": 1, "lg": 2},
            spacing="md",
            children=[
                chart_card(
                    "Alert Volume by Type — What Compliance Alerts Are Firing?",
                    "viz-alert-dist",
                    "mdi:alert-circle-outline",
                    "#FF1744",
                    "/analytics/anomaly",
                    "Explore Anomaly →",
                    purpose="High alert counts in specific categories indicate systemic patterns. "
                    "Use this to prioritise which alert type to investigate first.",
                ),
                chart_card(
                    "KYC Status — Which Customers Have Incomplete Know-Your-Customer Records?",
                    "viz-kyc-heatmap",
                    "mdi:file-document-check",
                    "#FFD600",
                    purpose="Customers with poor KYC status and high risk scores are the highest priority. "
                    "Dark red cells require immediate KYC review.",
                ),
            ],
        ),
        # =================== EXPORT BAR ===================
        dmc.Paper(
            [
                dmc.Group(
                    [
                        DashIconify(icon="mdi:download-circle-outline", width=22, color="#00D4FF"),
                        dmc.Text("Export Analytics Data", fw=600, c="white", size="sm"),
                        dmc.Button(
                            "⬇ Export CSV",
                            id="viz-export-csv",
                            size="xs",
                            variant="light",
                            color="cyan",
                            leftSection=DashIconify(icon="mdi:download", width=14),
                        ),
                    ],
                    gap="md",
                    align="center",
                ),
            ],
            p="sm",
            radius="lg",
            className="glass-card",
            mt="md",
            style={
                "background": "rgba(0,212,255,0.04)",
                "border": "1px solid rgba(0,212,255,0.15)",
            },
        ),
        dcc.Download(id="viz-download"),
    ]
)


# =============================================================================
# CALLBACKS — ALL 10 CHARTS
# =============================================================================
@callback(
    Output("viz-risk-histogram", "figure"),
    Output("viz-tier-donut", "figure"),
    Output("viz-degree-dist", "figure"),
    Output("viz-top-risk", "figure"),
    Output("viz-money-flow", "figure"),
    Output("viz-community", "figure"),
    Output("viz-analytics-radar", "figure"),
    Output("viz-txn-types", "figure"),
    Output("viz-alert-dist", "figure"),
    Output("viz-kyc-heatmap", "figure"),
    Input("viz-init-trigger", "n_intervals"),
    Input("pipeline-state", "data"),
    Input("global-refresh-ts", "data"),
)
@GlobalExceptionHandler.wrap(
    fallback=(
        empty_fig(),
        empty_fig(),
        empty_fig(),
        empty_fig(),
        empty_fig(),
        empty_fig(),
        empty_fig(),
        empty_fig(),
        empty_fig(),
        empty_fig(),
    )
)
def update_all_charts(_, __, _gr):
    """Build all 10 visualization charts from pipeline results."""
    pipeline = get_pipeline()
    scored = pipeline.get_scored_df()
    G = pipeline.G
    analytics = pipeline.get_analytics_results()
    tables = pipeline.tables

    if scored is None or len(scored) == 0:
        e = empty_fig()
        return e, e, e, e, e, e, e, e, e, e

    # Check for reset
    if isinstance(__, dict) and __.get("reset"):
        e = empty_fig("Data was reset — generate data and run pipeline")
        return e, e, e, e, e, e, e, e, e, e

    # ── CHART 1: Risk Score Histogram ──
    fig1 = go.Figure()
    _total_scored = len(scored)
    for tier in ["P4", "P3", "P2", "P1"]:
        tier_data = scored[scored["risk_tier"] == tier]
        if len(tier_data) > 0:
            fig1.add_trace(
                go.Histogram(
                    x=tier_data["risk_score"].values,
                    name=tier,
                    marker_color=TIER_COLORS.get(tier, "#64748B"),
                    opacity=0.85,
                    nbinsx=40,
                )
            )
    # v12.45: Show tier count + percentage annotations
    _tier_annots = []
    for _idx, _t in enumerate(["P1", "P2", "P3", "P4"]):
        _tc = int((scored["risk_tier"] == _t).sum())
        if _tc > 0:
            _pct = _tc / _total_scored * 100 if _total_scored > 0 else 0
            _tier_annots.append(
                dict(
                    text=f"{_t}: {_tc:,} ({_pct:.1f}%)",
                    x=0.98,
                    y=0.97 - _idx * 0.08,
                    xref="paper",
                    yref="paper",
                    showarrow=False,
                    font=dict(color=TIER_COLORS.get(_t, "#64748B"), size=10),
                    align="right",
                    xanchor="right",
                )
            )
    fig1.update_layout(
        **DARK_TEMPLATE,
        barmode="stack",
        xaxis_title="Risk Score",
        yaxis_title="Count",
        annotations=_tier_annots,
    )

    # ── CHART 2: Tier Donut ──
    tier_counts = scored["risk_tier"].value_counts()
    fig2 = go.Figure(
        go.Pie(
            labels=tier_counts.index.tolist(),
            values=tier_counts.values.tolist(),
            hole=0.6,
            marker=dict(
                colors=[TIER_COLORS.get(t, "#64748B") for t in tier_counts.index],
                line=dict(color="rgba(10,14,23,0.8)", width=2),
            ),
            textfont=dict(color="white", size=12),
            textinfo="label+value+percent",
            hovertemplate="<b>%{label}</b><br>Count: %{value}<br>%{percent}<extra></extra>",
        )
    )
    fig2.update_layout(
        **DARK_TEMPLATE,
        annotations=[
            dict(
                text=f"{len(scored):,}<br>Total",
                x=0.5,
                y=0.5,
                font=dict(size=18, color="white"),
                showarrow=False,
            )
        ],
    )

    # ── CHART 3: Degree Distribution ──
    if G is not None and G.number_of_nodes() > 0:
        degrees = [d for _, d in G.degree()]
        degree_counts = pd.Series(degrees).value_counts().sort_index()
        fig3 = go.Figure(
            go.Scatter(
                x=degree_counts.index.tolist(),
                y=degree_counts.values.tolist(),
                mode="markers",
                marker=dict(
                    color="#00D4FF", size=6, opacity=0.7, line=dict(color="#00D4FF", width=1)
                ),
                hovertemplate="Degree: %{x}<br>Nodes: %{y}<extra></extra>",
            )
        )
        fig3.update_layout(
            **DARK_TEMPLATE,
            xaxis_title="Degree (log)",
            yaxis_title="Count (log)",
            xaxis_type="log",
            yaxis_type="log",
        )
    else:
        fig3 = empty_fig("No graph data")

    # ── CHART 4: Top 20 Risk Nodes ──
    top20 = scored.nlargest(20, "risk_score")
    # v12.22 BUG-M02 FIX: build name map once; avoid 20 separate get_pipeline()+df-filter calls
    _cust_df_v = tables.get("customer") if tables else None
    _nm_v: dict = {}
    if _cust_df_v is not None and len(_cust_df_v) > 0 and "customer_id" in _cust_df_v.columns:
        _nc_v = next((c for c in ("customer_name", "name") if c in _cust_df_v.columns), None)
        if _nc_v:
            for _cid_v, _cn_v in zip(
                _cust_df_v["customer_id"].astype(str), _cust_df_v[_nc_v].fillna("")
            ):
                if _cn_v:
                    _f_v = str(_cn_v).split()[0]
                    _s_v = _cid_v[-4:] if len(_cid_v) >= 4 else _cid_v
                    _nm_v[_cid_v] = f"{_f_v} (…{_s_v})"

    def _fast_lbl_v(nid):
        s = str(nid)
        return _nm_v.get(s, f"…{s[-4:]}" if len(s) > 8 else s)

    top20_labels = [_fast_lbl_v(nid) for nid in top20["node_id"].values[::-1]]
    # v15.10: compute percentile rank for each top-20 customer (absolute score + %)
    _all_scores = scored["risk_score"].values
    _n_total = max(len(_all_scores), 1)
    _top20_scores_rev = top20["risk_score"].values[::-1]
    _top20_pct = [int(((_all_scores <= s).sum() / _n_total) * 100) for s in _top20_scores_rev]
    fig4 = go.Figure(
        go.Bar(
            y=top20_labels,
            x=_top20_scores_rev,
            orientation="h",
            # v15.10: show absolute score + top-X% label
            text=[f"{s:.0f} (top {100 - p}%)" for s, p in zip(_top20_scores_rev, _top20_pct)],
            textposition="outside",
            textfont=dict(size=10, color="white"),
            marker=dict(
                color=_top20_scores_rev,
                colorscale=[[0, "#FFD600"], [0.5, "#FF9800"], [1, "#FF1744"]],
                line=dict(color="rgba(255,255,255,0.1)", width=1),
            ),
            customdata=_top20_pct,
            hovertemplate="<b>%{y}</b><br>Score: %{x:.1f}<br>Percentile: top %{customdata}%<extra></extra>",
        )
    )
    fig4.update_layout(
        **{k: v for k, v in DARK_TEMPLATE.items() if k != "margin"},
        xaxis_title="Risk Score",
        margin=dict(l=140, r=60, t=20, b=40),
    )

    # ── CHART 5: Money Flow ──
    if G is not None and G.number_of_nodes() > 0:
        flow_data = []
        for node in G.nodes():
            attrs = G.nodes[node]
            flow_data.append(
                {
                    "node": node,
                    "label": _nm_v.get(str(node), _fast_lbl_v(node)),
                    "in_flow": attrs.get("in_flow", 0),
                    "out_flow": attrs.get("out_flow", 0),
                    "tier": attrs.get("risk_tier", "P4"),
                }
            )
        flow_df = pd.DataFrame(flow_data)
        flow_df["total_flow"] = flow_df["in_flow"] + flow_df["out_flow"]
        flow_df = flow_df.nlargest(500, "total_flow")

        fig5 = go.Figure()
        for tier, color in TIER_COLORS.items():
            sub = flow_df[flow_df["tier"] == tier]
            if len(sub) > 0:
                fig5.add_trace(
                    go.Scatter(
                        x=sub["in_flow"].values,
                        y=sub["out_flow"].values,
                        mode="markers",
                        name=tier,
                        marker=dict(color=color, size=6, opacity=0.6),
                        hovertemplate="<b>%{text}</b><br>In: $%{x:,.0f}<br>Out: $%{y:,.0f}<extra></extra>",
                        text=sub["label"].values,
                    )
                )
        max_val = (
            max(flow_df["in_flow"].max(), flow_df["out_flow"].max()) if len(flow_df) > 0 else 1
        )
        fig5.add_trace(
            go.Scatter(
                x=[0, max_val],
                y=[0, max_val],
                mode="lines",
                line=dict(color="rgba(255,255,255,0.15)", dash="dash"),
                showlegend=False,
                hoverinfo="skip",
            )
        )
        fig5.update_layout(**DARK_TEMPLATE, xaxis_title="In-Flow ($)", yaxis_title="Out-Flow ($)")
    else:
        fig5 = empty_fig("No flow data")

    # ── CHART 6: Community Sizes ──
    community_df = analytics.get("community")
    if community_df is not None and "community_louvain" in community_df.columns:
        comm_sizes = community_df["community_louvain"].value_counts().sort_values(ascending=False)
        _total_comm_members = int(comm_sizes.sum())
        # v12.45: Show count + percentage for each community
        _comm_text = [
            f"{v:,} ({v/_total_comm_members*100:.1f}%)" if _total_comm_members > 0 else f"{v:,}"
            for v in comm_sizes.values
        ]
        fig6 = go.Figure(
            go.Bar(
                x=[f"C{i}" for i in range(len(comm_sizes))],
                y=comm_sizes.values,
                text=_comm_text,
                textposition="outside",
                textfont=dict(size=9, color="white"),
                marker=dict(
                    color=comm_sizes.values,
                    colorscale=[[0, "#1A2332"], [0.5, "#9D4EDD"], [1, "#00D4FF"]],
                ),
                hovertemplate="Community %{x}<br>%{y:,} members (%{customdata:.1f}%)<extra></extra>",
                customdata=[
                    v / _total_comm_members * 100 if _total_comm_members > 0 else 0
                    for v in comm_sizes.values
                ],
            )
        )
        fig6.update_layout(**DARK_TEMPLATE, xaxis_title="Community", yaxis_title="Members")
    else:
        fig6 = empty_fig("No community data")

    # ── CHART 7: Analytics Radar ──
    FAMILY_LABELS = {
        "centrality": "Relationship Influence",
        "community": "Risk Group Identification",
        "pathflow": "Money Flow Tracing",
        "link_prediction": "Hidden Relationship Discovery",
        "anomaly": "Behavioural Anomaly Detection",
        "temporal": "Time-Pattern Risk Analysis",
        "multi_layer": "Cross-Entity Risk Assessment",
    }
    families = list(analytics.keys()) if analytics else []
    if families:
        values, labels, node_counts, score_means = [], [], [], []
        for fam in families:
            df = analytics[fam]
            num_cols = [
                c for c in df.columns if c != "node_id" and pd.api.types.is_numeric_dtype(df[c])
            ]
            node_counts.append(len(df))
            if num_cols:
                mean_val = float(df[num_cols[0]].mean())
                max_val = float(df[num_cols[0]].max())
                norm = (mean_val / max_val) if max_val > 0 else 0
                values.append(round(norm, 3))
                score_means.append(round(mean_val, 2))
            else:
                values.append(0)
                score_means.append(0.0)
            labels.append(FAMILY_LABELS.get(fam, fam.replace("_", " ").title()))

        values_closed = values + [values[0]]
        labels_closed = labels + [labels[0]]
        # v15.10: customdata for absolute count + mean score per family
        customdata_closed = [
            [nc, f"{v*100:.0f}", sm] for nc, v, sm in zip(node_counts, values, score_means)
        ] + [[node_counts[0], f"{values[0]*100:.0f}", score_means[0]]]

        fig7 = go.Figure(
            go.Scatterpolar(
                r=values_closed,
                theta=labels_closed,
                fill="toself",
                fillcolor="rgba(0, 212, 255, 0.15)",
                line=dict(color="#00D4FF", width=2),
                marker=dict(size=8, color="#00D4FF"),
                customdata=customdata_closed,
                # v15.10: show absolute node count + coverage % in hover
                hovertemplate=(
                    "<b>%{theta}</b><br>"
                    "Coverage: %{customdata[1]}%<br>"
                    "Nodes analysed: %{customdata[0]:,}<br>"
                    "Avg score: %{customdata[2]}<extra></extra>"
                ),
                # v15.10: show % label on each radial point
                mode="lines+markers+text",
                text=[f"{v*100:.0f}%" for v in values_closed],
                textposition="top center",
                textfont=dict(size=9, color="#94A3B8"),
            )
        )
        fig7.update_layout(
            **{k: v for k, v in DARK_TEMPLATE.items() if k not in ["xaxis", "yaxis"]},
            polar=dict(
                bgcolor="rgba(0,0,0,0)",
                radialaxis=dict(
                    visible=True,
                    gridcolor="rgba(255,255,255,0.08)",
                    color="#64748B",
                    tickformat=".0%",
                ),
                angularaxis=dict(gridcolor="rgba(255,255,255,0.08)", color="#94A3B8"),
            ),
        )
    else:
        fig7 = empty_fig("No analytics data")

    # ── CHART 8: Transaction Types ──
    txn_df = tables.get("transaction")
    if txn_df is not None and "transaction_type" in txn_df.columns:
        type_counts = txn_df["transaction_type"].value_counts()
        fig8 = go.Figure(
            go.Pie(
                labels=type_counts.index.tolist(),
                values=type_counts.values.tolist(),
                hole=0.45,
                marker=dict(
                    colors=CHART_COLORS[: len(type_counts)],
                    line=dict(color="rgba(10,14,23,0.8)", width=1.5),
                ),
                textfont=dict(color="white", size=11),
                textinfo="label+value+percent",
                hovertemplate="<b>%{label}</b><br>Count: %{value:,}<br>%{percent}<extra></extra>",
            )
        )
        fig8.update_layout(**DARK_TEMPLATE)
    else:
        fig8 = empty_fig("No transaction data")

    # ── CHART 9: Alert Distribution ──
    alert_df = tables.get("alert")
    if alert_df is not None and "alert_type" in alert_df.columns:
        alert_counts = alert_df["alert_type"].value_counts()
        _total_alerts = int(alert_counts.sum())
        # v12.45: Show count + percentage for each alert type
        _alert_text = [
            f"{v:,} ({v/_total_alerts*100:.1f}%)" if _total_alerts > 0 else f"{v:,}"
            for v in alert_counts.values
        ]
        fig9 = go.Figure(
            go.Bar(
                x=alert_counts.index.tolist(),
                y=alert_counts.values.tolist(),
                text=_alert_text,
                textposition="outside",
                textfont=dict(size=9, color="white"),
                marker=dict(
                    color=alert_counts.values.tolist(),
                    colorscale=[[0, "#FF9800"], [1, "#FF1744"]],
                ),
                hovertemplate="<b>%{x}</b><br>Count: %{y:,} (%{customdata:.1f}%)<extra></extra>",
                customdata=[
                    v / _total_alerts * 100 if _total_alerts > 0 else 0 for v in alert_counts.values
                ],
            )
        )
        fig9.update_layout(**DARK_TEMPLATE, xaxis_title="Alert Type", yaxis_title="Count")
    else:
        fig9 = empty_fig("No alert data")

    # ── CHART 10: KYC Risk Heatmap ──
    kyc_df = tables.get("kyc")
    if kyc_df is not None and "risk_rating" in kyc_df.columns:
        if "kyc_status" in kyc_df.columns:
            # Cross-tabulate risk_rating vs kyc_status
            ct = pd.crosstab(kyc_df["risk_rating"], kyc_df["kyc_status"])
            _total_kyc = int(ct.values.sum())
            # v12.45: Show count + percentage in each cell
            _kyc_pct = (ct.values / _total_kyc * 100) if _total_kyc > 0 else ct.values * 0
            _kyc_text = [
                [
                    f"{ct.values[r][c]:,}<br>({_kyc_pct[r][c]:.1f}%)"
                    for c in range(ct.values.shape[1])
                ]
                for r in range(ct.values.shape[0])
            ]
            fig10 = go.Figure(
                go.Heatmap(
                    z=ct.values,
                    x=ct.columns.tolist(),
                    y=ct.index.tolist(),
                    colorscale=[[0, "#0A0E17"], [0.5, "#9D4EDD"], [1, "#FF1744"]],
                    text=_kyc_text,
                    texttemplate="%{text}",
                    textfont={"size": 9},
                    hovertemplate="Status: %{x}<br>Rating: %{y}<br>Count: %{z:,}<extra></extra>",
                )
            )
            fig10.update_layout(
                **DARK_TEMPLATE, xaxis_title="KYC Status", yaxis_title="Risk Rating"
            )
        else:
            rating_counts = kyc_df["risk_rating"].value_counts().sort_index()
            _total_ratings = int(rating_counts.sum())
            _rating_text = [
                f"{v:,} ({v/_total_ratings*100:.1f}%)" if _total_ratings > 0 else f"{v:,}"
                for v in rating_counts.values
            ]
            fig10 = go.Figure(
                go.Bar(
                    x=rating_counts.index.tolist(),
                    y=rating_counts.values.tolist(),
                    text=_rating_text,
                    textposition="outside",
                    textfont=dict(size=9, color="white"),
                    marker=dict(color=CHART_COLORS[: len(rating_counts)]),
                    hovertemplate="<b>%{x}</b><br>Count: %{y:,}<extra></extra>",
                )
            )
            fig10.update_layout(**DARK_TEMPLATE, xaxis_title="Risk Rating", yaxis_title="Count")
    else:
        fig10 = empty_fig("No KYC data")

    return fig1, fig2, fig3, fig4, fig5, fig6, fig7, fig8, fig9, fig10


# ── EXPORT CALLBACK ───────────────────────────────────────────────────────
@callback(
    Output("viz-download", "data"),
    Input("viz-export-csv", "n_clicks"),
    prevent_initial_call=True,
)
def export_viz_csv(_):
    """Export full risk-score data as CSV for offline analysis."""
    pipeline = get_pipeline()
    scored = pipeline.get_scored_df()
    if scored is not None:
        return dcc.send_data_frame(scored.to_csv, "visualization_risk_data.csv", index=False)
    return no_update
