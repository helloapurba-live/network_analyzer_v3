"""
Page: Lobby Analysis (v12.22 — CEO / Business Presentation Format)
===================================================================
BUSINESS PURPOSE:
  This page identifies 'lobbies' — tightly connected groups of customers
  who transact with each other in circular or hub-and-spoke patterns.
  Lobbies are the organizational structure behind money laundering:
  one customer acts as the 'hub' (conduit), while others act as layering
  accounts that pass money in circles.

  Every element is designed for non-technical users: compliance officers,
  senior investigations management, and board-level executives.

V12.19 additions (same as Network Intelligence):
  - Customer NAMES shown instead of IDs (first name + last 4 of ID)
  - Business-language section headers explaining PURPOSE of each analysis
  - P1/P2/P3/P4 priority legend always visible with business actions
  - Ring graph: color-coded, CEO-readable, full legend
  - Table column headers changed to business language

V12.20 ROOT-CAUSE FIX (same as Network Intelligence):
  - _safe_float() / _safe_int() prevent TypeError on None node attributes
  - dict(G.nodes[m]) replaces G.nodes.get(m, {}) for reliable attr access
  - try/except around card rendering prevents silent blank outputs
  - Version badge updated to v12.20

V12.21 FIXES:
  TASK2 — Lobby Risk Comparison blank chart: bar chart text/hovertemplate
  used r.get('avg_risk', 0):.1f directly — when avg_risk key exists with
  value None, .get() returns None (not 0), and :.1f on None = TypeError.
  Fix: all numeric fields now wrapped with _safe_float().
  Wrapped ring graph build in try/except to prevent silent blank.
  TASK3/4 — Added CEO-level business explanation panel to ring chart section.
  TASK5 — Customer name consistently shown in all ring cards and tables.
"""

import dash
from dash import html, dcc, callback, Input, Output, State, no_update, dash_table, ctx
import dash_mantine_components as dmc
import dash_cytoscape as cyto           # v16.25: lobby network visualization
from dash_iconify import DashIconify
import plotly.graph_objects as go
import pandas as pd
import json
import math
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, APP
from engine import get_pipeline

# v16.36: Business-language narrative engine
try:
    from utils.business_rules import ring_business_summary, lobby_portfolio_summary
    _HAS_BIZ_RULES = True
except Exception:
    _HAS_BIZ_RULES = False
    def ring_business_summary(size, avg_risk, total_flow, tier, ring_id):
        return {
            "tier_word": tier, "headline": f"Ring #{ring_id} — {size} accounts",
            "what_happened": "", "business_risk": "", "next_step": "",
        }
    def lobby_portfolio_summary(total_lobbies, total_flow, p1_count, p2_count, max_ring_size, total_customers):
        return {"urgency": "", "colour": "gray", "banner": ""}

dash.register_page(
    __name__,
    path="/lobby-analysis",
    name="Lobby Analysis",
    title=f"FCDAI v{APP.VERSION} | Lobby Analysis",
)


def _safe_float(val, default=0.0) -> float:
    """V12.20 FIX: Safely convert None/NaN node attrs to float."""
    if val is None:
        return default
    try:
        f = float(val)
        return default if (f != f) else f  # NaN check: NaN != NaN
    except (TypeError, ValueError):
        return default


def _safe_int(val, default=0) -> int:
    """V12.20 FIX: Safely convert None/NaN node attrs to int."""
    return int(_safe_float(val, default))


# ═══════════════════════════════════════════════════════════════════════════════
# CONSTANTS
# ═══════════════════════════════════════════════════════════════════════════════

TIER_COLORS = {"P1": "#FF1744", "P2": "#FF9800", "P3": "#FFD600", "P4": "#00E676"}

# v14.7 FIX-GAP2: TIER_LABELS use percentile descriptions (not hardcoded score ranges).
# Tiers are assigned by l6_scoring.py percentile mode: top 1%=P1, 1-5%=P2, 5-15%=P3.
# Score ranges are NOT thresholds — they are approximate calibrated score bands.
TIER_LABELS = {
    "P1": (
        "CRITICAL",
        "Top 1%",
        "Immediate Investigation — Highest probability of financial crime. Restrict account activity pending full review.",
    ),
    "P2": (
        "HIGH RISK",
        "Top 1–5%",
        "Enhanced Due Diligence — Significant suspicious patterns detected. Requires immediate senior analyst review.",
    ),
    "P3": (
        "MEDIUM",
        "Top 5–15%",
        "Active Monitoring — Some unusual activity warrants ongoing attention. Escalate if patterns persist.",
    ),
    "P4": (
        "LOW",
        "Standard",
        "Normal Operations — No significant concerns. Standard transaction monitoring continues.",
    ),
}

DARK_TEMPLATE = dict(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(0,0,0,0)",
    font=dict(color="#94A3B8", size=11),
    margin=dict(l=40, r=20, t=30, b=40),
    xaxis=dict(gridcolor="rgba(255,255,255,0.05)"),
    yaxis=dict(gridcolor="rgba(255,255,255,0.05)"),
)
_TH = {
    "backgroundColor": "#111827",
    "color": "#94A3B8",
    "fontWeight": "600",
    "border": "1px solid #1E293B",
}
_TC = {
    "backgroundColor": "#0A0E17",
    "color": "#E2E8F0",
    "border": "1px solid #1E293B",
    "fontSize": "11px",
    "padding": "6px",
}
_SEC = dict(
    p="xl",
    radius="lg",
    className="glass-card",
    mb="lg",
    style={"border": "1px solid rgba(255,255,255,0.06)"},
)

# Sample customer names (consistent with NI page)
_SAMPLE_NAMES = {
    "CUST-0847": "David Chen",
    "CUST-1204": "Maria Santos",
    "CUST-0553": "James Wilson",
    "CUST-0912": "Elena Kowalski",
    "CUST-1531": "Robert Nguyen",
    "CUST-0776": "Sarah Ahmed",
    "CUST-0234": "Michael Park",
    "CUST-0891": "Linda Torres",
    "CUST-1345": "Thomas Brown",
    "CUST-0667": "Priya Sharma",
    "CUST-1488": "Carlos Mendez",
    "CUST-1789": "Anna Volkov",
    "CUST-0445": "Kevin O'Brien",
    "CUST-1267": "Yuki Tanaka",
    "CUST-0923": "Fatima Hassan",
    "CUST-1055": "Daniel Berg",
    "CUST-0398": "Sophie Laurent",
    "CUST-1102": "Hassan Ali",
    "CUST-0612": "Jennifer Kim",
}


# ═══════════════════════════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════════════════════════


def empty_fig(msg="Run pipeline first"):
    fig = go.Figure()
    fig.add_annotation(text=msg, showarrow=False, font=dict(color="#64748B", size=14))
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=20, r=20, t=20, b=20),
    )
    return fig


def _hex_to_rgb(hex_color):
    h = hex_color.lstrip("#")
    return f"{int(h[0:2], 16)},{int(h[2:4], 16)},{int(h[4:6], 16)}"


def _build_ring_explainer_fig():
    """
    v12.43: Build a Plotly figure illustrating how a money-laundering ring works.
    Shows a circular network with labelled roles (Hub, Conduit, Receiver) and
    annotated money-flow arrows — AML business-domain visualisation.
    """
    import math

    fig = go.Figure()

    # Ring nodes positioned in a circle
    roles = [
        ("Hub\n(Key Person)", "#FF1744", 18),
        ("Conduit A", "#FF9800", 12),
        ("Conduit B", "#FF9800", 12),
        ("Conduit C", "#FFD600", 10),
        ("Receiver", "#00E676", 10),
    ]
    n = len(roles)
    cx, cy = [], []
    for i in range(n):
        angle = 2 * math.pi * i / n - math.pi / 2
        cx.append(math.cos(angle))
        cy.append(math.sin(angle))

    # Draw edges (arrows) — circular flow
    for i in range(n):
        j = (i + 1) % n
        fig.add_annotation(
            x=cx[j],
            y=cy[j],
            ax=cx[i],
            ay=cy[i],
            xref="x",
            yref="y",
            axref="x",
            ayref="y",
            showarrow=True,
            arrowhead=3,
            arrowsize=1.5,
            arrowwidth=2,
            arrowcolor="rgba(255,107,107,0.5)",
        )
        # Amount label on edge midpoint
        mx = (cx[i] + cx[j]) / 2
        my = (cy[i] + cy[j]) / 2
        amounts = ["$500K", "$480K", "$460K", "$440K", "$420K"]
        fig.add_annotation(
            x=mx,
            y=my,
            text=amounts[i],
            showarrow=False,
            font=dict(size=9, color="#94A3B8"),
            bgcolor="rgba(10,14,23,0.8)",
        )

    # Draw nodes
    fig.add_trace(
        go.Scatter(
            x=cx,
            y=cy,
            mode="markers+text",
            marker=dict(
                size=[r[2] * 2 for r in roles],
                color=[r[1] for r in roles],
                line=dict(width=2, color="rgba(255,255,255,0.3)"),
            ),
            text=[r[0] for r in roles],
            textposition="top center",
            textfont=dict(size=10, color="white"),
            hoverinfo="skip",
        )
    )

    # Center annotation
    fig.add_annotation(
        x=0,
        y=0,
        text="💰 Money flows\nin a circle",
        showarrow=False,
        font=dict(size=10, color="#64748B"),
        align="center",
    )

    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=5, r=5, t=5, b=5),
        xaxis=dict(visible=False, range=[-1.6, 1.6]),
        yaxis=dict(visible=False, range=[-1.6, 1.6], scaleanchor="x"),
        showlegend=False,
        height=180,  # v16.11 T3: compact
    )
    return fig


def _sn(cust_id):
    """Sample display name: 'FirstName (…last4)'."""
    name = _SAMPLE_NAMES.get(cust_id, cust_id)
    first = name.split()[0] if " " in name else name
    short = cust_id[-4:] if len(cust_id) >= 4 else cust_id
    return f"{first} (…{short})"


def _build_name_map(pipeline):
    """Build {node_id → display_name} dict once for efficient lookups."""
    nm = {}
    cust_df = pipeline.tables.get("customer") if hasattr(pipeline, "tables") else None
    if cust_df is not None and len(cust_df) > 0 and "customer_id" in cust_df.columns:
        # v12.22 PERF-01 FIX: vectorized zip instead of iterrows() — 10-100x faster at scale
        _nc = next((c for c in ("customer_name", "name") if c in cust_df.columns), None)
        if _nc:
            for cid, name in zip(cust_df["customer_id"].astype(str), cust_df[_nc].fillna("")):
                if name:
                    first = str(name).split()[0]
                    short = cid[-4:] if len(cid) >= 4 else cid
                    nm[cid] = f"{first} (…{short})"
    G = pipeline.G
    if G:
        for nid in G.nodes():
            if nid not in nm:
                attrs = G.nodes[nid]
                name = attrs.get("customer_name", "") or attrs.get("name", "")
                if name:
                    first = str(name).split()[0]
                    short = nid[-4:] if len(nid) >= 4 else nid
                    nm[nid] = f"{first} (…{short})"
    return nm


def _dn(name_map, node_id):
    """Quick display-name lookup with fallback."""
    if node_id in name_map:
        return name_map[node_id]
    s = str(node_id)
    return f"Cust …{s[-4:]}" if len(s) > 8 else s


def _risk_tier_legend():
    """Always-visible risk priority legend — same as NI page for consistency."""
    items = []
    for code in ("P1", "P2", "P3", "P4"):
        label, score_range, desc = TIER_LABELS[code]
        color = TIER_COLORS[code]
        items.append(
            dmc.Group(
                [
                    html.Div(
                        style={
                            "width": "12px",
                            "height": "12px",
                            "borderRadius": "50%",
                            "backgroundColor": color,
                            "flexShrink": "0",
                            "border": "1px solid rgba(255,255,255,0.3)",
                        }
                    ),
                    dmc.Text(f"{code} {label}", fw=600, c=color, size="xs"),
                    dmc.Text(
                        f"(Score {score_range}): {desc}",
                        size="xs",
                        c="dimmed",
                        style={"maxWidth": "240px"},
                    ),
                ],
                gap=4,
                wrap="nowrap",
            ),
        )
    return dmc.Paper(
        dmc.Stack(
            [
                dmc.Group(
                    [
                        DashIconify(icon="mdi:shield-alert", width=18, color="#94A3B8"),
                        dmc.Text(
                            "Risk Priority Classification — What the Colours Mean",
                            fw=600,
                            c="white",
                            size="sm",
                        ),
                    ],
                    gap="sm",
                ),
                dmc.SimpleGrid(cols={"base": 1}, spacing="xs", children=items),
            ],
            gap="sm",
        ),
        p="md",
        radius="md",
        style={"background": "rgba(17,24,39,0.8)", "border": "1px solid rgba(255,255,255,0.08)", "flex": "1"},
    )


def _section_header(icon, icon_color, title, purpose, extra=None):
    """Section header with icon, title, and business-purpose explanation."""
    children = [
        dmc.Stack(
            [
                dmc.Group(
                    [
                        DashIconify(icon=icon, width=24, color=icon_color),
                        dmc.Text(title, fw=700, c="white", size="lg"),
                    ]
                    + (extra or []),
                    gap="sm",
                ),
                dmc.Text(
                    purpose, size="xs", c="dimmed", style={"maxWidth": "900px", "lineHeight": "1.5"}
                ),
            ],
            gap=4,
        ),
    ]
    return html.Div(children, style={"marginBottom": "12px"})


# ── v14.7 AML FIX-GAP3: Ring tier helper ─────────────────────────────────────
def _ring_max_tier(ring: dict, G) -> str:
    """Return worst (highest severity) member tier for a ring.

    Percentile-consistent: reads risk_tier from graph nodes (assigned by the
    l6_scoring.py percentile algorithm — top 1%=P1, 1-5%=P2, 5-15%=P3).
    Falls back to avg_risk score thresholds ONLY when graph is unavailable
    (e.g. nodes-only load without edges, legacy save, pre-graph pipeline stage).

    Bank AML rationale: a ring with even ONE P1 member is a P1 ring.
    The worst-member tier drives investigation priority, not the average score.
    A ring averaging P4 but containing a P1 node MUST surface as P1.
    """
    _SEVER = {"P1": 4, "P2": 3, "P3": 2, "P4": 1}
    _raw = ring.get("nodes", ring.get("members", []))
    _mems = [m["node_id"] if isinstance(m, dict) else str(m) for m in _raw]
    _tiers: list = []
    if G:
        for _m in _mems:
            if _m in G.nodes:
                _mt = str(G.nodes[_m].get("risk_tier", "P4") or "P4")
                if _mt not in _SEVER:
                    _mt = "P4"
                _tiers.append(_mt)
    if _tiers:
        return max(_tiers, key=lambda t: _SEVER.get(t, 0))
    # Fallback: avg_risk score thresholds (legacy save / no-graph scenario)
    _avg = _safe_float(ring.get("avg_risk", 0))
    if _avg >= 80:
        return "P1"
    if _avg >= 60:
        return "P2"
    if _avg >= 40:
        return "P3"
    return "P4"


def _ring_card(ring, name_map, is_live=False, run_ver=""):
    """Build a visually rich card for one lobby ring — with customer names."""
    ring_id = ring["ring_id"]
    size = ring["size"]
    avg_risk = ring.get("avg_risk", 0)
    total_flow = ring.get("total_flow", 0) or ring.get("total_amount", 0) or 0
    initiator = _dn(name_map, ring.get("initiator", "N/A"))
    conduit = _dn(name_map, ring.get("conduit", "N/A"))

    # v14.7 FIX-GAP3: Ring tier = worst member tier (percentile-safe).
    # Extract members + G first so tier reflects actual risk_tier from graph nodes.
    _members_raw = ring.get("nodes", ring.get("members", []))
    members = [m["node_id"] if isinstance(m, dict) else str(m) for m in _members_raw]
    G = get_pipeline().G
    tier = _ring_max_tier(ring, G)
    accent = TIER_COLORS[tier]
    tier_label = TIER_LABELS[tier][0]

    # Members table
    # v12.31 FIX: detect_lobbies returns "members" as list of dicts
    # {"node_id": ..., "risk_score": ...} AND "nodes" as list of plain string IDs.
    # Always prefer "nodes" (strings) first; normalise any dict entries to node_id.
    member_data = []
    for m in members:
        # V12.20 FIX: use dict() copy to avoid NodeView issues; _safe_float prevents TypeError
        attrs = dict(G.nodes[m]) if (G and m in G.nodes) else {}
        m_tier = attrs.get("risk_tier", "P4") or "P4"
        m_tier = m_tier if m_tier in TIER_LABELS else "P4"
        m_tier_lbl = TIER_LABELS.get(m_tier, ("", "", ""))[0]
        # v16.36: business-friendly column names for investigators
        member_data.append(
            {
                "Account Holder": _dn(name_map, m),
                "Risk Score": f"{_safe_float(attrs.get('risk_score')):.0f}/100",
                "Urgency": f"{m_tier} — {m_tier_lbl}",
                "Received": f"${_safe_float(attrs.get('in_flow')):,.0f}",
                "Sent Out": f"${_safe_float(attrs.get('out_flow')):,.0f}",
            }
        )

    # Edges table
    edges = ring.get("edges", [])
    edge_data = (
        [
            {
                "From": _dn(name_map, e.get("from", "")),
                "To": _dn(name_map, e.get("to", "")),
                "Amount": f"${_safe_float(e.get('amount')):,.0f}",
            }
            for e in edges
        ]
        if edges
        else []
    )

    # V12.20 FIX: use _safe_float for avg_risk to prevent TypeError on None
    avg_risk_safe = _safe_float(avg_risk)
    total_flow_safe = _safe_float(total_flow)

    # v16.36: Business commentary for this ring
    biz = ring_business_summary(
        size=size, avg_risk=avg_risk_safe, total_flow=total_flow_safe,
        tier=tier, ring_id=ring_id,
    )
    tier_color_map = {"P1": "red", "P2": "orange", "P3": "yellow", "P4": "green"}
    badge_color = tier_color_map.get(tier, "gray")
    live_badge = (
        dmc.Badge(
            f"LIVE — #{run_ver}" if run_ver else "LIVE DATA",
            color="green", variant="light", size="xs",
        ) if is_live else None
    )

    # ── Business headline card ────────────────────────────────────────────────
    headline_row = dmc.Group(
        [
            dmc.Badge(biz["tier_word"], color=badge_color, variant="filled", size="lg"),
            dmc.Text(biz["headline"], fw=700, c="white", size="sm",
                     style={"flex": "1"}),
        ] + ([live_badge] if live_badge else []),
        gap="xs", mb="xs",
    )

    # ── What happened panel ─────────────────────────────────────────────────
    what_happened_panel = dmc.Paper(
        dmc.Stack(
            [
                dmc.Group(
                    [
                        DashIconify(icon="mdi:information-outline", width=16, color="#00D4FF"),
                        dmc.Text("What Is Happening?", fw=700, c="#00D4FF", size="xs"),
                    ],
                    gap=4,
                ),
                dmc.Text(
                    biz["what_happened"],
                    size="xs", c="#CBD5E1",
                    style={"lineHeight": "1.6"},
                ),
            ],
            gap="xs",
        ),
        p="sm", radius="md", mb="xs",
        style={"background": "rgba(0,212,255,0.04)", "border": "1px solid rgba(0,212,255,0.12)"},
    )

    # ── Business risk panel ──────────────────────────────────────────────────
    biz_risk_panel = dmc.Paper(
        dmc.Stack(
            [
                dmc.Group(
                    [
                        DashIconify(icon="mdi:bank-alert", width=16, color="#FF9800"),
                        dmc.Text("Why This Matters for Our Bank", fw=700, c="#FF9800", size="xs"),
                    ],
                    gap=4,
                ),
                dmc.Text(
                    biz["business_risk"],
                    size="xs", c="#CBD5E1",
                    style={"lineHeight": "1.6"},
                ),
            ],
            gap="xs",
        ),
        p="sm", radius="md", mb="xs",
        style={"background": "rgba(255,152,0,0.04)", "border": "1px solid rgba(255,152,0,0.12)"},
    )

    # ── Action required panel ───────────────────────────────────────────────
    action_color_map = {"P1": "#FF1744", "P2": "#FF9800", "P3": "#FFD600", "P4": "#00E676"}
    action_border_map = {"P1": "rgba(255,23,68,0.25)", "P2": "rgba(255,152,0,0.20)",
                         "P3": "rgba(255,214,0,0.18)", "P4": "rgba(0,230,118,0.15)"}
    action_panel = dmc.Paper(
        dmc.Stack(
            [
                dmc.Group(
                    [
                        DashIconify(icon="mdi:clipboard-check-outline", width=16,
                                    color=action_color_map.get(tier, "#FF9800")),
                        dmc.Text("Recommended Action", fw=700,
                                 c=action_color_map.get(tier, "#FF9800"), size="xs"),
                    ],
                    gap=4,
                ),
                dmc.Text(
                    biz["next_step"],
                    size="xs", c="white", fw=600,
                    style={"lineHeight": "1.7"},
                ),
            ],
            gap="xs",
        ),
        p="sm", radius="md", mb="sm",
        style={
            "background": f"rgba({_hex_to_rgb(action_color_map.get(tier, '#FF9800'))},0.05)",
            "border": f"1px solid {action_border_map.get(tier, 'rgba(255,152,0,0.2)')}",
        },
    )

    # ── Technical detail row (score + initiator — secondary info) ─────────
    detail_row = dmc.Group(
        [
            dmc.Badge(f"Risk Score: {avg_risk_safe:.0f}/100", color=badge_color,
                      variant="light", size="sm"),
            dmc.Badge(f"{size} members in ring", color="cyan", variant="light", size="sm"),
            dmc.Badge(f"${total_flow_safe:,.0f} total flow", color="green",
                      variant="light", size="sm"),
            dmc.Text(
                f"Key person identified: {conduit}  |  Detection initiated from: {initiator}",
                size="xs", c="dimmed",
            ),
        ],
        gap=6, mb="sm",
    )

    content_children = [
        headline_row,
        what_happened_panel,
        biz_risk_panel,
        action_panel,
        detail_row,
    ]

    grid_cols = []
    if member_data:
        grid_cols.append(
            dmc.Stack(
                [
                    dmc.Text("Customers In This Ring", fw=600, c="white", size="sm"),
                    dash_table.DataTable(
                        columns=[{"name": k, "id": k} for k in member_data[0].keys()],
                        data=member_data,
                        style_header=_TH,
                        style_cell=_TC,
                        style_data_conditional=[
                            {
                                "if": {
                                    "column_id": "Priority",
                                    "filter_query": '{Priority} contains "P1"',
                                },
                                "color": "#FF1744",
                                "fontWeight": "bold",
                            },
                            {
                                "if": {
                                    "column_id": "Priority",
                                    "filter_query": '{Priority} contains "P2"',
                                },
                                "color": "#FF9800",
                            },
                        ],
                    ),
                ],
                gap="xs",
            )
        )
    if edge_data:
        grid_cols.append(
            dmc.Stack(
                [
                    dmc.Text("Money Flowing Between Members", fw=600, c="white", size="sm"),
                    dash_table.DataTable(
                        columns=[{"name": k, "id": k} for k in edge_data[0].keys()],
                        data=edge_data,
                        style_header=_TH,
                        style_cell=_TC,
                    ),
                ],
                gap="xs",
            )
        )

    if grid_cols:
        content_children.append(
            dmc.SimpleGrid(cols={"base": 1, "md": 2}, spacing="md", children=grid_cols)
        )

    return dmc.Paper(
        dmc.Stack(content_children, gap="sm"),
        p="lg",
        radius="lg",
        mb="md",
        style={
            "background": f"linear-gradient(135deg, rgba({_hex_to_rgb(accent)},0.04) 0%, rgba(10,14,23,0.95) 100%)",
            "border": f"1px solid rgba({_hex_to_rgb(accent)},0.15)",
        },
    )


# ═══════════════════════════════════════════════════════════════════════════════
# RING RISK BARS — Pure-DMC visual (never blank, no Plotly dependency)
# ═══════════════════════════════════════════════════════════════════════════════


def _ring_risk_bars(rings, nm=None, badge_label="PRE-ANALYSIS REFERENCE"):
    """
    Build a styled DMC progress-bar risk comparison for lobby rings.
    Works for both sample data (keys: name/risk/size/flow) and live data
    (keys: ring_id/avg_risk/size/total_flow/initiator). Never blank.
    """
    if not rings:
        return dmc.Center(
            dmc.Stack(
                [
                    DashIconify(icon="mdi:check-circle-outline", width=32, color="#00E676"),
                    dmc.Text("No lobby rings to display.", fw=600, c="#00E676", size="sm"),
                ],
                align="center",
                gap="xs",
            ),
            style={"minHeight": "180px", "padding": "32px"},
        )

    def _tier_info(risk):
        if risk >= 80:
            return "P1 CRITICAL", "#FF1744", "red", True, "immediate account restriction required"
        if risk >= 60:
            return "P2 HIGH", "#FF9800", "orange", False, "enhanced due diligence today"
        if risk >= 40:
            return "P3 MEDIUM", "#FFD600", "yellow", False, "schedule monitoring review"
        return "P4 LOW", "#00E676", "green", False, "standard monitoring"

    ring_items = []
    p1_count = 0
    for r in rings:
        # ── normalise field names (sample vs live) ──
        if nm and r.get("initiator"):
            name = f"Ring #{r.get('ring_id', '?')} — {_dn(nm, r.get('initiator', ''))}"
        else:
            name = r.get("name") or f"Ring #{r.get('ring_id', '?')}"
        risk = float(r.get("risk") or r.get("avg_risk") or 0)
        size = int(r.get("size") or 0)
        flow = float(r.get("flow") or r.get("total_flow") or r.get("total_amount") or 0)

        tier_lbl, color_hex, mantine_color, is_critical, action = _tier_info(risk)
        if is_critical:
            p1_count += 1

        ring_items.append(
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            # ── Name + tier badge column ──
                            dmc.Stack(
                                [
                                    dmc.Group(
                                        [
                                            dmc.Badge(
                                                tier_lbl,
                                                color=mantine_color,
                                                variant="filled",
                                                size="sm",
                                            ),
                                            dmc.Text(name, fw=600, c="white", size="sm"),
                                        ],
                                        gap="xs",
                                    ),
                                    dmc.Group(
                                        [
                                            DashIconify(
                                                icon="mdi:account-multiple",
                                                width=13,
                                                color="#64748B",
                                            ),
                                            dmc.Text(f"{size} members", size="xs", c="dimmed"),
                                            DashIconify(
                                                icon="mdi:cash-multiple", width=13, color="#64748B"
                                            ),
                                            dmc.Text(
                                                f"${flow:,.0f} suspicious flow",
                                                size="xs",
                                                c="dimmed",
                                            ),
                                        ],
                                        gap=6,
                                    ),
                                ],
                                gap=3,
                                style={"flex": "1 1 180px"},
                            ),
                            # ── Score + progress bar column ──
                            dmc.Stack(
                                [
                                    dmc.Group(
                                        [
                                            dmc.Text(
                                                f"{risk:.0f}",
                                                fw=900,
                                                c=color_hex,
                                                style={
                                                    "fontSize": "2.2rem",
                                                    "lineHeight": "1",
                                                    "minWidth": "58px",
                                                    "fontVariantNumeric": "tabular-nums",
                                                },
                                            ),
                                            dmc.Text(
                                                "out of 100 risk score",
                                                size="xs",
                                                c="dimmed",
                                                mt=12,
                                            ),
                                        ],
                                        gap=6,
                                        align="flex-end",
                                    ),
                                    dmc.Progress(
                                        value=risk,
                                        color=mantine_color,
                                        size="xl",
                                        radius="md",
                                        striped=is_critical,
                                        animated=is_critical,
                                    ),
                                    dmc.Text(
                                        f"→ {action}",
                                        size="xs",
                                        c=color_hex,
                                        fw=600,
                                    ),
                                ],
                                gap=4,
                                style={"flex": "2 1 220px"},
                            ),
                        ],
                        gap="xl",
                        align="center",
                        wrap="wrap",
                    ),
                ],
                p="md",
                radius="md",
                mb="xs",
                style={
                    "background": f"linear-gradient(90deg, {color_hex}16 0%, rgba(10,14,23,0.95) 45%)",
                    "border": f"1px solid {color_hex}28",
                    "borderLeft": f"5px solid {color_hex}",
                },
            ),
        )

    return dmc.Stack(
        [
            dmc.Group(
                [
                    dmc.Stack(
                        [
                            dmc.Text(
                                f"{len(rings)} Lobby Ring{'s' if len(rings) != 1 else ''} Ranked by Danger",
                                fw=700,
                                c="white",
                                size="sm",
                            ),
                            dmc.Text(
                                "Progress bar shows risk score 0–100. "
                                "Striped/animated bar = P1 Critical requiring immediate investigation. "
                                "Sorted from most dangerous to lowest.",
                                size="xs",
                                c="dimmed",
                            ),
                        ],
                        gap=1,
                    ),
                    dmc.Group(
                        [
                            (
                                dmc.Badge(
                                    f"⚠ {p1_count} P1 CRITICAL — act now",
                                    color="red",
                                    variant="filled",
                                    size="sm",
                                )
                                if p1_count
                                else None
                            ),
                            dmc.Badge(badge_label, color="blue", variant="light", size="xs"),
                        ],
                        gap="xs",
                    ),
                ],
                justify="space-between",
                wrap="wrap",
                mb="sm",
            ),
            dmc.Stack(ring_items, gap=4),
        ],
        gap="xs",
    )


# ═══════════════════════════════════════════════════════════════════════════════
# DEFAULT CONTENT — Pre-pipeline CEO-ready reference data
# ═══════════════════════════════════════════════════════════════════════════════



# ═══════════════════════════════════════════════════════════════════════════════
# LOBBY NETWORK VISUALIZATION — v16.25
# Build a Cytoscape graph for any lobby ring: members = nodes, transactions = edges
# Color-coded by risk tier; node size reflects tier severity.
# ═══════════════════════════════════════════════════════════════════════════════

_CYT_STYLESHEET_LOBBY = [
    {
        "selector": "node",
        "style": {
            "label": "data(label)",
            "color": "#e2e8f0",
            "font-size": "10px",
            "text-valign": "bottom",
            "text-halign": "center",
            "text-background-color": "rgba(10,14,23,0.75)",
            "text-background-opacity": 0.9,
            "text-background-padding": "2px",
            "text-margin-y": "4px",
            "width": 38,
            "height": 38,
            "border-width": 2,
            "border-color": "rgba(255,255,255,0.25)",
            "background-color": "#607D8B",
        },
    },
    # tier-based colours + sizes
    {"selector": ".P1", "style": {"background-color": "#FF1744", "border-color": "#FF6B6B", "width": 56, "height": 56}},
    {"selector": ".P2", "style": {"background-color": "#FF9800", "border-color": "#FFB74D", "width": 46, "height": 46}},
    {"selector": ".P3", "style": {"background-color": "#F9A825", "border-color": "#FFEE58"}},
    {"selector": ".P4", "style": {"background-color": "#00C853", "border-color": "#69F0AE"}},
    # hub / conduit marker (data class)
    {"selector": ".hub",  "style": {"shape": "diamond", "border-width": 3, "border-color": "#00D4FF"}},
    # edges
    {
        "selector": "edge",
        "style": {
            "label": "data(label)",
            "color": "#64748B",
            "font-size": "8px",
            "curve-style": "bezier",
            "target-arrow-shape": "triangle",
            "target-arrow-color": "#475569",
            "line-color": "#1E293B",
            "arrow-scale": 1.1,
            "width": 1.5,
            "text-background-color": "rgba(10,14,23,0.6)",
            "text-background-opacity": 0.7,
            "text-background-padding": "1px",
            "text-rotation": "autorotate",
        },
    },
    # hover / selected
    {"selector": "node:selected",  "style": {"border-color": "#00D4FF", "border-width": 4}},
    {"selector": "edge:selected",  "style": {"line-color": "#00D4FF", "target-arrow-color": "#00D4FF"}},
]


def _lobby_to_cytoscape(ring: dict, nm: dict, G) -> list:
    """Convert one lobby ring to a Cytoscape elements list (nodes + edges).

    Nodes carry: id, label (display name), risk_score, tier, node_type, in_flow, out_flow.
    Edges carry: source, target, label (relationship_type), weight.
    The conduit / hub node is given the extra class 'hub' so it renders as a diamond.
    """
    members_raw = ring.get("nodes", ring.get("members", []))
    members = [m["node_id"] if isinstance(m, dict) else str(m) for m in members_raw]
    conduit_id = str(ring.get("conduit", ""))
    elements: list = []

    for node_id in members:
        attrs = dict(G.nodes[node_id]) if (G and node_id in G.nodes) else {}
        risk    = _safe_float(attrs.get("risk_score", 50))
        tier    = attrs.get("risk_tier", "P4") or "P4"
        tier    = tier if tier in ("P1", "P2", "P3", "P4") else "P4"
        nt      = attrs.get("node_type", "Unknown")
        nt1     = attrs.get("node_type1", "") or attrs.get("account_type", "") or "Individual"
        nt2     = attrs.get("customer_segment") or attrs.get("segment") or "—"
        nt3     = attrs.get("occupation") or attrs.get("industry") or "—"
        classes = tier + (" hub" if node_id == conduit_id else "")
        elements.append({
            "data": {
                "id":         node_id,
                "label":      _dn(nm, node_id),
                "risk_score": f"{risk:.1f}",
                "tier":       tier,
                "node_type":  nt,
                "node_type1": nt1,
                "node_type2": nt2,
                "node_type3": nt3,
                "in_flow":    f"${_safe_float(attrs.get('in_flow')):,.0f}",
                "out_flow":   f"${_safe_float(attrs.get('out_flow')):,.0f}",
                "is_hub":     "Yes" if node_id == conduit_id else "No",
            },
            "classes": classes,
        })

    # Add edges only between lobby members (avoids crowding from global graph)
    member_set = set(members)
    if G:
        seen: set = set()
        for src, tgt, edata in G.edges(members, data=True):
            if src in member_set and tgt in member_set:
                key = (src, tgt)
                if key in seen:
                    continue
                seen.add(key)
                rel = edata.get("relationship_type", edata.get("edge_type", "txn"))
                elements.append({
                    "data": {
                        "source": src,
                        "target": tgt,
                        "label":  rel or "",
                        "weight": _safe_float(edata.get("amount", 1)),
                    },
                })
    return elements


def _default_content():
    """Build 3 defaults: (summary_stats, ring_graph, ring_cards)."""

    # ── 1. SUMMARY STATS ──
    pre_stats = [
        ("Active Lobbies Detected", "5", "mdi:target-account", "#FF6B6B"),
        ("Customers In Lobbies", "23", "mdi:account-multiple", "#00D4FF"),
        ("Total Suspicious Flow", "$6,582,000", "mdi:cash-multiple", "#00E676"),
        ("Highest Ring Risk", "81.5 (P1)", "mdi:alert-decagram", "#FF1744"),
    ]
    kpi_cards = []
    for label, value, icon, color in pre_stats:
        kpi_cards.append(
            dmc.Paper(
                dmc.Stack(
                    [
                        DashIconify(icon=icon, width=28, color=color),
                        dmc.Text(
                            value,
                            fw=700,
                            c="white",
                            style={"fontSize": "1.4rem", "lineHeight": "1"},
                        ),
                        dmc.Text(label, size="xs", c="dimmed"),
                        dmc.Badge("PRE-ANALYSIS", color="blue", variant="light", size="xs"),
                    ],
                    gap=4,
                    align="center",
                ),
                p="md",
                radius="lg",
                style={
                    "textAlign": "center",
                    "background": f"linear-gradient(180deg, rgba({_hex_to_rgb(color)},0.06) 0%, rgba(10,14,23,0.95) 100%)",
                    "border": f"1px solid rgba({_hex_to_rgb(color)},0.15)",
                },
            )
        )
    stats_default = dmc.SimpleGrid(cols={"base": 2, "sm": 4}, spacing="md", children=kpi_cards)

    # ── 2. RING COMPARISON (reference) — pure DMC, always visible ──
    sample_rings = [
        {"name": f"Ring #1 — {_sn('CUST-0234')}", "size": 5, "risk": 81.5, "flow": 2150000},
        {"name": f"Ring #2 — {_sn('CUST-0847')}", "size": 4, "risk": 72.3, "flow": 1247500},
        {"name": f"Ring #3 — {_sn('CUST-1789')}", "size": 4, "risk": 77.1, "flow": 1834000},
        {"name": f"Ring #4 — {_sn('CUST-1531')}", "size": 3, "risk": 65.8, "flow": 893200},
        {"name": f"Ring #5 — {_sn('CUST-0612')}", "size": 3, "risk": 58.2, "flow": 456800},
    ]
    ring_comparison = _ring_risk_bars(sample_rings, badge_label="PRE-ANALYSIS REFERENCE")

    # ── 3. RING CARDS (reference) ──
    ref_rings = [
        {
            "ring_id": 1,
            "size": 5,
            "avg_risk": 81.5,
            "total_flow": 2150000,
            "total_amount": 2150000,
            "initiator": "CUST-0234",
            "conduit": "CUST-0891",
            "nodes": ["CUST-0234", "CUST-0891", "CUST-1345", "CUST-0667", "CUST-1488"],
            "members": ["CUST-0234", "CUST-0891", "CUST-1345", "CUST-0667", "CUST-1488"],
            "edges": [],
        },
        {
            "ring_id": 2,
            "size": 4,
            "avg_risk": 72.3,
            "total_flow": 1247500,
            "total_amount": 1247500,
            "initiator": "CUST-0847",
            "conduit": "CUST-1204",
            "nodes": ["CUST-0847", "CUST-1204", "CUST-0553", "CUST-0912"],
            "members": ["CUST-0847", "CUST-1204", "CUST-0553", "CUST-0912"],
            "edges": [],
        },
        {
            "ring_id": 3,
            "size": 4,
            "avg_risk": 77.1,
            "total_flow": 1834000,
            "total_amount": 1834000,
            "initiator": "CUST-1789",
            "conduit": "CUST-0445",
            "nodes": ["CUST-1789", "CUST-0445", "CUST-1267", "CUST-0923"],
            "members": ["CUST-1789", "CUST-0445", "CUST-1267", "CUST-0923"],
            "edges": [],
        },
    ]
    # For default ring cards, build a name map from sample names
    sample_nm = {k: _sn(k) for k in _SAMPLE_NAMES}
    ring_cards = dmc.Stack(
        [
            dmc.Group(
                [
                    dmc.Badge("BASELINE REFERENCE", color="blue", variant="light", size="sm"),
                    dmc.Text(
                        "Sample lobby rings — live data replaces after pipeline execution",
                        size="xs",
                        c="dimmed",
                    ),
                ],
                gap="sm",
            ),
        ]
        + [_ring_card(r, sample_nm, is_live=False) for r in ref_rings],
        gap="md",
    )

    return (
        stats_default,
        ring_comparison,
        ring_cards,
        _build_default_action_table(),
        _build_default_risk_matrix(),
    )


# ═══════════════════════════════════════════════════════════════════════════════
# ACTION TABLE HELPERS — v15.17
# ═══════════════════════════════════════════════════════════════════════════════

_TIER_DMC_COLOR = {"P1": "red", "P2": "orange", "P3": "yellow", "P4": "green"}

_ACTION_MAP = {
    "P1": "Escalate to MLRO immediately — issue account restriction and open investigation within 24h",
    "P2": "Enhanced due diligence + senior analyst review within 24h",
    "P3": "Active monitoring + EDD if patterns persist within 5 days",
    "P4": "Standard monitoring — flag for next review cycle",
}
_SLA_MAP = {
    "P1": "Immediate (today)",
    "P2": "Within 24 hours",
    "P3": "Within 5 business days",
    "P4": "Standard review cycle",
}


def _build_action_table(lobbies, nm, G_param, is_live=True):
    """v15.17: Build per-ring intelligence narrative + structured action table."""
    if not lobbies:
        return dmc.Paper(
            dmc.Group(
                [
                    DashIconify(icon="mdi:check-circle-outline", width=22, color="#00E676"),
                    dmc.Text(
                        "No lobby rings detected — network clean.", fw=600, c="#00E676", size="sm"
                    ),
                ],
                gap="sm",
            ),
            p="sm",
            radius="md",
            style={"background": "rgba(0,230,118,0.05)", "border": "1px solid rgba(0,230,118,0.2)"},
        )

    # ── CEO ACTION BANNER ───────────────────────────────────────────────────
    p1_rings = [r for r in lobbies if _ring_max_tier(r, G_param) == "P1"]
    p2_rings = [r for r in lobbies if _ring_max_tier(r, G_param) == "P2"]
    total_flow = sum(
        _safe_float(r.get("total_flow", 0) or r.get("total_amount", 0)) for r in lobbies
    )
    banner_color = "#FF1744" if p1_rings else "#FF9800"
    banner_icon = "mdi:alert-octagram" if p1_rings else "mdi:alert"
    banner_text = (
        (
            f"{len(p1_rings)} P1 CRITICAL ring{'s' if len(p1_rings) != 1 else ''} "
            f"require immediate account restriction. "
            if p1_rings
            else ""
        )
        + (
            f"{len(p2_rings)} P2 HIGH RISK ring{'s' if len(p2_rings) != 1 else ''} "
            f"require action within 24 hours. "
            if p2_rings
            else ""
        )
        + f"Total suspicious flow across {len(lobbies)} ring{'s' if len(lobbies) != 1 else ''}: ${total_flow:,.0f}."
    )

    ceo_banner = dmc.Paper(
        [
            dmc.Group(
                [
                    DashIconify(icon=banner_icon, width=28, color=banner_color),
                    dmc.Stack(
                        [
                            dmc.Text(
                                "PATTERN ANALYSIS — INTERNAL FINDING",
                                fw=700,
                                c=banner_color,
                                size="sm",
                                style={"letterSpacing": "0.06em"},
                            ),
                            dmc.Text(
                                banner_text, size="xs", c="dimmed", style={"lineHeight": "1.5"}
                            ),
                        ],
                        gap=2,
                    ),
                    dmc.Group(
                        [
                            (
                                dmc.Badge(
                                    f"{len(p1_rings)} P1 CRITICAL",
                                    color="red",
                                    variant="filled",
                                    size="sm",
                                )
                                if p1_rings
                                else None
                            ),
                            (
                                dmc.Badge(
                                    f"{len(p2_rings)} P2 HIGH RISK",
                                    color="orange",
                                    variant="filled",
                                    size="sm",
                                )
                                if p2_rings
                                else None
                            ),
                            dmc.Badge(
                                f"${total_flow:,.0f} total",
                                color="gray",
                                variant="light",
                                size="sm",
                            ),
                        ],
                        gap="xs",
                    ),
                ],
                gap="md",
                align="flex-start",
                wrap="wrap",
            ),
        ],
        p="md",
        radius="md",
        mb="md",
        style={
            "background": f"linear-gradient(135deg, rgba({_hex_to_rgb(banner_color)},0.10) 0%, rgba(10,14,23,0.97) 100%)",
            "border": f"2px solid rgba({_hex_to_rgb(banner_color)},0.40)",
        },
    )

    # ── PER-RING NARRATIVES ─────────────────────────────────────────────────
    narrative_cards = []
    for r in lobbies[:15]:  # cap at 15 for display performance
        ring_id = r.get("ring_id")
        members = r.get("members", r.get("nodes", []))
        size = r.get("size", len(members))
        flow = _safe_float(r.get("total_flow", 0) or r.get("total_amount", 0))
        avg_risk = _safe_float(r.get("avg_risk"))
        tier = (
            _ring_max_tier(r, G_param)
            if G_param
            else (
                "P1"
                if avg_risk >= 80
                else "P2" if avg_risk >= 60 else "P3" if avg_risk >= 40 else "P4"
            )
        )
        hub = _dn(nm, r.get("initiator", members[0] if members else "Unknown"))
        col = TIER_COLORS.get(tier, "#FF6B6B")
        tier_lbl = TIER_LABELS[tier][0]
        action = _ACTION_MAP.get(tier, "Review")
        sla = _SLA_MAP.get(tier, "Review")
        narrative = (
            f"Ring #{ring_id} is a {size}-member {tier} {tier_lbl} lobby "
            f"with ${flow:,.0f} in suspicious circular flow. "
            f"Hub account: {hub} (avg ring risk score: {avg_risk:.0f}/100). "
            f"Required action: {action}. SLA: {sla}."
        )
        narrative_cards.append(
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            html.Div(
                                style={
                                    "width": "10px",
                                    "height": "10px",
                                    "borderRadius": "50%",
                                    "backgroundColor": col,
                                    "flexShrink": "0",
                                }
                            ),
                            dmc.Text(f"Ring #{ring_id}", fw=700, c=col, size="sm"),
                            dmc.Badge(
                                tier,
                                color=_TIER_DMC_COLOR.get(tier, "gray"),
                                variant="filled",
                                size="xs",
                            ),
                            dmc.Badge(
                                tier_lbl,
                                color=_TIER_DMC_COLOR.get(tier, "gray"),
                                variant="light",
                                size="xs",
                            ),
                            dmc.Badge(f"{size} members", color="cyan", variant="light", size="xs"),
                            dmc.Badge(f"${flow:,.0f}", color="gray", variant="light", size="xs"),
                        ],
                        gap="xs",
                        wrap="wrap",
                    ),
                    dmc.Text(
                        narrative, size="xs", c="dimmed", mt="xs", style={"lineHeight": "1.6"}
                    ),
                ],
                p="sm",
                radius="md",
                style={
                    "backgroundColor": f"rgba({_hex_to_rgb(col)},0.04)",
                    "borderLeft": f"4px solid {col}",
                    "marginBottom": "6px",
                },
            )
        )

    # ── ACTION TABLE ────────────────────────────────────────────────────────
    table_rows = []
    for r in lobbies:
        members = r.get("members", r.get("nodes", []))
        size = r.get("size", len(members))
        flow = _safe_float(r.get("total_flow", 0) or r.get("total_amount", 0))
        avg_risk = _safe_float(r.get("avg_risk"))
        tier = (
            _ring_max_tier(r, G_param)
            if G_param
            else (
                "P1"
                if avg_risk >= 80
                else "P2" if avg_risk >= 60 else "P3" if avg_risk >= 40 else "P4"
            )
        )
        hub = _dn(nm, r.get("initiator", members[0] if members else ""))
        table_rows.append(
            {
                "Ring #": str(r.get("ring_id", "")),
                "Priority": tier,
                "Hub Customer": hub,
                "Members": str(size),
                "Susp. Flow": f"${flow:,.0f}",
                "Risk Score": f"{avg_risk:.0f}",
                "Required Action": _ACTION_MAP.get(tier, "Review"),
                "SLA": _SLA_MAP.get(tier, "Review"),
            }
        )

    action_table = dash_table.DataTable(
        data=table_rows,
        columns=[
            {"name": c, "id": c}
            for c in [
                "Ring #",
                "Priority",
                "Hub Customer",
                "Members",
                "Susp. Flow",
                "Risk Score",
                "Required Action",
                "SLA",
            ]
        ],
        style_header=_TH,
        style_cell=_TC,
        style_data_conditional=[
            {
                "if": {"filter_query": '{Priority} = "P1"'},
                "backgroundColor": "rgba(255,23,68,0.08)",
                "borderLeft": "3px solid #FF1744",
            },
            {
                "if": {"filter_query": '{Priority} = "P2"'},
                "backgroundColor": "rgba(255,152,0,0.06)",
                "borderLeft": "3px solid #FF9800",
            },
        ],
        sort_action="native",
        page_size=20,
        style_table={"overflowX": "auto"},
    )

    live_badge = (
        dmc.Badge("LIVE DATA", color="green", variant="light", size="xs")
        if is_live
        else dmc.Badge("PRE-ANALYSIS", color="blue", variant="light", size="xs")
    )

    return dmc.Stack(
        [
            ceo_banner,
            dmc.Group(
                [
                    DashIconify(icon="mdi:text-box-check-outline", width=18, color="#FF6B6B"),
                    dmc.Text("Per-Ring Intelligence Brief", fw=700, c="white", size="sm"),
                    dmc.Badge(
                        f"{len(lobbies)} ring(s) detected", color="red", variant="light", size="xs"
                    ),
                    live_badge,
                ],
                gap="sm",
                mb="xs",
            ),
            dmc.Stack(narrative_cards, gap=0),
            dmc.Divider(my="md"),
            dmc.Group(
                [
                    DashIconify(icon="mdi:table-check", width=18, color="#00D4FF"),
                    dmc.Text("Structured Action Table — All Rings", fw=700, c="white", size="sm"),
                    dmc.Badge(
                        "Click column headers to sort", color="blue", variant="light", size="xs"
                    ),
                ],
                gap="sm",
                mb="xs",
            ),
            action_table,
        ],
        gap="xs",
    )


def _build_default_action_table():
    """v15.17: Placeholder action table shown before any pipeline run."""
    return dmc.Paper(
        dmc.Stack(
            [
                dmc.Group(
                    [
                        DashIconify(icon="mdi:clock-outline", width=18, color="#00D4FF"),
                        dmc.Text(
                            "Action Brief — Waiting for Pipeline Data", fw=700, c="white", size="sm"
                        ),
                    ],
                    gap="sm",
                ),
                dmc.Text(
                    "Run the pipeline to generate AI-detected lobby rings. "
                    "Once complete, this tab will show: a CEO-level action banner, "
                    "per-ring intelligence narratives, and a sortable action table "
                    "with recommended actions and SLA deadlines.",
                    size="xs",
                    c="dimmed",
                    style={"lineHeight": "1.6"},
                ),
                dmc.Group(
                    [
                        dmc.Badge(
                            "CEO banner: P1/P2 counts + total flow",
                            color="red",
                            variant="light",
                            size="xs",
                        ),
                        dmc.Badge(
                            "Per-ring narrative paragraph",
                            color="orange",
                            variant="light",
                            size="xs",
                        ),
                        dmc.Badge("SLA action table", color="cyan", variant="light", size="xs"),
                    ],
                    gap="xs",
                    mt="xs",
                ),
            ],
            gap="sm",
        ),
        p="lg",
        radius="md",
        style={"background": "rgba(0,212,255,0.03)", "border": "1px solid rgba(0,212,255,0.10)"},
    )


# ═══════════════════════════════════════════════════════════════════════════════
# RISK MATRIX HELPERS — v15.18 TASK2
# ═══════════════════════════════════════════════════════════════════════════════


def _build_default_risk_matrix():
    """v15.18 TASK2: Placeholder risk matrix before pipeline run."""
    return dmc.Paper(
        dmc.Stack(
            [
                dmc.Group(
                    [
                        DashIconify(icon="mdi:grid-large", width=18, color="#00D4FF"),
                        dmc.Text("Ring Size × Risk Tier Matrix", fw=700, c="white", size="sm"),
                    ],
                    gap="sm",
                ),
                dmc.Text(
                    "Run the pipeline to generate the ring size × risk tier distribution heatmap. "
                    "This matrix will show how many rings of each detected size (3-member, 4-member, …) "
                    "fall into each risk tier — revealing criminal network sophistication at a glance.",
                    size="xs",
                    c="dimmed",
                    style={"lineHeight": "1.6"},
                ),
                dmc.Group(
                    [
                        dmc.Badge(
                            "Heat color = avg risk intensity",
                            color="red",
                            variant="light",
                            size="xs",
                        ),
                        dmc.Badge(
                            "Cell number = ring count", color="orange", variant="light", size="xs"
                        ),
                        dmc.Badge(
                            "Rows = only ring sizes detected",
                            color="cyan",
                            variant="light",
                            size="xs",
                        ),
                    ],
                    gap="xs",
                    mt="xs",
                ),
            ],
            gap="sm",
        ),
        p="lg",
        radius="md",
        style={"background": "rgba(0,212,255,0.03)", "border": "1px solid rgba(0,212,255,0.10)"},
    )


def _build_risk_matrix(lobbies, nm, G_param, is_live=True):
    """v15.18 TASK2: Ring Size × Risk Tier heatmap matrix (PhD AML grade).

    AML Analytical Insight:
      - Small rings (3–4 members) + P1: Concentrated criminal cell.
        Hub-and-spoke placement scheme. High-value, low-headcount.
      - Medium rings (5–6 members) + P1: Organized layering scheme with conduit
        accounts. Suggests a professional money launderer.
      - Large rings (7+ members) + P1: Sophisticated organised crime network.
        Coordinate multiple activity reports across all ring members.

    Axes:
      Row  = distinct ring sizes detected in this pipeline run (dynamic).
      Col  = risk tier (P1 Critical → P4 Low).
      Cell = avg risk score as heat intensity + count as text.
    """
    from collections import defaultdict

    if not lobbies:
        return _build_default_risk_matrix()

    tiers = ["P1", "P2", "P3", "P4"]

    # ── Bucket rings by (size, tier) ─────────────────────────────────────────
    buckets = defaultdict(lambda: {t: [] for t in tiers})
    for r in lobbies:
        members = r.get("members", r.get("nodes", []))
        size = r.get("size", len(members))
        tier = (
            _ring_max_tier(r, G_param)
            if G_param
            else (
                "P1"
                if _safe_float(r.get("avg_risk")) >= 80
                else (
                    "P2"
                    if _safe_float(r.get("avg_risk")) >= 60
                    else "P3" if _safe_float(r.get("avg_risk")) >= 40 else "P4"
                )
            )
        )
        buckets[size][tier].append(_safe_float(r.get("avg_risk")))

    sizes = sorted(buckets.keys())

    # ── Build z (avg risk) and text (count) matrices ──────────────────────────
    z_vals, text_vals = [], []
    for s in sizes:
        row_z, row_t = [], []
        for tier in tiers:
            risks = buckets[s][tier]
            if risks:
                row_z.append(round(sum(risks) / len(risks), 1))
                row_t.append(str(len(risks)))
            else:
                row_z.append(None)
                row_t.append("")
        z_vals.append(row_z)
        text_vals.append(row_t)

    y_labels = [f"{s}-member" for s in sizes]

    # ── Plotly Heatmap ────────────────────────────────────────────────────────
    fig = go.Figure(
        data=go.Heatmap(
            z=z_vals,
            x=tiers,
            y=y_labels,
            text=text_vals,
            texttemplate="<b>%{text}</b>",
            textfont={"size": 18, "color": "white"},
            colorscale=[
                [0.00, "rgba(0,230,118,0.30)"],
                [0.40, "rgba(255,214,0,0.65)"],
                [0.70, "rgba(255,152,0,0.85)"],
                [1.00, "rgba(255,23,68,0.95)"],
            ],
            zmin=0,
            zmax=100,
            showscale=True,
            hoverongaps=False,
            hovertemplate=(
                "<b>%{y}</b><br>"
                "Tier: <b>%{x}</b><br>"
                "Rings: <b>%{text}</b><br>"
                "Avg risk: <b>%{z:.1f}</b>"
                "<extra></extra>"
            ),
            xgap=4,
            ygap=4,
            colorbar=dict(
                title=dict(text="Avg Risk", font=dict(color="#94A3B8", size=11)),
                tickvals=[0, 25, 50, 75, 100],
                ticktext=["0 (Low)", "25", "50", "75", "100 (Crit)"],
                tickfont=dict(color="#94A3B8", size=9),
                thickness=12,
            ),
        )
    )
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color="#94A3B8", size=12),
        margin=dict(l=120, r=20, t=40, b=60),
        xaxis=dict(
            title=dict(text="Risk Tier", font=dict(color="#94A3B8", size=12)),
            tickfont=dict(color="#E2E8F0", size=13, family="monospace"),
        ),
        yaxis=dict(
            title=dict(text="Ring Size", font=dict(color="#94A3B8", size=12)),
            tickfont=dict(color="#E2E8F0", size=11),
            autorange="reversed",
        ),
    )

    # ── Per-tier summary chips ────────────────────────────────────────────────
    tier_totals = {t: {"count": 0, "flow": 0.0} for t in tiers}
    for r in lobbies:
        t = _ring_max_tier(r, G_param) if G_param else "P4"
        tier_totals[t]["count"] += 1
        tier_totals[t]["flow"] += _safe_float(r.get("total_flow", 0) or r.get("total_amount", 0))

    chips = []
    for tier in tiers:
        cnt = tier_totals[tier]["count"]
        if cnt == 0:
            continue
        fl = tier_totals[tier]["flow"]
        col = TIER_COLORS[tier]
        dmc_col = _TIER_DMC_COLOR.get(tier, "gray")
        chips.append(
            dmc.Paper(
                dmc.Stack(
                    [
                        dmc.Group(
                            [
                                html.Div(
                                    style={
                                        "width": "8px",
                                        "height": "8px",
                                        "borderRadius": "50%",
                                        "backgroundColor": col,
                                    }
                                ),
                                dmc.Text(tier, fw=700, c=col, size="xs"),
                                dmc.Badge(
                                    TIER_LABELS[tier][0], color=dmc_col, variant="light", size="xs"
                                ),
                            ],
                            gap=4,
                        ),
                        dmc.Text(
                            str(cnt),
                            fw=700,
                            c="white",
                            style={"fontSize": "1.5rem", "lineHeight": "1"},
                        ),
                        dmc.Text("ring(s)", size="xs", c="dimmed"),
                        dmc.Text(f"${fl:,.0f}", size="xs", c="dimmed"),
                    ],
                    gap=2,
                    align="center",
                ),
                p="sm",
                radius="md",
                style={
                    "textAlign": "center",
                    "background": f"linear-gradient(180deg, rgba({_hex_to_rgb(col)},0.08) 0%, rgba(10,14,23,0.95) 100%)",
                    "border": f"1px solid rgba({_hex_to_rgb(col)},0.20)",
                },
            )
        )

    # ── AML expert interpretation guide ──────────────────────────────────────
    guide = dmc.Paper(
        [
            dmc.Group(
                [
                    DashIconify(icon="mdi:lightbulb-outline", width=16, color="#00D4FF"),
                    dmc.Text(
                        "AML Interpretation — Ring Size vs. Risk Tier", fw=700, c="white", size="xs"
                    ),
                ],
                gap="sm",
                mb="xs",
            ),
            dmc.SimpleGrid(
                cols={"base": 1, "md": 2},
                spacing="xs",
                children=[
                    dmc.Group(
                        [
                            DashIconify(icon="mdi:circle-small", width=14, color="#FF1744"),
                            dmc.Text(
                                "3–4 member + P1: Concentrated criminal cell. "
                                "Hub-and-spoke placement. Restrict hub account immediately.",
                                size="xs",
                                c="dimmed",
                            ),
                        ],
                        gap=4,
                        wrap="nowrap",
                        align="flex-start",
                    ),
                    dmc.Group(
                        [
                            DashIconify(icon="mdi:circle-small", width=14, color="#FF9800"),
                            dmc.Text(
                                "5–6 member + P1: Organized layering scheme. "
                                "Likely a professional money launderer coordinating accounts.",
                                size="xs",
                                c="dimmed",
                            ),
                        ],
                        gap=4,
                        wrap="nowrap",
                        align="flex-start",
                    ),
                    dmc.Group(
                        [
                            DashIconify(icon="mdi:circle-small", width=14, color="#FFD600"),
                            dmc.Text(
                                "7+ member + P1: Extensive coordinated circular flow network. "
                                "Recommend simultaneous group-level deep-dive across all ring members.",
                                size="xs",
                                c="dimmed",
                            ),
                        ],
                        gap=4,
                        wrap="nowrap",
                        align="flex-start",
                    ),
                    dmc.Group(
                        [
                            DashIconify(icon="mdi:circle-small", width=14, color="#00E676"),
                            dmc.Text(
                                "Any size + P4: Low risk. Circular flows may be legitimate "
                                "business transactions. Standard monitoring applies.",
                                size="xs",
                                c="dimmed",
                            ),
                        ],
                        gap=4,
                        wrap="nowrap",
                        align="flex-start",
                    ),
                ],
            ),
        ],
        p="sm",
        radius="md",
        mt="md",
        style={"background": "rgba(0,212,255,0.03)", "border": "1px solid rgba(0,212,255,0.08)"},
    )

    live_badge = (
        dmc.Badge("LIVE DATA", color="green", variant="light", size="xs")
        if is_live
        else dmc.Badge("PRE-ANALYSIS", color="blue", variant="light", size="xs")
    )

    _stack_items = [
        dmc.Group(
            [
                DashIconify(icon="mdi:grid", width=18, color="#FF6B6B"),
                dmc.Text("Ring Size × Risk Tier Distribution Matrix", fw=700, c="white", size="sm"),
                dmc.Badge(f"{len(sizes)} ring size(s)", color="cyan", variant="light", size="xs"),
                dmc.Badge(f"{len(lobbies)} total rings", color="gray", variant="light", size="xs"),
                live_badge,
            ],
            gap="sm",
            mb="xs",
        ),
        dmc.Text(
            "Color intensity = average risk score of rings in that bucket (darker red = higher risk). "
            "Number in cell = count of detected rings. "
            "White/empty = no rings detected for that size–tier combination.",
            size="xs",
            c="dimmed",
            mb="sm",
            style={"lineHeight": "1.5"},
        ),
        (
            dmc.SimpleGrid(cols={"base": 2, "sm": 4}, spacing="xs", children=chips, mb="md")
            if chips
            else None
        ),
        dcc.Graph(
            figure=fig,
            config={"displayModeBar": False},
            style={"height": f"{max(220, len(sizes) * 70 + 100)}px"},
        ),
        guide,
    ]
    return dmc.Stack([c for c in _stack_items if c is not None], gap="xs")


# ═══════════════════════════════════════════════════════════════════════════════
# LAYOUT — Executive Single-Page Presentation
# ═══════════════════════════════════════════════════════════════════════════════

layout = dmc.Box(
    [
        dcc.Interval(id="la-init", interval=5000, max_intervals=-1),
        # ━━━ EXECUTIVE HEADER ━━━
        dmc.Paper(
            [
                dmc.Group(
                    [
                        dmc.Group(
                            [
                                DashIconify(
                                    icon="mdi:account-group-outline", width=40, color="#FF6B6B"
                                ),
                                dmc.Stack(
                                    [
                                        dmc.Title(
                                            "Lobby Analysis",
                                            order=2,
                                            c="white",
                                            style={"letterSpacing": "0.02em"},
                                        ),
                                        dmc.Text(
                                            "Detecting organized groups of customers who transact "
                                            "in suspicious circular patterns — the structure behind money-laundering rings",
                                            c="dimmed",
                                            size="sm",
                                        ),
                                    ],
                                    gap=0,
                                ),
                            ],
                            gap="md",
                        ),
                        dmc.Group(
                            [
                                dmc.Badge(
                                    f"v{APP.VERSION}", color="red", variant="outline", size="lg"
                                ),
                                dmc.Button(
                                    "⟳ Refresh",
                                    id="la-refresh-btn",
                                    size="xs",
                                    variant="light",
                                    color="red",
                                    leftSection=DashIconify(icon="mdi:refresh", width=16),
                                ),
                                dcc.Link(
                                    dmc.Button(
                                        "← Dashboard", size="xs", variant="subtle", color="gray"
                                    ),
                                    href="/",
                                    style={"textDecoration": "none"},
                                ),
                                dcc.Link(
                                    dmc.Button(
                                        "← Network Intelligence",
                                        size="xs",
                                        variant="light",
                                        color="cyan",
                                    ),
                                    href="/network-intelligence",
                                    style={"textDecoration": "none"},
                                ),
                            ],
                            gap="sm",
                        ),
                    ],
                    justify="space-between",
                ),
            ],
            p="xl",
            radius="lg",
            mb="lg",
            style={
                "background": "linear-gradient(135deg, rgba(255,107,107,0.05) 0%, rgba(10,14,23,0.95) 100%)",
                "border": "1px solid rgba(255,107,107,0.15)",
            },
        ),
        # ━━━ CEO EXECUTIVE BRIEF ━━━
        dmc.Paper(
            [
                dmc.Group(
                    [
                        DashIconify(icon="mdi:briefcase-outline", width=22, color="#FF6B6B"),
                        dmc.Stack(
                            [
                                dmc.Text(
                                    "What Is This Page? — Executive Overview",
                                    fw=700,
                                    c="white",
                                    size="sm",
                                ),
                                dmc.Text(
                                    "Lobby Analysis detects organized crime rings: groups of customers who "
                                    "secretly coordinate their transactions to disguise illegal money (money laundering). "
                                    "The system identifies these 'lobbies' automatically by analysing circular money flows — "
                                    "for example, Customer A sends to B, B sends to C, and C sends back to A, creating a suspicious loop. "
                                    "Each detected ring is ranked by its danger level (0–100). "
                                    "This page answers: 'Are there coordinated criminal networks operating in my customer base?'",
                                    size="xs",
                                    c="dimmed",
                                    style={"lineHeight": "1.6"},
                                ),
                            ],
                            gap=4,
                        ),
                    ],
                    gap="md",
                    align="flex-start",
                ),
                dmc.Group(
                    [
                        dmc.Badge(
                            "Progress bar width = ring danger score (0–100)",
                            color="red",
                            variant="light",
                            size="xs",
                        ),
                        dmc.Badge(
                            "Score ≥ 80 = immediate account restriction required",
                            color="orange",
                            variant="light",
                            size="xs",
                        ),
                        dmc.Badge(
                            "Ring cards show all members + money flow",
                            color="cyan",
                            variant="light",
                            size="xs",
                        ),
                    ],
                    gap="xs",
                    mt="sm",
                ),
            ],
            p="md",
            radius="md",
            mb="sm",
            style={
                "background": "linear-gradient(135deg, rgba(255,107,107,0.04) 0%, rgba(10,14,23,0.95) 100%)",
                "border": "1px solid rgba(255,107,107,0.12)",
            },
        ),
        # ━━━ v16.10 T3: RISK PRIORITY (LEFT, compressed) + MONEY-LAUNDERING EXPLAINER (RIGHT) — side by side at top ━━━
        html.Div(
            [
                # LEFT: Risk Priority Classification — compressed smaller box
                html.Div(
                    _risk_tier_legend(),
                    style={"flex": "1 1 280px", "maxWidth": "400px", "display": "flex", "flexDirection": "column"},
                ),
                # RIGHT: AML Lobby Ring Explanation Chart — compact layout
                dmc.Paper(
                    [
                        dmc.Group(
                            [
                                DashIconify(icon="mdi:graph-outline", width=18, color="#FF6B6B"),
                                dmc.Text(
                                    "How a Money-Laundering Lobby Works",
                                    fw=700,
                                    c="white",
                                    size="xs",
                                ),
                            ],
                            gap="xs",
                            mb=4,
                        ),
                        # v16.11 T3: Side-by-side ring diagram + explanation steps
                        html.Div(
                            [
                                # LEFT: Plotly ring diagram — compact
                                html.Div(
                                    dcc.Graph(
                                        id="la-ring-explainer",
                                        config={"displayModeBar": False, "staticPlot": True},
                                        style={"height": "180px"},
                                        figure=_build_ring_explainer_fig(),
                                    ),
                                    style={"flex": "1 1 200px", "minWidth": "180px"},
                                ),
                                # RIGHT: Business explanation — compact vertical list
                                html.Div(
                                    [
                                        dmc.Group(
                                            [
                                                dmc.Badge("1", color="red", variant="filled", size="xs", w=22),
                                                dmc.Text("Placement — Dirty money enters via the Hub", size="xs", c="dimmed"),
                                            ],
                                            gap=4, wrap="nowrap",
                                        ),
                                        dmc.Group(
                                            [
                                                dmc.Badge("2", color="orange", variant="filled", size="xs", w=22),
                                                dmc.Text("Layering — Passes through Conduits in circular patterns", size="xs", c="dimmed"),
                                            ],
                                            gap=4, wrap="nowrap",
                                        ),
                                        dmc.Group(
                                            [
                                                dmc.Badge("3", color="yellow", variant="filled", size="xs", w=22),
                                                dmc.Text("Integration — Clean funds return to Hub or exit via Receiver", size="xs", c="dimmed"),
                                            ],
                                            gap=4, wrap="nowrap",
                                        ),
                                        dmc.Divider(my=4),
                                        dmc.Group(
                                            [
                                                DashIconify(icon="mdi:target-account", width=14, color="#FF1744"),
                                                dmc.Text("Key Person = Hub/Conduit", fw=600, c="#FF1744", size="xs"),
                                                dmc.Text("— restrict this account to disrupt the network", size="xs", c="dimmed"),
                                            ],
                                            gap=4, wrap="wrap",
                                        ),
                                    ],
                                    style={"flex": "1 1 200px", "display": "flex", "flexDirection": "column", "gap": "6px", "justifyContent": "center"},
                                ),
                            ],
                            style={"display": "flex", "gap": "12px", "alignItems": "center", "flexWrap": "wrap"},
                        ),
                    ],
                    p="sm",
                    radius="md",
                    className="glass-card",
                    mb="lg",
                    style={
                        "border": "1px solid rgba(255,107,107,0.15)",
                        "flex": "2 1 0%",
                        "minWidth": "320px",
                    },
                ),
            ],
            style={
                "display": "flex",
                "gap": "16px",
                "alignItems": "stretch",
                "flexWrap": "wrap",
                "marginBottom": "8px",
            },
        ),
        # ━━━ EXECUTIVE SUMMARY STATS (full width, below top row) ━━━
        dmc.Paper(
            [
                _section_header(
                    "mdi:chart-box-outline",
                    "#00D4FF",
                    "Executive Summary — Lobby Detection Results",
                    "Key metrics from the lobby detection engine. "
                    "Rings are detected using directed cycle analysis (NetworkX simple_cycles) on the transaction graph. "
                    "Minimum ring size is 3 — two accounts cannot form a self-sustaining loop without a third conduit to complete the circular flow; this is the smallest closed laundering circuit possible. "
                    "Maximum ring size is capped at 8 — rings beyond 8 members are operationally fragile (more members = more exposure risk for the criminal network) "
                    "and statistically rare; AML typology research shows most organised schemes use 3–6 members for stealth. "
                    "P1 and P2 rings indicate high-confidence organised layering activity requiring immediate escalation.",
                ),
                html.Div(id="la-summary-stats"),
            ],
            p="xl",
            radius="lg",
            className="glass-card",
            mb="lg",
            style={"border": "1px solid rgba(255,255,255,0.06)"},
        ),
        # ━━━ TABBED ANALYSIS VIEW — v15.17 ━━━
        dcc.Tabs(
            [
                dcc.Tab(
                    label="📋  Action Brief",
                    value="action",
                    style={
                        "color": "#94A3B8",
                        "backgroundColor": "rgba(17,24,39,0.8)",
                        "border": "1px solid rgba(255,255,255,0.06)",
                    },
                    selected_style={
                        "color": "#FF6B6B",
                        "backgroundColor": "rgba(17,24,39,0.95)",
                        "borderTop": "2px solid #FF6B6B",
                        "border": "1px solid rgba(255,107,107,0.25)",
                    },
                    children=[
                        html.Div(id="la-action-table", style={"padding": "16px 0"}),
                    ],
                ),
                dcc.Tab(
                    label="📊  Risk Overview",
                    value="risk",
                    style={
                        "color": "#94A3B8",
                        "backgroundColor": "rgba(17,24,39,0.8)",
                        "border": "1px solid rgba(255,255,255,0.06)",
                    },
                    selected_style={
                        "color": "#FF9800",
                        "backgroundColor": "rgba(17,24,39,0.95)",
                        "borderTop": "2px solid #FF9800",
                        "border": "1px solid rgba(255,152,0,0.25)",
                    },
                    children=[
                        html.Div(
                            [
                                dmc.Text(
                                    "Each row is one detected lobby ring. Bar width = average risk score (0–100). "
                                    "Red/striped = P1 Critical: restrict accounts now. Orange = P2 High: escalate today.",
                                    size="xs",
                                    c="dimmed",
                                    style={"lineHeight": "1.5", "marginBottom": "12px"},
                                ),
                                html.Div(id="la-ring-graph", style={"minHeight": "80px"}),
                            ],
                            style={"padding": "16px 0"},
                        ),
                    ],
                ),
                dcc.Tab(
                    label="🔍  Ring Details",
                    value="details",
                    style={
                        "color": "#94A3B8",
                        "backgroundColor": "rgba(17,24,39,0.8)",
                        "border": "1px solid rgba(255,255,255,0.06)",
                    },
                    selected_style={
                        "color": "#00D4FF",
                        "backgroundColor": "rgba(17,24,39,0.95)",
                        "borderTop": "2px solid #00D4FF",
                        "border": "1px solid rgba(0,212,255,0.25)",
                    },
                    children=[
                        html.Div(
                            [
                                # ── FILTERS ──
                                dmc.Accordion(
                                    [
                                        dmc.AccordionItem(
                                            [
                                                dmc.AccordionControl(
                                                    dmc.Group(
                                                        [
                                                            DashIconify(
                                                                icon="mdi:filter-outline",
                                                                width=18,
                                                                color="#FF6B6B",
                                                            ),
                                                            dmc.Text(
                                                                "Advanced Filters — Search by Customer Name or Ring",
                                                                fw=600,
                                                                c="white",
                                                                size="sm",
                                                            ),
                                                        ],
                                                        gap="sm",
                                                    ),
                                                ),
                                                dmc.AccordionPanel(
                                                    [
                                                        dmc.SimpleGrid(
                                                            cols={"base": 1, "md": 4, "xl": 5},
                                                            spacing="sm",
                                                            children=[
                                                                dmc.TextInput(
                                                                    id="la-filter-custid",
                                                                    placeholder="Customer Name or ID...",
                                                                    leftSection=DashIconify(
                                                                        icon="mdi:magnify", width=16
                                                                    ),
                                                                    styles={
                                                                        "input": {
                                                                            "backgroundColor": THEME.DARK_BG,
                                                                            "color": "white",
                                                                            "border": f"1px solid {THEME.DARK_BORDER}",
                                                                        }
                                                                    },
                                                                ),
                                                                dmc.NumberInput(
                                                                    id="la-filter-ring",
                                                                    placeholder="Ring #",
                                                                    min=1,
                                                                    max=100,
                                                                    leftSection=DashIconify(
                                                                        icon="mdi:circle-outline",
                                                                        width=16,
                                                                    ),
                                                                    styles={
                                                                        "input": {
                                                                            "backgroundColor": THEME.DARK_BG,
                                                                            "color": "white",
                                                                            "border": f"1px solid {THEME.DARK_BORDER}",
                                                                        }
                                                                    },
                                                                ),
                                                                dmc.TextInput(
                                                                    id="la-filter-node",
                                                                    placeholder="Node ID...",
                                                                    leftSection=DashIconify(
                                                                        icon="mdi:graph", width=16
                                                                    ),
                                                                    styles={
                                                                        "input": {
                                                                            "backgroundColor": THEME.DARK_BG,
                                                                            "color": "white",
                                                                            "border": f"1px solid {THEME.DARK_BORDER}",
                                                                        }
                                                                    },
                                                                ),
                                                                # v16.23 T2: Node Type Filter (entity category)
                                                                dcc.Dropdown(
                                                                    id="la-node-type-filter",
                                                                    placeholder="All Entity Types",
                                                                    options=[{"label": "All Types", "value": "ALL"}],
                                                                    value="ALL",
                                                                    clearable=False,
                                                                    style={
                                                                        "backgroundColor": "#0F172A",
                                                                        "color": "white",
                                                                        "border": f"1px solid {THEME.DARK_BORDER}",
                                                                        "borderRadius": "4px",
                                                                        "fontSize": "12px",
                                                                    },
                                                                ),
                                                                # v16.24: Internal / External filter
                                                                dcc.Dropdown(
                                                                    id="la-node-type1-filter",
                                                                    placeholder="All (Int/Ext)",
                                                                    options=[
                                                                        {"label": "All (Int/Ext)", "value": "ALL"},
                                                                        {"label": "Internal",      "value": "Internal"},
                                                                        {"label": "External",      "value": "External"},
                                                                    ],
                                                                    value="ALL",
                                                                    clearable=False,
                                                                    style={
                                                                        "backgroundColor": "#0F172A",
                                                                        "color": "white",
                                                                        "border": f"1px solid {THEME.DARK_BORDER}",
                                                                        "borderRadius": "4px",
                                                                        "fontSize": "12px",
                                                                    },
                                                                ),
                                                                dmc.Button(
                                                                    "Apply Filters",
                                                                    id="la-apply-filters",
                                                                    color="red",
                                                                    variant="light",
                                                                    leftSection=DashIconify(
                                                                        icon="mdi:filter-check",
                                                                        width=16,
                                                                    ),
                                                                ),
                                                            ],
                                                        ),
                                                    ]
                                                ),
                                            ],
                                            value="filters",
                                        ),
                                    ],
                                    variant="separated",
                                    radius="lg",
                                    mb="md",
                                    styles={
                                        "control": {"backgroundColor": "rgba(17,24,39,0.7)"},
                                        "panel": {"backgroundColor": "rgba(17,24,39,0.3)"},
                                        "item": {"borderColor": "rgba(255,255,255,0.06)"},
                                    },
                                ),
                                # ── EXPORT + RING CARDS ──
                                dmc.Group(
                                    [
                                        dmc.Text(
                                            "Detailed ring breakdowns — who is in each lobby and their flow:",
                                            size="xs",
                                            c="dimmed",
                                        ),
                                        dmc.Group(
                                            [
                                                dmc.Button(
                                                    "⬇ Export CSV",
                                                    id="la-export-csv",
                                                    size="xs",
                                                    variant="light",
                                                    color="cyan",
                                                    leftSection=DashIconify(
                                                        icon="mdi:download", width=14
                                                    ),
                                                ),
                                                dmc.Button(
                                                    "⬇ Export PNG",
                                                    id="la-export-png",
                                                    size="xs",
                                                    variant="light",
                                                    color="green",
                                                    leftSection=DashIconify(
                                                        icon="mdi:image-outline", width=14
                                                    ),
                                                ),
                                            ],
                                            gap="xs",
                                        ),
                                    ],
                                    justify="space-between",
                                    mb="sm",
                                ),
                                dcc.Download(id="la-download"),
                                html.Div(id="la-ring-cards"),
                            ],
                            style={"padding": "16px 0"},
                        ),
                    ],
                ),
                dcc.Tab(
                    label="🧮  Risk Matrix",
                    value="matrix",
                    style={
                        "color": "#94A3B8",
                        "backgroundColor": "rgba(17,24,39,0.8)",
                        "border": "1px solid rgba(255,255,255,0.06)",
                    },
                    selected_style={
                        "color": "#FF6B6B",
                        "backgroundColor": "rgba(17,24,39,0.95)",
                        "borderTop": "2px solid #FF6B6B",
                        "border": "1px solid rgba(255,107,107,0.25)",
                    },
                    children=[
                        html.Div(id="la-risk-matrix", style={"padding": "16px 0"}),
                    ],
                ),
                # ── v16.25 T2: Lobby Network Visualization ──────────────────────
                dcc.Tab(
                    label="🕸️  Lobby Network",
                    value="network",
                    style={
                        "color": "#94A3B8",
                        "backgroundColor": "rgba(17,24,39,0.8)",
                        "border": "1px solid rgba(255,255,255,0.06)",
                    },
                    selected_style={
                        "color": "#00D4FF",
                        "backgroundColor": "rgba(17,24,39,0.95)",
                        "borderTop": "2px solid #00D4FF",
                        "border": "1px solid rgba(0,212,255,0.25)",
                    },
                    children=[
                        html.Div(
                            [
                                # ── header ──────────────────────────────────
                                dmc.Group(
                                    [
                                        DashIconify(icon="mdi:graph-outline", width=20, color="#00D4FF"),
                                        dmc.Text("Lobby Network Visualizer", fw=700, c="white", size="sm"),
                                        dmc.Text(
                                            "Select a detected lobby ring to see who is in it and how members are transacting — "
                                            "circular patterns and hub-and-spoke flows indicate money laundering layering.",
                                            size="xs", c="dimmed",
                                            style={"lineHeight": "1.6"},
                                        ),
                                    ],
                                    gap="xs",
                                ),
                                dmc.Divider(color="rgba(255,255,255,0.08)", mt="xs", mb="xs"),
                                # ── ring selector ───────────────────────────
                                dmc.Select(
                                    id="la-lobby-net-select",
                                    data=[],
                                    value=None,
                                    searchable=True,
                                    placeholder="Run pipeline — then select a lobby ring to visualize…",
                                    leftSection=DashIconify(icon="mdi:circle-multiple-outline", width=16, color="#00D4FF"),
                                    label="Lobby Ring",
                                    description="Each ring is a detected cluster of potentially colluding accounts",
                                    styles={
                                        "input": {
                                            "background": "rgba(10,14,23,0.7)",
                                            "color": "#fff",
                                            "border": "1px solid rgba(255,255,255,0.1)",
                                        },
                                        "dropdown": {
                                            "background": "rgba(15,20,30,0.98)",
                                            "border": "1px solid rgba(255,255,255,0.1)",
                                        },
                                    },
                                    style={"maxWidth": "560px"},
                                ),
                                # ── tier legend ─────────────────────────────
                                dmc.Group(
                                    [
                                        dmc.Text("Risk Tier:", size="xs", c="dimmed"),
                                        dmc.Badge("● P1 Critical", color="red",    variant="dot", size="xs"),
                                        dmc.Badge("● P2 High",     color="orange", variant="dot", size="xs"),
                                        dmc.Badge("● P3 Medium",   color="yellow", variant="dot", size="xs"),
                                        dmc.Badge("● P4 Standard", color="green",  variant="dot", size="xs"),
                                        dmc.Badge("◆ Hub/Conduit", color="cyan",   variant="dot", size="xs"),
                                        dmc.Text("| Node size = risk severity | Arrow = transaction direction",
                                                 size="xs", c="dimmed"),
                                    ],
                                    gap="xs",
                                    mt="xs",
                                ),
                                # ── 80% graph left | 20% details right ────────
                                dmc.Grid(
                                    [
                                        dmc.GridCol(
                                            html.Div(
                                                id="la-lobby-net-cyto",
                                                style={"minHeight": "100px"},
                                            ),
                                            span=10,
                                        ),
                                        dmc.GridCol(
                                            dmc.Stack(
                                                [
                                                    html.Div(id="la-lobby-ring-info"),
                                                    html.Div(id="la-lobby-net-node-info"),
                                                ],
                                                gap="sm",
                                            ),
                                            span=2,
                                        ),
                                    ],
                                    gutter="sm",
                                    mt="sm",
                                ),
                            ],
                            style={"padding": "16px 0"},
                        ),
                    ],
                ),
            ],
            value="action",
            style={"marginTop": "8px"},
            colors={
                "border": "rgba(255,255,255,0.08)",
                "primary": "#FF6B6B",
                "background": "rgba(10,14,23,0.7)",
            },
        ),
    ]
)


# ═══════════════════════════════════════════════════════════════════════════════
# CALLBACKS — V12.17 pipeline logic preserved, now with customer names
# ═══════════════════════════════════════════════════════════════════════════════


@callback(
    Output("la-summary-stats", "children"),
    Output("la-ring-graph", "children"),
    Output("la-ring-cards", "children"),
    Output("la-action-table", "children"),  # v15.17: action brief tab
    Output("la-risk-matrix", "children"),  # v15.18 TASK2: risk matrix tab
    Input("la-init", "n_intervals"),
    Input("pipeline-state", "data"),
    Input("global-refresh-ts", "data"),  # v14.7 FIX-GAP4: sync on Global Refresh
    Input("la-apply-filters", "n_clicks"),
    Input("la-refresh-btn", "n_clicks"),
    State("la-filter-custid", "value"),
    State("la-filter-ring", "value"),
    State("la-filter-node", "value"),
    State("la-node-type-filter",  "value"),
    State("la-node-type1-filter", "value"),   # v16.24: Internal/External
)
def update_lobby(_, pipeline_state, _grt, __, ___, filter_cust, filter_ring, filter_node, filter_node_type, filter_node_type1):
    try:
        return _update_lobby_inner(pipeline_state, filter_cust, filter_ring, filter_node, filter_node_type, filter_node_type1)
    except Exception as exc:  # noqa: BLE001
        import traceback

        err_msg = traceback.format_exc()
        err_ui = dmc.Alert(
            dmc.Stack(
                [
                    dmc.Text("Lobby Analysis — Render Error", fw=700, c="#FF6B6B"),
                    dmc.Text(str(exc), size="xs", c="dimmed"),
                    dmc.Code(err_msg[:600], block=True),
                ],
                gap="xs",
            ),
            color="red",
            variant="light",
            title="⚠ Could not load lobby data",
        )
        return err_ui, err_ui, err_ui, err_ui, err_ui


def _update_lobby_inner(pipeline_state, filter_cust, filter_ring, filter_node, filter_node_type=None, filter_node_type1=None):
    pipeline = get_pipeline()

    # v12.17 Task7: bypass is_running race
    pipeline_done = isinstance(pipeline_state, dict) and pipeline_state.get("success", False)

    if pipeline.is_running() and not pipeline_done:
        running_msg = dmc.Center(
            dmc.Stack(
                [
                    dmc.Loader(color="red", size="sm"),
                    dmc.Text(
                        "Pipeline is running... Data will refresh automatically.",
                        c="dimmed",
                        size="sm",
                    ),
                ],
                align="center",
                gap="xs",
            ),
            style={"minHeight": "80px"},
        )
        return running_msg, running_msg, running_msg, running_msg, running_msg

    if not pipeline.has_data():
        return _default_content()

    # Build name lookup map once
    nm = _build_name_map(pipeline)
    _run_ver = pipeline_state.get("run_version", "") if isinstance(pipeline_state, dict) else ""

    # ── DETECT LOBBIES ── v15.15: max_rings=200 (was 30 — caused always-30 bug)
    lobbies = pipeline.detect_lobbies(max_rings=200)
    # Practical AML filter: only rings with 3+ members are meaningful lobbies
    # (2-node pairs are directional pairs, not organised groups)
    lobbies = [r for r in lobbies if _safe_int(r.get("size", len(r.get("nodes", r.get("members", []))))) >= 3]
    # Apply filters
    if filter_ring:
        lobbies = [r for r in lobbies if r["ring_id"] == filter_ring]
    if filter_cust:
        lobbies = [
            r
            for r in lobbies
            if any(
                filter_cust.lower() in n.lower() or filter_cust.lower() in _dn(nm, n).lower()
                for n in r.get("nodes", r.get("members", []))
            )
        ]
    if filter_node:
        lobbies = [r for r in lobbies if filter_node in r.get("nodes", r.get("members", []))]

    # v16.23 T2: filter by node_type — keep lobbies with at least one matching member
    if filter_node_type and filter_node_type != "ALL":
        _nt_set: set = set()
        for _nt_tbl in ("node", "customer"):
            _nt_df = pipeline.tables.get(_nt_tbl) if hasattr(pipeline, "tables") else None
            if _nt_df is not None and "node_type" in _nt_df.columns:
                _nt_id = "node_id" if "node_id" in _nt_df.columns else "customer_id"
                if _nt_id in _nt_df.columns:
                    _nt_set = set(
                        _nt_df[_nt_df["node_type"] == filter_node_type][_nt_id].astype(str)
                    )
                break
        if _nt_set:
            lobbies = [
                r for r in lobbies
                if any(str(m) in _nt_set for m in r.get("nodes", r.get("members", [])))
            ]

    # v16.24: filter by node_type1 (Internal/External)
    if filter_node_type1 and filter_node_type1 != "ALL":
        _nt1_set: set = set()
        for _nt1_tbl in ("node", "customer"):
            _nt1_df = pipeline.tables.get(_nt1_tbl) if hasattr(pipeline, "tables") else None
            if _nt1_df is not None and "node_type1" in _nt1_df.columns:
                _nt1_id = "node_id" if "node_id" in _nt1_df.columns else "customer_id"
                if _nt1_id in _nt1_df.columns:
                    _nt1_set = set(
                        _nt1_df[_nt1_df["node_type1"] == filter_node_type1][_nt1_id].astype(str)
                    )
                break
        if _nt1_set:
            lobbies = [
                r for r in lobbies
                if any(str(m) in _nt1_set for m in r.get("nodes", r.get("members", [])))
            ]

    # v15.18 TASK1: Sort by avg_risk descending — highest risk first inside each tier
    lobbies = sorted(lobbies, key=lambda r: _safe_float(r.get("avg_risk")), reverse=True)

    # ── SUMMARY STATS ──
    total_lobbies = len(lobbies)
    total_members = sum(r.get("size", 0) for r in lobbies)
    total_flow = sum(r.get("total_flow", 0) or r.get("total_amount", 0) or 0 for r in lobbies)
    max_risk = max((r.get("avg_risk", 0) for r in lobbies), default=0)
    # v16.56 BUG-FIX #5: weighted avg by ring size (not unweighted avg-of-avgs)
    avg_risk_all = (sum(r.get("avg_risk", 0) * r.get("size", 1) for r in lobbies) / max(total_members, 1)) if total_lobbies else 0
    avg_ring_size = (total_members / total_lobbies) if total_lobbies else 0
    max_ring_size = max((r.get("size", 0) for r in lobbies), default=0)
    G = pipeline.G  # v14.7: graph for member tier resolution

    # v14.7 FIX-GAP3: Worst ring tier = worst-member tier across all rings
    _SEVER = {"P1": 4, "P2": 3, "P3": 2, "P4": 1}
    _all_ring_tiers = [_ring_max_tier(r, G) for r in lobbies]
    max_tier = max(_all_ring_tiers, key=lambda t: _SEVER.get(t, 0)) if _all_ring_tiers else "P4"
    p1_ring_count = sum(1 for t in _all_ring_tiers if t == "P1")
    p2_ring_count = sum(1 for t in _all_ring_tiers if t == "P2")

    # v16.36: Portfolio summary (business language executive banner)
    total_customers_in_graph = G.number_of_nodes() if G else 0
    _port = lobby_portfolio_summary(
        total_lobbies=total_lobbies,
        total_flow=total_flow,
        p1_count=p1_ring_count,
        p2_count=p2_ring_count,
        max_ring_size=max_ring_size,
        total_customers=total_customers_in_graph,
    )
    _port_colour_map = {"red": "#FF1744", "orange": "#FF9800", "yellow": "#FFD600",
                        "green": "#00E676", "gray": "#64748B"}
    _port_icon_map = {
        "red": "mdi:alert-octagram", "orange": "mdi:alert-circle",
        "yellow": "mdi:clipboard-list-outline", "green": "mdi:check-circle-outline",
        "gray": "mdi:information-outline",
    }
    _port_hex = _port_colour_map.get(_port["colour"], "#64748B")
    _executive_banner = dmc.Paper(
        dmc.Stack(
            [
                dmc.Group(
                    [
                        DashIconify(
                            icon=_port_icon_map.get(_port["colour"], "mdi:bank-alert"),
                            width=24, color=_port_hex,
                        ),
                        dmc.Text(_port["urgency"], fw=900, c=_port_hex, size="md"),
                    ],
                    gap="sm",
                ),
                dmc.Text(
                    _port["banner"],
                    size="sm", c="#CBD5E1", style={"lineHeight": "1.7"},
                ),
                dmc.Text(
                    "💡 Tip for Branch Managers: Focus on the Critical (red) and High-Risk (orange) groups first. "
                    "Each group card below shows exactly what happened, why it matters, and what to do.",
                    size="xs", c="dimmed", style={"fontStyle": "italic"},
                ),
            ],
            gap="sm",
        ),
        p="lg", radius="lg", mb="md",
        style={
            "background": f"linear-gradient(135deg, rgba({_hex_to_rgb(_port_hex)},0.06) 0%, rgba(10,14,23,0.95) 100%)",
            "border": f"1px solid rgba({_hex_to_rgb(_port_hex)},0.20)",
        },
    )

    # v16.36: Business-language KPI labels (manager-friendly)
    stat_items = [
        (
            "Suspicious Groups Found",
            str(total_lobbies),
            "mdi:target-account",
            "#FF6B6B",
            "Number of customer groups showing circular money movement patterns",
        ),
        (
            "Ring Participations",
            str(total_members),
            "mdi:account-multiple",
            "#00D4FF",
            "Total member-seats across all rings — one customer is counted once per ring they appear in. A single customer can sit inside 20+ rings simultaneously, so this number is always larger than unique individuals.",
        ),
        (
            "Total Suspicious Flow",
            f"${total_flow:,.0f}",
            "mdi:cash-multiple",
            "#00E676",
            "Combined dollar value circulating through all detected suspicious groups",
        ),
        (
            "Highest Risk Score",
            f"{max_risk:.0f}/100 ({max_tier})",
            "mdi:alert-decagram",
            TIER_COLORS.get(max_tier, "#FF1744"),
            "Peak analytical risk score across all detected rings — shows how strong the most significant pattern is on a 0–100 scale",
        ),
        (
            "Warrants Urgent Review",
            str(p1_ring_count),
            "mdi:alert-octagram",
            "#FF1744",
            "Groups rated highest-risk (P1) — analytical evidence is strongest here; internal deep-dive recommended before any external decisions",
        ),
        (
            "High-Risk — Analyst Priority",
            str(p2_ring_count),
            "mdi:alert-circle",
            "#FF9800",
            "Groups rated high-risk (P2) — assign to senior analyst for independent pattern review this week",
        ),
        (
            "Average Risk Across Groups",
            f"{avg_risk_all:.0f}/100",
            "mdi:gauge",
            "#FFD600",
            "Portfolio-wide average risk score for all detected suspicious groups",
        ),
        (
            "Largest Ring Size",
            f"{max_ring_size} members",
            "mdi:resize",
            "#9D4EDD",
            "The biggest single circular flow ring by number of participants",
        ),
    ]
    kpi_cards = []
    for label, value, icon, color, description in stat_items:
        badge = (
            dmc.Badge(
                f"LIVE — #{_run_ver}" if _run_ver else "LIVE DATA",
                color="green",
                variant="light",
                size="xs",
            )
            if pipeline_done
            else None
        )
        kpi_cards.append(
            dmc.Paper(
                dmc.Stack(
                    [
                        DashIconify(icon=icon, width=28, color=color),
                        dmc.Text(
                            value,
                            fw=700,
                            c="white",
                            style={"fontSize": "1.4rem", "lineHeight": "1"},
                        ),
                        dmc.Text(label, size="xs", c=color, fw=600),
                        dmc.Text(description, size="10px", c="dimmed",
                                 style={"lineHeight": "1.4", "textAlign": "center"}),
                    ]
                    + ([badge] if badge else []),
                    gap=4,
                    align="center",
                ),
                p="md",
                radius="lg",
                style={
                    "textAlign": "center",
                    "background": f"linear-gradient(180deg, rgba({_hex_to_rgb(color)},0.06) 0%, rgba(10,14,23,0.95) 100%)",
                    "border": f"1px solid rgba({_hex_to_rgb(color)},0.15)",
                },
            )
        )
    summary_stats = html.Div([
        _executive_banner,
        dmc.SimpleGrid(cols={"base": 2, "sm": 4, "lg": 8}, spacing="sm", children=kpi_cards),
    ])

    # ── RING COMPARISON & CARDS — v12.34 TASK2: grouped by risk tier, collapsible ──
    badge_lbl = f"LIVE DATA — Run #{_run_ver}" if _run_ver else "LIVE DATA"

    # Group rings by tier (shared for both sections)
    # v14.7 FIX-GAP3: use max member tier (percentile-consistent), not avg_risk thresholds
    _tier_groups: dict = {"P1": [], "P2": [], "P3": [], "P4": []}
    _tier_mcolors = {"P1": "red", "P2": "orange", "P3": "yellow", "P4": "green"}
    for _r in lobbies:
        _rt = _ring_max_tier(_r, G)  # G resolved above; worst-member tier
        _tier_groups[_rt].append(_r)

    # Most critical tier with rings (auto-expanded)
    _default_open = next((t for t in ("P1", "P2", "P3", "P4") if _tier_groups[t]), "P1")

    if lobbies:
        # ── RING COMPARISON — accordion per tier (compact progress bars) ──
        _cmp_items = []
        for _tier in ("P1", "P2", "P3", "P4"):
            _grp = _tier_groups[_tier]
            if not _grp:
                continue
            _lbl, _srng, _act = TIER_LABELS[_tier]
            _col = TIER_COLORS[_tier]
            _mc = _tier_mcolors[_tier]
            _g_flow = sum(
                _safe_float(_r.get("total_flow", 0) or _r.get("total_amount", 0)) for _r in _grp
            )
            _cmp_items.append(
                dmc.AccordionItem(
                    [
                        dmc.AccordionControl(
                            dmc.Group(
                                [
                                    html.Div(
                                        style={
                                            "width": "14px",
                                            "height": "14px",
                                            "borderRadius": "50%",
                                            "backgroundColor": _col,
                                            "flexShrink": "0",
                                        }
                                    ),
                                    dmc.Text(f"{_tier} — {_lbl}", fw=700, c=_col, size="sm"),
                                    dmc.Badge(
                                        f"{len(_grp)} ring{'s' if len(_grp) != 1 else ''}",
                                        color=_mc,
                                        variant="filled",
                                        size="xs",
                                    ),
                                    dmc.Badge(
                                        f"${_g_flow:,.0f} suspicious flow",
                                        color="gray",
                                        variant="light",
                                        size="xs",
                                    ),
                                    dmc.Text(f"Score {_srng}", size="xs", c="dimmed"),
                                ],
                                gap="xs",
                                wrap="wrap",
                            ),
                            style={
                                "borderLeft": f"4px solid {_col}",
                                "paddingLeft": "12px",
                                "background": f"linear-gradient(90deg, rgba({_hex_to_rgb(_col)},0.08) 0%, transparent 60%)",
                            },
                        ),
                        dmc.AccordionPanel(
                            [
                                _ring_risk_bars(_grp, nm=nm, badge_label=badge_lbl),
                            ]
                        ),
                    ],
                    value=_tier,
                ),
            )

        ring_comparison = dmc.Stack(
            [
                dmc.Group(
                    [
                        dmc.Text(
                            "Rings grouped by risk tier — click to expand or collapse each group",
                            size="xs",
                            c="dimmed",
                        ),
                        dmc.Badge(
                            "All tiers expanded by default",
                            color="blue",
                            variant="light",
                            size="xs",
                        ),
                    ],
                    justify="space-between",
                    wrap="wrap",
                    mb="xs",
                ),
                dmc.Accordion(
                    _cmp_items,
                    multiple=True,
                    value=[],  # v15.18 TASK1: all collapsed by default
                    variant="separated",
                    radius="lg",
                    styles={
                        "control": {"backgroundColor": "rgba(17,24,39,0.8)"},
                        "panel": {"backgroundColor": "rgba(10,14,23,0.5)"},
                        "item": {"borderColor": "rgba(255,255,255,0.06)", "marginBottom": "4px"},
                    },
                ),
            ],
            gap="xs",
        )

        # ── RING CARDS — collapsible per risk tier (v12.34 TASK2) ──
        _card_items = []
        for _tier in ("P1", "P2", "P3", "P4"):
            _grp = _tier_groups[_tier]
            if not _grp:
                continue
            _lbl, _srng, _act = TIER_LABELS[_tier]
            _col = TIER_COLORS[_tier]
            _mc = _tier_mcolors[_tier]
            _g_flow = sum(
                _safe_float(_r.get("total_flow", 0) or _r.get("total_amount", 0)) for _r in _grp
            )
            # v16.56 BUG-FIX #6: weighted avg by ring size within tier group
            _g_total_size = sum(_r.get("size", 1) for _r in _grp)
            _g_avg = sum(_safe_float(_r.get("avg_risk", 0)) * _r.get("size", 1) for _r in _grp) / max(_g_total_size, 1)
            _short_act = _act.split("—", 1)[0].strip() if "—" in _act else _act[:60]
            _card_items.append(
                dmc.AccordionItem(
                    [
                        dmc.AccordionControl(
                            dmc.Group(
                                [
                                    html.Div(
                                        style={
                                            "width": "16px",
                                            "height": "16px",
                                            "borderRadius": "50%",
                                            "backgroundColor": _col,
                                            "flexShrink": "0",
                                            "border": "2px solid rgba(255,255,255,0.3)",
                                        }
                                    ),
                                    dmc.Text(f"{_tier} — {_lbl}", fw=700, c=_col, size="sm"),
                                    dmc.Badge(
                                        f"{len(_grp)} ring{'s' if len(_grp) != 1 else ''}",
                                        color=_mc,
                                        variant="filled",
                                        size="xs",
                                    ),
                                    dmc.Badge(
                                        f"${_g_flow:,.0f} total suspicious flow",
                                        color="gray",
                                        variant="light",
                                        size="xs",
                                    ),
                                    dmc.Badge(
                                        f"Avg Risk {_g_avg:.0f}",
                                        color=_mc,
                                        variant="light",
                                        size="xs",
                                    ),
                                    dmc.Text(
                                        f" Score {_srng} — {_short_act}", size="xs", c="dimmed"
                                    ),
                                ],
                                gap="xs",
                                wrap="wrap",
                            ),
                            style={
                                "borderLeft": f"4px solid {_col}",
                                "paddingLeft": "12px",
                                "background": f"linear-gradient(90deg, rgba({_hex_to_rgb(_col)},0.08) 0%, transparent 60%)",
                            },
                        ),
                        dmc.AccordionPanel(
                            [
                                dmc.Paper(
                                    [
                                        dmc.Group(
                                            [
                                                DashIconify(
                                                    icon="mdi:information-outline",
                                                    width=14,
                                                    color=_col,
                                                ),
                                                dmc.Text(
                                                    f"Recommended action for {_tier} rings:",
                                                    fw=600,
                                                    c=_col,
                                                    size="xs",
                                                ),
                                                dmc.Text(
                                                    _act,
                                                    size="xs",
                                                    c="dimmed",
                                                    style={"maxWidth": "700px"},
                                                ),
                                            ],
                                            gap="sm",
                                            wrap="wrap",
                                        ),
                                    ],
                                    p="xs",
                                    radius="sm",
                                    mb="sm",
                                    style={
                                        "backgroundColor": f"rgba({_hex_to_rgb(_col)},0.06)",
                                        "border": f"1px solid rgba({_hex_to_rgb(_col)},0.2)",
                                    },
                                ),
                                dmc.Stack(
                                    [
                                        _ring_card(_r, nm, is_live=pipeline_done, run_ver=_run_ver)
                                        for _r in _grp
                                    ],
                                    gap="md",
                                ),
                            ]
                        ),
                    ],
                    value=_tier,
                ),
            )

        ring_cards = dmc.Stack(
            [
                dmc.Group(
                    [
                        dmc.Text(
                            f"{len(lobbies)} lobby ring{'s' if len(lobbies) != 1 else ''} grouped by risk priority — "
                            "click a tier header to expand or collapse that group",
                            size="xs",
                            c="dimmed",
                        ),
                        dmc.Badge(
                            "P1 & P2 auto-expanded (most critical)",
                            color="red",
                            variant="light",
                            size="xs",
                        ),
                    ],
                    justify="space-between",
                    wrap="wrap",
                    mb="xs",
                ),
                dmc.Accordion(
                    _card_items,
                    multiple=True,
                    value=[],  # v15.18 TASK1: all collapsed by default
                    variant="separated",
                    radius="lg",
                    styles={
                        "control": {"backgroundColor": "rgba(17,24,39,0.8)"},
                        "panel": {"backgroundColor": "rgba(10,14,23,0.5)"},
                        "item": {"borderColor": "rgba(255,255,255,0.06)", "marginBottom": "4px"},
                    },
                ),
            ],
            gap="xs",
        )

    else:
        _nodes_n = pipeline.G.number_of_nodes() if pipeline.G else 0
        ring_comparison = dmc.Center(
            dmc.Stack(
                [
                    DashIconify(icon="mdi:check-circle-outline", width=36, color="#00E676"),
                    dmc.Text(
                        "✓ Network Clean — No Lobby Rings Detected", fw=700, c="#00E676", size="md"
                    ),
                    dmc.Text(
                        f"We analysed {_nodes_n:,} customers and found no organized circular "
                        "money-movement patterns. No immediate action required from this analysis.",
                        size="xs",
                        c="dimmed",
                        style={"maxWidth": "420px", "textAlign": "center"},
                    ),
                ],
                align="center",
                gap="sm",
            ),
            style={"minHeight": "160px", "padding": "32px"},
        )
        _edges_n = pipeline.G.number_of_edges() if pipeline.G else 0
        ring_cards = dmc.Paper(
            [
                dmc.Group(
                    [
                        DashIconify(icon="mdi:check-circle", width=22, color="#00E676"),
                        dmc.Text(
                            "Network Clean — No organized lobby rings detected",
                            size="sm",
                            fw=600,
                            c="#00E676",
                        ),
                    ],
                    gap="sm",
                ),
                dmc.Text(
                    f"Good news: We analyzed {_nodes_n:,} customers and {_edges_n:,} transaction links — "
                    "no tightly connected lobby patterns were found. This means there are no obvious "
                    "organized groups coordinating circular money movements.",
                    size="xs",
                    c="dimmed",
                    mt="xs",
                ),
            ],
            p="sm",
            radius="md",
            style={"background": "rgba(0,230,118,0.05)", "border": "1px solid rgba(0,230,118,0.2)"},
        )

    return (
        summary_stats,
        ring_comparison,
        ring_cards,
        _build_action_table(lobbies, nm, pipeline.G, is_live=pipeline_done),
        _build_risk_matrix(lobbies, nm, pipeline.G, is_live=pipeline_done),
    )


@callback(
    Output("la-download", "data"),
    Input("la-export-csv", "n_clicks"),
    prevent_initial_call=True,
)
def export_csv(_):
    pipeline = get_pipeline()
    lobbies = pipeline.detect_lobbies(max_rings=200)
    if lobbies:
        lobbies = [r for r in lobbies if _safe_int(r.get("size", len(r.get("nodes", r.get("members", []))))) >= 3]
        nm = _build_name_map(pipeline)
        rows = []
        for r in lobbies:
            for m in r.get("members", r.get("nodes", [])):
                rows.append(
                    {
                        "Ring": r["ring_id"],
                        "Customer": _dn(nm, m),
                        "Customer_ID": m,
                        "Avg_Ring_Risk": r.get("avg_risk", 0),
                        "Total_Flow": r.get("total_flow", 0) or r.get("total_amount", 0) or 0,
                        "Initiator": _dn(nm, r.get("initiator", "")),
                        "Conduit": _dn(nm, r.get("conduit", "")),
                    }
                )
        df = pd.DataFrame(rows)
        return dcc.send_data_frame(df.to_csv, "lobby_analysis.csv", index=False)
    return no_update


@callback(
    Output("la-download", "data", allow_duplicate=True),
    Input("la-export-png", "n_clicks"),
    State("pipeline-state", "data"),
    prevent_initial_call=True,
)
def export_png_la(n_clicks, pipeline_state):
    """v12.28: PNG export — builds a quick Plotly figure from live pipeline data for kaleido."""
    if not n_clicks:
        return no_update
    try:
        import plotly.io as pio

        pipeline = get_pipeline()
        if not pipeline.has_data():
            return no_update
        lobbies = pipeline.detect_lobbies(max_rings=200)
        if not lobbies:
            return no_update
        lobbies = [r for r in lobbies if _safe_int(r.get("size", len(r.get("nodes", r.get("members", []))))) >= 3]
        if not lobbies:
            return no_update
        nm = _build_name_map(pipeline)
        ring_labels = [f"Ring #{r['ring_id']} — {_dn(nm, r.get('initiator', ''))}" for r in lobbies]
        colors = []
        for r in lobbies:
            avg_r = _safe_float(r.get("avg_risk"))
            colors.append(
                "#FF1744"
                if avg_r >= 80
                else "#FF9800" if avg_r >= 60 else "#FFD600" if avg_r >= 40 else "#00E676"
            )
        fig = go.Figure()
        fig.add_trace(
            go.Bar(
                x=ring_labels,
                y=[_safe_float(r.get("avg_risk")) for r in lobbies],
                marker_color=colors,
                text=[f"{_safe_float(r.get('avg_risk')):.0f}" for r in lobbies],
                textposition="outside",
            )
        )
        fig.update_layout(
            paper_bgcolor="rgba(17,24,39,1)",
            plot_bgcolor="rgba(10,14,23,1)",
            font=dict(color="#94A3B8"),
            height=500,
            title="Lobby Ring Risk Comparison",
            yaxis=dict(range=[0, 110]),
        )
        img_bytes = pio.to_image(fig, format="png", width=1200, height=500, scale=2)
        return dcc.send_bytes(img_bytes, "lobby_ring_analysis.png")
    except Exception:
        return no_update


@callback(
    Output("la-init", "max_intervals"),
    Input("pipeline-state", "data"),
)
def stop_la_polling(pipeline_state):
    """v12.22 DESIGN-01 FIX: Stop polling once pipeline completes."""
    if isinstance(pipeline_state, dict) and pipeline_state.get("success", False):
        return 0
    return -1


# ── v16.24: Populate node-type & node-type1 filter options ───────────────────
@callback(
    Output("la-node-type-filter",  "options"),
    Output("la-node-type1-filter", "options"),
    Input("pipeline-state", "data"),
    Input("global-refresh-ts", "data"),
)
def update_la_node_type_options(_ps, _gr):
    """Populate entity-type and Int/Ext dropdowns from live pipeline data."""
    try:
        from utils.node_colormap import node_type_filter_options, node_type1_filter_options
        from engine import get_pipeline
        pipeline = get_pipeline()
        return node_type_filter_options(pipeline), node_type1_filter_options(pipeline)
    except Exception:
        default2 = [
            {"label": "All (Int/Ext)", "value": "ALL"},
            {"label": "Internal",      "value": "Internal"},
            {"label": "External",      "value": "External"},
        ]
        return [{"label": "All Types", "value": "ALL"}], default2


# ── v16.25 T2: Lobby Network — populate ring selector ────────────────────────
@callback(
    Output("la-lobby-net-select", "data"),
    Output("la-lobby-net-select", "value"),
    Input("pipeline-state", "data"),
    Input("global-refresh-ts", "data"),
)
def update_lobby_net_options(_ps, _gr):
    """Populate the lobby-ring dropdown from live detected lobbies."""
    try:
        pipeline = get_pipeline()
        if not pipeline.has_data():
            return [], None
        lobbies = pipeline.detect_lobbies(max_rings=200)
        if not lobbies:
            return [], None
        lobbies = [r for r in lobbies if _safe_int(r.get("size", len(r.get("nodes", r.get("members", []))))) >= 3]
        if not lobbies:
            return [{"label": "No lobbies detected", "value": "__none__"}], "__none__"
        options = [
            {
                "value": str(r["ring_id"]),
                "label": (
                    f"Ring #{r['ring_id']} — {r['size']} members | "
                    f"Avg Risk {_safe_float(r.get('avg_risk', 0)):.1f} | "
                    f"${_safe_float(r.get('total_flow', 0) or r.get('total_amount', 0)):,.0f} flow"
                ),
            }
            for r in lobbies
        ]
        return options, str(lobbies[0]["ring_id"])
    except Exception:
        return [], None


# ── v16.25 T2: Lobby Network — render Cytoscape for selected ring ─────────────
@callback(
    Output("la-lobby-net-cyto", "children"),
    Input("la-lobby-net-select", "value"),
    State("pipeline-state", "data"),
)
def render_lobby_network(ring_id, pipeline_state):
    """Render the Cytoscape graph for the selected lobby ring."""
    _no_data = dmc.Center(
        dmc.Stack(
            [
                DashIconify(icon="mdi:graph-outline", width=40, color="#334155"),
                dmc.Text("Select a lobby ring above to visualize its network", c="dimmed", size="sm"),
            ],
            align="center", gap="xs",
        ),
        style={"minHeight": "200px"},
    )
    if not ring_id or ring_id == "__none__":
        return _no_data
    try:
        pipeline = get_pipeline()
        if not pipeline.has_data():
            return _no_data
        lobbies = pipeline.detect_lobbies(max_rings=200)
        lobbies = [r for r in lobbies if _safe_int(r.get("size", len(r.get("nodes", r.get("members", []))))) >= 3]
        ring = next((r for r in lobbies if str(r["ring_id"]) == str(ring_id)), None)
        if ring is None:
            return _no_data
        nm    = _build_name_map(pipeline)
        G     = pipeline.G
        elems = _lobby_to_cytoscape(ring, nm, G)
        n_nodes = sum(1 for e in elems if "source" not in e.get("data", {}))
        n_edges = len(elems) - n_nodes
        # pick layout: circle for small rings (≤8), cose for larger
        layout_name = "circle" if n_nodes <= 8 else "cose"
        cyto_layout = (
            {"name": "circle", "padding": 40, "fit": True}
            if layout_name == "circle"
            else {"name": "cose", "idealEdgeLength": 90, "nodeOverlap": 20,
                  "refresh": 20, "fit": True, "padding": 40, "randomize": False,
                  "componentSpacing": 80}
        )
        size_note = dmc.Text(
            f"Ring #{ring_id} — {n_nodes} members, {n_edges} transaction links | "
            "Click any node for details",
            size="xs", c="dimmed", style={"marginBottom": "6px"},
        )
        return html.Div([
            size_note,
            cyto.Cytoscape(
                id="la-cytoscape-graph",
                elements=elems,
                layout=cyto_layout,
                stylesheet=_CYT_STYLESHEET_LOBBY,
                style={
                    "width": "100%",
                    "height": "480px",
                    "background": "rgba(10,14,23,0.75)",
                    "borderRadius": "12px",
                    "border": "1px solid rgba(255,255,255,0.08)",
                },
                responsive=True,
                minZoom=0.3,
                maxZoom=3.0,
            ),
        ])
    except Exception as exc:
        return dmc.Alert(str(exc), color="red", variant="light", title="Network render error")


# ── v16.69: Lobby Network — ring detail panel (right side) ───────────────────
@callback(
    Output("la-lobby-ring-info", "children"),
    Input("la-lobby-net-select", "value"),
    State("pipeline-state", "data"),
    prevent_initial_call=False,
)
def render_ring_detail_panel(ring_id, _ps):
    """Show condensed ring metrics in right-side panel as soon as a ring is selected."""
    if not ring_id or ring_id == "__none__":
        return dmc.Stack(
            [
                DashIconify(icon="mdi:circle-multiple-outline", width=28, color="#334155"),
                dmc.Text("Select a ring", c="dimmed", size="xs", ta="center"),
            ],
            align="center",
            pt="lg",
        )
    try:
        pipeline = get_pipeline()
        if not pipeline.has_data():
            return dmc.Text("No data", c="dimmed", size="xs")
        lobbies = pipeline.detect_lobbies(max_rings=200)
        lobbies = [
            r for r in lobbies
            if _safe_int(r.get("size", len(r.get("nodes", r.get("members", []))))) >= 3
        ]
        ring = next((r for r in lobbies if str(r["ring_id"]) == str(ring_id)), None)
        if ring is None:
            return dmc.Text("Ring not found", c="dimmed", size="xs")
        nm = _build_name_map(pipeline)
        _G = pipeline.G
        tier = _ring_max_tier(ring, _G)
        tier_color = TIER_COLORS.get(tier, "#64748B")
        tier_badge_color = {"P1": "red", "P2": "orange", "P3": "yellow", "P4": "green"}.get(tier, "gray")
        members_raw = ring.get("nodes", ring.get("members", []))
        member_ids = [m["node_id"] if isinstance(m, dict) else str(m) for m in members_raw]
        total_flow = _safe_float(ring.get("total_flow") or ring.get("total_amount") or 0)
        avg_risk = _safe_float(ring.get("avg_risk", 0))
        initiator = _dn(nm, ring.get("initiator", "—"))
        pattern = ring.get("pattern", ring.get("type", "Circular"))
        member_rows = []
        for mid in member_ids[:12]:
            m_attrs = dict(_G.nodes[mid]) if (_G and mid in _G.nodes) else {}
            m_tier = m_attrs.get("risk_tier", "P4") or "P4"
            m_color = {"P1": "red", "P2": "orange", "P3": "yellow", "P4": "green"}.get(m_tier, "gray")
            member_rows.append(
                dmc.Group(
                    [
                        dmc.Text(
                            _dn(nm, mid), size="xs", c="white", truncate="end",
                            style={"flex": "1", "minWidth": 0, "overflow": "hidden"},
                        ),
                        dmc.Badge(m_tier, size="xs", color=m_color, variant="dot"),
                    ],
                    gap=4,
                    style={
                        "borderBottom": "1px solid rgba(255,255,255,0.05)",
                        "paddingBottom": "3px",
                        "paddingTop": "3px",
                    },
                )
            )
        if len(member_ids) > 12:
            member_rows.append(dmc.Text(f"+{len(member_ids) - 12} more", size="xs", c="dimmed"))
        return dmc.Paper(
            dmc.Stack(
                [
                    dmc.Group(
                        [
                            dmc.Badge(tier, color=tier_badge_color, variant="filled", size="sm"),
                            dmc.Text(f"Ring #{ring_id}", fw=700, c="white", size="sm"),
                        ],
                        gap="xs",
                    ),
                    dmc.Divider(color="rgba(255,255,255,0.08)"),
                    dmc.SimpleGrid(
                        cols=2,
                        spacing=4,
                        children=[
                            dmc.Stack([dmc.Text("Members", size="xs", c="dimmed"), dmc.Text(str(ring.get("size", len(member_ids))), fw=700, c="#00D4FF", size="sm")], gap=1),
                            dmc.Stack([dmc.Text("Avg Risk", size="xs", c="dimmed"), dmc.Text(f"{avg_risk:.0f}", fw=700, c=tier_color, size="sm")], gap=1),
                            dmc.Stack([dmc.Text("Flow", size="xs", c="dimmed"), dmc.Text(f"${total_flow:,.0f}", fw=600, c="#FFD600", size="xs")], gap=1),
                            dmc.Stack([dmc.Text("Pattern", size="xs", c="dimmed"), dmc.Text(str(pattern)[:12], fw=600, c="#CBD5E1", size="xs")], gap=1),
                        ],
                    ),
                    dmc.Stack(
                        [
                            dmc.Text("Hub Account", size="xs", c="dimmed"),
                            dmc.Text(initiator, fw=600, c="#00E676", size="xs", truncate="end"),
                        ],
                        gap=1,
                    ),
                    dmc.Divider(color="rgba(255,255,255,0.08)"),
                    dmc.Text("Members", size="xs", c="dimmed", fw=600),
                    dmc.Stack(member_rows, gap=0),
                ],
                gap="xs",
            ),
            p="sm",
            radius="md",
            className="glass-card",
            style={"borderLeft": f"3px solid {tier_color}"},
        )
    except Exception as exc:
        return dmc.Text(str(exc)[:60], c="red", size="xs")


# ── v16.25 T2 / v16.69: Lobby Network — node click + hover detail panel ──────
@callback(
    Output("la-lobby-net-node-info", "children"),
    Input("la-cytoscape-graph", "tapNodeData"),
    Input("la-cytoscape-graph", "mouseoverNodeData"),
    prevent_initial_call=True,
)
def show_lobby_node_info(tap_data, hover_data):
    """Show a detail card when the user clicks or hovers a node in the lobby network."""
    triggered = ctx.triggered[0]["prop_id"] if ctx.triggered else ""
    data = tap_data if ("tapNodeData" in triggered and tap_data) else hover_data
    if not data:
        return no_update
    tier   = data.get("tier", "P4")
    color  = {"P1": "red", "P2": "orange", "P3": "yellow", "P4": "green"}.get(tier, "gray")
    tier_clr = {"P1": "#FF1744", "P2": "#FF9800", "P3": "#F9A825", "P4": "#00C853"}.get(tier, "#607D8B")
    return dmc.Paper(
        dmc.Stack(
            [
                dmc.Group(
                    [
                        DashIconify(icon="mdi:account-circle-outline", width=32, color=tier_clr),
                        dmc.Stack(
                            [
                                dmc.Group([
                                    dmc.Text(data.get("label", data.get("id", "")), fw=700, c="white", size="sm"),
                                    dmc.Badge(tier, color=color, variant="light", size="xs"),
                                    *(  [dmc.Badge("Hub / Conduit", color="cyan", variant="dot", size="xs")]
                                        if data.get("is_hub") == "Yes" else []),
                                ], gap="xs"),
                                dmc.Text(f"Risk Score: {data.get('risk_score', 'N/A')}", size="xs", c="dimmed"),
                            ],
                            gap=2,
                        ),
                    ],
                    gap="md",
                ),
                dmc.Divider(color="rgba(255,255,255,0.07)"),
                dmc.SimpleGrid(
                    cols=3,
                    spacing="xs",
                    children=[
                        dmc.Stack(
                            [
                                dmc.Text("Node Type 1", size="xs", c="dimmed", fw=600),
                                dmc.Text("Account Class", size="xs", c="rgba(255,255,255,0.4)"),
                                dmc.Text(
                                    data.get("node_type1") or data.get("node_type") or "Individual",
                                    size="sm", c="white", fw=500,
                                ),
                            ],
                            gap=2,
                        ),
                        dmc.Stack(
                            [
                                dmc.Text("Node Type 2", size="xs", c="dimmed", fw=600),
                                dmc.Text("Banking Segment", size="xs", c="rgba(255,255,255,0.4)"),
                                dmc.Text(
                                    data.get("node_type2") or "—",
                                    size="sm", c="white", fw=500,
                                ),
                            ],
                            gap=2,
                        ),
                        dmc.Stack(
                            [
                                dmc.Text("Node Type 3", size="xs", c="dimmed", fw=600),
                                dmc.Text("Industry / Role", size="xs", c="rgba(255,255,255,0.4)"),
                                dmc.Text(
                                    data.get("node_type3") or "—",
                                    size="sm", c="white", fw=500,
                                ),
                            ],
                            gap=2,
                        ),
                    ],
                ),
                dmc.Divider(color="rgba(255,255,255,0.07)"),
                dmc.Group(
                    [
                        dmc.Stack(
                            [
                                dmc.Text("Money In", size="xs", c="dimmed"),
                                dmc.Text(data.get("in_flow", "N/A"), size="sm", c="#00E676", fw=600),
                            ],
                            gap=1,
                        ),
                        dmc.Stack(
                            [
                                dmc.Text("Money Out", size="xs", c="dimmed"),
                                dmc.Text(data.get("out_flow", "N/A"), size="sm", c="#FF6B6B", fw=600),
                            ],
                            gap=1,
                        ),
                    ],
                    gap="xl",
                ),
            ],
            gap="xs",
        ),
        p="sm",
        radius="md",
        withBorder=True,
        style={"background": "rgba(10,14,23,0.9)", "border": f"1px solid rgba({_hex_to_rgb(tier_clr)},0.4)"},
    )
