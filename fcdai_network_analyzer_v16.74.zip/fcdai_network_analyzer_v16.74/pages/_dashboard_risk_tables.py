"""
pages/_dashboard_risk_tables.py
v16.53 — Pipeline Risk Analysis: Four AG Grid Tables

Four tables built dynamically from pipeline.scored_df + pipeline.analytics_results.
Families are discovered at runtime from score_{family} columns — no hard-coding.

Table 1 — Risk by Detection Family (Count)
    Rows  : one per active detection family
    Cols  : Family | # Algorithms | Total Records | P1 | P2 | P3 | P4 (customer counts)

Table 2 — Risk by Detection Family (Avg Score)
    Rows  : one per active detection family
    Cols  : Family | # Algorithms | Total Records | P1 Avg | P2 Avg | P3 Avg | P4 Avg (0-100)

Table 3 — Top Flagged Customers (family scores)
    Rows  : top-N customers sorted by overall risk score DESC
    Cols  : Customer ID | Name | Type | Tier | Overall Score | score_family1 | score_family2 | ...

Table 4 — Top Flagged Customers (anomaly flags)
    Rows  : top-N customers sorted by overall risk score DESC
    Cols  : Customer ID | Name | Type | Risk Group | Overall Score | Engines Flagged | flag_family1 | ...

All tables auto-refresh on every pipeline run via the dashboard's `pipeline-state` store.
No external HTTP calls — data sourced directly from the in-memory pipeline singleton.
"""
from __future__ import annotations

import pandas as pd
import numpy as np                          # noqa: F401 — kept for future numeric ops
from dash import html
import dash_ag_grid as dag
import dash_mantine_components as dmc
from dash_iconify import DashIconify

# ── Constants ─────────────────────────────────────────────────────────────────

#: Score above this threshold (0–1 scale) → customer "active" in a family.
#   Used to decide whether the family produced a meaningful signal for that node.
_ACTIVE_THRESHOLD: float = 0.05   # 5 %

#: Score above this threshold → family anomaly flag = 1 in Table 4.
_ANOMALY_THRESHOLD: float = 0.10  # 10 %

#: Max customers shown in Tables 3 and 4.
_TOP_N: int = 50

#: AG Grid CSS class — matches existing dashboard theme.
_GRID_CLASS: str = "ag-theme-fcdai"

#: Ordered list of 10 standard families (mirrors FAMILY_DISPLAY_NAMES in l5_analytics).
#: (display_name, mdi_icon, hex_colour)
_FAMILY_META: dict[str, tuple[str, str, str]] = {
    "centrality":      ("Network Influence Hub",          "mdi:hub-outline",       "#00D4FF"),
    "community":       ("Topological Cluster Engine",     "mdi:graph",             "#9D4EDD"),
    "pathflow":        ("Laundering Traceability",        "mdi:routes",            "#00E676"),
    "link_prediction": ("Hidden Association Predictor",   "mdi:link-variant",      "#FFD600"),
    "anomaly":         ("Topological Outlier Detector",   "mdi:alert-decagram",    "#FF1744"),
    "temporal":        ("Dynamic Velocity Analyzer",      "mdi:clock-fast",        "#FF9800"),
    "multi_layer":     ("Multi-Layer Risk Module",        "mdi:layers-triple",     "#2196F3"),
    "structuring":     ("Structuring Split Detector",     "mdi:cash-multiple",     "#FF1744"),
    "benfords":        ("Benford's Law Analyzer",         "mdi:chart-bell-curve",  "#E040FB"),
    "motifs":          ("Network Motif Scanner",          "mdi:shape-outline",     "#00BCD4"),
}

#: Minimum algorithm counts per family (fallback when analytics_results absent).
_ALGO_COUNT_MIN: dict[str, int] = {
    "centrality": 5, "community": 3, "pathflow": 4, "link_prediction": 3,
    "anomaly": 4, "temporal": 5, "multi_layer": 3, "structuring": 4,
    "benfords": 3, "motifs": 3,
}

_TIER_ORDER = ["P1", "P2", "P3", "P4"]
_TIER_LABELS = {
    "P1": "P1 – Critical",
    "P2": "P2 – High",
    "P3": "P3 – Medium",
    "P4": "P4 – Standard",
}
_TIER_COLORS = {"P1": "#FF1744", "P2": "#FF9800", "P3": "#FFD600", "P4": "#4CAF50"}

#: Business-friendly description of what each detection family is looking for.
#: Used as the "What It Detects" column in Table 1.
_FAMILY_DETECTS: dict[str, str] = {
    "centrality":      "Customers who act as high-volume hubs or brokers in the transaction network — unusual connectivity suggests a coordinating role in money flows",
    "community":       "Clusters of accounts that transact predominantly with each other, forming isolated groups that may represent criminal communities or coordinated fraud rings",
    "pathflow":        "Suspicious money-movement paths — funds that travel through multiple intermediaries in patterns consistent with layering or placement of illicit proceeds",
    "link_prediction": "Hidden or undisclosed financial relationships between customers predicted by their network neighbourhood — potential undeclared beneficial ownership",
    "anomaly":         "Statistically abnormal transaction behaviour versus peer group — outliers in volume, frequency or counterparty diversity that deviate from expected norms",
    "temporal":        "Unusual timing patterns: velocity spikes, after-hours bursts or regular timed sequences that mimic structured relay or payment-ring behaviour",
    "multi_layer":     "Risk exposure that spans multiple relationship types — customers who appear risky across both the financial transaction layer and the corporate ownership layer",
    "structuring":     "Sub-threshold cash splitting: repeated transactions just below reporting thresholds (Regulation 10A/CTR) to avoid currency transaction reports",
    "benfords":        "Statistical digit-frequency irregularity in transaction amounts — deviations from Benford's Law signal artificially generated or manipulated figures",
    "motifs":          "Recognised AML transaction patterns: fan-in/fan-out structures, cyclic triangles, and relay chains that match known money-laundering typologies",
}

_EMPTY_STYLE: dict = {
    "minHeight": "60px", "display": "flex",
    "alignItems": "center", "justifyContent": "center",
    "padding": "16px",
}

# v16.65: Per-family score thresholds for Table 1.
# Using ABSOLUTE thresholds (not percentile) on the 0–1 normalised family score
# so each detection engine shows its OWN distribution — not the composite tier.
# This reveals genuine differences: Network Hub may have 5 critical signals,
# Benford's Law 0 critical but 20 moderate, etc.
_FAMILY_TIER_THRESHOLDS = {
    "P1": 0.65,   # Critical: strong engine signal  ≥ 65 / 100
    "P2": 0.40,   # High    : elevated engine signal  40–65
    "P3": 0.12,   # Medium  : moderate engine signal  12–40
    # P4          : Active  : low signal               2–12
    # No Signal   : not flagged                        < 2%
    "ACTIVE": 0.02,
}

# ── Private helpers ────────────────────────────────────────────────────────────

def _family_keys(scored_df: pd.DataFrame) -> list[str]:
    """Return ordered list of family keys present in scored_df as score_* columns."""
    present = {c[6:] for c in scored_df.columns if c.startswith("score_")}
    ordered = [f for f in _FAMILY_META if f in present]
    extras  = sorted(f for f in present if f not in _FAMILY_META)
    return ordered + extras


def _get_col(df: pd.DataFrame, candidates: list[str]) -> str | None:
    """Return first matching column name from candidates list."""
    return next((c for c in candidates if c in df.columns), None)


def _id_col(df: pd.DataFrame) -> str | None:
    return _get_col(df, ["node_id", "customer_id", "id", "entity_id"])


def _name_col(df: pd.DataFrame) -> str | None:
    return _get_col(df, ["name", "customer_name", "full_name", "cust_name"])


def _type_col(df: pd.DataFrame) -> str | None:
    return _get_col(df, ["node_type", "type", "customer_type", "entity_type"])


def _tier_col(df: pd.DataFrame) -> str | None:
    return next(
        (c for c in df.columns if "tier" in c.lower() and "change" not in c.lower()),
        None,
    )


def _score_col(df: pd.DataFrame) -> str | None:
    return _get_col(df, ["risk_score", "composite_score", "score", "overall_score"])


def _algo_count(family_key: str, analytics_results: dict) -> int:
    """Count numeric signal columns in family analytics DataFrame as #algorithms.
    Falls back to hardcoded minimum if results unavailable."""
    df = (analytics_results or {}).get(family_key)
    if df is None or len(df) == 0:
        return _ALGO_COUNT_MIN.get(family_key, 3)
    id_cols = {"node_id", "customer_id", "id", "entity_id"}
    numeric_types = {float, int, "float32", "float64", "int32", "int64"}
    count = sum(
        1
        for c in df.columns
        if c not in id_cols and df[c].dtype in numeric_types or pd.api.types.is_numeric_dtype(df[c])
    )
    return max(1, count - len(id_cols))  # subtract any id-like columns that slipped through


def _enrich_scored(scored_df: pd.DataFrame, pipeline) -> pd.DataFrame:
    """Attempt to join name / type from pipeline.tables onto scored_df.
    Returns enriched copy; never raises on failure."""
    sdf = scored_df.copy()
    if _name_col(sdf) and _type_col(sdf):
        return sdf  # already enriched
    try:
        tables = getattr(pipeline, "tables", None) or {}
        node_tbl = next(
            (tables[k] for k in ("node", "customer", "account", "node_features")
             if tables.get(k) is not None and len(tables[k]) > 0),
            None,
        )
        if node_tbl is None:
            return sdf

        sdf_id = _id_col(sdf)
        tbl_id = _id_col(node_tbl)
        if sdf_id is None or tbl_id is None:
            return sdf

        rename_map: dict[str, str] = {tbl_id: sdf_id}
        select_cols = [tbl_id]

        if not _name_col(sdf):
            nc = _name_col(node_tbl)
            if nc:
                rename_map[nc] = "name"
                select_cols.append(nc)

        if not _type_col(sdf):
            tc = _type_col(node_tbl)
            if tc:
                rename_map[tc] = "type"
                select_cols.append(tc)

        if len(select_cols) <= 1:
            return sdf  # nothing new to add

        subset = (
            node_tbl[select_cols]
            .rename(columns=rename_map)
            .drop_duplicates(subset=[sdf_id])
        )
        sdf = sdf.merge(subset, on=sdf_id, how="left")
    except Exception:
        pass
    return sdf


def _safe_str(series_val) -> str:
    """Convert a pandas Series element to string safely."""
    if series_val is None or (isinstance(series_val, float) and pd.isna(series_val)):
        return "—"
    return str(series_val)


def _safe_float(series_val, default: float = 0.0) -> float:
    """Convert a pandas Series element to float safely."""
    try:
        v = float(series_val)
        return v if np.isfinite(v) else default
    except (TypeError, ValueError):
        return default


def _per_family_tier(sc_series: pd.Series) -> pd.Series:
    """v16.71 H2: Assign P1/P2/P3/P4 tier using per-engine PERCENTILE thresholds.

    Percentile-based approach ensures fair comparison across detection engines
    with very different score distributions (sparse Benford vs dense Network Hub).
    Among active customers (score > 0):
      P1 — top 1%  (≥ 99th percentile of active)   Critical
      P2 — top 5%  (≥ 95th percentile of active)   High
      P3 — top 20% (≥ 80th percentile of active)   Medium
      P4 — any active score > 0                     Active
      No Signal — score == 0 or NaN

    If fewer than 5 active customers, falls back to absolute thresholds.
    """
    tiers = pd.Series("No Signal", index=sc_series.index, dtype=object)
    active_mask = sc_series.fillna(0) > 0
    non_zero = sc_series[active_mask].fillna(0)
    if len(non_zero) < 5:
        # Fallback: absolute thresholds for very sparse engines
        th = _FAMILY_TIER_THRESHOLDS
        tiers[sc_series >= th["ACTIVE"]]  = "P4"
        tiers[sc_series >= th["P3"]]      = "P3"
        tiers[sc_series >= th["P2"]]      = "P2"
        tiers[sc_series >= th["P1"]]      = "P1"
        return tiers
    p99 = float(non_zero.quantile(0.99))
    p95 = float(non_zero.quantile(0.95))
    p80 = float(non_zero.quantile(0.80))
    tiers[active_mask]                    = "P4"   # active
    tiers[sc_series >= p80]               = "P3"   # top 20%
    tiers[sc_series >= p95]               = "P2"   # top 5%
    tiers[sc_series >= p99]               = "P1"   # top 1%
    return tiers


# ── Layout helpers ─────────────────────────────────────────────────────────────

def _empty_placeholder(msg: str) -> html.Div:
    return html.Div(
        dmc.Text(msg, c="dimmed", size="sm"),
        style=_EMPTY_STYLE,
    )


def _section_header(title: str, subtitle: str, icon: str = "mdi:table") -> html.Div:
    return html.Div(
        [
            dmc.Group(
                [
                    DashIconify(icon=icon, width=18, color="#00D4FF"),
                    dmc.Text(title, fw=700, c="white", size="sm"),
                ],
                gap="xs",
                mb=2,
            ),
            dmc.Text(subtitle, c="dimmed", size="xs", mb="sm"),
        ]
    )


def _default_col_def() -> dict:
    return {"sortable": True, "filter": True, "resizable": True, "suppressMenu": False}


def _grid_options(page_size: int = 10) -> dict:
    """Return dashGridOptions dict.  Pagination is always enabled; default page = 10.
    Users can switch to 20 / 50 / 100 via the built-in AG Grid page-size selector."""
    return {
        "domLayout": "autoHeight",
        "rowHeight": 40,
        "headerHeight": 36,
        "animateRows": True,
        "suppressCellFocus": True,
        "pagination": True,
        "paginationPageSize": page_size,
        "paginationPageSizeSelector": [10, 20, 50, 100],
    }


# ── Table 1 — Risk by Detection Family (Count) ────────────────────────────────

def _build_table1(scored_df: pd.DataFrame, analytics_results: dict) -> html.Div:
    """v16.65: One row per detection family.

    Columns: Family | What It Detects | # Algorithms | Total Records
             | P1 (Critical) | P2 (High) | P3 (Medium) | P4 (Active) | No Signal

    v16.65 FIX: Tier counts now use per-family score thresholds (absolute 0-1 scale)
    instead of the composite risk_tier column.  This gives each engine its own
    independent distribution — e.g. Network Hub may show 4 critical signals while
    Benford's Law shows 0 critical but 18 moderate.  Previously all rows showed
    the same counts because the composite tier always has exactly 1 P1 per 100
    customers (percentile-based) and all engines flagged the same top customer.
    """
    families = _family_keys(scored_df)

    if not families:
        return _empty_placeholder("No detection family scores found in pipeline results.")

    # v16.65: Extended tier order includes "No Signal"
    _TIER_EXT = ["P1", "P2", "P3", "P4", "No Signal"]
    _TIER_COLORS_EXT = {
        "P1": "#FF1744", "P2": "#FF9800", "P3": "#FFD600",
        "P4": "#4CAF50", "No Signal": "#475569",
    }

    rows: list[dict] = []
    for fkey in families:
        sc_col = f"score_{fkey}"
        meta = _FAMILY_META.get(fkey, (fkey.replace("_", " ").title(), "", "#888"))
        disp    = meta[0]

        # ── per-family tier using this engine's own score ──
        if sc_col in scored_df.columns:
            family_tiers = _per_family_tier(scored_df[sc_col].fillna(0))
            tier_vc      = family_tiers.value_counts()
            fam_total    = int((scored_df[sc_col].fillna(0) >= _FAMILY_TIER_THRESHOLDS["ACTIVE"]).sum())
        else:
            tier_vc   = {}
            fam_total = 0

        rows.append({
            "Family":           disp,
            "# Algorithms":     _algo_count(fkey, analytics_results),
            "Total Records":    fam_total,
            **{t: int(tier_vc.get(t, 0)) for t in _TIER_EXT},
        })

    # Tier-cell conditional style
    def _tier_style(tier: str) -> dict:
        col = _TIER_COLORS_EXT.get(tier, "#888")
        return {
            "function": (
                f"params.value > 0 ? "
                f"{{'color':'{col}','fontWeight':'700'}} : "
                f"{{'color':'#334155'}}"
            )
        }

    col_defs: list[dict] = [
        {
            "field": "Family", "headerName": "Detection Family",
            "minWidth": 180, "flex": 1,
            "cellStyle": {"color": "#00D4FF", "fontWeight": "600"},
        },
        {
            "field": "# Algorithms", "headerName": "# Algos",
            "width": 90, "type": "numericColumn",
            "cellStyle": {"color": "#94A3B8"},
        },
        {
            "field": "Total Records", "headerName": "Flagged",
            "width": 100, "type": "numericColumn",
            "cellStyle": {"color": "#CBD5E1"},
            "valueFormatter": {"function": "params.value.toLocaleString()"},
        },
    ]
    for t in _TIER_EXT:
        col_defs.append({
            "field": t,
            "headerName": t if t != "No Signal" else "No Signal",
            "width": 105 if t != "No Signal" else 110,
            "type": "numericColumn",
            "cellStyle": _tier_style(t),
            "valueFormatter": {"function": "params.value.toLocaleString()"},
        })

    return html.Div([
        _section_header(
            "Table 1 — Risk by Detection Family (Count)",
            "Each engine's own signal-strength distribution. "
            "P1 ≥ 65/100 score · P2 ≥ 40 · P3 ≥ 12 · P4 ≥ 2 · No Signal = not flagged. "
            "Different engines flag different customers — compare to find the most discriminating detectors.",
            "mdi:table-eye",
        ),
        dag.AgGrid(
            rowData=rows,
            columnDefs=col_defs,
            defaultColDef=_default_col_def(),
            dashGridOptions=_grid_options(),
            style={"height": None, "width": "100%"},
            className=_GRID_CLASS,
        ),
    ])


# ── Table 2 — Risk by Detection Family (Avg Score per Tier) ───────────────────

def _build_table2(scored_df: pd.DataFrame, analytics_results: dict) -> html.Div:
    """
    One row per detection family.
    Columns: Family | # Algorithms | Total Records | P1 Avg | P2 Avg | P3 Avg | P4 Avg (0–100 scale)
    """
    families = _family_keys(scored_df)
    tier_c   = _tier_col(scored_df)

    if not families:
        return _empty_placeholder("No detection family scores found in pipeline results.")
    if tier_c is None:
        return _empty_placeholder("Risk tier column not found — re-run pipeline.")

    # Heat colour JS expression for avg score cells (0–100)
    heat_fn = (
        "params.value >= 60 ? {'color':'#FF1744','fontWeight':'700'} : "
        "params.value >= 40 ? {'color':'#FF9800','fontWeight':'600'} : "
        "params.value >= 20 ? {'color':'#FFD600'} : "
        "params.value > 0  ? {'color':'#94A3B8'} : "
        "{'color':'#475569'}"
    )

    rows: list[dict] = []
    for fkey in families:
        sc_col = f"score_{fkey}"
        disp, _, _ = _FAMILY_META.get(fkey, (fkey.replace("_", " ").title(), "", "#888"))
        # Total Records = customers where this family produced any signal (score > 0)
        if sc_col in scored_df.columns:
            fam_total = int((scored_df[sc_col] > 0).sum())
        else:
            fam_total = 0
        row: dict = {
            "Family":        disp,
            "# Algorithms":  _algo_count(fkey, analytics_results),
            "Total Records": fam_total,
        }
        for t in _TIER_ORDER:
            # Only customers in this tier AND with a non-zero signal from this family
            tier_mask = scored_df[tier_c] == t
            if sc_col in scored_df.columns:
                active_mask = tier_mask & (scored_df[sc_col] > 0)
                if active_mask.sum() > 0:
                    avg = float(scored_df.loc[active_mask, sc_col].mean()) * 100.0
                else:
                    avg = 0.0
            else:
                avg = 0.0
            row[f"{t} Avg Score"] = round(avg, 1)
        rows.append(row)

    col_defs: list[dict] = [
        {
            "field": "Family", "headerName": "Detection Family",
            "minWidth": 200, "flex": 2,
            "cellStyle": {"color": "#00D4FF", "fontWeight": "600"},
        },
        {
            "field": "# Algorithms", "headerName": "# Algorithms",
            "width": 120, "type": "numericColumn",
            "cellStyle": {"color": "#94A3B8"},
        },
        {
            "field": "Total Records", "headerName": "Total Records",
            "width": 130, "type": "numericColumn",
            "cellStyle": {"color": "#CBD5E1"},
            "valueFormatter": {"function": "params.value.toLocaleString()"},
        },
    ]
    for t in _TIER_ORDER:
        col_defs.append({
            "field": f"{t} Avg Score", "headerName": f"{t} Avg",
            "width": 110, "type": "numericColumn",
            "cellStyle": {"function": heat_fn},
            "valueFormatter": {"function": "params.value.toFixed(1)"},
        })

    return html.Div([
        _section_header(
            "Table 2 — Risk by Detection Family (Average Scores)",
            "Average detection signal per tier (0–100). "
            "Reveals which engines drive the highest risk in each priority group.",
            "mdi:chart-bar",
        ),
        dag.AgGrid(
            rowData=rows,
            columnDefs=col_defs,
            defaultColDef=_default_col_def(),
            dashGridOptions=_grid_options(),
            style={"height": None, "width": "100%"},
            className=_GRID_CLASS,
        ),
    ])


# ── Table 3 — Top Flagged Customers (family scores) ───────────────────────────

def _build_table3(scored_df: pd.DataFrame) -> html.Div:
    """
    Top-N customers by risk_score, with one score column per detection family.
    """
    families  = _family_keys(scored_df)
    score_c   = _score_col(scored_df)

    if not families or score_c is None:
        return _empty_placeholder("No scored results — run pipeline to populate this table.")

    id_c    = _id_col(scored_df)
    name_c  = _name_col(scored_df)
    type_c  = _type_col(scored_df)
    tier_c  = _tier_col(scored_df)
    n_shown = min(_TOP_N, len(scored_df))
    top     = scored_df.nlargest(n_shown, score_c).reset_index(drop=True)

    rows: list[dict] = []
    for seq, (_, row) in enumerate(top.iterrows(), start=1):
        r: dict = {
            "cust_id":       _safe_str(row[id_c])   if id_c   else f"#{seq}",
            "name":          _safe_str(row[name_c]) if name_c else "—",
            "type":          _safe_str(row[type_c]) if type_c else "—",
            "tier":          _safe_str(row[tier_c]) if tier_c else "—",
            "overall_score": round(_safe_float(row[score_c]), 1),
        }
        for fkey in families:
            sc = f"score_{fkey}"
            # Family score × 100 → 0–100 for display
            r[sc] = round(_safe_float(row.get(sc, 0.0)) * 100.0, 1)
        rows.append(r)

    tier_fn = (
        "params.value === 'P1' ? {'color':'#FF1744','fontWeight':'700'} : "
        "params.value === 'P2' ? {'color':'#FF9800','fontWeight':'600'} : "
        "params.value === 'P3' ? {'color':'#FFD600'} : {'color':'#4CAF50'}"
    )
    score_fn = (
        "params.value >= 70 ? {'color':'#FF1744','fontWeight':'700'} : "
        "params.value >= 50 ? {'color':'#FF9800','fontWeight':'600'} : "
        "params.value >= 30 ? {'color':'#FFD600'} : {'color':'#94A3B8'}"
    )

    col_defs: list[dict] = [
        {
            "field": "cust_id", "headerName": "Customer ID",
            "width": 140,
            "cellStyle": {"color": "#00D4FF", "fontWeight": "600", "fontFamily": "monospace"},
        },
        {
            "field": "name", "headerName": "Name",
            "minWidth": 140, "flex": 1,
            "cellStyle": {"color": "#E2E8F0"},
        },
        {
            "field": "type", "headerName": "Type",
            "width": 110,
            "cellStyle": {"color": "#94A3B8"},
        },
        {
            "field": "tier", "headerName": "Tier",
            "width": 90,
            "cellStyle": {"function": tier_fn},
        },
        {
            "field": "overall_score", "headerName": "Overall Score",
            "width": 120, "type": "numericColumn",
            "sort": "desc",
            "cellStyle": {"function": score_fn},
            "valueFormatter": {"function": "params.value.toFixed(1)"},
        },
    ]
    for fkey in families:
        disp, _, _ = _FAMILY_META.get(fkey, (fkey.replace("_", " ").title(), "", "#888"))
        sc = f"score_{fkey}"
        col_defs.append({
            "field": sc,
            "headerName": disp[:22],
            "width": 145, "type": "numericColumn",
            "cellStyle": {"function": score_fn},
            "valueFormatter": {"function": "params.value.toFixed(1)"},
            "tooltipValueGetter": {"function": f"'{disp}'"},
        })

    return html.Div([
        _section_header(
            f"Table 3 — Top {n_shown} Flagged Customers (Detection Engine Scores)",
            "Sorted by overall risk score ↓. Each column shows the detection engine signal "
            "for that customer (0–100 scale; higher = more suspicious).",
            "mdi:account-alert",
        ),
        dag.AgGrid(
            rowData=rows,
            columnDefs=col_defs,
            defaultColDef=_default_col_def(),
            dashGridOptions=_grid_options(page_size=10),
            style={"height": None, "width": "100%"},
            className=_GRID_CLASS,
        ),
    ])


# ── Table 4 — Top Flagged Customers (anomaly flags per family) ─────────────────

def _build_table4(scored_df: pd.DataFrame) -> html.Div:
    """
    Top-N customers by risk_score.
    Binary anomaly flag per family: 1 if score_{family} > ANOMALY_THRESHOLD.
    """
    families  = _family_keys(scored_df)
    score_c   = _score_col(scored_df)

    if not families or score_c is None:
        return _empty_placeholder("No scored results — run pipeline to populate this table.")

    id_c    = _id_col(scored_df)
    name_c  = _name_col(scored_df)
    type_c  = _type_col(scored_df)
    tier_c  = _tier_col(scored_df)
    n_shown = min(_TOP_N, len(scored_df))
    top     = scored_df.nlargest(n_shown, score_c).reset_index(drop=True)

    rows: list[dict] = []
    for seq, (_, row) in enumerate(top.iterrows(), start=1):
        flag_count = 0
        r: dict = {
            "cust_id":       _safe_str(row[id_c])   if id_c   else f"#{seq}",
            "name":          _safe_str(row[name_c]) if name_c else "—",
            "type":          _safe_str(row[type_c]) if type_c else "—",
            "risk_group":    _safe_str(row[tier_c]) if tier_c else "—",
            "overall_score": round(_safe_float(row[score_c]), 1),
        }
        for fkey in families:
            sc = f"score_{fkey}"
            val   = _safe_float(row.get(sc, 0.0))
            flag  = 1 if val > _ANOMALY_THRESHOLD else 0
            flag_count += flag
            r[f"{fkey}_flag"] = flag
        r["engines_flagged"] = flag_count
        rows.append(r)

    tier_fn = (
        "params.value === 'P1' ? {'color':'#FF1744','fontWeight':'700'} : "
        "params.value === 'P2' ? {'color':'#FF9800','fontWeight':'600'} : "
        "params.value === 'P3' ? {'color':'#FFD600'} : {'color':'#4CAF50'}"
    )
    score_fn = (
        "params.value >= 70 ? {'color':'#FF1744','fontWeight':'700'} : "
        "params.value >= 50 ? {'color':'#FF9800','fontWeight':'600'} : "
        "params.value >= 30 ? {'color':'#FFD600'} : {'color':'#94A3B8'}"
    )
    flag_fn = (
        "params.value === 1 ? "
        "{'color':'#FF1744','fontWeight':'700','background':'rgba(255,23,68,0.12)'} : "
        "{'color':'#4CAF50'}"
    )
    engines_fn = (
        "params.value >= 6 ? {'color':'#FF1744','fontWeight':'700'} : "
        "params.value >= 4 ? {'color':'#FF9800','fontWeight':'600'} : "
        "params.value >= 2 ? {'color':'#FFD600'} : "
        "params.value >= 1 ? {'color':'#94A3B8'} : {'color':'#475569'}"
    )

    col_defs: list[dict] = [
        {
            "field": "cust_id", "headerName": "Customer ID",
            "width": 140,
            "cellStyle": {"color": "#00D4FF", "fontWeight": "600", "fontFamily": "monospace"},
        },
        {
            "field": "name", "headerName": "Name",
            "minWidth": 140, "flex": 1,
            "cellStyle": {"color": "#E2E8F0"},
        },
        {
            "field": "type", "headerName": "Type",
            "width": 110,
            "cellStyle": {"color": "#94A3B8"},
        },
        {
            "field": "risk_group", "headerName": "Risk Group",
            "width": 100,
            "cellStyle": {"function": tier_fn},
        },
        {
            "field": "overall_score", "headerName": "Overall Score",
            "width": 120, "type": "numericColumn",
            "sort": "desc",
            "cellStyle": {"function": score_fn},
            "valueFormatter": {"function": "params.value.toFixed(1)"},
        },
        {
            "field": "engines_flagged", "headerName": "Engines",
            "width": 90, "type": "numericColumn",
            "cellStyle": {"function": engines_fn},
            "headerTooltip": "How many of the 10 detection engines raised an anomaly flag",
        },
    ]
    for fkey in families:
        disp, _, _ = _FAMILY_META.get(fkey, (fkey.replace("_", " ").title(), "", "#888"))
        col_defs.append({
            "field": f"{fkey}_flag",
            "headerName": disp[:22],
            "width": 145,
            "cellStyle": {"function": flag_fn},
            "valueFormatter": {"function": "params.value === 1 ? '🚨 YES' : '✓ No'"},
            "tooltipValueGetter": {"function": f"params.value === 1 ? 'Anomaly flagged by {disp}' : 'No anomaly'"},
        })

    return html.Div([
        _section_header(
            f"Table 4 — Top {n_shown} Flagged Customers (Anomaly Flags per Engine)",
            f"Binary anomaly flag per detection engine (score > {int(_ANOMALY_THRESHOLD * 100)}% "
            "threshold). 'Engines' = total engines that raised a flag for this customer.",
            "mdi:flag-triangle",
        ),
        dag.AgGrid(
            rowData=rows,
            columnDefs=col_defs,
            defaultColDef=_default_col_def(),
            dashGridOptions=_grid_options(page_size=10),
            style={"height": None, "width": "100%"},
            className=_GRID_CLASS,
        ),
    ])


# ── Public entry point ─────────────────────────────────────────────────────────

def build_risk_tables_section(pipeline) -> html.Div:
    """
    Main entry point — called from the dashboard callback.

    Returns a ``html.Div`` containing the full 4-table risk analysis suite.
    If the pipeline has no scored results, returns a styled placeholder.

    Parameters
    ----------
    pipeline : fcdai_network_analyzer.engine.Pipeline
        Live pipeline singleton from ``engine.get_pipeline()``.
    """
    scored_df: pd.DataFrame | None = getattr(pipeline, "scored_df", None) if pipeline else None
    analytics_results: dict = getattr(pipeline, "analytics_results", None) or {}

    # Also try pipeline.analytics.results as fallback
    if not analytics_results:
        _analytics_obj = getattr(pipeline, "analytics", None)
        if _analytics_obj:
            analytics_results = getattr(_analytics_obj, "results", None) or {}

    if scored_df is None or len(scored_df) == 0:
        return html.Div(
            dmc.Alert(
                dmc.Group(
                    [
                        DashIconify(icon="mdi:table-off", width=20),
                        dmc.Text(
                            "Run the pipeline to generate the Risk Analysis Table Suite (Tables 1–4).",
                            c="white", size="sm",
                        ),
                    ],
                    gap="sm",
                ),
                color="gray", variant="filled", radius="md",
                style={
                    "backgroundColor": "rgba(30,41,59,0.6)",
                    "border": "1px solid rgba(100,116,139,0.3)",
                },
            ),
        )

    # Enrich with name / type from node table if available
    scored_df = _enrich_scored(scored_df, pipeline)

    n_families = len(_family_keys(scored_df))
    n_customers = len(scored_df)

    return html.Div(
        [
            # ── Section divider ─────────────────────────────────────────
            dmc.Divider(
                label=dmc.Group(
                    [
                        DashIconify(icon="mdi:table-multiple", width=20, color="#00D4FF"),
                        dmc.Text(
                            "Pipeline Risk Analysis — 4-Table Intelligence Suite",
                            fw=700, c="white", size="sm",
                        ),
                        dmc.Badge(
                            f"{n_customers:,} customers · {n_families} engines",
                            color="cyan", variant="light", size="xs",
                        ),
                    ],
                    gap="xs",
                ),
                labelPosition="left",
                mb="md",
                mt="sm",
            ),

            # ── Tables 1 & 2 side by side (responsive: 1 col on small screens) ──
            dmc.SimpleGrid(
                cols={"base": 1, "xl": 2},
                spacing="md",
                mb="md",
                children=[
                    dmc.Paper(
                        _build_table1(scored_df, analytics_results),
                        p="md", radius="lg", className="glass-card",
                    ),
                    dmc.Paper(
                        _build_table2(scored_df, analytics_results),
                        p="md", radius="lg", className="glass-card",
                    ),
                ],
            ),

            # ── Table 3: family scores ───────────────────────────────────
            dmc.Paper(
                _build_table3(scored_df),
                p="md", radius="lg", className="glass-card", mb="md",
            ),

            # ── Table 4: anomaly flags ───────────────────────────────────
            dmc.Paper(
                _build_table4(scored_df),
                p="md", radius="lg", className="glass-card", mb="md",
            ),
        ],
    )
