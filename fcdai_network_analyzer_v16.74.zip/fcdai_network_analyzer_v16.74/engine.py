"""
FCDAI Network Analyzer v12.4 — Pipeline Engine (AIR-GAPPED)
=============================================================
v12.4 High-Performance Edition (based on v12.4 lineage):
  P1: Parallel family execution (ThreadPoolExecutor, 3-5x)
  P2: Graph sampling with user-configurable thresholds
  P4: Hash-based family caching (5-10x on re-runs)
  P6: Progressive analytics — fast families first, then slow
  BG: Background pipeline execution with live progress
v12.4 Audit-Fix Release:
  E1: Resume/Retry — pipeline can resume from last successful stage
  B1-B4: 10-family analytics (3 new: structuring, benfords, motifs)
  A1: Geo-risk data getter (CRIT-01 duplicate removed)
  A2: Customer 360 getter
  A3: Comparative run support
  A4: Audit trail integration
  H1: Config hot-reload (check_config_changed / reload_config)

Air-gapped: No external calls. PII-protected. Offline-only.
"""
# ── Developer Attribution (v16.45) ─────────────────────────────────────────
# Developer: Das Apurba | FCDAI Analytics — internal fingerprint
# For modifications or extensions contact Das Apurba.
__author__  = "Das Apurba"
__team__    = "FCDAI Analytics"
__version__ = "16.74.0"

import pandas as pd
import numpy as np
import networkx as nx
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime
import time
import json
import sys
import gc
import threading
import hashlib

sys.path.insert(0, str(Path(__file__).parent))
from config import PATHS, PIPELINE, APP
from layers.l0_ingest import IngestLayer
from layers.l1_validate import ValidateLayer
from layers.l2_aggregate import AggregateLayer
from layers.l3_graph import GraphConstructionLayer
from layers.l5_analytics import AnalyticsLayer
from layers.l6_scoring import ScoringLayer
from layers.l7_reporting import ReportingLayer
from models.schemas import PipelineStageResult, PipelineResult
from utils.logger import log_audit, log_error
from utils.persistence import store_or_load, get_vault
from utils.pii_guard import mask_for_log, validate_air_gap
from utils.memory_monitor import MemoryMonitor
from database import get_db


# =============================================================================
# AUDIT TRAIL (v10 A4)
# =============================================================================
class AuditTrail:
    """Thread-safe audit trail for all pipeline operations."""

    def __init__(self):
        self._lock = threading.Lock()
        self._entries: List[Dict] = []

    def log(self, action: str, details: str, user: str = "SYSTEM", severity: str = "INFO"):
        with self._lock:
            entry = {
                "timestamp": datetime.now().isoformat(),
                "action": action,
                "details": mask_for_log(details),
                "user": user,
                "severity": severity,
                "hash": hashlib.sha256(
                    f"{action}{details}{datetime.now().isoformat()}".encode()
                ).hexdigest()[:16],
            }
            self._entries.append(entry)
            # Keep last 5000 entries in memory
            if len(self._entries) > 5000:
                self._entries = self._entries[-5000:]

    def get_entries(self, limit: int = 200, severity: str = None) -> List[Dict]:
        with self._lock:
            entries = self._entries.copy()
            if severity:
                entries = [e for e in entries if e["severity"] == severity]
            return entries[-limit:]

    def get_summary(self) -> Dict:
        with self._lock:
            return {
                "total_entries": len(self._entries),
                "by_severity": {
                    sev: len([e for e in self._entries if e["severity"] == sev])
                    for sev in ["INFO", "WARNING", "ERROR", "CRITICAL"]
                },
                "last_entry": self._entries[-1] if self._entries else None,
            }

    def flush_to_db(self, db, run_id: int = None) -> int:
        """v16.8 H1: Persist in-memory audit trail to SQLite.

        Thread-safe flush: copies and clears the in-memory buffer,
        then writes to DB outside the lock to avoid deadlock.
        Returns number of entries flushed.
        """
        with self._lock:
            to_flush = self._entries.copy()
            self._entries.clear()
        if not to_flush:
            return 0
        try:
            db.save_audit_trail(to_flush, run_id=run_id)
        except Exception:
            # Restore entries on DB failure so nothing is lost
            with self._lock:
                self._entries = to_flush + self._entries
        return len(to_flush)

    def load_from_db(self, db, limit: int = 200):
        """v16.8 H1: Pre-populate in-memory trail from SQLite on startup.

        Loads most recent persisted entries so the trail has historical context
        even after a server restart.
        """
        try:
            entries = db.load_audit_trail(limit=limit)
            with self._lock:
                current_actions = {e["action"] for e in self._entries}
                for e in entries:
                    if e.get("action") not in current_actions:
                        self._entries.append(e)
                if len(self._entries) > 5000:
                    self._entries = self._entries[-5000:]
        except Exception:
            pass


# =============================================================================
# PIPELINE PROGRESS TRACKER
# =============================================================================
class PipelineProgress:
    """Thread-safe pipeline progress tracker for live dashboard updates."""

    STAGES = [
        {"id": 0, "name": "Ingest & Validate", "weight": 15},
        {"id": 1, "name": "Aggregation", "weight": 10},
        {"id": 2, "name": "Graph Construction", "weight": 15},
        {"id": 3, "name": "Analytics (10-Family)", "weight": 35},
        {"id": 4, "name": "Risk Scoring", "weight": 15},
        {"id": 5, "name": "Reporting & Persist", "weight": 10},
    ]

    def __init__(self):
        self._lock = threading.Lock()
        # v16.8 M1: shared MemoryMonitor — never instantiate inside get_status() hotpath
        self._mem_monitor = MemoryMonitor()
        self.reset()

    def reset(self):
        with self._lock:
            self._running = False
            self._current_stage = -1
            self._stage_status = {}
            self._overall_pct = 0
            self._message = "Idle"
            self._start_time = None
            self._stage_times = {}
            self.stop_requested = False
            self._last_successful_stage = -1

    def start(self):
        with self._lock:
            self._running = True
            self._current_stage = 0
            self._overall_pct = 0
            self._message = "Starting pipeline..."
            self._start_time = time.time()
            self._stage_status = {s["id"]: "pending" for s in self.STAGES}
            self._stage_times = {}

    def update_stage(self, stage_id: int, status: str, message: str = ""):
        with self._lock:
            self._current_stage = stage_id
            self._stage_status[stage_id] = status
            self._message = message or f"Running {self.STAGES[stage_id]['name']}..."
            if status == "running":
                self._stage_times[stage_id] = {"start": time.time()}
            elif status == "done":
                self._last_successful_stage = stage_id
                if stage_id in self._stage_times:
                    self._stage_times[stage_id]["end"] = time.time()
                done_weight = sum(
                    s["weight"] for s in self.STAGES if self._stage_status.get(s["id"]) == "done"
                )
                self._overall_pct = min(done_weight, 100)

    def finish(self, success: bool = True):
        with self._lock:
            self._running = False
            self._overall_pct = 100 if success else self._overall_pct
            self._message = "Pipeline complete!" if success else "Pipeline failed"

    def get_status(self) -> Dict:
        with self._lock:
            elapsed = (time.time() - self._start_time) if self._start_time else 0
            # v16.8 M1: reuse singleton instead of new instance per poll cycle
            mem = self._mem_monitor
            return {
                "running": self._running,
                "current_stage": self._current_stage,
                "overall_pct": self._overall_pct,
                "message": self._message,
                "elapsed_sec": round(elapsed, 1),
                "memory": mem.get_status(),
                "last_successful_stage": self._last_successful_stage,
                "stages": [
                    {
                        "id": s["id"],
                        "name": s["name"],
                        "status": self._stage_status.get(s["id"], "pending"),
                        "duration": (
                            round(
                                self._stage_times.get(s["id"], {}).get("end", time.time())
                                - self._stage_times.get(s["id"], {}).get("start", time.time()),
                                1,
                            )
                            if s["id"] in self._stage_times
                            else 0
                        ),
                    }
                    for s in self.STAGES
                ],
            }


# ---- Optional igraph ----
try:
    import igraph as ig

    _HAS_IGRAPH = True
except ImportError:
    _HAS_IGRAPH = False


# =============================================================================
# v16.5 MODULE-LEVEL HELPERS (Rule-12 + Rule-14)
# =============================================================================


def _validate_scoring_weights(
    weights: Optional[Dict[str, float]],
    audit=None,
) -> Optional[Dict[str, float]]:
    """Rule-12: warn + auto-normalize risk_formula_weights that don't sum to 1.0.

    Non-fatal — never raises. Returns None unchanged.
    Args:
        weights: scoring weights dict or None (passed-through from caller).
        audit:   FCDAIPipeline.audit instance for structured logging.
    Returns:
        Normalized weights dict, or the original value if None / empty.
    """
    if not weights:
        return weights
    total = sum(weights.values())
    if abs(total - 1.0) < 1e-6:
        return weights
    msg = f"Scoring weights sum={total:.6f} != 1.0 — auto-normalizing"
    log_audit("WEIGHT_SUM_WARN", msg)
    try:
        audit.log("WEIGHT_SUM_WARN", msg, severity="WARNING")
    except Exception:
        pass
    if total <= 0:
        return weights  # cannot normalize — return as-is
    return {k: v / total for k, v in weights.items()}


def _check_graph_integrity(G, audit=None) -> None:
    """Rule-14: warn on NaN/negative edge weights and isolated nodes.

    Non-fatal — warnings only, pipeline is never blocked.
    Args:
        G:     NetworkX graph object.
        audit: FCDAIPipeline.audit instance for structured logging.
    """
    try:
        nan_edges = neg_edges = isolated = 0
        for _u, _v, d in G.edges(data=True):
            w = d.get("weight", 1.0)
            if w is None or (isinstance(w, float) and np.isnan(w)):
                nan_edges += 1
            elif w < 0:
                neg_edges += 1
        isolated = sum(1 for n in G.nodes() if G.degree(n) == 0)
        issues: List[str] = []
        if nan_edges:
            issues.append(f"NaN-weight edges: {nan_edges}")
        if neg_edges:
            issues.append(f"negative-weight edges: {neg_edges}")
        if isolated:
            issues.append(f"isolated nodes: {isolated}")
        if issues:
            msg = " | ".join(issues)
            log_audit("GRAPH_INTEGRITY_WARN", msg)
            try:
                audit.log("GRAPH_INTEGRITY_WARN", msg, severity="WARNING")
            except Exception:
                pass
        else:
            log_audit(
                "GRAPH_INTEGRITY_OK",
                f"nodes={G.number_of_nodes()} edges={G.number_of_edges()}",
            )
    except Exception:
        pass  # integrity check is advisory — never block the pipeline


class FCDAIPipeline:
    """
    v12.36 Pipeline Orchestrator — 10-family analytics, air-gapped, PII-safe.
    Resume/retry support, comparative run, audit trail.

    v12.36: RESILIENT NODE+EDGE MODE
    --------------------------------
    The pipeline now supports TWO data modes:
      1. GRAPH-SCHEMA MODE: User provides "node" + "edge" tables (minimum).
         These are used directly for graph construction — no aggregation needed.
         Optional enrichment tables: relationship_edge, shared_attribute, temporal.
      2. LEGACY MODE: User provides "customer" + "transaction" tables.
         Traditional aggregation produces customer_features + edges.
         Optional tables: kyc, alert, historical, account, relationship, case.

    With just 2 tables (node + edge), the full 10-family analytics pipeline
    runs end-to-end: graph construction → analytics → scoring → reporting.
    """

    def __init__(self):
        self.ingest = IngestLayer()
        self.validate = ValidateLayer()
        self.aggregate = AggregateLayer()
        self.graph = GraphConstructionLayer()
        self.analytics = AnalyticsLayer()
        self.scoring = ScoringLayer()
        self.reporting = ReportingLayer()

        # Pipeline state
        self.tables: Dict[str, pd.DataFrame] = {}
        self.customer_features: Optional[pd.DataFrame] = None
        self.edges: Optional[pd.DataFrame] = None
        self.G: Optional[nx.DiGraph] = None
        self.analytics_results: Dict[str, pd.DataFrame] = {}
        self.scored_df: Optional[pd.DataFrame] = None
        self.reports: Dict[str, Any] = {}
        self.stage_results: List[PipelineStageResult] = []
        self.last_run_meta: Dict[str, Any] = {}
        self._current_run_id: Optional[int] = None

        # v12.36: Data mode flag — "graph_schema" or "legacy"
        self._data_mode: str = "legacy"

        # v10: Progress + Audit
        self.progress = PipelineProgress()
        self.audit = AuditTrail()

        # v10: Memory monitor
        self.mem_monitor = MemoryMonitor()

        # Caches
        self._cycles_cache: Optional[List] = None
        self._lobbies_cache: Optional[List] = None
        self._important_nodes_cache: Optional[pd.DataFrame] = None

        self.run_version: int = 0

        # v16.73: 4-layer deterministic run fingerprint
        # L1=full data content, L2=weights, L3=config params, L4=version
        # Master = SHA-256 of all 4 layer hashes concatenated.
        # True cache skip: if master FP matches, skip pipeline.run() entirely.
        self._last_run_fingerprint: Optional[str] = None      # 32-char master SHA-256
        self._last_run_layer_hashes: dict = {}                 # {data, weights, config, version}
        self._last_run_params: dict = {}                       # weights+config used in last run
        self._last_run_was_cache_hit: bool = False
        self._cache_hit_msg: str = ""
        self._cache_miss_reason: str = ""                     # which layer(s) changed

        # v16.8 M3: threading.Event replaces raw bool for cross-thread safety
        self._cleansed_event = threading.Event()

        # v16.8 M5: run lock prevents simultaneous launches from two browser tabs
        self._run_lock = threading.Lock()

        # v10: Validate air-gap on init
        validate_air_gap()
        self.audit.log("PIPELINE_INIT", "Pipeline initialized (air-gapped mode)")

        # v16.8 H1: Restore recent audit trail entries from DB (best-effort)
        try:
            db = get_db()
            self.audit.load_from_db(db, limit=200)
        except Exception:
            pass

    # =========================================================================
    # CONFIG OVERRIDE
    # =========================================================================
    def load_config_overrides(self) -> Dict:
        config_path = PATHS.BASE / "pipeline_config.json"
        if config_path.exists():
            try:
                with open(config_path, "r") as f:
                    overrides = json.load(f)
                log_audit("CONFIG_OVERRIDE", f"Loaded overrides: {list(overrides.keys())}")
                self.audit.log("CONFIG_OVERRIDE", f"Keys: {list(overrides.keys())}")
                return overrides
            except Exception as e:
                log_error(f"Failed to load config overrides: {e}")
        return {}

    def save_config(self, config: Dict):
        config_path = PATHS.BASE / "pipeline_config.json"
        try:
            with open(config_path, "w") as f:
                json.dump(config, f, indent=2)
            log_audit("CONFIG_SAVE", f"Saved config: {list(config.keys())}")
            self.audit.log("CONFIG_SAVE", f"Keys: {list(config.keys())}")
        except Exception as e:
            log_error(f"Failed to save config: {e}")

    # =========================================================================
    # PERSISTENCE
    # =========================================================================
    @staticmethod
    def _hash_df(df: pd.DataFrame) -> str:
        """v16.73: Full-content SHA-256 of a DataFrame, row+column order independent.

        Columns are sorted alphabetically; rows are sorted lexicographically
        across all column values (as strings). This ensures two DataFrames with
        identical data but different row/column ordering produce the same hash.
        """
        df_s = df.reindex(sorted(df.columns), axis=1).astype(str)
        df_s = df_s.sort_values(by=list(df_s.columns)).reset_index(drop=True)
        return hashlib.sha256(df_s.to_csv(index=False).encode('utf-8')).hexdigest()

    @staticmethod
    def _compute_run_fingerprint(
        tables: dict,
        weights: dict,
        run_params: dict,
        app_version: str,
    ) -> tuple:
        """v16.73: Compute 4-layer master run fingerprint.

        Returns (master_fp_32chars, layer_hashes_dict) where layer_hashes_dict
        has keys: 'data', 'weights', 'config', 'version'.

        L1 DATA     — full content of ALL present tables (ALL rows, ALL cells).
                      Optional tables: absent+absent = same key set = no change.
        L2 WEIGHTS  — all scoring weights rounded to 6 decimal places.
        L3 CONFIG   — pipeline run params (norm_method, tier, max_customers, etc.).
        L4 VERSION  — app version string ensures new releases always re-run.
        MASTER      — SHA-256 of the four layer hashes concatenated.
        """
        import json as _json

        # L1: DATA — record which tables are present, then hash each fully
        l1 = hashlib.sha256()
        present_keys = sorted(
            k for k, v in (tables or {}).items()
            if v is not None and len(v) > 0
        )
        l1.update(_json.dumps(present_keys).encode('utf-8'))  # table presence is part of FP
        for key in present_keys:
            l1.update(f"{key}:".encode('utf-8'))
            l1.update(FCDAIPipeline._hash_df(tables[key]).encode('utf-8'))
        layer_data = l1.hexdigest()[:32]

        # L2: WEIGHTS
        weights_clean = {
            k: round(float(v), 6)
            for k, v in sorted((weights or {}).items())
        }
        layer_weights = hashlib.sha256(
            _json.dumps(weights_clean, sort_keys=True).encode('utf-8')
        ).hexdigest()[:32]

        # L3: CONFIG PARAMS
        params_clean = {k: v for k, v in sorted((run_params or {}).items())}
        layer_config = hashlib.sha256(
            _json.dumps(params_clean, sort_keys=True, default=str).encode('utf-8')
        ).hexdigest()[:32]

        # L4: VERSION
        layer_version = hashlib.sha256(
            str(app_version).encode('utf-8')
        ).hexdigest()[:32]

        # MASTER
        master = hashlib.sha256(
            (layer_data + layer_weights + layer_config + layer_version).encode('utf-8')
        ).hexdigest()[:32]

        return master, {
            "data":    layer_data,
            "weights": layer_weights,
            "config":  layer_config,
            "version": layer_version,
        }

    def save_last_run(self):
        try:
            db = get_db()
            if self._current_run_id is None:
                self._current_run_id = db.start_run(self.last_run_meta.get("max_customers", 500))

            customers = len(self.scored_df) if self.scored_df is not None else 0
            nodes = self.G.number_of_nodes() if self.G is not None else 0
            edges = self.G.number_of_edges() if self.G is not None else 0
            duration = self.last_run_meta.get("duration_sec", 0)

            # v16.73: Inject fingerprint into meta BEFORE finish_run so it is
            # persisted inside the DB metadata blob and survives server restarts.
            if self._last_run_fingerprint and self._last_run_layer_hashes:
                self.last_run_meta["_fingerprint"]  = self._last_run_fingerprint
                self.last_run_meta["_layer_hashes"] = self._last_run_layer_hashes
                self.last_run_meta["_run_params"]   = self._last_run_params

            db.finish_run(
                self._current_run_id,
                duration,
                customers,
                nodes,
                edges,
                status="success",
                meta=self.last_run_meta,
            )
            if self.tables:
                db.save_raw_tables(self._current_run_id, self.tables)
            if self.scored_df is not None:
                db.save_scored(self._current_run_id, self.scored_df)
            if self.analytics_results:
                db.save_analytics(self._current_run_id, self.analytics_results)
            if self.G is not None:
                db.save_graph(self._current_run_id, self.G)
            if self.reports:
                db.save_reports(self._current_run_id, self.reports)

            self.audit.log(
                "PERSIST_SAVE", f"Run {self._current_run_id}: {customers} customers, {nodes} nodes"
            )
            log_audit(
                "PERSIST_SAVE",
                f"Run {self._current_run_id} saved to SQLite: {customers} customers, {nodes} nodes",
            )
            # v16.8 H2: Persist FULL tables to Parquet vault (bypasses 5k row preview limit)
            try:
                vault = get_vault()
                if vault and self.tables:
                    for tname, tdf in self.tables.items():
                        if tdf is not None and len(tdf) > 0:
                            vault.store(f"run_{self._current_run_id}_{tname}", tdf)
            except Exception:
                pass  # vault is advisory — never block pipeline save
            # v16.8 H1: Flush in-memory audit trail to SQLite after each successful save
            try:
                self.audit.flush_to_db(get_db(), run_id=self._current_run_id)
            except Exception:
                pass
        except Exception as e:
            log_error(f"Failed to save run: {e}", exc=e)
            self.audit.log("PERSIST_SAVE_FAIL", str(e), severity="ERROR")

    def load_last_run(self) -> bool:
        try:
            db = get_db()
            data = db.load_latest_run()
            if not data:
                return False

            run_info = data["run_info"]
            self.last_run_meta = {
                "saved_at": run_info.get("finished_at", ""),
                "customers": run_info.get("customers", 0),
                "graph_nodes": run_info.get("nodes", 0),
                "graph_edges": run_info.get("edges", 0),
                "run_id": run_info.get("run_id"),
                "families": list(data.get("analytics", {}).keys()),
            }

            if data.get("scored_df") is not None:
                self.scored_df = data["scored_df"]
            if data.get("graph") is not None:
                self.G = data["graph"]
                self.graph.graph = self.G
                self.graph.node_count = self.G.number_of_nodes()
                self.graph.edge_count = self.G.number_of_edges()
            if data.get("analytics"):
                self.analytics_results = data["analytics"]
                self.analytics.results = self.analytics_results
            if data.get("raw_tables"):
                self.tables = data["raw_tables"]
            if data.get("reports"):
                self.reports = data["reports"]

            self._cycles_cache = None
            self._lobbies_cache = None
            self._important_nodes_cache = None

            # v16.73: Restore 4-layer fingerprint from persisted metadata.
            # This means cache-hit detection survives a server restart.
            try:
                _meta_fp = run_info.get("metadata", {})
                if isinstance(_meta_fp, str):
                    import json as _json_fp
                    _meta_fp = _json_fp.loads(_meta_fp)
                self._last_run_fingerprint   = _meta_fp.get("_fingerprint")
                self._last_run_layer_hashes  = _meta_fp.get("_layer_hashes", {})
                self._last_run_params        = _meta_fp.get("_run_params", {})
            except Exception:
                pass  # non-fatal: FP will be recomputed on next run

            # v16.48 AUDIT-FIX: Restore stage_results from persisted metadata so
            # Dashboard stage timeline and total-duration display correctly after
            # an app restart — previously stage_results stayed [] after load.
            try:
                _meta_from_db = run_info.get("metadata", {})
                if isinstance(_meta_from_db, str):
                    import json as _json
                    _meta_from_db = _json.loads(_meta_from_db)
                _sr_raw = _meta_from_db.get("stage_results", [])
                if _sr_raw:
                    self.stage_results = [PipelineStageResult(**sr) for sr in _sr_raw]
            except Exception:
                pass  # non-fatal: stage_results stays [] if meta missing or malformed

            # v12.12: Mark progress as complete so Dashboard can display
            # persisted algo summary without requiring a fresh pipeline run
            if self.analytics_results:
                self.progress._overall_pct = 100
                self.progress._message = "Loaded from persistence"
                self.progress._last_successful_stage = len(PipelineProgress.STAGES) - 1

            self.audit.log(
                "PERSIST_LOAD",
                f"Loaded run {run_info.get('run_id')}: {run_info.get('customers', 0)} customers",
            )
            log_audit(
                "PERSIST_LOAD",
                f"Loaded run {run_info.get('run_id')}: {run_info.get('customers', 0)} customers",
            )
            return True
        except Exception as e:
            log_error(f"Failed to load last run: {e}", exc=e)
            self.audit.log("PERSIST_LOAD_FAIL", str(e), severity="ERROR")
            return False

    # =========================================================================
    # PIPELINE RUN — v10: Resume/Retry (E1)
    # =========================================================================
    def run(
        self,
        sources: Dict[str, pd.DataFrame] = None,
        analytics_params: Dict[str, Any] = None,
        scoring_weights: Dict[str, float] = None,
        start_stage: int = 0,
        max_customers: int = 10,
        resume: bool = False,
        parallel: bool = True,
        sample_size: int = None,
        progressive: bool = False,
        norm_method: str = None,  # v16.4 GAP-7: 'rank'|'minmax'|'zscore'|'robust'
        tier_override: dict = None,  # v16.4 GAP-2/9: {mode, p1, p2, p3} from UI
    ) -> PipelineResult:
        """Execute pipeline with resume/retry + performance support. v12.4."""
        self._perf_settings = {
            "parallel": parallel,
            "sample_size": sample_size,
            "progressive": progressive,
        }
        # v10 E1: Resume from last successful stage
        if resume and self.progress.get_status().get("last_successful_stage", -1) >= 0:
            resume_stage = self.progress.get_status()["last_successful_stage"] + 1
            if resume_stage > start_stage:
                start_stage = resume_stage
                self.audit.log(
                    "PIPELINE_RESUME", f"Resuming from stage {start_stage}", severity="WARNING"
                )

        log_audit(
            "SYSTEM_IDENTITY",
            "AIM Network Analyzer v16.56.0 | Developer: Das Apurba | "
            "Team: FCDAI Analytics | For modifications contact Das Apurba",
        )
        log_audit("PIPELINE_START", f"Stage {start_stage} | Max customers: {max_customers}")
        self.audit.log("PIPELINE_START", f"Stage {start_stage}, Max customers: {max_customers}")

        start_time = time.time()
        self.stage_results = []
        self.progress.start()

        # v12.13: For NEW runs (not resume), clear stale persistence-loaded
        # tables unless user explicitly pushed data from Port Authority.
        # This prevents stale/partial tables from corrupting the pipeline.
        # v16.8 M3: use _cleansed_event (threading.Event) for proper cross-thread visibility
        if not resume and not self._cleansed_event.is_set():
            if self.tables:
                log_audit(
                    "PIPELINE_CLEAR_STALE",
                    f"Clearing {len(self.tables)} stale persistence " f"tables for fresh run",
                )
            self.tables = {}

        # v12.9: Clear caches at START of run to prevent stale data during
        # background execution while other pages may be reading
        self._cycles_cache = None
        self._lobbies_cache = None
        self._important_nodes_cache = None

        # Memory check before starting
        mem_status = self.mem_monitor.get_status()
        if mem_status["level"] == "critical":
            self.mem_monitor.force_gc()
            self.audit.log(
                "MEMORY_WARNING",
                f"RSS={mem_status['rss_mb']:.0f}MB — forced GC",
                severity="WARNING",
            )

        overrides = self.load_config_overrides()
        if overrides.get("scoring_weights"):
            scoring_weights = overrides["scoring_weights"]
        if overrides.get("max_customers"):
            max_customers = overrides["max_customers"]

        db = get_db()
        self._current_run_id = db.start_run(max_customers)

        success = True

        if start_stage <= 1:
            try:
                self.progress.update_stage(0, "running", "Ingesting & validating data...")
                self._run_stage_01(sources, max_customers)
                self.progress.update_stage(0, "done")
                self.audit.log("STAGE_COMPLETE", "Stage 0-1: Ingest & Validate")
            except Exception as e:
                log_error(f"Stage 0-1 failed: {e}", exc=e)
                self.audit.log("STAGE_FAIL", f"Stage 0-1: {e}", severity="ERROR")
                success = False
            gc.collect()
            # v15.11: honour stop_requested between stages
            if success and self.progress.stop_requested:
                success = False
                self.audit.log("PIPELINE_STOPPED", "User stop after Stage 0-1", severity="WARNING")

        if success and start_stage <= 2:
            try:
                self.progress.update_stage(1, "running", "Aggregating features...")
                self._run_stage_2()
                self.progress.update_stage(1, "done")
                self.audit.log("STAGE_COMPLETE", "Stage 2: Aggregation")
            except Exception as e:
                log_error(f"Stage 2 failed: {e}", exc=e)
                self.audit.log("STAGE_FAIL", f"Stage 2: {e}", severity="ERROR")
                success = False
            gc.collect()
            # v15.11: honour stop_requested between stages
            if success and self.progress.stop_requested:
                success = False
                self.audit.log("PIPELINE_STOPPED", "User stop after Stage 2", severity="WARNING")

        if success and start_stage <= 4:
            try:
                self.progress.update_stage(2, "running", "Building transaction graph...")
                self._run_stage_34()
                self.progress.update_stage(2, "done")
                self.audit.log("STAGE_COMPLETE", "Stage 3-4: Graph Construction")
            except Exception as e:
                log_error(f"Stage 3-4 failed: {e}", exc=e)
                self.audit.log("STAGE_FAIL", f"Stage 3-4: {e}", severity="ERROR")
                success = False
            gc.collect()
            # v15.11: honour stop_requested between stages
            if success and self.progress.stop_requested:
                success = False
                self.audit.log("PIPELINE_STOPPED", "User stop after Stage 3-4", severity="WARNING")

        if success and start_stage <= 5:
            try:
                mode_lbl = []
                if parallel:
                    mode_lbl.append("parallel")
                if sample_size:
                    mode_lbl.append(f"sampled({sample_size})")
                if progressive:
                    mode_lbl.append("progressive")
                mode_str = "+".join(mode_lbl) if mode_lbl else "sequential"
                self.progress.update_stage(
                    3, "running", f"Running 10-family analytics [{mode_str}]..."
                )
                self._run_stage_5(
                    analytics_params,
                    parallel=parallel,
                    sample_size=sample_size,
                    progressive=progressive,
                )
                self.progress.update_stage(3, "done")
                self.audit.log("STAGE_COMPLETE", "Stage 5: Analytics (10-Family)")
            except Exception as e:
                log_error(f"Stage 5 failed: {e}", exc=e)
                self.audit.log("STAGE_FAIL", f"Stage 5: {e}", severity="ERROR")
                success = False
            gc.collect()
            # v15.11: honour stop_requested between stages
            if success and self.progress.stop_requested:
                success = False
                self.audit.log("PIPELINE_STOPPED", "User stop after Stage 5", severity="WARNING")

        if success and start_stage <= 6:
            try:
                self.progress.update_stage(4, "running", "Scoring risk...")
                self._run_stage_68(
                    scoring_weights, norm_method=norm_method, tier_override=tier_override
                )
                self.progress.update_stage(4, "done")
                self.audit.log("STAGE_COMPLETE", "Stage 6-8: Scoring & Reporting")
            except Exception as e:
                log_error(f"Stage 6-8 failed: {e}", exc=e)
                self.audit.log("STAGE_FAIL", f"Stage 6-8: {e}", severity="ERROR")
                success = False
            gc.collect()

        self.progress.update_stage(5, "running", "Saving results...")

        total_time = (time.time() - start_time) * 1000
        duration_sec = time.time() - start_time

        tier_dist = self.scoring.get_tier_distribution() if self.scored_df is not None else {}
        result = PipelineResult(
            success=success,
            total_duration_ms=round(total_time, 1),
            stages=self.stage_results,
            customers_processed=len(self.scored_df) if self.scored_df is not None else 0,
            alerts_generated=len(self.reports.get("narratives", {})) if self.reports else 0,
            tier_distribution=tier_dist,
        )

        if success:
            # v12.14: Record which tables the user selected (for readiness display)
            selected = getattr(self, "_selected_table_names", None)
            if not selected:
                selected = list(self.tables.keys())

            self.last_run_meta.update(
                {
                    "max_customers": max_customers,
                    "duration_sec": round(duration_sec, 2),
                    "graph_nodes": self.G.number_of_nodes() if self.G else 0,
                    "graph_edges": self.G.number_of_edges() if self.G else 0,
                    "tier_distribution": tier_dist,
                    "saved_at": datetime.now().isoformat(),
                    "customers": len(self.scored_df) if self.scored_df is not None else 0,
                    "version": APP.VERSION,
                    "families": 10,
                    "weights": scoring_weights or {},
                    "norm_method": norm_method or "rank",  # v16.4: audit trail
                    "tier_override": tier_override or {},  # v16.4: audit trail
                    "perf_settings": getattr(self, "_perf_settings", {}),
                    "selected_tables": selected,
                    "data_mode": self._data_mode,
                    "max_customers_applied": getattr(self, "_max_customers_applied", max_customers),
                    "run_tables_snapshot": getattr(self, "_run_tables_snapshot", {}),
                    # v16.48 AUDIT-FIX: serialise stage results so they survive app restarts.
                    # Dashboard stage timeline / total-duration displays correctly after reload.
                    "stage_results": [
                        r.model_dump() for r in self.stage_results
                    ] if self.stage_results else [],
                }
            )
            self.save_last_run()
            self.run_version += 1
            self._cycles_cache = None
            self._lobbies_cache = None
            self._important_nodes_cache = None
            self.audit.log(
                "PIPELINE_COMPLETE",
                f"Duration={total_time:.0f}ms, Customers={result.customers_processed}",
            )
        else:
            db.finish_run(self._current_run_id, duration_sec, 0, 0, 0, status="failed")
            self.audit.log("PIPELINE_FAILED", f"Duration={total_time:.0f}ms", severity="ERROR")

        self.progress.update_stage(5, "done")
        self.progress.finish(success)

        log_audit(
            "PIPELINE_COMPLETE",
            f"Success={success} | Duration={total_time:.0f}ms | "
            f"Customers={result.customers_processed} | Tiers={tier_dist}",
        )
        return result

    def _run_stage_01(self, sources=None, max_customers: int = 10):
        t0 = time.time()
        # v12.36: RESILIENT TABLE DETECTION
        # ------------------------------------
        # The pipeline now supports TWO minimum-viable table sets:
        #   A) Graph-schema mode : "node" + "edge" tables present
        #   B) Legacy mode       : "customer" + "transaction" tables present
        # ALL other tables are OPTIONAL in both modes.
        # If neither minimum set is present, generate sample data (all 13 tables).

        GRAPH_SCHEMA_TABLES = {"node", "edge"}
        LEGACY_REQUIRED_TABLES = {"customer", "transaction"}

        if sources:
            self.tables = sources
        elif self.tables and len(self.tables) > 0:
            pass  # Use existing tables (e.g., from Port Authority push)
        else:
            # v15.2 Task3: NO AUTO-GENERATION — data must come from Port Authority.
            # Reaching here means the dashboard started a run without PA data,
            # which should have been caught by the UI gate. Raise so the error
            # surfaces cleanly rather than silently generating dummy data.
            raise RuntimeError(
                "No data available. Load and push data via Port Authority first. "
                "Auto-generation is disabled in v15.2+."
            )

        # --- Detect data mode ---
        present = set(self.tables.keys())
        has_graph_schema = GRAPH_SCHEMA_TABLES.issubset(present)
        has_legacy = LEGACY_REQUIRED_TABLES.issubset(present)

        if has_graph_schema:
            # GRAPH-SCHEMA MODE: node + edge tables found
            self._data_mode = "graph_schema"
            log_audit(
                "STAGE01_MODE",
                f"Graph-schema mode: node+edge present. "
                f"Optional tables: {sorted(present - GRAPH_SCHEMA_TABLES)}",
            )
            self.audit.log("DATA_MODE", "graph_schema — node+edge direct path")
        elif has_legacy:
            # LEGACY MODE: customer + transaction tables found
            self._data_mode = "legacy"
            log_audit(
                "STAGE01_MODE",
                f"Legacy mode: customer+transaction present. "
                f"Optional tables: {sorted(present - LEGACY_REQUIRED_TABLES)}",
            )
            self.audit.log("DATA_MODE", "legacy — customer+transaction aggregation path")
        else:
            # NEITHER minimum set present — v15.2 Task3: raise instead of supplementing.
            # PA data should always be complete. If it's missing required tables,
            # surface the error so the user can fix their data in Port Authority.
            missing_graph = sorted(GRAPH_SCHEMA_TABLES - present)
            missing_legacy = sorted(LEGACY_REQUIRED_TABLES - present)
            raise RuntimeError(
                f"Incomplete data: tables present={sorted(present)}. "
                f"Need either {sorted(GRAPH_SCHEMA_TABLES)} (graph) or "
                f"{sorted(LEGACY_REQUIRED_TABLES)} (legacy). "
                f"Push complete data via Port Authority first."
            )

        records_in = sum(len(df) for df in self.tables.values())

        # ── v12.44 Task 3: MAX CUSTOMERS FILTER ────────────────────────────
        # max_customers is a FINAL top-level filter applied on top of whatever
        # data was pushed from Port Authority (or generated).  If the user
        # pushed 500 nodes but set max_customers=150, we randomly sample 150
        # unique entity IDs and filter ALL tables to that subset so every
        # downstream stage, report, and readiness display reflects the same
        # filtered dataset.
        self._max_customers_applied = max_customers  # track what was applied
        _total_entities = 0
        if self._data_mode == "graph_schema" and "node" in self.tables:
            _total_entities = len(self.tables["node"])
        elif "customer" in self.tables:
            _total_entities = len(self.tables["customer"])

        if max_customers and _total_entities > max_customers:
            import numpy as np

            if self._data_mode == "graph_schema" and "node" in self.tables:
                node_df = self.tables["node"]
                # Determine the ID column in node table
                _node_id_col = next(
                    (
                        c
                        for c in ["node_id", "id", "customer_id", "entity_id"]
                        if c in node_df.columns
                    ),
                    node_df.columns[0],
                )
                sampled_ids = set(
                    node_df[_node_id_col]
                    .sample(n=max_customers, random_state=APP.RANDOM_SEED)
                    .tolist()
                )
                self.tables["node"] = node_df[node_df[_node_id_col].isin(sampled_ids)].reset_index(
                    drop=True
                )
                # Filter edge table to keep only edges where BOTH endpoints
                # are in the sampled set
                if "edge" in self.tables:
                    edge_df = self.tables["edge"]
                    _src_col = next(
                        (c for c in ["source", "src", "from", "source_id"] if c in edge_df.columns),
                        edge_df.columns[0],
                    )
                    _tgt_col = next(
                        (c for c in ["target", "tgt", "to", "target_id"] if c in edge_df.columns),
                        edge_df.columns[1] if len(edge_df.columns) > 1 else edge_df.columns[0],
                    )
                    self.tables["edge"] = edge_df[
                        edge_df[_src_col].isin(sampled_ids) & edge_df[_tgt_col].isin(sampled_ids)
                    ].reset_index(drop=True)
                # Filter other tables (customer, account, etc.) by their ID
                _id_candidates = ["customer_id", "node_id", "id", "entity_id", "account_id"]
                for tname in list(self.tables.keys()):
                    if tname in ("node", "edge"):
                        continue
                    tdf = self.tables[tname]
                    _match_col = next((c for c in _id_candidates if c in tdf.columns), None)
                    if _match_col:
                        self.tables[tname] = tdf[tdf[_match_col].isin(sampled_ids)].reset_index(
                            drop=True
                        )
                log_audit(
                    "MAX_CUSTOMERS_FILTER",
                    f"Sampled {max_customers} from {_total_entities} "
                    f"entities (graph_schema mode). "
                    f"Node: {len(self.tables['node'])}, "
                    f"Edge: {len(self.tables.get('edge', []))}",
                )
            else:
                # Legacy mode — filter by customer table
                cust_df = self.tables["customer"]
                _cust_id_col = next(
                    (c for c in ["customer_id", "id", "cust_id"] if c in cust_df.columns),
                    cust_df.columns[0],
                )
                sampled_ids = set(
                    cust_df[_cust_id_col].sample(n=max_customers, random_state=42).tolist()
                )
                self.tables["customer"] = cust_df[
                    cust_df[_cust_id_col].isin(sampled_ids)
                ].reset_index(drop=True)
                # Filter transaction table
                if "transaction" in self.tables:
                    txn_df = self.tables["transaction"]
                    _txn_id_col = next(
                        (c for c in ["customer_id", "sender_id", "source"] if c in txn_df.columns),
                        None,
                    )
                    if _txn_id_col:
                        self.tables["transaction"] = txn_df[
                            txn_df[_txn_id_col].isin(sampled_ids)
                        ].reset_index(drop=True)
                # Filter other tables by customer_id if present
                for tname in list(self.tables.keys()):
                    if tname in ("customer", "transaction"):
                        continue
                    tdf = self.tables[tname]
                    if "customer_id" in tdf.columns:
                        self.tables[tname] = tdf[tdf["customer_id"].isin(sampled_ids)].reset_index(
                            drop=True
                        )
                log_audit(
                    "MAX_CUSTOMERS_FILTER",
                    f"Sampled {max_customers} from {_total_entities} "
                    f"customers (legacy mode). "
                    f"Customer: {len(self.tables['customer'])}",
                )
            self.audit.log(
                "MAX_CUSTOMERS_FILTER",
                f"Applied max_customers={max_customers} filter "
                f"on {_total_entities} total entities",
            )
        # ── End max customers filter ───────────────────────────────────────

        dq_reports = self.validate.assess_all(self.tables)
        # v12.12: Skip re-cleansing if tables were already cleansed by
        # Port Authority push — prevents destructive double-cleansing
        # v16.8 M3: use _cleansed_event.is_set() for thread-safe flag read
        if not self._cleansed_event.is_set():
            for name in list(self.tables.keys()):
                self.tables[name] = self.validate.cleanse(self.tables[name])
        self._cleansed_event.clear()  # Reset for next run
        records_out = sum(len(df) for df in self.tables.values())

        # v12.44 Task 4: Store snapshot of tables that ACTUALLY entered the
        # pipeline (post max-customers filter) so Data Readiness and reports
        # can show accurate counts matching the analysis.
        self._run_tables_snapshot = {
            k: {
                "rows": len(v),
                "cols": len(v.columns),
                "completeness": round((v.count().sum() / max(len(v) * len(v.columns), 1)) * 100),
            }
            for k, v in self.tables.items()
            if v is not None and len(v) > 0
        }

        self.stage_results.append(
            PipelineStageResult(
                stage=1,
                name="Ingest & Validate",
                success=True,
                duration_ms=round((time.time() - t0) * 1000, 1),
                records_in=records_in,
                records_out=records_out,
                summary={
                    "tables": len(self.tables),
                    "data_mode": self._data_mode,
                    "max_customers_applied": max_customers,
                    "entities_before_filter": _total_entities,
                    "entities_after_filter": records_out,
                    "overall_dq": self.validate.get_overall_report().get("overall_score", 0),
                },
            )
        )

    def _run_stage_2(self):
        t0 = time.time()
        records_in = sum(len(df) for df in self.tables.values())

        if self._data_mode == "graph_schema":
            # v12.36: GRAPH-SCHEMA MODE — bypass traditional aggregation.
            # Convert node table → customer_features, edge table → edges
            # directly. This allows the app to run with ONLY 2 tables.
            self.customer_features, self.edges = self.aggregate.run_graph_schema(self.tables)
            self.audit.log(
                "STAGE2_GRAPH_SCHEMA",
                f"Direct graph-schema: {len(self.customer_features)} nodes, "
                f"{len(self.edges)} edges",
            )
        else:
            # LEGACY MODE — standard aggregation from customer+transaction tables
            self.customer_features, self.edges = self.aggregate.run(self.tables)

        self.stage_results.append(
            PipelineStageResult(
                stage=2,
                name="Aggregation",
                success=True,
                duration_ms=round((time.time() - t0) * 1000, 1),
                records_in=records_in,
                records_out=len(self.customer_features),
                summary=self.aggregate.get_summary(),
            )
        )

    def _run_stage_34(self):
        t0 = time.time()
        if self.customer_features is None:
            self.customer_features = pd.DataFrame({"customer_id": []})
        if self.edges is None:
            self.edges = pd.DataFrame(
                columns=["source", "target", "weight", "txn_count", "edge_type"]
            )
        self.G = self.graph.build(self.customer_features, self.edges)
        self.stage_results.append(
            PipelineStageResult(
                stage=4,
                name="Graph Construction",
                success=True,
                duration_ms=round((time.time() - t0) * 1000, 1),
                records_in=len(self.customer_features),
                records_out=self.graph.node_count,
                summary=self.graph.get_summary(),
            )
        )

    def _run_stage_5(self, params=None, parallel=True, sample_size=None, progressive=False):
        t0 = time.time()
        if self.G is None:
            self.G = nx.DiGraph()

        def _progress_cb(stage_name, info):
            """Progressive analytics callback — updates progress message."""
            completed = info.get("completed", [])
            pending = info.get("pending", [])
            if stage_name == "stage1_done":
                self.progress.update_stage(
                    3,
                    "running",
                    f"Fast families done ({len(completed)}/10) — "
                    f"computing {len(pending)} slow families...",
                )

        # v16.8 M2: pass stop_check so analytics layer can honour stop between families
        self.analytics_results = self.analytics.run_all(
            self.G,
            params,
            parallel=parallel,
            sample_size=sample_size,
            progressive=progressive,
            progress_callback=_progress_cb if progressive else None,
            stop_check=lambda: self.progress.stop_requested,
        )
        self.stage_results.append(
            PipelineStageResult(
                stage=5,
                name="Analytics (10-Family)",
                success=True,
                duration_ms=round((time.time() - t0) * 1000, 1),
                records_in=self.G.number_of_nodes(),
                records_out=self.G.number_of_nodes(),
                summary=self.analytics.get_summary(),
            )
        )

    def run_background(self, **kwargs) -> bool:
        """Start pipeline in background thread (v12.4). Returns immediately.

        v16.8 M5: non-blocking lock prevents two browser tabs launching simultaneously.
        Returns False if a run is already in progress.
        """
        if not self._run_lock.acquire(blocking=False):
            return False  # already running — silently reject

        def _run_and_release():
            try:
                self.run(**kwargs)
            finally:
                self._run_lock.release()

        self._bg_thread = threading.Thread(target=_run_and_release, daemon=True)
        self._bg_thread.start()
        return True

    def is_running(self) -> bool:
        """Check if background pipeline is still running."""
        if hasattr(self, "_bg_thread") and self._bg_thread is not None:
            return self._bg_thread.is_alive()
        return self.progress.get_status().get("running", False)

    def get_current_status(self) -> Dict:
        """v16.8 M4: Atomically combined status — get_status() + is_running() in one call.

        Prevents the race window where status["running"] is False but the background
        thread is still alive between two separate get_status() / is_running() checks.
        """
        status = self.progress.get_status()
        bg_alive = self.is_running()
        status["running"] = status["running"] or bg_alive
        return status

    def get_analytics_status(self) -> Dict:
        """Get progressive family-level status (v12.4)."""
        if hasattr(self.analytics, "get_family_status"):
            return self.analytics.get_family_status()
        return {"families": {}, "completed": 0, "total": 10, "cached": 0}

    def run_single_family(self, family_name: str, params: Dict = None) -> pd.DataFrame:
        if self.G is None:
            raise ValueError("Pipeline must be run first to build the graph")
        family_map = {
            "centrality": self.analytics._centrality,
            "community": self.analytics._community,
            "pathflow": self.analytics._pathflow,
            "link_prediction": self.analytics._link_prediction,
            "anomaly": self.analytics._anomaly,
            "temporal": self.analytics._temporal,
            "multi_layer": self.analytics._multi_layer,
            "structuring": self.analytics._structuring,
            "benfords": self.analytics._benfords,
            "motifs": self.analytics._motifs,
        }
        func = family_map.get(family_name)
        if func is None:
            raise ValueError(f"Unknown family: {family_name}")
        family_params = {**self.analytics.analytics_config.get(family_name, {}), **(params or {})}
        df = func(self.G, family_params)
        self.analytics_results[family_name] = df
        self.analytics.results[family_name] = df
        self.audit.log("SINGLE_FAMILY_RUN", f"Family: {family_name}, Nodes: {len(df)}")
        try:
            if self._current_run_id or self.last_run_meta.get("run_id"):
                db = get_db()
                run_id = self._current_run_id or self.last_run_meta.get("run_id")
                db.save_analytics(run_id, {family_name: df})
        except Exception:
            pass
        return df

    def _run_stage_68(self, weights=None, norm_method=None, tier_override=None):
        t0 = time.time()
        # v16.5 Rule-12: validate + normalise scoring weights before passing to scoring layer
        weights = _validate_scoring_weights(weights, self.audit)
        # v16.5 Rule-14: graph integrity check (NaN/negative edges, isolated nodes)
        if self.G is not None:
            _check_graph_integrity(self.G, self.audit)
        self.scored_df = self.scoring.score(
            self.analytics_results,
            weights,
            G=self.G,
            norm_method=norm_method,
            tier_override=tier_override,
        )  # v14.3: G for propagation | v16.4: norm_method + tier_override
        if self.G is not None and self.scored_df is not None:
            for _, row in self.scored_df.iterrows():
                nid = row["node_id"]
                if nid in self.G.nodes:
                    self.G.nodes[nid]["risk_score"] = row["risk_score"]
                    self.G.nodes[nid]["risk_tier"] = row["risk_tier"]
        self.reports = self.reporting.generate_reports(
            self.scored_df, self.G, self.analytics_results
        )
        self.stage_results.append(
            PipelineStageResult(
                stage=8,
                name="Scoring & Reporting",
                success=True,
                duration_ms=round((time.time() - t0) * 1000, 1),
                records_in=len(self.scored_df) if self.scored_df is not None else 0,
                records_out=len(self.reports.get("narratives", {})) if self.reports else 0,
                summary=self.scoring.get_summary(),
            )
        )

    # =========================================================================
    # v10 A1: GEO-RISK DATA  (CRIT-01 fix: single definition, sanctions-first)
    # =========================================================================

    # =========================================================================
    # v10 A2: CUSTOMER 360
    # =========================================================================
    def get_customer_360(self, node_id: str) -> Dict:
        """Get comprehensive 360-degree view of a customer."""
        if self.G is None or node_id not in self.G.nodes:
            return {}

        attrs = self.G.nodes[node_id]
        scored_row = {}
        if self.scored_df is not None:
            match = self.scored_df[self.scored_df["node_id"] == node_id]
            if len(match) > 0:
                scored_row = match.iloc[0].to_dict()

        # Neighbors
        in_neighbors = list(self.G.predecessors(node_id))
        out_neighbors = list(self.G.successors(node_id))

        # Analytics per family
        family_scores = {}
        for family_name, df in self.analytics_results.items():
            if "node_id" in df.columns:
                match = df[df["node_id"] == node_id]
                if len(match) > 0:
                    family_scores[family_name] = {
                        k: v for k, v in match.iloc[0].to_dict().items() if k != "node_id"
                    }

        # Edge details
        edges_in = []
        for src in in_neighbors[:20]:
            ed = self.G.get_edge_data(src, node_id, default={})
            edges_in.append(
                {"from": src, "amount": ed.get("weight", 0), "type": ed.get("edge_type", "unknown")}
            )
        edges_out = []
        for dst in out_neighbors[:20]:
            ed = self.G.get_edge_data(node_id, dst, default={})
            edges_out.append(
                {"to": dst, "amount": ed.get("weight", 0), "type": ed.get("edge_type", "unknown")}
            )

        narrative = self.reporting.get_narrative(node_id) if hasattr(self, "reporting") else ""

        self.audit.log("CUSTOMER_360_ACCESS", f"Node: {mask_for_log(node_id)}")
        return {
            "node_id": node_id,
            "attributes": attrs,
            "scored": scored_row,
            "family_scores": family_scores,
            "in_neighbors": in_neighbors[:50],
            "out_neighbors": out_neighbors[:50],
            "edges_in": edges_in,
            "edges_out": edges_out,
            "narrative": narrative,
            "in_degree": self.G.in_degree(node_id),
            "out_degree": self.G.out_degree(node_id),
        }

    # =========================================================================
    # v10 A3: COMPARATIVE RUNS
    # =========================================================================
    def get_comparative_data(self, run_id_a: int = None, run_id_b: int = None) -> Dict:
        """Compare two pipeline runs — risk drift, score changes."""
        db = get_db()
        history = db.get_run_history()
        if history is None or len(history) < 2:
            return {"error": "Need at least 2 runs to compare"}

        if run_id_a is None:
            run_id_a = history.iloc[-2]["run_id"] if len(history) >= 2 else None
        if run_id_b is None:
            run_id_b = history.iloc[-1]["run_id"] if len(history) >= 1 else None

        if run_id_a is None or run_id_b is None:
            return {"error": "Cannot determine runs to compare"}

        try:
            data_a = db.load_run(int(run_id_a)) if hasattr(db, "load_run") else None
            data_b = db.load_run(int(run_id_b)) if hasattr(db, "load_run") else None

            # If load_run not available, use current vs meta
            comparison = {
                "run_a": {
                    "id": run_id_a,
                    "info": (
                        history[history["run_id"] == run_id_a].iloc[0].to_dict()
                        if len(history[history["run_id"] == run_id_a]) > 0
                        else {}
                    ),
                },
                "run_b": {
                    "id": run_id_b,
                    "info": (
                        history[history["run_id"] == run_id_b].iloc[0].to_dict()
                        if len(history[history["run_id"] == run_id_b]) > 0
                        else {}
                    ),
                },
                "drift_summary": {},
            }

            self.audit.log("COMPARATIVE_RUN", f"Compare run {run_id_a} vs {run_id_b}")
            return comparison
        except Exception as e:
            self.audit.log("COMPARATIVE_FAIL", str(e), severity="ERROR")
            return {"error": str(e)}

    # =========================================================================
    # CYCLE DETECTION (from v9)
    # =========================================================================
    def detect_cycles(self, max_length: int = 6, max_results: int = 50) -> List[Dict]:
        if self._cycles_cache is not None:
            return self._cycles_cache
        if self.G is None or self.G.number_of_nodes() == 0:
            return []
        try:
            raw_cycles = []
            if _HAS_IGRAPH:
                nodes_list = list(self.G.nodes())
                node_map = {n: i for i, n in enumerate(nodes_list)}
                edges = [
                    (node_map[u], node_map[v])
                    for u, v in self.G.edges()
                    if u in node_map and v in node_map
                ]
                g = ig.Graph(n=len(nodes_list), edges=edges, directed=True)
                g.vs["name"] = nodes_list
                for v_id in range(min(g.vcount(), 500)):
                    if len(raw_cycles) >= max_results * 3:
                        break
                    nbs = g.neighborhood(v_id, order=max_length, mode="out")
                    if len(nbs) < 3:
                        continue
                    sub = g.subgraph(nbs)
                    try:
                        for edge in sub.es:
                            s, t = edge.source, edge.target
                            try:
                                paths = sub.get_all_shortest_paths(t, to=s, mode="out")
                                for p in paths:
                                    if len(p) >= 3 and len(p) <= max_length:
                                        cycle_ids = [sub.vs[i]["name"] for i in p]
                                        if (
                                            len(set(cycle_ids)) == len(cycle_ids)
                                            and len(cycle_ids) >= 3
                                        ):
                                            raw_cycles.append(cycle_ids)
                                            if len(raw_cycles) >= max_results * 3:
                                                break
                            except Exception:
                                continue
                    except Exception:
                        continue
            else:
                for cycle in nx.simple_cycles(self.G, length_bound=max_length):
                    if len(raw_cycles) >= max_results * 3:
                        break
                    if len(cycle) >= 3:
                        raw_cycles.append(cycle)

            seen = set()
            cycles = []
            count = 0
            for cycle in raw_cycles:
                key = tuple(sorted(cycle))
                if key in seen:
                    continue
                seen.add(key)
                if count >= max_results:
                    break
                total_amount = 0
                risk_sum = 0
                edges_info = []
                for i in range(len(cycle)):
                    src = cycle[i]
                    dst = cycle[(i + 1) % len(cycle)]
                    edge_data = self.G.get_edge_data(src, dst, default={})
                    amt = edge_data.get("weight", edge_data.get("amount", 0))
                    total_amount += amt
                    risk = self.G.nodes.get(src, {}).get("risk_score", 0) or 0
                    risk_sum += risk
                    edges_info.append({"from": src, "to": dst, "amount": amt})
                avg_risk = risk_sum / len(cycle) if cycle else 0
                cycles.append(
                    {
                        "cycle_id": count + 1,
                        "nodes": cycle,
                        "length": len(cycle),
                        "total_amount": round(total_amount, 2),
                        "avg_risk": round(avg_risk, 2),
                        "risk_sum": round(risk_sum, 2),
                        "edges": edges_info,
                        "initiator": cycle[0],
                    }
                )
                count += 1
            cycles.sort(key=lambda x: x["risk_sum"], reverse=True)
            self._cycles_cache = cycles
            return cycles
        except Exception as e:
            log_error(f"Cycle detection failed: {e}", exc=e)
            return []

    # =========================================================================
    # LOBBY DETECTION (from v9)
    # =========================================================================
    def detect_lobbies(self, max_rings: int = None) -> List[Dict]:
        if self._lobbies_cache is not None:
            return self._lobbies_cache
        # v15.16: scale max_rings and max_results dynamically with graph size
        # max_rings  = min( max(50, n_nodes // 2), 500 )  e.g. 500 nodes -> 250 rings
        # max_results = max(80,  n_nodes // 3)             e.g. 500 nodes -> 166 per bucket
        n_nodes = self.G.number_of_nodes() if self.G else 0
        if max_rings is None:
            max_rings = min(max(50, n_nodes // 2), 500)
        max_cyc_results = max(80, n_nodes // 3)
        # v12.33: Search multiple cycle lengths with stratified selection
        # to guarantee variety of ring sizes (3-8 members)
        all_cycles = []
        seen_keys = set()
        cycles_by_size = {}  # {length: [cycles...]}
        for ml in [3, 4, 5, 6, 7, 8]:
            self._cycles_cache = None  # reset so each length runs fresh
            batch = self.detect_cycles(max_length=ml, max_results=max_cyc_results) or []
            for cyc in batch:
                key = tuple(sorted(cyc["nodes"]))
                if key not in seen_keys:
                    seen_keys.add(key)
                    sz = cyc.get("length", len(cyc["nodes"]))
                    cycles_by_size.setdefault(sz, []).append(cyc)
        # Sort within each size bucket by avg_risk descending
        for sz in cycles_by_size:
            cycles_by_size[sz].sort(key=lambda c: c.get("avg_risk", 0), reverse=True)
        # Round-robin selection: pick from each size to ensure variety
        selected = []
        remaining = True
        idx = 0
        sizes_sorted = sorted(cycles_by_size.keys())
        while remaining and len(selected) < max_rings:
            remaining = False
            for sz in sizes_sorted:
                bucket = cycles_by_size[sz]
                if idx < len(bucket):
                    selected.append(bucket[idx])
                    remaining = True
                    if len(selected) >= max_rings:
                        break
            idx += 1
        # Final sort by avg_risk for presentation
        selected.sort(key=lambda c: c.get("avg_risk", 0), reverse=True)
        cycles = selected
        if not cycles:
            return []
        lobbies = []
        for i, cyc in enumerate(cycles[:max_rings]):
            nodes = cyc["nodes"]
            initiator = nodes[0]
            max_out = 0
            members = []
            for node in nodes:
                attrs = self.G.nodes.get(node, {})
                out_deg = self.G.out_degree(node) if node in self.G else 0
                in_deg = self.G.in_degree(node) if node in self.G else 0
                if out_deg > max_out:
                    max_out = out_deg
                    initiator = node
                members.append(
                    {
                        "node_id": node,
                        "risk_score": attrs.get("risk_score", 0) or 0,
                        "risk_tier": attrs.get("risk_tier", "P4"),
                        "in_degree": in_deg,
                        "out_degree": out_deg,
                        "in_flow": attrs.get("in_flow", 0),
                        "out_flow": attrs.get("out_flow", 0),
                    }
                )
            conduit = max(members, key=lambda m: m["in_degree"] + m["out_degree"])["node_id"]
            total_flow = sum(m["in_flow"] + m["out_flow"] for m in members)
            lobbies.append(
                {
                    "ring_id": i + 1,
                    "ring_name": f"Ring {i + 1}",
                    "size": len(nodes),
                    "nodes": nodes,
                    "members": members,
                    "initiator": initiator,
                    "conduit": conduit,
                    "total_amount": cyc["total_amount"],
                    "total_flow": round(total_flow, 2),
                    "avg_risk": cyc["avg_risk"],
                    "risk_sum": cyc["risk_sum"],
                    "edges": cyc["edges"],
                }
            )
        self._lobbies_cache = lobbies
        return lobbies

    # =========================================================================
    # IMPORTANT NODES (from v9)
    # =========================================================================
    def get_important_nodes(self, top_n: int = 50) -> pd.DataFrame:
        if self._important_nodes_cache is not None:
            return self._important_nodes_cache
        if self.G is None or self.G.number_of_nodes() == 0:
            return pd.DataFrame()
        try:
            nodes = list(self.G.nodes())
            if _HAS_IGRAPH:
                node_map = {n: i for i, n in enumerate(nodes)}
                edges = [
                    (node_map[u], node_map[v])
                    for u, v in self.G.edges()
                    if u in node_map and v in node_map
                ]
                g = ig.Graph(n=len(nodes), edges=edges, directed=True)
                g.vs["name"] = nodes
                pr_vals = g.pagerank(damping=0.85)
                bc_vals = g.betweenness(directed=True)
                max_bc = max(bc_vals) if bc_vals and max(bc_vals) > 0 else 1
                pr = dict(zip(nodes, pr_vals))
                bc = dict(zip(nodes, [b / max_bc for b in bc_vals]))
            else:
                pr = nx.pagerank(self.G, alpha=0.85)
                bc = nx.betweenness_centrality(self.G)
            rows = []
            for node in nodes:
                attrs = self.G.nodes[node]
                in_flow = attrs.get("in_flow", 0)
                out_flow = attrs.get("out_flow", 0)
                flow_ratio = (out_flow / in_flow) if in_flow > 0 else 0
                risk = attrs.get("risk_score", 0) or 0
                composite = (
                    pr.get(node, 0) * 30
                    + bc.get(node, 0) * 25
                    + min(flow_ratio, 5) * 5
                    + (risk / 100) * 40
                )
                rows.append(
                    {
                        "node_id": node,
                        "pagerank": round(pr.get(node, 0), 6),
                        "betweenness": round(bc.get(node, 0), 6),
                        "in_degree": self.G.in_degree(node),
                        "out_degree": self.G.out_degree(node),
                        "in_flow": round(in_flow, 2),
                        "out_flow": round(out_flow, 2),
                        "flow_ratio": round(flow_ratio, 3),
                        "risk_score": round(risk, 2),
                        "risk_tier": attrs.get("risk_tier", "P4"),
                        "composite_importance": round(composite, 4),
                    }
                )
            df = (
                pd.DataFrame(rows)
                .sort_values("composite_importance", ascending=False)
                .head(top_n)
                .reset_index(drop=True)
            )
            self._important_nodes_cache = df
            return df
        except Exception as e:
            log_error(f"Important nodes failed: {e}", exc=e)
            return pd.DataFrame()

    # =========================================================================
    # NETWORK STATS
    # =========================================================================
    def get_network_stats(self) -> Dict:
        if self.G is None:
            return {}
        try:
            return {
                "nodes": self.G.number_of_nodes(),
                "edges": self.G.number_of_edges(),
                "density": round(nx.density(self.G), 6),
                "avg_in_degree": round(
                    sum(d for _, d in self.G.in_degree()) / max(self.G.number_of_nodes(), 1), 2
                ),
                "avg_out_degree": round(
                    sum(d for _, d in self.G.out_degree()) / max(self.G.number_of_nodes(), 1), 2
                ),
                "components": nx.number_weakly_connected_components(self.G),
                "is_dag": nx.is_directed_acyclic_graph(self.G),
            }
        except Exception:
            return {"nodes": self.G.number_of_nodes(), "edges": self.G.number_of_edges()}

    # =========================================================================
    # ACCESSORS
    # =========================================================================
    def get_cytoscape_elements(self, max_nodes=1000):
        return self.graph.to_cytoscape_elements(max_nodes)

    def get_cytoscape_elements_scaled(
        self, max_nodes=5000, selection="composite", show_weights=True, performance_mode=False
    ):
        """v12.4: Scalable cytoscape element generation."""
        return self.graph.to_cytoscape_elements_scaled(
            max_nodes=max_nodes,
            selection=selection,
            show_weights=show_weights,
            performance_mode=performance_mode,
        )

    def get_graph_scale_info(self):
        """v12.4: Return scale metrics for the graph visualization UI."""
        return self.graph.get_scale_info()

    def get_node_details(self, node_id):
        return self.graph.get_node_details(node_id)

    def get_scored_df(self):
        return self.scored_df

    def get_investigation_queue(self):
        return self.reports.get("investigation_queue")

    def get_narrative(self, node_id):
        return self.reporting.get_narrative(node_id)

    def get_risk_matrix(self):
        return self.reports.get("risk_matrix", {})

    def get_analytics_results(self):
        return self.analytics_results

    def get_family_results(self, family: str):
        return self.analytics_results.get(family)

    def get_dq_reports(self):
        return self.validate.get_overall_report()

    def get_dq_detail(self) -> Dict:
        """
        v16.32 NEW-DQ3: Enriched DQ dict for the Data Quality infographic page.
        Returns per-table DQ scores PLUS extended checks (referential integrity,
        self-loops, future dates) and inventory of present/missing optional tables.
        Safe to call before pipeline runs — returns a graceful empty-state dict.
        """
        MANDATORY = {"node", "edge"}
        OPTIONAL = {"relationship", "shared_attribute", "temporal"}
        ALL_DQ_TABLES = MANDATORY | OPTIONAL

        # --- table inventory ---
        present = {t for t in ALL_DQ_TABLES if t in self.tables and self.tables[t] is not None and len(self.tables[t]) > 0}
        missing = ALL_DQ_TABLES - present

        node_df = self.tables.get("node")
        edge_df = self.tables.get("edge")

        # --- per-table DQ scores from existing assess_all results ---
        per_table = {}
        for tname in ALL_DQ_TABLES:
            if tname in self.validate.reports:
                r = self.validate.reports[tname]
                per_table[tname] = {
                    "present": tname in present,
                    "rows": r.total_rows,
                    "columns": r.total_columns,
                    "completeness": r.completeness,
                    "consistency": r.consistency,
                    "validity": r.validity,
                    "overall_score": r.overall_score,
                    "issues": r.issues,
                    "column_stats": r.column_stats,
                }
            else:
                per_table[tname] = {
                    "present": tname in present,
                    "rows": 0,
                    "columns": 0,
                    "completeness": None,
                    "consistency": None,
                    "validity": None,
                    "overall_score": None,
                    "issues": [],
                    "column_stats": {},
                }

        # --- extended checks (only possible after pipeline run) ---
        ref_integrity = {"orphan_count": 0, "orphan_sample": [], "issues": []}
        self_loops = {"self_loop_count": 0, "issues": []}
        future_dates = {"future_date_count": 0, "affected_columns": [], "issues": []}

        if node_df is not None and edge_df is not None:
            try:
                ref_integrity = self.validate.check_referential_integrity(node_df, edge_df)
            except Exception as _e:
                ref_integrity["issues"].append(str(_e))

        if edge_df is not None:
            try:
                self_loops = self.validate.check_self_loops(edge_df)
            except Exception as _e:
                self_loops["issues"].append(str(_e))

        for tname in ["temporal", "edge"]:
            if tname in self.tables and self.tables[tname] is not None:
                try:
                    fd = self.validate.check_future_dates(self.tables[tname])
                    future_dates["future_date_count"] += fd["future_date_count"]
                    future_dates["affected_columns"] += [
                        f"{tname}.{c}" for c in fd["affected_columns"]
                    ]
                    future_dates["issues"] += fd["issues"]
                except Exception:
                    pass

        # --- pipeline readiness ---
        block_result = self.validate.check_pipeline_block(
            required_tables=["node", "edge"],
            block_threshold=0.50,
            warn_threshold=0.75,
        )
        if block_result.get("blocked"):
            readiness = "BLOCKED"
        elif block_result.get("warnings"):
            readiness = "WARN"
        elif not present.issuperset(MANDATORY):
            readiness = "BLOCKED"
        else:
            readiness = "READY"

        return {
            "tables_present": sorted(present),
            "tables_missing": sorted(missing),
            "mandatory_ok": MANDATORY.issubset(present),
            "per_table": per_table,
            "referential_integrity": ref_integrity,
            "self_loops": self_loops,
            "future_dates": future_dates,
            "readiness": readiness,
            "block_detail": block_result,
            "has_data": bool(present),
        }

    def get_pipeline_summary(self):
        return {
            "stages": [r.model_dump() for r in self.stage_results],
            "tables_loaded": len(self.tables),
            "data_mode": self._data_mode,
            "customers": len(self.scored_df) if self.scored_df is not None else 0,
            "graph_nodes": self.G.number_of_nodes() if self.G is not None else 0,
            "graph_edges": self.G.number_of_edges() if self.G is not None else 0,
            "narratives": len(self.reports.get("narratives", {})) if self.reports else 0,
            "families": 10,
            "version": APP.VERSION,
        }

    def get_run_history(self) -> pd.DataFrame:
        return get_db().get_run_history()

    def has_data(self) -> bool:
        # v12.16 Task 7: Return True if scored_df OR graph G has data
        return (self.scored_df is not None and len(self.scored_df) > 0) or (
            self.G is not None and self.G.number_of_nodes() > 0
        )

    def get_audit_trail(self, limit: int = 200) -> List[Dict]:
        return self.audit.get_entries(limit)

    def get_geo_risk_data(self) -> Dict:
        """
        v12.4: Compute geo-risk statistics from graph node attributes.
        Returns dict with 'nodes' list and 'country_stats' dict.
        Sanctions checked first (correct priority). Single definition (CRIT-01).
        """
        from config import GEO_RISK as GR

        if self.G is None or self.scored_df is None:
            return {"nodes": [], "country_stats": {}}

        country_stats: Dict[str, Dict] = {}
        nodes_list = []

        for node_id in self.G.nodes():
            attrs = self.G.nodes[node_id]
            country = attrs.get("country", attrs.get("nationality", "XX")) or "XX"
            risk_score = float(attrs.get("risk_score", 0) or 0)
            in_flow = float(attrs.get("in_flow", 0) or 0)
            out_flow = float(attrs.get("out_flow", 0) or 0)
            total_flow = in_flow + out_flow

            # Classify geo level — sanctions first (highest priority)
            if country in GR.SANCTIONS:
                geo_level = "sanctions"
            elif country in GR.HIGH_RISK:
                geo_level = "high"
            elif country in GR.MEDIUM_RISK:
                geo_level = "medium"
            else:
                geo_level = "low"

            nodes_list.append(
                {
                    "node_id": node_id,
                    "country": country,
                    "geo_level": geo_level,
                    "risk_score": risk_score,
                    "total_flow": total_flow,
                }
            )

            if country not in country_stats:
                country_stats[country] = {
                    "count": 0,
                    "total_risk": 0.0,
                    "total_flow": 0.0,
                    "geo_level": geo_level,
                    "high_risk_count": 0,
                }
            cs = country_stats[country]
            cs["count"] += 1
            cs["total_risk"] += risk_score
            cs["total_flow"] += total_flow
            if risk_score >= 70:
                cs["high_risk_count"] += 1

        self.audit.log("GEO_RISK_ACCESS", f"Retrieved {len(nodes_list)} nodes geo data")
        return {"nodes": nodes_list, "country_stats": country_stats}

    def get_memory_status(self) -> Dict:
        return self.mem_monitor.get_status()


# =============================================================================
# CONFIG HOT-RELOAD (v12.4)
# =============================================================================
_config_mtime: Optional[float] = None


def check_config_changed() -> bool:
    """Return True if config.yaml has been modified since last check."""
    global _config_mtime
    try:
        cfg_path = Path(__file__).parent / "config.yaml"
        if not cfg_path.exists():
            return False
        mtime = cfg_path.stat().st_mtime
        if _config_mtime is None:
            _config_mtime = mtime
            return False
        if mtime != _config_mtime:
            _config_mtime = mtime
            return True
        return False
    except Exception:
        return False


def reload_config():
    """Reload config.yaml and update singletons."""
    try:
        from config import _CFG
        import yaml

        cfg_path = Path(__file__).parent / "config.yaml"
        with open(cfg_path, "r") as f:
            new_cfg = yaml.safe_load(f)
        _CFG.clear()
        _CFG.update(new_cfg)
        print("  [OK] Config hot-reloaded")
    except Exception as e:
        print(f"  [WARN] Config reload failed: {e}")


# =============================================================================
# SINGLETON
# =============================================================================
_pipeline: Optional[FCDAIPipeline] = None


def get_pipeline() -> FCDAIPipeline:
    global _pipeline
    if _pipeline is None:
        _pipeline = FCDAIPipeline()
    return _pipeline


def run_pipeline(**kwargs) -> PipelineResult:
    return get_pipeline().run(**kwargs)
