"""
FCDAI v12.4 - Plugin Loader
==============================
AIR-GAPPED | Discovers and loads plugins from layers/plugins/
Each plugin is a .py file with PLUGIN_NAME and run() function.
v12.4: Removed auto-discover on import; call discover_plugins() explicitly.
"""

import importlib
import importlib.util
from pathlib import Path
from typing import Dict, Any, List
import traceback

PLUGINS: Dict[str, Any] = {}


def discover_plugins(plugin_dir: Path = None) -> Dict[str, Any]:
    """
    Scan plugin directory for .py files that expose:
      - PLUGIN_NAME (str)
      - run(engine) -> dict
    """
    if plugin_dir is None:
        plugin_dir = Path(__file__).parent.parent / "layers" / "plugins"

    PLUGINS.clear()

    if not plugin_dir.exists():
        return PLUGINS

    for py_file in sorted(plugin_dir.glob("*.py")):
        if py_file.name.startswith("_"):
            continue
        try:
            spec = importlib.util.spec_from_file_location(f"plugin_{py_file.stem}", str(py_file))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)

            name = getattr(mod, "PLUGIN_NAME", py_file.stem)
            run_fn = getattr(mod, "run", None)
            if run_fn and callable(run_fn):
                PLUGINS[name] = {
                    "module": mod,
                    "run": run_fn,
                    "file": str(py_file),
                    "description": getattr(mod, "PLUGIN_DESCRIPTION", ""),
                    "version": getattr(mod, "PLUGIN_VERSION", "1.0"),
                }
        except Exception:
            traceback.print_exc()

    return PLUGINS


def run_plugin(name: str, engine=None) -> dict:
    """Run a single plugin by name."""
    plug = PLUGINS.get(name)
    if plug is None:
        return {"error": f"Plugin '{name}' not found"}
    try:
        return plug["run"](engine)
    except Exception as exc:
        return {"error": str(exc)}


def run_all_plugins(engine=None) -> Dict[str, dict]:
    """Run every registered plugin. Returns {name: result_dict}."""
    results = {}
    for name in PLUGINS:
        results[name] = run_plugin(name, engine)
    return results


def list_plugins() -> List[dict]:
    """List registered plugins."""
    return [
        {
            "name": name,
            "file": info["file"],
            "version": info["version"],
            "description": info["description"],
        }
        for name, info in PLUGINS.items()
    ]


# Lazy discovery: call discover_plugins() explicitly when needed
# discover_plugins()
