"""
utils/business_rules.py — v16.36 Template-Driven Business Explanation Engine
==============================================================================
PURPOSE
-------
Translate every AML signal from technical language into plain business English
that a Branch Manager, Compliance Officer, or Senior Investigator can act on
immediately — WITHOUT needing to understand algorithms.

DESIGN PRINCIPLES
-----------------
1. TEMPLATE-DRIVEN: Every signal maps to three things:
     • why_flagged   — plain English: why the system flagged this
     • what_it_means — business context: what this behaviour indicates
     • what_to_do    — recommended next action
2. DYNAMIC: Works with any new or adhoc data automatically.
   Adding a new signal = add one entry to SIGNAL_RULES dict. No other changes.
3. OFFLINE-SAFE: No external API calls. Fully self-contained templates.
4. PIPELINE-SYNC: Called by l6_scoring.py so every page that reads
   evidence_summary gets business language automatically.

USAGE
-----
    from utils.business_rules import build_business_narrative, build_action_required
    summary = build_business_narrative(signal_dict)   # → str for evidence_summary col
    action  = build_action_required(signal_dict)       # → str for action_required col

v16.36.1: 44 personalized signal templates — 10 groups, unique messages per customer.
Every customer's explanation includes their actual score, flow amounts, ring size, and
degree so no two customers ever see the same generic message.
"""

from __future__ import annotations
from typing import Dict, Any, List

# ═══════════════════════════════════════════════════════════════════════════════
# SIGNAL RULE TEMPLATES
# Each key maps to a dict with:
#   why_flagged   → short sentence explaining the detection
#   what_it_means → business implication
#   what_to_do    → recommended investigator action
#   severity      → P1/P2/P3/P4 (drives urgency language)
# ═══════════════════════════════════════════════════════════════════════════════

SIGNAL_RULES: Dict[str, Dict[str, Any]] = {

    # ── Circular ring (SCC) ───────────────────────────────────────────────────
    "in_ring": {
        "why_flagged": (
            "This customer's account is part of a circular money loop — "
            "funds leave this account and eventually return to it through {sz} connected accounts."
        ),
        "what_it_means": (
            "Circular money movement is one of the strongest indicators of organised money "
            "laundering. Legitimate customers don't regularly receive back money they sent out. "
            "This pattern suggests the customer may be knowingly (or unknowingly) part of a "
            "layering scheme designed to disguise the origin of funds."
        ),
        "what_to_do": (
            "FREEZE or RESTRICT: Place a hold on outgoing transactions. "
            "File a Suspicious Activity Report (SAR). "
            "Contact the compliance team today."
        ),
        "severity": "P1",
    },

    # ── Deep network embedding (K-Core) ──────────────────────────────────────
    "k_core": {
        "why_flagged": (
            "This customer transacts with people who also transact with each other — "
            "forming a tightly connected cluster (network depth: {k})."
        ),
        "what_it_means": (
            "When accounts form interconnected clusters rather than transacting independently, "
            "it strongly suggests a coordinated group. Legitimate customers rarely transact "
            "with the same tight circle of people repeatedly. Depth {k} means every person in "
            "this group knows every other person through transactions."
        ),
        "what_to_do": (
            "INVESTIGATE GROUP: Review all accounts in this cluster together — not individually. "
            "Ask the customer to explain their relationship with other flagged accounts."
        ),
        "severity": "P2",
    },

    # ── Round-trip (A→B→A motif) ─────────────────────────────────────────────
    "motif_circular": {
        "why_flagged": (
            "Money sent TO this customer comes back FROM this customer — "
            "a direct back-and-forth payment loop was detected."
        ),
        "what_it_means": (
            "Sending money to someone and receiving it back is a classic round-trip pattern. "
            "This is different from normal refunds (which are rare and documented). "
            "Regular back-and-forth payments with no clear commercial purpose are a "
            "common way to generate fake transaction history to legitimise dirty money."
        ),
        "what_to_do": (
            "REQUEST DOCUMENTATION: Ask the customer for invoices or contracts "
            "explaining why money travels back and forth. "
            "If no business purpose can be demonstrated, escalate to compliance."
        ),
        "severity": "P2",
    },

    # ── Structuring / smurfing ────────────────────────────────────────────────
    "potential_structuring": {
        "why_flagged": (
            "Multiple transactions were detected that are deliberately kept just below "
            "the $10,000 regulatory reporting threshold."
        ),
        "what_it_means": (
            "Banks are required to file a Currency Transaction Report (CTR) for "
            "cash transactions over $10,000. Breaking one large payment into "
            "several smaller amounts just under this limit — known as 'structuring' "
            "or 'smurfing' — is illegal regardless of the money's origin. "
            "This is one of the most common money laundering techniques."
        ),
        "what_to_do": (
            "FILE CTR / SAR: This behaviour alone may require a SAR filing. "
            "Document all transactions in the $9,000–$9,999 range. "
            "Do NOT inform the customer you are filing (tipping-off offence)."
        ),
        "severity": "P1",
    },

    # ── CTR bracket avoidance ─────────────────────────────────────────────────
    "potential_ctr_avoidance": {
        "why_flagged": (
            "{cnt} transaction(s) were made in the $9,000–$10,000 range — "
            "the exact window used to avoid mandatory reporting."
        ),
        "what_it_means": (
            "Transactions clustered between $9,000 and $9,999 are a specific red flag "
            "because they exploit the exact gap just below the CTR threshold. "
            "While a single such transaction may be coincidental, repeated occurrences "
            "suggest deliberate structuring to avoid bank reporting obligations."
        ),
        "what_to_do": (
            "DOCUMENT AND REPORT: Record all transactions in this bracket. "
            "If a pattern exists over multiple dates, file a SAR. "
            "Check whether these transactions share a common counterparty."
        ),
        "severity": "P1",
    },

    # ── Layering intermediary ─────────────────────────────────────────────────
    "is_layering_intermediary": {
        "why_flagged": (
            "Money flows through this account without accumulating — "
            "funds arrive and are quickly sent onwards to other accounts."
        ),
        "what_it_means": (
            "This account appears to be acting as a 'pass-through' — receiving money "
            "and immediately forwarding it elsewhere. This is the definition of layering: "
            "creating distance between dirty money and its source by moving it through "
            "multiple accounts. The account may belong to a 'mule' who is wittingly "
            "or unwittingly facilitating money laundering."
        ),
        "what_to_do": (
            "IDENTIFY THE CHAIN: Trace where the money came from AND where it went. "
            "Interview the customer about the business relationship with both counterparties. "
            "Consider whether the customer may be an unwitting mule — contact fraud team."
        ),
        "severity": "P2",
    },

    # ── Unusual digit patterns (Benford's Law) ────────────────────────────────
    "benfords_anomaly": {
        "why_flagged": (
            "The first digits of this customer's transaction amounts do not follow "
            "the natural statistical pattern expected in genuine financial data."
        ),
        "what_it_means": (
            "Real-world financial data follows a law called Benford's Law — amounts "
            "naturally start with 1 more often than 2, 2 more often than 3, and so on. "
            "When amounts are invented or deliberately structured, this pattern breaks. "
            "A violation suggests amounts may have been chosen manually rather than "
            "arising from genuine commercial activity."
        ),
        "what_to_do": (
            "VERIFY COMMERCIAL PURPOSE: Request supporting documentation (invoices, "
            "contracts, payslips) for the top 5 largest transactions. "
            "Artificially round or clustered amounts are a specific red flag."
        ),
        "severity": "P3",
    },

    # ── Second-digit anomaly (near-threshold clustering) ─────────────────────
    "benfords_second_anomaly": {
        "why_flagged": (
            "Transaction amounts cluster suspiciously close to reporting thresholds "
            "— the second digits show an unnatural concentration."
        ),
        "what_it_means": (
            "When people deliberately keep amounts just under $10,000, the second digit "
            "of amounts tends to cluster around '9' (e.g. $9,900 / $9,800 / $9,750). "
            "This mathematical signature is detectable even when the individual amounts "
            "look innocent. It strengthens any existing structuring concern."
        ),
        "what_to_do": (
            "COMBINE WITH STRUCTURING REVIEW: Cross-reference with CTR bracket analysis. "
            "If amounts cluster in the $9,500–$9,999 band, the structuring case is strengthened."
        ),
        "severity": "P2",
    },

    # ── Shared device / phone / IP / address ─────────────────────────────────
    "shared_infrastructure_count": {
        "why_flagged": (
            "This account shares {infra} identifying detail(s) — such as device, phone number, "
            "IP address, or home address — with other flagged customers."
        ),
        "what_it_means": (
            "When different customers share the same device, phone, address, or IP address, "
            "it strongly suggests these accounts are controlled by the same person or organisation. "
            "This is a classic 'mule network' indicator. What appears to be independent "
            "third-party transactions may actually be one person moving money through "
            "fictitious accounts."
        ),
        "what_to_do": (
            "LINK INVESTIGATION: Do not investigate these accounts in isolation. "
            "Identify ALL accounts sharing this infrastructure and review them as a single case. "
            "Request identity verification documents — photos and live checks."
        ),
        "severity": "P1",
    },

    # ── Transaction burst / volume spike ─────────────────────────────────────
    "is_burst": {
        "why_flagged": (
            "An abnormal spike in transaction volume was detected — "
            "far more activity than this account's normal pattern."
        ),
        "what_it_means": (
            "Sudden sharp increases in transaction frequency — particularly when the account "
            "has been dormant or low-activity beforehand — are a strong red flag. "
            "Criminals often use accounts that have been 'warming up' slowly, then conduct "
            "high-volume activity in a short window before closing or abandoning the account."
        ),
        "what_to_do": (
            "REVIEW RECENT HISTORY: Pull all transactions from the burst period. "
            "Check whether the customer profile (age, income, declared purpose) is "
            "consistent with the sudden activity level. Consider dormancy-then-burst flag."
        ),
        "severity": "P2",
    },

    # ── Historical circular flows ─────────────────────────────────────────────
    "temporal_circular_flow_count": {
        "why_flagged": (
            "The system's historical records show {circ_cnt} previous occasion(s) "
            "where circular money movement was detected with this customer "
            "{circ_val_str}."
        ),
        "what_it_means": (
            "A single circular transaction could be explained away. Multiple historical "
            "instances of circular flow are evidence of a sustained pattern — not an accident. "
            "This customer has been involved in organised money rotation repeatedly over time."
        ),
        "what_to_do": (
            "ESCALATE TO MANAGEMENT: Recurring patterns require senior compliance sign-off. "
            "Review previous SAR filings for this customer. If none filed, consider "
            "retroactive SAR filing for the historical period."
        ),
        "severity": "P1",
    },

    # ── Historical burst events ───────────────────────────────────────────────
    "temporal_burst_count": {
        "why_flagged": (
            "Historical data shows {burst_cnt} previous transaction burst event(s) "
            "on this account."
        ),
        "what_it_means": (
            "Repeated spikes in transaction volume — not just the current one — indicate "
            "this is a behavioural pattern for this customer, not a one-off event. "
            "Seasonal or legitimate bursts (e.g. payroll) would be explainable. "
            "Unexplained repeated spikes are a serious AML concern."
        ),
        "what_to_do": (
            "PATTERN REVIEW: Map all burst dates. Are they regular (scripted)? "
            "Cross-reference with known events (year-end, bonuses). "
            "Unexplained regularity should be escalated."
        ),
        "severity": "P2",
    },

    # ── Multi-signal consensus ────────────────────────────────────────────────
    "consensus_count": {
        "why_flagged": (
            "{cc} out of 10 independent detection methods flagged this customer as suspicious."
        ),
        "what_it_means": (
            "Our system runs 10 different detection methods simultaneously — each looking "
            "for different fraud patterns. When {cc} or more of these methods flag the same "
            "customer, that is extremely unlikely to be a false alarm. Each confirmation "
            "independently corroborates the others. High agreement = high confidence."
        ),
        "what_to_do": (
            "HIGH CONFIDENCE CASE: Prioritise this case for immediate review. "
            "The probability of false positive is very low when {cc}+ signals agree. "
            "Prepare SAR narrative using all flagged signals as supporting evidence."
        ),
        "severity": "P1",
    },

    # ── Scripted / bot-like transactions ─────────────────────────────────────
    "temporal_is_scripted_regular": {
        "why_flagged": (
            "Transactions arrive at unnaturally precise time intervals — "
            "suggesting automated software rather than a real person making payments."
        ),
        "what_it_means": (
            "Genuine customers make payments at random times driven by their life activities. "
            "When transactions occur at perfectly regular intervals (e.g. every 3h 15m), "
            "it indicates automated scripts. Money mule networks increasingly use "
            "automated tools to cycle funds quickly across accounts."
        ),
        "what_to_do": (
            "AUTOMATED FRAUD INVESTIGATION: Flag for digital forensics. "
            "Check whether the customer's online banking app could generate such regularity, "
            "or whether account credentials may have been compromised."
        ),
        "severity": "P2",
    },

    # ── Temporal relay (time-ordered layering chain) ──────────────────────────
    "temporal_is_temporal_relay": {
        "why_flagged": (
            "Funds were received and then forwarded to another account within 24 hours "
            "on {relay_cnt} occasion(s) — a rapid pass-through pattern."
        ),
        "what_it_means": (
            "When money arrives and leaves the same day or within hours, the account "
            "is acting as a relay station — not as a genuine final recipient. "
            "This 'hot potato' pattern keeps money moving quickly to make it harder "
            "to trace. Legitimate customers hold money; mules relay it."
        ),
        "what_to_do": (
            "TRACE THE CHAIN: Identify origin account and final destination account. "
            "The relay account may be a victim (compromised) or a willing participant. "
            "Both require different regulatory treatment — assess intent."
        ),
        "severity": "P1",
    },

    # ── Power-law structural anomaly ──────────────────────────────────────────
    "centrality_is_powerlaw_tail": {
        "why_flagged": (
            "⚠️ HUB ACCOUNT — This customer connects to an extreme number of other "
            "accounts — far beyond any normal banking customer. Hub accounts are the "
            "control centres of money laundering networks."
        ),
        "what_it_means": (
            "Most bank customers transact with a handful of regular counterparties. "
            "When one account connects to dozens or hundreds of different accounts, "
            "it is almost certainly operating as a hub — collecting from many sources "
            "or distributing to many destinations. Hub accounts sit at the centre "
            "of professional money laundering operations."
        ),
        "what_to_do": (
            "HUB ACCOUNT REVIEW: List every unique counterparty. Check each against "
            "sanctions lists and PEP databases. Determine whether a business purpose "
            "can explain the breadth of connections."
        ),
        "severity": "P2",
    },

    # ════════════════════════════════════════════════════════════════════════
    # GROUP: LARGE RING VARIANTS
    # ════════════════════════════════════════════════════════════════════════

    "in_large_ring": {
        "why_flagged": (
            "🔴 LARGE MONEY CAROUSEL — This account belongs to a {sz}-member "
            "circular money network. ${out_flow} has been cycled through this group "
            "with no legitimate business purpose found."
        ),
        "what_it_means": (
            "A ring of {sz} accounts is not accidental — it represents an organised "
            "scheme. Each member is either a knowing participant or an unwitting mule. "
            "The larger the ring, the more resources have been invested in setting it up. "
            "This is a professional criminal operation."
        ),
        "what_to_do": (
            "ESCALATE TO HEAD OF AML: All {sz} accounts must be investigated "
            "as a linked case. Restrict outbound transactions on all members. "
            "SAR filing required within 30 days."
        ),
        "severity": "P1",
    },

    "in_mega_ring": {
        "why_flagged": (
            "🚨 MAJOR ORGANISED MONEY RING — This account is embedded in a "
            "{sz}-account money laundering network. Total suspicious flow: "
            "${out_flow}. This is the hallmark of a professional criminal operation."
        ),
        "what_it_means": (
            "A circular network of over {sz} accounts indicates a highly organised "
            "criminal syndicate — not opportunistic fraud. These networks are typically "
            "linked to serious organised crime: drug trafficking, human trafficking, "
            "or large-scale financial fraud. The bank faces significant regulatory risk."
        ),
        "what_to_do": (
            "URGENT ESCALATION: Brief the Head of AML "
            "today. Consider reporting to law enforcement in addition to SAR. "
            "Restrict all accounts in the ring immediately."
        ),
        "severity": "P1",
    },

    # ════════════════════════════════════════════════════════════════════════
    # GROUP: FLOW VOLUME ANOMALIES
    # ════════════════════════════════════════════════════════════════════════

    "extreme_outflow": {
        "why_flagged": (
            "⚠️ VERY HIGH OUTGOING TRANSFERS — {out_flow} has left this account "
            "during the analysis period — an unusually large outflow for a "
            "customer of this profile."
        ),
        "what_it_means": (
            "Large outflows combined with other risk signals indicate significant sums "
            "moving without clear documented business justification. The volume alone "
            "warrants source-of-funds verification."
        ),
        "what_to_do": (
            "SOURCE OF FUNDS: Request documentation explaining where the money originated "
            "and what the outgoing payments were for. "
            "If the customer cannot explain {out_flow} in outflows, escalate to compliance."
        ),
        "severity": "P2",
    },

    "extreme_inflow": {
        "why_flagged": (
            "⚠️ VERY HIGH INCOMING FUNDS — {in_flow} flowed INTO this account "
            "during the analysis period from external sources — a volume "
            "inconsistent with the customer's declared profile."
        ),
        "what_it_means": (
            "Receiving very large amounts from many different sources raises the question "
            "of where this money comes from. Placement — the first stage of money "
            "laundering — involves introducing criminal funds into the banking system. "
            "High unexplained inflows are a classic placement indicator."
        ),
        "what_to_do": (
            "WEALTH VERIFICATION: Ask the customer to explain the source of "
            "{in_flow} in incoming funds. Request bank statements, salary slips, "
            "or business accounts to verify legitimacy."
        ),
        "severity": "P2",
    },

    "flow_imbalance": {
        "why_flagged": (
            "⚠️ SEVERE FLOW IMBALANCE — Money coming in ({in_flow}) and money "
            "going out ({out_flow}) are dramatically mismatched. This is inconsistent "
            "with normal banking behaviour."
        ),
        "what_it_means": (
            "A healthy account sees money come in and go out in rough proportion. "
            "When one direction is dramatically larger, it suggests the account is "
            "being used purely as a receiving bucket (placement) or purely as a "
            "distribution point (layering) — not as a real transaction account."
        ),
        "what_to_do": (
            "ENHANCED REVIEW: Request a full account statement. Map sources of inflow "
            "and destinations of outflow. Look for single-source inflows or "
            "single-destination outflows — both are layering signals."
        ),
        "severity": "P2",
    },

    "high_total_flow": {
        "why_flagged": (
            "⚠️ HIGH TOTAL TRANSACTION VOLUME — A combined total of {total_flow} "
            "has moved through this account ({in_flow} in, {out_flow} out). "
            "This volume exceeds normal expectations for this customer type."
        ),
        "what_it_means": (
            "When an account processes more money than the customer's known income, "
            "occupation, or business type would suggest, it raises the possibility "
            "that the account is processing money on behalf of other parties — "
            "a key sign of money laundering."
        ),
        "what_to_do": (
            "KYC REVIEW: Update the customer's Know Your Customer file. Compare declared "
            "income or business revenue against the {total_flow} processed. "
            "Any unexplained excess should trigger a SAR review."
        ),
        "severity": "P2",
    },

    # ════════════════════════════════════════════════════════════════════════
    # GROUP: DEGREE / NETWORK BREADTH
    # ════════════════════════════════════════════════════════════════════════

    "high_out_degree": {
        "why_flagged": (
            "⚠️ MONEY DISPERSED TO {out_deg} DIFFERENT RECIPIENTS — This account "
            "has sent money to an unusually large number of different people or "
            "businesses — far beyond what a typical bank customer does."
        ),
        "what_it_means": (
            "Most customers send money to a small stable group: family, bills, a few "
            "regular payees. When money is dispersed to {out_deg} different recipients "
            "without a clear business reason, it suggests the account is distributing "
            "funds — possibly to multiple mule accounts or to layer money across many channels."
        ),
        "what_to_do": (
            "RECIPIENT REVIEW: Identify who the {out_deg} recipients are. Are they "
            "individuals acting as mules? Are they real businesses? "
            "Check whether any recipients are also flagged in the system."
        ),
        "severity": "P2",
    },

    "high_unique_senders": {
        "why_flagged": (
            "⚠️ RECEIVING FROM {in_deg} DIFFERENT SENDERS — This account receives "
            "money from an unusually large number of different sources. Collecting "
            "from many unrelated parties is a known placement technique."
        ),
        "what_it_means": (
            "Legitimate accounts receive from a small predictable group: employer, "
            "family, a few regular counterparties. When {in_deg} different senders "
            "contribute to one account with no clear business reason, the account may "
            "be aggregating criminal funds from multiple sources before forwarding them."
        ),
        "what_to_do": (
            "SENDER ANALYSIS: Review who the {in_deg} senders are. Are they individuals? "
            "Businesses? Other flagged accounts? Strangers sending money to one account "
            "with no invoices or contracts is a serious AML concern."
        ),
        "severity": "P2",
    },

    # ════════════════════════════════════════════════════════════════════════
    # GROUP: COMBO / MULTI-SIGNAL RULES
    # ════════════════════════════════════════════════════════════════════════

    "shared_device_ring_combo": {
        "why_flagged": (
            "🚨 DOUBLE RED FLAG — Shared account details AND circular money loop. "
            "This account shares identifiers with other customers AND is part of "
            "a circular money ring — a coordinated criminal scheme."
        ),
        "what_it_means": (
            "Finding shared infrastructure alongside circular money movement is extremely "
            "rare in legitimate banking. This combination is a signature of an organised "
            "mule network: the same controller runs multiple accounts and cycles money. "
            "This is one of the highest-confidence fraud signatures the system can detect."
        ),
        "what_to_do": (
            "MAXIMUM ALERT: Freeze all accounts sharing the same infrastructure AND all "
            "accounts in the money ring simultaneously. Brief the Head of Financial Crime. "
            "Consider contacting law enforcement."
        ),
        "severity": "P1",
    },

    "ring_plus_structuring_combo": {
        "why_flagged": (
            "🚨 CRITICAL COMBINATION — Circular money ring AND threshold-splitting "
            "transactions detected simultaneously. These two patterns together are "
            "the hallmark of a sophisticated money laundering operation."
        ),
        "what_it_means": (
            "Circular money loops CREATE the impression of legitimate wealth. "
            "Threshold splitting EXTRACTS that apparent wealth without triggering "
            "reporting. Finding both in the same account means both key stages of "
            "a laundering scheme are visible. This is a textbook case."
        ),
        "what_to_do": (
            "IMMEDIATE SAR: Both structuring and circular flow independently justify "
            "a SAR. Together, this is an open-and-shut case. Freeze account, file "
            "internally, brief compliance within 24 hours."
        ),
        "severity": "P1",
    },

    "ring_plus_relay_combo": {
        "why_flagged": (
            "🚨 CIRCULAR LOOP AND SAME-DAY FORWARDING — Part of a money ring AND "
            "forwards funds within 24 hours on multiple occasions. Money never "
            "stays — it just passes through this account."
        ),
        "what_it_means": (
            "Ring membership (money going in circles) combined with rapid same-day "
            "relay means this account is both a node in an organised loop AND "
            "an active relay station within it. The account exists purely to move money."
        ),
        "what_to_do": (
            "FREEZE AND INVESTIGATE: Halt all outgoing transactions. Pull the full "
            "transaction history. Map every account that sent to or received from "
            "this account."
        ),
        "severity": "P1",
    },

    "automated_relay_combo": {
        "why_flagged": (
            "🚨 FULLY AUTOMATED MULE ACCOUNT — Robot-like transaction timing AND "
            "same-day relay forwarding detected together. Money arrives and is "
            "automatically forwarded within hours — without human interaction."
        ),
        "what_it_means": (
            "An account that receives money on a scripted schedule and forwards it "
            "automatically is the definition of an automated mule account. The account "
            "owner may not even know their credentials are being used by criminals."
        ),
        "what_to_do": (
            "CONTACT CUSTOMER CAREFULLY — they may be a fraud victim. Use only a "
            "verified contact channel, NOT the email or phone on file. "
            "File SAR. Freeze outbound transactions immediately."
        ),
        "severity": "P1",
    },

    "scripted_plus_structuring_combo": {
        "why_flagged": (
            "🚨 AUTOMATED STRUCTURING — Robot-like timing AND threshold-splitting "
            "amounts detected together. Criminal software appears to be deliberately "
            "splitting payments to avoid mandatory reporting."
        ),
        "what_it_means": (
            "Manual structuring requires a person to deliberately split payments. "
            "Automated structuring — where software makes payments of exactly $9,800 "
            "at precisely timed intervals — is a signature of sophisticated criminal "
            "automation. This is industrial-scale money laundering."
        ),
        "what_to_do": (
            "TECHNICAL AND COMPLIANCE REVIEW: Flag for digital forensics to confirm "
            "automated activity. File SAR immediately. This case may warrant "
            "law enforcement referral."
        ),
        "severity": "P1",
    },

    "infrastructure_plus_ring_combo": {
        "why_flagged": (
            "🚨 SAME CONTROLLER, CIRCULAR NETWORK — Shares device or identifiers "
            "with other accounts AND is in a circular money ring. One person may be "
            "operating multiple accounts in an organised laundering loop."
        ),
        "what_it_means": (
            "Shared infrastructure proves a common controller. Circular ring membership "
            "proves money is being cycled deliberately. Together, they confirm a "
            "coordinated multi-account scheme — the operational signature of a "
            "mule network manager."
        ),
        "what_to_do": (
            "NETWORK TAKEDOWN: Identify the common controller. All accounts sharing "
            "infrastructure AND in the same ring form one criminal network. "
            "Investigate and freeze simultaneously. Law enforcement referral may apply."
        ),
        "severity": "P1",
    },

    # ════════════════════════════════════════════════════════════════════════
    # GROUP: RISK SCORE RULES
    # ════════════════════════════════════════════════════════════════════════

    "extreme_risk_score": {
        "why_flagged": (
            "🔴 EXTREME RISK SCORE: {score}/100 — This account received one of the "
            "highest risk ratings in the entire customer portfolio. A score above 90 "
            "places this account in the top 1% of suspicious accounts."
        ),
        "what_it_means": (
            "Our risk model evaluates over 20 different signals simultaneously. "
            "A score of {score}/100 means multiple strong signals all point in the same "
            "direction. Even if no single signal is definitive, the combined weight of "
            "evidence is extremely elevated."
        ),
        "what_to_do": (
            "PRIORITY REVIEW: A risk score of {score}/100 requires immediate "
            "investigation. Review all flagged signals. Do not de-prioritise based "
            "on account size — high-risk small accounts are commonly used to test "
            "laundering techniques."
        ),
        "severity": "P1",
    },

    "very_high_risk_score": {
        "why_flagged": (
            "⚠️ HIGH RISK SCORE: {score}/100 — Our risk model rated this account "
            "in the top 5% of the customer portfolio. Multiple concerning signals "
            "are present, even if none individually is conclusive."
        ),
        "what_it_means": (
            "A score of {score}/100 indicates that while no single smoking-gun signal "
            "was detected, the combination of multiple moderate signals produces a "
            "significant overall risk profile. These cases are worth enhanced due "
            "diligence even if they don't immediately require a SAR."
        ),
        "what_to_do": (
            "ENHANCED DUE DILIGENCE: Review the detailed signal breakdown. "
            "Update KYC documentation. Consider requesting a source-of-funds "
            "statement from the customer at the next contact opportunity."
        ),
        "severity": "P2",
    },

    "moderate_high_risk_score": {
        "why_flagged": (
            "📋 ELEVATED RISK SCORE: {score}/100 — This account scored above average "
            "on our risk model. The pattern warrants monitoring and documentation."
        ),
        "what_it_means": (
            "A score of {score}/100 reflects a slightly elevated risk profile that may "
            "reflect a single moderate signal or several minor signals together above "
            "the monitoring threshold. Watch for escalation over the next 90 days."
        ),
        "what_to_do": (
            "WATCHLIST: Add to the 30-day monitoring list. Set an alert for any "
            "transaction above $5,000 in the next 30 days. "
            "Review again at the next quarterly AML cycle."
        ),
        "severity": "P3",
    },

    # ════════════════════════════════════════════════════════════════════════
    # GROUP: ACCOUNT PROFILE PATTERNS
    # ════════════════════════════════════════════════════════════════════════

    "mule_account_profile": {
        "why_flagged": (
            "🔴 MONEY MULE PROFILE — This account matches the classic signature of a "
            "bank money mule: funds received from unknown parties and immediately "
            "forwarded to different accounts."
        ),
        "what_it_means": (
            "A money mule is someone whose bank account is used to receive and forward "
            "criminal funds. They may be witting (paid to do it) or unwitting (deceived "
            "through a romance scam, job scam, or phishing). The account holder may "
            "actually be a victim — or a knowing accomplice."
        ),
        "what_to_do": (
            "URGENT DUAL REVIEW: (1) Freeze outbound transactions. (2) Contact customer "
            "through a VERIFIED channel — they may be a fraud victim. (3) File SAR "
            "regardless of intent. (4) Check whether they received a suspicious job "
            "offer or online relationship (common mule recruitment tactics)."
        ),
        "severity": "P1",
    },

    "professional_launderer_profile": {
        "why_flagged": (
            "🚨 ORGANISED CRIME PROFILE — This account matches multiple signatures of a "
            "professional money laundering operation: circular rings, automated patterns, "
            "shared infrastructure, and high consensus across detection systems."
        ),
        "what_it_means": (
            "Professional money laundering involves deliberate, structured operations with "
            "multiple overlapping techniques deployed simultaneously. When an account "
            "triggers circular ring + automated timing + infrastructure-sharing + high "
            "multi-system consensus, it is operating within an organised criminal scheme."
        ),
        "what_to_do": (
            "FULL ESCALATION: Notify the Chief Compliance Officer. Preserve all transaction "
            "records for potential law enforcement use. File SAR. Consider referral to the "
            "Financial Intelligence Unit (FIU). Do NOT tip off the customer."
        ),
        "severity": "P1",
    },

    "shell_account_indicators": {
        "why_flagged": (
            "⚠️ SHELL ACCOUNT PATTERN — This account shows signs of a 'shell': opened to "
            "process funds with no genuine banking relationship. High flow volume combined "
            "with minimal authentic activity."
        ),
        "what_it_means": (
            "Shell accounts are opened specifically to receive, hold briefly, and forward "
            "criminal funds. They often show: high transaction volumes inconsistent with "
            "the holder's profile, minimal regular payments (no bills, no salary), and "
            "sudden activation after a dormant period."
        ),
        "what_to_do": (
            "IDENTITY VERIFICATION: Conduct a face-to-face or live video KYC check. "
            "Verify the account holder is who they claim to be. Request proof of address "
            "and income. If the customer cannot be reached, consider account closure."
        ),
        "severity": "P2",
    },

    "dormant_then_active_profile": {
        "why_flagged": (
            "⚠️ DORMANT ACCOUNT SUDDENLY ACTIVATED — After a long period of minimal "
            "activity, this account suddenly processed significantly higher volumes. "
            "The 'sleep then activate' pattern is common in accounts opened for future "
            "criminal use."
        ),
        "what_it_means": (
            "Criminals sometimes open accounts and keep them dormant for months or years "
            "to establish a clean transaction history. The sudden activation, especially "
            "with no corresponding change in the customer's known circumstances, is "
            "a significant red flag."
        ),
        "what_to_do": (
            "REACTIVATION REVIEW: Contact the customer to confirm they are responsible "
            "for the recent activity. Request updated KYC. Check whether account "
            "credentials may have been compromised. If unexplained, file SAR."
        ),
        "severity": "P2",
    },

    # ════════════════════════════════════════════════════════════════════════
    # GROUP: ADDITIONAL AML TYPOLOGIES
    # ════════════════════════════════════════════════════════════════════════

    "cross_layering_signals": {
        "why_flagged": (
            "🔴 FOUR OR MORE LAUNDERING TECHNIQUES SIMULTANEOUSLY — This account is "
            "triggering at least 4 different suspicious activity signals at once. "
            "Multiple overlapping techniques signals deliberate sophistication."
        ),
        "what_it_means": (
            "A naive money launderer uses one technique. A professional uses multiple "
            "overlapping techniques — circular flows, threshold splitting, relay "
            "forwarding, scripted timing. When 4 or more fire at once, the account "
            "is almost certainly operated by someone with specific knowledge of AML "
            "detection and is deliberately trying to evade it."
        ),
        "what_to_do": (
            "SENIOR SPECIALIST REVIEW: This case requires a financial crime specialist. "
            "The number of overlapping techniques puts this above standard automated "
            "SAR processing. Consider law enforcement referral."
        ),
        "severity": "P1",
    },

    "velocity_anomaly": {
        "why_flagged": (
            "⚠️ RAPID FUND CYCLING — Money is moving through this account at an "
            "unusually high speed. Funds received are immediately forwarded rather "
            "than being held, which is not normal banking behaviour."
        ),
        "what_it_means": (
            "Transaction velocity — how fast money moves through an account — is a key "
            "indicator. High velocity means money arrives and leaves quickly. This is "
            "preferred by criminals for its ability to move funds before detection "
            "is triggered."
        ),
        "what_to_do": (
            "VELOCITY REVIEW: Calculate the average time between money arriving and "
            "leaving. If funds consistently clear within 24–48 hours, treat as a "
            "relay case and escalate accordingly."
        ),
        "severity": "P2",
    },

    "accumulation_dispersal": {
        "why_flagged": (
            "⚠️ COLLECT THEN DISPERSE PATTERN — This account accumulates incoming funds "
            "over a period, then disperses them all at once to multiple recipients. "
            "This is a known AML staging pattern."
        ),
        "what_it_means": (
            "The accumulate-then-disperse pattern mirrors the behaviour of a staging "
            "account: funds collected from multiple sources (often small amounts to "
            "avoid detection), held briefly, then distributed in a rapid burst to "
            "multiple destinations — making the dispersed funds harder to trace."
        ),
        "what_to_do": (
            "STAGING ACCOUNT REVIEW: Identify dispersal events and trace where funds "
            "went. Compare timing of inflows vs outflows. If inflows are slow and "
            "diffuse while outflows are sudden and concentrated, file SAR."
        ),
        "severity": "P2",
    },

    "layering_chain_detected": {
        "why_flagged": (
            "🔴 MONEY TRAIL DETECTED — The system traced a multi-hop path through "
            "this account: money originates elsewhere, passes through here, and ends "
            "at a different destination. This account is a link in a laundering chain."
        ),
        "what_it_means": (
            "Money laundering involves three stages: placement (entry to banking), "
            "layering (moving through accounts to hide trail), and integration "
            "(reintroducing as clean money). When an account appears as a middle link "
            "in a traced transaction chain, it is participating in the layering phase."
        ),
        "what_to_do": (
            "TRACE BOTH ENDS: Investigate the account that sent money to this customer "
            "AND where this customer sent it. The full chain must be mapped. "
            "All accounts in the chain should be reviewed together as one case."
        ),
        "severity": "P1",
    },

    "concentration_risk": {
        "why_flagged": (
            "⚠️ TRANSACTION CONCENTRATION — A large proportion of this customer's "
            "flow is concentrated with a very small number of counterparties — "
            "a pattern consistent with directed or controlled layering."
        ),
        "what_it_means": (
            "When one account processes most of its volume with just one or two "
            "counterparties — particularly if individuals rather than established "
            "businesses — it suggests a directed transfer rather than genuine "
            "commercial activity. Bilateral concentrated flow is a common "
            "two-party layering pattern."
        ),
        "what_to_do": (
            "COUNTERPARTY CHECK: Identify the concentrated counterparties and investigate "
            "them independently. If they are also flagged in the system, "
            "open a linked investigation."
        ),
        "severity": "P2",
    },
}

# ── Tier severity order ────────────────────────────────────────────────────────
_SEVERITY_ORDER = {"P1": 4, "P2": 3, "P3": 2, "P4": 1}


def _fmt(template: str, **kw: Any) -> str:
    """Safe string format — returns template unchanged if any key is missing."""
    try:
        return template.format(**kw)
    except (KeyError, ValueError):
        return template


def _fmoney(val: float) -> str:
    """Format a float as a money string: $1.2M / $45,000 / $900."""
    try:
        if val <= 0:
            return "$0"
        if val >= 1_000_000:
            return f"${val / 1_000_000:.1f}M"
        if val >= 1_000:
            return f"${val:,.0f}"
        return f"${val:.0f}"
    except Exception:
        return "$?"


# ═══════════════════════════════════════════════════════════════════════════════
# CORE PUBLIC FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

def build_business_narrative(signals: Dict[str, Any]) -> str:
    """
    Return a fully PERSONALIZED plain-English explanation of why this specific
    customer was flagged.  Every explanation includes the customer's ACTUAL
    values (score, flow amounts, ring size, degree) so no two customers ever
    receive the same generic message.

    Priority order:
      1. Combo rules (two overlapping signals → special combined message)
      2. Individual binary signals (in_ring, structuring, relay, etc.)
      3. Risk-score fallback (customers with no discrete signals)
    """
    # ── Extract context values used across many rules ──────────────────────────
    g = signals.get
    in_flow   = float(g("in_flow",   0) or 0)
    out_flow  = float(g("out_flow",  0) or 0)
    in_deg    = int(float(g("in_degree",  0) or 0))
    out_deg   = int(float(g("out_degree", 0) or 0))
    score     = float(g("risk_score", 0) or 0)
    scc       = int(float(g("scc_size", 2) or 2))
    cc        = int(float(g("consensus_count", 0) or 0))
    relay_cnt = int(float(g("temporal_temporal_relay_count", 0) or 0))
    infra     = int(float(g("shared_infrastructure_count", 0) or 0))
    ctr_cnt   = int(float(g("ctr_bracket_count", 1) or 1))
    k         = int(float(g("k_core", 0) or 0))
    circ_cnt  = int(float(g("temporal_circular_flow_count", 0) or 0))
    burst_cnt = int(float(g("temporal_burst_count", 0) or 0))
    total_flow = in_flow + out_flow

    # Boolean fires
    in_ring       = bool(float(g("in_ring",       0) or 0))
    structuring   = bool(float(g("potential_structuring",    0) or 0))
    ctr_avoid     = bool(float(g("potential_ctr_avoidance",  0) or 0))
    benford1      = bool(float(g("benfords_anomaly",         0) or 0))
    benford2      = int(float(g("benfords_second_anomaly",   0) or 0)) == 1
    layering      = bool(float(g("is_layering_intermediary", 0) or 0))
    relay         = bool(float(g("temporal_is_temporal_relay", 0) or 0))
    scripted      = bool(float(g("temporal_is_scripted_regular", 0) or 0))
    burst         = bool(float(g("is_burst", 0) or 0))
    powerlaw      = bool(float(g("centrality_is_powerlaw_tail", 0) or 0))
    motif_circ    = bool(float(g("motif_circular", 0) or 0))

    # Money formatting
    in_f  = _fmoney(in_flow)
    out_f = _fmoney(out_flow)
    tot_f = _fmoney(total_flow)

    # Ring-size variant
    if in_ring:
        if scc >= 21:
            ring_variant = "in_mega_ring"
        elif scc >= 9:
            ring_variant = "in_large_ring"
        else:
            ring_variant = "in_ring"
    else:
        ring_variant = None

    parts: List[str] = []

    # ══════════════════════════════════════════════════════════════════════════
    # STEP 1 — COMBO RULES (highest priority, suppress component rules)
    # ══════════════════════════════════════════════════════════════════════════
    combo_fired: set = set()

    if infra >= 1 and in_ring:
        parts.append(
            f"\U0001f6a8 DOUBLE RED FLAG — Shared account details AND circular money loop. "
            f"This account shares identifiers with {infra} other customer(s) AND is part of "
            f"a {scc}-account circular money ring. One person may be controlling multiple "
            f"accounts in an organised laundering loop."
        )
        combo_fired.update({"shared_infrastructure_count", "in_ring", "in_large_ring", "in_mega_ring"})

    if in_ring and structuring:
        parts.append(
            f"\U0001f6a8 CRITICAL COMBINATION — Circular money ring ({scc} accounts) AND "
            f"threshold-splitting transactions detected simultaneously. "
            f"Ring membership cycles {out_f} through the group; structuring extracts it "
            f"without triggering mandatory reports. This is a textbook two-stage laundering scheme."
        )
        combo_fired.update({"in_ring", "in_large_ring", "in_mega_ring", "potential_structuring"})

    if in_ring and relay and relay_cnt >= 1:
        parts.append(
            f"\U0001f6a8 CIRCULAR LOOP AND SAME-DAY FORWARDING — Part of a {scc}-account money "
            f"ring AND forwards funds on the same day on {relay_cnt} occasion(s). "
            f"Money arrives and is passed on within hours — it never genuinely settles here."
        )
        combo_fired.update({"in_ring", "in_large_ring", "in_mega_ring", "temporal_is_temporal_relay"})

    if scripted and relay:
        parts.append(
            f"\U0001f6a8 FULLY AUTOMATED MULE ACCOUNT — Robot-like transaction timing AND "
            f"same-day relay forwarding detected together. Money arrives on a fixed schedule "
            f"and is automatically forwarded within hours — hallmark of criminal software "
            f"controlling this account without the holder's awareness."
        )
        combo_fired.update({"temporal_is_scripted_regular", "temporal_is_temporal_relay"})

    if scripted and structuring:
        parts.append(
            f"\U0001f6a8 AUTOMATED STRUCTURING — Robot-like timing AND threshold-splitting "
            f"amounts detected together. Criminal software appears to be deliberately splitting "
            f"payments just below reporting thresholds at precisely timed intervals. "
            f"This is industrial-scale money laundering, not opportunistic fraud."
        )
        combo_fired.update({"temporal_is_scripted_regular", "potential_structuring"})

    # High consensus override (7+ systems agreeing)
    if cc >= 7 and "consensus_count" not in combo_fired:
        parts.insert(0,
            f"\U0001f6a8 {cc}/10 INDEPENDENT DETECTION SYSTEMS ALL AGREE this account is "
            f"suspicious. With a risk score of {score:.0f}/100 and {out_f} in outgoing "
            f"transfers, this customer is among the highest-risk accounts in the entire "
            f"portfolio. Each detection system uses different logic — agreement across all "
            f"{cc} is statistically nearly impossible by chance."
        )
        combo_fired.add("consensus_count")

    # ══════════════════════════════════════════════════════════════════════════
    # STEP 2 — INDIVIDUAL SIGNAL RULES
    # ══════════════════════════════════════════════════════════════════════════

    # Ring (only if not already covered by a combo)
    if in_ring and ring_variant not in combo_fired:
        if ring_variant == "in_mega_ring":
            parts.append(
                f"\U0001f6a8 MAJOR ORGANISED MONEY RING — This account is embedded in a "
                f"{scc}-account money laundering network. Total suspicious outflow: {out_f}. "
                f"A network of this size ({scc}+ accounts) requires coordinated criminal "
                f"organisation — this is not random customer behaviour."
            )
        elif ring_variant == "in_large_ring":
            parts.append(
                f"\U0001f534 LARGE MONEY CAROUSEL — This account belongs to a {scc}-member "
                f"circular money network. {out_f} has been cycled through this group. "
                f"Fund cycling on this scale with no clear business purpose strongly indicates "
                f"a professional money laundering operation."
            )
        else:
            parts.append(
                f"\U0001f534 CIRCULAR MONEY LOOP — This account is one of {scc} accounts "
                f"sending money to each other in a closed circle. {out_f} is circulating "
                f"in this loop with no legitimate business purpose identified. "
                f"Circular money flows ARE money laundering \u2014 funds that go in circles "
                f"appear to have a transaction history but no real value has been created."
            )

    if structuring and "potential_structuring" not in combo_fired:
        parts.append(
            f"\U0001f534 DELIBERATE PAYMENT SPLITTING — Transactions are being structured "
            f"in amounts just below the $10,000 mandatory reporting threshold. "
            f"Out of {out_f} in outgoing payments, multiple transactions fall just under $10K. "
            f"This is called 'structuring' — a federal offence in most jurisdictions, "
            f"even when the underlying money is legitimate."
        )

    if ctr_avoid:
        parts.append(
            f"\U0001f534 THRESHOLD BRACKET ACTIVITY — {ctr_cnt} transaction(s) detected in "
            f"the $9,000–$9,999 bracket \u2014 specifically designed to sit just under the "
            f"$10,000 Currency Transaction Report trigger. The concentration of amounts in "
            f"this narrow band is statistically unlikely to be coincidental."
        )

    if layering:
        parts.append(
            f"\U0001f534 PASS-THROUGH ACCOUNT — This account functions as a relay station: "
            f"{in_f} received from external sources and {out_f} forwarded onwards. "
            f"A genuine banking account retains funds; a layering account simply moves them. "
            f"Being a pass-through is the defining characteristic of the layering stage "
            f"of money laundering."
        )

    if relay and "temporal_is_temporal_relay" not in combo_fired:
        cnt_str = f"{relay_cnt} occasion(s)" if relay_cnt > 0 else "multiple occasions"
        parts.append(
            f"\U0001f534 SAME-DAY MONEY FORWARDING — Funds received and forwarded on "
            f"{cnt_str} (within 24 hours of receipt). Money that does not stay is not being "
            f"used for the account holder's purposes \u2014 it is being relayed through this "
            f"account to another destination, classic layering behaviour."
        )

    if scripted and "temporal_is_scripted_regular" not in combo_fired:
        parts.append(
            f"\u26a0\ufe0f ROBOT-LIKE TRANSACTION PATTERN — Transactions occur at unnaturally "
            f"regular intervals, inconsistent with normal human banking behaviour. "
            f"Real customers make payments at varying times. Scripted regularity indicates "
            f"automated software controlling this account, which may have been taken over "
            f"or opened fraudulently."
        )

    if burst and burst_cnt > 0:
        parts.append(
            f"\u26a0\ufe0f SUDDEN TRANSACTION BURST — {burst_cnt} burst period(s) detected where "
            f"transaction frequency spiked dramatically above the account's normal baseline. "
            f"Criminals often use accounts intensively for short windows before abandoning them. "
            f"Sudden spikes in an otherwise quiet account are a red flag."
        )

    if k >= 3:
        parts.append(
            f"\u26a0\ufe0f TIGHTLY LINKED ACCOUNT CLUSTER (depth {k}) — This account sits within "
            f"a dense network where every member connects to every other member at depth {k}. "
            f"Normal banking networks are loose; tight clusters of mutually transacting accounts "
            f"indicate an organised group operating together."
        )

    if motif_circ:
        parts.append(
            f"\u26a0\ufe0f MONEY BOUNCING BACK — A triangular transaction pattern detected: "
            f"money sent from this account returns via one or two intermediary accounts. "
            f"This 'bounce-back' pattern is used to create fictitious transaction records "
            f"while keeping money under the same effective control."
        )

    if powerlaw:
        parts.append(
            f"\u26a0\ufe0f HUB ACCOUNT — This account connects to an extreme number of other "
            f"accounts (out-degree: {out_deg}, in-degree: {in_deg}). "
            f"Hub accounts are control centres of money laundering networks, distributing "
            f"or collecting funds across dozens of recipient accounts."
        )

    if out_deg >= 20 and not powerlaw:
        parts.append(
            f"\u26a0\ufe0f MONEY DISPERSED TO {out_deg} DIFFERENT RECIPIENTS — Sending to this "
            f"many unique accounts ({out_f} across {out_deg} recipients) is inconsistent "
            f"with normal individual or business banking. Distributing funds widely across "
            f"many accounts is a layering technique."
        )

    if in_deg >= 20 and not powerlaw:
        parts.append(
            f"\u26a0\ufe0f RECEIVING FROM {in_deg} DIFFERENT SENDERS — Collecting {in_f} from "
            f"{in_deg} different sources with no apparent invoicing or contract relationship "
            f"suggests this account is aggregating funds from a diffuse network of "
            f"contributors \u2014 a placement stage indicator."
        )

    if infra >= 1 and "shared_infrastructure_count" not in combo_fired:
        parts.append(
            f"\U0001f534 SHARED IDENTIFIERS WITH OTHER FLAGGED ACCOUNTS — "
            f"{infra} shared detail(s) found (device ID, address, or contact) with other "
            f"accounts in our suspicious customer list. Sharing identifiers with other "
            f"flagged accounts is strong evidence of a common controller."
        )

    if benford1:
        parts.append(
            f"\u26a0\ufe0f UNNATURAL TRANSACTION AMOUNTS — The first digits of this customer's "
            f"transaction amounts do not follow the natural distribution (Benford's Law) "
            f"observed in real-world financial data. This statistical signature is used by "
            f"forensic accountants to detect manipulated or fabricated transactions."
        )

    if benford2:
        parts.append(
            f"\u26a0\ufe0f SECOND-DIGIT CLUSTERING — Transaction amounts show an unusual "
            f"concentration at specific second-digit values, inconsistent with genuine "
            f"commercial activity. This pattern is found in round-number or threshold-motivated "
            f"transactions designed to look natural but aren't."
        )

    if cc >= 5 and cc < 7 and "consensus_count" not in combo_fired:
        parts.append(
            f"\u26a0\ufe0f {cc} DETECTION SYSTEMS FLAGGED THIS ACCOUNT — Our system runs "
            f"{cc} independent AML detection methods simultaneously. When {cc} of them all "
            f"flag the same customer (risk score: {score:.0f}/100), it means different types "
            f"of suspicious activity overlap in one account. Multi-signal cases are the most "
            f"reliable fraud detections \u2014 and the most serious."
        )

    # Large flow amounts (only add if no more specific signal already covers them)
    if circ_cnt >= 1 and "temporal_circular_flow_count" not in {k for k in combo_fired}:
        parts.append(
            f"\u26a0\ufe0f RECURRING CIRCULAR FLOWS — {circ_cnt} separate circular flow event(s) "
            f"detected historically. Recurring circular patterns show this is not a one-time "
            f"anomaly but a repeated operational behaviour."
        )

    if out_flow >= 100_000 and not parts:
        parts.append(
            f"\u26a0\ufe0f VERY HIGH OUTGOING TRANSFERS — {out_f} has left this account, "
            f"an unusually large outflow for a customer of this profile. "
            f"Source-of-funds documentation is required to explain this volume."
        )

    if in_flow >= 100_000 and not any("incoming" in p.lower() or "inflow" in p.lower() for p in parts):
        parts.append(
            f"\u26a0\ufe0f VERY HIGH INCOMING FUNDS — {in_f} received from external sources, "
            f"a volume inconsistent with the customer's declared profile. "
            f"Wealth verification is required."
        )

    # ══════════════════════════════════════════════════════════════════════════
    # STEP 3 — RISK SCORE FALLBACK (for accounts with no discrete binary signals)
    # ══════════════════════════════════════════════════════════════════════════
    if not parts:
        if score >= 90:
            parts.append(
                f"\U0001f534 EXTREME RISK SCORE: {score:.0f}/100 — This account scored in the "
                f"top 1% of the entire customer portfolio. Our model evaluates 20+ signals "
                f"simultaneously; a score of {score:.0f}/100 means the combined weight of "
                f"evidence is extremely elevated even if no single signal dominated. "
                f"Total flow processed: {tot_f}."
            )
        elif score >= 75:
            parts.append(
                f"\u26a0\ufe0f HIGH RISK SCORE: {score:.0f}/100 — Rated in the top 5% of our "
                f"customer portfolio. Multiple moderate signals combine into a significant "
                f"overall risk profile. Total flow: {tot_f} "
                f"({in_f} received, {out_f} sent). Enhanced due diligence is warranted."
            )
        elif score >= 55:
            parts.append(
                f"\U0001f4cb ELEVATED RISK SCORE: {score:.0f}/100 — Above the monitoring "
                f"threshold. Pattern warrants documentation and 30-day watchlist. "
                f"Total flow: {tot_f}. Review at next quarterly AML cycle."
            )
        else:
            parts.append(
                f"Risk score {score:.0f}/100 — included for monitoring based on network "
                f"proximity to higher-risk accounts. Total flow: {tot_f}."
            )

    return "\n\n".join(parts)


def build_action_required(signals: Dict[str, Any]) -> str:
    """
    Return the single highest-priority recommended action for this customer.
    Based on the most severe signal fired.

    Returns
    -------
    str  — one-line action recommendation.
    """
    best_severity = 0
    best_action = "Continue standard monitoring."

    for signal_key, rule in SIGNAL_RULES.items():
        val = signals.get(signal_key, 0)
        if not val or float(val) == 0:
            continue

        # Apply same threshold guards as build_business_narrative
        fv = float(val)
        if signal_key == "k_core" and fv < 3:
            continue
        if signal_key == "shared_infrastructure_count" and fv < 1:
            continue
        if signal_key == "temporal_circular_flow_count" and fv < 1:
            continue
        if signal_key == "temporal_burst_count" and fv < 1:
            continue
        if signal_key == "consensus_count" and fv < 5:
            continue
        if signal_key == "benfords_second_anomaly" and int(fv) != 1:
            continue

        sev = _SEVERITY_ORDER.get(rule["severity"], 0)
        if sev > best_severity:
            best_severity = sev
            best_action = rule["what_to_do"]

    return best_action


def build_full_explanation(signals: Dict[str, Any]) -> List[Dict[str, str]]:
    """
    Return a list of dicts — one per fired signal — each with:
      signal, why_flagged, what_it_means, what_to_do, severity

    Used for the tooltip / drill-down view.
    """
    explanations: List[Dict[str, str]] = []

    for signal_key, rule in SIGNAL_RULES.items():
        val = signals.get(signal_key, 0)
        if not val or float(val) == 0:
            continue

        fv = float(val)
        if signal_key == "k_core" and fv < 3:
            continue
        if signal_key == "shared_infrastructure_count" and fv < 1:
            continue
        if signal_key == "temporal_circular_flow_count" and fv < 1:
            continue
        if signal_key == "temporal_burst_count" and fv < 1:
            continue
        if signal_key == "consensus_count" and fv < 5:
            continue
        if signal_key == "benfords_second_anomaly" and int(fv) != 1:
            continue

        kw: Dict[str, Any] = {"val": fv}
        if signal_key == "in_ring":
            kw["sz"] = int(float(signals.get("scc_size", 2)))
        elif signal_key == "k_core":
            kw["k"] = int(fv)
        elif signal_key == "potential_ctr_avoidance":
            kw["cnt"] = int(float(signals.get("ctr_bracket_count", 1)))
        elif signal_key == "shared_infrastructure_count":
            kw["infra"] = int(fv)
        elif signal_key == "temporal_circular_flow_count":
            kw["circ_cnt"] = int(fv)
            circ_val = float(signals.get("temporal_circular_flow_value", 0))
            kw["circ_val_str"] = f"(${int(circ_val):,} total)" if circ_val > 0 else ""
        elif signal_key == "temporal_burst_count":
            kw["burst_cnt"] = int(fv)
        elif signal_key == "consensus_count":
            kw["cc"] = int(fv)
        elif signal_key == "temporal_is_temporal_relay":
            relay_cnt = int(float(signals.get("temporal_temporal_relay_count", 2)))
            kw["relay_cnt"] = max(relay_cnt, 2)

        explanations.append({
            "signal": signal_key,
            "severity": rule["severity"],
            "why_flagged": _fmt(rule["why_flagged"], **kw),
            "what_it_means": _fmt(rule["what_it_means"], **kw),
            "what_to_do": _fmt(rule["what_to_do"], **kw),
        })

    # Sort by severity (highest first)
    explanations.sort(key=lambda x: _SEVERITY_ORDER.get(x["severity"], 0), reverse=True)
    return explanations


def get_overall_priority_label(signals: Dict[str, Any]) -> str:
    """
    Return a one-line manager summary: overall risk verdict + single strongest reason.
    e.g. "CRITICAL — Circular money ring involving 5 accounts detected"
    """
    best_sev = 0
    best_signal_key = None

    for signal_key, rule in SIGNAL_RULES.items():
        val = signals.get(signal_key, 0)
        if not val or float(val) == 0:
            continue
        fv = float(val)
        if signal_key == "k_core" and fv < 3:
            continue
        if signal_key == "consensus_count" and fv < 5:
            continue
        sev = _SEVERITY_ORDER.get(rule["severity"], 0)
        if sev > best_sev:
            best_sev = sev
            best_signal_key = signal_key

    if not best_signal_key:
        return "LOW RISK — No specific suspicious patterns detected"

    tier_words = {4: "CRITICAL", 3: "HIGH RISK", 2: "MEDIUM RISK", 1: "LOW RISK"}
    verdict = tier_words.get(best_sev, "REVIEW")

    rule = SIGNAL_RULES[best_signal_key]
    fv = float(signals.get(best_signal_key, 1))
    kw: Dict[str, Any] = {"val": fv}
    if best_signal_key == "in_ring":
        kw["sz"] = int(float(signals.get("scc_size", 2)))
    elif best_signal_key == "k_core":
        kw["k"] = int(fv)
    elif best_signal_key == "potential_ctr_avoidance":
        kw["cnt"] = int(float(signals.get("ctr_bracket_count", 1)))
    elif best_signal_key == "consensus_count":
        kw["cc"] = int(fv)

    short = _fmt(rule["why_flagged"], **kw)
    # trim to ~80 chars for display
    if len(short) > 80:
        short = short[:77] + "..."
    return f"{verdict} — {short}"


# ── Lobby / Ring business commentary ──────────────────────────────────────────

def ring_business_summary(
    size: int,
    avg_risk: float,
    total_flow: float,
    tier: str,
    ring_id,
) -> Dict[str, str]:
    """
    Generate a plain-English business summary for one lobby ring card.
    Works with any data dynamically — inputs drive the output.

    Returns dict with keys: headline, what_happened, business_risk, next_step
    """
    tier_word = {"P1": "CRITICAL", "P2": "HIGH RISK", "P3": "MEDIUM RISK", "P4": "LOWER RISK"}.get(tier, "REVIEW")
    flow_str = f"${total_flow:,.0f}" if total_flow > 0 else "amount undetermined"

    if tier == "P1":
        headline = f"🚨 Suspicious money loop — {size} accounts, {flow_str} in circulation"
        what_happened = (
            f"We have identified {size} customer accounts that are sending money to each other "
            f"in a circular pattern. A total of {flow_str} is moving around this loop. "
            f"Money that 'goes in circles' between accounts has no legitimate business purpose — "
            f"it is a textbook method of disguising the source of criminal funds."
        )
        business_risk = (
            f"Circular money flows of this analytical strength (risk score: {avg_risk:.0f}/100) "
            f"represent the top tier of findings in our current portfolio. "
            f"Understanding the true business purpose behind these flows is critical to forming "
            f"an accurate picture of this customer segment — and should be the starting point "
            f"for any further investigation."
        )
        next_step = (
            "URGENT INTERNAL REVIEW ADVISED: (1) Conduct a deep-dive on all {sz} accounts — "
            "map the full transaction trail, counterparty relationships, and declared source of funds. "
            "(2) Escalate findings to senior management for advisory decision — "
            "this pattern is among the strongest analytical signals in the current portfolio. "
            "(3) Document the observed behaviour in detail before any external steps are considered."
        ).format(sz=size)

    elif tier == "P2":
        headline = f"⚠️ High-risk circular group — {size} accounts, {flow_str} flowing"
        what_happened = (
            f"A group of {size} accounts has been detected with suspicious circular money flow "
            f"totalling {flow_str}. While not yet confirmed as fraud, the pattern is "
            f"consistent with layering — a stage in the money laundering process where "
            f"funds are moved between accounts to obscure their origin."
        )
        business_risk = (
            f"Accounts with risk scores in the 60–80 range (this group: {avg_risk:.0f}/100) "
            f"fall in the top 5% of our portfolio. While not every high-risk account is "
            f"laundering, ignoring this group creates regulatory exposure."
        )
        next_step = (
            "PRIORITY ANALYST REVIEW: (1) Conduct an enhanced review of all {sz} accounts — "
            "focus on flow direction, counterparty profile, and transaction timing. "
            "(2) Request context from account holders (stated purpose, relationship "
            "with other ring members). "
            "(3) Assign to a senior analyst and document findings independently."
        ).format(sz=size)

    elif tier == "P3":
        headline = f"📋 Medium-risk group — {size} accounts require monitoring, {flow_str} in flow"
        what_happened = (
            f"A group of {size} accounts shows some patterns of circular transactions "
            f"totalling {flow_str}. The activity level currently falls in the medium-risk "
            f"range and may have a legitimate explanation, but warrants closer attention."
        )
        business_risk = (
            f"These accounts (risk score: {avg_risk:.0f}/100) are in the top 5–15% of our "
            f"customer base. Many medium-risk patterns resolve with customer explanation, "
            f"but unmonitored medium-risk accounts can escalate to high-risk quickly."
        )
        next_step = (
            "SCHEDULE REVIEW: (1) Add to the 30-day monitoring watchlist. "
            "(2) Review the next statement cycle for escalating patterns. "
            "(3) Send routine 'source of funds' questionnaire to account holders."
        )

    else:
        headline = f"📊 Low-risk group — {size} accounts, routine monitoring, {flow_str} in flow"
        what_happened = (
            f"A group of {size} accounts shows minor connectivity in transaction patterns. "
            f"Current activity levels ({avg_risk:.0f}/100 risk score) do not suggest "
            f"immediate concern but are included for completeness."
        )
        business_risk = "Low regulatory exposure at current activity levels."
        next_step = "STANDARD MONITORING: Continue normal transaction review cycle."

    return {
        "tier_word": tier_word,
        "headline": headline,
        "what_happened": what_happened,
        "business_risk": business_risk,
        "next_step": next_step,
    }


def lobby_portfolio_summary(
    total_lobbies: int,
    total_flow: float,
    p1_count: int,
    p2_count: int,
    max_ring_size: int,
    total_customers: int,
) -> Dict[str, str]:
    """
    Generate a plain-English executive summary for the lobby page banner.
    Designed for a Branch Manager or CCO reading level.
    """
    pct_in_lobbies = (total_customers / max(total_customers, 1) * 100) if total_customers else 0
    flow_str = f"${total_flow:,.0f}"

    if p1_count > 0:
        urgency = "ELEVATED PATTERN DETECTED — SENIOR REVIEW ADVISED"
        colour = "red"
        banner = (
            f"Our analytical engine has identified {total_lobbies} circular flow pattern(s), "
            f"of which {p1_count} show the strongest evidence and warrant urgent internal review. "
            f"A total of {flow_str} is observed circulating through these groups. "
            f"The largest single ring involves {max_ring_size} participants. "
            f"{'All ' + str(p1_count) + ' top-priority group' + ('s' if p1_count > 1 else '')} "
            f"are recommended for senior management advisory review."
        )
    elif p2_count > 0:
        urgency = "HIGH-RISK PATTERNS — ANALYST PRIORITY THIS WEEK"
        colour = "orange"
        banner = (
            f"Our system has identified {total_lobbies} circular flow pattern(s). "
            f"{p2_count} group(s) are rated high-risk and are recommended for analyst review this week. "
            f"Total observed flow across these groups: {flow_str}. "
            f"No top-priority (P1) patterns at this time — the {p2_count} high-risk group(s) "
            f"should not remain unreviewed beyond the current analysis cycle."
        )
    elif total_lobbies > 0:
        urgency = "PATTERNS NOTED — ROUTINE MONITORING"
        colour = "yellow"
        banner = (
            f"Our system has detected {total_lobbies} group(s) of accounts with connected "
            f"transaction patterns. All are currently rated medium or lower risk. "
            f"Total observed flow in these groups: {flow_str}. "
            f"Include in next scheduled analytical review cycle."
        )
    else:
        urgency = "NO SUSPICIOUS GROUPS DETECTED"
        colour = "green"
        banner = (
            "No circular money groups were detected in the current dataset. "
            "This is a healthy result. Continue standard monitoring procedures."
        )

    return {
        "urgency": urgency,
        "colour": colour,
        "banner": banner,
    }
