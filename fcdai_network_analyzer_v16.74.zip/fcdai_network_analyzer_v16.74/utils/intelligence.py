"""
FCDAI v12.4 - Intelligence Engine
==================================
AIR-GAPPED | Pure Python | No external ML deps beyond scikit-learn
Provides: Explainability, Alert Deduplication, Typology Tagging,
          Watchlist Cross-Reference, Threshold Tuning
v12.4: Added NaN-safe column access in tag_typologies (HIGH-05 fix).
"""

import hashlib
import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))

# ─────────────────────────────────────────────────────────────────────────────
# I1: EXPLAINABILITY — Feature attribution for risk scores
# ─────────────────────────────────────────────────────────────────────────────


def explain_risk_score(
    node_id: str,
    scored_df: pd.DataFrame,
    analytics_results: Dict[str, pd.DataFrame],
    risk_weights: Dict[str, float],
) -> Dict:
    """
    Compute per-family contribution to a customer's risk score.
    Returns dict: {family: contribution_pct, ...} sorted descending.
    """
    if scored_df is None or scored_df.empty:
        return {}

    row = scored_df[scored_df.get("node_id", scored_df.index) == node_id]
    if hasattr(scored_df, "columns") and "node_id" in scored_df.columns:
        row = scored_df[scored_df["node_id"] == node_id]
    if len(row) == 0:
        return {}

    row = row.iloc[0]
    total_score = float(row.get("risk_score", 0))
    if total_score == 0:
        return {}

    contributions = {}
    for family, weight in risk_weights.items():
        col_candidates = [f"{family}_score", f"{family}_risk", family]
        for col in col_candidates:
            if col in row.index:
                val = float(row[col]) if not pd.isna(row[col]) else 0.0
                contributions[family] = round(val * weight, 2)
                break
        else:
            contributions[family] = 0.0

    total = sum(contributions.values()) or 1
    pct = {k: round(v / total * 100, 1) for k, v in contributions.items()}
    return dict(sorted(pct.items(), key=lambda x: x[1], reverse=True))


def get_top_features(
    node_id: str,
    scored_df: pd.DataFrame,
    analytics_results: Dict,
    risk_weights: Dict,
    top_n: int = 5,
) -> List[Dict]:
    """Return top N contributing features as list of {family, pct, label}."""
    contribs = explain_risk_score(node_id, scored_df, analytics_results, risk_weights)
    result = []
    labels = {
        "centrality": "Network Centrality",
        "community": "Community Structure",
        "pathflow": "Transaction Flow",
        "anomaly": "Anomaly Detection",
        "temporal": "Temporal Patterns",
        "link_prediction": "Link Prediction",
        "multi_layer": "Multi-Layer Analysis",
    }
    for family, pct in list(contribs.items())[:top_n]:
        result.append(
            {
                "family": family,
                "label": labels.get(family, family.replace("_", " ").title()),
                "pct": pct,
            }
        )
    return result


# ─────────────────────────────────────────────────────────────────────────────
# I2: ALERT DEDUPLICATION
# ─────────────────────────────────────────────────────────────────────────────


def compute_alert_hash(node_id: str, risk_tier: str, top_pattern: str) -> str:
    """Stable hash for deduplication across runs."""
    key = f"{node_id}|{risk_tier}|{top_pattern}"
    return hashlib.sha256(key.encode()).hexdigest()[:16]


def deduplicate_alerts(scored_df: pd.DataFrame, db) -> pd.DataFrame:
    """
    Tag each alert as NEW / SEEN / ESCALATED based on dedup registry in DB.
    Adds 'dedup_status' column to scored_df.
    """
    if scored_df is None or scored_df.empty:
        return scored_df

    result = scored_df.copy()
    result["dedup_status"] = "NEW"
    result["alert_hash"] = ""

    try:
        existing_hashes = db.get_alert_hashes() if hasattr(db, "get_alert_hashes") else {}
    except Exception:
        existing_hashes = {}

    for idx, row in result.iterrows():
        node_id = str(row.get("node_id", ""))
        tier = str(row.get("risk_tier", ""))
        pattern = str(row.get("top_pattern", ""))
        ahash = compute_alert_hash(node_id, tier, pattern)
        result.at[idx, "alert_hash"] = ahash

        if ahash in existing_hashes:
            prev_tier = existing_hashes[ahash].get("tier", tier)
            tier_order = {"P4": 0, "P3": 1, "P2": 2, "P1": 3}
            if tier_order.get(tier, 0) > tier_order.get(prev_tier, 0):
                result.at[idx, "dedup_status"] = "ESCALATED"
            else:
                result.at[idx, "dedup_status"] = "SEEN"

    return result


# ─────────────────────────────────────────────────────────────────────────────
# I3: TYPOLOGY LIBRARY
# ─────────────────────────────────────────────────────────────────────────────

TYPOLOGY_DESCRIPTIONS = {
    "Structuring": "Breaking large transactions into smaller amounts to avoid reporting thresholds",
    "Smurfing": "Multiple individuals depositing small amounts into accounts controlled by one person",
    "Layering": "Complex chain of transactions to obscure the audit trail",
    "Round-Tripping": "Funds sent out and returned through circular transaction paths",
    "Trade-Based": "Cross-border flows potentially used to misrepresent trade value",
}


def _safe_float(val) -> float:
    """Convert value to float, treating None/NaN as 0.0."""
    if val is None:
        return 0.0
    try:
        f = float(val)
        return 0.0 if pd.isna(f) else f
    except (ValueError, TypeError):
        return 0.0


def tag_typologies(row: pd.Series, analytics_results: Dict[str, pd.DataFrame]) -> List[str]:
    """
    Rule-based typology tagging for a single customer row.
    Returns list of matched typology names.
    v12.4: Uses _safe_float() for NaN-safe column access (HIGH-05 fix).
    """
    tags = []

    struct_score = _safe_float(row.get("structuring_score", 0))
    if struct_score > 0.5:
        tags.append("Structuring")

    comm_score = _safe_float(row.get("community_score", 0))
    flow_score = _safe_float(row.get("pathflow_score", 0))
    if comm_score > 0.5 and flow_score > 0.4:
        tags.append("Smurfing")

    path_score = _safe_float(row.get("pathflow_score", 0))
    if path_score > 0.6:
        tags.append("Layering")

    cycle_score = _safe_float(row.get("cycle_score", 0))
    if cycle_score > 0.3:
        tags.append("Round-Tripping")

    geo_score = _safe_float(row.get("geo_risk_score", 0))
    if geo_score > 0.5:
        tags.append("Trade-Based")

    return tags


def apply_typologies(
    scored_df: pd.DataFrame, analytics_results: Dict[str, pd.DataFrame]
) -> pd.DataFrame:
    """Add 'typologies' column to scored_df."""
    if scored_df is None or scored_df.empty:
        return scored_df
    result = scored_df.copy()
    result["typologies"] = result.apply(lambda row: tag_typologies(row, analytics_results), axis=1)
    result["typology_str"] = result["typologies"].apply(lambda t: ", ".join(t) if t else "None")
    return result


# ─────────────────────────────────────────────────────────────────────────────
# I4: WATCHLIST CROSS-REFERENCE
# ─────────────────────────────────────────────────────────────────────────────

_watchlist_cache: Optional[pd.DataFrame] = None


def load_watchlist(path: Path) -> pd.DataFrame:
    """Load watchlist CSV. Expected columns: entity_id, entity_name, reason, severity."""
    global _watchlist_cache
    if _watchlist_cache is not None:
        return _watchlist_cache
    try:
        if path.exists():
            df = pd.read_csv(path, dtype=str)
            _watchlist_cache = df
            return df
    except Exception:
        pass
    return pd.DataFrame(columns=["entity_id", "entity_name", "reason", "severity"])


def check_watchlist(node_ids: List[str], watchlist_path: Path) -> Dict[str, Dict]:
    """
    Check node_ids against watchlist.
    Returns {node_id: {hit: bool, reason, severity}} for hits only.
    """
    wl = load_watchlist(watchlist_path)
    if wl.empty:
        return {}

    hits = {}
    wl_ids = set(wl.get("entity_id", pd.Series(dtype=str)).str.strip().str.upper())

    for nid in node_ids:
        if str(nid).strip().upper() in wl_ids:
            match = wl[wl["entity_id"].str.strip().str.upper() == str(nid).strip().upper()]
            if len(match) > 0:
                hits[nid] = {
                    "hit": True,
                    "reason": match.iloc[0].get("reason", "Watchlist match"),
                    "severity": match.iloc[0].get("severity", "HIGH"),
                }
    return hits


def apply_watchlist_flags(scored_df: pd.DataFrame, watchlist_path: Path) -> pd.DataFrame:
    """Add 'watchlist_hit' and 'watchlist_reason' columns."""
    if scored_df is None or scored_df.empty:
        return scored_df
    result = scored_df.copy()
    node_ids = result.get("node_id", pd.Series(dtype=str)).tolist()
    hits = check_watchlist(node_ids, watchlist_path)
    result["watchlist_hit"] = result["node_id"].apply(lambda n: n in hits)
    result["watchlist_reason"] = result["node_id"].apply(
        lambda n: hits[n]["reason"] if n in hits else ""
    )
    return result


# ─────────────────────────────────────────────────────────────────────────────
# I5: THRESHOLD TUNING
# ─────────────────────────────────────────────────────────────────────────────


def apply_custom_thresholds(
    scored_df: pd.DataFrame, thresholds: Dict[str, Tuple[float, float]]
) -> pd.DataFrame:
    """
    Re-tier customers using custom thresholds without re-running pipeline.
    thresholds: {"P1": (80, 100), "P2": (60, 80), ...}
    Returns copy with updated 'risk_tier' column.
    """
    if scored_df is None or scored_df.empty:
        return scored_df
    result = scored_df.copy()

    def assign_tier(score):
        for tier, (low, high) in sorted(thresholds.items(), key=lambda x: x[1][0], reverse=True):
            if low <= score <= high:
                return tier
        return "P4"

    if "risk_score" in result.columns:
        result["risk_tier"] = result["risk_score"].apply(assign_tier)
    return result


def preview_threshold_impact(
    scored_df: pd.DataFrame, thresholds: Dict[str, Tuple[float, float]]
) -> Dict:
    """
    Show how many customers move between tiers with new thresholds.
    Returns {tier: {old_count, new_count, delta}} dict.
    """
    if scored_df is None or scored_df.empty:
        return {}

    old_counts = (
        scored_df["risk_tier"].value_counts().to_dict() if "risk_tier" in scored_df.columns else {}
    )
    new_df = apply_custom_thresholds(scored_df, thresholds)
    new_counts = new_df["risk_tier"].value_counts().to_dict()

    result = {}
    all_tiers = set(list(old_counts.keys()) + list(new_counts.keys()))
    for tier in all_tiers:
        old = old_counts.get(tier, 0)
        new = new_counts.get(tier, 0)
        result[tier] = {"old": old, "new": new, "delta": new - old}
    return result
