"""
FCDAI v10 - PII Guard & Data Protection
==========================================
AIR-GAPPED | ZERO DATA LEAKAGE | PII PROTECTED
Masks, hashes, and redacts PII in DataFrames, logs, and exports.
All processing is local — no external calls.
"""

import hashlib
import re
import pandas as pd
import numpy as np
from typing import List, Optional, Dict
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import PII


def mask_value(value, mode: str = None) -> str:
    """Mask a single PII value. Modes: partial, full, hash."""
    mode = mode or PII.MASK_MODE
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return ""
    s = str(value)
    if not s:
        return ""
    if mode == "full":
        return "***REDACTED***"
    elif mode == "hash":
        return hashlib.new(PII.HASH_ALGO, s.encode("utf-8")).hexdigest()[:12]
    else:  # partial
        if len(s) <= 4:
            return s[0] + "***"
        return s[:2] + "***" + s[-2:]


def mask_dataframe(df: pd.DataFrame, fields: List[str] = None, mode: str = None) -> pd.DataFrame:
    """Return a copy of df with PII fields masked."""
    if df is None or df.empty:
        return df
    fields = fields or PII.FIELDS_TO_MASK
    result = df.copy()
    for col in fields:
        if col in result.columns:
            result[col] = result[col].apply(lambda v: mask_value(v, mode))
    return result


def mask_for_export(df: pd.DataFrame) -> pd.DataFrame:
    """Mask PII for file exports (CSV, Excel, PDF)."""
    if not PII.EXPORT_REDACTION:
        return df
    return mask_dataframe(df)


def mask_for_log(text: str) -> str:
    """Redact potential PII from log messages. Bank-grade: covers IDs, emails, phones, IBANs."""
    if not PII.LOG_REDACTION:
        return text
    # Mask customer IDs (CUST000001 or CUST_000001 pattern)
    text = re.sub(r"CUST[_-]?\d{4,}", "CUST***", text)
    # Mask account IDs
    text = re.sub(r"ACCT[_-]?\d{4,}", "ACCT***", text)
    # Mask email-like patterns
    text = re.sub(r"[\w.+-]+@[\w-]+\.[\w.]+", "***@***.***", text)
    # Mask IBAN-like patterns (2 letters + 2 digits + 10-30 alphanumeric) — before numeric
    text = re.sub(r"\b[A-Z]{2}\d{2}[A-Z0-9]{10,30}\b", "[IBAN-REDACTED]", text)
    # Mask long numeric sequences (account numbers, card numbers, national IDs) — before phone
    text = re.sub(r"\b\d{8,}\b", "[NUM-REDACTED]", text)
    # Mask phone-like patterns (international and local) — after long numbers
    text = re.sub(r"\b\+?\d[\d\s\-().]{8,}\d\b", "***-***-****", text)
    # Mask long quoted strings in SQL errors / exception messages (potential PII values)
    text = re.sub(r"'[^']{15,}'", "'[REDACTED]'", text)
    text = re.sub(r'"[^"]{15,}"', '"[REDACTED]"', text)
    return text


def redact_dict(d: Dict, fields: List[str] = None) -> Dict:
    """Redact PII fields from a dictionary."""
    fields = fields or PII.FIELDS_TO_MASK
    result = {}
    for k, v in d.items():
        if k in fields:
            result[k] = mask_value(v)
        elif isinstance(v, dict):
            result[k] = redact_dict(v, fields)
        else:
            result[k] = v
    return result


def validate_air_gap():
    """Verify no external connections are configured. Called at startup."""
    import socket

    # Check that we're only binding to localhost
    from config import APP

    if APP.HOST not in ("127.0.0.1", "localhost", "0.0.0.0"):
        raise RuntimeError(f"AIR-GAP VIOLATION: Host {APP.HOST} is not localhost")
    if not APP.SERVE_LOCALLY:
        raise RuntimeError("AIR-GAP VIOLATION: serve_locally must be True")
    return True
