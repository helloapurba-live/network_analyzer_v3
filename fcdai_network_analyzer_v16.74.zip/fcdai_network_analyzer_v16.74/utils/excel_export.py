"""
FCDAI v12.43 - Excel Multi-Sheet Investigation Package
=======================================================
AIR-GAPPED: Uses openpyxl (already in requirements). No external calls.
Exports a business-grade multi-sheet Excel workbook for AML investigators.

Sheets produced:
  1. Portfolio Intelligence Summary  — key metrics at a glance
  2. Full Scored Portfolio            — every customer with score + tier + action
  3. P1 Critical Risk                 — immediate escalation candidates
  4. P2 High Risk                     — enhanced due diligence candidates
  5. Risk Distribution Matrix         — tier breakdown with counts and percentages
  6-15. Per-Family Analytics          — one sheet per active detection engine
  16. Data Sources                    — input table inventory
"""

import pandas as pd
from pathlib import Path
from datetime import datetime
from typing import Dict, Optional
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import PATHS
from utils.pii_guard import mask_for_export

# Business-friendly names for analytics families
_FAMILY_DISPLAY = {
    "centrality": "Relationship Influence",
    "community": "Risk Group Identification",
    "pathflow": "Money Flow Tracing",
    "link_prediction": "Hidden Relationship Discovery",
    "anomaly": "Behavioural Anomaly Detection",
    "temporal": "Time-Pattern Risk Analysis",
    "multi_layer": "Cross-Entity Risk Assessment",
    "structuring": "Structuring & Smurfing",
    "benfords": "Numeric Pattern Compliance",
    "motifs": "Transaction Pattern Recognition",
}

_TIER_ACTION = {
    "P1": "ESCALATE — Narrative Filing Required",
    "P2": "Enhanced Due Diligence Required",
    "P3": "Routine Monitoring",
    "P4": "Standard Processing",
}
_TIER_LABEL = {
    "P1": "Critical Risk (80–100)",
    "P2": "High Risk (60–80)",
    "P3": "Medium Risk (40–60)",
    "P4": "Low Risk (0–40)",
}


def export_investigation_excel(
    scored_df: pd.DataFrame = None,
    analytics: Dict[str, pd.DataFrame] = None,
    risk_matrix: Dict = None,
    tables: Dict[str, pd.DataFrame] = None,
) -> Path:
    """Export a business-grade investigation package as multi-sheet Excel."""
    PATHS.EXPORTS.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    filepath = PATHS.EXPORTS / f"AML_Investigation_Report_{ts}.xlsx"

    with pd.ExcelWriter(str(filepath), engine="openpyxl") as writer:

        # ── Sheet 1: Portfolio Intelligence Summary ───────────────────────────
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M")
        total = len(scored_df) if scored_df is not None else 0
        p1 = p2 = p3 = p4 = 0
        avg_score = max_score = 0.0
        score_col = None

        if scored_df is not None and len(scored_df) > 0:
            score_col = next(
                (c for c in scored_df.columns if c in ("risk_score", "score", "composite_score")),
                None,
            )
            if score_col is None:
                score_col = next((c for c in scored_df.columns if "score" in c.lower()), None)
            tier_col = next((c for c in scored_df.columns if "tier" in c.lower()), None)
            if tier_col:
                vc = scored_df[tier_col].value_counts()
                p1, p2, p3, p4 = (int(vc.get(k, 0)) for k in ("P1", "P2", "P3", "P4"))
            elif score_col:
                s = scored_df[score_col]
                p1 = int((s >= 80).sum())
                p2 = int(((s >= 60) & (s < 80)).sum())
                p3 = int(((s >= 40) & (s < 60)).sum())
                p4 = int((s < 40).sum())
            if score_col:
                avg_score = round(float(scored_df[score_col].mean()), 2)
                max_score = round(float(scored_df[score_col].max()), 2)

        summary_rows = [
            ("Report Generated", now_str),
            ("Total Customers Analysed", f"{total:,}"),
            ("", ""),
            ("── Risk Tier Breakdown ──", ""),
            ("P1 Critical Risk (Score 80–100)", f"{p1:,}  →  Narrative filing required"),
            ("P2 High Risk (Score 60–80)", f"{p2:,}  →  Enhanced due diligence"),
            ("P3 Medium Risk (Score 40–60)", f"{p3:,}  →  Routine monitoring"),
            ("P4 Low Risk (Score 0–40)", f"{p4:,}  →  Standard processing"),
            ("", ""),
            ("── Score Statistics ──", ""),
            ("Average Risk Score", avg_score),
            ("Highest Risk Score", max_score),
            ("", ""),
            ("── Analytics Engines Run ──", ""),
        ]
        if analytics:
            for key, df in analytics.items():
                rows_ran = len(df) if df is not None else 0
                name = _FAMILY_DISPLAY.get(key, key.replace("_", " ").title())
                summary_rows.append((name, f"{rows_ran:,} customers scored"))

        pd.DataFrame(summary_rows, columns=["Metric", "Value"]).to_excel(
            writer, sheet_name="Portfolio Intelligence", index=False
        )

        # ── Sheet 2: Full Scored Portfolio (PII masked, with action column) ──
        if scored_df is not None and len(scored_df) > 0:
            safe_df = mask_for_export(scored_df).copy()
            # Add business-friendly action column
            if "risk_tier" in safe_df.columns:
                safe_df.insert(
                    safe_df.columns.get_loc("risk_tier") + 1,
                    "Required Action",
                    safe_df["risk_tier"].map(_TIER_ACTION).fillna("Review Required"),
                )
                safe_df.insert(
                    safe_df.columns.get_loc("risk_tier") + 1,
                    "Risk Tier Label",
                    safe_df["risk_tier"].map(_TIER_LABEL).fillna(safe_df["risk_tier"]),
                )
            safe_df.to_excel(writer, sheet_name="Full Scored Portfolio", index=False)

        # ── Sheet 3: P1 Critical (immediate action required) ─────────────────
        if scored_df is not None and len(scored_df) > 0:
            tier_col = next((c for c in scored_df.columns if "tier" in c.lower()), None)
            if tier_col:
                p1_df = scored_df[scored_df[tier_col] == "P1"]
            elif score_col:
                p1_df = scored_df[scored_df[score_col] >= 80]
            else:
                p1_df = pd.DataFrame()
            if len(p1_df) > 0:
                mask_for_export(p1_df).to_excel(
                    writer, sheet_name="P1 Critical — Escalate Now", index=False
                )

        # ── Sheet 4: P2 High Risk ─────────────────────────────────────────────
        if scored_df is not None and len(scored_df) > 0:
            if tier_col:
                p2_df = scored_df[scored_df[tier_col] == "P2"]
            elif score_col:
                p2_df = scored_df[(scored_df[score_col] >= 60) & (scored_df[score_col] < 80)]
            else:
                p2_df = pd.DataFrame()
            if len(p2_df) > 0:
                mask_for_export(p2_df).to_excel(
                    writer, sheet_name="P2 High — Due Diligence", index=False
                )

        # ── Sheet 5: Risk Distribution Matrix ────────────────────────────────
        matrix_rows = []
        tier_total = p1 + p2 + p3 + p4 or 1
        for tier_key, tier_label, count in [
            ("P1", "Critical Risk (Score 80–100)", p1),
            ("P2", "High Risk (Score 60–80)", p2),
            ("P3", "Medium Risk (Score 40–60)", p3),
            ("P4", "Low Risk (Score 0–40)", p4),
        ]:
            matrix_rows.append(
                {
                    "Risk Tier": tier_key,
                    "Description": tier_label,
                    "Customer Count": count,
                    "Portfolio %": f"{round(count / tier_total * 100, 1)}%",
                    "Required Action": _TIER_ACTION.get(tier_key, ""),
                }
            )
        pd.DataFrame(matrix_rows).to_excel(
            writer, sheet_name="Risk Distribution Matrix", index=False
        )

        # ── Sheets 6+: Per-family analytics (business-named sheets) ──────────
        if analytics:
            for family_key, df in analytics.items():
                if df is None or len(df) == 0:
                    continue
                biz_name = _FAMILY_DISPLAY.get(family_key, family_key.replace("_", " ").title())
                # Excel sheet name: max 31 chars
                sheet_name = biz_name[:31]
                mask_for_export(df).to_excel(writer, sheet_name=sheet_name, index=False)

        # ── Sheet: All Data Used in Analysis ───────────────────────────────
        #    Shows every table that was present in pipeline.tables during this run –
        #    both source inputs (customer, transaction, …) and any derived tables
        #    (node, edge).  Mirrors exactly what the detection engine operated on.
        if tables:
            table_info = []
            for name, df in sorted(tables.items()):
                if df is None:
                    continue
                table_kind = "Graph / Derived" if name in {"node", "edge"} else "Source Input"
                table_info.append(
                    {
                        "Table Name": name.replace("_", " ").title(),
                        "Type": table_kind,
                        "Records": len(df),
                        "Fields": len(df.columns),
                        "Column Names": ", ".join(df.columns[:20]),
                    }
                )
            if table_info:
                pd.DataFrame(table_info).to_excel(
                    writer, sheet_name="Data Used in Analysis", index=False
                )

    return filepath
