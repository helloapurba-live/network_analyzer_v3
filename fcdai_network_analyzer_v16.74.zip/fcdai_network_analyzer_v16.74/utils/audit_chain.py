"""
FCDAI v2.1 - Audit Trail Tamper Detection
============================================
Verifies integrity of audit trail entries using SHA-256 hash chain.
Each entry's hash is computed from: action + details + timestamp + prev_hash.
Tampered entries are detected when the stored hash doesn't match recomputed hash.
"""

import hashlib
from typing import List, Dict, Tuple, Optional
from pathlib import Path
import json
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))


def compute_entry_hash(action: str, details: str, timestamp: str, prev_hash: str = "") -> str:
    """Compute SHA-256 hash for an audit entry."""
    payload = f"{action}|{details}|{timestamp}|{prev_hash}"
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:32]


def build_hash_chain(entries: List[Dict]) -> List[Dict]:
    """
    Build a tamper-evident hash chain over audit entries.
    Each entry gets a 'chain_hash' that depends on all previous entries.
    Returns entries with 'chain_hash' added.
    """
    chained = []
    prev_hash = "GENESIS"

    for entry in entries:
        action = str(entry.get("action", ""))
        details = str(entry.get("details", ""))
        timestamp = str(entry.get("timestamp", ""))
        chain_hash = compute_entry_hash(action, details, timestamp, prev_hash)
        enriched = dict(entry)
        enriched["chain_hash"] = chain_hash
        enriched["prev_hash"] = prev_hash
        chained.append(enriched)
        prev_hash = chain_hash

    return chained


def verify_chain(entries: List[Dict]) -> Tuple[bool, List[int]]:
    """
    Verify integrity of a hash-chained audit trail.
    Returns (all_valid: bool, tampered_indices: List[int])
    """
    tampered = []
    prev_hash = "GENESIS"

    for i, entry in enumerate(entries):
        action = str(entry.get("action", ""))
        details = str(entry.get("details", ""))
        timestamp = str(entry.get("timestamp", ""))
        stored_hash = entry.get("chain_hash", "")
        stored_prev = entry.get("prev_hash", "")

        if stored_prev != prev_hash:
            tampered.append(i)
            prev_hash = stored_hash or compute_entry_hash(action, details, timestamp, prev_hash)
            continue

        expected = compute_entry_hash(action, details, timestamp, prev_hash)
        if stored_hash != expected:
            tampered.append(i)

        prev_hash = stored_hash if stored_hash else expected

    return (len(tampered) == 0, tampered)


def get_chain_summary(entries: List[Dict]) -> Dict:
    """
    Return a summary of chain integrity for display in the Audit Trail page.
    """
    if not entries:
        return {
            "total": 0,
            "verified": 0,
            "tampered": 0,
            "integrity": "NO_DATA",
            "tampered_indices": [],
        }

    has_chain = any("chain_hash" in e for e in entries)
    if not has_chain:
        entries = build_hash_chain(entries)

    valid, tampered_indices = verify_chain(entries)

    return {
        "total": len(entries),
        "verified": len(entries) - len(tampered_indices),
        "tampered": len(tampered_indices),
        "integrity": "INTACT" if valid else "COMPROMISED",
        "tampered_indices": tampered_indices,
        "first_entry": entries[0].get("timestamp", "") if entries else "",
        "last_entry": entries[-1].get("timestamp", "") if entries else "",
        "chain_tip": entries[-1].get("chain_hash", "") if entries else "",
    }


def save_chain_to_file(entries: List[Dict], path: Path) -> bool:
    """Save hash-chained audit entries to a JSON file for offline verification."""
    try:
        chained = build_hash_chain(entries)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(chained, f, indent=2, default=str)
        return True
    except Exception:
        return False


def load_and_verify_chain(path: Path) -> Tuple[bool, Dict]:
    """Load chain from file and verify integrity."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            entries = json.load(f)
        summary = get_chain_summary(entries)
        return summary["integrity"] == "INTACT", summary
    except Exception as e:
        return False, {"error": str(e), "integrity": "ERROR"}
