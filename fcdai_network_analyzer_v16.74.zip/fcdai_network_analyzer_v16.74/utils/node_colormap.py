"""
FCDAI Network Analyzer — Dynamic Node-Type Color Map (v16.23 T2)
================================================================
Business Logic:
    Maps node_type values (read from the node table at runtime) to
    deterministic colors from a fixed palette.  No hard-coding of specific
    type names — any value present in the data is handled automatically.

    This module is imported by Radar, Network Intelligence, and Lobby pages
    to ensure CONSISTENT coloring of node types across all visualisations.

Technical:
    - Palette: 10 visually distinct colors suitable for dark backgrounds.
    - Mapping is alphabetically sorted so colors are stable across re-runs.
    - Unknown/None types fall back to #94A3B8 (slate gray).
    - Returns a dict suitable for both Plotly marker colors and Cytoscape
      stylesheet rules.
"""

from typing import Dict, List, Optional
import pandas as pd


# ─── Fixed palette (dark-background safe, ADA-contrast checked) ──────────────
_PALETTE = [
    "#00D4FF",  # cyan      – used for Person
    "#9D4EDD",  # violet    – used for Entity
    "#00E676",  # green     – used for Merchant
    "#FFD600",  # amber     – used for Account
    "#FF6B6B",  # coral     – used for Trust
    "#2196F3",  # blue      – 6th type
    "#FF9800",  # orange    – 7th type
    "#E040FB",  # fuchsia   – 8th type
    "#00BFA5",  # teal      – 9th type
    "#F06292",  # pink      – 10th type
]

_FALLBACK_COLOR = "#94A3B8"  # slate gray for unknown / None

# ─── Fixed colors for node_type1 (Internal / External) ───────────────────────
# These are FIXED (not dynamic) because Internal/External is a binary classification
# with well-known banking semantics and must be consistent across all pages.
NODE_TYPE1_COLORS: Dict[str, str] = {
    "Internal": "#2196F3",   # blue  – bank-owned accounts / assets
    "External": "#FF9800",   # orange – customers / counterparties / external entities
}

# ─── Fixed colors for node_type3 (Customer Segment) — v16.31 [renamed from node_type2] ───────────
# FIXED 4-value segment classification used for Radar ChipGroup filter.
# Colors chosen to be visually distinct on dark backgrounds.
NODE_TYPE3_COLORS: Dict[str, str] = {
    "Retail":     "#00BFA5",  # teal    – individual consumers
    "Corporate":  "#9D4EDD",  # violet  – companies / businesses
    "Financial":  "#FFD600",  # amber   – banks / payment processors / fintech
    "Government": "#94A3B8",  # slate   – public sector / state entities
}


def build_colormap(node_types: List[str]) -> Dict[str, str]:
    """
    Build a {node_type: hex_color} dict from a list of type values.

    Args:
        node_types: List of node_type strings (may contain None / NaN).

    Returns:
        Dict mapping each unique, non-null type to a palette color.
        None / NaN / empty strings map to FALLBACK_COLOR.
    """
    unique_types = sorted(
        {str(t) for t in node_types if t is not None and pd.notna(t) and str(t).strip()}
    )
    colormap = {}
    for i, ntype in enumerate(unique_types):
        colormap[ntype] = _PALETTE[i % len(_PALETTE)]
    return colormap


def get_node_color(node_type: Optional[str], colormap: Dict[str, str]) -> str:
    """Return the color for a given node_type, falling back to FALLBACK_COLOR."""
    if node_type is None or pd.isna(node_type) if hasattr(pd, "isna") else node_type is None:
        return _FALLBACK_COLOR
    return colormap.get(str(node_type), _FALLBACK_COLOR)


def extract_node_types_from_pipeline(pipeline) -> List[str]:
    """
    Read node_type values from the pipeline's node / customer_features table.
    Returns a sorted list of unique type strings.
    Falls back to an empty list if the column does not exist.
    """
    types: List[str] = []
    try:
        node_df = None
        if hasattr(pipeline, "tables"):
            node_df = pipeline.tables.get("node") or pipeline.tables.get("customer")
        if node_df is None and hasattr(pipeline, "customer_features") and pipeline.customer_features is not None:
            node_df = pipeline.customer_features
        if node_df is not None and "node_type" in node_df.columns:
            types = [
                str(t)
                for t in node_df["node_type"].dropna().unique()
                if str(t).strip()
            ]
    except Exception:
        pass
    return sorted(types)


def node_type_filter_options(pipeline) -> List[Dict]:
    """
    Return dcc.Dropdown options for node_type filter.
    Always includes 'All Types' as the first option.
    """
    types = extract_node_types_from_pipeline(pipeline)
    options = [{"label": "All Types", "value": "ALL"}]
    try:
        cm = build_colormap(types)
        for t in types:
            color = cm.get(t, _FALLBACK_COLOR)
            options.append({"label": t, "value": t, "color": color})
    except Exception:
        for t in types:
            options.append({"label": t, "value": t})
    return options


def extract_node_type1_from_pipeline(pipeline) -> List[str]:
    """
    Read node_type1 values from the pipeline's node / customer_features table.
    Returns sorted list of unique type1 strings.
    Falls back to ["Internal", "External"] if column absent (safe default).
    """
    types: List[str] = []
    try:
        node_df = None
        if hasattr(pipeline, "tables"):
            node_df = pipeline.tables.get("node") or pipeline.tables.get("customer")
        if node_df is None and hasattr(pipeline, "customer_features") and pipeline.customer_features is not None:
            node_df = pipeline.customer_features
        if node_df is not None and "node_type1" in node_df.columns:
            types = [
                str(t)
                for t in node_df["node_type1"].dropna().unique()
                if str(t).strip()
            ]
    except Exception:
        pass
    # Guarantee Internal/External always appear even on first load
    for _default in ("Internal", "External"):
        if _default not in types:
            types.append(_default)
    return sorted(types)


def node_type1_filter_options(pipeline) -> List[Dict]:
    """
    Return dcc.Dropdown options for node_type1 (Internal/External) filter.
    Uses fixed colors from NODE_TYPE1_COLORS for clear visual distinction.
    Always includes 'All' as the first option.
    """
    types = extract_node_type1_from_pipeline(pipeline)
    options = [{"label": "All (Int/Ext)", "value": "ALL"}]
    for t in types:
        color = NODE_TYPE1_COLORS.get(t, _FALLBACK_COLOR)
        options.append({"label": t, "value": t, "color": color})
    return options


# ── v16.31: node_type3 (Customer Segment) functions [renamed from node_type2] ────────────

def extract_node_type3_from_pipeline(pipeline) -> List[str]:
    """
    Read node_type3 values from the pipeline's node / customer table.
    Returns sorted list of unique type3 strings.
    Falls back to the four canonical segment values if column absent.
    """
    types: List[str] = []
    try:
        node_df = None
        if hasattr(pipeline, "tables"):
            node_df = pipeline.tables.get("node") or pipeline.tables.get("customer")
        if node_df is None and hasattr(pipeline, "customer_features") and pipeline.customer_features is not None:
            node_df = pipeline.customer_features
        if node_df is not None and "node_type3" in node_df.columns:
            types = [
                str(t)
                for t in node_df["node_type3"].dropna().unique()
                if str(t).strip()
            ]
    except Exception:
        pass
    # Guarantee canonical segments always appear even on first load
    _canonical = ["Retail", "Corporate", "Financial", "Government"]
    for _v in _canonical:
        if _v not in types:
            types.append(_v)
    # Return in canonical order (not alphabetical) for consistent chip layout
    ordered = [v for v in _canonical if v in types]
    return ordered


def node_type3_chip_options(pipeline) -> List[Dict]:
    """
    Return chip option dicts for node_type3 (Customer Segment) ChipGroup.
    Each dict has: value, label, color (dmc chip color name).
    """
    _DMC_COLOR = {
        "Retail":     "teal",
        "Corporate":  "violet",
        "Financial":  "yellow",
        "Government": "gray",
    }
    types = extract_node_type3_from_pipeline(pipeline)
    options = []
    for t in types:
        color = _DMC_COLOR.get(t, "cyan")
        options.append({"value": t, "label": t, "color": color})
    return options


def apply_node_type_colors(
    node_ids: List[str],
    node_type_map: Dict[str, str],  # {node_id: node_type}
    colormap: Dict[str, str],
    fallback_tier_colors: Optional[List[str]] = None,
    node_type_filter: Optional[str] = None,  # None or 'ALL' → no filter
) -> tuple:
    """
    Map a list of node IDs to display colors and visibility flags.

    Args:
        node_ids:           List of node IDs (order matches graph nodes).
        node_type_map:      {node_id → node_type} lookup.
        colormap:           {node_type → hex_color} from build_colormap().
        fallback_tier_colors: If provided, use these risk-tier colors when
                            no node_type_filter is active (preserves existing
                            tier-based coloring when no filter set).
        node_type_filter:   If set and not 'ALL', keeps only nodes of this type.

    Returns:
        (colors, opacities) — two parallel lists matching node_ids.
        Colors: hex string per node.
        Opacities: 1.0 (visible) or 0.2 (faded when filtered out).
    """
    colors = []
    opacities = []

    use_filter = node_type_filter and node_type_filter != "ALL"

    for i, nid in enumerate(node_ids):
        ntype = node_type_map.get(str(nid), None)
        if use_filter:
            if str(ntype) == node_type_filter:
                colors.append(colormap.get(str(ntype), _FALLBACK_COLOR))
                opacities.append(1.0)
            else:
                colors.append(_FALLBACK_COLOR)
                opacities.append(0.15)
        else:
            # No filter active — use tier colors if provided, else node_type colors
            if fallback_tier_colors and i < len(fallback_tier_colors):
                colors.append(fallback_tier_colors[i])
                opacities.append(1.0)
            else:
                colors.append(colormap.get(str(ntype), _FALLBACK_COLOR) if ntype else _FALLBACK_COLOR)
                opacities.append(1.0)

    return colors, opacities


def build_legend_items(colormap: Dict[str, str]) -> list:
    """
    Build dmc legend items for the node_type color map.
    Returns a list of dmc.Group components, one per node type.
    """
    items = []
    try:
        import dash_mantine_components as dmc
        for ntype, color in sorted(colormap.items()):
            items.append(
                dmc.Group(
                    [
                        __import__("dash").html.Div(
                            style={
                                "width": "10px",
                                "height": "10px",
                                "borderRadius": "50%",
                                "backgroundColor": color,
                                "flexShrink": "0",
                            }
                        ),
                        dmc.Text(ntype, size="xs", c=color),
                    ],
                    gap=4,
                )
            )
    except Exception:
        pass
    return items
