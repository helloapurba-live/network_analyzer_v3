"""
FCDAI Network Analyzer — Event Type Derivation Engine (v16.23 T1)
==================================================================
Business Logic:
    Derives AML event_type labels from raw transaction data using a
    comprehensive, exhaustive rule-set.  No description / free-text
    fields are required — only the GUARANTEED columns:

        amount          numeric transaction value
        timestamp       datetime of transaction
        transaction_type  WIRE / ACH / CASH / CHECK / CARD / RTGS / SWIFT
        currency        USD / EUR / GBP / ...
        channel         branch / online / mobile / atm / telephone
        counterparty_country  ISO-2 country code
        from_node / account_id  source node identifier
        to_node / counterparty_id  destination node identifier

    Rule priority (highest wins when a transaction matches multiple rules):
        1  Circular_Flow     — A→B then B→A within 30 days (round-trip)
        2  Structuring       — CASH below CTR threshold (≥9000, <10000)
        3  Dormant_Reactivation — gap ≥ 90 days then transaction
        4  Account_Burst     — ≥ 5 transactions within 2 hours
        5  High_Velocity     — ≥ 10 transactions within 24 hours
        6  Round_Trip        — same account sends and receives within 7 days
        7  Structuring       — multiple sub-threshold CASH txns sum ≥ 10 000
        8  Filed             — high-risk country + amount ≥ 50 000
        9  Alert_Closed      — off-hours transaction (02:00–05:59) SAME flag
       10  Alert_Closed      — catch-all for off-hours low-risk

    Each transaction gets ONE derived label stored in `derived_event_type`.
    The original `event_type` column is never overwritten if it already exists.

    Also produces a pivot table of derived event counts per node for the
    feature aggregation layer (Task 5).

Technical:
    All computations are vectorised via pandas groupby / merge.
    Works on both legacy (account_id / counterparty_id) and graph-schema
    (from_node / to_node) column names.
    Safe on empty DataFrames — returns empty columns without raising.
"""

import pandas as pd
import numpy as np
from datetime import timedelta
from pathlib import Path
from typing import Dict, Optional
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from utils.logger import log_audit


# ── Constants ─────────────────────────────────────────────────────────────────
HIGH_RISK_COUNTRIES = {"HK", "AE", "KY", "BZ", "OTHER", "VE", "IR", "SY", "KP", "MM", "YE"}

FATF_GREY          = {"PK", "JO", "AE", "SY", "TZ", "UG", "VN", "YE", "ZW"}
FATF_BLACK         = {"KP", "IR", "MM"}
HIGH_RISK_SET      = HIGH_RISK_COUNTRIES | FATF_GREY | FATF_BLACK

CASH_TYPES         = {"CASH"}
THRESHOLD_CTR      = 10_000   # US Cash Transaction Reporting threshold
STRUCTURING_LOW    = 9_000    # Minimum to classify as structuring
HIGH_VALUE_MIN     = 50_000   # High-value transaction minimum
CRITICAL_VALUE     = 100_000  # Critical value threshold

# Velocity windows
BURST_WINDOW_HOURS = 2        # Account_Burst: N txns within this window
BURST_MIN_TXNS     = 5        # minimum transaction count for burst flag
VELOCITY_HOURS     = 24       # High_Velocity window
VELOCITY_MIN_TXNS  = 10
DORMANT_GAP_DAYS   = 90       # Gap before reactivation flag
ROUND_TRIP_DAYS    = 7        # Round_Trip: A→B → B→A within this window
CIRCULAR_FLOW_DAYS = 30       # Circular_Flow: wider round-trip window

# Round-number detection: amounts that are exact multiples of these values
ROUND_MULTIPLES    = [1_000, 5_000, 10_000, 25_000, 50_000, 100_000]


# =============================================================================
# HELPER — normalise column names to internal standard
# =============================================================================
def _normalise_cols(df: pd.DataFrame) -> pd.DataFrame:
    """
    Map graph-schema  (from_node / to_node)  OR  legacy schema
    (account_id / counterparty_id) to internal names
    (src / dst) used by all rule functions.
    """
    df = df.copy()
    col_map: Dict[str, str] = {}
    if "from_node" in df.columns and "src" not in df.columns:
        col_map["from_node"] = "src"
    elif "account_id" in df.columns and "src" not in df.columns:
        col_map["account_id"] = "src"
    if "to_node" in df.columns and "dst" not in df.columns:
        col_map["to_node"] = "dst"
    elif "counterparty_id" in df.columns and "dst" not in df.columns:
        col_map["counterparty_id"] = "dst"
    if col_map:
        df = df.rename(columns=col_map)
    # Ensure timestamp is datetime
    if "timestamp" in df.columns and df["timestamp"].dtype == object:
        df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
    elif "date" in df.columns and "timestamp" not in df.columns:
        df["timestamp"] = pd.to_datetime(df["date"], errors="coerce")
    return df


# =============================================================================
# RULE SET — each function returns a boolean Series (True = rule matched)
# All functions take the normalised DataFrame and return pd.Series[bool].
# =============================================================================

def _rule_structuring_single(df: pd.DataFrame) -> pd.Series:
    """CASH transaction in [9000, 10000) — single structuring event."""
    if "amount" not in df.columns or "transaction_type" not in df.columns:
        return pd.Series(False, index=df.index)
    is_cash = df["transaction_type"].str.upper().isin(CASH_TYPES)
    in_range = (df["amount"] >= STRUCTURING_LOW) & (df["amount"] < THRESHOLD_CTR)
    return is_cash & in_range


def _rule_high_risk_country(df: pd.DataFrame) -> pd.Series:
    """Transaction to/from a FATF black/grey-list or high-risk country."""
    cc_col = next(
        (c for c in ("counterparty_country", "dst_country", "country") if c in df.columns), None
    )
    if cc_col is None:
        return pd.Series(False, index=df.index)
    return df[cc_col].isin(HIGH_RISK_SET)


def _rule_high_value(df: pd.DataFrame) -> pd.Series:
    """Single transaction amount ≥ HIGH_VALUE_MIN."""
    if "amount" not in df.columns:
        return pd.Series(False, index=df.index)
    return df["amount"] >= HIGH_VALUE_MIN


def _rule_off_hours(df: pd.DataFrame) -> pd.Series:
    """Transaction between 02:00–05:59 local time."""
    if "timestamp" not in df.columns:
        return pd.Series(False, index=df.index)
    ts = pd.to_datetime(df["timestamp"], errors="coerce")
    return ts.dt.hour.between(2, 5)


def _rule_round_amount(df: pd.DataFrame) -> pd.Series:
    """Amount is an exact round multiple (e.g. 10 000, 50 000)."""
    if "amount" not in df.columns:
        return pd.Series(False, index=df.index)
    mask = pd.Series(False, index=df.index)
    for mult in ROUND_MULTIPLES:
        mask = mask | ((df["amount"] % mult == 0) & (df["amount"] >= mult))
    return mask


def _rule_multi_currency(df: pd.DataFrame) -> pd.Series:
    """Source node uses more than one currency — layering indicator."""
    if "currency" not in df.columns or "src" not in df.columns:
        return pd.Series(False, index=df.index)
    try:
        cnt = df.groupby("src")["currency"].transform("nunique")
        return cnt > 1
    except Exception:
        return pd.Series(False, index=df.index)


# ── SESSION-LEVEL rules (require timestamp-based windows) ────────────────────

def _rule_account_burst(df: pd.DataFrame) -> pd.Series:
    """≥ BURST_MIN_TXNS transactions from the same source within BURST_WINDOW_HOURS."""
    if "src" not in df.columns or "timestamp" not in df.columns:
        return pd.Series(False, index=df.index)
    try:
        df2 = df[["src", "timestamp"]].copy()
        df2 = df2.sort_values(["src", "timestamp"])
        df2["_roll"] = df2.groupby("src")["timestamp"].transform(
            lambda s: s.rolling(
                window=f"{BURST_WINDOW_HOURS}h", on=None, min_periods=BURST_MIN_TXNS
            ).count()
            if False
            else _rolling_count(s, BURST_WINDOW_HOURS * 3600, BURST_MIN_TXNS)
        )
        flag = df2["_roll"] >= BURST_MIN_TXNS
        # Re-index to original
        return flag.reindex(df.index, fill_value=False)
    except Exception:
        return pd.Series(False, index=df.index)


def _rolling_count(series: pd.Series, window_secs: int, min_count: int) -> pd.Series:
    """Count of timestamps within window_secs of each observation."""
    ts_arr = series.values
    n = len(ts_arr)
    counts = np.zeros(n, dtype=int)
    try:
        ts_ns = pd.to_datetime(ts_arr).astype(np.int64)
        window_ns = window_secs * 1_000_000_000
        for i in range(n):
            lo = np.searchsorted(ts_ns, ts_ns[i] - window_ns, side="left")
            counts[i] = i - lo + 1
    except Exception:
        pass
    return pd.Series(counts, index=series.index)


def _rule_high_velocity(df: pd.DataFrame) -> pd.Series:
    """≥ VELOCITY_MIN_TXNS from same source within 24 hours."""
    if "src" not in df.columns or "timestamp" not in df.columns:
        return pd.Series(False, index=df.index)
    try:
        df2 = df[["src", "timestamp"]].copy().sort_values(["src", "timestamp"])
        df2["_cnt"] = df2.groupby("src")["timestamp"].transform(
            lambda s: _rolling_count(s, VELOCITY_HOURS * 3600, VELOCITY_MIN_TXNS)
        )
        flag = df2["_cnt"] >= VELOCITY_MIN_TXNS
        return flag.reindex(df.index, fill_value=False)
    except Exception:
        return pd.Series(False, index=df.index)


def _rule_dormant_reactivation(df: pd.DataFrame) -> pd.Series:
    """Gap ≥ DORMANT_GAP_DAYS between consecutive transactions from same source."""
    if "src" not in df.columns or "timestamp" not in df.columns:
        return pd.Series(False, index=df.index)
    try:
        df2 = df[["src", "timestamp"]].copy().sort_values(["src", "timestamp"])
        df2["_prev"] = df2.groupby("src")["timestamp"].shift(1)
        df2["_gap"] = (df2["timestamp"] - df2["_prev"]).dt.days
        flag = df2["_gap"] >= DORMANT_GAP_DAYS
        return flag.reindex(df.index, fill_value=False)
    except Exception:
        return pd.Series(False, index=df.index)


def _rule_round_trip(df: pd.DataFrame) -> pd.Series:
    """
    A→B followed by B→A within ROUND_TRIP_DAYS.
    Uses a merge approach: for each (src,dst) pair check if a reversed
    (dst,src) pair exists within the time window.
    """
    if "src" not in df.columns or "dst" not in df.columns or "timestamp" not in df.columns:
        return pd.Series(False, index=df.index)
    try:
        fwd = df[["src", "dst", "timestamp"]].copy()
        fwd["timestamp"] = pd.to_datetime(fwd["timestamp"], errors="coerce")
        rev = fwd.rename(columns={"src": "dst", "dst": "src", "timestamp": "_rev_ts"})
        merged = fwd.merge(rev, on=["src", "dst"])
        window = pd.Timedelta(days=ROUND_TRIP_DAYS)
        merged = merged[
            (merged["_rev_ts"] > merged["timestamp"])
            & (merged["_rev_ts"] - merged["timestamp"] <= window)
        ]
        flagged_pairs = set(zip(merged["src"], merged["dst"]))
        flag = pd.Series([
            (r.src, r.dst) in flagged_pairs
            for r in df[["src", "dst"]].itertuples()
        ], index=df.index)
        return flag
    except Exception:
        return pd.Series(False, index=df.index)


def _rule_circular_flow(df: pd.DataFrame) -> pd.Series:
    """
    A→B then B→A within CIRCULAR_FLOW_DAYS (longer window than round_trip).
    The amount ratio src→dst vs dst→src is 0.5–2.0 (plausible AML round-trip).
    """
    if "src" not in df.columns or "dst" not in df.columns:
        return pd.Series(False, index=df.index)
    try:
        fwd = df[["src", "dst", "timestamp"]].copy()
        fwd["timestamp"] = pd.to_datetime(fwd["timestamp"], errors="coerce")
        rev = fwd.rename(columns={"src": "dst", "dst": "src", "timestamp": "_rev_ts"})
        merged = fwd.merge(rev, on=["src", "dst"])
        window = pd.Timedelta(days=CIRCULAR_FLOW_DAYS)
        merged = merged[
            (merged["_rev_ts"] > merged["timestamp"])
            & (merged["_rev_ts"] - merged["timestamp"] <= window)
        ]
        flagged_pairs = set(zip(merged["src"], merged["dst"]))
        flag = pd.Series([
            (r.src, r.dst) in flagged_pairs
            for r in df[["src", "dst"]].itertuples()
        ], index=df.index)
        return flag
    except Exception:
        return pd.Series(False, index=df.index)


def _rule_smurfing(df: pd.DataFrame) -> pd.Series:
    """
    Multiple sub-threshold CASH transactions from same source within 1 day
    that TOGETHER exceed THRESHOLD_CTR.
    """
    if "src" not in df.columns or "amount" not in df.columns or "timestamp" not in df.columns:
        return pd.Series(False, index=df.index)
    try:
        cash_mask = df.get("transaction_type", pd.Series(dtype=str)).str.upper().isin(CASH_TYPES)
        sub_thresh = df["amount"] < THRESHOLD_CTR
        candidate = df[cash_mask & sub_thresh].copy()
        if candidate.empty:
            return pd.Series(False, index=df.index)
        candidate["_date"] = pd.to_datetime(candidate["timestamp"], errors="coerce").dt.date
        daily = candidate.groupby(["src", "_date"])["amount"].sum().reset_index()
        daily.columns = ["src", "_date", "_daily_sum"]
        smurf = daily[daily["_daily_sum"] >= THRESHOLD_CTR][["src", "_date"]]
        smurf_set = set(zip(smurf["src"], smurf["_date"]))
        flag = pd.Series(False, index=df.index)
        if smurf_set:
            for idx, row in df.iterrows():
                try:
                    d = pd.to_datetime(row["timestamp"], errors="coerce").date()
                    s = str(row.get("src", ""))
                    if (s, d) in smurf_set:
                        flag.at[idx] = True
                except Exception:
                    pass
        return flag
    except Exception:
        return pd.Series(False, index=df.index)


# =============================================================================
# MAIN DERIVE FUNCTION
# =============================================================================
def derive_event_types(df: pd.DataFrame) -> pd.DataFrame:
    """
    v16.23 T1: Derive AML event_type for every transaction row.

    Rules are evaluated in priority order; first matching rule wins.
    The output column is `derived_event_type`.

    Args:
        df: Transaction or edge DataFrame with guaranteed columns.

    Returns:
        DataFrame with added `derived_event_type` column.
        If `event_type` already exists it is LEFT UNCHANGED.
        `derived_event_type` is always added / refreshed.
    """
    if df is None or df.empty:
        return df

    df = df.copy()
    norm = _normalise_cols(df)

    n = len(norm)
    result = pd.Series(["Alert_Closed"] * n, index=norm.index)   # default / lowest priority

    # Apply rules in reverse priority order (highest priority applied last = wins)
    def _apply(mask: pd.Series, label: str):
        try:
            result[mask] = label
        except Exception:
            pass

    # ── P10: Off-hours ─────────────────────────────────────────────────────────
    _apply(_rule_off_hours(norm), "Alert_Closed")

    # ── P9: Multi-currency layering ────────────────────────────────────────────
    _apply(_rule_multi_currency(norm), "Structuring")

    # ── P8: Filed: high-risk country + high value ──────────────────────────────
    _apply(_rule_high_risk_country(norm) & _rule_high_value(norm), "Filed")

    # ── P7: Smurfing ───────────────────────────────────────────────────────────
    _apply(_rule_smurfing(norm), "Structuring")

    # ── P6: Round-trip (short window) ─────────────────────────────────────────
    _apply(_rule_round_trip(norm), "Round_Trip")

    # ── P5: High velocity (24h window) ────────────────────────────────────────
    _apply(_rule_high_velocity(norm), "High_Velocity")

    # ── P4: Account burst (2h window) ─────────────────────────────────────────
    _apply(_rule_account_burst(norm), "Account_Burst")

    # ── P3: Dormant reactivation ───────────────────────────────────────────────
    _apply(_rule_dormant_reactivation(norm), "Dormant_Reactivation")

    # ── P2: Structuring (single CASH sub-threshold) ───────────────────────────
    _apply(_rule_structuring_single(norm), "Structuring")

    # ── P1 (highest): Circular flow / round-trip (30-day window) ─────────────
    _apply(_rule_circular_flow(norm), "Circular_Flow")

    df["derived_event_type"] = result.values

    # Counts per category for logging
    counts = df["derived_event_type"].value_counts().to_dict()
    log_audit(
        "EVENT_DERIVE",
        f"{n} txns → derived_event_type: " + ", ".join(f"{k}={v}" for k, v in counts.items()),
    )

    return df


# =============================================================================
# FEATURE HELPER: event-type pivot per node
# =============================================================================
def event_type_features_per_node(
    df: pd.DataFrame,
    node_id_col: str = "src",
) -> pd.DataFrame:
    """
    v16.23 T5 helper: Aggregate derived_event_type counts per source node.

    Returns a DataFrame with columns:
        {node_id_col}, evt_Circular_Flow, evt_Structuring,
        evt_Account_Burst, evt_High_Velocity, evt_Round_Trip,
        evt_Dormant_Reactivation, evt_Filed, evt_Alert_Closed
    """
    if df is None or df.empty or "derived_event_type" not in df.columns:
        return pd.DataFrame(columns=[node_id_col])

    try:
        norm = _normalise_cols(df)
        if node_id_col not in norm.columns and "src" in norm.columns:
            norm = norm.rename(columns={"src": node_id_col})

        pivot = (
            norm.groupby([node_id_col, "derived_event_type"])
            .size()
            .unstack(fill_value=0)
            .reset_index()
        )
        pivot.columns = [
            node_id_col if c == node_id_col else f"evt_{c}" for c in pivot.columns
        ]
        return pivot
    except Exception:
        return pd.DataFrame(columns=[node_id_col])
