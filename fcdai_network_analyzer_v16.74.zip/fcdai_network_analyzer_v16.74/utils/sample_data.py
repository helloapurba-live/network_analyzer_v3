"""
FCDAI Network Analyzer - Synthetic Sample Data Generator
==========================================================
Business Logic: Generates realistic AML data across 13 tables:
  - 8 legacy tables: customer, account, kyc, transaction, historical,
    alert, relationship, case
  - 5 graph-schema tables: node, edge, relationship_edge,
    shared_attribute, temporal
Supports controllable anomaly injection and diverse data types
(numeric, categorical, binary, ordinal, nominal, mixed). This sample data
is used until the user uploads their own data.

Technical Implementation: NumPy-based generation with Pydantic validation
on output. Saves to data/samples/ as CSV. Supports parameterized generation
for testing different scenarios.
"""

import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, Optional, Tuple
import sys
import json
import threading  # for non-blocking background CSV saves (OneDrive-safe)

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import PATHS
from utils.logger import log_audit, log_error


# =============================================================================
# CONFIGURATION
# =============================================================================
# US states with population-weighted probabilities (for domestic customers)
US_STATES = [
    "CA", "TX", "FL", "NY", "PA", "IL", "OH", "GA", "NC", "MI",
    "NJ", "VA", "WA", "AZ", "MA", "TN", "IN", "MO", "MD", "WI",
    "CO", "MN", "SC", "AL", "LA", "KY", "OR", "OK", "CT", "UT",
    "IA", "NV", "AR", "MS", "KS", "NM", "NE", "WV", "ID", "HI",
    "NH", "ME", "MT", "RI", "DE", "SD", "ND", "AK", "VT", "WY",
]
US_STATE_WEIGHTS = [
    0.122, 0.090, 0.069, 0.059, 0.038, 0.038, 0.035, 0.033, 0.033, 0.030,
    0.027, 0.026, 0.024, 0.022, 0.021, 0.021, 0.020, 0.018, 0.018, 0.018,
    0.017, 0.017, 0.016, 0.015, 0.014, 0.013, 0.013, 0.012, 0.011, 0.010,
    0.009, 0.009, 0.009, 0.009, 0.009, 0.006, 0.006, 0.005, 0.005, 0.004,
    0.004, 0.004, 0.003, 0.003, 0.003, 0.003, 0.002, 0.002, 0.002, 0.002,
]

COUNTRIES = ["US", "GB", "DE", "FR", "CH", "SG", "HK", "AE", "KY", "BZ", "OTHER"]
COUNTRY_WEIGHTS = [0.30, 0.12, 0.10, 0.08, 0.05, 0.05, 0.04, 0.04, 0.03, 0.02, 0.17]
HIGH_RISK_COUNTRIES = {"HK", "AE", "KY", "BZ", "OTHER"}

TXN_TYPES = ["WIRE", "ACH", "CASH", "CHECK", "CARD", "RTGS", "SWIFT"]
TXN_TYPE_WEIGHTS = [0.18, 0.25, 0.12, 0.10, 0.20, 0.08, 0.07]

CHANNELS = ["branch", "online", "mobile", "atm", "telephone"]
CHANNEL_WEIGHTS = [0.15, 0.35, 0.30, 0.10, 0.10]

OCCUPATIONS = [
    "engineer",
    "doctor",
    "lawyer",
    "teacher",
    "business_owner",
    "retired",
    "student",
    "finance",
    "government",
    "self_employed",
    "unemployed",
    "other",
]
SEGMENTS = ["retail", "commercial", "private_banking", "wealth", "sme"]
STATUSES_CUSTOMER = ["active", "dormant", "suspended", "closed"]
STATUSES_ACCOUNT = ["active", "frozen", "closed", "under_review"]
ACCOUNT_TYPES = ["checking", "savings", "investment", "loan", "credit_card"]
CURRENCIES = ["USD", "EUR", "GBP", "CHF", "SGD", "HKD"]

ALERT_TYPES = ["TM", "ACT", "MAN", "EDD", "PEP", "SANCTIONS"]
ALERT_SEVERITY = ["low", "medium", "high", "critical"]
EVENT_TYPES = ["ACT_filed", "STR_filed", "EDD_review", "alert_closed", "case_opened"]
RELATIONSHIP_TYPES = [
    "shared_address",
    "shared_phone",
    "beneficial_owner",
    "corporate_link",
    "family",
    "power_of_attorney",
    "same_employer",
]

# Graph-schema relationship types (from reference image)
GRAPH_REL_TYPES = [
    "Beneficial_Owner",
    "Director",
    "Authorized_Signer",
    "Corporate_Customer",
    "Shareholder",
    "Guarantor",
    "Nominee",
]
GRAPH_ATTR_TYPES = ["others", "Address", "Phone", "Email", "Device_ID", "IP_Address"]
GRAPH_EVENT_TYPES = [
    "High_Velocity",
    "Filed",
    "Account_Burst",
    "Alert_Closed",
    "Circular_Flow",
    "Structuring",
    "Round_Trip",
    "Dormant_Reactivation",
]
NODE_TYPES = ["Person", "Entity", "Merchant", "Account", "Trust"]
CASE_STATUSES = ["open", "closed", "escalated", "pending_review", "filed"]
CASE_TYPES = ["ACT", "STR", "EDD", "CTR", "Fraud", "AML"]


# =============================================================================
# GENERATORS
# =============================================================================
def generate_customers(n: int = 10000, seed: int = 42) -> pd.DataFrame:
    """
    Business Logic: Generate customer master data. Each customer has a unique
    ID, demographics, and a risk rating. Some customers are flagged as
    high-risk based on country, PEP status, or unusual attributes.
    """
    rng = np.random.default_rng(seed)

    customer_ids = [f"CUST{i:06d}" for i in range(1, n + 1)]
    # v16.23 T3: Pre-generate country so we can derive state from same values
    countries = rng.choice(COUNTRIES, size=n, p=COUNTRY_WEIGHTS)
    # Vectorized state assignment: US customers get a state code, others get "N/A"
    _us_mask = countries == "US"
    _us_count = int(_us_mask.sum())
    states = np.full(n, "N/A", dtype=object)
    if _us_count > 0:
        _sw = np.array(US_STATE_WEIGHTS, dtype=float)
        _sw /= _sw.sum()  # normalise to guard against float drift
        states[_us_mask] = rng.choice(US_STATES, size=_us_count, p=_sw)

    df = pd.DataFrame(
        {
            "customer_id": customer_ids,
            "name": [f"Customer_{i}" for i in range(1, n + 1)],
            "customer_type": rng.choice(
                ["individual", "corporate", "trust", "joint"], size=n, p=[0.60, 0.25, 0.08, 0.07]
            ),
            "country": countries,
            "registration_date": [
                (datetime.now() - timedelta(days=int(rng.integers(30, 3650)))).strftime("%Y-%m-%d")
                for _ in range(n)
            ],
            "risk_rating": rng.choice(
                [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
                size=n,
                p=[0.15, 0.15, 0.15, 0.12, 0.10, 0.08, 0.08, 0.07, 0.05, 0.05],
            ),
            "status": rng.choice(STATUSES_CUSTOMER, size=n, p=[0.75, 0.10, 0.05, 0.10]),
            "segment": rng.choice(SEGMENTS, size=n, p=[0.40, 0.20, 0.15, 0.10, 0.15]),
            "annual_income": np.abs(rng.lognormal(mean=11.0, sigma=1.0, size=n)).round(2),
            "occupation": rng.choice(OCCUPATIONS, size=n),
            # v16.23 T3: state from registration address (US customers get state code; others "N/A")
            "state": states,
        }
    )

    log_audit("SAMPLE_GEN", f"customers: {n} records")
    return df


def generate_accounts(n_customers: int = 10000, seed: int = 42) -> pd.DataFrame:
    """
    Business Logic: Generate bank accounts. Each customer has 1-4 accounts.
    Accounts link to customers via customer_id.
    """
    rng = np.random.default_rng(seed + 1)

    records = []
    acct_id = 1
    for i in range(1, n_customers + 1):
        n_accounts = int(rng.choice([1, 2, 3, 4], p=[0.50, 0.30, 0.15, 0.05]))
        for _ in range(n_accounts):
            records.append(
                {
                    "account_id": f"ACCT{acct_id:07d}",
                    "customer_id": f"CUST{i:06d}",
                    "account_type": rng.choice(ACCOUNT_TYPES),
                    "currency": rng.choice(CURRENCIES),
                    "balance": round(float(np.abs(rng.lognormal(mean=9.0, sigma=2.0))), 2),
                    "open_date": (
                        datetime.now() - timedelta(days=int(rng.integers(1, 3650)))
                    ).strftime("%Y-%m-%d"),
                    "status": rng.choice(STATUSES_ACCOUNT, p=[0.80, 0.05, 0.05, 0.10]),
                    "branch": f"BR{int(rng.integers(1, 50)):03d}",
                }
            )
            acct_id += 1

    df = pd.DataFrame(records)
    log_audit("SAMPLE_GEN", f"accounts: {len(df)} records for {n_customers} customers")
    return df


def generate_kyc(n_customers: int = 10000, seed: int = 42) -> pd.DataFrame:
    """
    Business Logic: KYC (Know-Your-Customer) data for each customer.
    Includes PEP status, sanctions hits, ID verification, and source of funds.
    """
    rng = np.random.default_rng(seed + 2)

    df = pd.DataFrame(
        {
            "customer_id": [f"CUST{i:06d}" for i in range(1, n_customers + 1)],
            "kyc_date": [
                (datetime.now() - timedelta(days=int(rng.integers(0, 365)))).strftime("%Y-%m-%d")
                for _ in range(n_customers)
            ],
            "kyc_score": rng.uniform(0.3, 1.0, size=n_customers).round(3),
            "pep_status": rng.choice([0, 1], size=n_customers, p=[0.95, 0.05]),
            "sanctions_hit": rng.choice([0, 1], size=n_customers, p=[0.98, 0.02]),
            "id_verified": rng.choice([0, 1], size=n_customers, p=[0.10, 0.90]),
            "source_of_funds": rng.choice(
                ["employment", "business", "investment", "inheritance", "unknown"],
                size=n_customers,
                p=[0.40, 0.25, 0.15, 0.10, 0.10],
            ),
            "risk_category": rng.choice(
                ["low", "medium", "high", "critical"], size=n_customers, p=[0.50, 0.30, 0.15, 0.05]
            ),
        }
    )

    log_audit("SAMPLE_GEN", f"kyc: {n_customers} records")
    return df


def generate_transactions(
    n_records: int = 50000, n_customers: int = 10000, anomaly_rate: float = 0.03, seed: int = 42
) -> pd.DataFrame:
    """
    Business Logic: Financial transactions — the primary data source for
    graph construction. Each transaction connects accounts through money flow.
    Anomalies are injected at a configurable rate.
    """
    rng = np.random.default_rng(seed + 3)

    # Generate account IDs (distribute across customers)
    # Approximate: each customer gets ~1.5 accounts on avg
    all_accounts = []
    for i in range(1, n_customers + 1):
        n_acct = max(1, int(rng.choice([1, 2, 3], p=[0.50, 0.35, 0.15])))
        for j in range(n_acct):
            all_accounts.append((f"CUST{i:06d}", f"ACCT{len(all_accounts)+1:07d}"))

    # Assign transactions to random accounts
    chosen = rng.choice(len(all_accounts), size=n_records)
    cust_ids = [all_accounts[c][0] for c in chosen]
    acct_ids = [all_accounts[c][1] for c in chosen]

    # Counterparties (other customers)
    counterparty_ids = [f"CUST{int(rng.integers(1, n_customers+1)):06d}" for _ in range(n_records)]

    df = pd.DataFrame(
        {
            "txn_id": [f"TXN{i:08d}" for i in range(1, n_records + 1)],
            "account_id": acct_ids,
            "customer_id": cust_ids,
            "timestamp": [
                (
                    datetime.now()
                    - timedelta(
                        days=int(rng.integers(0, 365)),
                        hours=int(rng.integers(0, 24)),
                        minutes=int(rng.integers(0, 60)),
                    )
                ).strftime("%Y-%m-%d %H:%M:%S")
                for _ in range(n_records)
            ],
            "amount": np.abs(rng.lognormal(mean=6.0, sigma=1.5, size=n_records)).round(2),
            "currency": rng.choice(
                CURRENCIES, size=n_records, p=[0.40, 0.20, 0.15, 0.10, 0.08, 0.07]
            ),
            "transaction_type": rng.choice(TXN_TYPES, size=n_records, p=TXN_TYPE_WEIGHTS),
            "counterparty_id": counterparty_ids,
            "counterparty_country": rng.choice(COUNTRIES, size=n_records, p=COUNTRY_WEIGHTS),
            "channel": rng.choice(CHANNELS, size=n_records, p=CHANNEL_WEIGHTS),
            "description": [f"Transaction {i}" for i in range(1, n_records + 1)],
            "is_international": rng.choice([0, 1], size=n_records, p=[0.70, 0.30]),
        }
    )

    # Inject anomalies
    n_anomalies = int(n_records * anomaly_rate)
    anomaly_idx = rng.choice(n_records, size=n_anomalies, replace=False)

    for idx in anomaly_idx:
        anom_type = rng.choice(["amount", "velocity", "pattern", "structuring", "mixed"])

        if anom_type == "amount":
            df.loc[idx, "amount"] = float(rng.uniform(100000, 2000000))
        elif anom_type == "velocity":
            # Same customer, many txns in short window — handled by temporal analytics
            df.loc[idx, "amount"] = float(rng.uniform(5000, 20000))
        elif anom_type == "pattern":
            df.loc[idx, "amount"] = float(rng.choice([9999, 9998, 9997, 4999]))
            df.loc[idx, "counterparty_country"] = rng.choice(list(HIGH_RISK_COUNTRIES))
        elif anom_type == "structuring":
            df.loc[idx, "amount"] = float(rng.choice([9500, 9800, 9900, 9950]))
            df.loc[idx, "transaction_type"] = "CASH"
        else:
            df.loc[idx, "amount"] = float(rng.uniform(500000, 5000000))
            df.loc[idx, "counterparty_country"] = "OTHER"
            df.loc[idx, "is_international"] = 1

    log_audit("SAMPLE_GEN", f"transactions: {n_records} records, {n_anomalies} anomalies injected")
    return df


def generate_historical(n_customers: int = 10000, seed: int = 42) -> pd.DataFrame:
    """
    Business Logic: Historical alerts, Activity Reports, and investigation records.
    ~20% of customers have some history; repeat offenders have multiple entries.
    """
    rng = np.random.default_rng(seed + 4)

    records = []
    rec_id = 1
    for i in range(1, n_customers + 1):
        # 20% of customers have historical events
        if rng.random() < 0.20:
            n_events = int(rng.choice([1, 2, 3, 4], p=[0.50, 0.30, 0.15, 0.05]))
            for _ in range(n_events):
                records.append(
                    {
                        "record_id": f"HIST{rec_id:06d}",
                        "customer_id": f"CUST{i:06d}",
                        "event_type": rng.choice(EVENT_TYPES),
                        "event_date": (
                            datetime.now() - timedelta(days=int(rng.integers(30, 730)))
                        ).strftime("%Y-%m-%d"),
                        "outcome": rng.choice(["TP", "FP", "pending"], p=[0.30, 0.50, 0.20]),
                        "risk_score_at_time": round(float(rng.uniform(30, 95)), 1),
                        "narrative": f"Historical event for customer CUST{i:06d}",
                        "filed_by": f"analyst_{int(rng.integers(1, 20)):02d}",
                    }
                )
                rec_id += 1

    df = (
        pd.DataFrame(records)
        if records
        else pd.DataFrame(
            columns=[
                "record_id",
                "customer_id",
                "event_type",
                "event_date",
                "outcome",
                "risk_score_at_time",
                "narrative",
                "filed_by",
            ]
        )
    )
    log_audit("SAMPLE_GEN", f"historical: {len(df)} records")
    return df


def generate_alerts(n_customers: int = 10000, seed: int = 42) -> pd.DataFrame:
    """
    Business Logic: Current alerts for investigation. ~10% of customers
    have active alerts.
    """
    rng = np.random.default_rng(seed + 5)

    records = []
    alert_id = 1
    for i in range(1, n_customers + 1):
        if rng.random() < 0.10:
            n_alerts = int(rng.choice([1, 2, 3], p=[0.60, 0.30, 0.10]))
            for _ in range(n_alerts):
                records.append(
                    {
                        "alert_id": f"ALT{alert_id:06d}",
                        "customer_id": f"CUST{i:06d}",
                        "alert_date": (
                            datetime.now() - timedelta(days=int(rng.integers(0, 90)))
                        ).strftime("%Y-%m-%d"),
                        "alert_type": rng.choice(ALERT_TYPES),
                        "severity": rng.choice(ALERT_SEVERITY, p=[0.30, 0.35, 0.25, 0.10]),
                        "status": rng.choice(["open", "closed", "escalated"], p=[0.40, 0.40, 0.20]),
                        "score": round(float(rng.uniform(0.3, 1.0)), 3),
                        "rule_triggered": f"RULE_{int(rng.integers(1, 50)):03d}",
                        "assigned_to": f"analyst_{int(rng.integers(1, 20)):02d}",
                    }
                )
                alert_id += 1

    df = (
        pd.DataFrame(records)
        if records
        else pd.DataFrame(
            columns=[
                "alert_id",
                "customer_id",
                "alert_date",
                "alert_type",
                "severity",
                "status",
                "score",
                "rule_triggered",
                "assigned_to",
            ]
        )
    )
    log_audit("SAMPLE_GEN", f"alerts: {len(df)} records")
    return df


def generate_relationships(n_customers: int = 10000, seed: int = 42) -> pd.DataFrame:
    """
    Business Logic: Explicit relationships between customers — shared addresses,
    beneficial ownership, corporate links. These become similarity edges in
    the graph (Stage 3-4).
    """
    rng = np.random.default_rng(seed + 6)

    records = []
    for i in range(1, n_customers + 1):
        # ~15% of customers have explicit relationships
        if rng.random() < 0.15:
            n_rels = int(rng.choice([1, 2, 3], p=[0.60, 0.30, 0.10]))
            for _ in range(n_rels):
                target = rng.integers(1, n_customers + 1)
                if target == i:
                    continue
                records.append(
                    {
                        "source_id": f"CUST{i:06d}",
                        "target_id": f"CUST{target:06d}",
                        "relationship_type": rng.choice(RELATIONSHIP_TYPES),
                        "strength": round(float(rng.uniform(0.3, 1.0)), 3),
                        "start_date": (
                            datetime.now() - timedelta(days=int(rng.integers(0, 1825)))
                        ).strftime("%Y-%m-%d"),
                        "end_date": None,
                    }
                )

    df = (
        pd.DataFrame(records)
        if records
        else pd.DataFrame(
            columns=[
                "source_id",
                "target_id",
                "relationship_type",
                "strength",
                "start_date",
                "end_date",
            ]
        )
    )
    log_audit("SAMPLE_GEN", f"relationships: {len(df)} records")
    return df


# =============================================================================
# GRAPH-SCHEMA GENERATORS (matching reference image schemas)
# =============================================================================
def generate_nodes(n: int = 10000, seed: int = 42) -> pd.DataFrame:
    """
    Graph Layer 1: NODE table.
    Schema: node_id, name, node_type, node_type1, node_type3, country, state, identifier, risk_score

    node_type  — entity category: Person, Entity, Merchant, Account, Trust
    node_type1 — bank-level classification: Internal (Account nodes owned by the bank)
                 vs External (all other counterparties / customers)
    node_type3 — customer segment: Retail / Corporate / Financial / Government
                 (v16.28: added for ChipGroup filter on Radar page; renamed node_type2 → node_type3 in v16.31)
    state      — US state code for US-country nodes; "N/A" for all others

    Merged from: Accounts, Persons, Entities, Merchants
    """
    rng = np.random.default_rng(seed + 10)
    names_pool = [
        "John Smith",
        "Shell Corp Ltd",
        "Crypto Exchange Pro",
        "Maria Garcia",
        "ABC Trading",
        "Global Finance",
        "Tech Ventures",
        "Pacific Holdings",
        "Alpha Consulting",
        "Beta Solutions",
    ]
    identifier_prefixes = {
        "Person": lambda i: f"CREF-{rng.integers(100,999)}-{rng.integers(10,99)}-{rng.integers(1000,9999)}",
        "Entity": lambda i: f"EREF-{rng.integers(10,99)}-{rng.integers(1000000,9999999)}",
        "Merchant": lambda i: f"MSB-License-{rng.integers(100,999)}",
        "Account": lambda i: f"ACCT-{rng.integers(10000000,99999999)}",
        "Trust": lambda i: f"TRUST-{rng.integers(1000,9999)}",
    }
    node_ids = [f"N{i:04d}" for i in range(1, n + 1)]
    node_types = rng.choice(NODE_TYPES, size=n, p=[0.40, 0.25, 0.15, 0.15, 0.05])
    countries = rng.choice(COUNTRIES, size=n, p=COUNTRY_WEIGHTS)
    risk_scores = rng.integers(20, 99, size=n)

    # v16.24: state assignment — US nodes get a state code, others get "N/A"
    _us_mask_n = (countries == "US")
    _us_count_n = int(_us_mask_n.sum())
    states_n = np.full(n, "N/A", dtype=object)
    if _us_count_n > 0:
        _sw_n = np.array(US_STATE_WEIGHTS, dtype=float)
        _sw_n /= _sw_n.sum()  # normalise to guard against float drift
        states_n[_us_mask_n] = rng.choice(US_STATES, size=_us_count_n, p=_sw_n)

    # v16.24: node_type1 — "Internal" for bank-owned Account nodes, "External" otherwise
    # Business Logic: Account nodes represent the bank's own accounts (internal assets).
    # All other node types (Person, Entity, Merchant, Trust) are external counterparties.
    node_type1_arr = np.where(node_types == "Account", "Internal", "External")

    # v16.31: node_type3 — customer segment classification (renamed from node_type2)
    # Distribution: Retail 50%, Corporate 30%, Financial 15%, Government 5%
    _NT3_VALS = ["Retail", "Corporate", "Financial", "Government"]
    _NT3_PROBS = [0.50, 0.30, 0.15, 0.05]
    node_type3_arr = rng.choice(_NT3_VALS, size=n, p=_NT3_PROBS)

    records = []
    for i in range(n):
        ntype = node_types[i]
        records.append(
            {
                "node_id": node_ids[i],
                "name": names_pool[i % len(names_pool)] if n <= 10 else f"{ntype}_{i+1:05d}",
                "node_type": ntype,
                "node_type1": node_type1_arr[i],
                "node_type3": node_type3_arr[i],
                "country": countries[i],
                "state": states_n[i],
                "identifier": identifier_prefixes[ntype](i),
                "risk_score": int(risk_scores[i]),
            }
        )
    df = pd.DataFrame(records)
    log_audit("SAMPLE_GEN", f"nodes: {n} records (cols: {list(df.columns)})")
    return df


def generate_transaction_edges(
    n_records: int = 50000, n_nodes: int = 10000, anomaly_rate: float = 0.03, seed: int = 42
) -> pd.DataFrame:
    """
    Graph Layer 2: TRANSACTION EDGE table.
    Schema: from_node, to_node, amount, date, transaction_type
    Financial flows between nodes.
    """
    rng = np.random.default_rng(seed + 11)
    node_ids = [f"N{i:04d}" for i in range(1, n_nodes + 1)]
    txn_types = ["Wire", "ACH", "Cash", "Crypto_Purchase", "Payment", "SWIFT", "RTGS", "Check"]

    from_nodes = rng.choice(node_ids, size=n_records)
    to_nodes = rng.choice(node_ids, size=n_records)
    amounts = np.abs(rng.lognormal(mean=6.5, sigma=1.5, size=n_records)).round(2)

    # Inject structuring anomalies
    n_anom = int(n_records * anomaly_rate)
    anom_idx = rng.choice(n_records, size=n_anom, replace=False)
    for idx in anom_idx:
        amounts[idx] = float(rng.choice([9500, 9800, 9900, 9950, 125000, 50000]))

    base_date = datetime(2024, 1, 1)
    dates = [
        (base_date + timedelta(days=int(rng.integers(0, 365)))).strftime("%Y-%m-%d")
        for _ in range(n_records)
    ]

    df = pd.DataFrame(
        {
            "from_node": from_nodes,
            "to_node": to_nodes,
            "amount": amounts,
            "date": dates,
            "transaction_type": rng.choice(txn_types, size=n_records),
        }
    )
    log_audit("SAMPLE_GEN", f"transaction_edges: {n_records} records")
    return df


def generate_relationship_edges(n_nodes: int = 10000, seed: int = 42) -> pd.DataFrame:
    """
    Graph Layer 3: RELATIONSHIP EDGE table.
    Schema: from_node, to_node, relationship_type, start_date
    Merged from: Ownership, Control, Authorization

    NOTE: ownership_percent was intentionally removed (v16.23 T4).
    In practice, ownership percentage data is rarely available in structured form
    inside AML investigation datasets and creates false precision.
    """
    rng = np.random.default_rng(seed + 12)

    records = []
    for i in range(1, n_nodes + 1):
        if rng.random() < 0.15:
            n_rels = int(rng.choice([1, 2, 3], p=[0.60, 0.30, 0.10]))
            for _ in range(n_rels):
                target = int(rng.integers(1, n_nodes + 1))
                if target == i:
                    continue
                rel_type = rng.choice(GRAPH_REL_TYPES)
                records.append(
                    {
                        "from_node": f"N{i:04d}",
                        "to_node": f"N{target:04d}",
                        "relationship_type": rel_type,
                        "start_date": (
                            datetime(2020, 1, 1) + timedelta(days=int(rng.integers(0, 1460)))
                        ).strftime("%Y-%m-%d"),
                    }
                )

    df = (
        pd.DataFrame(records)
        if records
        else pd.DataFrame(
            columns=["from_node", "to_node", "relationship_type", "start_date"]
        )
    )
    log_audit("SAMPLE_GEN", f"relationship_edges: {len(df)} records")
    return df


def generate_shared_attributes(n_nodes: int = 10000, seed: int = 42) -> pd.DataFrame:
    """
    Graph Layer 4: SHARED ATTRIBUTE table.
    Schema: node_id, attribute_type, attribute_value, last_used_date
    Merged from: attribue1, attribue2, Address
    """
    rng = np.random.default_rng(seed + 13)

    # Shared values pool — some nodes share the same value (the key signal)
    shared_phones = [f"555-{rng.integers(1000,9999)}" for _ in range(max(1, n_nodes // 20))]
    shared_ips = [
        f"192.168.{rng.integers(0,255)}.{rng.integers(0,255)}" for _ in range(max(1, n_nodes // 30))
    ]
    shared_addrs = [
        f"{rng.integers(1,999)} Main St {rng.choice(['Miami FL','New York NY','Houston TX'])}"
        for _ in range(max(1, n_nodes // 15))
    ]
    shared_emails = [f"user{rng.integers(1,500)}@mail.com" for _ in range(max(1, n_nodes // 25))]

    attr_value_pools = {
        "others": shared_phones,
        "Address": shared_addrs,
        "Phone": shared_phones,
        "Email": shared_emails,
        "IP_Address": shared_ips,
        "Device_ID": [f"DEV-{rng.integers(10000,99999)}" for _ in range(max(1, n_nodes // 20))],
    }

    records = []
    for i in range(1, n_nodes + 1):
        if rng.random() < 0.30:
            n_attrs = int(rng.choice([1, 2], p=[0.70, 0.30]))
            for _ in range(n_attrs):
                attr_type = rng.choice(GRAPH_ATTR_TYPES)
                pool = attr_value_pools[attr_type]
                records.append(
                    {
                        "node_id": f"N{i:04d}",
                        "attribute_type": attr_type,
                        "attribute_value": pool[int(rng.integers(0, len(pool)))],
                        "last_used_date": (
                            datetime(2024, 1, 1) + timedelta(days=int(rng.integers(0, 365)))
                        ).strftime("%Y-%m-%d"),
                    }
                )

    df = (
        pd.DataFrame(records)
        if records
        else pd.DataFrame(
            columns=["node_id", "attribute_type", "attribute_value", "last_used_date"]
        )
    )
    log_audit("SAMPLE_GEN", f"shared_attributes: {len(df)} records")
    return df


def generate_temporal_patterns(n_nodes: int = 10000, seed: int = 42) -> pd.DataFrame:
    """
    Graph Layer 5: TEMPORAL PATTERN table  (v16.26 — clean bank ledger schema)
    ============================================================================
    Schema:
        node_id         text      REQUIRED   Customer = focal node
        date            date      REQUIRED   Posting / value date
        value           decimal   REQUIRED   Always positive (never negative)
        dr_cr           char(1)   REQUIRED   D = debit (outflow), C = credit (inflow)
        counterparty_id text      OPTIONAL   NULL for cash / ATM / unknown external
        currency        char(3)   REQUIRED   ISO 4217 (USD, EUR, GBP …)
        country_code    char(2)   OPTIONAL   From payment message header; NULL for domestic
        txn_type_code   text      REQUIRED   Bank transaction type code (DBT/SAL/SWT/ATM/…)
        channel_code    text      REQUIRED   ATM / BRANCH / SWIFT / ONLINE / MOBILE / CASH

    Intentionally excluded:
        description     — no free text in real bank systems (pure codes)
        from_node       — edge-table concept; replaced by counterparty_id + dr_cr
        to_node         — edge-table concept; replaced by counterparty_id + dr_cr
        account_type    — node attribute; lives in the node table, not per transaction
        txn_ref         — synthetic; no analytical value for AML detection

    event_type is NOT an input — it is derived by aml_event_classifier.py
    using aml_rules.yaml thresholds when the full pipeline runs.

    Distributions (realistic for a large international bank):
        currency      USD 60% / EUR 20% / GBP 10% / AED 5% / SGD 2% / CHF 2% / JPY 1%
        channel_code  ONLINE 35% / BRANCH 25% / ATM 15% / SWIFT 12% / MOBILE 8% / CASH 5%
        txn_type_code DBT 22% / CDT 22% / SAL 12% / SWT 10% / ATM 10% / CHQ 8%
                      LNR 4% / LN 3% / CRYP 2% / TRD 3% / FEE 2% / INT 2%
        country_code  FATF-realistic: 60% domestic (None), 25% clean, 10% greylist, 5% blacklist
    """
    rng = np.random.default_rng(seed + 14)

    # ── Distributions ─────────────────────────────────────────────────────────
    currencies  = ["USD", "EUR", "GBP", "AED", "SGD", "CHF", "JPY"]
    currency_p  = [0.60,  0.20,  0.10,  0.05,  0.02,  0.02,  0.01]

    channels   = ["ONLINE", "BRANCH", "ATM",  "SWIFT", "MOBILE", "CASH"]
    channel_p  = [0.35,     0.25,     0.15,   0.12,    0.08,     0.05]

    # Transaction type codes (structured bank-style codes — no free text)
    txn_codes  = ["DBT",  "CDT",  "SAL",  "SWT",  "ATM",  "CHQ",
                  "LNR",  "LN",   "CRYP", "TRD",  "FEE",  "INT"]
    txn_code_p = [0.22,   0.22,   0.12,   0.10,   0.10,   0.08,
                  0.04,   0.03,   0.02,   0.03,   0.02,   0.02]

    # Direction: debits slightly more common (fees, withdrawals)
    dr_cr_vals = ["D", "C"]
    dr_cr_p    = [0.54, 0.46]

    # Country codes — 60% domestic (no header = None), else FATF distribution
    countries_ext = [
        # clean jurisdictions
        "US", "GB", "DE", "FR", "SG", "JP", "AU",
        # FATF greylist
        "AE", "TR", "PH", "VN", "PK", "NG", "ZA",
        # FATF blacklist
        "IR", "KP",
    ]
    country_ext_p = [0.18, 0.14, 0.10, 0.08, 0.06, 0.05, 0.05,
                     0.07, 0.06, 0.05, 0.04, 0.04, 0.03, 0.02,
                     0.02, 0.01]
    country_ext_p = [p / sum(country_ext_p) for p in country_ext_p]

    # Force certain channel/code relationships to be realistic:
    # ATM channel → ATM code; SWIFT channel → SWT code (override where inconsistent)
    channel_to_code_override = {
        "ATM":   "ATM",
        "CASH":  "CDT",  # cash deposits are credits; cash withdrawals DBT — approximate
        "SWIFT": "SWT",
    }

    # Build a pool of internal counterparty IDs that actually exist in the node set
    all_internal = [f"N{i:04d}" for i in range(1, n_nodes + 1)]

    records = []
    for i in range(1, n_nodes + 1):
        if rng.random() < 0.35:          # ~35% of nodes have ledger-level temporal rows
            n_txns  = int(rng.choice([1, 2, 3, 4, 5], p=[0.40, 0.30, 0.15, 0.10, 0.05]))
            node_id = f"N{i:04d}"
            # Small pool of counterparties this node transacts with (realistic: ~3-6 regular counterparties)
            pool_size     = int(rng.integers(2, 7))
            cparty_pool   = [all_internal[j] for j in
                             rng.choice(n_nodes, size=pool_size, replace=False).tolist()
                             if all_internal[j] != node_id]
            for _ in range(n_txns):
                # Amount: skewed — most retail, some near-CTR, few large
                rand_cat = rng.random()
                if rand_cat < 0.65:
                    value = float(rng.integers(50, 9750))
                elif rand_cat < 0.85:
                    value = float(rng.integers(9750, 10250))   # near-CTR band
                else:
                    value = float(rng.integers(10000, 200000))
                # Round amount ~18% of transactions (AML signal for round amounts)
                if rng.random() < 0.18:
                    value = round(value / 1000) * 1000

                channel      = rng.choice(channels, p=channel_p)
                # Override txn_type_code for certain channels for realism
                if channel in channel_to_code_override:
                    txn_type_code = channel_to_code_override[channel]
                else:
                    txn_type_code = rng.choice(txn_codes, p=txn_code_p)

                dr_cr        = rng.choice(dr_cr_vals, p=dr_cr_p)
                # SAL = salary → always a credit (inflow to node)
                if txn_type_code == "SAL":
                    dr_cr = "C"
                # LN = loan disbursement → credit; LNR = loan repayment → debit
                elif txn_type_code == "LN":
                    dr_cr = "C"
                elif txn_type_code == "LNR":
                    dr_cr = "D"
                # FEE/INT = bank fees → always debit
                elif txn_type_code in ("FEE", "INT"):
                    dr_cr = "D"

                # Counterparty: internal if we have one, else external or null
                # ATM / FEE / INT have no meaningful counterparty
                if txn_type_code in ("ATM", "FEE", "INT") or channel == "CASH":
                    counterparty_id = ""   # unknown/no counterparty
                elif cparty_pool and rng.random() < 0.70:
                    counterparty_id = cparty_pool[
                        int(rng.integers(0, len(cparty_pool)))
                    ]
                else:
                    counterparty_id = ""   # external party not in our node set

                # Country code: 60% domestic (no header in payment), 40% international
                if rng.random() < 0.60 or channel not in ("SWIFT", "ONLINE"):
                    country_code = ""
                else:
                    country_code = rng.choice(countries_ext, p=country_ext_p)

                records.append({
                    "node_id":         node_id,
                    "date": (
                        datetime(2024, 1, 1)
                        + timedelta(days=int(rng.integers(0, 365)))
                    ).strftime("%Y-%m-%d"),
                    "value":           round(value, 2),
                    "dr_cr":           dr_cr,
                    "counterparty_id": counterparty_id,
                    "currency":        rng.choice(currencies, p=currency_p),
                    "country_code":    country_code,
                    "txn_type_code":   txn_type_code,
                    "channel_code":    channel,
                })

    _TEMPORAL_COLS = [
        "node_id", "date", "value", "dr_cr", "counterparty_id",
        "currency", "country_code", "txn_type_code", "channel_code",
    ]
    df = (
        pd.DataFrame(records)
        if records
        else pd.DataFrame(columns=_TEMPORAL_COLS)
    )
    log_audit(
        "SAMPLE_GEN",
        f"temporal_patterns: {len(df)} records | schema: ledger-posting | event_type derived in backend",
    )
    return df


def generate_cases(n_customers: int = 10000, seed: int = 42) -> pd.DataFrame:
    """
    Legacy Layer: CASE table.
    Schema: case_id, customer_id, case_type, status, opened_date, analyst, priority
    """
    rng = np.random.default_rng(seed + 15)
    records = []
    case_id = 1
    for i in range(1, n_customers + 1):
        if rng.random() < 0.08:
            records.append(
                {
                    "case_id": f"CASE{case_id:06d}",
                    "customer_id": f"CUST{i:06d}",
                    "case_type": rng.choice(CASE_TYPES),
                    "status": rng.choice(CASE_STATUSES, p=[0.35, 0.30, 0.15, 0.15, 0.05]),
                    "opened_date": (
                        datetime.now() - timedelta(days=int(rng.integers(0, 365)))
                    ).strftime("%Y-%m-%d"),
                    "analyst": f"analyst_{int(rng.integers(1, 20)):02d}",
                    "priority": rng.choice(
                        ["low", "medium", "high", "critical"], p=[0.30, 0.35, 0.25, 0.10]
                    ),
                }
            )
            case_id += 1
    df = (
        pd.DataFrame(records)
        if records
        else pd.DataFrame(
            columns=[
                "case_id",
                "customer_id",
                "case_type",
                "status",
                "opened_date",
                "analyst",
                "priority",
            ]
        )
    )
    log_audit("SAMPLE_GEN", f"cases: {len(df)} records")
    return df


# =============================================================================
# MASTER GENERATOR
# =============================================================================
def generate_all_samples(
    n_customers: int = 10000,
    n_transactions: int = 50000,
    anomaly_rate: float = 0.03,
    seed: int = 42,
    output_dir: Path = None,
) -> Dict[str, pd.DataFrame]:
    """
    Business Logic: Generate all 13 sample tables:
      - 8 legacy tables: customer, account, kyc, transaction, historical,
        alert, relationship, case
      - 5 graph-schema tables: node, edge, relationship_edge,
        shared_attribute, temporal

    Technical Implementation: Generates each table, validates shapes,
    saves to data/samples/ as CSV, and returns dict of DataFrames.
    """
    output_dir = output_dir or PATHS.SAMPLES
    output_dir.mkdir(parents=True, exist_ok=True)

    log_audit(
        "SAMPLE_GEN_START", f"Generating {n_customers} customers, {n_transactions} transactions"
    )

    # --- Legacy tables (8) ---
    legacy_tables = {
        "customer": generate_customers(n_customers, seed),
        "account": generate_accounts(n_customers, seed),
        "kyc": generate_kyc(n_customers, seed),
        "transaction": generate_transactions(n_transactions, n_customers, anomaly_rate, seed),
        "historical": generate_historical(n_customers, seed),
        "alert": generate_alerts(n_customers, seed),
        "relationship": generate_relationships(n_customers, seed),
        "case": generate_cases(n_customers, seed),
    }

    # --- Graph-schema tables (5) ---
    n_nodes = n_customers
    n_edges = n_transactions
    graph_tables = {
        "node": generate_nodes(n_nodes, seed),
        "edge": generate_transaction_edges(n_edges, n_nodes, anomaly_rate, seed),
        "relationship_edge": generate_relationship_edges(n_nodes, seed),
        "shared_attribute": generate_shared_attributes(n_nodes, seed),
        "temporal": generate_temporal_patterns(n_nodes, seed),
    }

    tables = {**legacy_tables, **graph_tables}

    # ── Background CSV save (non-blocking) ───────────────────────────────────
    # PROBLEM: df.to_csv() on OneDrive-hosted paths BLOCKS for 20-30 seconds
    # per file while OneDrive syncs the upload.  13 tables × 25s = ~5 minutes.
    # SOLUTION: Launch a daemon thread so the callback returns IMMEDIATELY
    # with the in-memory DataFrames, while disk writing happens in the background.
    # The DataFrames are thread-safe for concurrent READS (to_csv only reads them).
    _save_meta = {
        "generated_at": datetime.now().isoformat(),
        "seed":           seed,
        "n_customers":    n_customers,
        "n_transactions": n_transactions,
        "anomaly_rate":   anomaly_rate,
        "tables": {
            name: {"rows": len(df), "columns": len(df.columns)}
            for name, df in tables.items()
        },
    }

    def _bg_save(tables_snap: dict, out_dir: Path, meta: dict) -> None:
        """Background daemon: write CSVs and metadata.json.  Never raises."""
        saved = skipped = 0
        for name, df in tables_snap.items():
            try:
                df.to_csv(out_dir / f"{name}.csv", index=False)
                log_audit("SAMPLE_SAVE", f"{name}.csv: {len(df)} rows, {len(df.columns)} cols")
                saved += 1
            except Exception as _e:
                log_audit("SAMPLE_SAVE_SKIP",
                          f"{name}.csv skipped ({type(_e).__name__}: {_e})")
                skipped += 1
        try:
            with open(out_dir / "metadata.json", "w", encoding="utf-8") as _f:
                json.dump(meta, _f, indent=2)
        except Exception:
            pass  # metadata is cosmetic; failure must never propagate
        log_audit(
            "SAMPLE_SAVE_BG",
            f"background save complete: {saved} saved, {skipped} skipped to {out_dir}",
        )

    threading.Thread(
        target=_bg_save,
        args=(dict(tables), output_dir, _save_meta),
        daemon=True,
        name="sample-csv-bg-save",
    ).start()

    log_audit("SAMPLE_GEN_COMPLETE",
              f"13 tables generated ({sum(len(v) for v in tables.values()):,} total rows) — "
              f"CSV save queued in background thread (OneDrive-safe)")
    return tables


# =============================================================================
# CLI ENTRY POINT
# =============================================================================
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Generate FCDAI sample data")
    parser.add_argument("--customers", type=int, default=10000, help="Number of customers")
    parser.add_argument("--transactions", type=int, default=50000, help="Number of transactions")
    parser.add_argument("--anomaly-rate", type=float, default=0.03, help="Anomaly injection rate")
    parser.add_argument("--seed", type=int, default=42, help="Random seed")
    args = parser.parse_args()

    tables = generate_all_samples(
        n_customers=args.customers,
        n_transactions=args.transactions,
        anomaly_rate=args.anomaly_rate,
        seed=args.seed,
    )

    print("\n=== FCDAI Sample Data Generated ===")
    for name, df in tables.items():
        print(f"  {name:15s}: {len(df):>8,} rows × {len(df.columns):>3} columns")
    print(f"  {'':15s}  --------")
    total = sum(len(df) for df in tables.values())
    print(f"  {'TOTAL':15s}: {total:>8,} rows")
