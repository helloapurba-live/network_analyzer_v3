"""
FCDAI v10 - Memory Monitor
============================
Real-time memory/CPU monitoring for 8GB RAM constraint.
Thread-safe, lightweight, called from sidebar widget.
"""

import psutil
import os
import gc
import sys
import threading
from typing import Dict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import MEMORY


class MemoryMonitor:
    """Thread-safe singleton memory monitor."""

    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
                cls._instance._initialized = False
            return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self._initialized = True
        self._process = psutil.Process(os.getpid())

    def get_status(self) -> Dict:
        """Get current memory and CPU status."""
        try:
            mem = self._process.memory_info()
            vm = psutil.virtual_memory()
            rss_mb = mem.rss / (1024 * 1024)
            total_mb = vm.total / (1024 * 1024)
            used_pct = vm.percent

            if rss_mb >= MEMORY.CRITICAL_MB:
                level = "critical"
            elif rss_mb >= MEMORY.WARNING_MB:
                level = "warning"
            else:
                level = "ok"

            return {
                "rss_mb": round(rss_mb, 1),
                "total_mb": round(total_mb, 1),
                "used_pct": round(used_pct, 1),
                "level": level,
                "cpu_pct": round(self._process.cpu_percent(interval=0), 1),
                "threads": self._process.num_threads(),
                "gc_counts": gc.get_count(),
            }
        except Exception:
            return {"rss_mb": 0, "level": "unknown", "used_pct": 0, "cpu_pct": 0}

    def force_gc(self) -> Dict:
        """Force garbage collection and return freed bytes estimate."""
        before = self._process.memory_info().rss
        gc.collect()
        after = self._process.memory_info().rss
        freed = max(0, before - after)
        return {
            "freed_mb": round(freed / (1024 * 1024), 2),
            "current_mb": round(after / (1024 * 1024), 1),
        }

    def get_graph_memory_estimate(self, nodes: int, edges: int) -> Dict:
        """Estimate memory needed for a graph of given size."""
        # Rough estimates: ~500 bytes per node, ~200 bytes per edge
        node_bytes = nodes * 500
        edge_bytes = edges * 200
        total_mb = (node_bytes + edge_bytes) / (1024 * 1024)
        return {
            "estimated_mb": round(total_mb, 1),
            "safe": total_mb < (MEMORY.WARNING_MB - self.get_status()["rss_mb"]),
        }


def get_memory_monitor() -> MemoryMonitor:
    return MemoryMonitor()
