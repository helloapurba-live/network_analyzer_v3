"""
utils/data_provider.py — v16.72 F4+F5
Unified data loader: pipeline-memory → DB fallback, with score_* column normalization.

Always returns the same dict shape regardless of source:
    {
        "scored":   pd.DataFrame | None,
        "tables":   dict[str, pd.DataFrame],
        "analytics":dict[str, pd.DataFrame],
        "graph":    nx.Graph | None,
        "run_meta": dict  — always present, keys: run_id, started_at, customers, source
        "source":   "memory" | "db" | "empty"
    }

Column normalization (F5):
    Any *_score suffix (e.g. risk_score, aml_score) is renamed to score_* prefix
    (e.g. score_risk, score_aml) so all downstream pages can rely on score_* format.
"""

from __future__ import annotations

import re
import logging
from typing import Optional

import pandas as pd

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _normalize_score_columns(df: Optional[pd.DataFrame]) -> Optional[pd.DataFrame]:
    """
    Rename *_score (suffix) columns → score_* (prefix) if they don't already
    conform to the score_* convention.  Also strip extra leading/trailing
    whitespace from column names.
    """
    if df is None or df.empty:
        return df

    df = df.copy()
    rename_map = {}
    for col in df.columns:
        clean = col.strip()
        if clean != col:
            rename_map[col] = clean
            col = clean
        # e.g.  "risk_score" → "score_risk"
        m = re.fullmatch(r"^(.+)_score$", col)
        if m and not col.startswith("score_"):
            rename_map[col] = f"score_{m.group(1)}"
    if rename_map:
        df = df.rename(columns=rename_map)
    return df


def _build_run_meta(run_info: Optional[dict], source: str) -> dict:
    """Normalise run metadata from different shapes."""
    if run_info is None:
        return {"run_id": None, "started_at": None, "customers": 0, "source": source}
    # engine's last_run_meta uses "run_id"; database.load_latest_run uses "run_id" too
    return {
        "run_id":     run_info.get("run_id"),
        "started_at": run_info.get("started_at"),
        "finished_at":run_info.get("finished_at"),
        "customers":  run_info.get("customers", 0),
        "duration_sec": run_info.get("duration_sec"),
        "source":     source,
        **{k: v for k, v in run_info.items()
           if k not in ("run_id", "started_at", "finished_at", "customers",
                        "duration_sec")},
    }


_EMPTY = {
    "scored":    None,
    "tables":    {},
    "analytics": {},
    "graph":     None,
    "run_meta":  {"run_id": None, "started_at": None, "customers": 0, "source": "empty"},
    "source":    "empty",
}


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def get_latest_scored(pipeline=None) -> dict:
    """
    Unified data loader.

    Priority:
      1. pipeline memory  (fastest — already computed, in-process)
      2. database         (on page refresh / cold start when pipeline has no live data)
      3. empty sentinel   (nothing run yet)

    Parameters
    ----------
    pipeline : FCDAIPipeline | None
        Pass the in-process pipeline singleton.  If None, falls straight to DB.

    Returns
    -------
    dict  (see module docstring for keys)
    """
    # ── 1. Pipeline memory ──────────────────────────────────────────────────
    if pipeline is not None and pipeline.scored_df is not None:
        scored = _normalize_score_columns(pipeline.scored_df)
        tables = {k: _normalize_score_columns(v)
                  for k, v in (pipeline.tables or {}).items()}
        run_meta = _build_run_meta(
            getattr(pipeline, "last_run_meta", None), source="memory"
        )
        return {
            "scored":    scored,
            "tables":    tables,
            "analytics": pipeline.analytics or {},
            "graph":     pipeline.G,
            "run_meta":  run_meta,
            "source":    "memory",
        }

    # ── 2. Database fallback ─────────────────────────────────────────────────
    try:
        from database import FCDAIDatabase  # noqa: PLC0415
        db = FCDAIDatabase()
        data = db.load_latest_run()
        if data is not None:
            scored = _normalize_score_columns(data.get("scored_df"))
            raw_tables = data.get("raw_tables") or {}
            tables = {k: _normalize_score_columns(v)
                      for k, v in raw_tables.items()}
            run_meta = _build_run_meta(data.get("run_info"), source="db")
            log.debug("[data_provider] Loaded from DB — run_id=%s", run_meta.get("run_id"))
            return {
                "scored":    scored,
                "tables":    tables,
                "analytics": data.get("analytics") or {},
                "graph":     data.get("graph"),
                "run_meta":  run_meta,
                "source":    "db",
            }
    except Exception as exc:  # noqa: BLE001
        log.warning("[data_provider] DB load failed: %s", exc)

    # ── 3. Empty ─────────────────────────────────────────────────────────────
    return dict(_EMPTY)


def get_run_badge(run_meta: dict) -> str:
    """
    Return a short human-readable badge string for use in page banners.

    Examples:
        "Run #22  ·  memory  ·  12,450 customers"
        "Run #18  ·  DB  ·  9,300 customers  ·  ⚡ Cache Hit"
    """
    run_id   = run_meta.get("run_id")
    source   = run_meta.get("source", "?")
    custs    = run_meta.get("customers", 0)
    cache    = run_meta.get("cache_hit", False)

    source_label = {"memory": "live", "db": "DB"}.get(source, source)
    parts = []
    if run_id:
        parts.append(f"Run #{run_id}")
    parts.append(source_label)
    if custs:
        parts.append(f"{int(custs):,} customers")
    if cache:
        parts.append("⚡ Cache Hit")
    return "  ·  ".join(parts) if parts else "—"
