"""
v12.36: Reusable CEO-Presentable UI Components
================================================
Shared components for business-domain explanations, legends, and
context panels. Every chart, graph, and table across all pages should
use these components to ensure consistent CEO-level presentation.

DESIGN PRINCIPLES:
  - Non-technical business-domain language
  - PhD-level graph/neural network data science made accessible
  - Every visual element has a "What It Shows" + "Why It Matters" explanation
  - P1-P4 priority legend always visible where applicable
  - No duplication of information on the same page
"""

import dash_mantine_components as dmc
from dash import html
from dash_iconify import DashIconify
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME


# =============================================================================
# TIER / PRIORITY COLOURS — used everywhere
# =============================================================================
TIER_COLORS = {
    "P1": "#FF1744",  # Critical — immediate action
    "P2": "#FF9800",  # High — enhanced monitoring
    "P3": "#FFD600",  # Medium — scheduled review
    "P4": "#00E676",  # Low — normal operations
}

TIER_LABELS = {
    "P1": "Critical Risk (Score 80-100)",
    "P2": "High Risk (Score 60-79)",
    "P3": "Medium Risk (Score 40-59)",
    "P4": "Low Risk (Score 0-39)",
}

TIER_ACTIONS = {
    "P1": "Freeze account, file regulatory report within 24 hours",
    "P2": "Enhanced due diligence, senior analyst review within 48 hours",
    "P3": "Schedule monitoring review within 2 weeks",
    "P4": "Normal operations — no immediate action required",
}


# =============================================================================
# EXPLANATION BOX — main reusable component
# =============================================================================
def ceo_explanation_box(
    title: str,
    what_it_shows: str,
    why_it_matters: str,
    icon: str = "mdi:information-outline",
    color: str = "blue",
    management_action: str = None,
):
    """
    A styled info box that explains a chart/graph/table to non-technical users.

    Args:
        title: Short section name (e.g., "Risk Distribution Chart")
        what_it_shows: 1-2 sentence description of what the visual displays
        why_it_matters: 1-2 sentence business relevance for management
        icon: DashIconify icon name
        color: Mantine color for accent
        management_action: Optional recommended action for leadership
    """
    children = [
        dmc.Group(
            [
                DashIconify(icon=icon, width=18, color=THEME.PRIMARY),
                dmc.Text(title, size="sm", fw=700, c="white"),
            ],
            gap="xs",
        ),
        dmc.Space(h=6),
        dmc.Group(
            [
                dmc.Text("What It Shows:", size="xs", fw=700, c=THEME.PRIMARY),
                dmc.Text(what_it_shows, size="xs", c=THEME.TEXT_SECONDARY),
            ],
            gap=4,
            wrap="wrap",
        ),
        dmc.Group(
            [
                dmc.Text("Why It Matters:", size="xs", fw=700, c="#FFD600"),
                dmc.Text(why_it_matters, size="xs", c=THEME.TEXT_SECONDARY),
            ],
            gap=4,
            wrap="wrap",
        ),
    ]

    if management_action:
        children.append(
            dmc.Group(
                [
                    dmc.Text("Action Required:", size="xs", fw=700, c="#FF6B6B"),
                    dmc.Text(management_action, size="xs", c=THEME.TEXT_SECONDARY),
                ],
                gap=4,
                wrap="wrap",
            )
        )

    return dmc.Paper(
        children,
        p="sm",
        radius="sm",
        style={
            "background": "rgba(0, 212, 255, 0.05)",
            "border": f"1px solid {THEME.GLASS_BORDER}",
            "borderLeft": f"3px solid {THEME.PRIMARY}",
            "marginBottom": "12px",
            "marginTop": "4px",
        },
    )


# =============================================================================
# PRIORITY LEGEND — reusable P1-P4 legend
# =============================================================================
def priority_legend(compact: bool = False):
    """
    Standard P1-P4 priority legend with business-domain descriptions.
    Use compact=True for inline placement next to charts.
    """
    if compact:
        return dmc.Group(
            [
                dmc.Group(
                    [
                        html.Div(
                            style={
                                "width": "10px",
                                "height": "10px",
                                "borderRadius": "50%",
                                "background": TIER_COLORS[tier],
                                "display": "inline-block",
                            }
                        ),
                        dmc.Text(
                            f"{tier}: {TIER_LABELS[tier].split('(')[0].strip()}",
                            size="xs",
                            c=THEME.TEXT_SECONDARY,
                        ),
                    ],
                    gap=4,
                )
                for tier in ["P1", "P2", "P3", "P4"]
            ],
            gap="md",
            wrap="wrap",
        )

    # Full legend with actions
    items = []
    for tier in ["P1", "P2", "P3", "P4"]:
        items.append(
            dmc.Group(
                [
                    dmc.Badge(
                        tier,
                        color=(
                            "red"
                            if tier == "P1"
                            else "orange" if tier == "P2" else "yellow" if tier == "P3" else "green"
                        ),
                        variant="filled",
                        size="sm",
                        style={"minWidth": "36px"},
                    ),
                    dmc.Stack(
                        [
                            dmc.Text(TIER_LABELS[tier], size="xs", fw=600, c="white"),
                            dmc.Text(TIER_ACTIONS[tier], size="xs", c=THEME.TEXT_SECONDARY),
                        ],
                        gap=2,
                    ),
                ],
                gap="sm",
                wrap="nowrap",
            )
        )

    return dmc.Paper(
        [
            dmc.Group(
                [
                    DashIconify(icon="mdi:shield-alert", width=16, color=THEME.PRIMARY),
                    dmc.Text("Risk Priority Guide", size="sm", fw=700, c="white"),
                ],
                gap="xs",
            ),
            dmc.Space(h=8),
            dmc.Stack(items, gap="xs"),
        ],
        p="sm",
        radius="sm",
        style={
            "background": THEME.GLASS_BG,
            "border": f"1px solid {THEME.GLASS_BORDER}",
            "marginBottom": "12px",
        },
    )


# =============================================================================
# CHART LEGEND — explains visual encodings
# =============================================================================
def chart_legend(items: list):
    """
    A reusable legend panel for chart visual encodings.

    Args:
        items: List of dicts with keys:
            - "symbol": color hex or icon name
            - "label": legend label text
            - "meaning": business meaning
    """
    legend_items = []
    for item in items:
        symbol = item.get("symbol", "#666")
        if symbol.startswith("#") or symbol.startswith("rgb"):
            # Color swatch
            indicator = html.Div(
                style={
                    "width": "12px",
                    "height": "12px",
                    "borderRadius": "3px",
                    "background": symbol,
                    "flexShrink": "0",
                }
            )
        else:
            # Icon
            indicator = DashIconify(icon=symbol, width=14, color=THEME.PRIMARY)

        legend_items.append(
            dmc.Group(
                [
                    indicator,
                    dmc.Text(item.get("label", ""), size="xs", fw=600, c="white"),
                    dmc.Text(f"— {item.get('meaning', '')}", size="xs", c=THEME.TEXT_SECONDARY),
                ],
                gap=4,
                wrap="wrap",
            )
        )

    return dmc.Paper(
        [
            dmc.Text(
                "Legend",
                size="xs",
                fw=700,
                c=THEME.TEXT_MUTED,
                tt="uppercase",
                style={"letterSpacing": "1px"},
            ),
            dmc.Space(h=4),
            dmc.Stack(legend_items, gap=4),
        ],
        p="xs",
        radius="sm",
        style={
            "background": "rgba(255, 255, 255, 0.03)",
            "border": f"1px solid {THEME.GLASS_BORDER}",
            "marginTop": "8px",
        },
    )


# =============================================================================
# DATA MODE BADGE — shows whether app is in graph-schema or legacy mode
# =============================================================================
def data_mode_badge(data_mode: str = "legacy"):
    """Badge showing current pipeline data mode."""
    if data_mode == "graph_schema":
        return dmc.Badge(
            "Graph-Schema Mode (Node + Edge)",
            color="cyan",
            variant="light",
            size="sm",
            leftSection=DashIconify(icon="mdi:graph", width=14),
        )
    else:
        return dmc.Badge(
            "Legacy Mode (Customer + Transaction)",
            color="grape",
            variant="light",
            size="sm",
            leftSection=DashIconify(icon="mdi:database", width=14),
        )


# =============================================================================
# SECTION HEADER — consistent section titles across pages
# =============================================================================
def section_header(title: str, subtitle: str = None, icon: str = None):
    """Consistent section header with optional subtitle and icon."""
    items = []
    if icon:
        items.append(DashIconify(icon=icon, width=20, color=THEME.PRIMARY))
    items.append(dmc.Text(title, size="lg", fw=700, c="white"))
    header = dmc.Group(items, gap="xs")

    if subtitle:
        return dmc.Stack(
            [
                header,
                dmc.Text(subtitle, size="xs", c=THEME.TEXT_SECONDARY, style={"marginTop": "-4px"}),
            ],
            gap=2,
        )
    return header


# =============================================================================
# GRAPH ANALYTICS DEFINITIONS — PhD-level data science, business language
# =============================================================================
ANALYTICS_DEFINITIONS = {
    "centrality": {
        "title": "Influence & Connectivity Analysis",
        "what_it_shows": (
            "Identifies the most influential and well-connected accounts in the financial network. "
            "Uses PageRank (the algorithm behind Google Search) to measure how 'important' each account is "
            "based on who sends them money and how those senders are connected."
        ),
        "why_it_matters": (
            "Accounts with unusually high centrality scores are often money laundering conduits — "
            "they sit at the hub of complex transaction webs. Identifying them early prevents "
            "millions in regulatory fines and reputational damage."
        ),
        "management_action": "Review top 10 highest-centrality P1/P2 accounts for enhanced due diligence.",
    },
    "community": {
        "title": "Community & Cluster Detection",
        "what_it_shows": (
            "Groups accounts that transact heavily with each other into 'communities' — "
            "like finding friend circles in a social network, but for money flows. "
            "Uses the Louvain algorithm, a Nobel Prize-adjacent method for detecting hidden structure."
        ),
        "why_it_matters": (
            "Money laundering rings operate as tight-knit groups. If a cluster of 5-10 accounts "
            "sends money only to each other in circles, that's a textbook layering pattern. "
            "Each detected community is a potential regulatory filing."
        ),
        "management_action": "Investigate communities with >5 members and avg risk >60.",
    },
    "pathflow": {
        "title": "Money Flow Path Analysis",
        "what_it_shows": (
            "Traces the shortest paths money takes between high-risk accounts. "
            "Maps the exact route funds travel — from source through intermediaries to destination. "
            "Reveals 'pass-through' accounts that serve as money laundering pipelines."
        ),
        "why_it_matters": (
            "Regulators require institutions to demonstrate they can trace funds end-to-end. "
            "Path analysis automates what would take investigators weeks — following the money "
            "through complex multi-hop transaction chains."
        ),
        "management_action": "Escalate paths connecting 2+ P1 accounts through intermediaries.",
    },
    "link_prediction": {
        "title": "Hidden Connection Prediction",
        "what_it_shows": (
            "Predicts connections that SHOULD exist between accounts but don't appear in transaction data. "
            "Uses mathematical similarity measures (Jaccard, Adamic-Adar) to find accounts that "
            "share many common counterparties — suggesting undisclosed relationships."
        ),
        "why_it_matters": (
            "Shell companies and nominee accounts are designed to hide beneficial ownership. "
            "Link prediction reveals the invisible threads connecting seemingly unrelated accounts, "
            "exposing the true network behind corporate veils."
        ),
        "management_action": "Cross-reference predicted links with KYC beneficial ownership records.",
    },
    "anomaly": {
        "title": "Statistical Anomaly Detection",
        "what_it_shows": (
            "Applies 4 independent statistical methods (ECOD, Isolation Forest, Local Outlier Factor, Z-Score) "
            "to identify accounts whose behaviour deviates significantly from the norm. "
            "An account flagged by multiple methods is exponentially more suspicious."
        ),
        "why_it_matters": (
            "Traditional rule-based systems miss novel laundering techniques. Machine learning anomaly "
            "detection adapts to new patterns without manual rule updates. Multi-method consensus "
            "reduces false positives by 70-90%, saving investigator hours."
        ),
        "management_action": "Prioritize accounts flagged by 3+ anomaly methods (consensus anomalies).",
    },
    "temporal": {
        "title": "Time-Pattern Intelligence",
        "what_it_shows": (
            "Analyses WHEN transactions happen — detecting velocity spikes (sudden bursts of activity), "
            "dormant reactivation (accounts going quiet then flooding with transactions), "
            "and acceleration patterns (steadily increasing transaction volumes)."
        ),
        "why_it_matters": (
            "Timing is the fingerprint of financial crime. Structuring uses specific time windows, "
            "layering uses rapid-fire transactions, and integration uses gradual normalization. "
            "Time-pattern analysis catches what amount-based rules miss."
        ),
        "management_action": "Alert on velocity spikes >5x normal for P1/P2 accounts.",
    },
    "multi_layer": {
        "title": "Cross-Layer Network Analysis",
        "what_it_shows": (
            "Compares an account's behaviour across multiple relationship types simultaneously — "
            "transaction flows, corporate ownership links, shared addresses, and temporal patterns. "
            "An account that's central in ALL layers is a systemic risk."
        ),
        "why_it_matters": (
            "Sophisticated laundering operations span multiple relationship types. "
            "A corporate director who is also a high-volume transactor AND shares an address with "
            "another P1 account creates a multi-dimensional risk that single-layer analysis misses."
        ),
        "management_action": "Escalate accounts with high cross-layer correlation to senior compliance.",
    },
    "structuring": {
        "title": "Structuring & Smurfing Detection",
        "what_it_shows": (
            "Identifies accounts deliberately splitting large transactions into smaller ones "
            "to stay below regulatory reporting thresholds (e.g., $10,000 CTR limit). "
            "Detects clusters of just-below-threshold transactions within short time windows."
        ),
        "why_it_matters": (
            "Structuring is a federal crime and the most common form of money laundering. "
            "Each instance requires a regulatory filing. Missing structuring patterns can result "
            "in consent orders, fines of $100M+, and personal liability for compliance officers."
        ),
        "management_action": "File regulatory reports for all confirmed structuring patterns within 24 hours.",
    },
    "benfords": {
        "title": "Benford's Law Statistical Test",
        "what_it_shows": (
            "Tests whether transaction amounts follow the natural distribution expected in legitimate "
            "financial data (Benford's Law — first digits should be '1' about 30% of the time). "
            "Deviation from this law is a strong indicator of fabricated or manipulated transactions."
        ),
        "why_it_matters": (
            "Benford's Law detection has been used by forensic accountants for decades and has been "
            "upheld as evidence in court. It catches systematic data manipulation that individual "
            "transaction monitoring cannot detect."
        ),
        "management_action": "Refer Benford's violations to forensic accounting team for deep-dive.",
    },
    "motifs": {
        "title": "Transaction Pattern Recognition",
        "what_it_shows": (
            "Identifies recurring transaction patterns (motifs) such as fan-in (many accounts sending "
            "to one), fan-out (one account distributing to many), pass-through (money flowing straight "
            "through), and circular flows (money returning to its origin)."
        ),
        "why_it_matters": (
            "Each motif corresponds to a specific money laundering technique. Fan-in = collection, "
            "fan-out = distribution/layering, circular = round-tripping, pass-through = simple "
            "laundering pipeline. Pattern recognition automates typology classification."
        ),
        "management_action": "Map detected motifs to known laundering typologies for regulatory reporting.",
    },
}


def analytics_explanation(family_name: str):
    """Return a CEO explanation box for a specific analytics family."""
    defn = ANALYTICS_DEFINITIONS.get(family_name, {})
    if not defn:
        return html.Div()
    return ceo_explanation_box(
        title=defn.get("title", family_name.title()),
        what_it_shows=defn.get("what_it_shows", ""),
        why_it_matters=defn.get("why_it_matters", ""),
        icon="mdi:chart-box-outline",
        management_action=defn.get("management_action"),
    )


# =============================================================================
# PAGE-LEVEL DEFINITIONS — for major pages
# =============================================================================
PAGE_DEFINITIONS = {
    "dashboard": {
        "title": "Command Dashboard",
        "what_it_shows": (
            "Real-time overview of your financial crime detection pipeline. Shows how many customers "
            "have been analysed, current risk distribution across all priority tiers, pipeline execution "
            "status, and data readiness indicators for each uploaded table."
        ),
        "why_it_matters": (
            "The dashboard is your single source of truth for the institution's AML posture. "
            "At a glance you can see: how many P1 accounts need immediate attention, whether "
            "the analysis pipeline completed successfully, and which data sources are feeding the system."
        ),
    },
    "network_intelligence": {
        "title": "Network Intelligence",
        "what_it_shows": (
            "Interactive map of all financial relationships between accounts. Each dot represents "
            "a customer/entity, each line represents money movement. Color = risk level, "
            "size = risk magnitude, line thickness = transaction volume."
        ),
        "why_it_matters": (
            "Financial crime is a network problem. Individual transaction monitoring misses the "
            "bigger picture — network intelligence reveals the hidden structure of laundering "
            "operations by visualizing how money flows through the entire system."
        ),
    },
    "lobby_analysis": {
        "title": "Lobby & Ring Detection",
        "what_it_shows": (
            "Detects tightly connected groups of accounts that transact with each other in circular "
            "patterns. Each 'ring' represents a potential money laundering cell — accounts passing "
            "funds in closed loops to disguise the origin of money."
        ),
        "why_it_matters": (
            "Lobbies are the organizational unit of professional money laundering. A single ring "
            "can process millions. Automated ring detection replaces months of manual investigation "
            "and provides ready-made evidence packages for regulatory filings."
        ),
    },
    "radar": {
        "title": "Interactive Risk Radar",
        "what_it_shows": (
            "Full interactive network map with point-and-click investigation. Each node is a customer "
            "or entity you can click to see their complete risk profile, transaction history, "
            "and connections to other flagged accounts."
        ),
        "why_it_matters": (
            "Empowers compliance officers to conduct investigations directly from the tool — "
            "no SQL queries, no spreadsheet exports. Click, explore, and document findings "
            "in minutes instead of days."
        ),
    },
    "geo_risk": {
        "title": "Geographic Risk Assessment",
        "what_it_shows": (
            "Maps customer and transaction activity by country, highlighting exposure to "
            "sanctioned jurisdictions, high-risk corridors, and concentration risk. "
            "Shows which countries account for the most P1/P2 flagged activity."
        ),
        "why_it_matters": (
            "Geographic risk is the foundation of any AML program. Regulators expect institutions "
            "to demonstrate awareness of jurisdictional risk. This analysis directly supports "
            "the Country Risk Assessment required by FATF recommendations."
        ),
    },
    "customer_360": {
        "title": "Customer 360° View",
        "what_it_shows": (
            "Complete profile of a single customer/entity: risk score breakdown, network position, "
            "transaction patterns, counterparty analysis, alert history, and AI-generated "
            "investigation narrative."
        ),
        "why_it_matters": (
            "Regulatory examiners expect institutions to demonstrate 'customer-level understanding'. "
            "The 360° view provides everything an investigator needs for a single case — "
            "from KYC to transaction patterns to network position — in one screen."
        ),
    },
    "intelligence_hub": {
        "title": "10-Family Analytics Intelligence Hub",
        "what_it_shows": (
            "Deep-dive into all 10 analytics families: centrality, community detection, path analysis, "
            "link prediction, anomaly detection, temporal patterns, multi-layer analysis, structuring, "
            "Benford's law, and motif recognition. Each family represents a different angle of "
            "financial crime detection."
        ),
        "why_it_matters": (
            "Multi-family analytics provides comprehensive coverage — no single algorithm catches "
            "everything. The intelligence hub shows which families are flagging which accounts, "
            "enabling investigators to focus on consensus high-risk entities."
        ),
    },
    "comparative_runs": {
        "title": "Pipeline Run Comparison",
        "what_it_shows": (
            "Compares risk scores and tier distributions between pipeline runs — "
            "showing which accounts moved UP in risk (emerging threats) and which moved DOWN "
            "(resolved issues). Tracks your institution's risk posture over time."
        ),
        "why_it_matters": (
            "Regulators expect trend analysis. 'Is our risk exposure growing or shrinking?' "
            "Run comparison provides the data to answer that question, supporting quarterly "
            "compliance reports and board presentations."
        ),
    },
    "audit_trail": {
        "title": "Compliance Audit Trail",
        "what_it_shows": (
            "Chronological log of every pipeline action, data access, and system event — "
            "who ran what analysis, when, on which data, with SHA-256 integrity verification. "
            "Every entry is tamper-evident and time-stamped."
        ),
        "why_it_matters": (
            "Regulatory examinations require complete audit trails. This log proves your institution "
            "is running AML analytics regularly, reviewing results, and maintaining data integrity. "
            "It's your defense in any regulatory inquiry."
        ),
    },
    "reports": {
        "title": "Regulatory Reporting Package",
        "what_it_shows": (
            "Pre-formatted investigation queue, risk matrix, and auto-generated narratives for "
            "every flagged account. Ready-to-file content for regulatory reports including "
            "risk justification and supporting evidence."
        ),
        "why_it_matters": (
            "Reduces report preparation time from hours to minutes. Auto-generated narratives "
            "ensure consistency and completeness across all filings. The investigation queue "
            "prioritizes work by risk level, optimizing analyst productivity."
        ),
    },
    "pipeline_runs": {
        "title": "Pipeline Execution History",
        "what_it_shows": (
            "Complete history of all pipeline executions — duration, customers processed, "
            "graph size, success/failure status. Tracks system performance and data volume "
            "trends over time."
        ),
        "why_it_matters": (
            "Operational oversight for the compliance technology team. Ensures the AML system "
            "is running consistently, processing the expected data volumes, and completing "
            "within acceptable time windows."
        ),
    },
    "visualization": {
        "title": "Advanced Graph Visualization",
        "what_it_shows": (
            "Interactive network graph with advanced layout controls, node selection strategies, "
            "and scale management. Supports viewing up to 10,000 nodes simultaneously with "
            "level-of-detail rendering for smooth performance."
        ),
        "why_it_matters": (
            "Visual pattern recognition is essential for complex investigations. The human brain "
            "excels at spotting anomalous structures in network visualizations that algorithms "
            "might miss — this tool augments AI with human expertise."
        ),
    },
}


def page_explanation(page_name: str):
    """Return a CEO explanation box for a specific page."""
    defn = PAGE_DEFINITIONS.get(page_name, {})
    if not defn:
        return html.Div()
    return ceo_explanation_box(
        title=defn.get("title", page_name.replace("_", " ").title()),
        what_it_shows=defn.get("what_it_shows", ""),
        why_it_matters=defn.get("why_it_matters", ""),
        icon="mdi:information-outline",
    )
