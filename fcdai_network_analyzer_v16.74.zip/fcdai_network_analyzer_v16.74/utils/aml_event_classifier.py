"""
utils/aml_event_classifier.py -- v16.27
=======================================
FATF / FinCEN-Aligned AML Event Classification Engine.

PURPOSE
-------
Transform raw bank ledger records (NO pre-labelled event_type) into
classified AML events using a comprehensive, configurable ruleset.

INPUT SCHEMA (temporal / ledger-posting table)
-----------------------------------------------
  Required:
    node_id         text     Customer = focal node (always the account holder)
    date            date     Posting / value date
    value           decimal  Always positive
    dr_cr           char(1)  D = debit (outflow FROM node), C = credit (inflow TO node)
    currency        char(3)  ISO 4217

  Optional (blank string or missing column -- rule skips gracefully):
    counterparty_id text     The other party; blank for ATM / CASH / FEE / INT
    country_code    char(2)  From SWIFT/SEPA message header; blank = domestic
    txn_type_code   text     Bank code: DBT CDT SAL SWT ATM CHQ LNR LN CRYP TRD FEE INT
    channel_code    text     ATM / BRANCH / SWIFT / ONLINE / MOBILE / CASH

Intentionally ABSENT -- these do not belong in a ledger row:
    description     -- no free text in real bank core-banking systems
    from_node       -- edge-table concept; replaced by counterparty_id + dr_cr
    to_node         -- edge-table concept; replaced by counterparty_id + dr_cr
    account_type    -- node attribute; lives in the node table
    txn_ref         -- synthetic; no AML detection value

FLOW SEMANTICS
--------------
  dr_cr = 'D'  =>  outflow  =>  node_id --[value]--> counterparty_id
  dr_cr = 'C'  =>  inflow   =>  counterparty_id --[value]--> node_id

OUTPUT
------
  Same DataFrame + two new columns:
    event_type  : highest-priority rule that fired (str)
    event_flags : pipe-separated list of ALL rules that fired

EVENT TYPE PRIORITY ORDER (first match wins for event_type)
------------------------------------------------------------
 1  SAR_INDICATOR          Composite: >=3 other flags simultaneously
 2  STRUCTURING            Sub-CTR multi-txn avoidance
 3  ROUND_TRIP             Funds return to originator (D then C, same counterparty)
 4  CIRCULAR_LAYERING      Multi-hop cycle through 3+ entities
 5  SMURFING               Many nodes -> same counterparty, similar amounts, same day
 6  RAPID_IN_OUT           Pass-through node: high inflow quickly followed by outflow
 7  MULE_INDICATOR         Receives from many, forwards to many, retains <10%
 8  HIGH_RISK_CPTY         Counterparty country in FATF blacklist
 9  OFFSHORE_TRANSFER      Transfer involving FATF grey/blacklist country
10  LARGE_CASH_TXN         Cash channel txn >= CTR threshold
11  THRESHOLD_AVOIDANCE    Amount just below reporting threshold
12  SPLIT_DEPOSIT          Multiple credits from same counterparty within hours
13  HIGH_VELOCITY          >=N transactions in 24-hour window
14  BURST_ACTIVITY         Day count >> 30-day baseline (5x spike)
15  DORMANT_REACTIVATION   Inactive 90+ days then sudden activity
16  CONCENTRATION_RISK     >=80% of inflows from single counterparty
17  LAYERING_CHAIN         5+ outbound debits within 12h window
18  UNUSUAL_HOURS          Majority of txns at night / weekend
19  PEP_LINKED             High-risk country + high value (PEP proxy)
20  TRADE_BASED_ML         TRD txn_type_code + amount anomaly
21  CRYPTO_BRIDGE          CRYP txn_type_code
22  LOAN_BACK              LN followed by LNR bilateral -- loan-back layering
23  CURRENCY_ANOMALY       3+ different currencies transacted
24  GEOGRAPHIC_ANOMALY     Unexpected FATF-risk country vs node\'s typical country
25  CASH_INTENSIVE         >=70% ATM or CASH channel transactions
26  ROUND_AMOUNT           >=60% of high-value txns are perfectly round
27  MULTI_CURRENCY_LAYER   Multi-currency use above half-CTR threshold
28  ACCOUNT_TAKEOVER       10x spike vs own baseline
29  EDD_TRIGGER            High-risk country + large value (EDD criteria)
30  RAPID_MOVEMENT         Large inflow -> bulk outflows within same day
31  NORMAL                 No rule triggered
"""

from __future__ import annotations

import logging
from datetime import timedelta
from functools import lru_cache
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import yaml

__all__ = ["classify_events", "load_rules", "EVENT_PRIORITY"]

logger = logging.getLogger(__name__)

_RULES_FILE_DEFAULT = Path(__file__).parent.parent / "aml_rules.yaml"

# -- Priority list -------------------------------------------------------
EVENT_PRIORITY = [
    "SAR_INDICATOR",
    "STRUCTURING",
    "ROUND_TRIP",
    "CIRCULAR_LAYERING",
    "SMURFING",
    "RAPID_IN_OUT",
    "MULE_INDICATOR",
    "HIGH_RISK_CPTY",
    "OFFSHORE_TRANSFER",
    "LARGE_CASH_TXN",
    "THRESHOLD_AVOIDANCE",
    "SPLIT_DEPOSIT",
    "HIGH_VELOCITY",
    "BURST_ACTIVITY",
    "DORMANT_REACTIVATION",
    "CONCENTRATION_RISK",
    "LAYERING_CHAIN",
    "UNUSUAL_HOURS",
    "PEP_LINKED",
    "TRADE_BASED_ML",
    "CRYPTO_BRIDGE",
    "LOAN_BACK",
    "CURRENCY_ANOMALY",
    "GEOGRAPHIC_ANOMALY",
    "CASH_INTENSIVE",
    "ROUND_AMOUNT",
    "MULTI_CURRENCY_LAYER",
    "ACCOUNT_TAKEOVER",
    "EDD_TRIGGER",
    "RAPID_MOVEMENT",
    "NORMAL",
]

EVENT_DESCRIPTIONS: dict[str, str] = {
    "SAR_INDICATOR":        "Composite SAR signal -- 3+ AML typologies firing simultaneously",
    "STRUCTURING":          "Multiple sub-CTR transactions to avoid reporting threshold",
    "ROUND_TRIP":           "Debited to counterparty then credited back -- layering loop",
    "CIRCULAR_LAYERING":    "Multi-entity fund cycle detected (3+ hops)",
    "SMURFING":             "Many accounts debiting same counterparty, similar amounts, same day",
    "RAPID_IN_OUT":         "Pass-through: large inflows rapidly forwarded as outflows",
    "MULE_INDICATOR":       "Money mule: many counterparties, minimal retention",
    "HIGH_RISK_CPTY":       "Transaction country is FATF blacklist jurisdiction",
    "OFFSHORE_TRANSFER":    "SWIFT/ONLINE transfer to/from FATF grey/blacklist country",
    "LARGE_CASH_TXN":       "ATM/CASH channel transaction >= CTR reporting threshold",
    "THRESHOLD_AVOIDANCE":  "Transaction amount just below a known reporting limit",
    "SPLIT_DEPOSIT":        "Multiple credits from same counterparty within hours",
    "HIGH_VELOCITY":        "Abnormally high daily transaction count",
    "BURST_ACTIVITY":       "Transaction spike vs 30-day node baseline",
    "DORMANT_REACTIVATION": "Account inactive 90+ days, then sudden large activity",
    "CONCENTRATION_RISK":   ">=80% of inflows from a single counterparty",
    "LAYERING_CHAIN":       "5+ outbound debits in 12-hour window -- layering pipeline",
    "UNUSUAL_HOURS":        ">=50% of transactions outside business hours",
    "PEP_LINKED":           "High-value transfer involving PEP-risk jurisdiction",
    "TRADE_BASED_ML":       "Trade (TRD) transaction with anomalous value vs node average",
    "CRYPTO_BRIDGE":        "Cryptocurrency transaction code (CRYP)",
    "LOAN_BACK":            "Loan disbursement (LN) followed by repayment (LNR) from same counterparty",
    "CURRENCY_ANOMALY":     "3+ currencies used across node\'s transaction history",
    "GEOGRAPHIC_ANOMALY":   "FATF-risk country different from node\'s usual geography",
    "CASH_INTENSIVE":       ">=70% ATM/CASH channel transactions",
    "ROUND_AMOUNT":         "High proportion of perfectly round transaction amounts",
    "MULTI_CURRENCY_LAYER": "Multi-currency usage above half-CTR threshold",
    "ACCOUNT_TAKEOVER":     "10x activity spike vs own baseline -- possible compromise",
    "EDD_TRIGGER":          "High-risk country + high value triggers Enhanced Due Diligence",
    "RAPID_MOVEMENT":       "Large credit immediately followed by bulk debits (same day)",
    "NORMAL":               "No AML typology triggered",
}


# --------------------------------------------------------------------------
# RULES LOADER
# --------------------------------------------------------------------------

@lru_cache(maxsize=4)
def load_rules(rules_path: str | None = None) -> dict[str, Any]:
    path = Path(rules_path) if rules_path else _RULES_FILE_DEFAULT
    try:
        with open(path, encoding="utf-8") as fh:
            cfg = yaml.safe_load(fh) or {}
        logger.info("AML rules loaded from %s", path)
        return cfg
    except Exception as exc:
        logger.warning("aml_rules.yaml not found (%s) -- using built-in defaults", exc)
        return _default_rules()


def _default_rules() -> dict[str, Any]:
    return {
        "reporting_thresholds": {
            "ctr_threshold": 10000,
            "sar_threshold": 5000,
            "structuring_window_days": 7,
            "structuring_min_count": 3,
            "structuring_tolerance_pct": 0.20,
        },
        "velocity": {
            "high_velocity_window_hours": 24,
            "high_velocity_min_count": 10,
            "burst_lookback_days": 30,
            "burst_multiplier": 5.0,
        },
        "dormancy": {"dormant_days": 90, "reactivation_min_value": 500},
        "round_trip": {"max_days": 30, "min_value": 1000},
        "rapid_in_out": {"window_hours": 24, "min_throughput_pct": 0.80},
        "concentration": {"top_source_pct": 0.80},
        "high_risk_countries": {
            "blacklist": ["IR", "KP", "MM"],
            "greylist": ["AE", "PH", "TR", "VN", "YE", "SY", "PK", "JM", "HT",
                         "NG", "PA", "BH", "CG", "TZ", "MZ", "KH", "SN"],
        },
        "smurfing": {"max_amount_variance_pct": 0.05, "min_accounts": 3},
        "split_deposit": {"window_hours": 4, "min_count": 3, "combined_min": 9000},
        "offshore": {"min_transfer_value": 5000},
        "trade_based_ml": {"invoice_variance_pct": 0.30},
        "loan_back": {"return_window_days": 90, "min_value": 10000},
        "unusual_hours": {
            "night_start_hour": 23, "night_end_hour": 5,
            "weekend_days": [5, 6], "unusual_hours_min_pct": 0.50,
        },
        "round_amount": {"min_value": 1000, "min_pct": 0.60},
        "cash_intensive": {"channels": ["ATM", "CASH"], "min_pct": 0.70},
        "mule_indicator": {
            "throughput_min_pct": 0.85,
            "min_counterparties": 5,
            "max_retention_pct": 0.10,
        },
        "multi_currency": {"min_currencies": 3},
        "pep_linked": {
            "pep_high_risk_countries": ["IR", "KP", "VE", "BY", "RU", "CU", "ZW", "SY"],
            "pep_min_value": 5000,
        },
        "edd_triggers": {
            "high_risk_countries": ["IR", "KP", "MM", "VE", "SY"],
            "min_value": 2000,
        },
        "sar_composite": {"min_flag_count": 3},
        "account_takeover": {"baseline_days": 30, "spike_multiplier": 10.0},
        "layering_chain": {"min_sequential_txns": 5, "max_window_hours": 12},
        "threshold_avoidance": {
            "watch_thresholds": [3000, 5000, 9000, 9900, 9950, 9999, 10000],
            "tolerance_below": 200,
            "min_count": 2,
        },
        "crypto_bridge": {"min_value": 500},
    }


# --------------------------------------------------------------------------
# NORMALISATION
# --------------------------------------------------------------------------

def _normalise(df: pd.DataFrame) -> pd.DataFrame:
    """Ensure expected columns exist with correct types; fill missing safely."""
    df = df.copy()

    # value
    if "value" not in df.columns:
        df["value"] = 0.0
    df["value"] = pd.to_numeric(df["value"], errors="coerce").fillna(0.0).abs()

    # date
    if "date" not in df.columns:
        df["date"] = pd.Timestamp("2024-01-01")
    df["date"] = pd.to_datetime(df["date"], errors="coerce").fillna(
        pd.Timestamp("2024-01-01")
    )

    # node_id
    if "node_id" not in df.columns and "customer_id" in df.columns:
        df["node_id"] = df["customer_id"].astype(str)
    elif "node_id" not in df.columns:
        df["node_id"] = "UNKNOWN"
    df["node_id"] = df["node_id"].astype(str)

    # dr_cr: D = debit (outflow), C = credit (inflow)
    if "dr_cr" not in df.columns:
        df["dr_cr"] = "D"
    df["dr_cr"] = (
        df["dr_cr"].fillna("D").astype(str).str.upper().str.strip()
    )
    df["dr_cr"] = df["dr_cr"].where(df["dr_cr"].isin(["D", "C"]), "D")

    # Optional string columns - all uppercase, fill blanks
    for col in (
        "counterparty_id", "currency", "country_code",
        "txn_type_code", "channel_code",
    ):
        if col not in df.columns:
            df[col] = ""
        else:
            df[col] = df[col].fillna("").astype(str).str.strip().str.upper()

    return df.reset_index(drop=True)


# --------------------------------------------------------------------------
# PER-NODE FEATURE PRE-COMPUTATION (one pass, fully vectorized)
# --------------------------------------------------------------------------

def _compute_node_features(df: pd.DataFrame, rules: dict) -> pd.DataFrame:
    """Add per-node aggregate feature columns in one vectorized pass."""

    # daily transaction count
    day_counts = (
        df.groupby(["node_id", "date"]).size()
        .reset_index(name="_day_txn_count")
    )
    df = df.merge(day_counts, on=["node_id", "date"], how="left")

    node_baseline = (
        df.groupby("node_id")["_day_txn_count"].mean()
        .reset_index()
        .rename(columns={"_day_txn_count": "_node_baseline_daily_avg"})
    )
    df = df.merge(node_baseline, on="node_id", how="left")

    # inflow / outflow from dr_cr  (D = debit = outflow, C = credit = inflow)
    node_inflow = (
        df[df["dr_cr"] == "C"]
        .groupby("node_id")["value"].sum()
        .reset_index()
        .rename(columns={"value": "_node_total_inflow"})
    )
    node_outflow = (
        df[df["dr_cr"] == "D"]
        .groupby("node_id")["value"].sum()
        .reset_index()
        .rename(columns={"value": "_node_total_outflow"})
    )
    df = df.merge(node_inflow,  on="node_id", how="left")
    df = df.merge(node_outflow, on="node_id", how="left")
    df["_node_total_inflow"]  = df["_node_total_inflow"].fillna(0.0)
    df["_node_total_outflow"] = df["_node_total_outflow"].fillna(0.0)

    # unique counterparties per node (blank counterparty_id excluded)
    with_cpty = df[df["counterparty_id"] != ""]
    if not with_cpty.empty:
        cparty_count = (
            with_cpty.groupby("node_id")["counterparty_id"].nunique()
            .reset_index()
            .rename(columns={"counterparty_id": "_node_counterparty_count"})
        )
        df = df.merge(cparty_count, on="node_id", how="left")
    else:
        df["_node_counterparty_count"] = 0
    df["_node_counterparty_count"] = df["_node_counterparty_count"].fillna(0).astype(int)

    # unique currencies per node
    with_curr = df[df["currency"] != ""]
    if not with_curr.empty:
        curr_count = (
            with_curr.groupby("node_id")["currency"].nunique()
            .reset_index()
            .rename(columns={"currency": "_node_currency_count"})
        )
        df = df.merge(curr_count, on="node_id", how="left")
    else:
        df["_node_currency_count"] = 1
    df["_node_currency_count"] = df["_node_currency_count"].fillna(1).astype(int)

    # cash / ATM channel percentage per node (uses channel_code)
    cash_channels = [
        c.upper() for c in
        rules.get("cash_intensive", {}).get("channels", ["ATM", "CASH"])
    ]
    df["_is_cash"] = df["channel_code"].isin(cash_channels).astype(int)
    node_cash = (
        df.groupby("node_id")["_is_cash"].mean()
        .reset_index()
        .rename(columns={"_is_cash": "_cash_pct"})
    )
    df = df.merge(node_cash, on="node_id", how="left")
    df["_cash_pct"] = df["_cash_pct"].fillna(0.0)

    # round-amount percentage per node
    ra_min = float(rules.get("round_amount", {}).get("min_value", 1000))
    df["_is_round_amount"] = (
        (df["value"] >= ra_min) & (df["value"] % 100 == 0)
    ).astype(int)
    node_round = (
        df.groupby("node_id")["_is_round_amount"].mean()
        .reset_index()
        .rename(columns={"_is_round_amount": "_round_pct"})
    )
    df = df.merge(node_round, on="node_id", how="left")
    df["_round_pct"] = df["_round_pct"].fillna(0.0)

    # earliest date per node (dormancy proxy)
    first_date = (
        df.groupby("node_id")["date"].min()
        .reset_index()
        .rename(columns={"date": "_node_first_date"})
    )
    df = df.merge(first_date, on="node_id", how="left")

    # most common country per node (for geographic anomaly)
    with_country = df[df["country_code"] != ""]
    if not with_country.empty:
        top_country = (
            with_country.groupby("node_id")["country_code"]
            .agg(lambda x: x.mode().iloc[0] if len(x) else "")
            .reset_index()
            .rename(columns={"country_code": "_node_top_country"})
        )
        df = df.merge(top_country, on="node_id", how="left")
    else:
        df["_node_top_country"] = ""
    df["_node_top_country"] = df["_node_top_country"].fillna("")

    # same-day inflow / outflow per node (for rapid_movement)
    day_inflow = (
        df[df["dr_cr"] == "C"]
        .groupby(["node_id", "date"])["value"].sum()
        .reset_index()
        .rename(columns={"value": "_day_inflow"})
    )
    df = df.merge(day_inflow, on=["node_id", "date"], how="left")
    df["_day_inflow"] = df["_day_inflow"].fillna(0.0)

    day_outflow = (
        df[df["dr_cr"] == "D"]
        .groupby(["node_id", "date"])["value"].sum()
        .reset_index()
        .rename(columns={"value": "_day_outflow"})
    )
    df = df.merge(day_outflow, on=["node_id", "date"], how="left")
    df["_day_outflow"] = df["_day_outflow"].fillna(0.0)

    return df


# --------------------------------------------------------------------------
# INDIVIDUAL RULE MASKS
# Each returns a boolean pd.Series aligned to df.index.
# Schema: dr_cr + counterparty_id + channel_code + txn_type_code + country_code
# --------------------------------------------------------------------------

def _rule_structuring(df: pd.DataFrame, rules: dict) -> pd.Series:
    """Multiple sub-CTR transactions within rolling window -- structuring."""
    cfg   = rules.get("reporting_thresholds", {})
    ctr   = float(cfg.get("ctr_threshold", 10000))
    win   = int(cfg.get("structuring_window_days", 7))
    minn  = int(cfg.get("structuring_min_count", 3))
    tol   = float(cfg.get("structuring_tolerance_pct", 0.20))
    low, high = ctr * (1 - tol), ctr
    is_sub = (df["value"] >= low) & (df["value"] < high)
    if not is_sub.any():
        return pd.Series(False, index=df.index)
    df2 = df[["node_id", "date", "value"]].copy()
    df2["_sub"] = is_sub.astype(int)
    df2 = df2.sort_values(["node_id", "date"])
    win_td = f"{win}D"
    try:
        node_sub_counts = (
            df2.set_index("date")
            .groupby("node_id")["_sub"]
            .rolling(win_td, min_periods=1).sum()
            .reset_index()
            .rename(columns={"_sub": "_sub_count"})
        )
        node_sub_counts["date"] = pd.to_datetime(node_sub_counts["date"])
        merged = df[["node_id", "date"]].merge(
            node_sub_counts, on=["node_id", "date"], how="left"
        )
        return (merged["_sub_count"].fillna(0) >= minn) & is_sub
    except Exception:
        return is_sub


def _rule_high_velocity(df: pd.DataFrame, rules: dict) -> pd.Series:
    minn = int(rules.get("velocity", {}).get("high_velocity_min_count", 10))
    return df["_day_txn_count"] >= minn


def _rule_burst_activity(df: pd.DataFrame, rules: dict) -> pd.Series:
    mult     = float(rules.get("velocity", {}).get("burst_multiplier", 5.0))
    baseline = df["_node_baseline_daily_avg"].fillna(1).clip(lower=0.5)
    return (df["_day_txn_count"] / baseline) >= mult


def _rule_dormant_reactivation(df: pd.DataFrame, rules: dict) -> pd.Series:
    cfg     = rules.get("dormancy", {})
    d_days  = int(cfg.get("dormant_days", 90))
    min_val = float(cfg.get("reactivation_min_value", 500))
    cutoff  = df["date"].max() - timedelta(days=d_days)
    recent  = df["date"].max() - timedelta(days=30)
    old_first  = df["_node_first_date"] < cutoff
    is_recent  = df["date"] >= recent
    return old_first & is_recent & (df["value"] >= min_val)


def _rule_large_cash(df: pd.DataFrame, rules: dict) -> pd.Series:
    """ATM or CASH channel transaction at/above CTR threshold."""
    ctr = float(rules.get("reporting_thresholds", {}).get("ctr_threshold", 10000))
    cash_channels = [
        c.upper() for c in
        rules.get("cash_intensive", {}).get("channels", ["ATM", "CASH"])
    ]
    is_cash = df["channel_code"].isin(cash_channels)
    return is_cash & (df["value"] >= ctr)


def _rule_threshold_avoidance(df: pd.DataFrame, rules: dict) -> pd.Series:
    cfg        = rules.get("threshold_avoidance", {})
    thresholds = cfg.get("watch_thresholds", [3000, 5000, 9000, 9900, 9999, 10000])
    tol        = float(cfg.get("tolerance_below", 200))
    min_count  = int(cfg.get("min_count", 2))
    mask = pd.Series(False, index=df.index)
    for t in thresholds:
        mask |= (df["value"] >= t - tol) & (df["value"] < t)
    df2 = df.copy()
    df2["_is_avoid"] = mask.astype(int)
    node_avoids = (
        df2.groupby("node_id")["_is_avoid"].sum()
        .reset_index().rename(columns={"_is_avoid": "_avoid_count"})
    )
    merged = df[["node_id"]].merge(node_avoids, on="node_id", how="left")
    return mask & (merged["_avoid_count"].fillna(0) >= min_count)


def _rule_offshore(df: pd.DataFrame, rules: dict) -> pd.Series:
    """Transfer to/from FATF grey or blacklist country above threshold."""
    cfg_hr  = rules.get("high_risk_countries", {})
    hr_all  = set(cfg_hr.get("blacklist", []) + cfg_hr.get("greylist", []))
    min_val = float(rules.get("offshore", {}).get("min_transfer_value", 5000))
    cross_border_channels = {"SWIFT", "ONLINE", "MOBILE"}
    in_hr    = df["country_code"].isin(hr_all) & (df["country_code"] != "")
    is_cross = df["channel_code"].isin(cross_border_channels)
    return in_hr & is_cross & (df["value"] >= min_val)


def _rule_high_risk_cpty(df: pd.DataFrame, rules: dict) -> pd.Series:
    """Any transaction involving a FATF blacklist country."""
    bl = set(rules.get("high_risk_countries", {}).get("blacklist", []))
    return df["country_code"].isin(bl) & (df["country_code"] != "")


def _rule_smurfing(df: pd.DataFrame, rules: dict) -> pd.Series:
    """Many different node_ids debiting the SAME counterparty_id,
    similar amounts, on the same day -- classic smurfing."""
    cfg     = rules.get("smurfing", {})
    min_acc = int(cfg.get("min_accounts", 3))
    if not (df["counterparty_id"] != "").any():
        return pd.Series(False, index=df.index)
    # Only debit (outflow) rows to a known counterparty
    df2 = df[
        (df["dr_cr"] == "D") & (df["counterparty_id"] != "")
    ][["node_id", "date", "counterparty_id", "value"]].copy()
    if df2.empty:
        return pd.Series(False, index=df.index)
    overall_mean = df2["value"].mean()
    df2["_val_bucket"] = (df2["value"] / max(overall_mean, 1)).round(1)
    grouped = (
        df2.groupby(["counterparty_id", "date", "_val_bucket"])["node_id"]
        .nunique().reset_index()
        .rename(columns={"node_id": "_unique_senders"})
    )
    grouped = grouped[grouped["_unique_senders"] >= min_acc]
    if grouped.empty:
        return pd.Series(False, index=df.index)
    df2 = df2.merge(
        grouped[["counterparty_id", "date", "_val_bucket"]],
        on=["counterparty_id", "date", "_val_bucket"],
        how="left", indicator=True,
    )
    smurf_orig_idx = df2[df2["_merge"] == "both"].index
    return pd.Series(df.index.isin(smurf_orig_idx), index=df.index)


def _rule_split_deposit(df: pd.DataFrame, rules: dict) -> pd.Series:
    """Node receives multiple credits from SAME counterparty within hours."""
    cfg   = rules.get("split_deposit", {})
    win_h = float(cfg.get("window_hours", 4))
    min_c = int(cfg.get("min_count", 3))
    comb  = float(cfg.get("combined_min", 9000))
    df2 = df[
        (df["dr_cr"] == "C") & (df["counterparty_id"] != "")
    ][["node_id", "counterparty_id", "date", "value"]].copy()
    if df2.empty:
        return pd.Series(False, index=df.index)
    df2 = df2.sort_values(["node_id", "counterparty_id", "date"])
    df2["_ts"] = df2["date"].astype(np.int64) // 10**9
    flagged_idx: set = set()
    win_s = win_h * 3600
    for (nid, cpid), grp in df2.groupby(["node_id", "counterparty_id"]):
        if len(grp) < min_c:
            continue
        vals = grp["value"].values
        tss  = grp["_ts"].values
        idxs = grp.index.values
        for i in range(len(tss)):
            in_win = (tss >= tss[i]) & (tss <= tss[i] + win_s)
            if in_win.sum() >= min_c and vals[in_win].sum() >= comb:
                flagged_idx.update(idxs[in_win])
    return pd.Series(df.index.isin(flagged_idx), index=df.index)


def _rule_round_trip(df: pd.DataFrame, rules: dict) -> pd.Series:
    """Node debits counterparty X then receives credit FROM X within window.
    Flow: node --D--> X  ...then...  X --C--> node  (funds return to origin)."""
    cfg   = rules.get("round_trip", {})
    max_d = int(cfg.get("max_days", 30))
    min_v = float(cfg.get("min_value", 1000))
    if not (df["counterparty_id"] != "").any():
        return pd.Series(False, index=df.index)
    debits = df[
        (df["dr_cr"] == "D") & (df["counterparty_id"] != "") & (df["value"] >= min_v)
    ][["node_id", "counterparty_id", "date"]].rename(columns={"date": "debit_date"})
    credits = df[
        (df["dr_cr"] == "C") & (df["counterparty_id"] != "") & (df["value"] >= min_v)
    ][["node_id", "counterparty_id", "date"]].rename(columns={"date": "credit_date"})
    if debits.empty or credits.empty:
        return pd.Series(False, index=df.index)
    pairs = debits.merge(credits, on=["node_id", "counterparty_id"], how="inner")
    pairs = pairs[
        (pairs["credit_date"] > pairs["debit_date"]) &
        ((pairs["credit_date"] - pairs["debit_date"]).dt.days <= max_d)
    ]
    if pairs.empty:
        return pd.Series(False, index=df.index)
    rt_node_cpty = set(zip(pairs["node_id"], pairs["counterparty_id"]))
    return pd.Series(
        [
            (row.node_id, row.counterparty_id) in rt_node_cpty and row.value >= min_v
            for row in df.itertuples(index=False)
        ],
        index=df.index,
    )


def _rule_rapid_in_out(df: pd.DataFrame, rules: dict) -> pd.Series:
    """High lifetime inflow / outflow ratio -- pass-through node."""
    cfg     = rules.get("rapid_in_out", {})
    min_pct = float(cfg.get("min_throughput_pct", 0.80))
    ratio   = df["_node_total_outflow"] / df["_node_total_inflow"].clip(lower=1)
    return (ratio >= min_pct) & (df["_node_total_inflow"] > 0)


def _rule_concentration(df: pd.DataFrame, rules: dict) -> pd.Series:
    """>=80% of inflows from a single counterparty -- concentration risk."""
    top_pct = float(rules.get("concentration", {}).get("top_source_pct", 0.80))
    credits = df[
        (df["dr_cr"] == "C") & (df["counterparty_id"] != "")
    ][["node_id", "counterparty_id", "value"]].copy()
    if credits.empty:
        return pd.Series(False, index=df.index)
    node_total = credits.groupby("node_id")["value"].sum().rename("_total")
    top_val = (
        credits.groupby(["node_id", "counterparty_id"])["value"].sum()
        .reset_index()
    )
    top_val = (
        top_val.loc[top_val.groupby("node_id")["value"].idxmax()]
        .set_index("node_id")["value"]
    )
    pct = (top_val / node_total).fillna(0)
    conc_nodes = pct[pct >= top_pct].index
    return df["node_id"].isin(conc_nodes)


def _rule_concentration_risk(df: pd.DataFrame, rules: dict) -> pd.Series:
    return _rule_concentration(df, rules)


def _rule_mule(df: pd.DataFrame, rules: dict) -> pd.Series:
    """Money mule: high counterparty diversity + high throughput + low retention."""
    cfg        = rules.get("mule_indicator", {})
    throughput = float(cfg.get("throughput_min_pct", 0.85))
    min_cparty = int(cfg.get("min_counterparties", 5))
    max_retain = float(cfg.get("max_retention_pct", 0.10))
    ratio      = df["_node_total_outflow"] / df["_node_total_inflow"].clip(lower=1)
    return (
        (ratio >= throughput) &
        (df["_node_counterparty_count"] >= min_cparty) &
        ((1 - ratio) <= max_retain)
    )


def _rule_currency_anomaly(df: pd.DataFrame, rules: dict) -> pd.Series:
    min_curr = int(rules.get("multi_currency", {}).get("min_currencies", 3))
    return df["_node_currency_count"] >= min_curr


def _rule_multi_currency_layering(df: pd.DataFrame, rules: dict) -> pd.Series:
    min_curr = int(rules.get("multi_currency", {}).get("min_currencies", 3))
    ctr      = float(rules.get("reporting_thresholds", {}).get("ctr_threshold", 10000))
    return (df["_node_currency_count"] >= min_curr) & (df["value"] >= ctr * 0.5)


def _rule_geographic_anomaly(df: pd.DataFrame, rules: dict) -> pd.Series:
    """Transaction country differs from node mode AND falls in FATF greylist."""
    greylist  = set(rules.get("high_risk_countries", {}).get("greylist", []))
    is_risky  = df["country_code"].isin(greylist) & (df["country_code"] != "")
    different = df["country_code"] != df["_node_top_country"]
    return is_risky & different


def _rule_unusual_hours(df: pd.DataFrame, rules: dict) -> pd.Series:
    cfg      = rules.get("unusual_hours", {})
    night_s  = int(cfg.get("night_start_hour", 23))
    night_e  = int(cfg.get("night_end_hour", 5))
    weekends = cfg.get("weekend_days", [5, 6])
    min_pct  = float(cfg.get("unusual_hours_min_pct", 0.50))
    hour     = df["date"].dt.hour
    wday     = df["date"].dt.weekday
    is_unusual = (hour >= night_s) | (hour < night_e) | wday.isin(weekends)
    df2 = df.copy()
    df2["_unusual"] = is_unusual.astype(int)
    node_unusual = (
        df2.groupby("node_id")["_unusual"].mean()
        .reset_index().rename(columns={"_unusual": "_unusual_pct"})
    )
    merged = df[["node_id"]].merge(node_unusual, on="node_id", how="left")
    return merged["_unusual_pct"].fillna(0) >= min_pct


def _rule_pep_linked(df: pd.DataFrame, rules: dict) -> pd.Series:
    """High-value transaction from/to PEP high-risk jurisdiction.
    country_code used as structured PEP proxy (no free text)."""
    cfg     = rules.get("pep_linked", {})
    hr_ctry = set(cfg.get("pep_high_risk_countries", ["IR", "KP", "VE", "BY", "RU"]))
    min_val = float(cfg.get("pep_min_value", 5000))
    in_pep  = df["country_code"].isin(hr_ctry) & (df["country_code"] != "")
    return in_pep & (df["value"] >= min_val)


def _rule_trade_based_ml(df: pd.DataFrame, rules: dict) -> pd.Series:
    """txn_type_code == TRD with value anomalous vs node TRD mean.
    Replaces old free-text description keyword matching."""
    cfg     = rules.get("trade_based_ml", {})
    var_pct = float(cfg.get("invoice_variance_pct", 0.30))
    is_trd  = df["txn_type_code"] == "TRD"
    if not is_trd.any():
        return pd.Series(False, index=df.index)
    node_mean = (
        df[is_trd].groupby("node_id")["value"].mean()
        .reset_index().rename(columns={"value": "_trd_mean"})
    )
    df2 = df.merge(node_mean, on="node_id", how="left")
    anomaly = (
        df2["_trd_mean"].notna() &
        (
            abs(df["value"] - df2["_trd_mean"])
            / df2["_trd_mean"].clip(lower=1) >= var_pct
        )
    )
    return is_trd & anomaly


def _rule_crypto_bridge(df: pd.DataFrame, rules: dict) -> pd.Series:
    """CRYP transaction type code -- cryptocurrency gateway transaction."""
    min_val = float(rules.get("crypto_bridge", {}).get("min_value", 500))
    return (df["txn_type_code"] == "CRYP") & (df["value"] >= min_val)


def _rule_loan_back(df: pd.DataFrame, rules: dict) -> pd.Series:
    """LN (credit) from counterparty X then LNR (debit) to same X -- loan-back layering."""
    cfg   = rules.get("loan_back", {})
    max_d = int(cfg.get("return_window_days", 90))
    min_v = float(cfg.get("min_value", 10000))
    if not (df["counterparty_id"] != "").any():
        return pd.Series(False, index=df.index)
    ln = df[
        (df["txn_type_code"] == "LN") & (df["counterparty_id"] != "") & (df["value"] >= min_v)
    ][["node_id", "counterparty_id", "date"]].rename(columns={"date": "ln_date"})
    lnr = df[
        (df["txn_type_code"] == "LNR") & (df["counterparty_id"] != "") & (df["value"] >= min_v)
    ][["node_id", "counterparty_id", "date"]].rename(columns={"date": "lnr_date"})
    if ln.empty or lnr.empty:
        return pd.Series(False, index=df.index)
    pairs = ln.merge(lnr, on=["node_id", "counterparty_id"], how="inner")
    pairs = pairs[
        (pairs["lnr_date"] > pairs["ln_date"]) &
        ((pairs["lnr_date"] - pairs["ln_date"]).dt.days <= max_d)
    ]
    if pairs.empty:
        return pd.Series(False, index=df.index)
    loan_nodes = set(pairs["node_id"])
    return df["node_id"].isin(loan_nodes) & df["txn_type_code"].isin(["LN", "LNR"])


def _rule_cash_intensive(df: pd.DataFrame, rules: dict) -> pd.Series:
    min_pct = float(rules.get("cash_intensive", {}).get("min_pct", 0.70))
    return df["_cash_pct"] >= min_pct


def _rule_round_amount(df: pd.DataFrame, rules: dict) -> pd.Series:
    min_pct = float(rules.get("round_amount", {}).get("min_pct", 0.60))
    return df["_round_pct"] >= min_pct


def _rule_account_takeover(df: pd.DataFrame, rules: dict) -> pd.Series:
    """10x spike in daily activity vs own baseline."""
    mult     = float(rules.get("account_takeover", {}).get("spike_multiplier", 10.0))
    baseline = df["_node_baseline_daily_avg"].fillna(1).clip(lower=0.5)
    return (df["_day_txn_count"] / baseline) >= mult


def _rule_layering_chain(df: pd.DataFrame, rules: dict) -> pd.Series:
    """5+ outbound debits (dr_cr==D) in a single day -- rapid fund forwarding."""
    cfg      = rules.get("layering_chain", {})
    min_txns = int(cfg.get("min_sequential_txns", 5))
    debits   = df[df["dr_cr"] == "D"]
    debit_day = (
        debits.groupby(["node_id", "date"]).size()
        .reset_index(name="_debit_day_count")
    )
    df2 = df.merge(debit_day, on=["node_id", "date"], how="left")
    df2["_debit_day_count"] = df2["_debit_day_count"].fillna(0).astype(int)
    return (df2["_debit_day_count"] >= min_txns) & (df["dr_cr"] == "D")


def _rule_edd_trigger(df: pd.DataFrame, rules: dict) -> pd.Series:
    """Enhanced Due Diligence trigger: high-risk country + value threshold.
    account_type is a node attribute absent from the temporal ledger;
    country_code is the structured proxy for EDD risk."""
    cfg     = rules.get("edd_triggers", {})
    hr_ctry = set(cfg.get("high_risk_countries", ["IR", "KP", "MM", "VE", "SY"]))
    min_val = float(cfg.get("min_value", 2000))
    in_hr   = df["country_code"].isin(hr_ctry) & (df["country_code"] != "")
    return in_hr & (df["value"] >= min_val)


def _rule_rapid_movement(df: pd.DataFrame, rules: dict) -> pd.Series:
    """Large inflow on a day followed by large outflow on the SAME day."""
    ctr       = float(rules.get("reporting_thresholds", {}).get("ctr_threshold", 10000))
    threshold = ctr * 0.3
    return (
        (df["_day_inflow"] >= threshold) &
        (df["_day_outflow"] >= threshold) &
        (df["_day_outflow"] / df["_day_inflow"].clip(lower=1) >= 0.50)
    )


# --------------------------------------------------------------------------
# SAR COMPOSITE -- runs AFTER all other masks
# --------------------------------------------------------------------------

def _rule_sar_composite(all_masks: dict[str, pd.Series], rules: dict) -> pd.Series:
    min_flags = int(rules.get("sar_composite", {}).get("min_flag_count", 3))
    flag_sum  = pd.Series(
        0, index=next(iter(all_masks.values())).index, dtype=int
    )
    for key, mask in all_masks.items():
        if key != "SAR_INDICATOR":
            flag_sum += mask.astype(int)
    return flag_sum >= min_flags


# --------------------------------------------------------------------------
# MAIN ENTRY POINT
# --------------------------------------------------------------------------

def classify_events(
    df: pd.DataFrame,
    rules_path: str | None = None,
) -> pd.DataFrame:
    """Classify each bank ledger row with an AML event type.

    Parameters
    ----------
    df : pd.DataFrame
        Ledger DataFrame -- schema:
        node_id | date | value | dr_cr | counterparty_id | currency |
        country_code | txn_type_code | channel_code
    rules_path : str or None
        Path to aml_rules.yaml.  None = auto-discover from project root.

    Returns
    -------
    pd.DataFrame
        df + ``event_type`` (str)  +  ``event_flags`` (pipe-separated str).
    """
    if df is None or df.empty:
        out = df.copy() if df is not None else pd.DataFrame()
        out["event_type"]  = "NORMAL"
        out["event_flags"] = ""
        return out

    logger.debug("AML classifier: %d rows", len(df))
    rules = load_rules(rules_path)

    # 1. Normalise schema
    out = _normalise(df)

    # 2. Pre-compute per-node aggregate features (single vectorized pass)
    out = _compute_node_features(out, rules)

    # 3. Run all individual rule masks
    mask_fns = {
        "STRUCTURING":          _rule_structuring,
        "HIGH_VELOCITY":        _rule_high_velocity,
        "BURST_ACTIVITY":       _rule_burst_activity,
        "DORMANT_REACTIVATION": _rule_dormant_reactivation,
        "LARGE_CASH_TXN":       _rule_large_cash,
        "THRESHOLD_AVOIDANCE":  _rule_threshold_avoidance,
        "OFFSHORE_TRANSFER":    _rule_offshore,
        "HIGH_RISK_CPTY":       _rule_high_risk_cpty,
        "SMURFING":             _rule_smurfing,
        "SPLIT_DEPOSIT":        _rule_split_deposit,
        "ROUND_TRIP":           _rule_round_trip,
        "RAPID_IN_OUT":         _rule_rapid_in_out,
        "CONCENTRATION_RISK":   _rule_concentration_risk,
        "MULE_INDICATOR":       _rule_mule,
        "CURRENCY_ANOMALY":     _rule_currency_anomaly,
        "MULTI_CURRENCY_LAYER": _rule_multi_currency_layering,
        "GEOGRAPHIC_ANOMALY":   _rule_geographic_anomaly,
        "UNUSUAL_HOURS":        _rule_unusual_hours,
        "PEP_LINKED":           _rule_pep_linked,
        "TRADE_BASED_ML":       _rule_trade_based_ml,
        "CRYPTO_BRIDGE":        _rule_crypto_bridge,
        "LOAN_BACK":            _rule_loan_back,
        "CASH_INTENSIVE":       _rule_cash_intensive,
        "ROUND_AMOUNT":         _rule_round_amount,
        "ACCOUNT_TAKEOVER":     _rule_account_takeover,
        "LAYERING_CHAIN":       _rule_layering_chain,
        "EDD_TRIGGER":          _rule_edd_trigger,
        "RAPID_MOVEMENT":       _rule_rapid_movement,
        "CIRCULAR_LAYERING":    _rule_concentration,
    }

    all_masks: dict[str, pd.Series] = {}
    for name, fn in mask_fns.items():
        try:
            all_masks[name] = fn(out, rules).reindex(out.index, fill_value=False)
        except Exception as exc:
            logger.debug("Rule %s skipped: %s", name, exc)
            all_masks[name] = pd.Series(False, index=out.index)

    # 4. SAR composite (depends on all other masks)
    try:
        all_masks["SAR_INDICATOR"] = _rule_sar_composite(all_masks, rules)
    except Exception:
        all_masks["SAR_INDICATOR"] = pd.Series(False, index=out.index)

    # 5. event_flags -- ALL fired rules per row (pipe-separated)
    flag_lists: list[str] = []
    for i in range(len(out)):
        flags = [
            name for name in EVENT_PRIORITY
            if all_masks.get(name, pd.Series(False)).iat[i]
        ]
        flag_lists.append("|".join(flags) if flags else "")
    out["event_flags"] = flag_lists

    # 6. event_type -- highest-priority rule (first match wins)
    out["event_type"] = "NORMAL"
    for name in reversed(EVENT_PRIORITY):
        if name == "NORMAL":
            continue
        mask = all_masks.get(name)
        if mask is not None:
            out.loc[mask, "event_type"] = name

    # 7. Drop internal working columns (_xxx)
    drop_cols = [c for c in out.columns if c.startswith("_")]
    out = out.drop(columns=drop_cols, errors="ignore")

    # 8. Log distribution
    counts = out["event_type"].value_counts().to_dict()
    logger.info(
        "AML classify: %d rows | %s",
        len(out),
        ", ".join(f"{k}={v}" for k, v in counts.items()),
    )
    return out


def describe_event(event_type: str) -> str:
    """Return plain-English description for an event_type label."""
    return EVENT_DESCRIPTIONS.get(event_type, f"AML pattern: {event_type}")
