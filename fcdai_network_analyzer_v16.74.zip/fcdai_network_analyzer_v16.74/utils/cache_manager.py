"""
FCDAI v12.4 - Cache Manager
==============================
AIR-GAPPED | Uses diskcache (already in requirements)
Caches analytics results with TTL. Auto-invalidates on new pipeline run.
v12.4: Renamed set() -> cache_set() to avoid shadowing Python built-in.
"""

import time
import hashlib
import json
from pathlib import Path
from typing import Any, Optional, Callable
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))

_cache = None
_cache_dir = None
_TTL = 300  # default 5 minutes
_enabled = True


def _get_cache():
    """Lazy-init diskcache singleton."""
    global _cache, _cache_dir, _TTL, _enabled
    if _cache is None:
        try:
            import diskcache
            from config import PATHS, _CFG

            cache_cfg = _CFG.get("cache", {})
            _enabled = cache_cfg.get("enabled", True)
            _TTL = cache_cfg.get("ttl_seconds", 300)
            max_mb = cache_cfg.get("max_size_mb", 512)
            _cache_dir = PATHS.CACHE
            _cache_dir.mkdir(parents=True, exist_ok=True)
            _cache = diskcache.Cache(
                str(_cache_dir),
                size_limit=max_mb * 1024 * 1024,
            )
        except Exception:
            _enabled = False
            _cache = {}  # fallback to in-memory dict
    return _cache


def _make_key(key: str) -> str:
    return hashlib.md5(key.encode("utf-8")).hexdigest()


def get(key: str) -> Optional[Any]:
    """Retrieve cached value. Returns None if missing or expired."""
    if not _enabled:
        return None
    try:
        cache = _get_cache()
        if isinstance(cache, dict):
            entry = cache.get(_make_key(key))
            if entry and time.time() < entry["expires"]:
                return entry["value"]
            return None
        return cache.get(_make_key(key))
    except Exception:
        return None


def cache_set(key: str, value: Any, ttl: int = None) -> bool:
    """Store value in cache with TTL. (Renamed from set() to avoid shadowing built-in.)"""
    if not _enabled:
        return False
    try:
        cache = _get_cache()
        expire = ttl or _TTL
        k = _make_key(key)
        if isinstance(cache, dict):
            # v16.8 L1: Prune expired entries when fallback dict grows large.
            # Prevents unbounded memory growth during long-running sessions.
            now = time.time()
            if len(cache) >= 100:
                expired_keys = [ck for ck, cv in list(cache.items()) if cv["expires"] < now]
                for ek in expired_keys:
                    cache.pop(ek, None)
            cache[k] = {"value": value, "expires": now + expire}
        else:
            cache.set(k, value, expire=expire)
        return True
    except Exception:
        return False


def invalidate(prefix: str = "") -> int:
    """Invalidate all cache entries (or those matching prefix)."""
    try:
        cache = _get_cache()
        if isinstance(cache, dict):
            count = len(cache)
            cache.clear()
            return count
        count = len(cache)
        cache.clear()
        return count
    except Exception:
        return 0


def cache_result(key: str, fn: Callable, ttl: int = None, force: bool = False) -> Any:
    """
    Get from cache or compute and store.
    Usage:
        result = cache_result("analytics_centrality", lambda: compute_centrality())
    """
    if not force:
        cached = get(key)
        if cached is not None:
            return cached
    result = fn()
    cache_set(key, result, ttl=ttl)
    return result


def get_stats() -> dict:
    """Return cache statistics."""
    try:
        cache = _get_cache()
        if isinstance(cache, dict):
            return {"entries": len(cache), "enabled": _enabled, "backend": "memory"}
        return {
            "entries": len(cache),
            "size_mb": round(cache.volume() / 1024 / 1024, 2),
            "enabled": _enabled,
            "backend": "diskcache",
            "directory": str(_cache_dir),
        }
    except Exception:
        return {"entries": 0, "enabled": False, "backend": "error"}
