"""
utils/presidio_pii.py — Airgap-safe PII detection wrapper (v16.7)
==================================================================
Wraps presidio-analyzer to use the locally installed en_core_web_sm model
instead of the default en_core_web_lg (which triggers a 400 MB download).

Key design rules:
  - Never triggers external downloads — fully offline, airgap-compliant
  - Falls back gracefully if spaCy / presidio not installed
  - All returned data is anonymised metadata (entity type + position) — NO raw PII
  - Not called anywhere in the main pipeline; available for manual OPSEC review

Usage:
    from utils.presidio_pii import scan_text_for_pii, anonymise_text

    results = scan_text_for_pii("John Smith transferred $50,000 to ACC_003")
    clean   = anonymise_text("John Smith transferred $50,000 to ACC_003")
"""

from __future__ import annotations

import sys
from typing import Dict, List, Optional

# ---------------------------------------------------------------------------
# Lazy import — presidio is optional (installed in ai311 / v16.6+ only)
# ---------------------------------------------------------------------------
_ANALYZER = None  # module-level singleton; created once on first call
_ANONYMIZER = None
_INIT_ATTEMPTED = False


def _get_analyzer():
    """Return the AnalyzerEngine singleton, creating it if needed.

    Configured to use en_core_web_sm (≈40 MB, already installed in ai311).
    Never downloads en_core_web_lg (400 MB).
    Returns None if presidio / spaCy is not available.
    """
    global _ANALYZER, _INIT_ATTEMPTED
    if _INIT_ATTEMPTED:
        return _ANALYZER
    _INIT_ATTEMPTED = True
    try:
        from presidio_analyzer import AnalyzerEngine
        from presidio_analyzer.nlp_engine import NlpEngineProvider

        # Force en_core_web_sm — overrides presidio default (en_core_web_lg)
        _nlp_config = {
            "nlp_engine_name": "spacy",
            "models": [{"lang_code": "en", "model_name": "en_core_web_sm"}],
        }
        provider = NlpEngineProvider(nlp_configuration=_nlp_config)
        nlp_engine = provider.create_engine()
        _ANALYZER = AnalyzerEngine(nlp_engine=nlp_engine, supported_languages=["en"])
    except Exception as exc:
        # Presidio or spaCy not installed / broken — degrade silently
        _ANALYZER = None
        print(f"[presidio_pii] Warning: PII detection unavailable — {exc}", file=sys.stderr)
    return _ANALYZER


def _get_anonymizer():
    """Return the anonymizer singleton (requires presidio-anonymizer, optional)."""
    global _ANONYMIZER
    if _ANONYMIZER is not None:
        return _ANONYMIZER
    try:
        from presidio_anonymizer import AnonymizerEngine

        _ANONYMIZER = AnonymizerEngine()
    except ImportError:
        _ANONYMIZER = None
    return _ANONYMIZER


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def scan_text_for_pii(text: str, language: str = "en") -> List[Dict]:
    """Scan free text for PII entities. Returns metadata only — no raw PII stored.

    Args:
        text:     Plain-text string to scan.
        language: ISO 639-1 language code (default 'en').

    Returns:
        List of dicts: [{"entity_type": str, "start": int, "end": int, "score": float}, ...]
        Empty list if presidio unavailable or text is empty.

    Design note (airgap/PII safety):
        Returned dicts contain ONLY entity_type + position + confidence score.
        RAW PII text is never stored, logged, or returned. Callers must NOT
        log the original `text` argument through the audit trail.
    """
    if not text or not text.strip():
        return []
    analyzer = _get_analyzer()
    if analyzer is None:
        return []
    try:
        results = analyzer.analyze(text=text, language=language)
        return [
            {
                "entity_type": r.entity_type,
                "start": r.start,
                "end": r.end,
                "score": round(r.score, 4),
            }
            for r in results
        ]
    except Exception:
        return []


def anonymise_text(text: str, language: str = "en", replacement: str = "<REDACTED>") -> str:
    """Replace all detected PII in text with a placeholder string.

    Args:
        text:        Original free-text string.
        language:    ISO 639-1 language code (default 'en').
        replacement: Placeholder to substitute PII spans (default '<REDACTED>').

    Returns:
        Anonymised string, or the original text if presidio is unavailable.

    Design note (airgap/PII safety):
        The original `text` is processed in-memory only and never persisted.
        Callers should ensure the return value (not the input) is logged.
    """
    if not text or not text.strip():
        return text
    analyzer = _get_analyzer()
    if analyzer is None:
        return text  # degrade gracefully — return original
    anonymizer = _get_anonymizer()
    try:
        results = analyzer.analyze(text=text, language=language)
        if not results:
            return text
        if anonymizer is not None:
            from presidio_anonymizer.entities import OperatorConfig

            anon_result = anonymizer.anonymize(
                text=text,
                analyzer_results=results,
                operators={"DEFAULT": OperatorConfig("replace", {"new_value": replacement})},
            )
            return anon_result.text
        else:
            # Manual replacement fallback (no presidio-anonymizer installed)
            chars = list(text)
            for r in sorted(results, key=lambda x: x.start, reverse=True):
                chars[r.start : r.end] = list(replacement)
            return "".join(chars)
    except Exception:
        return text


def pii_summary(text: str) -> Dict:
    """Return a summary dict of entity types found, suitable for audit logging.

    Args:
        text: Plain-text to scan.

    Returns:
        {"found": bool, "entity_types": [str, ...], "count": int}
        Caller-safe: never include the original text in the returned dict.
    """
    entities = scan_text_for_pii(text)
    types = list({e["entity_type"] for e in entities})
    return {"found": bool(entities), "entity_types": sorted(types), "count": len(entities)}
