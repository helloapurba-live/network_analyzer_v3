"""
tests/test_pipeline.py — Pipeline integration tests for FCDAI v16.1
=====================================================================
Tests the full 7-layer pipeline end-to-end using only node + edge tables.
Validates: output columns, tier coverage, role assignments, no crash.

AML head perspective:
  - P1/P2 accounts must exist after running on the synthetic ring graph.
  - ACC_001 (mule topology) and ACC_004 (sink topology) must NOT be PERIPHERAL.
  - No PII in output — node_ids are synthetic codes.
  - Pipeline must never raise an exception (graceful degradation everywhere).

Run with:
    cd fcdai_network_analyzer_v16.1
    C:/ProgramData/anaconda3/envs/ai311/python.exe -m pytest tests/test_pipeline.py -v
"""

from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd
import pytest

_ROOT = Path(__file__).parent.parent.resolve()
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))


# ---------------------------------------------------------------------------
# Required output columns (what the business dashboard depends on)
# ---------------------------------------------------------------------------

REQUIRED_COLUMNS = {
    "node_id",
    "risk_score",
    "risk_tier",
    "aml_role",
    "role_confidence",
    "sar_narrative",
    "evidence_summary",
}

# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestPipelineNodeEdgeOnly:
    """
    Pipeline with ONLY nodes + edges (the minimum viable input).
    All optional tables (transaction, customer, alert, etc.) absent.
    """

    @pytest.fixture(scope="class")
    def result(self, tmp_node_csv, tmp_edge_csv):
        """Run full pipeline and return scored DataFrame."""
        from engine import FcdaiEngine

        eng = FcdaiEngine()
        df = eng.run(
            nodes_path=tmp_node_csv,
            edges_path=tmp_edge_csv,
        )
        assert df is not None, "Pipeline returned None"
        assert len(df) > 0, "Pipeline returned empty DataFrame"
        return df

    # ── Shape & columns ───────────────────────────────────────────────────

    def test_has_required_columns(self, result):
        """All business-facing columns must be present."""
        missing = REQUIRED_COLUMNS - set(result.columns)
        assert not missing, f"Missing columns: {missing}"

    def test_all_nodes_present(self, result):
        """Every node submitted must appear in output."""
        assert len(result) == 10, f"Expected 10 nodes, got {len(result)}"

    def test_risk_score_range(self, result):
        """Risk score must be 0–100 (no out-of-range values)."""
        assert result["risk_score"].between(0, 100).all(), "risk_score values outside [0, 100]"

    def test_tier_values(self, result):
        """Tier must be exactly P1, P2, P3, or P4."""
        valid = {"P1", "P2", "P3", "P4"}
        actual = set(result["risk_tier"].unique())
        assert actual.issubset(valid), f"Unexpected tier values: {actual - valid}"

    def test_role_confidence_range(self, result):
        """Role confidence must be 0–1."""
        assert result["role_confidence"].between(0.0, 1.0).all(), "role_confidence outside [0, 1]"

    def test_sar_narrative_not_empty(self, result):
        """Every node must have a SAR narrative string."""
        assert result["sar_narrative"].notna().all(), "NaN in sar_narrative"
        assert (
            result["sar_narrative"].str.len() > 5
        ).all(), "sar_narrative too short — likely empty stub"

    # ── Business logic ────────────────────────────────────────────────────

    def test_p1_or_p2_accounts_exist(self, result):
        """
        The synthetic graph has mule + sink topology.
        We MUST get at least 1 high-risk account — if we don't,
        the scoring layer has a bug.
        """
        high_risk = result[result["risk_tier"].isin(["P1", "P2"])]
        assert len(high_risk) >= 1, "No P1/P2 accounts found — scoring or tier assignment broken"

    def test_mule_node_not_peripheral(self, result):
        """ACC_001 has 94% passthrough ratio — must not be classed PERIPHERAL."""
        row = result[result["node_id"] == "ACC_001"]
        if not row.empty:
            assert (
                row["aml_role"].iloc[0] != "PERIPHERAL"
            ), "ACC_001 (mule topology) incorrectly classified as PERIPHERAL"

    def test_sink_node_not_peripheral(self, result):
        """ACC_004 has 6 in-edges, 0 out-edges — must not be PERIPHERAL."""
        row = result[result["node_id"] == "ACC_004"]
        if not row.empty:
            assert (
                row["aml_role"].iloc[0] != "PERIPHERAL"
            ), "ACC_004 (sink topology) incorrectly classified as PERIPHERAL"

    def test_originator_not_peripheral(self, result):
        """ACC_003 has 5 outbound edges, 0 inbound — originator signal."""
        row = result[result["node_id"] == "ACC_003"]
        if not row.empty:
            role = row["aml_role"].iloc[0]
            assert (
                "ORIGINATOR" in role or "BROKER" in role or row["risk_tier"].iloc[0] in ("P1", "P2")
            ), "ACC_003 (5 out-edges) expected to be non-peripheral"

    # ── No crash on repeated runs ─────────────────────────────────────────

    def test_pipeline_idempotent(self, tmp_node_csv, tmp_edge_csv):
        """Running twice must not crash (DB, cache, idempotency checks)."""
        from engine import FcdaiEngine

        eng = FcdaiEngine()
        try:
            eng.run(nodes_path=tmp_node_csv, edges_path=tmp_edge_csv)
            eng.run(nodes_path=tmp_node_csv, edges_path=tmp_edge_csv)
        except Exception as e:
            pytest.fail(f"Second pipeline run crashed: {e}")


class TestPipelineGracefulDegradation:
    """
    Pipeline must complete even with minimal / edge-case inputs.
    """

    def test_single_edge_graph(self, tmp_path):
        """Two nodes, one edge — must not crash."""
        nodes = pd.DataFrame({"node_id": ["A", "B"]})
        edges = pd.DataFrame({"source": ["A"], "target": ["B"], "amount": [100.0]})
        n_path = tmp_path / "n.csv"
        nodes.to_csv(n_path, index=False)
        e_path = tmp_path / "e.csv"
        edges.to_csv(e_path, index=False)
        from engine import FcdaiEngine

        try:
            df = FcdaiEngine().run(nodes_path=str(n_path), edges_path=str(e_path))
            assert df is not None
        except Exception as exc:
            pytest.fail(f"Single-edge pipeline crashed: {exc}")

    def test_no_amount_column(self, tmp_path):
        """Edge table without amount — pipeline must still run."""
        nodes = pd.DataFrame({"node_id": ["X", "Y", "Z"]})
        edges = pd.DataFrame({"source": ["X", "X"], "target": ["Y", "Z"]})
        n_path = tmp_path / "n.csv"
        nodes.to_csv(n_path, index=False)
        e_path = tmp_path / "e.csv"
        edges.to_csv(e_path, index=False)
        from engine import FcdaiEngine

        try:
            df = FcdaiEngine().run(nodes_path=str(n_path), edges_path=str(e_path))
            assert df is not None
        except Exception as exc:
            pytest.fail(f"No-amount pipeline crashed: {exc}")
