"""
tests/test_l6_scoring.py — Unit tests for ScoringLayer (Rule-10)
=================================================================
v16.5 additions:
  • _normalise_mat: all 4 methods + edge cases
  • _assign_tiers_vectorized: percentile mode, absolute mode
  • _BINARY_FLAG_WEIGHTS sum validation (Rule-12 parity)
  • Score range assertion [0, 100]
  • n=1 node edge case
  • Nodes-only data mode (no optional tables) — pipeline must not crash

Design rules (mirror conftest.py):
  - Zero PII: all IDs are synthetic codes
  - Fully offline / air-gapped — no external calls
  - pytest-compatible, no pytest plugins required beyond pytest itself
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest

# Ensure package root on path
_ROOT = Path(__file__).parent.parent.resolve()
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from layers.l6_scoring import _normalise_mat, ScoringLayer, _BINARY_FLAG_WEIGHTS


# =============================================================================
# _normalise_mat
# =============================================================================


class TestNormaliseMat:
    """Unit tests for the module-level normalisation helper."""

    def _col(self, values) -> np.ndarray:
        """Wrap a 1-D list into the (n,1) shape expected by _normalise_mat."""
        return np.array(values, dtype=float).reshape(-1, 1)

    # ------------------------------------------------------------------
    # rank
    # ------------------------------------------------------------------
    def test_rank_output_in_unit_interval(self):
        arr = self._col([10, 30, 20, 50, 40])
        out = _normalise_mat(arr, "rank")
        assert out.min() >= 0.0 and out.max() <= 1.0

    def test_rank_monotone(self):
        arr = self._col([1, 2, 3, 4, 5])
        out = _normalise_mat(arr, "rank").ravel()
        assert list(out) == sorted(out)

    def test_rank_identical_values_midpoint(self):
        """All-same values → all ranks equal → output should be in [0,1]."""
        arr = self._col([7, 7, 7, 7])
        out = _normalise_mat(arr, "rank")
        assert out.min() >= 0.0 and out.max() <= 1.0

    # ------------------------------------------------------------------
    # minmax
    # ------------------------------------------------------------------
    def test_minmax_endpoints(self):
        arr = self._col([0, 5, 10])
        out = _normalise_mat(arr, "minmax").ravel()
        assert pytest.approx(out[0], abs=1e-6) == 0.0
        assert pytest.approx(out[-1], abs=1e-6) == 1.0

    def test_minmax_output_in_unit_interval(self):
        arr = self._col([100, -50, 0, 75, 25])
        out = _normalise_mat(arr, "minmax")
        assert out.min() >= -1e-9 and out.max() <= 1.0 + 1e-9

    # ------------------------------------------------------------------
    # zscore
    # ------------------------------------------------------------------
    def test_zscore_output_in_unit_interval(self):
        rng = np.random.default_rng(42)
        arr = rng.normal(50, 10, size=(50, 1))
        out = _normalise_mat(arr, "zscore")
        assert out.min() >= 0.0 and out.max() <= 1.0

    def test_zscore_constant_column_no_crash(self):
        arr = self._col([5.0] * 10)
        out = _normalise_mat(arr, "zscore")
        assert out.shape == (10, 1)
        assert out.min() >= 0.0 and out.max() <= 1.0

    # ------------------------------------------------------------------
    # robust
    # ------------------------------------------------------------------
    def test_robust_output_in_unit_interval(self):
        arr = self._col([1, 2, 100, 3, 4, 5, 6])  # outlier at 100
        out = _normalise_mat(arr, "robust")
        assert out.min() >= 0.0 and out.max() <= 1.0

    # ------------------------------------------------------------------
    # unknown method → rank fallback
    # ------------------------------------------------------------------
    def test_unknown_method_falls_back_to_rank(self):
        arr = self._col([1, 3, 2])
        out = _normalise_mat(arr, "bogus_method")
        assert out.min() >= 0.0 and out.max() <= 1.0

    # ------------------------------------------------------------------
    # edge case: n == 1
    # ------------------------------------------------------------------
    def test_single_row_returns_half(self):
        arr = self._col([42.0])
        for method in ("rank", "minmax", "zscore", "robust"):
            out = _normalise_mat(arr, method)
            assert pytest.approx(out[0, 0], abs=1e-6) == 0.5, f"n=1 failed for method={method}"


# =============================================================================
# _assign_tiers_vectorized
# =============================================================================


class TestAssignTiersVectorized:
    """Tests for ScoringLayer._assign_tiers_vectorized()."""

    @pytest.fixture
    def scorer(self):
        return ScoringLayer()

    # ------------------------------------------------------------------
    # percentile mode
    # ------------------------------------------------------------------
    def test_percentile_top_node_gets_p1_high_score(self, scorer):
        """Highest-score node on a large-enough array should be P1 if above min gate."""
        # 100 nodes, top node score=95 (well above min_p1=20 default)
        scores = np.linspace(0, 95, 100)
        tiers = scorer._assign_tiers_vectorized(scores)
        assert "P1" in tiers, "Expected at least one P1 from percentile mode"

    def test_percentile_low_population_all_p4(self, scorer):
        """n < 4: percentile mode not active, falls through to config-based absolute."""
        scores = np.array([50.0, 60.0, 70.0])
        tiers = scorer._assign_tiers_vectorized(scores)
        # No P1 from percentile — result depends on absolute config but must not crash
        assert len(tiers) == 3

    def test_percentile_zero_scores_no_crash(self, scorer):
        """All-zero scores: no P1/P2/P3 because they are below min score gates."""
        scores = np.zeros(50)
        tiers = scorer._assign_tiers_vectorized(scores)
        assert len(tiers) == 50
        # All should be P4 since scores don't meet minimum thresholds
        assert all(t == "P4" for t in tiers)

    # ------------------------------------------------------------------
    # absolute mode (tier_override)
    # ------------------------------------------------------------------
    def test_absolute_override_splits_correctly(self, scorer):
        scores = np.array([80.0, 60.0, 40.0, 20.0])
        override = {"mode": "absolute", "p1": 75.0, "p2": 55.0, "p3": 35.0}
        tiers = scorer._assign_tiers_vectorized(scores, tier_override=override)
        assert tiers[0] == "P1"  # 80 >= 75
        assert tiers[1] == "P2"  # 60 in [55,75)
        assert tiers[2] == "P3"  # 40 in [35,55)
        assert tiers[3] == "P4"  # 20 < 35

    def test_absolute_boundary_values(self, scorer):
        """Boundary-equal scores land in the correct tier."""
        override = {"mode": "absolute", "p1": 70.0, "p2": 50.0, "p3": 30.0}
        scores = np.array([70.0, 50.0, 30.0, 29.9])
        tiers = scorer._assign_tiers_vectorized(scores, tier_override=override)
        assert tiers[0] == "P1"
        assert tiers[1] == "P2"
        assert tiers[2] == "P3"
        assert tiers[3] == "P4"

    def test_empty_scores_no_crash(self, scorer):
        tiers = scorer._assign_tiers_vectorized(np.array([]))
        assert len(tiers) == 0


# =============================================================================
# Rule-12 parity: _BINARY_FLAG_WEIGHTS sum
# =============================================================================


class TestBinaryFlagWeights:
    """Ensure _BINARY_FLAG_WEIGHTS (config-driven) stays normalised to ~1.0."""

    def test_weights_sum_close_to_one(self):
        total = sum(_BINARY_FLAG_WEIGHTS.values())
        assert abs(total - 1.0) < 0.02, (
            f"_BINARY_FLAG_WEIGHTS sum={total:.6f} — "
            "expected ~1.0; update config.yaml binary_flag_weights."
        )

    def test_all_weights_positive(self):
        for k, v in _BINARY_FLAG_WEIGHTS.items():
            assert v > 0, f"Weight for '{k}' is non-positive: {v}"

    def test_weight_keys_not_empty(self):
        assert len(_BINARY_FLAG_WEIGHTS) > 0, "_BINARY_FLAG_WEIGHTS must not be empty"


# =============================================================================
# _validate_scoring_weights (engine helper — Rule-12)
# =============================================================================


class TestValidateScoringWeights:
    """Unit tests for the module-level engine helper (loaded without full pipeline)."""

    @pytest.fixture(autouse=True)
    def _import_helper(self):
        from engine import _validate_scoring_weights

        self.fn = _validate_scoring_weights

    def test_none_passthrough(self):
        assert self.fn(None) is None

    def test_empty_dict_passthrough(self):
        assert self.fn({}) == {}

    def test_already_normalised_unchanged(self):
        w = {"a": 0.5, "b": 0.3, "c": 0.2}
        result = self.fn(w)
        assert pytest.approx(sum(result.values()), abs=1e-6) == 1.0
        # Values should be identical (within float noise)
        for k in w:
            assert pytest.approx(result[k], abs=1e-6) == w[k]

    def test_unnormalised_gets_normalised(self):
        w = {"a": 2.0, "b": 2.0, "c": 1.0}  # sum = 5.0
        result = self.fn(w)
        assert pytest.approx(sum(result.values()), abs=1e-6) == 1.0
        assert pytest.approx(result["a"], abs=1e-6) == 0.4
        assert pytest.approx(result["c"], abs=1e-6) == 0.2

    def test_zero_sum_returned_as_is(self):
        """Zero-sum weights cannot be normalized — must not crash."""
        w = {"a": 0.0, "b": 0.0}
        result = self.fn(w)  # should not raise
        assert result is not None


# =============================================================================
# Nodes-only smoke test (Rule-1 parity: no crash with minimal data)
# =============================================================================


class TestScoringLayerMinimalData:
    """ScoringLayer.score() must not crash when called with only node features."""

    def _make_node_df(self, n: int = 10) -> "pd.DataFrame":
        import pandas as pd

        ids = [f"ACC_{i:03d}" for i in range(n)]
        rng = np.random.default_rng(0)
        return pd.DataFrame(
            {
                "node_id": ids,
                "passthrough_ratio": rng.uniform(0, 1, n),
                "betweenness_centrality": rng.uniform(0, 1, n),
                "total_inflow": rng.uniform(0, 1e5, n),
                "total_outflow": rng.uniform(0, 1e5, n),
                "degree_centrality": rng.uniform(0, 1, n),
            }
        )

    def test_score_returns_dataframe(self):
        import pandas as pd

        scorer = ScoringLayer()
        df = self._make_node_df(20)
        result = scorer.score(df)
        assert isinstance(result, pd.DataFrame)

    def test_score_has_risk_score_column(self):
        scorer = ScoringLayer()
        df = self._make_node_df(20)
        result = scorer.score(df)
        assert "risk_score" in result.columns, "Expected 'risk_score' column"

    def test_score_range(self):
        """risk_score must lie within [0, 100]."""
        scorer = ScoringLayer()
        df = self._make_node_df(20)
        result = scorer.score(df)
        assert result["risk_score"].between(0, 100).all(), "risk_score out of [0,100] range"

    def test_score_n1_no_crash(self):
        """Single-node input: must return a result without raising."""
        scorer = ScoringLayer()
        df = self._make_node_df(1)
        result = scorer.score(df)
        assert len(result) == 1
