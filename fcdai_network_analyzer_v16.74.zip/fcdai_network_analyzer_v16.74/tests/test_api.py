"""
tests/test_api.py — FastAPI endpoint tests for FCDAI v16.1
============================================================
Tests the REST API surface without requiring a running server.
Uses httpx.AsyncClient with ASGITransport (in-process testing).

Endpoints under test:
    GET  /health                        — liveness check
    GET  /api/v1/results/latest         — read scored results
    GET  /api/v1/results/tiers          — tier distribution
    GET  /api/v1/results/roles          — role distribution
    POST /api/v1/pipeline/run           — trigger a pipeline run
    GET  /api/v1/pipeline/status        — run state

PII policy tested:
    - Responses must NOT contain fields named email, phone, name, address, ssn, dob

Run with:
    cd fcdai_network_analyzer_v16.1
    C:/ProgramData/anaconda3/envs/ai311/python.exe -m pytest tests/test_api.py -v

Requires: pip install httpx
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

_ROOT = Path(__file__).parent.parent.resolve()
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

# ── Soft-skip if FastAPI / httpx not installed (avoids hard failure on
# environments that haven't yet run pip install -e .[dev]) ─────────────────
try:
    from fastapi.testclient import TestClient
    from api.main import app

    _API_AVAILABLE = True
except ImportError:
    _API_AVAILABLE = False

pytestmark = pytest.mark.skipif(
    not _API_AVAILABLE,
    reason="FastAPI or api.main not importable — run: pip install -e .[dev]",
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(scope="module")
def client():
    """Synchronous ASGI test client — no running server needed."""
    with TestClient(app) as c:
        yield c


# ---------------------------------------------------------------------------
# Health / root
# ---------------------------------------------------------------------------


class TestHealth:
    def test_root_responds(self, client):
        r = client.get("/")
        assert r.status_code in (200, 307, 404), f"Root returned unexpected status {r.status_code}"

    def test_health_endpoint(self, client):
        """GET /health must return 200 with status=ok for monitoring."""
        r = client.get("/health")
        assert r.status_code == 200, f"Health check failed: {r.status_code}"
        body = r.json()
        assert body.get("status") in ("ok", "healthy"), f"Health status unexpected: {body}"

    def test_api_docs_accessible(self, client):
        """Swagger docs must load — dev discoverability."""
        r = client.get("/docs")
        assert r.status_code == 200, "Swagger UI /docs not accessible"


# ---------------------------------------------------------------------------
# Pipeline endpoints
# ---------------------------------------------------------------------------


class TestPipelineEndpoints:
    def test_pipeline_status_idle(self, client):
        """
        GET /api/v1/pipeline/status before any run must return HTTP 200
        with status field.
        """
        r = client.get("/api/v1/pipeline/status")
        assert r.status_code == 200, f"Status returned {r.status_code}"
        body = r.json()
        assert "status" in body, f"Missing 'status' key: {body}"

    def test_pipeline_run_post_accepts_empty_body(self, client):
        """
        POST /api/v1/pipeline/run with empty JSON must return 200 or 202
        (pipeline picks up default data paths from config).
        """
        r = client.post("/api/v1/pipeline/run", json={})
        assert r.status_code in (200, 202, 422), f"Pipeline run unexpected status: {r.status_code}"

    def test_pipeline_runs_history_exists(self, client):
        """GET /api/v1/pipeline/runs must return a list."""
        r = client.get("/api/v1/pipeline/runs")
        if r.status_code == 200:
            body = r.json()
            assert isinstance(body, (list, dict)), "Runs history not list/dict"


# ---------------------------------------------------------------------------
# Results endpoints
# ---------------------------------------------------------------------------


class TestResultsEndpoints:
    def test_latest_results_endpoint_exists(self, client):
        """GET /api/v1/results/latest must return 200 or 404 (no data yet)."""
        r = client.get("/api/v1/results/latest")
        assert r.status_code in (
            200,
            404,
        ), f"Unexpected status {r.status_code} from /results/latest"

    def test_tier_distribution_endpoint_exists(self, client):
        r = client.get("/api/v1/results/tiers")
        assert r.status_code in (200, 404)

    def test_role_distribution_endpoint_exists(self, client):
        r = client.get("/api/v1/results/roles")
        assert r.status_code in (200, 404)

    def test_sar_endpoint_exists(self, client):
        """SAR narrative endpoint — must exist (compliance requirement)."""
        r = client.get("/api/v1/results/sar")
        assert r.status_code in (200, 404)

    def test_escalation_endpoint_exists(self, client):
        """Escalation endpoint — accounts that moved to higher tier."""
        r = client.get("/api/v1/results/escalations")
        assert r.status_code in (200, 404)

    def test_results_no_pii_fields(self, client):
        """
        PII policy: response JSON must NOT contain fields called
        email, phone, full_name, address, ssn, date_of_birth, dob.
        This is a BANK-GRADE control — must pass on every release.
        """
        r = client.get("/api/v1/results/latest")
        if r.status_code == 200:
            text = r.text.lower()
            pii_fields = [
                '"email"',
                '"phone"',
                '"full_name"',
                '"address"',
                '"ssn"',
                '"date_of_birth"',
                '"dob"',
            ]
            for field in pii_fields:
                assert field not in text, f"PII LEAK: field {field} found in API response"

    def test_filtered_nodes_endpoint(self, client):
        """GET /api/v1/results/nodes?tier=P1 must work without error."""
        r = client.get("/api/v1/results/nodes", params={"tier": "P1"})
        assert r.status_code in (200, 404)

    def test_node_pagination(self, client):
        """GET /api/v1/results/latest?limit=5&offset=0 must return ≤5 records."""
        r = client.get("/api/v1/results/latest", params={"limit": 5, "offset": 0})
        if r.status_code == 200:
            body = r.json()
            # Could be wrapped in a pagination object or a plain list
            items = body.get("items", body) if isinstance(body, dict) else body
            if isinstance(items, list):
                assert len(items) <= 5, f"Pagination limit=5 exceeded: got {len(items)} records"
