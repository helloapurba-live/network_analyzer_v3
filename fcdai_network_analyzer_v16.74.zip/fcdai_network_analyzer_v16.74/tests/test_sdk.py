"""
tests/test_sdk.py — Python library (fcdai SDK) tests for FCDAI v16.1
======================================================================
Validates the public `fcdai` package API:
    from fcdai import FcdaiPipeline
    results = pipeline.run(nodes="...", edges="...")

Tests the programmatic interface a data science team would use when
integrating FCDAI into a larger AML workflow.

Run with:
    cd fcdai_network_analyzer_v16.1
    C:/ProgramData/anaconda3/envs/ai311/python.exe -m pytest tests/test_sdk.py -v
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

_ROOT = Path(__file__).parent.parent.resolve()
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))


# ---------------------------------------------------------------------------
# Import tests — must work as an installed package
# ---------------------------------------------------------------------------


class TestImport:
    def test_fcdai_importable(self):
        """Top-level fcdai package must be importable."""
        import fcdai  # noqa: F401

    def test_version_string(self):
        """__version__ must be a non-empty string."""
        import fcdai

        assert isinstance(fcdai.__version__, str)
        assert len(fcdai.__version__) > 0

    def test_version_is_16(self):
        """We are in v16 — version must start with 16."""
        import fcdai

        assert fcdai.__version__.startswith("16"), f"Expected 16.x.x, got {fcdai.__version__}"

    def test_pipeline_class_importable(self):
        """FcdaiPipeline must be importable from fcdai directly."""
        from fcdai import FcdaiPipeline  # noqa: F401

    def test_result_class_importable(self):
        """FcdaiResult must be importable from fcdai directly."""
        from fcdai import FcdaiResult  # noqa: F401

    def test_sdk_module_importable(self):
        """fcdai.sdk must be importable."""
        from fcdai import sdk  # noqa: F401

    def test_cli_module_importable(self):
        """fcdai.cli must be importable."""
        from fcdai import cli  # noqa: F401


# ---------------------------------------------------------------------------
# FcdaiPipeline API surface
# ---------------------------------------------------------------------------


class TestFcdaiPipelineInterface:
    """
    Tests the PUBLIC SDK interface — what a downstream developer calls.
    Does NOT test internal layers (those are tested in test_pipeline.py).
    """

    @pytest.fixture
    def pipeline(self):
        from fcdai import FcdaiPipeline

        return FcdaiPipeline()

    def test_pipeline_instantiable(self, pipeline):
        """FcdaiPipeline() must construct without arguments."""
        assert pipeline is not None

    def test_pipeline_has_run_method(self, pipeline):
        """pipeline.run() must exist and be callable."""
        assert callable(getattr(pipeline, "run", None)), "FcdaiPipeline.run() not found"

    def test_pipeline_has_score_method(self, pipeline):
        """pipeline.score() must exist for re-scoring without re-running L0–L4."""
        assert callable(getattr(pipeline, "score", None)), "FcdaiPipeline.score() not found"

    def test_pipeline_has_report_method(self, pipeline):
        """pipeline.report() must exist for exporting results."""
        assert callable(getattr(pipeline, "report", None)), "FcdaiPipeline.report() not found"

    def test_pipeline_has_status_property(self, pipeline):
        """pipeline.status must describe the current state."""
        status = getattr(pipeline, "status", None)
        assert status is not None, "FcdaiPipeline.status not found"

    def test_pipeline_run_node_edge_only(self, tmp_path):
        """
        Full SDK run with node + edge CSV — must return a DataFrame
        with node_id and risk_tier columns.
        """
        import pandas as pd
        from fcdai import FcdaiPipeline

        nodes = pd.DataFrame({"node_id": [f"N{i}" for i in range(6)]})
        edges = pd.DataFrame(
            {
                "source": ["N0", "N0", "N1", "N2", "N3", "N4"],
                "target": ["N1", "N2", "N3", "N4", "N5", "N0"],
                "amount": [1000, 2000, 1500, 3000, 500, 800],
            }
        )
        n_csv = tmp_path / "nodes.csv"
        nodes.to_csv(n_csv, index=False)
        e_csv = tmp_path / "edges.csv"
        edges.to_csv(e_csv, index=False)

        pipeline = FcdaiPipeline()
        result = pipeline.run(nodes=str(n_csv), edges=str(e_csv))

        assert result is not None, "run() returned None"
        assert len(result) > 0, "run() returned empty result"
        assert "node_id" in result.columns, "node_id missing from result"
        assert "risk_tier" in result.columns, "risk_tier missing from result"

    def test_pipeline_result_has_sar_narrative(self, tmp_path):
        """SAR narrative column must exist in v16.1 output — business value."""
        import pandas as pd
        from fcdai import FcdaiPipeline

        nodes = pd.DataFrame({"node_id": ["A", "B", "C", "D", "E"]})
        edges = pd.DataFrame(
            {
                "source": ["A", "A", "B", "C"],
                "target": ["B", "C", "D", "E"],
                "amount": [5000, 3000, 4000, 2000],
            }
        )
        n_csv = tmp_path / "n.csv"
        nodes.to_csv(n_csv, index=False)
        e_csv = tmp_path / "e.csv"
        edges.to_csv(e_csv, index=False)

        pipeline = FcdaiPipeline()
        result = pipeline.run(nodes=str(n_csv), edges=str(e_csv))

        assert "sar_narrative" in result.columns, "sar_narrative column missing from SDK result"


# ---------------------------------------------------------------------------
# FcdaiResult wrapper
# ---------------------------------------------------------------------------


class TestFcdaiResult:
    def test_result_instantiable(self, tmp_path):
        """FcdaiResult can wrap a DataFrame."""
        import pandas as pd
        from fcdai import FcdaiResult

        df = pd.DataFrame(
            {
                "node_id": ["A", "B"],
                "risk_score": [85.0, 30.0],
                "risk_tier": ["P1", "P3"],
                "aml_role": ["MULE", "PERIPHERAL"],
            }
        )
        r = FcdaiResult(df)
        assert r is not None

    def test_result_filterable(self, tmp_path):
        """FcdaiResult.high_risk() should return P1+P2 only."""
        import pandas as pd
        from fcdai import FcdaiResult

        df = pd.DataFrame(
            {
                "node_id": ["A", "B", "C", "D"],
                "risk_score": [90.0, 60.0, 30.0, 10.0],
                "risk_tier": ["P1", "P2", "P3", "P4"],
                "aml_role": ["MULE", "BROKER", "PERIPHERAL", "PERIPHERAL"],
            }
        )
        r = FcdaiResult(df)
        if hasattr(r, "high_risk"):
            hr = r.high_risk()
            assert set(hr["risk_tier"].unique()).issubset({"P1", "P2"})
