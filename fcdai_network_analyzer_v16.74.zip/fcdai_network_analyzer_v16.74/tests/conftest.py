"""
tests/conftest.py — Shared pytest fixtures for FCDAI v16.1
============================================================
Provides minimal synthetic node + edge DataFrames that trigger every
pipeline layer without requiring real bank data.

Design rules:
  - Zero PII: all node_ids are synthetic codes (ACC_001 … ACC_010)
  - No external files required: everything generated in-memory
  - Covers: mule (high passthrough), broker (high betweenness),
            originator (high out-degree), sink (high in-degree),
            peripheral (low signals all round)
  - Works fully offline on Windows CPU
"""

from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd
import numpy as np
import pytest

# Ensure package root is on path so imports resolve
_ROOT = Path(__file__).parent.parent.resolve()
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))


# ---------------------------------------------------------------------------
# Synthetic minimal dataset
# ---------------------------------------------------------------------------

_NODE_IDS = [
    "ACC_001",  # MULE candidate: high passthrough
    "ACC_002",  # BROKER: structural bridge
    "ACC_003",  # ORIGINATOR: many outflows
    "ACC_004",  # SINK: many inflows, few outflows
    "ACC_005",  # PERIPHERAL
    "ACC_006",  # PERIPHERAL
    "ACC_007",  # Supporting node
    "ACC_008",  # Supporting node
    "ACC_009",  # Supporting node
    "ACC_010",  # Supporting node
]

_EDGES = [
    # Cluster A → ACC_002 (broker) → Cluster B
    ("ACC_003", "ACC_002", 5000.0),
    ("ACC_003", "ACC_005", 2000.0),
    ("ACC_003", "ACC_006", 1500.0),
    ("ACC_003", "ACC_007", 3000.0),
    ("ACC_003", "ACC_008", 2500.0),
    # Mule path: receives from ACC_003, forwards to ACC_004
    ("ACC_002", "ACC_001", 8000.0),
    ("ACC_001", "ACC_004", 7500.0),  # passthrough ratio ~94%
    # Sink cluster: many inflows to ACC_004
    ("ACC_005", "ACC_004", 1200.0),
    ("ACC_006", "ACC_004", 900.0),
    ("ACC_007", "ACC_004", 1100.0),
    ("ACC_008", "ACC_004", 800.0),
    ("ACC_009", "ACC_004", 950.0),
    # Peripheral activity
    ("ACC_009", "ACC_010", 300.0),
    ("ACC_010", "ACC_009", 250.0),
]


@pytest.fixture(scope="session")
def sample_nodes() -> pd.DataFrame:
    """Minimal node table — only node_id required (all else optional)."""
    return pd.DataFrame({"node_id": _NODE_IDS})


@pytest.fixture(scope="session")
def sample_edges() -> pd.DataFrame:
    """Minimal edge table — source, target, amount."""
    return pd.DataFrame(
        _EDGES,
        columns=["source", "target", "amount"],
    )


@pytest.fixture(scope="session")
def sample_transactions() -> pd.DataFrame:
    """Optional flat transaction table (mirrors edge list for l2 aggregation)."""
    rows = []
    for i, (src, tgt, amt) in enumerate(_EDGES):
        rows.append(
            {
                "account_id": src,
                "txn_id": f"TXN_{i:04d}",
                "amount": amt,
                "direction": "OUT",
                "counterparty_id": tgt,
                "txn_date": "2026-01-15",
            }
        )
    return pd.DataFrame(rows)


@pytest.fixture(scope="session")
def tmp_node_csv(tmp_path_factory, sample_nodes) -> str:
    """Write a temp node CSV and return its path (string)."""
    p = tmp_path_factory.mktemp("data") / "nodes.csv"
    sample_nodes.to_csv(p, index=False)
    return str(p)


@pytest.fixture(scope="session")
def tmp_edge_csv(tmp_path_factory, sample_edges) -> str:
    """Write a temp edge CSV and return its path (string)."""
    p = tmp_path_factory.mktemp("data") / "edges.csv"
    sample_edges.to_csv(p, index=False)
    return str(p)
