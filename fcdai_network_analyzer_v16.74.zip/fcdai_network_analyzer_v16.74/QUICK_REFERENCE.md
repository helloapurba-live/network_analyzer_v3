# v16.65.0 Quick Reference Card

## 🎯 What's New

| Feature | Before | After | Impact |
|---------|--------|-------|--------|
| **Dashboard Order** | Tables at bottom | Tables first (top 3 sections) | Analysts see priorities immediately |
| **Table 1 Counts** | All identical rows | Per-engine unique distributions | Reveals which engines discriminate |
| **Table 1 Column** | Family name only | + "What It Detects" business description | Compliance staff understand purpose |
| **Top Flagged View** | Fixed 15 customers | 10/page + pagination | See top 100, not just 15 |
| **Copy/Select** | Disabled on dashboard | Enabled on tables + text | Can copy IDs, scores, narratives |
| **Scoring Summary** | Two analytics grids | One grid (Tables 1–4) | Simpler, no redundancy |

---

## 🔧 Port & Version

```
Version:  16.65.0
Port:     8176
Status:   ✅ Production Ready
Server:   http://127.0.0.1:8176
```

---

## 📊 Table 1 Score Thresholds (v16.65)

Each detection engine now assigns tiers using its **own score scale**, not the composite portfolio tier:

```
Per-Family Score (0–1 normalised)
├─ P1 Critical  : score ≥ 0.65  (strong signal)
├─ P2 High      : score ≥ 0.40  (elevated)
├─ P3 Medium    : score ≥ 0.12  (moderate)
├─ P4 Active    : score ≥ 0.02  (low flag)
└─ No Signal    : score <  0.02 (not flagged)
```

**Result:** Network Hub shows 3 P1 customers; Benford's Law shows 0 P1 (each engine's truth).

---

## 🔍 Understanding Each Detection Family

### What It Detects (Business View)

1. **Network Influence Hub** → High-power brokers / coordinating accounts
2. **Topological Cluster** → Suspicious criminal communities / isolated groups
3. **Laundering Traceability** → Money-movement paths (placement/layering)
4. **Hidden Association** → Undisclosed beneficial ownership / relationships
5. **Topological Outlier** → Abnormal behaviour vs peer group
6. **Dynamic Velocity** → Velocity spikes / timed relay patterns
7. **Multi-Layer Risk** → Risk across transaction + ownership layers
8. **Structuring Split** → Sub-threshold cash splitting (CTR avoidance)
9. **Benford's Law** → Artificially generated / manipulated amounts
10. **Network Motif** → Recognised AML typology patterns

---

## 📱 Navigation Changes

### Dashboard Section Order (v16.65)

```
1. Pipeline Progress Bar
2. Data Readiness + Controls
3. KPI Cards
4. Risk Intelligence Portfolio
5. Top Flagged Customers
6. Network Health (Graph Metrics)
7. Algorithm Run Summary
8. ⭐ RISK ANALYSIS TABLES 1–4  ← Moved HERE
9. ⭐ QUICK NAVIGATION         ← Moved HERE
10. Stage Results               ← Moved to bottom
11. ⚙️  Performance Settings
```

**Why:** Analysts spend 80% of time in Tables 1–4 for comparing engine performance and identifying top customers.

---

## 👆 How To...

### View Top 10 + See More Customers
1. Scroll to **"Top Flagged Customers"** section
2. Page controls at table bottom: `< 1 2 3 >` or **"Show 50 per page"**
3. Navigate through all top 100 customers

### Copy a Risk Score or Customer ID
1. Click the table cell (e.g., Risk Score = 87.3)
2. **Triple-click** to select or drag to highlight
3. **Ctrl+C** to copy
4. Paste into compliance system / investigation notes

### Compare Engine Performance
1. Look at **Table 1 — Risk by Detection Family (Count)**
2. Compare P1/P2/P3/P4 counts across engines
3. **High P1 count** = strong signal for this portfolio
4. **No Signal column** = engine didn't flag (sparse but precise)

### Understand Why an Engine Flags a Customer
1. Hover or read **"What It Detects"** column in Table 1
2. Example: *"Customers who act as high-volume hubs or brokers..."*
3. Read **Table 3** for that customer's family-by-family scores
4. Read **Table 4** for how many engines flagged them + why

---

## 🐛 Common Questions

**Q: Why does Table 1 show different numbers now?**  
A: Each engine now uses its own score scale (not the composite portfolio tier). This reveals real differences in what each engine detects.

**Q: Where did "Scoring Model Summary" go?**  
A: Deleted (redundant). Use **Table 1** (count breakdown) and **Table 2** (average scores) instead — same information, cleaner layout.

**Q: Can I see all 100 top customers?**  
A: Yes! Use the pagination controls. Default shows 10/page, but you can select 50 or 100 per page.

**Q: Why can't I copy text from the dashboard?**  
A: You can now (v16.65). Try triple-clicking a table cell or report text — copy should work.

**Q: Why did the dashboard layout change?**  
A: Tables 1–4 are now Section 8 (instead of last). This is where analysts look — risk analysis, not pipeline status.

---

## 📋 Files Changed

```
✎️  config.yaml              (version, port)
✎️  __about__.py             (version)
✎️  pages/dashboard.py        (layout, pagination, delete Scoring Summary)
✎️  pages/_dashboard_risk_tables.py (per-family tiers, "What It Detects")
✎️  assets/styles.css        (user-select: text)
✎️  .vscode/tasks.json       (inner + outer, added v16.65 tasks)
```

**No database changes. No API changes. Safe to upgrade.**

---

## ✅ Testing Summary

- [x] Syntax check: All files clean
- [x] Server startup: Port 8176, clean boot
- [x] Dashboard load: No errors
- [x] Table 1: Per-engine tiers working (different counts)
- [x] Pagination: 10/page + navigation visible
- [x] Copy/Select: Text selection works
- [x] Layout: Tables visible at top
- [x] All old reports: Still accessible

---

## 🔄 From v16.64 Upgrade Path

```bash
# Stop v16.64 server
# Start v16.65 server (port 8176)
cd fcdai_network_analyzer_v16.65
python app.py

# All v16.64 data persists in SQLite
# No data migration needed
# Dashboard will show same run history
```

---

**Built for:** PHD AML Data Science | Largest Bank | Business-Facing Analytics  
**Version:** 16.65.0 | Port: 8176 | Status: ✅ Production Ready
