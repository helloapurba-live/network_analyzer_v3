"""
fcdai.sdk — Programmatic SDK for FCDAI Network Analyzer
========================================================
Provides FcdaiPipeline class for use in Python scripts, notebooks, and integrations.

Usage:
    from fcdai import FcdaiPipeline
    import pandas as pd

    pipeline = FcdaiPipeline()
    results  = pipeline.run(nodes="accounts.csv", edges="transactions.csv")

    # Inspect results
    critical = results[results["risk_tier"] == "P1"]
    print(critical[["node_id", "risk_score", "aml_role", "sar_narrative"]])

    # Export
    results.to_csv("flagged_accounts.csv", index=False)

Air-gapped: no external calls made. All processing is local.
"""

from __future__ import annotations

import sys
import time
import json
import io
from pathlib import Path
from typing import Union, Optional, Dict, Any

import pandas as pd

# Ensure package root on path (also done in __init__ but safe to repeat)
_PKG_ROOT = Path(__file__).parent.parent.resolve()
if str(_PKG_ROOT) not in sys.path:
    sys.path.insert(0, str(_PKG_ROOT))


# ---------------------------------------------------------------------------
# FcdaiResult — pandas DataFrame with AML-specific convenience methods
# ---------------------------------------------------------------------------
class FcdaiResult(pd.DataFrame):
    """
    Scored results from the FCDAI pipeline.
    Inherits all pandas DataFrame methods plus AML-specific helpers.

    Columns always present after a successful run:
        node_id          Unique account identifier
        risk_score       0–100 risk score (100 = most suspicious)
        risk_tier        P1 / P2 / P3 / P4
        aml_role         MULE / BROKER / ORIGINATOR / SINK / PERIPHERAL / MIXED
        role_confidence  0.0–1.0 confidence in the assigned role
        sar_narrative    Plain-English SAR opening sentence
        tier_change      STABLE / ESCALATED (Px→Py) / IMPROVED (Px→Py)
        tier_escalated   1 if escalated vs prior run, 0 otherwise
    """

    @property
    def _constructor(self):
        return FcdaiResult

    # ── Business-facing accessors ────────────────────────────────────────────

    def critical(self) -> "FcdaiResult":
        """Return P1 accounts (Immediate Action required)."""
        return self[self["risk_tier"] == "P1"].copy()

    def high_risk(self) -> "FcdaiResult":
        """Return P2 accounts (Investigate within 24h)."""
        return self[self["risk_tier"] == "P2"].copy()

    def escalated(self) -> "FcdaiResult":
        """Return accounts that escalated to a higher risk tier since last run."""
        if "tier_escalated" in self.columns:
            return self[self["tier_escalated"] == 1].copy()
        return self.iloc[0:0].copy()

    def sar_ready(self) -> "FcdaiResult":
        """Return P1+P2 accounts with SAR narratives — ready for SAR filing."""
        flagged = self[self["risk_tier"].isin(["P1", "P2"])].copy()
        cols = [
            "node_id",
            "risk_score",
            "risk_tier",
            "aml_role",
            "role_confidence",
            "sar_narrative",
            "tier_change",
        ]
        available = [c for c in cols if c in flagged.columns]
        return flagged[available]

    def by_role(self, role: str) -> "FcdaiResult":
        """
        Filter by AML role.
        role: 'MULE' | 'BROKER' | 'ORIGINATOR' | 'SINK' | 'PERIPHERAL'
        """
        if "aml_role" not in self.columns:
            return self.iloc[0:0].copy()
        return self[self["aml_role"].str.contains(role.upper(), na=False)].copy()

    def tier_summary(self) -> pd.DataFrame:
        """Return P1/P2/P3/P4 count and percentage breakdown."""
        if "risk_tier" not in self.columns:
            return pd.DataFrame()
        counts = self["risk_tier"].value_counts().reindex(["P1", "P2", "P3", "P4"], fill_value=0)
        total = counts.sum()
        pct = (counts / max(total, 1) * 100).round(1)
        labels = {"P1": "Critical", "P2": "High", "P3": "Medium", "P4": "Low"}
        return pd.DataFrame(
            {
                "tier": counts.index,
                "label": [labels.get(t, "") for t in counts.index],
                "count": counts.values,
                "percentage": pct.values,
            }
        )

    def role_summary(self) -> pd.DataFrame:
        """Return AML role distribution."""
        if "aml_role" not in self.columns:
            return pd.DataFrame()
        return (
            self["aml_role"]
            .value_counts()
            .reset_index()
            .rename(columns={"index": "role", "aml_role": "count"})
        )

    def to_sar_text(self, max_accounts: int = 50) -> str:
        """
        Return a plain-text SAR synopsis for the top flagged accounts.
        max_accounts: cap to avoid very long output.
        """
        flagged = self.sar_ready().head(max_accounts)
        if len(flagged) == 0:
            return "No accounts flagged for SAR filing in the current analysis."
        lines = [f"SAR Synopsis — {len(flagged)} account(s) flagged\n{'='*60}"]
        for _, row in flagged.iterrows():
            conf_pct = int(float(row.get("role_confidence", 0)) * 100)
            lines.append(
                f"\nAccount: {row['node_id']} | Tier: {row['risk_tier']} | "
                f"Score: {row.get('risk_score', '?')} | Role: {row.get('aml_role', '?')} "
                f"({conf_pct}% confidence)"
            )
            if row.get("sar_narrative"):
                lines.append(f"  SAR: {row['sar_narrative']}")
            if row.get("tier_change") and row["tier_change"] != "STABLE":
                lines.append(f"  Alert: {row['tier_change']} since last run")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# FcdaiPipeline — main SDK class
# ---------------------------------------------------------------------------
class FcdaiPipeline:
    """
    SDK wrapper around the FCDAI pipeline engine.

    Supports:
    - File paths (CSV / Excel)          → pipeline.run(nodes="file.csv", edges="txn.csv")
    - pandas DataFrames                 → pipeline.run(nodes=df_nodes, edges=df_edges)
    - Dict of DataFrames (all tables)  → pipeline.run(sources={"node": df, "edge": df2})

    Example:
        pipeline = FcdaiPipeline()
        results  = pipeline.run(nodes="accounts.csv", edges="transactions.csv")
        print(results.critical())
        print(results.to_sar_text())
    """

    def __init__(self, config_path: Optional[str] = None):
        """
        Initialise the pipeline.
        config_path: optional path to a custom config.yaml.
                     Defaults to the bundled config.yaml in the package root.
        """
        self._root = _PKG_ROOT
        self._engine = None  # lazy-load on first run()
        self._config_path = config_path

    def _get_engine(self):
        """Lazy-load FCDAIPipeline singleton (reuses the single engine instance)."""
        if self._engine is None:
            from engine import get_pipeline  # type: ignore

            self._engine = get_pipeline()  # singleton — safe to call multiple times
        return self._engine

    # ── Data loading helpers ─────────────────────────────────────────────────

    @staticmethod
    def _load_table(source: Union[str, Path, pd.DataFrame]) -> pd.DataFrame:
        """Load a table from file path or accept a DataFrame directly."""
        if isinstance(source, pd.DataFrame):
            return source.copy()
        path = Path(source)
        if not path.exists():
            raise FileNotFoundError(f"Input file not found: {path}")
        ext = path.suffix.lower()
        if ext in (".xlsx", ".xls"):
            return pd.read_excel(path)
        if ext == ".parquet":
            return pd.read_parquet(path)
        # Default: CSV with comma or semicolon detection
        try:
            return pd.read_csv(path)
        except Exception:
            return pd.read_csv(path, sep=";")

    # ── Main run method ──────────────────────────────────────────────────────

    def run(
        self,
        nodes: Union[str, Path, pd.DataFrame, None] = None,
        edges: Union[str, Path, pd.DataFrame, None] = None,
        sources: Optional[Dict[str, Any]] = None,
        max_nodes: int = 5000,
        parallel: bool = True,
    ) -> FcdaiResult:
        """
        Run the full AML pipeline.

        Parameters
        ----------
        nodes     : Path to node/account CSV, or pandas DataFrame.
        edges     : Path to edge/transaction CSV, or pandas DataFrame.
        sources   : dict of {"node": df, "edge": df, ...} for multi-table input.
                    Overrides nodes/edges if provided.
        max_nodes : Maximum nodes to analyse (performance guard). Default 5000.
        parallel  : Use parallel family execution. Default True.

        Returns
        -------
        FcdaiResult (pandas DataFrame subclass) with scored results.
        """
        engine = self._get_engine()

        # Build sources dict
        if sources is None:
            sources = {}
            if nodes is not None:
                sources["node"] = self._load_table(nodes)
            if edges is not None:
                sources["edge"] = self._load_table(edges)

        if not sources:
            raise ValueError(
                "Provide at least: nodes= and edges= (file paths or DataFrames), "
                "or sources={} dict."
            )

        # Run pipeline
        t0 = time.time()
        pipeline_result = engine.run(
            sources=sources,
            max_customers=max_nodes,
            parallel=parallel,
        )
        elapsed = round(time.time() - t0, 1)

        # Extract scored DataFrame
        df = engine.scored_df
        if df is None or len(df) == 0:
            raise RuntimeError(
                "Pipeline completed but produced no scored results. "
                "Check that your node/edge tables have valid data."
            )

        result = FcdaiResult(df.copy())
        result.attrs["run_duration_sec"] = elapsed
        result.attrs["pipeline_version"] = "16.56.0"
        return result

    # ── Quick accessors against last run ────────────────────────────────────

    def get_last_results(self) -> Optional[FcdaiResult]:
        """Return results from the last pipeline run (from SQLite, no re-run)."""
        try:
            from database import get_db  # type: ignore

            db = get_db()
            data = db.load_latest_run()
            if data and data.get("scored_df") is not None:
                return FcdaiResult(data["scored_df"].copy())
        except Exception:
            pass
        return None

    def status(self) -> Dict[str, Any]:
        """
        Return a plain-dict summary of the last completed pipeline run.
        Safe to call even if no run has been performed yet.
        """
        try:
            engine = self._get_engine()
            meta = engine.last_run_meta or {}
            scored = engine.scored_df
            if scored is None:
                loaded = engine.load_last_run()
                scored = engine.scored_df if loaded else None

            tier_counts = {}
            role_counts = {}
            if scored is not None and len(scored) > 0:
                if "risk_tier" in scored.columns:
                    tier_counts = scored["risk_tier"].value_counts().to_dict()
                if "aml_role" in scored.columns:
                    role_counts = scored["aml_role"].value_counts().to_dict()

            return {
                "version": "16.56.0",
                "accounts_scored": len(scored) if scored is not None else 0,
                "tier_counts": tier_counts,
                "role_counts": role_counts,
                "run_meta": meta,
            }
        except Exception as exc:
            return {"version": "16.56.0", "error": str(exc)}

    def export(
        self,
        format: str = "csv",
        output_path: Optional[str] = None,
        tier_filter: Optional[list] = None,
    ) -> str:
        """
        Export last results to CSV or JSON.

        Parameters
        ----------
        format      : 'csv' | 'json'. Default 'csv'.
        output_path : File path to write. If None, returns content as string.
        tier_filter : e.g. ['P1','P2'] to export only those tiers.

        Returns
        -------
        str: file path written, or raw content if output_path is None.
        """
        result = self.get_last_results()
        if result is None:
            raise RuntimeError("No results available. Run the pipeline first.")

        if tier_filter:
            result = result[result["risk_tier"].isin(tier_filter)]

        if format.lower() == "json":
            content = result.to_json(orient="records", indent=2, default_handler=str)
            ext = "json"
        else:
            buf = io.StringIO()
            result.to_csv(buf, index=False)
            content = buf.getvalue()
            ext = "csv"

        if output_path:
            Path(output_path).write_text(content, encoding="utf-8")
            return output_path

        return content

    # ── Convenience aliases for test + downstream API parity ──────────────

    def score(self) -> Optional["FcdaiResult"]:
        """
        Re-run the scoring layer on the already-loaded graph (no re-ingestion).
        Returns updated FcdaiResult, or None if no graph is loaded yet.

        Use `run()` for first-time analysis. Use `score()` when you want to
        re-score after config changes (e.g. adjusted weights) without uploading
        new data.
        """
        try:
            engine = self._get_engine()
            if engine.G is None:
                loaded = engine.load_last_run()
                if not loaded or engine.G is None:
                    return None
            analytics_df = (
                engine.scored_df
                if engine.scored_df is not None
                else engine.analytics.results if hasattr(engine, "analytics") else None
            )
            if analytics_df is None:
                return None
            from layers.l6_scoring import ScoringLayer

            scorer = ScoringLayer()
            scored = scorer.score(analytics_df, engine.G)
            engine.scored_df = scored
            return FcdaiResult(scored.copy())
        except Exception:
            return None

    def report(
        self,
        format: str = "csv",
        output_path: Optional[str] = None,
        tier_filter: Optional[list] = None,
    ) -> str:
        """
        Alias for export() — generate a report from the last pipeline run.

        Parameters
        ----------
        format      : 'csv' | 'json'. Default 'csv'.
        output_path : File path to write. If None, returns content as string.
        tier_filter : e.g. ['P1','P2'] to export only those tiers.

        Returns
        -------
        str: file path written, or raw CSV/JSON content if output_path is None.
        """
        return self.export(
            format=format,
            output_path=output_path,
            tier_filter=tier_filter,
        )
