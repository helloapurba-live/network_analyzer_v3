"""
fcdai — FCDAI Network Analyzer Python Library
==============================================
Unsupervised AML graph analytics for financial crime detection.

Air-gapped | Zero data leakage | Bank PII protected | Offline-only

Quickstart:
    from fcdai import FcdaiPipeline
    pipeline = FcdaiPipeline()
    results = pipeline.run(nodes="accounts.csv", edges="transactions.csv")
    print(results[results["risk_tier"] == "P1"])

CLI:
    fcdai run --nodes accounts.csv --edges transactions.csv
    fcdai report --format csv --output flagged.csv
    fcdai serve --port 8100
    fcdai api --port 8101
    fcdai status
"""

from __future__ import annotations

__version__ = "16.74.0"
__author__ = "FCDAI AML Data Science Team"
__all__ = ["FcdaiPipeline", "FcdaiResult"]

# Ensure the package root (parent of this file) is findable for engine imports.
# Works whether installed via `pip install -e .` or run directly.
import sys
from pathlib import Path as _Path

_PKG_ROOT = _Path(__file__).parent.parent.resolve()
if str(_PKG_ROOT) not in sys.path:
    sys.path.insert(0, str(_PKG_ROOT))

from fcdai.sdk import FcdaiPipeline, FcdaiResult  # noqa: E402
