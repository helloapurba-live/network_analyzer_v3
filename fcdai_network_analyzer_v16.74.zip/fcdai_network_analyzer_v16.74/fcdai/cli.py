"""
fcdai.cli — Command-Line Interface for FCDAI Network Analyzer
==============================================================
Entry point installed as `fcdai` CLI by pyproject.toml.

Commands:
    fcdai run     --nodes accounts.csv --edges transactions.csv
    fcdai score
    fcdai report  --format csv|json|html --output flagged.csv --tiers P1,P2
    fcdai serve   --port 8100
    fcdai api     --port 8101
    fcdai status

All commands are air-gapped (no external calls).
"""

from __future__ import annotations

import sys
import json
import time
from pathlib import Path

# Ensure package root on path
_PKG_ROOT = Path(__file__).parent.parent.resolve()
if str(_PKG_ROOT) not in sys.path:
    sys.path.insert(0, str(_PKG_ROOT))

import click


# ---------------------------------------------------------------------------
# CLI group
# ---------------------------------------------------------------------------
@click.group()
@click.version_option(version="16.56.0", prog_name="fcdai")
def main():
    """
    \b
    FCDAI Network Analyzer — AML Graph Analytics
    ═══════════════════════════════════════════════
    Unsupervised financial crime detection using graph network analysis.
    Air-gapped | Zero PII leakage | Bank-grade

    Use --help on any command for details.
    """


# ---------------------------------------------------------------------------
# fcdai run
# ---------------------------------------------------------------------------
@main.command("run")
@click.option("--nodes", "-n", required=True, help="Path to node/account CSV file.")
@click.option("--edges", "-e", required=True, help="Path to edge/transaction CSV file.")
@click.option("--max-nodes", "-m", default=5000, show_default=True, help="Max nodes to analyse.")
@click.option("--output", "-o", default=None, help="Optional: export results to this CSV path.")
@click.option("--tiers", "-t", default=None, help="Comma-separated tiers to export, e.g. P1,P2.")
@click.option("--no-parallel", is_flag=True, help="Disable parallel family execution.")
def run_cmd(nodes, edges, max_nodes, output, tiers, no_parallel):
    """
    Run the full AML pipeline on node + edge tables.

    \b
    Examples:
        fcdai run --nodes accounts.csv --edges transactions.csv
        fcdai run -n accounts.csv -e transactions.csv --output flagged.csv --tiers P1,P2
    """
    click.echo(f"[FCDAI] Starting pipeline  nodes={nodes}  edges={edges}")
    click.echo(f"[FCDAI] Max nodes: {max_nodes} | Parallel: {not no_parallel}")

    try:
        from fcdai.sdk import FcdaiPipeline

        pipeline = FcdaiPipeline()
        t0 = time.time()
        results = pipeline.run(
            nodes=nodes,
            edges=edges,
            max_nodes=max_nodes,
            parallel=not no_parallel,
        )
        elapsed = round(time.time() - t0, 1)

        # Print tier summary
        click.echo(f"\n[FCDAI] Pipeline complete in {elapsed}s — {len(results)} accounts scored")
        click.echo("")
        summary = results.tier_summary()
        for _, row in summary.iterrows():
            bar = "█" * min(int(row["percentage"] / 2), 40)
            click.echo(
                f"  {row['tier']} {row['label']:8s}  {row['count']:5d}  "
                f"({row['percentage']:5.1f}%)  {bar}"
            )

        # Show top P1 accounts
        critical = results.critical()
        if len(critical) > 0:
            click.echo(f"\n[FCDAI] Top P1 accounts (showing up to 5):")
            top = critical.sort_values("risk_score", ascending=False).head(5)
            for _, row in top.iterrows():
                conf = int(float(row.get("role_confidence", 0)) * 100)
                click.echo(
                    f"  {str(row['node_id']):>20s}  score={row.get('risk_score','?'):5}  "
                    f"role={row.get('aml_role','?'):12s}  confidence={conf}%"
                )

        # Export if requested
        if output:
            tier_list = [t.strip() for t in tiers.split(",")] if tiers else None
            pipeline.export(format="csv", output_path=output, tier_filter=tier_list)
            click.echo(f"\n[FCDAI] Results exported to: {output}")

    except FileNotFoundError as exc:
        click.echo(f"[ERROR] File not found: {exc}", err=True)
        sys.exit(1)
    except Exception as exc:
        click.echo(f"[ERROR] Pipeline failed: {exc}", err=True)
        sys.exit(1)


# ---------------------------------------------------------------------------
# fcdai score  (re-score from last loaded data, no new data ingestion)
# ---------------------------------------------------------------------------
@main.command("score")
def score_cmd():
    """
    Re-run scoring on already-loaded data (no new data upload needed).
    Useful for testing weight adjustments without re-ingesting.
    """
    click.echo("[FCDAI] Re-scoring from last loaded graph data...")
    try:
        from fcdai.sdk import FcdaiPipeline

        pipeline = FcdaiPipeline()
        engine = pipeline._get_engine()
        if engine.G is None:
            loaded = engine.load_last_run()
            if not loaded or engine.G is None:
                click.echo("[ERROR] No graph data available. Run `fcdai run` first.", err=True)
                sys.exit(1)
        scored = engine.scoring.score(engine.analytics.results, engine.G)
        click.echo(f"[FCDAI] Re-scored {len(scored)} accounts.")
        if "risk_tier" in scored.columns:
            summary = scored["risk_tier"].value_counts()
            click.echo(f"[FCDAI] Tier breakdown: {summary.to_dict()}")
    except Exception as exc:
        click.echo(f"[ERROR] Score failed: {exc}", err=True)
        sys.exit(1)


# ---------------------------------------------------------------------------
# fcdai report
# ---------------------------------------------------------------------------
@main.command("report")
@click.option(
    "--format",
    "-f",
    default="csv",
    type=click.Choice(["csv", "json", "html"]),
    show_default=True,
    help="Output format.",
)
@click.option("--output", "-o", default=None, help="Output file path (stdout if omitted).")
@click.option("--tiers", "-t", default=None, help="Comma-separated tiers, e.g. P1,P2.")
@click.option("--sar-only", is_flag=True, help="Output SAR narrative text format.")
def report_cmd(format, output, tiers, sar_only):
    """
    Generate a report from the last pipeline run.

    \b
    Examples:
        fcdai report --format csv --output flagged.csv
        fcdai report --format json --tiers P1,P2
        fcdai report --sar-only --output sar_draft.txt
    """
    try:
        from fcdai.sdk import FcdaiPipeline, FcdaiResult

        pipeline = FcdaiPipeline()
        results = pipeline.get_last_results()
        if results is None:
            click.echo("[ERROR] No results available. Run `fcdai run` first.", err=True)
            sys.exit(1)

        tier_list = [t.strip() for t in tiers.split(",")] if tiers else None

        if sar_only:
            content = results.to_sar_text(max_accounts=200)
            if output:
                Path(output).write_text(content, encoding="utf-8")
                click.echo(f"[FCDAI] SAR text written to {output}")
            else:
                click.echo(content)
            return

        if format == "html":
            # Simple business-readable HTML table
            filtered = results
            if tier_list:
                filtered = results[results["risk_tier"].isin(tier_list)]
            cols = [
                c
                for c in [
                    "node_id",
                    "risk_score",
                    "risk_tier",
                    "aml_role",
                    "role_confidence",
                    "sar_narrative",
                    "tier_change",
                ]
                if c in filtered.columns
            ]
            html = filtered[cols].to_html(index=False, border=1, justify="left", na_rep="")
            header = (
                "<html><head><style>"
                "body{font-family:Arial,sans-serif;font-size:13px;padding:20px}"
                "table{border-collapse:collapse;width:100%}"
                "th{background:#1a2744;color:white;padding:8px}"
                "td{padding:6px;border:1px solid #ddd}"
                "tr:nth-child(even){background:#f5f5f5}"
                "</style></head><body>"
                "<h2>FCDAI AML Report — Flagged Accounts</h2>"
            )
            content = header + html + "</body></html>"
            if output:
                Path(output).write_text(content, encoding="utf-8")
                click.echo(f"[FCDAI] HTML report written to {output}")
            else:
                click.echo(content)
            return

        content = pipeline.export(format=format, output_path=output, tier_filter=tier_list)
        if output:
            click.echo(f"[FCDAI] Report written to {output}")
        else:
            click.echo(content)

    except Exception as exc:
        click.echo(f"[ERROR] Report failed: {exc}", err=True)
        sys.exit(1)


# ---------------------------------------------------------------------------
# fcdai status
# ---------------------------------------------------------------------------
@main.command("status")
@click.option("--json-out", is_flag=True, help="Output as JSON.")
def status_cmd(json_out):
    """Show summary of the last completed pipeline run."""
    try:
        from fcdai.sdk import FcdaiPipeline

        pipeline = FcdaiPipeline()
        info = pipeline.status()

        if json_out:
            click.echo(json.dumps(info, indent=2, default=str))
            return

        click.echo(f"\n[FCDAI] v{info.get('version','?')} — Last Run Status")
        click.echo(f"  Accounts scored : {info.get('accounts_scored', 0)}")

        tiers = info.get("tier_counts", {})
        if tiers:
            click.echo("  Tier breakdown  :")
            for t in ["P1", "P2", "P3", "P4"]:
                count = tiers.get(t, 0)
                label = {"P1": "Critical", "P2": "High", "P3": "Medium", "P4": "Low"}.get(t, "")
                click.echo(f"    {t} {label:8s} : {count}")

        roles = info.get("role_counts", {})
        if roles:
            click.echo("  Role breakdown  :")
            for role, count in sorted(roles.items(), key=lambda x: -x[1]):
                click.echo(f"    {role:15s} : {count}")

        meta = info.get("run_meta", {})
        if meta.get("duration_sec"):
            click.echo(f"  Run duration    : {meta['duration_sec']}s")

    except Exception as exc:
        click.echo(f"[ERROR] Status check failed: {exc}", err=True)
        sys.exit(1)


# ---------------------------------------------------------------------------
# fcdai serve  (start Dash UI)
# ---------------------------------------------------------------------------
@main.command("serve")
@click.option("--port", "-p", default=8163, show_default=True, help="Port for the Dash UI.")
@click.option(
    "--host",
    default="127.0.0.1",
    show_default=True,
    help="Host to bind (127.0.0.1 = local only, air-gapped).",
)
def serve_cmd(port, host):
    """
    Start the FCDAI Dashboard (Dash UI).

    \b
    Default: http://127.0.0.1:8100
    The server binds to localhost only by default (air-gapped).
    """
    click.echo(f"[FCDAI] Starting Dashboard on {host}:{port}")
    click.echo(f"[FCDAI] Open browser: http://{host}:{port}")
    click.echo(f"[FCDAI] Press Ctrl+C to stop.\n")
    try:
        import app as _app  # type: ignore  # noqa: F401

        # app.py uses config.yaml port but we override here
        import config as _cfg

        _cfg.APP.port = port
        _cfg.APP.host = host
        _app.app.run(host=host, port=port, debug=False)
    except KeyboardInterrupt:
        click.echo("\n[FCDAI] Dashboard stopped.")
    except Exception as exc:
        click.echo(f"[ERROR] Could not start Dash: {exc}", err=True)
        sys.exit(1)


# ---------------------------------------------------------------------------
# fcdai api  (start FastAPI server)
# ---------------------------------------------------------------------------
@main.command("api")
@click.option("--port", "-p", default=8164, show_default=True, help="Port for the FastAPI server.")
@click.option(
    "--host",
    default="127.0.0.1",
    show_default=True,
    help="Host to bind (127.0.0.1 = local only, air-gapped).",
)
@click.option("--reload", is_flag=True, help="Enable auto-reload (development mode only).")
def api_cmd(port, host, reload):
    """
    Start the FCDAI REST API (FastAPI + uvicorn).

    \b
    Default: http://127.0.0.1:8101
    Interactive docs: http://127.0.0.1:8101/docs
    The server binds to localhost only by default (air-gapped).
    """
    click.echo(f"[FCDAI] Starting REST API on {host}:{port}")
    click.echo(f"[FCDAI] Interactive docs: http://{host}:{port}/docs")
    click.echo(f"[FCDAI] Press Ctrl+C to stop.\n")
    try:
        import uvicorn

        uvicorn.run(
            "api.main:app",
            host=host,
            port=port,
            reload=reload,
            app_dir=str(_PKG_ROOT),
            log_level="info",
        )
    except KeyboardInterrupt:
        click.echo("\n[FCDAI] API server stopped.")
    except ImportError:
        click.echo("[ERROR] uvicorn not installed. Run: pip install uvicorn", err=True)
        sys.exit(1)
    except Exception as exc:
        click.echo(f"[ERROR] Could not start API: {exc}", err=True)
        sys.exit(1)
