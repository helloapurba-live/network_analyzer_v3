# v16.73 4-Layer Fingerprint System — Developer Quick Reference

## At a Glance

```
┌────────────────────────────────────────────────────────────┐
│ When user clicks "Run Pipeline":                           │
│                                                            │
│ 1. Compute SHA-256 of: DATA + WEIGHTS + CONFIG + VERSION  │
│ 2. Compare with last run's SHA-256                        │
│ 3. IF MATCH: Return 100% progress, load from DB instantly │
│ 4. IF DIFFER: Show diff badge, run pipeline normally      │
└────────────────────────────────────────────────────────────┘
```

---

## The 4 Layers Explained

### Layer 1: DATA (Full Content)
```python
# ALL rows, ALL cells, order-independent
def _hash_df(df: pd.DataFrame) -> str:
    # Sort cols alphabetically, rows lexicographically
    df_sorted = df.reindex(sorted(df.columns), axis=1).sort_values(...)
    return hashlib.sha256(df_sorted.to_csv().encode()).hexdigest()
```
**Trigger:** Any cell value changes = L1 hash changes = fresh run ✅

---

### Layer 2: WEIGHTS (Scoring Parameters)
```python
weights = {
    "centrality": 0.15,
    "community": 0.10,
    "pathflow": 0.10,
    "link_prediction": 0.10,
    "anomaly": 0.15,
    "temporal": 0.10,
    "multi_layer": 0.10,
    "structuring": 0.10,
    "benfords": 0.05,
    "motifs": 0.05,
}
# Set all to 6 decimals, sort by key, hash JSON
L2 = SHA256(json.dumps({k: round(v, 6) for k,v in sorted(weights.items())}))
```
**Trigger:** Any weight changes = L2 hash changes = fresh run ✅

---

### Layer 3: CONFIG (Pipeline Run Params)
```python
run_params = {
    "max_customers": 500,
    "norm_method": "rank",              # or "z-score"
    "tier_mode": "percentile",          # or "absolute"
    "tier_p1": 1.0,                     # top 1%
    "tier_p2": 5.0,                     # top 5%
    "tier_p3": 15.0,                    # top 15%
    "parallel": True,                   # parallelization on/off
    "progressive": True,                # progressive UI on/off
    "sample_size": None,                # or integer if sampling enabled
}
# Sort by key, hash JSON
L3 = SHA256(json.dumps(run_params, sort_keys=True))
```
**Trigger:** Any param changes = L3 hash changes = fresh run ✅

---

### Layer 4: VERSION (App Version)
```python
APP.VERSION  # "16.73.0"
# Simple hash of version string forces re-run on any version upgrade
L4 = SHA256(APP.VERSION.encode())
```
**Trigger:** App upgrade = L4 hash changes = fresh run ✅

---

### Master Fingerprint
```python
MASTER = SHA256(L1 + L2 + L3 + L4)  # Concatenate 4 layer hashes, hash again
# Result: 32-character SHA-256 string
# If MASTER matches last run's saved MASTER → CACHE HIT
```

---

## Key Code Locations

### File: engine.py

**Fields (lines 383-391):**
```python
self._last_run_fingerprint: Optional[str] = None       # 32-char master
self._last_run_layer_hashes: dict = {}                 # {data, weights, config, version}
self._last_run_params: dict = {}                       # captured params
self._cache_hit_msg: str = ""
self._cache_miss_reason: str = ""
```

**Methods (lines 434-507):**
- `_hash_df(df)` — Full-content hash of single DataFrame
- `_compute_run_fingerprint(tables, weights, run_params, version)` — Master fingerprint + layers

**Persist hooks:**
- `save_last_run()` line 525-534 — Store FP before `db.finish_run()`
- `load_last_run()` line 562-573 — Restore FP from DB metadata on startup

---

### File: pages/dashboard.py

**Callback: run_pipeline() (lines 3615-3850)**

1. **Build params (line 3615-3628)**
   ```python
   _run_params_fp = {
       "max_customers": _effective_max,
       "norm_method": norm_method_val,
       "tier_mode": tier_mode_val,
       # ... etc ...
   }
   ```

2. **Compute FP (line 3630-3633)**
   ```python
   _new_fp, _new_layers = pipeline._compute_run_fingerprint(
       _last_pushed, weights, _run_params_fp, APP.VERSION
   )
   ```

3. **Compare (line 3634-3640)**
   ```python
   _is_exact_match = (
       pipeline._last_run_fingerprint is not None
       and _new_fp == pipeline._last_run_fingerprint
       and pipeline.scored_df is not None
   )
   ```

4. **Cache hit? Early return (line 3642-3690)**
   ```python
   if _is_exact_match:
       return (..., 100, _hit_msg, "teal", ...)  # ← 100% progress, no polling
   ```

5. **Fresh run (line 3692-3705)**
   ```python
   pipeline._last_run_fingerprint = _new_fp
   pipeline._last_run_layer_hashes = _new_layers
   pipeline._last_run_params = {"weights": weights, **_run_params_fp}
   # Then call run_background() normally
   ```

---

## Workflow: User Uploads Data → Runs Pipeline → Adjusts Weight → Runs Again

```
SESSION START
│
├─ User uploads data to Port Authority
│  └─ portal.tables = {customer: df, node: df, ...}
│
├─ User clicks "Run Pipeline" 
│  └─ run_pipeline() fires
│  │
│  ├─ Compute FP1 from (data, weights={c:0.15, co:0.10...}, config={...}, version="16.73.0")
│  ├─ No prior run → FP1 stored in pipeline._last_run_fingerprint
│  ├─ Call pipeline.run_background()
│  └─ Results saved + fingerprint persisted to DB
│
├─ Results load
│  └─ User sees dashboard with scored_df, analytics, reports
│
├─ User adjusts weight: centrality 0.15 → 0.20
│
├─ User clicks "Run Pipeline" again
│  └─ run_pipeline() fires
│  │
│  ├─ Compute FP2 from (data, weights={c:0.20, co:0.10...}, config={...}, version="16.73.0")
│  ├─ Compare: FP2 == FP1?  NO! L2 (weights hash) differs
│  ├─ Show orange badge: "Scoring weights changed → fresh run"
│  ├─ Store: pipeline._last_run_fingerprint = FP2
│  ├─ Call pipeline.run_background()
│  └─ Results saved + FP2 persisted to DB
│
├─ Results load (new weights applied)
│
├─ User clicks "Run Pipeline" one more time (no changes)
│  └─ run_pipeline() fires
│  │
│  ├─ Compute FP3 from (data, weights={c:0.20, co:0.10...}, config={...}, version="16.73.0")
│  ├─ Compare: FP3 == FP2?  YES! All 4 layers match
│  ├─ CACHE HIT! → Load from DB instantly
│  └─ Return: progress=100%, status="⚡ Exact Match", reload_from_db()
│
└─ Results load instantly (< 500ms)
```

---

## API Reference

### pipeline._compute_run_fingerprint()

**Signature:**
```python
@staticmethod
def _compute_run_fingerprint(
    tables: dict,
    weights: dict,
    run_params: dict,
    app_version: str,
) -> tuple:
```

**Returns:**
```python
(
    master_fp: "a1b2c3d4e5f6...",  # 32-char SHA-256
    layer_hashes: {
        "data":    "1111111111111111111111111111",
        "weights": "2222222222222222222222222222",
        "config":  "3333333333333333333333333333",
        "version": "4444444444444444444444444444",
    }
)
```

**Example usage:**
```python
from engine import FCDAIPipeline
pipeline = FCDAIPipeline()

fp, layers = pipeline._compute_run_fingerprint(
    tables={"customer": df1, "node": df2},
    weights={"centrality": 0.15, "community": 0.10},
    run_params={"max_customers": 500, "norm_method": "rank"},
    app_version="16.73.0"
)

print(f"Master FP: {fp}")
print(f"Data layer: {layers['data']}")
print(f"Weights layer: {layers['weights']}")
```

---

## Debugging Tips

### Check fingerprint state
```python
pipeline = get_pipeline()
print(f"Last run FP: {pipeline._last_run_fingerprint}")
print(f"Layer hashes: {pipeline._last_run_layer_hashes}")
print(f"Cache hit: {pipeline._last_run_was_cache_hit}")
print(f"Diff reason: {pipeline._cache_miss_reason}")
```

### Force fresh run (bypass cache)
```python
# Option 1: Modify any weight slightly
# Option 2: Upload new data / modify existing data
# Option 3: Clear memory (restart server)
```

### Verify FP persistence
```python
from utils.db_manager import get_db
db = get_db()
data = db.load_latest_run()
meta = data["run_info"]["metadata"]
print(f"Persisted FP: {meta.get('_fingerprint')}")
print(f"Layer hashes: {meta.get('_layer_hashes')}")
```

---

## Common Issues & Solutions

### Problem: "Cache hit not working after server restart"
**Cause:** FP not persisted correctly  
**Solution:** Check that fingerprint is added to `last_run_meta` BEFORE `db.finish_run()` call in `save_last_run()`

### Problem: "Weight change not triggering fresh run"
**Cause:** Weights not included in L2 calculation  
**Solution:** Ensure `_compute_run_fingerprint()` includes all 10 weights in L2

### Problem: "Same data re-uploaded shows cache hit when it shouldn't"
**Cause:** Likely database row order difference interpreted as "same"  
**Solution:** `_hash_df()` sorts rows lexicographically — this is correct (order-independent)

### Problem: "FP computation is slow"
**Cause:** Hashing ALL rows of large DataFrames  
**Solution:** This is expected. For 100k rows × 50 cols, ~1-2s is normal. Pipeline run is ~30-60s, so 2s overhead is acceptable (3% cost for true cache verification)

---

## Testing Checklist for New Releases

- [ ] Run pipeline with fresh data → FP1 stored
- [ ] Run again with NO changes → FP matches, cache hit occurs, results instant
- [ ] Change 1 weight → FP differs on L2, fresh run + orange badge shows "Weights changed"
- [ ] Change max_customers → FP differs on L3, fresh run + orange badge shows "Config changed"
- [ ] Upload new row to any table → FP differs on L1, fresh run + orange badge shows "Data changed"
- [ ] Restart server → FP still loaded from DB → next run with same data/weights = cache hit
- [ ] Delete a table → FP differs on L1 (table presence recorded), fresh run

---

## Performance Notes

| Operation | Time | Notes |
|-----------|------|-------|
| Hash 1000-row DataFrame | ~50-100ms | O(rows × cols) |
| Hash all 4 layers | ~0.5-2s total | Depends on data size |
| Compare FP strings | <1ms | Simple string equality |
| Load from DB (cache hit) | 200-500ms | Database query + memory load |
| Full pipeline run | 30-60s | Standard execution |

**Rule of thumb:** FP computation cost is ~2-3% of total pipeline time. Worth it for cache accuracy.

---

## Version History

- **v16.73.0** (Mar 2, 2026) — 4-layer fingerprint, TRUE cache skip
- **v16.72.0** (prev) — Shallow 16-char fingerprint, UI-only feedback

---

## Questions?

Refer to:
- [CHANGELOG_v16.73.md](./CHANGELOG_v16.73.md) — Full architectural details
- [engine.py](./engine.py) — Source code with inline comments (lines 434-573)
- [pages/dashboard.py](./pages/dashboard.py) — Callback implementation (lines 3615-3850)
