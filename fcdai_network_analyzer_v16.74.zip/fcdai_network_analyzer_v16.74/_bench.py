"""Quick benchmark to time each generator at n=500."""
import time, sys
sys.path.insert(0, '.')

from utils.sample_data import (
    generate_customers, generate_accounts, generate_kyc,
    generate_transactions, generate_historical, generate_alerts,
    generate_relationships, generate_cases,
    generate_nodes, generate_transaction_edges, generate_relationship_edges,
    generate_shared_attributes, generate_temporal_patterns,
    generate_all_samples
)

N = 500
SEED = 42

print(f"\n=== GENERATOR BENCHMARK (n={N}) ===")
timings = {}
for fn, call in [
    ('customers',          lambda: generate_customers(N, SEED)),
    ('accounts',           lambda: generate_accounts(N, SEED)),
    ('kyc',                lambda: generate_kyc(N, SEED)),
    ('transactions',       lambda: generate_transactions(N*5, N, 0.03, SEED)),
    ('historical',         lambda: generate_historical(N, SEED)),
    ('alerts',             lambda: generate_alerts(N, SEED)),
    ('relationships',      lambda: generate_relationships(N, SEED)),
    ('cases',              lambda: generate_cases(N, SEED)),
    ('nodes',              lambda: generate_nodes(N, SEED)),
    ('transaction_edges',  lambda: generate_transaction_edges(N*5, N, 0.03, SEED)),
    ('relationship_edges', lambda: generate_relationship_edges(N, SEED)),
    ('shared_attributes',  lambda: generate_shared_attributes(N, SEED)),
    ('temporal_patterns',  lambda: generate_temporal_patterns(N, SEED)),
]:
    t = time.monotonic()
    df = call()
    elapsed = time.monotonic() - t
    timings[fn] = elapsed
    print(f"  {fn:25s}: {elapsed:.4f}s  ({len(df):>5} rows)")

print(f"\n  {'SUBTOTAL':25s}: {sum(timings.values()):.4f}s")

t2 = time.monotonic()
tables = generate_all_samples(n_customers=N, n_transactions=N*5, seed=SEED)
total_time = time.monotonic() - t2
total_rows = sum(len(v) for v in tables.values())
print(f"\n  TOTAL generate_all_samples : {total_time:.4f}s  ({total_rows:,} total rows)")
print(f"\n=== SLOWEST 3 ===")
for k, v in sorted(timings.items(), key=lambda x: -x[1])[:3]:
    print(f"  {k:25s}: {v:.4f}s")
